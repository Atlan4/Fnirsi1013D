/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.c to edit this template
 */

//----------------------------------------------------------------------------------------------------------------------------------
#include "types.h"
#include "menu.h"
#include "test.h"
#include "scope_functions.h"
#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "spi_control.h"
#include "sd_card_interface.h"  //only diagnostic menu?
#include "display_lib.h"
#include "ff.h"
#include "DS3231.h"

#include "usb_interface.h"
#include "variables.h"

#include "sin_cos_math.h"
#include  "ref_and_math.h"

#include <string.h>



//----------------------------------------------------------------------------------------------------------------------------------
void display_REFx_data(void)  //display 
{
    //Check if REF1 CH1 is enabled
    if(scopesettings.channel1.ref1)
    {          
      display_set_fg_color(REF1_1_COLOR);
      ref1_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref1_sample=0;
    }
    
    //Check if REF1 CH2 is enabled
    if(scopesettings.channel2.ref1)
    {          
      display_set_fg_color(REF1_2_COLOR);
      ref1_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref1_sample=0;
     }
    
    //Check if REF2 CH1 is enabled
    if(scopesettings.channel1.ref2)
    {          
      display_set_fg_color(REF2_1_COLOR);
      ref2_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref2_sample=0;
    }
    
    //Check if REF2 CH2 is enabled
    if(scopesettings.channel2.ref2)
    {          
      display_set_fg_color(REF2_2_COLOR);
      ref2_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref2_sample=0;
     }
    
    //Check if REF3 CH1 is enabled
    if(scopesettings.channel1.ref3)
    {          
      display_set_fg_color(REF3_1_COLOR);
      ref3_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref3_sample=0;
    }
    
    //Check if REF3 CH2 is enabled
    if(scopesettings.channel2.ref3)
    {          
      display_set_fg_color(REF3_2_COLOR);
      ref3_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref3_sample=0;
     }
    
    //Check if REF4 CH1 is enabled
    if(scopesettings.channel1.ref4)
    {          
      display_set_fg_color(REF4_1_COLOR);
      ref4_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref4_sample=0;
    }
    
    //Check if REF4 CH2 is enabled
    if(scopesettings.channel2.ref4)
    {          
      display_set_fg_color(REF4_2_COLOR);
      ref4_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref4_sample=0;
     }
}

//----------------------------------------------------------------------------------------------------------------------------------    

void display_MATHx_data(void)  //display 
{
  //Check if mathmode is enabled
  if(mathmode)
  {        
    display_set_fg_color(MATH_COLOR);
    
    math_sample=1;
    compute_all_math_ops(channelA, channelB);
        
    scope_display_channel_linear_trace(&scopesettings.channel1);  
    math_sample=0;
  }
    
    
    
    
  
}

          /*
            for (uint32 i = 0; i < MAX_SAMPLE_BUFFER_SIZE; i++) 
            {  
                //scopesettings.channel2.tracebuffer[i]=0;
                //scopesettings.channel2.tracebuffer[i] = ((scopesettings.channel2.tracebuffer[i]) + (channel2tracebufferAVG[i]))/2;
                //channel2tracebufferAVG[i]=scopesettings.channel2.tracebuffer[i];
              if((channalA==1)&&(channalB==1){ scopesettings.math_tracebuffer[i] = ((scopesettings.channel1.tracebuffer[i]) + (scopesettings.channel2.tracebuffer[i]-128)); }
                
            }
            //memcpy(settings->ref_tracebuffer, (scopesettings.channel1.tracebuffer+scopesettings.channel2.tracebuffer), MAX_SAMPLE_BUFFER_SIZE);
           */

//----------------------------------------------------------------------------------------------------------------------------------   

void compute_all_math_ops(int channelA, int channelB) 
{
    int8 result = 0;
    uint8* A = get_channel_data(channelA);
    uint8* B = get_channel_data(channelB);

    if (!A || !B) return;  // Ošetrenie neplatného vstupu

    for (int i = 0; i < MAX_SAMPLE_BUFFER_SIZE; i++) 
    {
        int8 a = A[i];
        int8 b = B[i]-128;
        
        if (mathmode==1) result = a + b;
        if (mathmode==2) result = a - b;
        if (mathmode==3) result = (a * b)/100;
        if (mathmode==4) result = (b != 0) ? a / b : 0;
        
        scopesettings.math_tracebuffer[i] = result;
    }
}

uint8* get_channel_data(int channel) 
{
    switch (channel) {
        case 0: return channel1tracebuffer;
        case 1: return channel2tracebuffer;
        case 2: return channel1_ref1_tracebuffer;
        case 3: return channel2_ref1_tracebuffer;
        default: return NULL;
    }
}

//----------------------------------------------------------------------------------------------------------------------------------