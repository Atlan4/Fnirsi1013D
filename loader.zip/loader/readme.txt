FNIRSI Firmware Loader
v1.0.0

This utility can load/verify/delete binary firmware directly to the USB-connected oscilloscope or to an SD card in a card reader. It can also read/write/clear/compile/fix LCD/TP configuration sector and load/save it as a file.

The utility writes directly to the physical sectors of the selected device, so there is a potential risk of data corruption. As usual, use it at your own risk. But I tried to make it safe enough - it won't work with devices that aren't USB, recognized by the system as hard drives, have a non-512 byte sector size, containing a system volume, etc (and won't even put that devices on the list). Also it can read but will not write to physical sectors that falls within MBR and existing partitions of any type (except of RAW).

The "F1C100S" device (i.e. Allwinner CPU of Fnirsi 1013D/1014D oscilloscope) will be the selected device by default if it is present, then the software will look for SD/SDHC cards and then for other USB storage devices. Side effect: USB flash drives will also be on the list because I don't know of a reliable way to distinguish them from noname USB card readers.

The utility requires administrator rights to directly access the physical device. If you are using an administrative account, you do not need to start it as an administrator, elevation will be performed by software itself (you may just get a UAC warning). For a non-administrative account, you will be prompted for administrator credentials.

This software does not have any undocumented, trojan or destructive features, and does not use any third party libraries and components. It does not write anything to the file system or registry. It's made with Delphi VCL and pure Win32API. Software compatible with systems from Windows XP SP3 to Windows 11 (both X86 and X64). Any bug reports and suggestions are welcome.

How to use: For convenience, place this .exe in the same folder as the firmware binaries (and configuration binaries, if needed) and run. Do not worry about safely removing the device, the program writes data immediately, ignoring system caching.

PS: Sorry for not implementing automatic light/dark theme switching, ;-) maybe in the next version...
PPS: For curiosity and possible future use: disabled input fields can be unlocked by double-clicking on the label above it.