//----------------------------------------------------------------------------------------------------------------------------------

//Scan the touch panel

//Main state is displaying the scope data

//On touch the first action is to see where the touch is, so an array of boxes might be needed
//Difficulty lies in when a trace or cursor is selected.

//----------------------------------------------------------------------------------------------------------------------------------

#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "sd_card_interface.h"
#include "scope_functions.h"
#include "power_and_battery.h"
#include "display_lib.h"
#include "DS3231.h"
#include "menu.h"
#include "test.h"
#include "usb_interface.h"
#include "mass_storage_class.h"

#include "variables.h"
#include "update.h"

//----------------------------------------------------------------------------------------------------------------------------------
//touch handler

void touch_handler(void)
{
  //Check on touch state
  if(touchstate == TOUCH_STATE_INACTIVE)
  {
    //No touch yet so scan for it
    scan_for_touch();

    //When movement of object initiated previous settings need to be saved for updating
    if(touchstate)
    {
  
    }
  }
  else
  {
    //At this point the movement of the traces, cursors and pointers is handled
    //Read the touch panel status to get a new position or be done
    tp_i2c_read_status();
    
    //When no longer touched reset and quit
    if(havetouch == 0)
    {
      //Signal done with moving
      touchstate = TOUCH_STATE_INACTIVE;

      //That's it for now
      return;
    }

    //Slow things down a bit. This is not a proper solution but will do for now
    //timer0_delay(50);  //before 0.26v4



   
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//Top menu bar ranges from 0,0 to 730,46        //44
//Right menu bar ranges from 730,0 to 800,480

void scan_for_touch(void)
{
  uint32 offset;

  //Read the touch panel status
  tp_i2c_read_status();
  
  //Check if the panel is not touched
  if(havetouch == 0)
  {
    //Quit if so
    return;
  }
  
  //scope_test_TP();
  //xtouch_tmp=xtouch;
  //ytouch_tmp=ytouch;

  //Draw directly to screen
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Scan for where the touch is applied

  //Check if in maximum lignt button range
  if((xtouch >= MAXLIGHT_BUTTON_XPOS) && (xtouch <= MAXLIGHT_BUTTON_XPOS+MAXLIGHT_BUTTON_WIDTH) && (ytouch <= 50)) //535 545
  {
    //Set the button active
    scope_maxlight_item(2);
    
    //Wait until touch is released
    tp_i2c_wait_for_touch_release();

    //Toggle the max backlight brightness
    scopesettings.maxlight ^= 1;

    if(scopesettings.maxlight == 0)
    {
      //Set the icon to white sun
      scope_maxlight_item(0);
      //Set backlight brightness to user set value
      scope_set_maxlight(0);
    }
    else
    {  
      //Set the icon to yellow sun
      scope_maxlight_item(1);
      //Set backlight brightness to max
      scope_set_maxlight(1);
    }
  }
  
//---------------------------- PECO firmware download button ---------------------------------------
  
  //Check if touch Calibration data download button
  else if((xtouch >= 70) && (xtouch <= 136) && (ytouch >= 365) && (ytouch <= 400) && download_button_cal_data && button_status)   
  {
    //Highlight the download button Calibration data 
    scope_download_button(70, 354, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the download button Calibration data 
    scope_download_button(70, 354, 0);
               
    read_sdcard_to_file_with_progress("firmware Atlan & PECO/data.cal", CALIBRATION_DATA_SECTOR, 1);
    //read_sdcard_to_file_with_progress(const char* filename, uint32 start_sector, uint32 num_sectors);
    check_file("firmware Atlan & PECO/data.cal", 145, 375, 40 );
    button_enable();
  }
          
  //Check if touch TP & screen data download button
  else if((xtouch >= 70) && (xtouch <= 136) && (ytouch >= 429) && (ytouch <= 464) && download_button_TP_Screen_data && button_status)   
  {
    //Highlight the download button TP & screen data 
    scope_download_button(70, 414, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the download button TP & screen data 
    scope_download_button(70, 414, 0);
               
    read_sdcard_to_file_with_progress("firmware Atlan & PECO/TP_Screen.bin", TP_DISPLAY_CONFIG_SECTOR, 1);
    //read_sdcard_to_file_with_progress(const char* filename, uint32 start_sector, uint32 num_sectors); 
    check_file("firmware Atlan & PECO/TP_Screen.bin", 145, 435, 25);
    button_enable();
  }
          
//----------------------------- PECO firmware Upload button ----------------------------------------
  
  //Check if touch Boot Loader upload button
  else if((xtouch >= 280) && (xtouch <= 346) && (ytouch >= 125) && (ytouch <= 160) && button_status)   
  {
    //Highlight the upload button Boot Loader
    scope_upload_button(280, 110, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released
    tp_i2c_wait_for_touch_release();
        
    //Darken the upload button Boot Loader
    scope_upload_button(280, 110, 0);
              
    write_file_to_sdcard_with_progress("firmware Atlan & PECO/bootloader.bin", BOOT_PROGRAM_START_SECTOR); 
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO", "bootloader", BOOT_PROGRAM_START_SECTOR);
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO", "bootloader", ".bin", BOOT_PROGRAM_START_SECTOR);


  }
  
  //Check if touch Updater upload button
  else if((xtouch >= 280) && (xtouch <= 346) && (ytouch >= 185) && (ytouch <= 220) && button_status)   
  {
    //Highlight the upload button Updater
    scope_upload_button(280, 170, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released 
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button Updater
    scope_upload_button(280, 170, 0);
               
    write_file_to_sdcard_with_progress("firmware Atlan & PECO/updater.bin", UPDATE_PROGRAM_START_SECTOR); 
  }
  
  //Check if touch DSO firmware upload button
  else if((xtouch >= 280) && (xtouch <= 346) && (ytouch >= 245) && (ytouch <= 280) && button_status)   
  {
    //Highlight the upload button DSO firmware
    scope_upload_button(280, 230, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button DSO firmware
    scope_upload_button(280, 230, 0);
               
    write_file_to_sdcard_with_progress("firmware Atlan & PECO/scope.bin", DSO_PROGRAM_START_SECTOR); 
  }
  
  //Check if touch FPGA firmware upload button
  else if((xtouch >= 280) && (xtouch <= 346) && (ytouch >= 305) && (ytouch <= 340) && button_status)   
  {
    //Highlight the upload button FPGA firmware 
    scope_upload_button(280, 290, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button FPGA firmware 
    scope_upload_button(280, 290, 0);
               
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO/updater.bin", 80); 
  }
  
  //Check if touch Calibration data upload button
  else if((xtouch >= 280) && (xtouch <= 346) && (ytouch >= 369) && (ytouch <= 404) && button_status)   
  {
    //Highlight the upload button Calibration data 
    scope_upload_button(280, 354, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button Calibration data 
    scope_upload_button(280, 354, 0);
               
    write_file_to_sdcard_with_progress("firmware Atlan & PECO/data.cal", CALIBRATION_DATA_SECTOR); //708
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO", "calibration", ".cal", CALIBRATION_DATA_SECTOR);//708

  }
  
  //Check if touch TP & screen data upload button
  else if((xtouch >= 280) && (xtouch <= 346) && (ytouch >= 429) && (ytouch <= 464) && button_status)   
  {
    //Highlight the upload button TP & screen data 
    scope_upload_button(280, 414, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button TP & screen data 
    scope_upload_button(280, 414, 0);
               
    write_file_to_sdcard_with_progress("firmware Atlan & PECO/TP_Screen.bin", TP_DISPLAY_CONFIG_SECTOR); //708
  }
  
//----------------------------- FNIRSI firmware download button --------------------------------------

  //Check if touch SPI BACKUP Flash download button
  else if((xtouch >= 460) && (xtouch <= 526) && (ytouch >= 305) && (ytouch <= 340) && download_button_SPI_BACKUP_Flash && button_status)   
  //else if((xtouch >= 460) && (xtouch <= 526) && (ytouch >= 305) && (ytouch <= 340) && button_status)  
  {
    //Highlight the download button SPI BACKUP Flash
    scope_download_button(460, 290, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the download button SPI BACKUP Flash 
    scope_download_button(460, 290, 0);
               
    //read_file_to_sdcard_with_progress("firmware Atlan & PECO/CAL.bin", 709); 
    read_spi_flash_to_file_with_progress("firmware_FNIRSI_BACKUP/Fnirsi backup.bin");
    check_file("firmware_FNIRSI_BACKUP/Fnirsi backup.bin", 535, 311, 18);
    button_enable();
  }
  
//------------------------------ FNIRSI firmware Upload button ---------------------------------------
  
 //Check if touch SPI FLash upload button
  else if((xtouch >= 670) && (xtouch <= 736) && (ytouch >= 125) && (ytouch <= 160) && !download_button_SPI_BACKUP_Flash && button_status)   
  {
    //Highlight the upload button SPI FLash
    scope_upload_button(670, 110, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released
    tp_i2c_wait_for_touch_release();
        
    //Darken the upload button SPI FLash
    scope_upload_button(670, 110, 0);
              
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO/updater.bin", 80);
    write_file_to_spi_flash_with_progress("firmware_FNIRSI/Fnirsi 1013D.bin", 0x13000);
  }
  
  //Check if touch FPGA Flash upload button
  else if((xtouch >= 670) && (xtouch <= 736) && (ytouch >= 185) && (ytouch <= 220) && !download_button_SPI_BACKUP_Flash && button_status)   
  {
    //Highlight the upload button FPGA Flash
    scope_upload_button(670, 170, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released 
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button FPGA Flash
    scope_upload_button(670, 170, 0);
               
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO/updater.bin", 80); 
    write_file_to_spi_flash_with_progress("firmware_FNIRSI_FPGA/Fnirsi FPGA.bin", 0); //HEX
  }
  
  //Check if touch SPI BACKUP Flash upload button
  else if((xtouch >= 670) && (xtouch <= 736) && (ytouch >= 305) && (ytouch <= 340) && !download_button_SPI_BACKUP_Flash && button_status)   
  {
    //Highlight the upload button SPI BACKUP Flash 
    scope_upload_button(670, 290, 1); //710+66  414+15 414+50
    
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
       
    //Darken the upload button SPI BACKUP Flash
    scope_upload_button(670, 290, 0);
               
    
    write_file_to_spi_flash_with_progress("firmware_FNIRSI_BACKUP/Fnirsi backup.bin", 0);
            
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO/updater.bin", 80); 
  }
  

  
  
  //****************************************************************************
  
  else if((xtouch >= 413) && (xtouch <= 479) && (ytouch >= 429) && (ytouch <= 464)&& button_status)  //25-91-429-471   //700 410 //752 440
    //else if((xtouch >= 45) && (xtouch <= 95) && (ytouch >= 430) && (ytouch <= 460))   //700 410 //752 440
  { 
    //Highlight the button USB on-off
    scope_USB_button(413, 414, 1);//25 710+66  414+15 414+57
        
    //deactivation download and upload button
    button_disable();
        
    tp_i2c_wait_for_touch_release();
             
    //Button for USB on-off
    //scope_USB_button(25, 414, 0);//20 415
  
    //f_mount(NULL, "", 0);
    
    
    //Start the USB interface
    usb_device_enable();

    //Re-sync the system files
    //scope_sync_thumbnail_files();
  }
         //Check if touch EXIT button
  else if((xtouch >= 710) && (xtouch <= 776) && (ytouch >= 429) && (ytouch <= 471))   //700 410 //752 440
      //else if((xtouch >= 730) && (xtouch <= 780) && (ytouch >= 430) && (ytouch <= 460))   //700 410 //752 440
  {
    //scope_test_TP();
    
    //Highlight the button EXIT
    scope_exit_button(710, 414, 1);//410  710+66  414+15 414+57
    //Touched the text field so wait until touch is released  
    tp_i2c_wait_for_touch_release();
        
    //Button for EXIT
    scope_exit_button(710, 414, 0);
            
    if (mounted_to_PC)
    {
      scope_display_error();
    }
    else 
    {  
    //Stop the USB interface
    usb_device_disable();
    
    //Button for USB on-off
    scope_USB_button(413, 414, 0);//20 415
    
    //activation download and upload button
    //button_enable();
    
    //Check folder, create if missing
    ini_folders();
    
    download_button_cal_data = 1;
    download_button_TP_Screen_data = 1;
    download_button_SPI_BACKUP_Flash = 1;
    
    //Check files in folders
    check_firmware_files(); 
    
    //activation download and upload button
    button_enable();
    
      //load_picture("updater.bmp");
  //timer0_delay(5000);
    }
    

        
    //write_file_to_sdcard_with_progress("firmware Atlan & PECO/updater.bin", 80); 
        
    //Set the address to run the loaded main program
    //load_from_SDcard(DSO_PROGRAM_START_SECTOR);

    //break;
  }

 
} //end scan_for_touch

//----------------------------------------------------------------------------------------------------------------------------------
//**********************************************************************************************************************************
//----------------------------------------------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------------------------------------------

void handle_diagnostic_view_touch(void)
{
  //uint8 tmp;                            //for diagnostic menu
  //uint32 *ptr = STARTUP_CONFIG_ADDRESS; //for diagnostic menu
  //boot_menu_start = ptr[0] & 0x07;      //choice 1 for fnirsi firmware, 0 for peco firmware, 2 for FEL mode, 4 view choice menu

  //Stay in this mode as long as the return is not touched
  while(1)
  {
    //Read the touch panel status
    tp_i2c_read_status();

    //Check if the panel is touched
    if(havetouch)
    {
      //scope_test_TP();
      //Check if touch button DEFAULT
      if((xtouch >= 40) && (xtouch <= 90) && (ytouch >= 420) && (ytouch <= 460))//x110-160 370 420 420 460
        {
          //Highlight the button DEFAULT
          scope_restore_button(30, 410, 1);//x50//x100 360 410//550 360  //460 410
          
          //Load a default configuration
          //scope_reset_config_data();
          //scope_save_config_data();
        
          //Wait until touch is released
          tp_i2c_wait_for_touch_release();
        
          //Go diagnostic info
          scope_open_diagnostic_view();//scope_diagnostic_screen();
        
          //Display the text with font 3 and the red color
          display_set_fg_color(ORANGE_COLOR);
          display_set_font(&font_3);
  
          //display_text(435, 414, "Reset calibration values !!!");
          //display_text(75, 390, "Please run BASE CALIBRATION !!!"); //335 390
          display_text(85, 355, "Settings set do default !!!"); //x90 335 
        }        
      //Check if touch button RESTORE
        else if((xtouch >= 140) && (xtouch <= 190) && (ytouch >= 420) && (ytouch <= 460))//x110-160 370 420 420 460
        {
          //Highlight the button RESTORE
          scope_restore_button(130, 410, 1);//x100 360 410//550 360  //460 410
        
          reload_cal_data = 1;
          //Set stored input calibration values   
          //scope_load_input_calibration_data();
          reload_cal_data = 0;
        
          //Cancel to Input calibration
          calibrationfail = 0;

          //Wait until touch is released
          tp_i2c_wait_for_touch_release();
        
          //Go diagnostic info
          scope_open_diagnostic_view();//scope_diagnostic_screen();
        
          //Display the text with font 3 and the red color
          display_set_fg_color(RED_COLOR);
          display_set_font(&font_3);
  
          //display_text(435, 414, "Reset calibration values !!!");
          display_text(60, 355, "Please run BASE CALIBRATION !!!"); //x75 335 390 
        }
        //Check if touch button RESET
        else if((xtouch >= 240) && (xtouch <= 290) && (ytouch >= 420) && (ytouch <= 460))//x210-260 470 520 420 460
        {
          //Highlight the button RESET
          scope_reset_button(230, 410, 1);//x200 460 410//550 360  //460 410
        
          //Set default channel calibration values   
          //Set default channel Input calibration values
          for(uint8 index=0;index<7;index++)
            {
                //Set default Input calibration values
                scopesettings.channel1.input_calibration[index] = signal_adjusters[index];
                scopesettings.channel2.input_calibration[index] = signal_adjusters[index];
           
                //Set FPGA center level
                scopesettings.channel1.dc_calibration_offset[index] = 860;
                scopesettings.channel2.dc_calibration_offset[index] = 860;
            }
          
          //Set default ADC compensation values
          scopesettings.channel1.adc1compensation = 0;
          scopesettings.channel1.adc2compensation = 0;
          scopesettings.channel2.adc1compensation = 0;
          scopesettings.channel2.adc2compensation = 0; 
        
          //Set default DC shift values  
          scopesettings.channel1.dc_shift_center  = 112;
          scopesettings.channel1.dc_shift_size    = 220;
          scopesettings.channel1.dc_shift_value   = 385;
    
          scopesettings.channel2.dc_shift_center  = 112;
          scopesettings.channel2.dc_shift_size    = 220;
          scopesettings.channel2.dc_shift_value   = 385;
        
          //Ready to Input calibration
          calibrationfail = 1;

          //Wait until touch is released
          tp_i2c_wait_for_touch_release();
        
          //Go diagnostic info
          scope_open_diagnostic_view();//scope_diagnostic_screen();
        }
      /*
        //Check if touch button NEWAUTOSETUP
        //else if((ytouch >= 164) && (ytouch <= 221))
        else if((xtouch >= 328) && (xtouch <= 378) && (ytouch >= 30) && (ytouch <= 60))//588 638 30 60
        {
        //Toggle the new_autosetup
        scopesettings.new_autosetup ^= 1;
          
        //Show the state (autosetup button mode)
        // scope_display_slide_button(588, 40, scopesettings.new_autosetup, GREEN_COLOR);//600 400
          
        //Go diagnostic info
        scope_open_diagnostic_view();//scope_diagnostic_screen();
          
        //Wait until touch is released
        tp_i2c_wait_for_touch_release();
        }
        //Check if touch button DC shift calibration
        //else if((ytouch >= 223) && (ytouch <= 280))
        else if((xtouch >= 328) && (xtouch <= 378) && (ytouch >= 70) && (ytouch <= 100))//588 638 70 100
        {    
        //Toggle the shift_cal
        dc_shift_cal ^= 1;
          
        //Go diagnostic info
        scope_open_diagnostic_view();//scope_diagnostic_screen();
            
        //Wait until touch is released
        tp_i2c_wait_for_touch_release(); 
        }
        //Check if touch button Boot menu
        //else if((ytouch >= 282) && (ytouch <= 339))
        else if((xtouch >= 328) && (xtouch <= 378) && (ytouch >= 110) && (ytouch <= 140))//588 638 110 140
        {
        //Toggle the Boot_menu
        tmp = (boot_menu_start & 0x04)>>2;
        tmp ^= 1;
        boot_menu_start &= 0x03;
        boot_menu_start |= tmp<<2;
            
        //Go diagnostic info
        scope_open_diagnostic_view();//scope_diagnostic_screen();
            
        //Wait until touch is released
        tp_i2c_wait_for_touch_release(); 
        }   
        
        //Check if touch button Default start
        //else if((ytouch >= 341) && (ytouch <= 398))
        else if((xtouch >= 328) && (xtouch <= 378) && (ytouch >= 150) && (ytouch <= 180))
        {    
          
        //Highlight the button Default start
        scope_boot_button(328, 160); //588 160 1
        
        //Toggle the Default start
        tmp = (boot_menu_start & 0x03);
        if (tmp < 2) tmp++; else tmp = 0;  
        boot_menu_start &= 0x04;
        boot_menu_start |= tmp;
               
        //Go diagnostic info
        scope_open_diagnostic_view();//scope_diagnostic_screen();
            
        //Wait until touch is released
        tp_i2c_wait_for_touch_release(); 
        } 
        //Check if touch button lock cursors
        else if((xtouch >= 328) && (xtouch <= 378) && (ytouch >= 190) && (ytouch <= 220))//588 638 70 100
        {    
        //Toggle the lock cursors
        scopesettings.lockcursors ^= 1;
                  
        //Go diagnostic info
        scope_open_diagnostic_view();//scope_diagnostic_screen();
            
        //Wait until touch is released
        tp_i2c_wait_for_touch_release(); 
        }
      */
      //**--------------------------------------------------------
      //Check if touch EXIT button
      else if((xtouch >= 730) && (xtouch <= 780) && (ytouch >= 430) && (ytouch <= 460))   //700 410 //752 440
        {
            //Highlight the button EXIT
            scope_exit_button(710, 410, 1);
            //Touched the text field so wait until touch is released  
            tp_i2c_wait_for_touch_release();

            break;
        }
        
    }

    //Need to wait for touch to release before checking again
    tp_i2c_wait_for_touch_release();
  } //end while
  
  //------------- save settings diagnostic menu ------------------------
  //if(boot_menu_start == 1) boot_menu_start = 0x05;              //fnirsi firmware always with boot menu
  //ptr[0] = boot_menu_start;
  //SAVE the display configuration sector from DRAM to SDcart   //save boot menu and default start
  //sd_card_write(DISPLAY_CONFIG_SECTOR, 1, (uint8 *)0x81BFFC00);
        //-------------------------------------
}

//----------------------------------------------------------------------------------------------------------------------------------

int32 handle_confirm_delete(void)
{
  int32 choice = 0;

  //Save the screen rectangle where the menu will be displayed
  display_copy_rect_from_screen(310, 192, 180, 96);

  //display the confirm delete menu
  //Draw the background in gray
  display_set_fg_color(0x00202020);
  display_fill_rounded_rect(310, 192, 179, 95, 3);//180 96

  //Draw the border in a lighter gray
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(310, 192, 179, 95, 3);//180 96

  //Draw the buttons
  display_fill_rounded_rect(320, 228, 74, 50, 2);
  display_fill_rounded_rect(405, 228, 74, 50, 2);

  //White color for text and use font_3
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(340, 204, "Confirm to delete?");//204
  display_text(348, 245, "NO");//246
  display_text(431, 245, "YES");//246

  //wait for touch
  while(1)
  {
    //Read the touch panel status
    tp_i2c_read_status();

    //Check if the panel is touched
    if(havetouch)
    {
      //Check if touch is on "NO"
      if((xtouch >= 324) && (xtouch <= 390) && (ytouch >= 230) && (ytouch <= 276))
      {
        //Highlight the button
        display_set_fg_color(ITEM_ACTIVE_COLOR);
        display_fill_rounded_rect(320, 228, 74, 50, 2);
        
        //With the text in black
        display_set_fg_color(BLACK_COLOR);
        display_text(348, 246, "NO");
        
        //Set the chosen option
        choice = VIEW_CONFIRM_DELETE_NO;

        //Done so quit the loop
        break;
      }
      //Else check if touch on "YES"
      else if((xtouch >= 409) && (xtouch <= 475) && (ytouch >= 230) && (ytouch <= 276))
      {
        //Highlight the button
        display_set_fg_color(ITEM_ACTIVE_COLOR);
        display_fill_rounded_rect(405, 228, 74, 50, 2);
        
        //With the text in black
        display_set_fg_color(BLACK_COLOR);
        display_text(431, 246, "YES");
        
        //Set the chosen option
        choice = VIEW_CONFIRM_DELETE_YES;

        //Done so quit the loop
        break;
      }

      //Need to wait for touch to release before checking again
      tp_i2c_wait_for_touch_release();
    }
  }

  //Need to wait for touch to release before returning
  tp_i2c_wait_for_touch_release();

  //Restore the original screen
  display_copy_rect_to_screen(310, 192, 180, 96);

  //return the choice
  return(choice);
}

//----------------------------------------------------------------------------------------------------------------------------------
