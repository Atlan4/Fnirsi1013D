openocd -f STM32F103C8T6.cfg
