#ifndef BUILD_TIME_H
#define BUILD_TIME_H
#define COMPILE_YEAR 25
#define COMPILE_MONTH 11
#define COMPILE_DAY 10
#define COMPILE_HOUR 9
#define COMPILE_MIN 12
#define COMPILE_SEC 11
#endif
