//The connections are:
//  PA2:  SDA
//  PA3:  SCL
/*
#include <avr/io.h>
#include <util/twi.h>
#include <util/delay.h>          //kniznica pre oneskorenia
*/

#include "variables.h"
#include "touchpanel.h"
#include "DS3231.h"

//#include	<stdio.h>
//#include 	"lcd.h"

//***********************************************************
//----------------------------------------------------------
//***********************************************************
void readtime(void)
	{
	uint8 buftimeX[3];	// 
        uint8 jedsec,jedmin,jedhod,dessec,desmin,deshod;

        tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 3);
  
	dessec=buftimeX[0]>>4;
	dessec&=7;
	jedsec=buftimeX[0]&15;

	desmin=buftimeX[1]>>4;
	desmin&=7;
	jedmin=buftimeX[1]&15;

	deshod=buftimeX[2]>>4;
	deshod&=3;
        jedhod=buftimeX[2]&15;
        
        //if(deshod)buftime[0]=deshod+48; else buftime[0]=' ';
        buftime[0]=deshod+48;
        
        buftime[1]=jedhod+48;
        buftime[2]=':';
        buftime[3]=desmin+48;
        buftime[4]=jedmin+48;
        buftime[5]=':';
        buftime[6]=dessec+48;
        buftime[7]=jedsec+48;
        buftime[8]=0;           //end of string   
	}
//;---------------------------------------------------------------
//****************************************************************
void settime (void)		//;prenos i2c DS3231
	{
        //unsigned char tmp=0;
        uint8 buftimeX[7];
        uint8 ddate,jdate;
        uint8 dmonth,jmonth;
        uint8 dyear,jyear;
        
        
    
        
        deshod=1;
        jedhod=2;
        desmin=5;
        jedmin=5;
        
        ddate=2;        //02
        jdate=2;
        dmonth=1;       //12
        jmonth=2;
        dyear=2;        //2023
        jyear=3;

        buftimeX[0]=0;          //set 0sec
	buftimeX[1]=desmin<<4;  //set min
	buftimeX[1]|=jedmin;

	buftimeX[2]=deshod<<4;  //set hour
	buftimeX[2]|=jedhod;
        buftimeX[3]=6;          //set day
        
        
        buftimeX[4]=ddate<<4;          //set date
        buftimeX[4]|=jdate;
        
        buftimeX[5]=dmonth<<4;         //set month
        buftimeX[5]|=jmonth;

        buftimeX[6]=dyear<<4;          //set year 20xx
        buftimeX[6]|=jyear;
         
        

	 //tp_i2c_send_data(RTC_DEVICE_ADDR, TP_STATUS_REG, data, 1);
        //tp_i2c_send_data(uint8 adr_dev, uint16 reg_addr, uint8 *buffer, uint32 size)
        uint8 RTC_CMD_REG = 0; //start register for writing
        tp_i2c_send_data(RTC_DEVICE_ADDR, RTC_CMD_REG, buftimeX, 7);

	return;
	}
//****************************************************************
//*************************  Set time  ***************************
//****************************************************************
void minp (void)
	{
	if (jedmin<9) jedmin++; 
		else {jedmin=0; if (desmin<5) desmin++; 
			else {desmin=0;}}
	settime();
	return;
	}
//--------------------------------------------------
void hodp (void)
	{
	if ((deshod==2)&(jedhod==3)){deshod=0;jedhod=0;} 
	else {
 			if (jedhod<9) jedhod++;			
				else {jedhod=0; if (deshod<2) deshod++;
					else {deshod=0;}}
		 }
	settime();
	return;
	}
//------------------------------------------------------------------------------
//******************************************************************************
//strcatx(thumbnaildata->filename, timecode);
//strcatx(thumbnaildata->filename, readnameRTC);

 void modname ( int8 *d, int8 *s )
{  
   while(*d) d++;
   *d=0;
   d++;
    while(*s) 
    {
       *d = *s;
       d++; 
       s++;
    }
   *d=0; 
}
 
//-------------------------------------------------------
//******************************************************* 
 //***********************************************************
void readnameRTC(void)
	{
	uint8 buftimeX[7];	// 
        uint8 jedsec,jedmin,jedhod,dessec,desmin,deshod,dated,datej,day,monthd,monthj,yeard,yearj;

        tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 7);
  
	dessec=buftimeX[0]>>4;
	dessec&=7;
	jedsec=buftimeX[0]&15;

	desmin=buftimeX[1]>>4;
	desmin&=7;
	jedmin=buftimeX[1]&15;

	deshod=buftimeX[2]>>4;
	deshod&=3;
        jedhod=buftimeX[2]&15;
        
        day=buftimeX[3]&7;
        
	dated=buftimeX[4]>>4;
	dated&=3;
        datej=buftimeX[4]&15;
        
	monthd=buftimeX[5]>>4;
	monthd&=1;
        monthj=buftimeX[5]&15;

        yeard=buftimeX[6]>>4;
	yeard&=15;
        yearj=buftimeX[6]&15;
        
        
        filenameRTC[0]=yeard+48;
        filenameRTC[1]=yearj+48;
        filenameRTC[2]=monthd+48;
        filenameRTC[3]=monthj+48;
        filenameRTC[4]=dated+48;
        filenameRTC[5]=datej+48; 
        filenameRTC[6]='-';
        filenameRTC[7]=deshod+48;
        filenameRTC[8]=jedhod+48;
        filenameRTC[9]=desmin+48;
        filenameRTC[10]=jedmin+48;     
        filenameRTC[11]=dessec+48;
        filenameRTC[12]=jedsec+48;
        
        filenameRTC[13]=0;           //end of string 
	}
//;---------------------------------------------------------------
//****************************************************************
void decodethumbnailfilename (int8 *s)
{
   //int8 filename[32];
   uint8 x=0;
   uint8 dx=0;
   
   //finds 's'
   while(*s)
      {
      if (*s==115) {s=s+2;break;}   //115 is 's' and go 2positions right
      s++; 
      //dx++;
      }
   
   //copy *s to filename  
   while(*s) 
      {
      filenameRTC[x] = *s;
      s++;
      x++;
      }
   //x++;
   filenameRTC[x]=' ';
   x++;
   filenameRTC[x]='2';
   x++;
   filenameRTC[x]='0';
   x++;
   s++;
   
   //dx=1;
   //copy *s to filename  
   while(*s) 
      {
      filenameRTC[x] = *s;
      if (dx==1) {x++;filenameRTC[x]='.';}
      if (dx==3) {x++;filenameRTC[x]='.';}
      if (dx==8) {x++;filenameRTC[x]=':';}
      if (dx==10) {x++;filenameRTC[x]=':';}
      s++;
      x++;
      dx++;
      }  
   filenameRTC[x++]=0;
   /*
   x=0;
   while(filenameRTC[x]!= 0) 
      {
      *s = filenameRTC[x];
      x++;
      s++;  
      }
   //s++;
   *s=0;
   */
   /*
   while(*d) d++;
   *d=0;
   d++;
    while(*s) 
    {
       *d = *s;
       d++; 
       s++;
    }
   *d=0; 
   */
   
/*
 //copy *s to filename  
   while(*s) 
      {
      filename[x] = *s;
      s++;
      x++;
      }  
   filename[x++]=' ';
   

   
  //copy *d to filename 
   while(*d) 
      {
      filename[x] = *d;
      d++;
      dx++;
      x++;
      }  
   filename[x++]=0; //insert end
   
  //back to start and copy
   
   if (dx==13) d=d-15; 
   if (dx==14) d=d-16; 
   if (dx==15) d=d-17; 
   if (dx==16) d=d-18; 
   if (dx==17) d=d-19; 
     
    //d=d-16;
  
   x=0;
   while(filename[x]!= 0) 
      {
      *d = filename[x];
      x++;
      d++;  
      }
   *d=0;
  */
  }

//;---------------------------------------------------------------
//****************************************************************
DWORD get_fattime (void)
{
    uint8   tm_year,tm_mon,tm_mday,tm_hour,tm_min,tm_sec;
    uint8   tmp;
    uint8   buftimeX[7];
    
    if(RTCon) 
        {
        tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 7);
  
	tmp=(buftimeX[0]>>4)&7;	
	tm_sec=(buftimeX[0]&15)+(10*tmp);
        
        tmp=(buftimeX[1]>>4)&7;	
	tm_min=(buftimeX[1]&15)+(10*tmp);
        
        tmp=(buftimeX[2]>>4)&3;	
	tm_hour=(buftimeX[2]&15)+(10*tmp);
        
        tmp=(buftimeX[4]>>4)&3;	
	tm_mday=(buftimeX[4]&15)+(10*tmp);
        
        tmp=(buftimeX[5]>>4)&1;	
	tm_mon=(buftimeX[5]&15)+(10*tmp);
        
        tmp=(buftimeX[6]>>4)&15;	
	tm_year=(buftimeX[6]&15)+(10*tmp);

   
        //return date and time
        return (DWORD)(tm_year+20) << 25 |
               (DWORD)(tm_mon) << 21 |
               (DWORD)(tm_mday-20) << 16 |
               (DWORD)(tm_hour-1) << 11 |
               (DWORD)tm_min << 5 |
               (DWORD)tm_sec >> 1; 
    } else 
        //Some date and time value
        return(1449957149);   //Ne 12. marec 2023, 19:56:58
}




