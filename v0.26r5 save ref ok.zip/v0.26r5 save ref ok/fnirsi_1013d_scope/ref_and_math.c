/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.c to edit this template
 */

//----------------------------------------------------------------------------------------------------------------------------------
#include "types.h"
#include "menu.h"
#include "test.h"
#include "scope_functions.h"
#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "spi_control.h"
#include "sd_card_interface.h"  //only diagnostic menu?
#include "display_lib.h"
#include "ff.h"
#include "DS3231.h"

#include "usb_interface.h"
#include "variables.h"

#include "sin_cos_math.h"
#include  "ref_and_math.h"

#include <string.h>



//----------------------------------------------------------------------------------------------------------------------------------
void display_REFx_data(void)  //display 
{
    //Check if REF1 CH1 is enabled
    if(scopesettings.channel1.ref1)
    {          
      display_set_fg_color(REF1_1_COLOR);
      ref1_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref1_sample=0;
    }
    
    //Check if REF1 CH2 is enabled
    if(scopesettings.channel2.ref1)
    {          
      display_set_fg_color(REF1_2_COLOR);
      ref1_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref1_sample=0;
     }
    
    //Check if REF2 CH1 is enabled
    if(scopesettings.channel1.ref2)
    {          
      display_set_fg_color(REF2_1_COLOR);
      ref2_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref2_sample=0;
    }
    
    //Check if REF2 CH2 is enabled
    if(scopesettings.channel2.ref2)
    {          
      display_set_fg_color(REF2_2_COLOR);
      ref2_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref2_sample=0;
     }
    
    //Check if REF3 CH1 is enabled
    if(scopesettings.channel1.ref3)
    {          
      display_set_fg_color(REF3_1_COLOR);
      ref3_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref3_sample=0;
    }
    
    //Check if REF3 CH2 is enabled
    if(scopesettings.channel2.ref3)
    {          
      display_set_fg_color(REF3_2_COLOR);
      ref3_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref3_sample=0;
     }
    
    //Check if REF4 CH1 is enabled
    if(scopesettings.channel1.ref4)
    {          
      display_set_fg_color(REF4_1_COLOR);
      ref4_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel1);  
      ref4_sample=0;
    }
    
    //Check if REF4 CH2 is enabled
    if(scopesettings.channel2.ref4)
    {          
      display_set_fg_color(REF4_2_COLOR);
      ref4_sample=1;
      scope_display_channel_linear_trace(&scopesettings.channel2);  
      ref4_sample=0;
     }
}

//----------------------------------------------------------------------------------------------------------------------------------    

void display_MATHx_data(void)  //display 
{
  //Check if mathmode is enabled
  if(mathmode)
  {        
    display_set_fg_color(MATH_COLOR);
    
    math_sample=1;
    compute_all_math_ops(channelA, channelB);
        
    scope_display_channel_linear_trace(&scopesettings.channel1);  
    math_sample=0;
  }
    
    
    
    
  
}

          /*
            for (uint32 i = 0; i < MAX_SAMPLE_BUFFER_SIZE; i++) 
            {  
                //scopesettings.channel2.tracebuffer[i]=0;
                //scopesettings.channel2.tracebuffer[i] = ((scopesettings.channel2.tracebuffer[i]) + (channel2tracebufferAVG[i]))/2;
                //channel2tracebufferAVG[i]=scopesettings.channel2.tracebuffer[i];
              if((channalA==1)&&(channalB==1){ scopesettings.math_tracebuffer[i] = ((scopesettings.channel1.tracebuffer[i]) + (scopesettings.channel2.tracebuffer[i]-128)); }
                
            }
            //memcpy(settings->ref_tracebuffer, (scopesettings.channel1.tracebuffer+scopesettings.channel2.tracebuffer), MAX_SAMPLE_BUFFER_SIZE);
           */

//----------------------------------------------------------------------------------------------------------------------------------   

void compute_all_math_ops(int channelA, int channelB) 
{
    int8 result = 0;
    uint8* A = get_channel_data(channelA);
    uint8* B = get_channel_data(channelB);

    if (!A || !B) return;  // Ošetrenie neplatného vstupu

    for (int i = 0; i < MAX_SAMPLE_BUFFER_SIZE; i++) 
    {
        int8 a = A[i];
        int8 b = B[i]-128;
        
        if (mathmode==1) result = a + b;
        if (mathmode==2) result = a - b;
        if (mathmode==3) result = (a * b)/100;
        if (mathmode==4) result = (b != 0) ? a / b : 0;
        
        scopesettings.math_tracebuffer[i] = result;
    }
}

uint8* get_channel_data(int channel) 
{
    switch (channel) {
        case 0: return (uint8 *)channel1tracebuffer;
        case 1: return (uint8 *)channel2tracebuffer;
        case 2: return (uint8 *)channel1_ref1_tracebuffer;
        case 3: return (uint8 *)channel2_ref1_tracebuffer;
        default: return NULL;
    }
}

//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------

void scope_save_REFx_item_file(uint8 number)
{
uint32  newnumber;
  uint32  result;
  uint16 *fnptr;
  uint16 *eptr;
  


  //Save the current view type to be able to determine if the thumbnail file need to be reloaded
  uint32 currentviewtype = viewtype;

  //Switch to the given type
  viewtype = VIEW_TYPE_REF;

  //Load the thumbnail file for this type. Needed for finding the file name and to add the thumbnail
  if(scope_load_thumbnail_file() != 0)
  {
    //Loading the thumbnail file failed so no sense in going on
    return;
  }

  //Check if there is still room for a new item
  if(viewavailableitems >= VIEW_MAX_ITEMS)
  {
    //Show the user there is no more room for a new item
    scope_display_file_status_message(MESSAGE_THUMBNAIL_FILE_FULL, 1);

    //No sense to continue
    return;
  }

  //Set the end pointer
  //eptr = &viewfilenumberdata[viewavailableitems];
  
  //fnptr = number;
/*
  //Find the first free file number
  //Most likely a more efficient solution for this problem exists, but this beats the original code where they try if a file number is free on the SD card with f_open
  for(newnumber=1;newnumber<VIEW_MAX_ITEMS;newnumber++)
  {
    //Start at the beginning of the list
    fnptr = viewfilenumberdata;

    //Go through the list to see if the current number is in the list
    while(fnptr < eptr)
    {
      //Check if this number is in the list
      if(*fnptr == newnumber)
      {
        //Found it, so quit the loop
        break;
      }

      //Select the next number entry
      fnptr++;
    }

    //Check if not found
    if(*fnptr != newnumber)
    {
      //Can use this number since it is not in the list
      break;
    }
  }
*/

  //Bump all the entries in the list up
  //memmove(&viewfilenumberdata[1], &viewfilenumberdata[0], viewavailableitems * sizeof(uint16));

  //Fill in the new number
  viewfilenumberdata[0] = number;

  //Bump the thumbnails up to make room for the new one
  //memmove(&viewthumbnaildata[1], &viewthumbnaildata[0], viewavailableitems * sizeof(THUMBNAILDATA));

  //Setup the filename for in the thumbnail
  scope_print_file_name(number);

  //Create the thumbnail
  scope_create_thumbnail(&viewthumbnaildata[0]);
  
    //Check if ref buffer is no empty
  if(1)
  {
    //Show the user there is no more room for a new item
    scope_display_file_status_message(MESSAGE_REF_BUFF_EMPTY_ERROR, 0);
    
    //No sense to continue
    return;
  }

  //One more item in the list
  //viewavailableitems++;

  //save the amended thumbnail file
  scope_save_thumbnail_file();

  //Copy the filename from the thumbnail filename, since the global one got written over in the saving of the thumbnail
  //Might need a re write of the message setup
  strcpy(viewfilename, viewthumbnaildata[0].filename); 
  
  //Open the new file. On failure signal this and quit
  result = f_open(&viewfp, viewfilename, FA_CREATE_ALWAYS | FA_WRITE);
  
  //Open the new file. On failure signal this and quit
  //result = f_open(&viewfp, viewfilename, FA_CREATE_ALWAYS | FA_WRITE);

  //Check if file created without problems
  if(result == FR_OK)
  {
    //For the waveform the setup and the waveform data needs to be written
    //Save the settings for the trace portion of the data and write them to the file
    scope_prepare_setup_for_REFx_file(number);
    
    if(number == 1)
    { 
      //Write the setup data to the file
      if((result = f_write(&viewfp, viewfilesetupdata, 16, 0)) == FR_OK)
      {
        //Write the trace data to the file
        //Save the channel 1 raw sample data
        if((result = f_write(&viewfp, (uint8 *)channel1_ref1_tracebuffer, 3000, 0)) == FR_OK)
        {
          //Save the channel 2 raw sample data
          result = f_write(&viewfp, (uint8 *)channel2_ref1_tracebuffer, 3000, 0); 
        }
      }
    }
    
    else if(number == 2)
    { 
      //Write the setup data to the file
      if((result = f_write(&viewfp, viewfilesetupdata, sizeof(viewfilesetupdata), 0)) == FR_OK)
      {
        //Write the trace data to the file
        //Save the channel 1 raw sample data
        if((result = f_write(&viewfp, (uint8 *)channel1_ref2_tracebuffer, 3000, 0)) == FR_OK)
        {
          //Save the channel 2 raw sample data
          result = f_write(&viewfp, (uint8 *)channel2_ref2_tracebuffer, 3000, 0);
        }
      }
    }
    
    else if(number == 3)
    { 
      //Write the setup data to the file
      if((result = f_write(&viewfp, viewfilesetupdata, sizeof(viewfilesetupdata), 0)) == FR_OK)
      {
        //Write the trace data to the file
        //Save the channel 1 raw sample data
        if((result = f_write(&viewfp, (uint8 *)channel1_ref3_tracebuffer, 3000, 0)) == FR_OK)
        {
          //Save the channel 2 raw sample data
          result = f_write(&viewfp, (uint8 *)channel2_ref3_tracebuffer, 3000, 0);
        }
      }
    }
    
    else if(number == 4)
    { 
      //Write the setup data to the file
      if((result = f_write(&viewfp, viewfilesetupdata, sizeof(viewfilesetupdata), 0)) == FR_OK)
      {
        //Write the trace data to the file
        //Save the channel 1 raw sample data
        if((result = f_write(&viewfp, (uint8 *)channel1_ref4_tracebuffer, 3000, 0)) == FR_OK)
        {
          //Save the channel 2 raw sample data
          result = f_write(&viewfp, (uint8 *)channel2_ref4_tracebuffer, 3000, 0);
        }
      }
    }
    
    //Close the file
    f_close(&viewfp);

    //Check if all went well
    if(result == FR_OK)
    {
      //Show the saved successful message
      scope_display_file_status_message(MESSAGE_SAVE_SUCCESSFUL, 0);
    }
    else
    {
      //Signal unable to write to the file
      scope_display_file_status_message(MESSAGE_FILE_WRITE_FAILED, 0);
    }
  }
  else
  {
    //Signal unable to create the file
    scope_display_file_status_message(MESSAGE_FILE_CREATE_FAILED, 0);
  }

}

//----------------------------------------------------------------------------------------------------------------------------------

//These functions are for handling the settings to and from file
void scope_prepare_setup_for_REFx_file(uint8 number)
{
  uint32 *ptr = viewfilesetupdata;
  uint32 index = 0;
  //uint32 channel;
  //uint32 measurement;
  uint32 checksum = 0;

  //Best to clear the buffer first since not all bytes are used for settings
  //memset((uint8 *)viewfilesetupdata, 0, sizeof(viewfilesetupdata));

  //Put in a version number for the waveform view file
  ptr[1] = WAVEFORM_FILE_VERSION;
  /*
  //Leave some space for other cursor settings changes  6
  index = CURSOR_SETTING_OFFSET;
  
  //Copy the cursor settings                    
  ptr[index++] = scopesettings.timecursorsenable;
  ptr[index++] = scopesettings.voltcursorsenable;
  ptr[index++] = scopesettings.timecursor1position;
  ptr[index++] = scopesettings.timecursor2position;
  ptr[index++] = scopesettings.voltcursor1position;
  ptr[index++] = scopesettings.voltcursor2position;
  ptr[index++] = scopesettings.lockcursors; //lock move cursors
  

  */
  /*
  //Calculate a checksum over the settings data
  for(index=1;index<VIEW_NUMBER_OF_SETTINGS;index++)
  {
    checksum += ptr[index];
  }
  */
  //Add the sample data too
  for(index=0;index<750;index++)
  {
    if(number == 1)
    { 
      //Add both the channels
      checksum += channel1_ref1_tracebuffer[index];
      checksum += channel2_ref1_tracebuffer[index];
    }
    else if(number == 2)
    { 
      //Add both the channels
      checksum += channel1_ref2_tracebuffer[index];
      checksum += channel2_ref2_tracebuffer[index];
    }
    else if(number == 3)
    { 
      //Add both the channels
      checksum += channel1_ref3_tracebuffer[index];
      checksum += channel2_ref3_tracebuffer[index];
    }
    else if(number == 4)
    { 
      //Add both the channels
      checksum += channel1_ref4_tracebuffer[index];
      checksum += channel2_ref4_tracebuffer[index];
    }
  }

  //Store the checksum at the beginning of the file
  ptr[0] = checksum;
}

//----------------------------------------------------------------------------------------------------------------------------------
