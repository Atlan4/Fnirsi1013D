open_project FPGA.al
import_device ef2_4.db -package EF2L45LG144B
elaborate -top fnirsi_1013D
read_adc zaklad.adc
optimize_rtl
read_sdc zaklad.sdc
optimize_gate
place
route
report_area -io_info -file FPGA_phy.area
report_timing -mode FINAL -net_info -ep_num 3 -path_num 3 -file FPGA_phy.timing
bitgen -bit FPGA.bit -version 0X10 -g ucode:011011100000000000000000 -bin FPGA.bin
