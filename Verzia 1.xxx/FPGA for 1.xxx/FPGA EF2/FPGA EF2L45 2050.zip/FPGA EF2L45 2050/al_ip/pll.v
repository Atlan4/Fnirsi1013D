/************************************************************\
 ** EF2L45 port of the fnirsi-1013d-mcp FPGA (0x153F).
 ** Written by hand after the TD 5.0.28716 IP generator output of the EF2L45 board project
 ** (al_ip/pll.v, 2026-02-22: C0 / C1) with the AL3 0x153F outputs C2 / C3 added.
\************************************************************/

///////////////////////////////////////////////////////////////////////////////
//	Input frequency:             50.000Mhz
//	Clock multiplication factor: 4
//	Clock division factor:       1
//	VCO 1000 MHz (CLKCn_DIV 5): CPHASE steps 1 ns, FPHASE steps 1/8 of that (125 ps), as on the AL3 PLL
//	Clock information:
//		Clock name	| Frequency 	| Phase shift
//		C0        	| 200.000000MHZ	| 0  DEG       clk_200MHz (feedback)
//		C1        	| 200.000000MHZ	| 90 DEG       clk_ADC, unused since 0x153E (kept as on the AL3)
//		C2        	| 200.000000MHZ	| 0  DEG       clk_ADCB: the B encodes' ODDRs
//		C3        	| 200.000000MHZ	| 27 DEG       clk_ADCA: the A encodes' ODDRs, 375 ps after C2
//	The 375 ps A / B offset was tuned on the AL3 board (fpga/al3/README.md section 19); on the EF2 board it is a
//	starting point only. pll.ipc still describes C0 / C1, so do not regenerate this file from the IP wizard
//	without adding C2 / C3 again.
///////////////////////////////////////////////////////////////////////////////
`timescale 1 ns / 100 fs

module pll(refclk,
		reset,
		clk0_out,
		clk1_out,
		clk2_out,
		clk3_out);

	input refclk;
	input reset;
	output clk0_out;
	output clk1_out;
	output clk2_out;
	output clk3_out;

	wire clk0_buf;

	EF2_LOGIC_BUFG bufg_feedback( .i(clk0_buf), .o(clk0_out) );

	EF2_PHY_PLL #(.DPHASE_SOURCE("DISABLE"),
		.DYNCFG("DISABLE"),
		.FIN("50.000"),
		.FEEDBK_MODE("NORMAL"),
		.FEEDBK_PATH("CLKC0_EXT"),
		.STDBY_ENABLE("DISABLE"),
		.PLLRST_ENA("ENABLE"),
		.SYNC_ENABLE("DISABLE"),
		.DERIVE_PLL_CLOCKS("ENABLE"),
		.GEN_BASIC_CLOCK("ENABLE"),
		.GMC_GAIN(4),
		.ICP_CURRENT(13),
		.KVCO(4),
		.LPF_CAPACITOR(1),
		.LPF_RESISTOR(4),
		.REFCLK_DIV(1),
		.FBCLK_DIV(4),
		.CLKC0_ENABLE("ENABLE"),
		.CLKC0_DIV(5),
		.CLKC0_CPHASE(4),
		.CLKC0_FPHASE(0),
		.CLKC1_ENABLE("ENABLE"),
		.CLKC1_DIV(5),
		.CLKC1_CPHASE(5),
		.CLKC1_FPHASE(2),
		.CLKC2_ENABLE("ENABLE"),
		.CLKC2_DIV(5),
		.CLKC2_CPHASE(4),
		.CLKC2_FPHASE(0),
		.CLKC3_ENABLE("ENABLE"),
		.CLKC3_DIV(5),
		.CLKC3_CPHASE(4),
		.CLKC3_FPHASE(3),
		.PU_INTP("DISABLE"),
		.INTPI(0),
		.HIGH_SPEED_EN("DISABLE"),
		.SSC_ENABLE("DISABLE"),
		.SSC_MODE("Down"),
		.SSC_AMP(0.0000),
		.SSC_FREQ_DIV(0),
		.SSC_RNGE(0),
		.FREQ_OFFSET(0.0000),
		.OFFSET_MODE("EXT"),
		.FREQ_OFFSET_INT(0),
		.CLKC0_DUTY(0.5000),
		.CLKC0_DUTY_INT(3),
		.CLKC0_DUTY50("ENABLE"),
		.CLKC1_DUTY(0.5000),
		.CLKC1_DUTY_INT(3),
		.CLKC1_DUTY50("ENABLE")	)	//EF2_PHY_PLL (TD 5.0.3 arch/ef2_macro.v) has DUTY parameters for C0 / C1 only
	pll_inst (.refclk(refclk),
		.reset(reset),
		.stdby(1'b0),
		.extlock(open),
		.load_reg(1'b0),
		.psclk(1'b0),
		.psdown(1'b0),
		.psstep(1'b0),
		.psclksel(3'b000),
		.psdone(open),
		.dclk(1'b0),
		.dcs(1'b0),
		.dwe(1'b0),
		.di(8'b00000000),
		.daddr(6'b000000),
		.do({open, open, open, open, open, open, open, open}),
		.fbclk(clk0_out),
		.clkc({open, open, open, clk3_out, clk2_out, clk1_out, clk0_buf}),
		.ssc_en(1'b0),
		.frac_offset_valid(1'b0),
		.dsm_refclk(1'b0),
		.dsm_rst(reset));

endmodule
