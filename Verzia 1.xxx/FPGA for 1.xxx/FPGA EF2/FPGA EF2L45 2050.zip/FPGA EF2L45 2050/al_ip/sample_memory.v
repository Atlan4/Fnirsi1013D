/************************************************************\
 ** EF2L45 port of the fnirsi-1013d-mcp FPGA (0x153F): the 8192 x 32 sample memory.
 ** The EF2L45 has 6 ERAM32K (1024 x 32 each) and 12 ERAM9K. The 32K blocks hold words 0 .. 6143 (as the
 ** EF2L45 board project's 6144-word sample_memory, IMPLEMENT "32K"), 8 of the 9K blocks hold words 6144 .. 8191.
 ** Same ports and timing as the AL3 IP: synchronous write on clka when cea, synchronous read on clkb
 ** (REGMODE NOREG, data valid after the clkb edge). The read mux select is registered on clkb with the address.
\************************************************************/

`timescale 1ns / 1ps

module sample_memory (
	dia, addra, cea, clka,
	dob, addrb, clkb
);

	output [31:0] dob;

	input  [31:0] dia;
	input  [12:0] addra;
	input  [12:0] addrb;
	input  cea;
	input  clka;
	input  clkb;

	wire hi_a = (addra[12:11] == 2'b11);       //word >= 6144
	wire hi_b = (addrb[12:11] == 2'b11);
	reg  hi_b_q = 1'b0;
	wire [31:0] dob_lo, dob_hi;

	always @(posedge clkb)
		hi_b_q <= hi_b;

	assign dob = hi_b_q ? dob_hi : dob_lo;

	EF2_LOGIC_BRAM #( .DATA_WIDTH_A(32),
				.DATA_WIDTH_B(32),
				.ADDR_WIDTH_A(13),
				.ADDR_WIDTH_B(13),
				.DATA_DEPTH_A(6144),
				.DATA_DEPTH_B(6144),
				.MODE("PDPW"),
				.REGMODE_A("NOREG"),
				.REGMODE_B("NOREG"),
				.WRITEMODE_A("NORMAL"),
				.WRITEMODE_B("NORMAL"),
				.RESETMODE("SYNC"),
				.IMPLEMENT("32K"),
				.INIT_FILE("NONE"),
				.FILL_ALL("NONE"))
			lo(
				.dia(dia),
				.dib({32{1'b0}}),
				.addra(addra),
				.addrb(addrb),
				.cea(cea & ~hi_a),
				.ceb(1'b1),
				.ocea(1'b0),
				.oceb(1'b0),
				.clka(clka),
				.clkb(clkb),
				.wea(1'b1),
				.web(1'b0),
				.bea(1'b0),
				.beb(1'b0),
				.rsta(1'b0),
				.rstb(1'b0),
				.doa(),
				.dob(dob_lo));

	EF2_LOGIC_BRAM #( .DATA_WIDTH_A(32),
				.DATA_WIDTH_B(32),
				.ADDR_WIDTH_A(11),
				.ADDR_WIDTH_B(11),
				.DATA_DEPTH_A(2048),
				.DATA_DEPTH_B(2048),
				.MODE("PDPW"),
				.REGMODE_A("NOREG"),
				.REGMODE_B("NOREG"),
				.WRITEMODE_A("NORMAL"),
				.WRITEMODE_B("NORMAL"),
				.RESETMODE("SYNC"),
				.IMPLEMENT("9K"),
				.INIT_FILE("NONE"),
				.FILL_ALL("NONE"))
			hi(
				.dia(dia),
				.dib({32{1'b0}}),
				.addra(addra[10:0]),
				.addrb(addrb[10:0]),
				.cea(cea & hi_a),
				.ceb(1'b1),
				.ocea(1'b0),
				.oceb(1'b0),
				.clka(clka),
				.clkb(clkb),
				.wea(1'b1),
				.web(1'b0),
				.bea(1'b0),
				.beb(1'b0),
				.rsta(1'b0),
				.rstb(1'b0),
				.doa(),
				.dob(dob_hi));

endmodule
