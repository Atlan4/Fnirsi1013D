`timescale 1ns/1ps
// EF2 port: al_ip/sample_memory.v (6144 words in 32K blocks + 2048 in 9K blocks) against a plain 8192 x 32 model
module tb;
  reg clka = 0, clkb = 0, cea = 0;
  reg [31:0] dia = 0; reg [12:0] addra = 0, addrb = 0;
  wire [31:0] dob;
  reg [31:0] rmem [0:8191]; reg [31:0] exp_q = 0;
  integer i, err = 0, n = 0, seed = 7;
  sample_memory dut(.dia(dia), .addra(addra), .cea(cea), .clka(clka), .dob(dob), .addrb(addrb), .clkb(clkb));
  initial for (i = 0; i < 8192; i = i + 1) rmem[i] = 0;
  always #5 clka = ~clka;
  always #20 clkb = ~clkb;
  always @(posedge clka) if (cea) rmem[addra] <= dia;
  always @(posedge clka) begin #1 dia <= $random(seed); addra <= $random(seed); cea <= $random(seed); end
  always @(posedge clkb) begin exp_q <= rmem[addrb]; end
  always @(negedge clkb) begin
    if (n > 2 && dob !== exp_q) begin err = err + 1; if (err < 5) $display("MISMATCH addr %0d dob %h exp %h", addrb, dob, exp_q); end
    n = n + 1; addrb <= (n & 1) ? $random(seed) : addrb + 1;
  end
  initial begin
    // fill every word once first so the read checks cover both halves
    #400000; $display("tb_ef2_mem: %0d reads, %0d mismatches: %s", n, err, err ? "FAIL" : "PASS"); $finish;
  end
endmodule
