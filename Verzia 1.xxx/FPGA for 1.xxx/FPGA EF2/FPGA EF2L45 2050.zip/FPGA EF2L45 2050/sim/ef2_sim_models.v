// EF2 port: tb/sim_models.v with the AL_LOGIC_* models renamed to the EF2_LOGIC_* macros the port instantiates
// Behavioural stand-ins for the Anlogic IP in fpga/al3/src/al_ip, for iverilog only.
// pll: clk0 = 200 MHz at 0 degrees, clk1 = 200 MHz at 90 degrees (1.25 ns later), as pll.ipc; clk2 / clk3 below.
// sample_memory: 8192 x 32 simple dual port, synchronous write on clka when cea, synchronous
// read on clkb (REGMODE NOREG: data valid after the clock edge). The read address is sampled
// through a 1 ps transport delay so a blocking update of the address register in the same
// time step (zaklad.v uses `sample_read_offset = ... + 1`) cannot race the read, as in hardware.
`timescale 1ns / 1ps

// clk2 / clk3: the B and A encode clocks of 0x153E (and of the encphase images, fpga/al3/README.md sections 19 and 21);
// the references (0x1532 .. 0x1535) and 0x153D and older leave them unused.
// run.sh sets PLL_C2_NS / PLL_C3_NS from the image's al_ip/pll.v (each output's rising edge after clk0's, ns, minus the
// IOB's 1.25 ns advance over the fabric encode route; see run.sh); clk1 stays at 1.25 for the references.
`ifndef PLL_C2_NS
`define PLL_C2_NS 1.25
`endif
`ifndef PLL_C3_NS
`define PLL_C3_NS 1.25
`endif
module pll (input refclk, input reset, output reg clk0_out = 0, output reg clk1_out = 0, output reg clk2_out = 0,
            output reg clk3_out = 0);
  always #2.5 clk0_out = ~clk0_out;
  initial begin
    #1.25;
    forever #2.5 clk1_out = ~clk1_out;
  end
  initial begin
    #(`PLL_C2_NS);
    forever #2.5 clk2_out = ~clk2_out;
  end
  initial begin
    #(`PLL_C3_NS);
    forever #2.5 clk3_out = ~clk3_out;
  end
endmodule

// sample_memory: the port's al_ip/sample_memory.v on the EF2_LOGIC_BRAM model below

// AL_LOGIC_BRAM (TD logic block RAM macro) as used by the 0x1536 sequencer RAMs: simple dual port
// ("PDPW": port A writes, port B reads), equal port widths, NORMAL write mode, REGMODE_B "NOREG" or
// "OUTREG" (one more clock of read latency, oceb = 1). Addresses are sampled through a 1 ps delay
// like sample_memory above, so a same-time-step update of an address register cannot race the read.
module EF2_LOGIC_BRAM #(
  parameter DATA_WIDTH_A = 9, parameter DATA_WIDTH_B = DATA_WIDTH_A,
  parameter ADDR_WIDTH_A = 10, parameter ADDR_WIDTH_B = ADDR_WIDTH_A,
  parameter DATA_DEPTH_A = 2 ** ADDR_WIDTH_A, parameter DATA_DEPTH_B = 2 ** ADDR_WIDTH_B,
  parameter MODE = "DP", parameter REGMODE_A = "NOREG", parameter REGMODE_B = "NOREG",
  parameter WRITEMODE_A = "NORMAL", parameter WRITEMODE_B = "NORMAL", parameter RESETMODE = "SYNC",
  parameter IMPLEMENT = "9K", parameter INIT_FILE = "NONE", parameter FILL_ALL = "NONE"
) (
  input  [DATA_WIDTH_A-1:0] dia,
  input  [ADDR_WIDTH_A-1:0] addra,
  input  cea, ocea, clka, wea, rsta,
  input  bea,
  input  [DATA_WIDTH_B-1:0] dib,
  input  [ADDR_WIDTH_B-1:0] addrb,
  input  ceb, oceb, clkb, web, rstb,
  input  beb,
  output [DATA_WIDTH_A-1:0] doa,
  output [DATA_WIDTH_B-1:0] dob
);
  reg [DATA_WIDTH_A-1:0] mem [0:DATA_DEPTH_A-1];
  reg [DATA_WIDTH_B-1:0] lat_b = 0, q_b = 0;
  wire [ADDR_WIDTH_A-1:0] addra_q;
  wire [ADDR_WIDTH_B-1:0] addrb_q;
  assign #0.001 addra_q = addra;
  assign #0.001 addrb_q = addrb;
  integer i;
  initial for (i = 0; i < DATA_DEPTH_A; i = i + 1) mem[i] = 0;
  always @(posedge clka) if (cea & wea) mem[addra_q] <= dia;
  always @(posedge clkb) begin
    if (ceb & ~web) lat_b <= mem[addrb_q];
    if (oceb) q_b <= lat_b;
  end
  assign dob = (REGMODE_B == "OUTREG") ? q_b : lat_b;
  assign doa = 0;
endmodule

// AL_LOGIC_ODDR (TD logic DDR output register; the encode pins since 0x153E), as TD's
// sim/al/al_logic_io.v without the global reset and the 0.1 ns clock-mux delay: d1 and d2 taken on the rising edge, the
// pin shows d1 from the rising edge and d2 from the falling edge. A register, not TD's mux of two, so the pin never
// glitches in zero time.
module EF2_LOGIC_ODDR #(parameter ASYNCRST = "DISABLE") (output reg q = 0, input clk, input d1, input d0, input rst);
  reg c0 = 0;
  always @(posedge clk) begin q <= d0; c0 <= d1; end
  always @(negedge clk) q <= c0;
endmodule

// AL_LOGIC_IDDR (TD logic DDR input register, 0x153A ADC capture), as TD's sim/al/al_logic_io.v without the global
// reset, with the TD EF2 port names: q0 = d at the rising edge, q1 = d at the falling edge, both on the next rising edge.
module EF2_LOGIC_IDDR #(parameter ASYNCRST = "DISABLE", parameter PIPEMODE = "PIPED") (output q1, output q0, input clk, input d, input rst);
  reg c0 = 0, c1 = 0, t0 = 0, t1 = 0;
  always @(negedge clk) c0 <= d;
  always @(posedge clk) begin c1 <= c0; t0 <= d; t1 <= t0; end
  assign q0 = t1;   //rising-edge sample (TD EF2 port name q0)
  assign q1 = c1;   //falling-edge sample (TD EF2 port name q1)
endmodule
