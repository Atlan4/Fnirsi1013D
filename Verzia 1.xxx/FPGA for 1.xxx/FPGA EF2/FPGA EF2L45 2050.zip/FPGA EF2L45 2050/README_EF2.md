# FPGA 0x2050 pre EF2L45 (FNIRSI 1013D)

**Build 2026-11-26 (TD 5.0.3, `build.tcl`):** 3299 LUT (74 %), 2968 registrov (66 %), 6 x BRAM32K + 8 x BRAM9K,
32 IDDR, 4 ODDR, časovanie 0 chýb na všetkých hodinách (najhorší slack +0.295 ns na clk_200MHz). Výstup `FPGA.bin` /
`FPGA.bit`, správy `FPGA_phy.area`, `FPGA_phy.timing`, log `build_2050_td.log`. Na časovanie bola v `sq_gen`
(generátor obdĺžnika) upravená dvojica ciest (počítadlo `cnt` a registrované `f_next`/`f_nn`), správanie rovnaké,
ale simuláciou zatiaľ neoverené. **Do skopu zatiaľ nenahraté.**

**0x2050** = tento port 0x153F s dvomi zmenami pre tvoj Atlan firmvér: príkaz 0x06 vracia `0x20 0x50` (rodina 2 = EF2,
verzie EF2 sú 0x2zzz, kde z sú len číslice 0-9 a čítajú sa dekadicky, takže 050; starý EF2 dizajn je 0x2000) a nový zápis **0x19** = hysterézia triggera v kódoch ADC (pri 0 presne ako 0x153F).
Zmeny: `diff_0x2050_vs_0x153F.patch`, pôvodný súbor `zaklad.v.orig_153F`. Firmvér MCP (vyžaduje presne 0x153F) s touto
verziou nepobeží.

Port FPGA dizajnu z `fnirsi-1013d-mcp` (`fpga/al3/src`, verzia 0x153F, Anlogic AL3A10) na **Anlogic EF2L45LG144B**,
pre Tang Dynasty 5.0.3 (5.0.28716), rovnaké TD ako tvoj pôvodný EF2 projekt.

## Čo je iné oproti AL3 verzii

| Vec | AL3 0x153F | EF2L45 port |
|---|---|---|
| Segmentovaný záznam a HW priemerovanie (0x1536) | áno | **vypnuté** (`EF2_NO_SEQ`) |
| CIC kompenzačný FIR (0x1535) | áno | **vypnuté** (`EF2_NO_FIR`) |
| Typy triggerov: šírka impulzu, N-tá hrana, timeout (0x153C) | áno | **vypnuté** (`EF2_NO_TRIGTYPES`, 2026-11-26: bez toho sa dizajn nezmestil do 2240 slice-ov). Hold-off 0x1B/0x66 a hysterézia 0x19 ostávajú |
| HW čítač frekvencie s min/max (0x153C C3) | áno | **vypnuté** (`EF2_NO_COUNTER`) |
| Všetko ostatné (EXT trigger, decimácia boxcar/CIC, typy triggerov, hold-off, peak detect, streaming logger, generátor, IOB capture, IOB enkódy) | áno | áno, bez zmeny logiky |
| Pamäť vzoriek | 8192 x 32 v 32 x EMB9K | 8192 x 32: 6144 slov v 6 x ERAM32K + 2048 slov v 8 x ERAM9K |
| PLL | AL_PHY_PLL, C0 200 MHz, C1 90°, C2 0°, C3 +375 ps | EF2_PHY_PLL, rovnaké výstupy a fázy |
| IDDR / ODDR | AL_LOGIC_IDDR / AL_LOGIC_ODDR | `ef2_iddr` / `ef2_oddr` v `ef2_io.v` (EF2_LOGIC_IDDR / EF2_LOGIC_ODDR) |
| Piny | AL3 pinout | piny z tvojho EF2 projektu (`zaklad.adc`) |
| Verzia (príkaz 0x06) | 0x153F | 0x2050 (firmvér MCP 0.3.0 s ňou nepobeží) |

Prečo: plná 0x153F má na AL3 6401 LUT a 5673 registrov, EF2L45 má 4480 LUT a 4480 registrov. Sekvencer navyše
potrebuje ďalších 2048 x 64 + 2048 x 32 RAM, na ktoré v EF2L45 popri 8192 x 32 vzorkách nezostane miesto.

Vypnuté funkcie: príkazy sa prijmú a ignorujú, čítania vracajú nuly (0x2A..0x32 a 0x35 samé nuly, 0x29 bajt 0 bit 5
"FIR aktívny" je vždy 0, 0x0A ukazuje bežný stav záznamu). **Firmware ich nesmie ponúkať** (segmenty, priemerovanie,
filtre "+FIR", counter), inak dostaneš nuly alebo nefiltrované dáta. Ak by si chcel niektorú vrátiť, zakomentuj
príslušný `` `define`` na začiatku `zaklad.v` (riadky `EF2_NO_*`). Pri sekvenceri sa to nezmestí.

Odhad veľkosti (yosys, prepočítané podľa toho, ako sa yosys a TD líšili na plnej AL3 verzii): okolo 3100 až 3400 LUT
a 3000 registrov, teda asi 70 až 76 % EF2L45. Je to len odhad, skutočné čísla dá TD v `FPGA_phy.area`. Ak ostane
rezerva, dá sa skúsiť vrátiť čítač (`EF2_NO_COUNTER`), na AL3 stál asi 350 LUT a 500 registrov.

## Súbory

| Súbor | Čo |
|---|---|
| `FPGA.al` | TD projekt pre EF2L45LG144B (UCode z tvojho EF2 projektu) |
| `zaklad.v` | top `fnirsi_1013D`, 0x153F so zmenami označenými `EF2_NO_*` a `ef2_iddr` / `ef2_oddr`, verzia 0x2050 |
| `ef2_io.v` | obal pre IDDR / ODDR, s náhradou na obyčajné flopy (`EF2_FABRIC_DDR`) |
| `al_ip/pll.v` | EF2_PHY_PLL s výstupmi C0..C3 (ručne doplnené C2 a C3, `pll.ipc` popisuje len C0/C1, **negeneruj ho znova cez IP wizard**) |
| `al_ip/sample_memory.v` | 8192 x 32 zo 6 x 32K + 2048 x 32 v 9K |
| `zaklad.adc` | piny z tvojho EF2 projektu; jediná zmena: `o_1khz_calib` (P94) má PULLDOWN kvôli EXT triggeru, ako na AL3 |
| `zaklad.sdc` | časové obmedzenia z AL3 0x153F bez zmeny (200 MHz, write clock ako generated clock, i_mcu_clk asynchrónny) |
| `FPGA commands.txt` | tabuľka príkazov z MCP (bez zmeny, platí okrem vypnutých funkcií) |
| `sim/` | simulačné modely EF2 makier a test pamäte, len pre iverilog |
| `diff_vs_al3_0x153F.patch` | všetky zmeny `zaklad.v` oproti AL3 originálu |

## Build v TD (GUI)

1. Rozbaľ priečinok niekam vedľa svojho starého projektu (napr. `~/Desktop/AnLogic/FPGA EF2L45 153F/`).
2. TD 5.0.3: **File > Open Project** a vyber `FPGA.al`. Ak by ho TD neotvoril (cesty v `.al`), sprav nový projekt
   pre EF2L45LG144B, top `fnirsi_1013D`, a pridaj `zaklad.v`, `ef2_io.v`, `al_ip/pll.v`, `al_ip/sample_memory.v`,
   `zaklad.adc`, `zaklad.sdc`.
3. Spusti celý flow až po **Generate Bitstream** (bin zapnutý, ako v starom projekte).
4. Skontroluj:
   - `FPGA_phy.area`: `#lut` a `#reg` pod 4480, `#bram32k 6`, `#bram9k 8` (alebo podobne), `#pll 1`,
     `#ireg` okolo 32 (IDDR na ADC pinoch), `#oreg` aspoň 4 (enkódy).
   - `FPGA_phy.timing`: clk_200MHz, sample_write_clock, i_mcu_clk a PLL výstupy **0 errors**. Na AL3 to vyšlo tesne
     (4.789 ns z 5 ns), na EF2 to môže chcieť pár pokusov alebo vypnutie ďalšej funkcie.
5. Výsledný `FPGA.bin` / `FPGA.bit` nahraj tak ako doteraz (TD Download). **Najprv si odlož zálohu** (máš
   `EF2 fnirsi backup.bin`).

Headless alternatíva (ako v MCP `build.tcl`, len pre EF2, neoverené):

```
open_project FPGA.al
import_device ef2_4.db -package EF2L45LG144B
elaborate -top fnirsi_1013D
read_adc zaklad.adc
optimize_rtl
read_sdc zaklad.sdc
optimize_gate
place
route
report_area -io_info -file FPGA_phy.area
report_timing -mode FINAL -net_info -ep_num 3 -path_num 3 -file FPGA_phy.timing
bitgen -bit FPGA.bit -version 0X10 -g ucode:011011100000000000000000 -bin FPGA.bin
```

## Čo som nemohol overiť (nemám TD)

1. **Mená a porty EF2 IDDR/ODDR makier** (overené 2026-11-26 v TD 5.0.3 `arch/ef2_macro.v` a
   `sim_release/ef2/ef2_logic_io.v`): `EF2_LOGIC_IDDR(q1, q0, clk, d, rst)`, q0 = vzorka pri nábežnej hrane,
   q1 = pri dobežnej; `EF2_LOGIC_ODDR(q, clk, d1, d0, rst)`, d0 ide na pin pri clk = 1, d1 pri clk = 0. Mená sú
   oproti AL3 prehodené, `ef2_io.v` ich mapuje správne. `CLKC2/3_DUTY*` parametre EF2_PHY_PLL nemá, z `pll.v` sú
   vyhodené.
2. **2048 x 32 v ERAM9K** (`IMPLEMENT("9K")`). Ak TD zahlási chybu, skús `"9K(FAST)"`, prípadne mi pošli hlášku.
3. **PLL C2/C3 na EF2.** Parametre som doplnil podľa vzoru C0/C1 z tvojho IP (CPHASE/FPHASE rovnako ako na AL3,
   VCO 1 GHz). Ak TD hlási neplatné parametre, vygeneruj PLL cez IP wizard so 4 výstupmi 200 MHz (0°, 90°, 0°, 27°).
4. **Časovanie na EF2 a na tvojej doske.** Fázy enkódov (A o 375 ps po B) a capture stupne boli ladené na AL3 doske.
   Po nahratí **spusti kalibračný wizard** vo firmvéri (Menu > Diagnostics > Calibrate), ktorý natrénuje capture
   stupne (0x63) pre tvoj kus. Ak budú dáta pri 200 MSa/s zlé, treba upraviť fázu C3 v `al_ip/pll.v`.
5. **Nastavenie konfigurácie EF2** (interný flash, `version 0x10` v `.al`) som prevzal z tvojho projektu bez zmeny.

## Čo som overil

Simulácia v iverilog s MCP testbenchmi, ktoré nepotrebujú git históriu (peak, stream, square, timeout, firstrec,
trigtypes, trigpos, adccap), seed 12345:

- **AL3 originál:** všetkých 8 PASS (kontrola, že testy tu bežia správne).
- **EF2 port so všetkými funkciami zapnutými** (EF2 makrá cez simulačné modely, `EF2_NO_*` zakomentované):
  všetkých 8 PASS. Zámena primitív teda logiku nemení.
- **EF2 port tak, ako je** (bez sekvencera, FIR a čítača): peak, square a adccap PASS. Ostatné padajú len v
  prípadoch, ktoré zapínajú FIR (`fir 1`) alebo segmenty (`HO0/HO1: 4 segments`), čo je očakávané. trigpos s FIR
  prípadmi prepnutými na bez FIR prešiel celou prvou fázou bez chyby (druhú fázu som pre čas nedokončil).
- Nová pamäť vzoriek 8192 x 32 (32K + 9K) proti referenčnému modelu: 10 000 náhodných čítaní, 0 chýb.

Simulácia neoverí EF2 makrá samotné (sú to moje modely podľa AL3), časovanie ani piny.
