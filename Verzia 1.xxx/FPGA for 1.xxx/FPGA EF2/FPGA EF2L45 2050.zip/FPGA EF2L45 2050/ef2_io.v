//-------------------------------------------------------------------------------------
// EF2L45 port of the fnirsi-1013d-mcp FPGA (0x153F): the IOB DDR registers.
// zaklad.v uses ef2_iddr for the 32 ADC data pins (0x153A capture) and ef2_oddr for the four ADC encode pins (0x153E).
//
// Behaviour the design relies on (same as AL_LOGIC_IDDR / AL_LOGIC_ODDR on the AL3):
//   ef2_iddr: q1 = d at the rising clk edge, q2 = d at the falling edge, both handed over on the next rising edge.
//   ef2_oddr: d1 / d2 taken on the rising edge; the pin shows d1 from the rising edge and d2 from the falling edge
//             (zaklad.v ties d1 = d2, so it is a single-rate output register packed in the IOB).
//
// Default: TD's EF2 macros, checked 2026-11-26 against TD 5.0.3 arch/ef2_macro.v and sim_release/ef2/ef2_logic_io.v:
//   EF2_LOGIC_IDDR (q1, q0, clk, d, rst): q0 = rising-edge sample, q1 = falling-edge sample (PIPEMODE "PIPED")
//   EF2_LOGIC_ODDR (q, clk, d1, d0, rst): d0 drives the high half of clk, d1 the low half
// so the EF2 port names are swapped against AL3 (q0/d0 = our q1/d1, q1/d1 = our q2/d2); mapped below. If TD has no such macros at all, define
// EF2_FABRIC_DDR (uncomment the line below): plain flops are used instead; TD 5 packs a plain output flop into the
// pad's OREG on the EF2 (the old EF2 project's o_1khz_calib shows PackReg OREG), but the falling-edge input flop
// may stay in the fabric, which makes the ADC capture instants placement dependent (retrain with the wizard).
//-------------------------------------------------------------------------------------
//`define EF2_FABRIC_DDR

module ef2_iddr (output q1, output q2, input clk, input d, input rst);
`ifdef EF2_FABRIC_DDR
  reg c0 = 0, c1 = 0, t0 = 0, t1 = 0;
  always @(negedge clk) c0 <= d;
  always @(posedge clk) begin c1 <= c0; t0 <= d; t1 <= t0; end
  assign q1 = t1;
  assign q2 = c1;
`else
  //TD 5.0.3 ef2_logic_io.v: q0 = rising-edge sample (PIPED: 2 posedge stages), q1 = falling-edge sample, both on next rising edge
  EF2_LOGIC_IDDR #(.ASYNCRST("DISABLE"), .PIPEMODE("PIPED")) u_iddr (.q1(q2), .q0(q1), .clk(clk), .d(d), .rst(rst));
`endif
endmodule

module ef2_oddr (output q, input clk, input d1, input d2, input rst);
`ifdef EF2_FABRIC_DDR
  reg r1 = 0, r2 = 0;
  always @(posedge clk) begin r1 <= d1; r2 <= d2; end
  //d1 = d2 in zaklad.v: a single-rate register on the rising edge
  assign q = r1;
`else
  //TD 5.0.3 ef2_logic_io.v: pin = d0 while clk is high, d1 (taken at posedge, moved at negedge) while clk is low
  EF2_LOGIC_ODDR #(.ASYNCRST("DISABLE")) u_oddr (.q(q), .clk(clk), .d1(d2), .d0(d1), .rst(rst));
`endif
endmodule
