open_project FPGA.al
import_device al3_10.db -package LQFP144
elaborate -top fnirsi_1013D
read_adc zaklad.adc
optimize_rtl
read_sdc zaklad.sdc
optimize_gate
set_param place opt_timing high
place
route
report_area -io_info -file FPGA_phy.area
report_timing -mode FINAL -net_info -ep_num 3 -path_num 3 -file FPGA_phy.timing
bitgen -bit FPGA.bit -version 0X00 -g ucode:00000000010101100000000000000000 -bin FPGA.bin
