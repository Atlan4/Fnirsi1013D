// Verilog netlist created by TD v5.0.28716
// Thu Nov 26 12:28:56 2026

`timescale 1ns / 1ps
module fnirsi_1013D  // zaklad.v(867)
  (
  i_adc1A_d,
  i_adc1B_d,
  i_adc2A_d,
  i_adc2B_d,
  i_mcu_clk,
  i_mcu_dcs,
  i_mcu_rws,
  i_xtal,
  o_ac_dc_1,
  o_ac_dc_2,
  o_adc1_encA,
  o_adc1_encB,
  o_adc2_encA,
  o_adc2_encB,
  o_offset_1,
  o_offset_2,
  o_pwm_display,
  o_relay1_1,
  o_relay1_2,
  o_relay1_3,
  o_relay2_1,
  o_relay2_2,
  o_relay2_3,
  io_mcu_data,
  o_1khz_calib
  );

  input [7:0] i_adc1A_d;  // zaklad.v(874)
  input [7:0] i_adc1B_d;  // zaklad.v(875)
  input [7:0] i_adc2A_d;  // zaklad.v(876)
  input [7:0] i_adc2B_d;  // zaklad.v(877)
  input i_mcu_clk;  // zaklad.v(871)
  input i_mcu_dcs;  // zaklad.v(873)
  input i_mcu_rws;  // zaklad.v(872)
  input i_xtal;  // zaklad.v(870)
  output o_ac_dc_1;  // zaklad.v(897)
  output o_ac_dc_2;  // zaklad.v(902)
  output o_adc1_encA;  // zaklad.v(889)
  output o_adc1_encB;  // zaklad.v(890)
  output o_adc2_encA;  // zaklad.v(891)
  output o_adc2_encB;  // zaklad.v(892)
  output o_offset_1;  // zaklad.v(893)
  output o_offset_2;  // zaklad.v(898)
  output o_pwm_display;  // zaklad.v(903)
  output o_relay1_1;  // zaklad.v(894)
  output o_relay1_2;  // zaklad.v(895)
  output o_relay1_3;  // zaklad.v(896)
  output o_relay2_1;  // zaklad.v(899)
  output o_relay2_2;  // zaklad.v(900)
  output o_relay2_3;  // zaklad.v(901)
  inout [7:0] io_mcu_data;  // zaklad.v(880)
  inout o_1khz_calib;  // zaklad.v(883)

  // localparam BUFFER_BITS = 13;
  // localparam BUFFER_SIZE = 8192;
  // localparam CAP_SEL_PO = 16'b0000011011011011;
  // localparam CAP_THR_PO = 8'b00001000;
  // localparam Q_DONE = 3'b111;
  // localparam Q_HOLD = 3'b110;
  // localparam Q_IDLE = 3'b000;
  // localparam Q_NEXT = 3'b101;
  // localparam Q_POST = 3'b011;
  // localparam Q_RUN = 3'b010;
  // localparam Q_TAB = 3'b100;
  // localparam Q_WEN = 3'b001;
  // localparam adc_iddr[0].adc_i = 0;
  // localparam adc_iddr[10].adc_i = 10;
  // localparam adc_iddr[11].adc_i = 11;
  // localparam adc_iddr[12].adc_i = 12;
  // localparam adc_iddr[13].adc_i = 13;
  // localparam adc_iddr[14].adc_i = 14;
  // localparam adc_iddr[15].adc_i = 15;
  // localparam adc_iddr[16].adc_i = 16;
  // localparam adc_iddr[17].adc_i = 17;
  // localparam adc_iddr[18].adc_i = 18;
  // localparam adc_iddr[19].adc_i = 19;
  // localparam adc_iddr[1].adc_i = 1;
  // localparam adc_iddr[20].adc_i = 20;
  // localparam adc_iddr[21].adc_i = 21;
  // localparam adc_iddr[22].adc_i = 22;
  // localparam adc_iddr[23].adc_i = 23;
  // localparam adc_iddr[24].adc_i = 24;
  // localparam adc_iddr[25].adc_i = 25;
  // localparam adc_iddr[26].adc_i = 26;
  // localparam adc_iddr[27].adc_i = 27;
  // localparam adc_iddr[28].adc_i = 28;
  // localparam adc_iddr[29].adc_i = 29;
  // localparam adc_iddr[2].adc_i = 2;
  // localparam adc_iddr[30].adc_i = 30;
  // localparam adc_iddr[31].adc_i = 31;
  // localparam adc_iddr[3].adc_i = 3;
  // localparam adc_iddr[4].adc_i = 4;
  // localparam adc_iddr[5].adc_i = 5;
  // localparam adc_iddr[6].adc_i = 6;
  // localparam adc_iddr[7].adc_i = 7;
  // localparam adc_iddr[8].adc_i = 8;
  // localparam adc_iddr[9].adc_i = 9;
  wire [7:0] adc1A_w;  // zaklad.v(1387)
  wire [7:0] adc1B_w;  // zaklad.v(1387)
  wire [7:0] adc2A_w;  // zaklad.v(1387)
  wire [7:0] adc2B_w;  // zaklad.v(1387)
  wire [31:0] adc_d1;  // zaklad.v(1326)
  wire [31:0] adc_d2;  // zaklad.v(1326)
  wire [31:0] adc_dd1;  // zaklad.v(1326)
  wire [31:0] adc_dd2;  // zaklad.v(1326)
  wire [31:0] adc_e1;  // zaklad.v(1326)
  wire [31:0] adc_e2;  // zaklad.v(1326)
  wire [31:0] adc_q1;  // zaklad.v(1325)
  wire [31:0] adc_q2;  // zaklad.v(1325)
  wire [12:0] addr_delta;  // zaklad.v(933)
  wire [31:0] cap_h;  // zaklad.v(1374)
  wire [15:0] cap_sel_x;  // zaklad.v(1337)
  wire [1:0] cap_st;  // zaklad.v(1373)
  wire [7:0] cap_thr;  // zaklad.v(1340)
  wire [7:0] cap_thr_x;  // zaklad.v(1338)
  wire [15:0] ch1_offset;  // zaklad.v(949)
  wire [15:0] ch2_offset;  // zaklad.v(950)
  wire [15:0] \channel1_dc_offset/count ;  // zaklad.v(192)
  wire [15:0] cic_out1;  // zaklad.v(1585)
  wire [15:0] cic_out2;  // zaklad.v(1585)
  wire [47:0] \dec_ch1/c1 ;  // zaklad.v(249)
  wire [47:0] \dec_ch1/c1p ;  // zaklad.v(249)
  wire [47:0] \dec_ch1/c2 ;  // zaklad.v(249)
  wire [47:0] \dec_ch1/c2p ;  // zaklad.v(249)
  wire [47:0] \dec_ch1/c3 ;  // zaklad.v(249)
  wire [47:0] \dec_ch1/d0 ;  // zaklad.v(249)
  wire [47:0] \dec_ch1/d0p ;  // zaklad.v(249)
  wire [10:0] \dec_ch1/f ;  // zaklad.v(247)
  wire [47:0] \dec_ch1/fine ;  // zaklad.v(275)
  wire [47:0] \dec_ch1/i1 ;  // zaklad.v(248)
  wire [47:0] \dec_ch1/i2 ;  // zaklad.v(248)
  wire [47:0] \dec_ch1/i3 ;  // zaklad.v(248)
  wire [7:0] \dec_ch1/n19 ;
  wire [7:0] \dec_ch1/n22 ;
  wire [47:0] \dec_ch1/n70 ;
  wire [47:0] \dec_ch1/n71 ;
  wire [47:0] \dec_ch1/n73 ;
  wire [47:0] \dec_ch1/n74 ;
  wire [47:0] \dec_ch1/n76 ;
  wire [47:0] \dec_ch1/n78 ;
  wire [47:0] \dec_ch1/n81 ;
  wire [47:0] \dec_ch1/n82 ;
  wire [47:0] \dec_ch1/n85 ;
  wire [47:0] \dec_ch1/n86 ;
  wire [7:0] \dec_ch1/pa ;  // zaklad.v(244)
  wire [7:0] \dec_ch1/pb ;  // zaklad.v(244)
  wire [7:0] \dec_ch1/pdn ;  // zaklad.v(263)
  wire [7:0] \dec_ch1/pdx ;  // zaklad.v(263)
  wire [7:0] \dec_ch1/pe ;  // zaklad.v(246)
  wire [15:0] \dec_ch1/pk0 ;  // zaklad.v(264)
  wire [15:0] \dec_ch1/pk1 ;  // zaklad.v(264)
  wire [15:0] \dec_ch1/pk2 ;  // zaklad.v(264)
  wire [15:0] \dec_ch1/pk3 ;  // zaklad.v(264)
  wire [15:0] \dec_ch1/pk4 ;  // zaklad.v(264)
  wire [15:0] \dec_ch1/pkw ;  // zaklad.v(264)
  wire [7:0] \dec_ch1/pl ;  // zaklad.v(246)
  wire [7:0] \dec_ch1/pmn ;  // zaklad.v(263)
  wire [7:0] \dec_ch1/pmx ;  // zaklad.v(263)
  wire [7:0] \dec_ch1/rmn ;  // zaklad.v(263)
  wire [7:0] \dec_ch1/rmx ;  // zaklad.v(263)
  wire [47:0] \dec_ch1/sh ;  // zaklad.v(250)
  wire [7:0] \dec_ch1/t_pe ;  // zaklad.v(273)
  wire [9:0] \dec_ch1/t_pl ;  // zaklad.v(272)
  wire [9:0] \dec_ch1/t_xe ;  // zaklad.v(271)
  wire [47:0] \dec_ch2/c1 ;  // zaklad.v(249)
  wire [47:0] \dec_ch2/c1p ;  // zaklad.v(249)
  wire [47:0] \dec_ch2/c2 ;  // zaklad.v(249)
  wire [47:0] \dec_ch2/c2p ;  // zaklad.v(249)
  wire [47:0] \dec_ch2/c3 ;  // zaklad.v(249)
  wire [47:0] \dec_ch2/d0 ;  // zaklad.v(249)
  wire [47:0] \dec_ch2/d0p ;  // zaklad.v(249)
  wire [10:0] \dec_ch2/f ;  // zaklad.v(247)
  wire [47:0] \dec_ch2/fine ;  // zaklad.v(275)
  wire [47:0] \dec_ch2/i1 ;  // zaklad.v(248)
  wire [47:0] \dec_ch2/i2 ;  // zaklad.v(248)
  wire [47:0] \dec_ch2/i3 ;  // zaklad.v(248)
  wire [7:0] \dec_ch2/n19 ;
  wire [7:0] \dec_ch2/n22 ;
  wire [47:0] \dec_ch2/n70 ;
  wire [47:0] \dec_ch2/n71 ;
  wire [47:0] \dec_ch2/n73 ;
  wire [47:0] \dec_ch2/n74 ;
  wire [47:0] \dec_ch2/n76 ;
  wire [47:0] \dec_ch2/n78 ;
  wire [47:0] \dec_ch2/n81 ;
  wire [47:0] \dec_ch2/n82 ;
  wire [47:0] \dec_ch2/n85 ;
  wire [47:0] \dec_ch2/n86 ;
  wire [7:0] \dec_ch2/pa ;  // zaklad.v(244)
  wire [7:0] \dec_ch2/pb ;  // zaklad.v(244)
  wire [7:0] \dec_ch2/pdn ;  // zaklad.v(263)
  wire [7:0] \dec_ch2/pdx ;  // zaklad.v(263)
  wire [7:0] \dec_ch2/pe ;  // zaklad.v(246)
  wire [15:0] \dec_ch2/pk0 ;  // zaklad.v(264)
  wire [15:0] \dec_ch2/pk1 ;  // zaklad.v(264)
  wire [15:0] \dec_ch2/pk2 ;  // zaklad.v(264)
  wire [15:0] \dec_ch2/pk3 ;  // zaklad.v(264)
  wire [15:0] \dec_ch2/pk4 ;  // zaklad.v(264)
  wire [15:0] \dec_ch2/pkw ;  // zaklad.v(264)
  wire [7:0] \dec_ch2/pl ;  // zaklad.v(246)
  wire [7:0] \dec_ch2/pmn ;  // zaklad.v(263)
  wire [7:0] \dec_ch2/pmx ;  // zaklad.v(263)
  wire [7:0] \dec_ch2/rmn ;  // zaklad.v(263)
  wire [7:0] \dec_ch2/rmx ;  // zaklad.v(263)
  wire [47:0] \dec_ch2/sh ;  // zaklad.v(250)
  wire [7:0] \dec_ch2/t_pe ;  // zaklad.v(273)
  wire [9:0] \dec_ch2/t_pl ;  // zaklad.v(272)
  wire [9:0] \dec_ch2/t_xe ;  // zaklad.v(271)
  wire [1:0] dec_order;  // zaklad.v(1031)
  wire [18:0] dec_pc;  // zaklad.v(1566)
  wire [5:0] dec_shift;  // zaklad.v(1033)
  wire [6:0] dec_sv;  // zaklad.v(1567)
  wire [15:0] dec_trig_sample;  // zaklad.v(1676)
  wire [15:0] \display_brightness/count ;  // zaklad.v(192)
  wire [15:0] \display_brightness/lt0/diff ;  // zaklad.v(202)
  wire [15:0] display_brigthness;  // zaklad.v(952)
  wire [3:0] enc_ok;  // zaklad.v(1507)
  wire [1:0] ext_hist;  // zaklad.v(1177)
  wire [1:0] ext_sync;  // zaklad.v(1176)
  wire [32:0] ho_cnt;  // zaklad.v(2095)
  wire [1:0] ho_ct_s;  // zaklad.v(2098)
  wire [7:0] hyst_hi;  // zaklad.v(1885)
  wire [8:0] hyst_hi9;  // zaklad.v(1881)
  wire [7:0] hyst_lo;  // zaklad.v(1884)
  wire [8:0] hyst_lo9;  // zaklad.v(1880)
  wire [7:0] io_mcu_data_pad;  // zaklad.v(880)
  wire [31:0] l_cnt;  // zaklad.v(1731)
  wire [13:0] l_occ;  // zaklad.v(1732)
  wire [2:0] l_rq;  // zaklad.v(1726)
  wire [12:0] l_wa;  // zaklad.v(1730)
  wire [2:0] lc_rq;  // zaklad.v(1726)
  wire [15:0] lg_hi;  // zaklad.v(1721)
  wire [15:0] lg_lo;  // zaklad.v(1721)
  wire [12:0] lg_wa;  // zaklad.v(1720)
  wire [12:0] log_rd;  // zaklad.v(1061)
  wire [7:0] mcu_command;  // zaklad.v(943)
  wire [3:0] mcu_state;  // zaklad.v(947)
  wire  \mux104_b10/B1_2 ;  // zaklad.v(3398)
  wire  \mux104_b11/B1_2 ;  // zaklad.v(3398)
  wire  \mux104_b12/B1_2 ;  // zaklad.v(3398)
  wire  \mux104_b13/B1_2 ;  // zaklad.v(3398)
  wire  \mux104_b14/B1_2 ;  // zaklad.v(3398)
  wire  \mux104_b15/B1_2 ;  // zaklad.v(3398)
  wire [8:0] n0;
  wire [10:0] n1;
  wire [19:0] n144;
  wire [19:0] n155;
  wire [12:0] n167;
  wire [12:0] n192;
  wire [13:0] n196;
  wire [8:0] n2;
  wire [31:0] n217;
  wire [7:0] n291;
  wire [7:0] n292;
  wire [7:0] n293;
  wire [10:0] n3;
  wire [7:0] n302;
  wire [7:0] n303;
  wire [7:0] n304;
  wire [7:0] n313;
  wire [7:0] n314;
  wire [7:0] n315;
  wire [7:0] n324;
  wire [7:0] n325;
  wire [7:0] n326;
  wire [12:0] n360;
  wire [32:0] n369;
  wire [12:0] n396;
  wire [31:0] n4;
  wire [12:0] n501;
  wire [7:0] n841;
  wire [7:0] n878;
  wire [7:0] o_adc1A_d;  // zaklad.v(935)
  wire [7:0] o_adc1B_d;  // zaklad.v(936)
  wire [7:0] o_adc2A_d;  // zaklad.v(937)
  wire [7:0] o_adc2B_d;  // zaklad.v(938)
  wire [7:0] o_mcu_data;  // zaklad.v(945)
  wire [15:0] oc_1A;  // zaklad.v(2036)
  wire [15:0] oc_1B;  // zaklad.v(2036)
  wire [15:0] oc_2A;  // zaklad.v(2036)
  wire [15:0] oc_2B;  // zaklad.v(2036)
  wire [1:0] oc_v;  // zaklad.v(2037)
  wire [13:0] occ;  // zaklad.v(1724)
  wire [12:0] p_wa;  // zaklad.v(1720)
  wire [7:0] pair_e1;  // zaklad.v(1586)
  wire [7:0] pair_e2;  // zaklad.v(1586)
  wire [7:0] pair_l1;  // zaklad.v(1586)
  wire [7:0] pair_l2;  // zaklad.v(1586)
  wire [7:0] pat_ctl;  // zaklad.v(976)
  wire [15:0] pat_wr_f;  // zaklad.v(974)
  wire [4:0] pat_wr_idx;  // zaklad.v(971)
  wire [31:0] pat_wr_n;  // zaklad.v(973)
  wire [0:0] \peripheral_clock/count ;  // zaklad.v(161)
  wire [12:0] post_words;  // zaklad.v(1844)
  wire [12:0] pretrigger_samples;  // zaklad.v(1023)
  wire [12:0] rd_200;  // zaklad.v(1727)
  wire [4:0] rd_hi;  // zaklad.v(1060)
  wire [2:0] rd_rq;  // zaklad.v(1726)
  wire [31:0] sample_dia;  // zaklad.v(1402)
  wire [19:0] sample_rate_counter;  // zaklad.v(990)
  wire [31:0] sample_rate_divider;  // zaklad.v(954)
  wire [19:0] sample_rate_divider_eff;  // zaklad.v(1545)
  wire [12:0] sample_read_addr_n;  // zaklad.v(931)
  wire [12:0] sample_read_offset;  // zaklad.v(1001)
  wire [3:0] sample_system_reset_count;  // zaklad.v(997)
  wire [12:0] sample_write_address;  // zaklad.v(999)
  wire  \sel32/B0 ;  // zaklad.v(2871)
  wire  \sel66_b0_var/B1_1 ;  // zaklad.v(3291)
  wire  \sel66_b6_var/B4_0 ;  // zaklad.v(3291)
  wire [1:0] str_q;  // zaklad.v(1065)
  wire [31:0] time_base_cnt;  // zaklad.v(958)
  wire [31:0] time_base_set;  // zaklad.v(957)
  wire [12:0] total_samples;  // zaklad.v(1024)
  wire [31:0] trig_holdoff;  // zaklad.v(960)
  wire [7:0] trig_hyst;  // zaklad.v(1012)
  wire [2:0] trig_type;  // zaklad.v(1040)
  wire [12:0] trigger_address;  // zaklad.v(1028)
  wire [7:0] trigger_data;  // zaklad.v(1016)
  wire [7:0] trigger_level;  // zaklad.v(1011)
  wire [15:0] trigger_level16;  // zaklad.v(1034)
  wire [7:0] trigger_previous;  // zaklad.v(1018)
  wire [12:0] trigger_read_address;  // zaklad.v(1026)
  wire [15:0] \u_sq/acc ;  // zaklad.v(669)
  wire [16:0] \u_sq/acc_sum ;  // zaklad.v(670)
  wire [32:0] \u_sq/cnt ;  // zaklad.v(668)
  wire [2:0] \u_sq/ct_s ;  // zaklad.v(664)
  wire [48:0] \u_sq/e0 ;  // zaklad.v(661)
  wire [15:0] \u_sq/e0f_n ;  // zaklad.v(687)
  wire [48:0] \u_sq/e1 ;  // zaklad.v(661)
  wire [15:0] \u_sq/e1f_n ;  // zaklad.v(688)
  wire [15:0] \u_sq/f_next ;  // zaklad.v(684)
  wire [15:0] \u_sq/f_nn ;  // zaklad.v(685)
  wire [2:0] \u_sq/go_d ;  // zaklad.v(672)
  wire [1:0] \u_sq/mode ;  // zaklad.v(665)
  wire [15:0] \u_sq/n18 ;
  wire [15:0] \u_sq/n20 ;
  wire [31:0] \u_sq/n51 ;
  wire [32:0] \u_sq/n52 ;
  wire [48:0] \u_sq/nx_e ;  // zaklad.v(663)
  wire [48:0] \u_sq/sh0 ;  // zaklad.v(662)
  wire [48:0] \u_sq/sh1 ;  // zaklad.v(662)
  wire [2:0] \u_sq/wr_s ;  // zaklad.v(664)
  wire _al_u1000_o;
  wire _al_u1001_o;
  wire _al_u1002_o;
  wire _al_u1235_o;
  wire _al_u1236_o;
  wire _al_u1238_o;
  wire _al_u1239_o;
  wire _al_u1241_o;
  wire _al_u1242_o;
  wire _al_u1244_o;
  wire _al_u1245_o;
  wire _al_u1247_o;
  wire _al_u1248_o;
  wire _al_u1250_o;
  wire _al_u1251_o;
  wire _al_u1253_o;
  wire _al_u1254_o;
  wire _al_u1256_o;
  wire _al_u1257_o;
  wire _al_u1259_o;
  wire _al_u1260_o;
  wire _al_u1262_o;
  wire _al_u1263_o;
  wire _al_u1265_o;
  wire _al_u1266_o;
  wire _al_u1268_o;
  wire _al_u1269_o;
  wire _al_u1271_o;
  wire _al_u1272_o;
  wire _al_u1274_o;
  wire _al_u1275_o;
  wire _al_u1277_o;
  wire _al_u1278_o;
  wire _al_u1280_o;
  wire _al_u1281_o;
  wire _al_u1283_o;
  wire _al_u1284_o;
  wire _al_u1286_o;
  wire _al_u1287_o;
  wire _al_u1289_o;
  wire _al_u1290_o;
  wire _al_u1292_o;
  wire _al_u1293_o;
  wire _al_u1295_o;
  wire _al_u1296_o;
  wire _al_u1298_o;
  wire _al_u1299_o;
  wire _al_u1301_o;
  wire _al_u1302_o;
  wire _al_u1304_o;
  wire _al_u1305_o;
  wire _al_u1307_o;
  wire _al_u1308_o;
  wire _al_u1310_o;
  wire _al_u1311_o;
  wire _al_u1313_o;
  wire _al_u1314_o;
  wire _al_u1316_o;
  wire _al_u1317_o;
  wire _al_u1319_o;
  wire _al_u1320_o;
  wire _al_u1322_o;
  wire _al_u1323_o;
  wire _al_u1325_o;
  wire _al_u1326_o;
  wire _al_u1328_o;
  wire _al_u1329_o;
  wire _al_u1365_o;
  wire _al_u1370_o;
  wire _al_u1391_o;
  wire _al_u1392_o;
  wire _al_u1394_o;
  wire _al_u1395_o;
  wire _al_u1396_o;
  wire _al_u1397_o;
  wire _al_u1399_o;
  wire _al_u1400_o;
  wire _al_u1401_o;
  wire _al_u1402_o;
  wire _al_u1404_o;
  wire _al_u1405_o;
  wire _al_u1406_o;
  wire _al_u1407_o;
  wire _al_u1413_o;
  wire _al_u1414_o;
  wire _al_u1415_o;
  wire _al_u1418_o;
  wire _al_u1419_o;
  wire _al_u1420_o;
  wire _al_u1421_o;
  wire _al_u1423_o;
  wire _al_u1426_o;
  wire _al_u1428_o;
  wire _al_u1433_o;
  wire _al_u1434_o;
  wire _al_u1436_o;
  wire _al_u1437_o;
  wire _al_u1439_o;
  wire _al_u1440_o;
  wire _al_u1441_o;
  wire _al_u1445_o;
  wire _al_u1451_o;
  wire _al_u1454_o;
  wire _al_u1457_o;
  wire _al_u1465_o;
  wire _al_u1466_o;
  wire _al_u1467_o;
  wire _al_u1469_o;
  wire _al_u1470_o;
  wire _al_u1528_o;
  wire _al_u1534_o;
  wire _al_u1540_o;
  wire _al_u1542_o;
  wire _al_u1543_o;
  wire _al_u1544_o;
  wire _al_u1546_o;
  wire _al_u1549_o;
  wire _al_u1551_o;
  wire _al_u1552_o;
  wire _al_u1555_o;
  wire _al_u1556_o;
  wire _al_u1558_o;
  wire _al_u1565_o;
  wire _al_u1576_o;
  wire _al_u1588_o;
  wire _al_u1596_o;
  wire _al_u1603_o;
  wire _al_u1605_o;
  wire _al_u1606_o;
  wire _al_u1608_o;
  wire _al_u1693_o;
  wire _al_u1694_o;
  wire _al_u1697_o;
  wire _al_u1699_o;
  wire _al_u1700_o;
  wire _al_u1701_o;
  wire _al_u1702_o;
  wire _al_u1703_o;
  wire _al_u1704_o;
  wire _al_u1706_o;
  wire _al_u1707_o;
  wire _al_u1708_o;
  wire _al_u1709_o;
  wire _al_u1710_o;
  wire _al_u1711_o;
  wire _al_u1712_o;
  wire _al_u1713_o;
  wire _al_u1715_o;
  wire _al_u1716_o;
  wire _al_u1717_o;
  wire _al_u1718_o;
  wire _al_u1719_o;
  wire _al_u1720_o;
  wire _al_u1723_o;
  wire _al_u1725_o;
  wire _al_u1726_o;
  wire _al_u1727_o;
  wire _al_u1728_o;
  wire _al_u1729_o;
  wire _al_u1730_o;
  wire _al_u1732_o;
  wire _al_u1733_o;
  wire _al_u1734_o;
  wire _al_u1735_o;
  wire _al_u1736_o;
  wire _al_u1738_o;
  wire _al_u1739_o;
  wire _al_u1741_o;
  wire _al_u1743_o;
  wire _al_u1744_o;
  wire _al_u1745_o;
  wire _al_u1746_o;
  wire _al_u1747_o;
  wire _al_u1748_o;
  wire _al_u1750_o;
  wire _al_u1751_o;
  wire _al_u1752_o;
  wire _al_u1753_o;
  wire _al_u1754_o;
  wire _al_u1759_o;
  wire _al_u1760_o;
  wire _al_u1761_o;
  wire _al_u1762_o;
  wire _al_u1763_o;
  wire _al_u1764_o;
  wire _al_u1765_o;
  wire _al_u1766_o;
  wire _al_u1767_o;
  wire _al_u1768_o;
  wire _al_u1771_o;
  wire _al_u1772_o;
  wire _al_u1773_o;
  wire _al_u1774_o;
  wire _al_u1775_o;
  wire _al_u1776_o;
  wire _al_u1778_o;
  wire _al_u1781_o;
  wire _al_u1783_o;
  wire _al_u1784_o;
  wire _al_u1787_o;
  wire _al_u1790_o;
  wire _al_u1791_o;
  wire _al_u1792_o;
  wire _al_u1796_o;
  wire _al_u1799_o;
  wire _al_u1800_o;
  wire _al_u1801_o;
  wire _al_u1804_o;
  wire _al_u1805_o;
  wire _al_u1806_o;
  wire _al_u1809_o;
  wire _al_u1810_o;
  wire _al_u1811_o;
  wire _al_u1814_o;
  wire _al_u1815_o;
  wire _al_u1816_o;
  wire _al_u1819_o;
  wire _al_u1820_o;
  wire _al_u1821_o;
  wire _al_u1825_o;
  wire _al_u1829_o;
  wire _al_u1831_o;
  wire _al_u1832_o;
  wire _al_u1834_o;
  wire _al_u1835_o;
  wire _al_u1836_o;
  wire _al_u1838_o;
  wire _al_u1839_o;
  wire _al_u1841_o;
  wire _al_u1842_o;
  wire _al_u1844_o;
  wire _al_u1845_o;
  wire _al_u1846_o;
  wire _al_u1848_o;
  wire _al_u1849_o;
  wire _al_u1850_o;
  wire _al_u1852_o;
  wire _al_u1853_o;
  wire _al_u1854_o;
  wire _al_u1856_o;
  wire _al_u1857_o;
  wire _al_u1858_o;
  wire _al_u1862_o;
  wire _al_u1865_o;
  wire _al_u1867_o;
  wire _al_u1869_o;
  wire _al_u1870_o;
  wire _al_u1873_o;
  wire _al_u1876_o;
  wire _al_u1877_o;
  wire _al_u1878_o;
  wire _al_u1879_o;
  wire _al_u1880_o;
  wire _al_u1881_o;
  wire _al_u1882_o;
  wire _al_u1883_o;
  wire _al_u1884_o;
  wire _al_u1885_o;
  wire _al_u1886_o;
  wire _al_u1887_o;
  wire _al_u1888_o;
  wire _al_u1889_o;
  wire _al_u1890_o;
  wire _al_u1894_o;
  wire _al_u1897_o;
  wire _al_u1898_o;
  wire _al_u1900_o;
  wire _al_u1902_o;
  wire _al_u1903_o;
  wire _al_u1905_o;
  wire _al_u1907_o;
  wire _al_u1908_o;
  wire _al_u1911_o;
  wire _al_u1912_o;
  wire _al_u1915_o;
  wire _al_u1916_o;
  wire _al_u1918_o;
  wire _al_u1920_o;
  wire _al_u1923_o;
  wire _al_u1925_o;
  wire _al_u1926_o;
  wire _al_u1928_o;
  wire _al_u1929_o;
  wire _al_u1931_o;
  wire _al_u1933_o;
  wire _al_u1935_o;
  wire _al_u1937_o;
  wire _al_u1939_o;
  wire _al_u1942_o;
  wire _al_u1945_o;
  wire _al_u1946_o;
  wire _al_u1947_o;
  wire _al_u1948_o;
  wire _al_u1949_o;
  wire _al_u1950_o;
  wire _al_u1951_o;
  wire _al_u1952_o;
  wire _al_u1953_o;
  wire _al_u1954_o;
  wire _al_u1955_o;
  wire _al_u1956_o;
  wire _al_u1957_o;
  wire _al_u1958_o;
  wire _al_u1959_o;
  wire _al_u1960_o;
  wire _al_u1962_o;
  wire _al_u1963_o;
  wire _al_u1964_o;
  wire _al_u1965_o;
  wire _al_u1966_o;
  wire _al_u1967_o;
  wire _al_u1968_o;
  wire _al_u1969_o;
  wire _al_u1970_o;
  wire _al_u1972_o;
  wire _al_u1973_o;
  wire _al_u1975_o;
  wire _al_u1991_o;
  wire _al_u2007_o;
  wire _al_u2008_o;
  wire _al_u2009_o;
  wire _al_u2010_o;
  wire _al_u2011_o;
  wire _al_u2012_o;
  wire _al_u2013_o;
  wire _al_u2014_o;
  wire _al_u2015_o;
  wire _al_u2016_o;
  wire _al_u2017_o;
  wire _al_u2018_o;
  wire _al_u2019_o;
  wire _al_u2020_o;
  wire _al_u2021_o;
  wire _al_u2022_o;
  wire _al_u2023_o;
  wire _al_u2024_o;
  wire _al_u2025_o;
  wire _al_u2026_o;
  wire _al_u2027_o;
  wire _al_u2029_o;
  wire _al_u2030_o;
  wire _al_u2031_o;
  wire _al_u2033_o;
  wire _al_u2034_o;
  wire _al_u2035_o;
  wire _al_u2036_o;
  wire _al_u2037_o;
  wire _al_u2039_o;
  wire _al_u2040_o;
  wire _al_u2041_o;
  wire _al_u2042_o;
  wire _al_u2043_o;
  wire _al_u2044_o;
  wire _al_u2045_o;
  wire _al_u2046_o;
  wire _al_u2047_o;
  wire _al_u2048_o;
  wire _al_u2049_o;
  wire _al_u2050_o;
  wire _al_u2051_o;
  wire _al_u2052_o;
  wire _al_u2053_o;
  wire _al_u2054_o;
  wire _al_u2055_o;
  wire _al_u2057_o;
  wire _al_u2058_o;
  wire _al_u2059_o;
  wire _al_u2060_o;
  wire _al_u2062_o;
  wire _al_u2063_o;
  wire _al_u2064_o;
  wire _al_u2065_o;
  wire _al_u2066_o;
  wire _al_u2068_o;
  wire _al_u2069_o;
  wire _al_u2070_o;
  wire _al_u2071_o;
  wire _al_u2072_o;
  wire _al_u2073_o;
  wire _al_u2074_o;
  wire _al_u2075_o;
  wire _al_u2076_o;
  wire _al_u2077_o;
  wire _al_u2078_o;
  wire _al_u2079_o;
  wire _al_u2080_o;
  wire _al_u2082_o;
  wire _al_u2083_o;
  wire _al_u2085_o;
  wire _al_u2086_o;
  wire _al_u2087_o;
  wire _al_u2088_o;
  wire _al_u2089_o;
  wire _al_u2090_o;
  wire _al_u2091_o;
  wire _al_u2092_o;
  wire _al_u2093_o;
  wire _al_u2094_o;
  wire _al_u2095_o;
  wire _al_u2096_o;
  wire _al_u2097_o;
  wire _al_u2098_o;
  wire _al_u2099_o;
  wire _al_u2100_o;
  wire _al_u2101_o;
  wire _al_u2102_o;
  wire _al_u2103_o;
  wire _al_u2106_o;
  wire _al_u2107_o;
  wire _al_u2109_o;
  wire _al_u2110_o;
  wire _al_u2111_o;
  wire _al_u2112_o;
  wire _al_u2113_o;
  wire _al_u2114_o;
  wire _al_u2115_o;
  wire _al_u2116_o;
  wire _al_u2117_o;
  wire _al_u2118_o;
  wire _al_u2119_o;
  wire _al_u2120_o;
  wire _al_u2121_o;
  wire _al_u2122_o;
  wire _al_u2124_o;
  wire _al_u2125_o;
  wire _al_u2127_o;
  wire _al_u2128_o;
  wire _al_u2129_o;
  wire _al_u2130_o;
  wire _al_u2131_o;
  wire _al_u2132_o;
  wire _al_u2133_o;
  wire _al_u2134_o;
  wire _al_u2135_o;
  wire _al_u2136_o;
  wire _al_u2137_o;
  wire _al_u2138_o;
  wire _al_u2139_o;
  wire _al_u2140_o;
  wire _al_u2141_o;
  wire _al_u2142_o;
  wire _al_u2143_o;
  wire _al_u2144_o;
  wire _al_u2145_o;
  wire _al_u2146_o;
  wire _al_u2147_o;
  wire _al_u2148_o;
  wire _al_u2151_o;
  wire _al_u2152_o;
  wire _al_u2153_o;
  wire _al_u2155_o;
  wire _al_u2156_o;
  wire _al_u2157_o;
  wire _al_u2158_o;
  wire _al_u2159_o;
  wire _al_u2160_o;
  wire _al_u2161_o;
  wire _al_u2162_o;
  wire _al_u2163_o;
  wire _al_u2164_o;
  wire _al_u2165_o;
  wire _al_u2166_o;
  wire _al_u2167_o;
  wire _al_u2168_o;
  wire _al_u2170_o;
  wire _al_u2171_o;
  wire _al_u2172_o;
  wire _al_u2173_o;
  wire _al_u2174_o;
  wire _al_u2175_o;
  wire _al_u2176_o;
  wire _al_u2177_o;
  wire _al_u2178_o;
  wire _al_u2179_o;
  wire _al_u2180_o;
  wire _al_u2182_o;
  wire _al_u2183_o;
  wire _al_u2184_o;
  wire _al_u2185_o;
  wire _al_u2186_o;
  wire _al_u2187_o;
  wire _al_u2188_o;
  wire _al_u2189_o;
  wire _al_u2190_o;
  wire _al_u2191_o;
  wire _al_u2194_o;
  wire _al_u2197_o;
  wire _al_u2203_o;
  wire _al_u2205_o;
  wire _al_u2206_o;
  wire _al_u2207_o;
  wire _al_u2208_o;
  wire _al_u2209_o;
  wire _al_u2210_o;
  wire _al_u2211_o;
  wire _al_u2212_o;
  wire _al_u2213_o;
  wire _al_u2214_o;
  wire _al_u2215_o;
  wire _al_u397_o;
  wire _al_u398_o;
  wire _al_u399_o;
  wire _al_u400_o;
  wire _al_u401_o;
  wire _al_u402_o;
  wire _al_u403_o;
  wire _al_u404_o;
  wire _al_u405_o;
  wire _al_u671_o;
  wire _al_u687_o;
  wire _al_u689_o;
  wire _al_u691_o;
  wire _al_u693_o;
  wire _al_u695_o;
  wire _al_u697_o;
  wire _al_u699_o;
  wire _al_u701_o;
  wire _al_u745_o;
  wire _al_u806_o;
  wire _al_u879_o;
  wire _al_u881_o;
  wire _al_u883_o;
  wire _al_u885_o;
  wire _al_u887_o;
  wire _al_u889_o;
  wire _al_u891_o;
  wire _al_u893_o;
  wire _al_u967_o;
  wire _al_u969_o;
  wire _al_u971_o;
  wire _al_u973_o;
  wire _al_u975_o;
  wire _al_u977_o;
  wire _al_u979_o;
  wire _al_u981_o;
  wire adc1_encA;  // zaklad.v(1105)
  wire adc1_encB;  // zaklad.v(1107)
  wire \add0/c11 ;  // zaklad.v(1532)
  wire \add0/c15 ;  // zaklad.v(1532)
  wire \add0/c19 ;  // zaklad.v(1532)
  wire \add0/c3 ;  // zaklad.v(1532)
  wire \add0/c7 ;  // zaklad.v(1532)
  wire \add10/c1 ;  // zaklad.v(2056)
  wire \add10/c11 ;  // zaklad.v(2056)
  wire \add10/c13 ;  // zaklad.v(2056)
  wire \add10/c15 ;  // zaklad.v(2056)
  wire \add10/c3 ;  // zaklad.v(2056)
  wire \add10/c5 ;  // zaklad.v(2056)
  wire \add10/c7 ;  // zaklad.v(2056)
  wire \add10/c9 ;  // zaklad.v(2056)
  wire \add11/c1 ;  // zaklad.v(2057)
  wire \add11/c11 ;  // zaklad.v(2057)
  wire \add11/c13 ;  // zaklad.v(2057)
  wire \add11/c15 ;  // zaklad.v(2057)
  wire \add11/c3 ;  // zaklad.v(2057)
  wire \add11/c5 ;  // zaklad.v(2057)
  wire \add11/c7 ;  // zaklad.v(2057)
  wire \add11/c9 ;  // zaklad.v(2057)
  wire \add12/c1 ;  // zaklad.v(2082)
  wire \add12/c11 ;  // zaklad.v(2082)
  wire \add12/c3 ;  // zaklad.v(2082)
  wire \add12/c5 ;  // zaklad.v(2082)
  wire \add12/c7 ;  // zaklad.v(2082)
  wire \add12/c9 ;  // zaklad.v(2082)
  wire \add15/c1 ;  // zaklad.v(2849)
  wire \add15/c11 ;  // zaklad.v(2849)
  wire \add15/c3 ;  // zaklad.v(2849)
  wire \add15/c5 ;  // zaklad.v(2849)
  wire \add15/c7 ;  // zaklad.v(2849)
  wire \add15/c9 ;  // zaklad.v(2849)
  wire \add2/c1 ;  // zaklad.v(1689)
  wire \add2/c11 ;  // zaklad.v(1689)
  wire \add2/c3 ;  // zaklad.v(1689)
  wire \add2/c5 ;  // zaklad.v(1689)
  wire \add2/c7 ;  // zaklad.v(1689)
  wire \add2/c9 ;  // zaklad.v(1689)
  wire \add3/c1 ;  // zaklad.v(1773)
  wire \add3/c11 ;  // zaklad.v(1773)
  wire \add3/c13 ;  // zaklad.v(1773)
  wire \add3/c15 ;  // zaklad.v(1773)
  wire \add3/c3 ;  // zaklad.v(1773)
  wire \add3/c5 ;  // zaklad.v(1773)
  wire \add3/c7 ;  // zaklad.v(1773)
  wire \add3/c9 ;  // zaklad.v(1773)
  wire \add4/c1 ;  // zaklad.v(1775)
  wire \add4/c11 ;  // zaklad.v(1775)
  wire \add4/c13 ;  // zaklad.v(1775)
  wire \add4/c15 ;  // zaklad.v(1775)
  wire \add4/c3 ;  // zaklad.v(1775)
  wire \add4/c5 ;  // zaklad.v(1775)
  wire \add4/c7 ;  // zaklad.v(1775)
  wire \add4/c9 ;  // zaklad.v(1775)
  wire \add5/c1 ;  // zaklad.v(1780)
  wire \add5/c11 ;  // zaklad.v(1780)
  wire \add5/c13 ;  // zaklad.v(1780)
  wire \add5/c3 ;  // zaklad.v(1780)
  wire \add5/c5 ;  // zaklad.v(1780)
  wire \add5/c7 ;  // zaklad.v(1780)
  wire \add5/c9 ;  // zaklad.v(1780)
  wire \add6/c11 ;  // zaklad.v(1810)
  wire \add6/c15 ;  // zaklad.v(1810)
  wire \add6/c19 ;  // zaklad.v(1810)
  wire \add6/c23 ;  // zaklad.v(1810)
  wire \add6/c27 ;  // zaklad.v(1810)
  wire \add6/c3 ;  // zaklad.v(1810)
  wire \add6/c31 ;  // zaklad.v(1810)
  wire \add6/c7 ;  // zaklad.v(1810)
  wire \add7/c1 ;  // zaklad.v(1881)
  wire \add7/c3 ;  // zaklad.v(1881)
  wire \add7/c5 ;  // zaklad.v(1881)
  wire \add7/c7 ;  // zaklad.v(1881)
  wire \add8/c1 ;  // zaklad.v(2054)
  wire \add8/c11 ;  // zaklad.v(2054)
  wire \add8/c13 ;  // zaklad.v(2054)
  wire \add8/c15 ;  // zaklad.v(2054)
  wire \add8/c3 ;  // zaklad.v(2054)
  wire \add8/c5 ;  // zaklad.v(2054)
  wire \add8/c7 ;  // zaklad.v(2054)
  wire \add8/c9 ;  // zaklad.v(2054)
  wire \add9/c1 ;  // zaklad.v(2055)
  wire \add9/c11 ;  // zaklad.v(2055)
  wire \add9/c13 ;  // zaklad.v(2055)
  wire \add9/c15 ;  // zaklad.v(2055)
  wire \add9/c3 ;  // zaklad.v(2055)
  wire \add9/c5 ;  // zaklad.v(2055)
  wire \add9/c7 ;  // zaklad.v(2055)
  wire \add9/c9 ;  // zaklad.v(2055)
  wire adv_d;  // zaklad.v(2177)
  wire cap_full;  // zaklad.v(1185)
  wire \channel1_dc_offset/add0/c1 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c11 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c13 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c15 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c3 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c5 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c7 ;  // zaklad.v(200)
  wire \channel1_dc_offset/add0/c9 ;  // zaklad.v(200)
  wire \channel1_dc_offset/lt0/less_6_11_inst/o_3_lutinv ;  // zaklad.v(202)
  wire \channel1_dc_offset/lt0/o_3_lutinv ;  // zaklad.v(202)
  wire \channel1_dc_offset/n0 ;
  wire \channel2_dc_offset/lt0/less_6_11_inst/o_3_lutinv ;  // zaklad.v(202)
  wire \channel2_dc_offset/lt0/less_6_11_inst/o_4_lutinv ;  // zaklad.v(202)
  wire \channel2_dc_offset/lt0/o_3_lutinv ;  // zaklad.v(202)
  wire clk_200MHz /* synthesis keep=1 */ ;  // zaklad.v(909)
  wire clk_50MHz;  // zaklad.v(914)
  wire clk_50MHz_gclk_net;
  wire clk_ADCA;  // zaklad.v(912)
  wire clk_ADCB;  // zaklad.v(911)
  wire \dec_ch1/add0/c1 ;  // zaklad.v(271)
  wire \dec_ch1/add0/c3 ;  // zaklad.v(271)
  wire \dec_ch1/add0/c5 ;  // zaklad.v(271)
  wire \dec_ch1/add0/c7 ;  // zaklad.v(271)
  wire \dec_ch1/add1/c1 ;  // zaklad.v(272)
  wire \dec_ch1/add1/c3 ;  // zaklad.v(272)
  wire \dec_ch1/add1/c5 ;  // zaklad.v(272)
  wire \dec_ch1/add1/c7 ;  // zaklad.v(272)
  wire \dec_ch1/add5/c11 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c15 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c19 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c23 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c27 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c3 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c31 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c35 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c39 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c43 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c47 ;  // zaklad.v(308)
  wire \dec_ch1/add5/c7 ;  // zaklad.v(308)
  wire \dec_ch1/add6/c11 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c15 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c19 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c23 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c27 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c3 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c31 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c35 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c39 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c43 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c47 ;  // zaklad.v(309)
  wire \dec_ch1/add6/c7 ;  // zaklad.v(309)
  wire \dec_ch1/add7/c11 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c15 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c19 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c23 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c27 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c3 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c31 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c35 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c39 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c43 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c47 ;  // zaklad.v(310)
  wire \dec_ch1/add7/c7 ;  // zaklad.v(310)
  wire \dec_ch1/k3_lutinv ;  // zaklad.v(267)
  wire \dec_ch1/lt0/c1 ;  // zaklad.v(287)
  wire \dec_ch1/lt0/c3 ;  // zaklad.v(287)
  wire \dec_ch1/lt0/c5 ;  // zaklad.v(287)
  wire \dec_ch1/lt0/c7 ;  // zaklad.v(287)
  wire \dec_ch1/lt1/c1 ;  // zaklad.v(288)
  wire \dec_ch1/lt1/c3 ;  // zaklad.v(288)
  wire \dec_ch1/lt1/c5 ;  // zaklad.v(288)
  wire \dec_ch1/lt1/c7 ;  // zaklad.v(288)
  wire \dec_ch1/lt2/c1 ;  // zaklad.v(299)
  wire \dec_ch1/lt2/c3 ;  // zaklad.v(299)
  wire \dec_ch1/lt2/c5 ;  // zaklad.v(299)
  wire \dec_ch1/lt2/c7 ;  // zaklad.v(299)
  wire \dec_ch1/lt3/c1 ;  // zaklad.v(300)
  wire \dec_ch1/lt3/c3 ;  // zaklad.v(300)
  wire \dec_ch1/lt3/c5 ;  // zaklad.v(300)
  wire \dec_ch1/lt3/c7 ;  // zaklad.v(300)
  wire \dec_ch1/mux10_b0_sel_is_0_o ;
  wire \dec_ch1/mux11_b0_sel_is_0_o ;
  wire \dec_ch1/n112_lutinv ;
  wire \dec_ch1/n113_lutinv ;
  wire \dec_ch1/n114_lutinv ;
  wire \dec_ch1/n115_lutinv ;
  wire \dec_ch1/n116_lutinv ;
  wire \dec_ch1/n117_lutinv ;
  wire \dec_ch1/n118_lutinv ;
  wire \dec_ch1/n119_lutinv ;
  wire \dec_ch1/n11_lutinv ;
  wire \dec_ch1/n120_lutinv ;
  wire \dec_ch1/n121_lutinv ;
  wire \dec_ch1/n122_lutinv ;
  wire \dec_ch1/n123_lutinv ;
  wire \dec_ch1/n124_lutinv ;
  wire \dec_ch1/n125_lutinv ;
  wire \dec_ch1/n126_lutinv ;
  wire \dec_ch1/n12_lutinv ;
  wire \dec_ch1/n136_lutinv ;
  wire \dec_ch1/n137_lutinv ;
  wire \dec_ch1/n138_lutinv ;
  wire \dec_ch1/n139_lutinv ;
  wire \dec_ch1/n13_lutinv ;
  wire \dec_ch1/n140_lutinv ;
  wire \dec_ch1/n141_lutinv ;
  wire \dec_ch1/n142_lutinv ;
  wire \dec_ch1/n143_lutinv ;
  wire \dec_ch1/n144_lutinv ;
  wire \dec_ch1/n14_lutinv ;
  wire \dec_ch1/n15_lutinv ;
  wire \dec_ch1/n16_lutinv ;
  wire \dec_ch1/n17_lutinv ;
  wire \dec_ch1/n18 ;
  wire \dec_ch1/n21 ;
  wire \dec_ch1/n226_lutinv ;
  wire \dec_ch1/n227_lutinv ;
  wire \dec_ch1/n228_lutinv ;
  wire \dec_ch1/n229_lutinv ;
  wire \dec_ch1/n230_lutinv ;
  wire \dec_ch1/n231_lutinv ;
  wire \dec_ch1/n232_lutinv ;
  wire \dec_ch1/n233_lutinv ;
  wire \dec_ch1/n234_lutinv ;
  wire \dec_ch1/n235_lutinv ;
  wire \dec_ch1/n236_lutinv ;
  wire \dec_ch1/n237_lutinv ;
  wire \dec_ch1/n238_lutinv ;
  wire \dec_ch1/n239_lutinv ;
  wire \dec_ch1/n240_lutinv ;
  wire \dec_ch1/n241_lutinv ;
  wire \dec_ch1/n242_lutinv ;
  wire \dec_ch1/n243_lutinv ;
  wire \dec_ch1/n244_lutinv ;
  wire \dec_ch1/n245_lutinv ;
  wire \dec_ch1/n53 ;
  wire \dec_ch1/n55 ;
  wire \dec_ch1/n57 ;
  wire \dec_ch1/n59 ;
  wire \dec_ch1/n95_lutinv ;
  wire \dec_ch1/sub0/c11 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c15 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c19 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c23 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c27 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c3 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c31 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c35 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c39 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c43 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c47 ;  // zaklad.v(317)
  wire \dec_ch1/sub0/c7 ;  // zaklad.v(317)
  wire \dec_ch1/sub1/c11 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c15 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c19 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c23 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c27 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c3 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c31 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c35 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c39 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c43 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c47 ;  // zaklad.v(323)
  wire \dec_ch1/sub1/c7 ;  // zaklad.v(323)
  wire \dec_ch1/sub2/c11 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c15 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c19 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c23 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c27 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c3 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c31 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c35 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c39 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c43 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c47 ;  // zaklad.v(329)
  wire \dec_ch1/sub2/c7 ;  // zaklad.v(329)
  wire \dec_ch2/add0/c1 ;  // zaklad.v(271)
  wire \dec_ch2/add0/c3 ;  // zaklad.v(271)
  wire \dec_ch2/add0/c5 ;  // zaklad.v(271)
  wire \dec_ch2/add0/c7 ;  // zaklad.v(271)
  wire \dec_ch2/add1/c1 ;  // zaklad.v(272)
  wire \dec_ch2/add1/c3 ;  // zaklad.v(272)
  wire \dec_ch2/add1/c5 ;  // zaklad.v(272)
  wire \dec_ch2/add1/c7 ;  // zaklad.v(272)
  wire \dec_ch2/add5/c11 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c15 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c19 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c23 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c27 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c3 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c31 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c35 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c39 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c43 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c47 ;  // zaklad.v(308)
  wire \dec_ch2/add5/c7 ;  // zaklad.v(308)
  wire \dec_ch2/add6/c11 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c15 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c19 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c23 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c27 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c3 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c31 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c35 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c39 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c43 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c47 ;  // zaklad.v(309)
  wire \dec_ch2/add6/c7 ;  // zaklad.v(309)
  wire \dec_ch2/add7/c11 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c15 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c19 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c23 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c27 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c3 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c31 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c35 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c39 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c43 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c47 ;  // zaklad.v(310)
  wire \dec_ch2/add7/c7 ;  // zaklad.v(310)
  wire \dec_ch2/lt0/c1 ;  // zaklad.v(287)
  wire \dec_ch2/lt0/c3 ;  // zaklad.v(287)
  wire \dec_ch2/lt0/c5 ;  // zaklad.v(287)
  wire \dec_ch2/lt0/c7 ;  // zaklad.v(287)
  wire \dec_ch2/lt1/c1 ;  // zaklad.v(288)
  wire \dec_ch2/lt1/c3 ;  // zaklad.v(288)
  wire \dec_ch2/lt1/c5 ;  // zaklad.v(288)
  wire \dec_ch2/lt1/c7 ;  // zaklad.v(288)
  wire \dec_ch2/lt2/c1 ;  // zaklad.v(299)
  wire \dec_ch2/lt2/c3 ;  // zaklad.v(299)
  wire \dec_ch2/lt2/c5 ;  // zaklad.v(299)
  wire \dec_ch2/lt2/c7 ;  // zaklad.v(299)
  wire \dec_ch2/lt3/c1 ;  // zaklad.v(300)
  wire \dec_ch2/lt3/c3 ;  // zaklad.v(300)
  wire \dec_ch2/lt3/c5 ;  // zaklad.v(300)
  wire \dec_ch2/lt3/c7 ;  // zaklad.v(300)
  wire \dec_ch2/mux10_b0_sel_is_0_o ;
  wire \dec_ch2/mux11_b0_sel_is_0_o ;
  wire \dec_ch2/n112_lutinv ;
  wire \dec_ch2/n113_lutinv ;
  wire \dec_ch2/n114_lutinv ;
  wire \dec_ch2/n115_lutinv ;
  wire \dec_ch2/n116_lutinv ;
  wire \dec_ch2/n117_lutinv ;
  wire \dec_ch2/n118_lutinv ;
  wire \dec_ch2/n119_lutinv ;
  wire \dec_ch2/n11_lutinv ;
  wire \dec_ch2/n120_lutinv ;
  wire \dec_ch2/n121_lutinv ;
  wire \dec_ch2/n122_lutinv ;
  wire \dec_ch2/n123_lutinv ;
  wire \dec_ch2/n124_lutinv ;
  wire \dec_ch2/n125_lutinv ;
  wire \dec_ch2/n126_lutinv ;
  wire \dec_ch2/n12_lutinv ;
  wire \dec_ch2/n136_lutinv ;
  wire \dec_ch2/n137_lutinv ;
  wire \dec_ch2/n138_lutinv ;
  wire \dec_ch2/n139_lutinv ;
  wire \dec_ch2/n13_lutinv ;
  wire \dec_ch2/n140_lutinv ;
  wire \dec_ch2/n141_lutinv ;
  wire \dec_ch2/n142_lutinv ;
  wire \dec_ch2/n143_lutinv ;
  wire \dec_ch2/n144_lutinv ;
  wire \dec_ch2/n14_lutinv ;
  wire \dec_ch2/n15_lutinv ;
  wire \dec_ch2/n16_lutinv ;
  wire \dec_ch2/n17_lutinv ;
  wire \dec_ch2/n18 ;
  wire \dec_ch2/n21 ;
  wire \dec_ch2/n226_lutinv ;
  wire \dec_ch2/n227_lutinv ;
  wire \dec_ch2/n228_lutinv ;
  wire \dec_ch2/n229_lutinv ;
  wire \dec_ch2/n230_lutinv ;
  wire \dec_ch2/n231_lutinv ;
  wire \dec_ch2/n232_lutinv ;
  wire \dec_ch2/n233_lutinv ;
  wire \dec_ch2/n234_lutinv ;
  wire \dec_ch2/n235_lutinv ;
  wire \dec_ch2/n236_lutinv ;
  wire \dec_ch2/n237_lutinv ;
  wire \dec_ch2/n238_lutinv ;
  wire \dec_ch2/n239_lutinv ;
  wire \dec_ch2/n240_lutinv ;
  wire \dec_ch2/n241_lutinv ;
  wire \dec_ch2/n242_lutinv ;
  wire \dec_ch2/n243_lutinv ;
  wire \dec_ch2/n244_lutinv ;
  wire \dec_ch2/n245_lutinv ;
  wire \dec_ch2/n53 ;
  wire \dec_ch2/n55 ;
  wire \dec_ch2/n57 ;
  wire \dec_ch2/n59 ;
  wire \dec_ch2/n95_lutinv ;
  wire \dec_ch2/sub0/c11 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c15 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c19 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c23 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c27 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c3 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c31 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c35 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c39 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c43 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c47 ;  // zaklad.v(317)
  wire \dec_ch2/sub0/c7 ;  // zaklad.v(317)
  wire \dec_ch2/sub1/c11 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c15 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c19 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c23 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c27 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c3 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c31 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c35 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c39 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c43 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c47 ;  // zaklad.v(323)
  wire \dec_ch2/sub1/c7 ;  // zaklad.v(323)
  wire \dec_ch2/sub2/c11 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c15 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c19 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c23 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c27 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c3 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c31 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c35 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c39 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c43 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c47 ;  // zaklad.v(329)
  wire \dec_ch2/sub2/c7 ;  // zaklad.v(329)
  wire \dec_order[1]_hfnopt2_0 ;  // zaklad.v(1031)
  wire \dec_order[1]_hfnopt2_1 ;  // zaklad.v(1031)
  wire \dec_order[1]_hfnopt2_2 ;  // zaklad.v(1031)
  wire \dec_order[1]_hfnopt2_3 ;  // zaklad.v(1031)
  wire \dec_order[1]_hfnopt2_4 ;  // zaklad.v(1031)
  wire \dec_shift[3]_hfnopt2_0 ;  // zaklad.v(1033)
  wire \dec_shift[3]_hfnopt2_1 ;  // zaklad.v(1033)
  wire \dec_shift[3]_hfnopt2_2 ;  // zaklad.v(1033)
  wire \dec_shift[3]_hfnopt2_3 ;  // zaklad.v(1033)
  wire \dec_sv[0]_hfnopt2_0 ;  // zaklad.v(1567)
  wire \dec_sv[0]_hfnopt2_1 ;  // zaklad.v(1567)
  wire \dec_sv[0]_hfnopt2_2 ;  // zaklad.v(1567)
  wire \dec_sv[0]_hfnopt2_3 ;  // zaklad.v(1567)
  wire \dec_sv[0]_hfnopt2_4 ;  // zaklad.v(1567)
  wire \dec_sv[1]_hfnopt2_0 ;  // zaklad.v(1567)
  wire \dec_sv[1]_hfnopt2_1 ;  // zaklad.v(1567)
  wire \dec_sv[1]_hfnopt2_2 ;  // zaklad.v(1567)
  wire \dec_sv[1]_hfnopt2_3 ;  // zaklad.v(1567)
  wire \dec_sv[1]_hfnopt2_4 ;  // zaklad.v(1567)
  wire \dec_sv[2]_hfnopt2_0 ;  // zaklad.v(1567)
  wire \dec_sv[2]_hfnopt2_1 ;  // zaklad.v(1567)
  wire \dec_sv[2]_hfnopt2_2 ;  // zaklad.v(1567)
  wire \dec_sv[2]_hfnopt2_3 ;  // zaklad.v(1567)
  wire \dec_sv[2]_hfnopt2_4 ;  // zaklad.v(1567)
  wire \dec_sv[3]_hfnopt2_0 ;  // zaklad.v(1567)
  wire \dec_sv[3]_hfnopt2_1 ;  // zaklad.v(1567)
  wire \dec_sv[3]_hfnopt2_2 ;  // zaklad.v(1567)
  wire \dec_sv[3]_hfnopt2_3 ;  // zaklad.v(1567)
  wire \dec_sv[3]_hfnopt2_4 ;  // zaklad.v(1567)
  wire \dec_sv[3]_hfnopt2_5 ;  // zaklad.v(1567)
  wire \dec_sv[4]_hfnopt2_0 ;  // zaklad.v(1567)
  wire \dec_sv[4]_hfnopt2_1 ;  // zaklad.v(1567)
  wire \dec_sv[4]_hfnopt2_2 ;  // zaklad.v(1567)
  wire dec_trig_ge;  // zaklad.v(1677)
  wire \display_brightness/add0/c1 ;  // zaklad.v(200)
  wire \display_brightness/add0/c11 ;  // zaklad.v(200)
  wire \display_brightness/add0/c13 ;  // zaklad.v(200)
  wire \display_brightness/add0/c15 ;  // zaklad.v(200)
  wire \display_brightness/add0/c3 ;  // zaklad.v(200)
  wire \display_brightness/add0/c5 ;  // zaklad.v(200)
  wire \display_brightness/add0/c7 ;  // zaklad.v(200)
  wire \display_brightness/add0/c9 ;  // zaklad.v(200)
  wire \display_brightness/lt0/less_6_11_inst/o_3_lutinv ;  // zaklad.v(202)
  wire \display_brightness/lt0/o_3_lutinv ;  // zaklad.v(202)
  wire \display_brightness/n0 ;
  wire enc_cur;  // zaklad.v(1458)
  wire enc_cur_n;  // zaklad.v(1459)
  wire enc_err;  // zaklad.v(1509)
  wire enc_nxt;  // zaklad.v(1442)
  wire enc_nxt_n;  // zaklad.v(1443)
  wire enc_pred_ok;  // zaklad.v(1508)
  wire ext_activity;  // zaklad.v(1180)
  wire ext_level;  // zaklad.v(1178)
  wire ext_level_prev;  // zaklad.v(1179)
  wire ext_pending;  // zaklad.v(1181)
  wire fir_en;  // zaklad.v(1036)
  wire gen_out_enable;  // zaklad.v(968)
  wire ho_clr_req;  // zaklad.v(1053)
  wire ho_clr_t;  // zaklad.v(1054)
  wire ho_ct_d;  // zaklad.v(2099)
  wire ho_en;  // zaklad.v(2097)
  wire ho_run;  // zaklad.v(2096)
  wire ho_st_q;  // zaklad.v(2094)
  wire hyst_above;  // zaklad.v(1887)
  wire hyst_below;  // zaklad.v(1886)
  wire i_mcu_clk_pad;  // zaklad.v(871)
  wire i_mcu_clk_pad_gclk_net;
  wire i_mcu_dcs_pad;  // zaklad.v(873)
  wire i_mcu_rws_pad;  // zaklad.v(872)
  wire i_xtal_pad;  // zaklad.v(870)
  wire \io_mcu_data_pad[3]_neg ;
  wire l_cp;  // zaklad.v(1733)
  wire l_lap;  // zaklad.v(1729)
  wire l_req;  // zaklad.v(1064)
  wire l_str;  // zaklad.v(1729)
  wire lap;  // zaklad.v(1725)
  wire lc_t;  // zaklad.v(1059)
  wire lo_ones;  // zaklad.v(1722)
  wire \lt0/c1 ;  // zaklad.v(1547)
  wire \lt0/c11 ;  // zaklad.v(1547)
  wire \lt0/c13 ;  // zaklad.v(1547)
  wire \lt0/c15 ;  // zaklad.v(1547)
  wire \lt0/c17 ;  // zaklad.v(1547)
  wire \lt0/c19 ;  // zaklad.v(1547)
  wire \lt0/c3 ;  // zaklad.v(1547)
  wire \lt0/c5 ;  // zaklad.v(1547)
  wire \lt0/c7 ;  // zaklad.v(1547)
  wire \lt0/c9 ;  // zaklad.v(1547)
  wire \lt1/c1 ;  // zaklad.v(1552)
  wire \lt1/c11 ;  // zaklad.v(1552)
  wire \lt1/c13 ;  // zaklad.v(1552)
  wire \lt1/c15 ;  // zaklad.v(1552)
  wire \lt1/c17 ;  // zaklad.v(1552)
  wire \lt1/c19 ;  // zaklad.v(1552)
  wire \lt1/c3 ;  // zaklad.v(1552)
  wire \lt1/c5 ;  // zaklad.v(1552)
  wire \lt1/c7 ;  // zaklad.v(1552)
  wire \lt1/c9 ;  // zaklad.v(1552)
  wire \lt10/c1 ;  // zaklad.v(1920)
  wire \lt10/c3 ;  // zaklad.v(1920)
  wire \lt10/c5 ;  // zaklad.v(1920)
  wire \lt10/c7 ;  // zaklad.v(1920)
  wire \lt11/c1 ;  // zaklad.v(2040)
  wire \lt11/c3 ;  // zaklad.v(2040)
  wire \lt11/c5 ;  // zaklad.v(2040)
  wire \lt11/c7 ;  // zaklad.v(2040)
  wire \lt12/c1 ;  // zaklad.v(2040)
  wire \lt12/c3 ;  // zaklad.v(2040)
  wire \lt12/c5 ;  // zaklad.v(2040)
  wire \lt12/c7 ;  // zaklad.v(2040)
  wire \lt13/c1 ;  // zaklad.v(2040)
  wire \lt13/c3 ;  // zaklad.v(2040)
  wire \lt13/c5 ;  // zaklad.v(2040)
  wire \lt13/c7 ;  // zaklad.v(2040)
  wire \lt14/c1 ;  // zaklad.v(2040)
  wire \lt14/c3 ;  // zaklad.v(2040)
  wire \lt14/c5 ;  // zaklad.v(2040)
  wire \lt14/c7 ;  // zaklad.v(2040)
  wire \lt15/c1 ;  // zaklad.v(2040)
  wire \lt15/c3 ;  // zaklad.v(2040)
  wire \lt15/c5 ;  // zaklad.v(2040)
  wire \lt15/c7 ;  // zaklad.v(2040)
  wire \lt16/c1 ;  // zaklad.v(2040)
  wire \lt16/c3 ;  // zaklad.v(2040)
  wire \lt16/c5 ;  // zaklad.v(2040)
  wire \lt16/c7 ;  // zaklad.v(2040)
  wire \lt17/c1 ;  // zaklad.v(2040)
  wire \lt17/c3 ;  // zaklad.v(2040)
  wire \lt17/c5 ;  // zaklad.v(2040)
  wire \lt17/c7 ;  // zaklad.v(2040)
  wire \lt18/c1 ;  // zaklad.v(2040)
  wire \lt18/c3 ;  // zaklad.v(2040)
  wire \lt18/c5 ;  // zaklad.v(2040)
  wire \lt18/c7 ;  // zaklad.v(2040)
  wire \lt19/c1 ;  // zaklad.v(2069)
  wire \lt19/c11 ;  // zaklad.v(2069)
  wire \lt19/c13 ;  // zaklad.v(2069)
  wire \lt19/c3 ;  // zaklad.v(2069)
  wire \lt19/c5 ;  // zaklad.v(2069)
  wire \lt19/c7 ;  // zaklad.v(2069)
  wire \lt19/c9 ;  // zaklad.v(2069)
  wire \lt2/c1 ;  // zaklad.v(1598)
  wire \lt2/c11 ;  // zaklad.v(1598)
  wire \lt2/c13 ;  // zaklad.v(1598)
  wire \lt2/c15 ;  // zaklad.v(1598)
  wire \lt2/c17 ;  // zaklad.v(1598)
  wire \lt2/c19 ;  // zaklad.v(1598)
  wire \lt2/c3 ;  // zaklad.v(1598)
  wire \lt2/c5 ;  // zaklad.v(1598)
  wire \lt2/c7 ;  // zaklad.v(1598)
  wire \lt2/c9 ;  // zaklad.v(1598)
  wire \lt21/o_1_lutinv ;  // zaklad.v(2847)
  wire \lt3/c1 ;  // zaklad.v(1677)
  wire \lt3/c11 ;  // zaklad.v(1677)
  wire \lt3/c13 ;  // zaklad.v(1677)
  wire \lt3/c15 ;  // zaklad.v(1677)
  wire \lt3/c3 ;  // zaklad.v(1677)
  wire \lt3/c5 ;  // zaklad.v(1677)
  wire \lt3/c7 ;  // zaklad.v(1677)
  wire \lt3/c9 ;  // zaklad.v(1677)
  wire \lt4/c1 ;  // zaklad.v(1813)
  wire \lt4/c11 ;  // zaklad.v(1813)
  wire \lt4/c13 ;  // zaklad.v(1813)
  wire \lt4/c15 ;  // zaklad.v(1813)
  wire \lt4/c17 ;  // zaklad.v(1813)
  wire \lt4/c19 ;  // zaklad.v(1813)
  wire \lt4/c21 ;  // zaklad.v(1813)
  wire \lt4/c23 ;  // zaklad.v(1813)
  wire \lt4/c25 ;  // zaklad.v(1813)
  wire \lt4/c27 ;  // zaklad.v(1813)
  wire \lt4/c29 ;  // zaklad.v(1813)
  wire \lt4/c3 ;  // zaklad.v(1813)
  wire \lt4/c31 ;  // zaklad.v(1813)
  wire \lt4/c5 ;  // zaklad.v(1813)
  wire \lt4/c7 ;  // zaklad.v(1813)
  wire \lt4/c9 ;  // zaklad.v(1813)
  wire \lt5/c1 ;  // zaklad.v(1848)
  wire \lt5/c11 ;  // zaklad.v(1848)
  wire \lt5/c13 ;  // zaklad.v(1848)
  wire \lt5/c3 ;  // zaklad.v(1848)
  wire \lt5/c5 ;  // zaklad.v(1848)
  wire \lt5/c7 ;  // zaklad.v(1848)
  wire \lt5/c9 ;  // zaklad.v(1848)
  wire \lt8/c1 ;  // zaklad.v(1886)
  wire \lt8/c3 ;  // zaklad.v(1886)
  wire \lt8/c5 ;  // zaklad.v(1886)
  wire \lt8/c7 ;  // zaklad.v(1886)
  wire \lt9/c1 ;  // zaklad.v(1887)
  wire \lt9/c3 ;  // zaklad.v(1887)
  wire \lt9/c5 ;  // zaklad.v(1887)
  wire \lt9/c7 ;  // zaklad.v(1887)
  wire \main_clock/clk0_buf ;  // al_ip/pll.v(43)
  wire mux100_b0_sel_is_3_o;
  wire mux101_b0_sel_is_3_o;
  wire mux101_b10_sel_is_3_o;
  wire mux101_b16_sel_is_3_o;
  wire mux101_b24_sel_is_3_o;
  wire mux102_b0_sel_is_3_o;
  wire mux102_b10_sel_is_3_o;
  wire mux103_b0_sel_is_3_o;
  wire mux105_b0_sel_is_3_o;
  wire mux18_b0_sel_is_3_o;
  wire mux23_b13_sel_is_0_o;
  wire mux47_b0_sel_is_3_o;
  wire mux48_b0_sel_is_3_o;
  wire mux49_b0_sel_is_3_o;
  wire mux50_b0_sel_is_3_o;
  wire mux68_b0_sel_is_3_o;
  wire mux68_b10_sel_is_3_o;
  wire mux70_b0_sel_is_3_o;
  wire mux70_b10_sel_is_3_o;
  wire mux71_b0_sel_is_3_o;
  wire mux71_b10_sel_is_3_o;
  wire mux72_b0_sel_is_3_o;
  wire mux72_b10_sel_is_3_o;
  wire mux72_b16_sel_is_3_o;
  wire mux73_b0_sel_is_3_o;
  wire mux73_b10_sel_is_3_o;
  wire mux73_b16_sel_is_3_o;
  wire mux73_b24_sel_is_3_o;
  wire mux74_b0_sel_is_3_o;
  wire mux75_b0_sel_is_3_o;
  wire mux76_b0_sel_is_3_o;
  wire mux76_b10_sel_is_3_o;
  wire mux76_b16_sel_is_3_o;
  wire mux76_b24_sel_is_3_o;
  wire mux77_b0_sel_is_3_o;
  wire mux77_b10_sel_is_3_o;
  wire mux78_b0_sel_is_3_o;
  wire mux78_b10_sel_is_3_o;
  wire mux79_b0_sel_is_3_o;
  wire mux79_b10_sel_is_3_o;
  wire mux80_b0_sel_is_3_o;
  wire mux81_b0_sel_is_3_o;
  wire mux82_b0_sel_is_3_o;
  wire mux82_b10_sel_is_3_o;
  wire mux89_b0_sel_is_3_o;
  wire mux89_b10_sel_is_3_o;
  wire mux90_b0_sel_is_3_o;
  wire mux91_b0_sel_is_3_o;
  wire mux98_b0_sel_is_3_o;
  wire mux99_b0_sel_is_3_o;
  wire mux9_b10_sel_is_3_o;
  wire n100;
  wire n122;
  wire n125;
  wire n139;
  wire n147;
  wire n148;
  wire n152;
  wire n153;
  wire n170;
  wire n172;
  wire n179;
  wire n181;
  wire n186;
  wire n194;
  wire n202;
  wire n206;
  wire n222_lutinv;
  wire n227;
  wire n23;
  wire n237;
  wire n251;
  wire n255;
  wire n26;
  wire n266;
  wire n290;
  wire n294;
  wire n30;
  wire n301;
  wire n305;
  wire n312;
  wire n316;
  wire n323;
  wire n327;
  wire n33;
  wire n346;
  wire n358;
  wire n365;
  wire n379;
  wire n38;
  wire n41;
  wire n431_lutinv;
  wire n45;
  wire n477;
  wire n479;
  wire n48;
  wire n499;
  wire n515;
  wire n53;
  wire n556;
  wire n557;
  wire n58;
  wire n602;
  wire n61;
  wire n647_lutinv;
  wire n648_lutinv;
  wire n650_lutinv;
  wire n651_lutinv;
  wire n652_lutinv;
  wire n653_lutinv;
  wire n657_lutinv;
  wire n658_lutinv;
  wire n661_lutinv;
  wire n664_lutinv;
  wire n679_lutinv;
  wire n680_lutinv;
  wire n682_lutinv;
  wire n687_lutinv;
  wire n78;
  wire n8;
  wire n82;
  wire n96;
  wire o_1khz_calib_pad;  // zaklad.v(883)
  wire o_ac_dc_1_pad;  // zaklad.v(897)
  wire o_ac_dc_2_pad;  // zaklad.v(902)
  wire o_offset_1_pad;  // zaklad.v(893)
  wire o_offset_2_pad;  // zaklad.v(898)
  wire o_pwm_display_pad;  // zaklad.v(903)
  wire o_relay1_1_pad;  // zaklad.v(894)
  wire o_relay1_2_pad;  // zaklad.v(895)
  wire o_relay1_3_pad;  // zaklad.v(896)
  wire o_relay2_1_pad;  // zaklad.v(899)
  wire o_relay2_2_pad;  // zaklad.v(900)
  wire o_relay2_3_pad;  // zaklad.v(901)
  wire p_rst;  // zaklad.v(1719)
  wire p_v;  // zaklad.v(1719)
  wire p_wr;  // zaklad.v(1719)
  wire pat_ctl_t;  // zaklad.v(977)
  wire pat_level;  // zaklad.v(978)
  wire pat_running;  // zaklad.v(978)
  wire pat_wr_lvl;  // zaklad.v(972)
  wire pat_wr_t;  // zaklad.v(975)
  wire peak_en;  // zaklad.v(1037)
  wire q_rs1;  // zaklad.v(2254)
  wire q_rs2;  // zaklad.v(2254)
  wire rd_ld;  // zaklad.v(1728)
  wire rd_t;  // zaklad.v(1063)
  wire sample_clock_enable;  // zaklad.v(917)
  wire sample_system_reset;  // zaklad.v(994)
  wire sample_system_state;  // zaklad.v(995)
  wire sample_write_clock /* synthesis keep=1 */ ;  // zaklad.v(992)
  wire sample_write_clock_gclk_net;
  wire sample_write_enable;  // zaklad.v(993)
  wire sampling_half_way;  // zaklad.v(1004)
  wire sampling_triggered;  // zaklad.v(1003)
  wire sce_q;  // zaklad.v(1182)
  wire sel63_b4_var_o_lutinv;
  wire sel65_b0_def_0_sel_is_0_o;
  wire sel67_b8_var_o_lutinv;
  wire seq_raw;  // zaklad.v(1072)
  wire ssr_d;  // zaklad.v(1091)
  wire str;  // zaklad.v(1058)
  wire str_s;  // zaklad.v(1067)
  wire \sub0/c11 ;  // zaklad.v(1601)
  wire \sub0/c15 ;  // zaklad.v(1601)
  wire \sub0/c3 ;  // zaklad.v(1601)
  wire \sub0/c7 ;  // zaklad.v(1601)
  wire \sub1/c1 ;  // zaklad.v(1778)
  wire \sub1/c11 ;  // zaklad.v(1778)
  wire \sub1/c3 ;  // zaklad.v(1778)
  wire \sub1/c5 ;  // zaklad.v(1778)
  wire \sub1/c7 ;  // zaklad.v(1778)
  wire \sub1/c9 ;  // zaklad.v(1778)
  wire \sub10/c1 ;  // zaklad.v(2040)
  wire \sub10/c3 ;  // zaklad.v(2040)
  wire \sub10/c5 ;  // zaklad.v(2040)
  wire \sub10/c7 ;  // zaklad.v(2040)
  wire \sub11/c1 ;  // zaklad.v(2040)
  wire \sub11/c3 ;  // zaklad.v(2040)
  wire \sub11/c5 ;  // zaklad.v(2040)
  wire \sub11/c7 ;  // zaklad.v(2040)
  wire \sub12/c1 ;  // zaklad.v(2040)
  wire \sub12/c3 ;  // zaklad.v(2040)
  wire \sub12/c5 ;  // zaklad.v(2040)
  wire \sub12/c7 ;  // zaklad.v(2040)
  wire \sub13/c11 ;  // zaklad.v(2113)
  wire \sub13/c15 ;  // zaklad.v(2113)
  wire \sub13/c19 ;  // zaklad.v(2113)
  wire \sub13/c23 ;  // zaklad.v(2113)
  wire \sub13/c27 ;  // zaklad.v(2113)
  wire \sub13/c3 ;  // zaklad.v(2113)
  wire \sub13/c31 ;  // zaklad.v(2113)
  wire \sub13/c7 ;  // zaklad.v(2113)
  wire \sub14/c11 ;  // zaklad.v(2118)
  wire \sub14/c15 ;  // zaklad.v(2118)
  wire \sub14/c19 ;  // zaklad.v(2118)
  wire \sub14/c23 ;  // zaklad.v(2118)
  wire \sub14/c27 ;  // zaklad.v(2118)
  wire \sub14/c3 ;  // zaklad.v(2118)
  wire \sub14/c31 ;  // zaklad.v(2118)
  wire \sub14/c7 ;  // zaklad.v(2118)
  wire \sub15/c1 ;  // zaklad.v(2152)
  wire \sub15/c11 ;  // zaklad.v(2152)
  wire \sub15/c3 ;  // zaklad.v(2152)
  wire \sub15/c5 ;  // zaklad.v(2152)
  wire \sub15/c7 ;  // zaklad.v(2152)
  wire \sub15/c9 ;  // zaklad.v(2152)
  wire \sub2/c1 ;  // zaklad.v(1832)
  wire \sub2/c11 ;  // zaklad.v(1832)
  wire \sub2/c3 ;  // zaklad.v(1832)
  wire \sub2/c5 ;  // zaklad.v(1832)
  wire \sub2/c7 ;  // zaklad.v(1832)
  wire \sub2/c9 ;  // zaklad.v(1832)
  wire \sub3/c1 ;  // zaklad.v(1844)
  wire \sub3/c11 ;  // zaklad.v(1844)
  wire \sub3/c3 ;  // zaklad.v(1844)
  wire \sub3/c5 ;  // zaklad.v(1844)
  wire \sub3/c7 ;  // zaklad.v(1844)
  wire \sub3/c9 ;  // zaklad.v(1844)
  wire \sub4/c1 ;  // zaklad.v(1880)
  wire \sub4/c3 ;  // zaklad.v(1880)
  wire \sub4/c5 ;  // zaklad.v(1880)
  wire \sub4/c7 ;  // zaklad.v(1880)
  wire \sub5/c1 ;  // zaklad.v(2040)
  wire \sub5/c3 ;  // zaklad.v(2040)
  wire \sub5/c5 ;  // zaklad.v(2040)
  wire \sub5/c7 ;  // zaklad.v(2040)
  wire \sub6/c1 ;  // zaklad.v(2040)
  wire \sub6/c3 ;  // zaklad.v(2040)
  wire \sub6/c5 ;  // zaklad.v(2040)
  wire \sub6/c7 ;  // zaklad.v(2040)
  wire \sub7/c1 ;  // zaklad.v(2040)
  wire \sub7/c3 ;  // zaklad.v(2040)
  wire \sub7/c5 ;  // zaklad.v(2040)
  wire \sub7/c7 ;  // zaklad.v(2040)
  wire \sub8/c1 ;  // zaklad.v(2040)
  wire \sub8/c3 ;  // zaklad.v(2040)
  wire \sub8/c5 ;  // zaklad.v(2040)
  wire \sub8/c7 ;  // zaklad.v(2040)
  wire \sub9/c1 ;  // zaklad.v(2040)
  wire \sub9/c3 ;  // zaklad.v(2040)
  wire \sub9/c5 ;  // zaklad.v(2040)
  wire \sub9/c7 ;  // zaklad.v(2040)
  wire swc_adv;  // zaklad.v(1102)
  wire swc_adv_q;  // zaklad.v(1103)
  wire swc_rose;  // zaklad.v(1184)
  wire swc_sh;  // zaklad.v(1183)
  wire swe_d;  // zaklad.v(2177)
  wire time_base_timeout;  // zaklad.v(923)
  wire trig_arm_f;  // zaklad.v(1014)
  wire trig_arm_r;  // zaklad.v(1013)
  wire trig_pol;  // zaklad.v(1042)
  wire trig_pw_long;  // zaklad.v(1041)
  wire trig_src_ext;  // zaklad.v(1043)
  wire trigger_channel;  // zaklad.v(1008)
  wire trigger_check_enable;  // zaklad.v(925)
  wire trigger_edge;  // zaklad.v(1007)
  wire trigger_ext;  // zaklad.v(1009)
  wire trigger_mode;  // zaklad.v(1006)
  wire trigger_mode_s;  // zaklad.v(1836)
  wire trigger_mode_s1;  // zaklad.v(1836)
  wire \u1/c1 ;  // zaklad.v(285)
  wire \u1/c3 ;  // zaklad.v(285)
  wire \u1/c5 ;  // zaklad.v(285)
  wire \u1/c7 ;  // zaklad.v(285)
  wire \u2/c1 ;  // zaklad.v(285)
  wire \u2/c3 ;  // zaklad.v(285)
  wire \u2/c5 ;  // zaklad.v(285)
  wire \u2/c7 ;  // zaklad.v(285)
  wire \u2/c9 ;  // zaklad.v(285)
  wire \u3/c1 ;  // zaklad.v(285)
  wire \u3/c3 ;  // zaklad.v(285)
  wire \u3/c5 ;  // zaklad.v(285)
  wire \u3/c7 ;  // zaklad.v(285)
  wire \u3/c9 ;  // zaklad.v(285)
  wire \u4/c1 ;  // zaklad.v(285)
  wire \u4/c3 ;  // zaklad.v(285)
  wire \u4/c5 ;  // zaklad.v(285)
  wire \u4/c7 ;  // zaklad.v(285)
  wire \u5/c1 ;  // zaklad.v(285)
  wire \u5/c3 ;  // zaklad.v(285)
  wire \u5/c5 ;  // zaklad.v(285)
  wire \u5/c7 ;  // zaklad.v(285)
  wire \u5/c9 ;  // zaklad.v(285)
  wire u536_sel_is_3_o;
  wire u538_sel_is_3_o;
  wire u540_sel_is_3_o;
  wire u543_sel_is_3_o;
  wire u545_sel_is_3_o;
  wire u546_sel_is_3_o;
  wire u549_sel_is_3_o;
  wire u550_sel_is_3_o;
  wire u553_sel_is_3_o;
  wire u554_sel_is_3_o;
  wire u555_sel_is_3_o;
  wire u558_sel_is_3_o;
  wire u560_sel_is_3_o;
  wire u561_sel_is_3_o;
  wire \u6/c1 ;  // zaklad.v(285)
  wire \u6/c3 ;  // zaklad.v(285)
  wire \u6/c5 ;  // zaklad.v(285)
  wire \u6/c7 ;  // zaklad.v(285)
  wire \u6/c9 ;  // zaklad.v(285)
  wire \u_sq/add0/c11 ;  // zaklad.v(704)
  wire \u_sq/add0/c15 ;  // zaklad.v(704)
  wire \u_sq/add0/c3 ;  // zaklad.v(704)
  wire \u_sq/add0/c7 ;  // zaklad.v(704)
  wire \u_sq/add1/c1 ;  // zaklad.v(706)
  wire \u_sq/add1/c11 ;  // zaklad.v(706)
  wire \u_sq/add1/c13 ;  // zaklad.v(706)
  wire \u_sq/add1/c15 ;  // zaklad.v(706)
  wire \u_sq/add1/c3 ;  // zaklad.v(706)
  wire \u_sq/add1/c5 ;  // zaklad.v(706)
  wire \u_sq/add1/c7 ;  // zaklad.v(706)
  wire \u_sq/add1/c9 ;  // zaklad.v(706)
  wire \u_sq/add2/c11 ;  // zaklad.v(757)
  wire \u_sq/add2/c15 ;  // zaklad.v(757)
  wire \u_sq/add2/c19 ;  // zaklad.v(757)
  wire \u_sq/add2/c23 ;  // zaklad.v(757)
  wire \u_sq/add2/c27 ;  // zaklad.v(757)
  wire \u_sq/add2/c3 ;  // zaklad.v(757)
  wire \u_sq/add2/c31 ;  // zaklad.v(757)
  wire \u_sq/add2/c7 ;  // zaklad.v(757)
  wire \u_sq/bd ;  // zaklad.v(680)
  wire \u_sq/commit ;  // zaklad.v(677)
  wire \u_sq/commit_hfnopt2_0 ;  // zaklad.v(677)
  wire \u_sq/commit_hfnopt2_1 ;  // zaklad.v(677)
  wire \u_sq/commit_hfnopt2_2 ;  // zaklad.v(677)
  wire \u_sq/commit_hfnopt2_3 ;  // zaklad.v(677)
  wire \u_sq/ct_ev ;  // zaklad.v(675)
  wire \u_sq/cur ;  // zaklad.v(667)
  wire \u_sq/cur_n_lutinv ;  // zaklad.v(686)
  wire \u_sq/go ;  // zaklad.v(671)
  wire \u_sq/idle_lv ;  // zaklad.v(666)
  wire \u_sq/n17 ;
  wire \u_sq/n19 ;
  wire \u_sq/n23 ;
  wire \u_sq/n26 ;
  wire \u_sq/n46 ;
  wire \u_sq/n49 ;
  wire \u_sq/n8_lutinv ;
  wire \u_sq/n9 ;
  wire \u_sq/stop ;  // zaklad.v(678)
  wire \u_sq/sub0/c11 ;  // zaklad.v(759)
  wire \u_sq/sub0/c15 ;  // zaklad.v(759)
  wire \u_sq/sub0/c19 ;  // zaklad.v(759)
  wire \u_sq/sub0/c23 ;  // zaklad.v(759)
  wire \u_sq/sub0/c27 ;  // zaklad.v(759)
  wire \u_sq/sub0/c3 ;  // zaklad.v(759)
  wire \u_sq/sub0/c31 ;  // zaklad.v(759)
  wire \u_sq/sub0/c7 ;  // zaklad.v(759)
  wire \u_sq/u39_sel_is_2_o ;
  wire \u_sq/wr_ev_lutinv ;  // zaklad.v(674)

  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1034|reg55_b7  (
    .a({open_n0,\dec_ch2/n120_lutinv }),
    .b({open_n1,\dec_ch2/c3 [15]}),
    .c({\dec_ch2/c2p [47],\dec_ch2/c3 [23]}),
    .ce(mux70_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch1/k3_lutinv ,dec_shift[3]}),
    .e({open_n2,dec_shift[4]}),
    .mi({open_n4,io_mcu_data_pad[7]}),
    .f({\dec_ch2/n85 [47],\dec_ch2/n11_lutinv }),
    .q({open_n20,pretrigger_samples[7]}));  // zaklad.v(2867)
  // zaklad.v(2075)
  AL_PHY_LSLICE \_al_u1035|reg46_b0  (
    .a({open_n21,trigger_read_address[0]}),
    .b({open_n22,n360[0]}),
    .c({\dec_ch2/c2p [46],_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,n358}),
    .e({open_n24,pretrigger_samples[0]}),
    .f({\dec_ch2/n85 [46],open_n40}),
    .q({open_n44,trigger_read_address[0]}));  // zaklad.v(2075)
  // zaklad.v(171)
  AL_PHY_MSLICE \_al_u1036|peripheral_clock/clk_out_reg  (
    .a({open_n45,clk_50MHz}),
    .c({\dec_ch2/c2p [45],open_n48}),
    .ce(\peripheral_clock/count ),
    .clk(clk_200MHz),
    .d({\dec_ch1/k3_lutinv ,open_n49}),
    .f({\dec_ch2/n85 [45],open_n63}),
    .q({open_n67,clk_50MHz}));  // zaklad.v(171)
  // zaklad.v(163)
  AL_PHY_LSLICE \_al_u1037|peripheral_clock/count_reg[0]  (
    .a({open_n68,\peripheral_clock/count }),
    .c({\dec_ch2/c2p [44],open_n71}),
    .clk(clk_200MHz),
    .d({\dec_ch1/k3_lutinv ,open_n73}),
    .sr(\peripheral_clock/count ),
    .f({\dec_ch2/n85 [44],open_n90}),
    .q({open_n94,\peripheral_clock/count }));  // zaklad.v(163)
  AL_PHY_MSLICE _al_u1038 (
    .c({open_n99,\dec_ch2/c2p [43]}),
    .d({open_n102,\dec_ch1/k3_lutinv }),
    .f({open_n116,\dec_ch2/n85 [43]}));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1040|dec_ch2/reg27_b36  (
    .c({\dec_ch2/c2p [41],\dec_ch2/c2p [42]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({open_n129,\dec_ch2/c2 [36]}),
    .f({\dec_ch2/n85 [41],\dec_ch2/n85 [42]}),
    .q({open_n145,\dec_ch2/c2p [36]}));  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1041|_al_u1043  (
    .c(\dec_ch2/c2p [40:39]),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .f(\dec_ch2/n85 [40:39]));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1051|dec_ch2/reg27_b27  (
    .c({\dec_ch2/c2p [31],\dec_ch2/c2p [34]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({open_n181,\dec_ch2/c2 [27]}),
    .f({\dec_ch2/n85 [31],\dec_ch2/n85 [34]}),
    .q({open_n197,\dec_ch2/c2p [27]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1055|dec_ch2/reg27_b19  (
    .a({open_n198,\dec_ch2/c2p [19]}),
    .c({\dec_ch2/c2p [28],open_n201}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({open_n205,\dec_ch2/c2 [19]}),
    .f({\dec_ch2/n85 [28],\dec_ch2/n85 [19]}),
    .q({open_n221,\dec_ch2/c2p [19]}));  // zaklad.v(277)
  // zaklad.v(1350)
  AL_PHY_LSLICE \_al_u1086|reg4_b18  (
    .b({open_n224,ch1_offset[11]}),
    .c({\dec_ch2/i3 [44],\channel1_dc_offset/count [11]}),
    .clk(clk_200MHz),
    .d({\dec_ch1/k3_lutinv ,_al_u1700_o}),
    .mi({open_n229,adc_d1[18]}),
    .f({\dec_ch2/n74 [44],_al_u1701_o}),
    .q({open_n245,adc_dd1[18]}));  // zaklad.v(1350)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1087|reg63_b9  (
    .a({open_n246,\display_brightness/count [1]}),
    .b({open_n247,display_brigthness[1]}),
    .c({\dec_ch2/i3 [43],\display_brightness/count [0]}),
    .ce(mux78_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch1/k3_lutinv ,display_brigthness[0]}),
    .mi({open_n251,io_mcu_data_pad[1]}),
    .f({\dec_ch2/n74 [43],_al_u1736_o}),
    .q({open_n267,ch2_offset[9]}));  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1088|_al_u1092  (
    .c({\dec_ch2/i3 [42],\dec_ch2/i3 [39]}),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .f({\dec_ch2/n74 [42],\dec_ch2/n74 [39]}));
  AL_PHY_LSLICE _al_u1089 (
    .c({open_n296,\dec_ch2/i3 [41]}),
    .d({open_n299,\dec_ch1/k3_lutinv }),
    .f({open_n317,\dec_ch2/n74 [41]}));
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1090|dec_ch2/reg20_b44  (
    .c({\dec_ch2/i3 [40],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch2/i2 [43]}),
    .mi({open_n338,\dec_ch2/n76 [44]}),
    .f({\dec_ch2/n74 [40],\dec_ch2/n71 [43]}),
    .q({open_n343,\dec_ch2/i3 [44]}));  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1093|_al_u1099  (
    .c({\dec_ch2/i3 [38],\dec_ch2/i3 [32]}),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .f({\dec_ch2/n74 [38],\dec_ch2/n74 [32]}));
  AL_PHY_MSLICE \_al_u1094|_al_u1095  (
    .c(\dec_ch2/i3 [37:36]),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .f(\dec_ch2/n74 [37:36]));
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1096|dec_ch2/reg20_b38  (
    .c({\dec_ch2/i3 [35],\dec_ch2/i3 [31]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({open_n411,\dec_ch2/n76 [38]}),
    .f({\dec_ch2/n74 [35],\dec_ch2/n74 [31]}),
    .q({open_n416,\dec_ch2/i3 [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1098|dec_ch2/reg20_b32  (
    .c({\dec_ch2/i3 [33],\dec_ch2/i3 [34]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({open_n425,\dec_ch2/n76 [32]}),
    .f({\dec_ch2/n74 [33],\dec_ch2/n74 [34]}),
    .q({open_n441,\dec_ch2/i3 [32]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1103|dec_ch2/reg20_b29  (
    .c({\dec_ch1/k3_lutinv ,\dec_ch2/i3 [28]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i3 [29],\dec_ch1/k3_lutinv }),
    .mi({open_n450,\dec_ch2/n76 [29]}),
    .f(\dec_ch2/n74 [29:28]),
    .q({open_n466,\dec_ch2/i3 [29]}));  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1110|_al_u1111  (
    .c(\dec_ch2/i3 [22:21]),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .f(\dec_ch2/n74 [22:21]));
  AL_PHY_MSLICE \_al_u1112|_al_u1114  (
    .c(\dec_ch2/i3 [20:19]),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .f(\dec_ch2/n74 [20:19]));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1133|dec_ch1/reg3_b2  (
    .a({open_n519,pair_e1[0]}),
    .b({open_n520,\dec_ch1/n19 [0]}),
    .c({\dec_ch1/pe [0],pair_e1[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,dec_order[0]}),
    .e({open_n522,\dec_order[1]_hfnopt2_1 }),
    .mi({open_n524,pair_e1[2]}),
    .f({\dec_ch1/t_pe [0],\dec_ch1/t_xe [1]}),
    .q({open_n540,\dec_ch1/pe [2]}));  // zaklad.v(277)
  AL_PHY_PAD _al_u133 (
    .ipad(i_mcu_clk),
    .di(i_mcu_clk_pad));  // zaklad.v(871)
  AL_PHY_PAD _al_u134 (
    .ipad(i_mcu_dcs),
    .di(i_mcu_dcs_pad));  // zaklad.v(873)
  AL_PHY_PAD _al_u135 (
    .ipad(i_mcu_rws),
    .di(i_mcu_rws_pad));  // zaklad.v(872)
  AL_PHY_PAD _al_u136 (
    .ipad(i_xtal),
    .di(i_xtal_pad));  // zaklad.v(870)
  AL_PHY_PAD _al_u137 (
    .otrue(o_mcu_data[7]),
    .ts(n477),
    .di(io_mcu_data_pad[7]),
    .bpad(io_mcu_data[7]));  // zaklad.v(3518)
  // zaklad.v(2102)
  AL_PHY_MSLICE \_al_u1370|ho_run_reg  (
    .a({open_n594,ho_run}),
    .b({open_n595,ho_st_q}),
    .c({ho_en,ho_cnt[32]}),
    .clk(clk_200MHz),
    .d({ho_run,sampling_triggered}),
    .sr(n365),
    .f({_al_u1370_o,open_n609}),
    .q({open_n613,ho_run}));  // zaklad.v(2102)
  AL_PHY_PAD _al_u138 (
    .otrue(o_mcu_data[6]),
    .ts(n477),
    .di(io_mcu_data_pad[6]),
    .bpad(io_mcu_data[6]));  // zaklad.v(3518)
  AL_PHY_PAD _al_u139 (
    .otrue(o_mcu_data[5]),
    .ts(n477),
    .di(io_mcu_data_pad[5]),
    .bpad(io_mcu_data[5]));  // zaklad.v(3518)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1393|reg57_b0  (
    .a({_al_u1391_o,oc_1A[0]}),
    .b({n170,mcu_state[0]}),
    .c({_al_u1392_o,mcu_state[1]}),
    .ce(mux72_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({io_mcu_data_pad[1],cap_sel_x[0]}),
    .e({io_mcu_data_pad[0],cap_sel_x[8]}),
    .mi({open_n633,io_mcu_data_pad[0]}),
    .f({n172,_al_u2159_o}),
    .q({open_n649,sample_rate_divider[0]}));  // zaklad.v(2867)
  // zaklad.v(694)
  AL_PHY_LSLICE \_al_u1399|u_sq/reg11_b0  (
    .a({\display_brightness/count [12],\u_sq/acc [0]}),
    .b({\display_brightness/count [13],\u_sq/n9 }),
    .c({\display_brightness/count [14],\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\display_brightness/count [15],\u_sq/n8_lutinv }),
    .e({open_n650,\u_sq/acc_sum [0]}),
    .f({_al_u1399_o,open_n666}),
    .q({open_n670,\u_sq/acc [0]}));  // zaklad.v(694)
  AL_PHY_PAD _al_u140 (
    .otrue(o_mcu_data[4]),
    .ts(n477),
    .di(io_mcu_data_pad[4]),
    .bpad(io_mcu_data[4]));  // zaklad.v(3518)
  AL_PHY_PAD _al_u141 (
    .otrue(o_mcu_data[3]),
    .ts(n477),
    .di(io_mcu_data_pad[3]),
    .bpad(io_mcu_data[3]));  // zaklad.v(3518)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1416|dec_ch2/reg28_b35  (
    .b({_al_u1414_o,open_n691}),
    .c({_al_u1415_o,_al_u806_o}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1413_o,\dec_ch2/n116_lutinv }),
    .f({n647_lutinv,open_n709}),
    .q({open_n713,\dec_ch2/sh [35]}));  // zaklad.v(277)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1417|reg58_b4  (
    .c({n515,mcu_command[1]}),
    .ce(mux73_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n647_lutinv,mcu_command[0]}),
    .mi({open_n721,io_mcu_data_pad[4]}),
    .f({u536_sel_is_3_o,_al_u1414_o}),
    .q({open_n737,time_base_set[4]}));  // zaklad.v(2867)
  AL_PHY_LSLICE _al_u1418 (
    .c({open_n742,mcu_command[5]}),
    .d({open_n745,mcu_command[4]}),
    .f({open_n763,_al_u1418_o}));
  AL_PHY_PAD _al_u142 (
    .otrue(o_mcu_data[2]),
    .ts(n477),
    .di(io_mcu_data_pad[2]),
    .bpad(io_mcu_data[2]));  // zaklad.v(3518)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1422|dec_ch2/reg28_b34  (
    .a({_al_u1419_o,open_n778}),
    .b({_al_u1420_o,open_n779}),
    .c({_al_u1421_o,_al_u806_o}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({n515,\dec_ch2/n117_lutinv }),
    .f({u545_sel_is_3_o,open_n797}),
    .q({open_n801,\dec_ch2/sh [34]}));  // zaklad.v(277)
  AL_PHY_PAD _al_u143 (
    .otrue(o_mcu_data[1]),
    .ts(n477),
    .di(io_mcu_data_pad[1]),
    .bpad(io_mcu_data[1]));  // zaklad.v(3518)
  // zaklad.v(2102)
  AL_PHY_MSLICE \_al_u1432|reg47_b1  (
    .a({n652_lutinv,open_n811}),
    .b({open_n812,_al_u1414_o}),
    .c({n515,_al_u1426_o}),
    .clk(clk_200MHz),
    .d({open_n814,_al_u1419_o}),
    .mi({open_n825,ho_ct_s[0]}),
    .f({u540_sel_is_3_o,n652_lutinv}),
    .q({open_n830,ho_ct_s[1]}));  // zaklad.v(2102)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1437|dec_ch2/reg28_b40  (
    .b({open_n833,\dec_ch2/c3 [40]}),
    .c({_al_u1436_o,\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1426_o,_al_u806_o}),
    .f({_al_u1437_o,open_n851}),
    .q({open_n855,\dec_ch2/sh [40]}));  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1439|_al_u2155  (
    .a({open_n856,_al_u2102_o}),
    .b({open_n857,sel67_b8_var_o_lutinv}),
    .c({mcu_command[5],mcu_command[2]}),
    .d(mcu_command[4:3]),
    .e({open_n860,o_mcu_data[0]}),
    .f({_al_u1439_o,_al_u2155_o}));
  AL_PHY_PAD _al_u144 (
    .otrue(o_mcu_data[0]),
    .ts(n477),
    .di(io_mcu_data_pad[0]),
    .bpad(io_mcu_data[0]));  // zaklad.v(3518)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1445|dec_ch2/reg28_b42  (
    .b({mcu_command[6],\dec_ch2/c3 [42]}),
    .c({mcu_command[7],\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1418_o,_al_u806_o}),
    .f({_al_u1445_o,open_n905}),
    .q({open_n909,\dec_ch2/sh [42]}));  // zaklad.v(277)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1447|reg76_b0  (
    .c({n515,sample_write_enable}),
    .ce(mux91_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n679_lutinv,swc_adv}),
    .mi({open_n924,io_mcu_data_pad[0]}),
    .f({mux91_b0_sel_is_3_o,n122}),
    .q({open_n929,trig_type[0]}));  // zaklad.v(2867)
  // zaklad.v(1215)
  AL_PHY_MSLICE \_al_u1448|ext_activity_reg  (
    .a({_al_u1445_o,open_n930}),
    .b({\lt21/o_1_lutinv ,sampling_half_way}),
    .c({_al_u1426_o,sampling_triggered}),
    .ce(n96),
    .clk(clk_200MHz),
    .d({n515,sample_write_enable}),
    .mi({open_n941,1'b1}),
    .sr(sample_system_reset),
    .f({u558_sel_is_3_o,n237}),
    .q({open_n945,ext_activity}));  // zaklad.v(1215)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1449|dec_ch2/reg28_b32  (
    .b({_al_u1445_o,open_n948}),
    .c({n515,_al_u806_o}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1428_o,\dec_ch2/n119_lutinv }),
    .f({u555_sel_is_3_o,open_n962}),
    .q({open_n966,\dec_ch2/sh [32]}));  // zaklad.v(277)
  AL_PHY_PAD _al_u145 (
    .otrue(pat_level),
    .ts(gen_out_enable),
    .di(o_1khz_calib_pad),
    .bpad(o_1khz_calib));  // zaklad.v(1161)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1450|reg66_b5  (
    .b({_al_u1445_o,_al_u1440_o}),
    .c({n515,n515}),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1437_o,_al_u1437_o}),
    .mi({open_n981,io_mcu_data_pad[5]}),
    .f({mux81_b0_sel_is_3_o,mux90_b0_sel_is_3_o}),
    .q({open_n997,dec_shift[5]}));  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1451|_al_u1989  (
    .b({open_n1000,\lt21/o_1_lutinv }),
    .c({\lt21/o_1_lutinv ,_al_u1441_o}),
    .d({_al_u1415_o,_al_u1419_o}),
    .f({_al_u1451_o,n431_lutinv}));
  AL_PHY_PAD _al_u146 (
    .otrue(o_ac_dc_1_pad),
    .opad(o_ac_dc_1));  // zaklad.v(897)
  AL_PHY_PAD _al_u147 (
    .otrue(o_ac_dc_2_pad),
    .opad(o_ac_dc_2));  // zaklad.v(902)
  AL_PHY_PAD _al_u148 (
    .otrue(o_offset_1_pad),
    .opad(o_offset_1));  // zaklad.v(893)
  AL_PHY_PAD _al_u149 (
    .otrue(o_offset_2_pad),
    .opad(o_offset_2));  // zaklad.v(898)
  AL_PHY_PAD _al_u150 (
    .otrue(o_pwm_display_pad),
    .opad(o_pwm_display));  // zaklad.v(903)
  AL_PHY_PAD _al_u151 (
    .otrue(o_relay1_1_pad),
    .opad(o_relay1_1));  // zaklad.v(894)
  AL_PHY_PAD _al_u152 (
    .otrue(o_relay1_2_pad),
    .opad(o_relay1_2));  // zaklad.v(895)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1524|reg74_b11  (
    .a({oc_1A[12],oc_1A[9]}),
    .b({oc_1A[13],mcu_state[0]}),
    .c({oc_1A[14],mcu_state[1]}),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({oc_1A[15],cap_sel_x[1]}),
    .e({open_n1102,cap_sel_x[9]}),
    .mi({open_n1104,io_mcu_data_pad[3]}),
    .f({n23,_al_u2144_o}),
    .q({open_n1120,cap_sel_x[11]}));  // zaklad.v(2867)
  // zaklad.v(1206)
  AL_PHY_MSLICE \_al_u1525|swc_rose_reg  (
    .a({oc_1A[0],open_n1121}),
    .b({oc_1A[1],open_n1122}),
    .c({oc_1A[2],swc_sh}),
    .clk(clk_200MHz),
    .d({oc_1A[3],sce_q}),
    .f({n33,open_n1137}),
    .q({open_n1141,swc_rose}));  // zaklad.v(1206)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1527|reg74_b8  (
    .a({oc_1A[10],oc_1A[4]}),
    .b({oc_1A[11],oc_1A[5]}),
    .c({oc_1A[8],oc_1A[6]}),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({oc_1A[9],oc_1A[7]}),
    .mi({open_n1152,io_mcu_data_pad[0]}),
    .f({n26,n30}),
    .q({open_n1157,cap_sel_x[8]}));  // zaklad.v(2867)
  AL_PHY_PAD _al_u153 (
    .otrue(o_relay1_3_pad),
    .opad(o_relay1_3));  // zaklad.v(896)
  AL_PHY_PAD _al_u154 (
    .otrue(o_relay2_1_pad),
    .opad(o_relay2_1));  // zaklad.v(899)
  AL_PHY_MSLICE _al_u1542 (
    .a({open_n1180,oc_2B[6]}),
    .b({open_n1181,oc_2B[7]}),
    .c({open_n1182,oc_2B[8]}),
    .d({open_n1185,oc_2B[9]}),
    .f({open_n1199,_al_u1542_o}));
  AL_PHY_MSLICE \_al_u1544|_al_u1543  (
    .a({_al_u1543_o,oc_2B[0]}),
    .b({_al_u1542_o,oc_2B[11]}),
    .c(oc_2B[3:2]),
    .d({oc_2B[4],oc_2B[5]}),
    .f({_al_u1544_o,_al_u1543_o}));
  AL_PHY_LSLICE \_al_u1545|_al_u2123  (
    .a({oc_2B[12],oc_2B[15]}),
    .b({oc_2B[13],oc_2B[7]}),
    .c({oc_2B[14],mcu_state[0]}),
    .d({oc_2B[15],mcu_state[1]}),
    .f({n82,\mux104_b15/B1_2 }));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1546|rd_t_reg  (
    .a({_al_u1544_o,rd_t}),
    .b({n82,open_n1249}),
    .c({oc_2B[1],open_n1250}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({oc_2B[10],open_n1251}),
    .f({_al_u1546_o,open_n1269}),
    .q({open_n1273,rd_t}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1548|reg58_b10  (
    .a({open_n1274,o_adc2A_d[5]}),
    .b({ho_clr_req,o_adc2B_d[5]}),
    .c({io_mcu_data_pad[0],mcu_command[0]}),
    .ce(mux73_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({u536_sel_is_3_o,mcu_command[1]}),
    .mi({open_n1285,io_mcu_data_pad[2]}),
    .f({u538_sel_is_3_o,_al_u1945_o}),
    .q({open_n1290,time_base_set[10]}));  // zaklad.v(2867)
  AL_PHY_PAD _al_u155 (
    .otrue(o_relay2_2_pad),
    .opad(o_relay2_2));  // zaklad.v(900)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1553|dec_ch2/reg28_b33  (
    .b({_al_u1420_o,open_n1304}),
    .c({_al_u1441_o,_al_u806_o}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1413_o,\dec_ch2/n118_lutinv }),
    .f({n651_lutinv,open_n1318}),
    .q({open_n1322,\dec_ch2/sh [33]}));  // zaklad.v(277)
  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u1556|reg25_b1  (
    .a({open_n1323,_al_u1420_o}),
    .b({n515,mcu_command[2]}),
    .c({mcu_state[0],mcu_command[3]}),
    .ce(n179),
    .clk(clk_200MHz),
    .d({_al_u1555_o,mcu_state[3]}),
    .mi({open_n1334,sample_write_address[1]}),
    .f({_al_u1556_o,_al_u1948_o}),
    .q({open_n1339,p_wa[1]}));  // zaklad.v(1742)
  // zaklad.v(1838)
  AL_PHY_MSLICE \_al_u1557|trigger_mode_s1_reg  (
    .a({open_n1340,_al_u1552_o}),
    .b({open_n1341,_al_u1565_o}),
    .c({n651_lutinv,_al_u1413_o}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1556_o,mcu_command[2]}),
    .mi({open_n1353,trigger_mode}),
    .f({mux73_b16_sel_is_3_o,mux71_b10_sel_is_3_o}),
    .q({open_n1358,trigger_mode_s1}));  // zaklad.v(1838)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1559|gen_out_enable_reg  (
    .a({n651_lutinv,_al_u1445_o}),
    .b({_al_u1558_o,_al_u1415_o}),
    .c({sel65_b0_def_0_sel_is_0_o,_al_u1436_o}),
    .ce(u554_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n515,n515}),
    .mi({open_n1362,io_mcu_data_pad[0]}),
    .f({mux73_b10_sel_is_3_o,u554_sel_is_3_o}),
    .q({open_n1378,gen_out_enable}));  // zaklad.v(2867)
  AL_PHY_PAD _al_u156 (
    .otrue(o_relay2_3_pad),
    .opad(o_relay2_3));  // zaklad.v(901)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1560|ac_dc_2_reg  (
    .a({n651_lutinv,_al_u1420_o}),
    .b({_al_u671_o,sample_write_enable}),
    .c({sel65_b0_def_0_sel_is_0_o,mcu_command[3]}),
    .ce(u553_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n515,o_mcu_data[0]}),
    .mi({open_n1393,io_mcu_data_pad[0]}),
    .f({mux73_b0_sel_is_3_o,_al_u2152_o}),
    .q({open_n1409,o_ac_dc_2_pad}));  // zaklad.v(2867)
  // zaklad.v(2102)
  AL_PHY_LSLICE \_al_u1571|ho_ct_d_reg  (
    .a({open_n1410,ho_ct_d}),
    .b({_al_u1421_o,open_n1411}),
    .c({\lt21/o_1_lutinv ,open_n1412}),
    .clk(clk_200MHz),
    .d({_al_u1419_o,ho_ct_s[1]}),
    .mi({open_n1417,ho_ct_s[1]}),
    .f({n657_lutinv,n365}),
    .q({open_n1433,ho_ct_d}));  // zaklad.v(2102)
  AL_PHY_LSLICE \_al_u1577|_al_u2201  (
    .a({open_n1434,trig_src_ext}),
    .b({open_n1435,io_mcu_data_pad[2]}),
    .c({_al_u1434_o,io_mcu_data_pad[1]}),
    .d({_al_u1576_o,io_mcu_data_pad[0]}),
    .f({n664_lutinv,n602}));
  // zaklad.v(2102)
  AL_PHY_MSLICE \_al_u1583|reg48_b1  (
    .a({open_n1460,sampling_triggered}),
    .b({_al_u1415_o,n4[0]}),
    .c({_al_u1420_o,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({_al_u1434_o,n369[1]}),
    .f({n658_lutinv,open_n1474}),
    .q({open_n1478,ho_cnt[1]}));  // zaklad.v(2102)
  // zaklad.v(2774)
  AL_PHY_MSLICE \_al_u1587|reg50_b0  (
    .b({_al_u1441_o,open_n1481}),
    .c({_al_u1436_o,_al_u1436_o}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1440_o,_al_u1551_o}),
    .mi({open_n1493,sample_read_offset[0]}),
    .f({n687_lutinv,_al_u2030_o}),
    .q({open_n1498,sample_read_addr_n[0]}));  // zaklad.v(2774)
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u1588|reg25_b10  (
    .c({mcu_state[3],mcu_state[3]}),
    .ce(n179),
    .clk(clk_200MHz),
    .d({mcu_state[2],mcu_state[2]}),
    .mi({open_n1506,sample_write_address[10]}),
    .f({_al_u1588_o,sel65_b0_def_0_sel_is_0_o}),
    .q({open_n1522,p_wa[10]}));  // zaklad.v(1742)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1598|reg76_b1  (
    .b({_al_u1596_o,_al_u1434_o}),
    .c({mcu_command[3],n515}),
    .ce(mux91_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1552_o,_al_u1437_o}),
    .mi({open_n1535,io_mcu_data_pad[1]}),
    .f({mux98_b0_sel_is_3_o,u549_sel_is_3_o}),
    .q({open_n1540,trig_type[1]}));  // zaklad.v(2867)
  // zaklad.v(1376)
  AL_PHY_LSLICE \_al_u1599|reg8_b0  (
    .a({_al_u1552_o,open_n1541}),
    .b({_al_u1451_o,open_n1542}),
    .c({_al_u1440_o,n515}),
    .clk(clk_200MHz),
    .d({open_n1544,_al_u1551_o}),
    .mi({open_n1548,swc_rose}),
    .f({mux89_b10_sel_is_3_o,_al_u1552_o}),
    .q({open_n1564,cap_st[0]}));  // zaklad.v(1376)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1600|reg74_b3  (
    .a({open_n1565,n23}),
    .b({_al_u1451_o,n30}),
    .c({_al_u1440_o,n33}),
    .ce(mux89_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1556_o,n26}),
    .mi({open_n1576,\io_mcu_data_pad[3]_neg }),
    .f({mux89_b0_sel_is_3_o,_al_u1528_o}),
    .q({open_n1581,cap_sel_x[3]}));  // zaklad.v(2867)
  // zaklad.v(2102)
  AL_PHY_LSLICE \_al_u1601|reg47_b0  (
    .a({_al_u1552_o,open_n1582}),
    .b({_al_u1445_o,open_n1583}),
    .c({_al_u1414_o,_al_u1419_o}),
    .clk(clk_200MHz),
    .d({_al_u1426_o,_al_u1428_o}),
    .mi({open_n1588,ho_clr_t}),
    .f({mux82_b10_sel_is_3_o,n653_lutinv}),
    .q({open_n1604,ho_ct_s[0]}));  // zaklad.v(2102)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1695|reg74_b13  (
    .a({open_n1605,oc_1A[12]}),
    .b({_al_u1428_o,oc_1A[4]}),
    .c({_al_u1434_o,_al_u2065_o}),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1694_o,mcu_state[1]}),
    .mi({open_n1616,io_mcu_data_pad[5]}),
    .f({u550_sel_is_3_o,_al_u2066_o}),
    .q({open_n1621,cap_sel_x[13]}));  // zaklad.v(2867)
  // zaklad.v(1473)
  AL_PHY_LSLICE \_al_u1708|adc1_encA_reg  (
    .a({open_n1622,\display_brightness/lt0/less_6_11_inst/o_3_lutinv }),
    .b({ch1_offset[15],display_brigthness[10]}),
    .c({\channel1_dc_offset/count [15],display_brigthness[11]}),
    .clk(clk_ADCA),
    .d({_al_u1707_o,\display_brightness/count [10]}),
    .e({open_n1624,\display_brightness/count [11]}),
    .mi({open_n1626,enc_cur_n}),
    .f({_al_u1708_o,_al_u1741_o}),
    .q({open_n1642,adc1_encA}));  // zaklad.v(1473)
  // zaklad.v(694)
  AL_PHY_MSLICE \_al_u1711|u_sq/reg6_b1  (
    .a({_al_u1709_o,display_brigthness[10]}),
    .b({_al_u1710_o,display_brigthness[9]}),
    .c({ch1_offset[14],\display_brightness/count [10]}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [14],\display_brightness/count [9]}),
    .mi({open_n1653,pat_wr_f[1]}),
    .f({_al_u1711_o,_al_u1732_o}),
    .q({open_n1658,\u_sq/sh0 [1]}));  // zaklad.v(694)
  // zaklad.v(1350)
  AL_PHY_LSLICE \_al_u1718|reg4_b20  (
    .a({_al_u1716_o,\channel1_dc_offset/count [6]}),
    .b({_al_u1717_o,\channel1_dc_offset/count [7]}),
    .c({ch2_offset[8],\channel1_dc_offset/count [8]}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [8],\channel1_dc_offset/count [9]}),
    .mi({open_n1663,adc_d1[20]}),
    .f({_al_u1718_o,_al_u1396_o}),
    .q({open_n1679,adc_dd1[20]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \_al_u1719|reg2_b20  (
    .a({open_n1680,\channel2_dc_offset/lt0/o_3_lutinv }),
    .b({_al_u1718_o,ch2_offset[4]}),
    .c({\channel1_dc_offset/count [5],ch2_offset[5]}),
    .clk(clk_200MHz),
    .d({ch2_offset[5],\channel1_dc_offset/count [4]}),
    .e({open_n1682,\channel1_dc_offset/count [5]}),
    .mi({open_n1684,adc_q1[20]}),
    .f({_al_u1719_o,_al_u1725_o}),
    .q({open_n1700,adc_d1[20]}));  // zaklad.v(1350)
  AL_PHY_MSLICE _al_u1721 (
    .a({_al_u1720_o,_al_u1720_o}),
    .b({ch2_offset[8],ch2_offset[8]}),
    .c({ch2_offset[9],ch2_offset[9]}),
    .d({\channel1_dc_offset/count [8],\channel1_dc_offset/count [8]}),
    .mi({open_n1713,\channel1_dc_offset/count [9]}),
    .fx({open_n1718,\channel2_dc_offset/lt0/less_6_11_inst/o_3_lutinv }));
  AL_PHY_MSLICE _al_u1751 (
    .a({_al_u1750_o,_al_u1750_o}),
    .b({sample_rate_divider_eff[11],sample_rate_divider_eff[11]}),
    .c({sample_rate_divider_eff[10],sample_rate_divider_eff[10]}),
    .d({sample_rate_divider_eff[1],sample_rate_divider_eff[1]}),
    .mi({open_n1733,sample_rate_divider_eff[0]}),
    .fx({open_n1738,_al_u1751_o}));
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1752|reg86_b30  (
    .a({sample_rate_divider_eff[5],oc_2A[15]}),
    .b({sample_rate_divider_eff[4],oc_2A[7]}),
    .c({sample_rate_divider_eff[3],mcu_state[0]}),
    .ce(mux101_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_rate_divider_eff[2],mcu_state[1]}),
    .mi({open_n1751,io_mcu_data_pad[6]}),
    .f({_al_u1752_o,_al_u2119_o}),
    .q({open_n1756,pat_wr_n[30]}));  // zaklad.v(2867)
  // zaklad.v(1556)
  AL_PHY_LSLICE \_al_u1753|cap_full_reg  (
    .a({sample_rate_divider_eff[9],_al_u1753_o}),
    .b({sample_rate_divider_eff[8],_al_u1752_o}),
    .c({sample_rate_divider_eff[7],_al_u1751_o}),
    .clk(clk_200MHz),
    .d({sample_rate_divider_eff[6],_al_u1754_o}),
    .f({_al_u1753_o,n147}),
    .q({open_n1778,cap_full}));  // zaklad.v(1556)
  // zaklad.v(1551)
  AL_PHY_MSLICE \_al_u1754|sce_q_reg  (
    .a({sample_rate_divider_eff[15],open_n1779}),
    .b({sample_rate_divider_eff[14],n148}),
    .c({sample_rate_divider_eff[13],n147}),
    .clk(clk_200MHz),
    .d({sample_rate_divider_eff[12],sample_clock_enable}),
    .f({_al_u1754_o,open_n1794}),
    .q({open_n1798,sce_q}));  // zaklad.v(1551)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1760|fir_en_reg  (
    .a({_al_u1759_o,open_n1799}),
    .b({\dec_ch2/sh [43],open_n1800}),
    .c({\dec_ch2/sh [47],_al_u1421_o}),
    .ce(u555_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({peak_en,_al_u1414_o}),
    .mi({open_n1804,io_mcu_data_pad[0]}),
    .f({_al_u1760_o,_al_u1423_o}),
    .q({open_n1820,fir_en}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1762|trigger_mode_reg  (
    .a({_al_u1760_o,open_n1821}),
    .b({_al_u1761_o,open_n1822}),
    .c({\dec_ch2/sh [26],_al_u1426_o}),
    .ce(u545_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [44],_al_u1420_o}),
    .mi({open_n1833,io_mcu_data_pad[0]}),
    .f({_al_u1762_o,_al_u1428_o}),
    .q({open_n1838,trigger_mode}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1763|str_reg  (
    .a({\dec_ch2/sh [25],_al_u1565_o}),
    .b({\dec_ch2/sh [36],mcu_command[2]}),
    .c({\dec_ch2/sh [39],o_mcu_data[0]}),
    .ce(u560_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [41],sampling_triggered}),
    .mi({open_n1849,io_mcu_data_pad[0]}),
    .f({_al_u1763_o,_al_u2156_o}),
    .q({open_n1854,str}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1764|seq_raw_reg  (
    .c({\dec_ch2/sh [38],n651_lutinv}),
    .ce(u558_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [45],_al_u1552_o}),
    .mi({open_n1869,io_mcu_data_pad[3]}),
    .f({_al_u1764_o,mux73_b24_sel_is_3_o}),
    .q({open_n1874,seq_raw}));  // zaklad.v(2867)
  AL_PHY_LSLICE _al_u1766 (
    .c({open_n1879,\dec_ch2/sh [35]}),
    .d({open_n1882,\dec_ch2/sh [34]}),
    .f({open_n1900,_al_u1766_o}));
  // zaklad.v(2806)
  AL_PHY_LSLICE \_al_u1767|reg52_b3  (
    .b({\dec_ch2/sh [32],_al_u1764_o}),
    .c({_al_u1766_o,\dec_ch2/sh [28]}),
    .ce(n170),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [33],_al_u1763_o}),
    .mi({open_n1911,io_mcu_data_pad[3]}),
    .f({_al_u1767_o,_al_u1765_o}),
    .q({open_n1927,mcu_command[3]}));  // zaklad.v(2806)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1769|trigger_channel_reg  (
    .b({\dec_ch2/sh [21],dec_shift[1]}),
    .c({dec_shift[0],\dec_ch2/n228_lutinv }),
    .ce(u540_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [20],\dec_ch2/n226_lutinv }),
    .mi({open_n1940,io_mcu_data_pad[0]}),
    .f({\dec_ch2/n227_lutinv ,_al_u1778_o}),
    .q({open_n1945,trigger_channel}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1770|reg67_b14  (
    .b({\dec_ch2/sh [22],_al_u1790_o}),
    .c({dec_shift[0],dec_shift[2]}),
    .ce(mux82_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [21],_al_u1783_o}),
    .mi({open_n1958,io_mcu_data_pad[6]}),
    .f({\dec_ch2/n226_lutinv ,_al_u1838_o}),
    .q({open_n1963,trigger_level16[14]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1771|trig_pol_reg  (
    .b({\dec_ch2/n226_lutinv ,open_n1966}),
    .c({dec_shift[1],n515}),
    .ce(u543_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/n227_lutinv ,n653_lutinv}),
    .mi({open_n1977,io_mcu_data_pad[0]}),
    .f({_al_u1771_o,u543_sel_is_3_o}),
    .q({open_n1982,trig_pol}));  // zaklad.v(2867)
  AL_PHY_MSLICE _al_u1772 (
    .b({open_n1985,\dec_ch2/sh [28]}),
    .c({open_n1986,dec_shift[0]}),
    .d({open_n1989,\dec_ch2/sh [22]}),
    .f({open_n2003,_al_u1772_o}));
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1775|peak_en_reg  (
    .a({_al_u1773_o,open_n2009}),
    .b({_al_u1772_o,\dec_ch2/sh [30]}),
    .c({_al_u1771_o,dec_shift[0]}),
    .ce(u555_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1774_o,\dec_ch2/sh [23]}),
    .mi({open_n2020,io_mcu_data_pad[1]}),
    .f({_al_u1775_o,_al_u1773_o}),
    .q({open_n2025,peak_en}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1776|ho_clr_t_reg  (
    .a({open_n2026,ho_clr_t}),
    .c({\dec_ch2/sh [23],open_n2029}),
    .ce(u538_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1775_o,open_n2030}),
    .f({_al_u1776_o,open_n2048}),
    .q({open_n2052,ho_clr_t}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1777|reg67_b7  (
    .a({open_n2053,\dec_ch2/n231_lutinv }),
    .b({\dec_ch2/sh [20],\dec_ch2/n233_lutinv }),
    .c({dec_shift[0],_al_u1848_o}),
    .ce(mux82_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [19],dec_shift[2]}),
    .mi({open_n2057,io_mcu_data_pad[7]}),
    .f({\dec_ch2/n228_lutinv ,_al_u1849_o}),
    .q({open_n2073,trigger_level16[7]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1779|sample_system_reset_reg  (
    .b(\dec_ch2/sh [19:18]),
    .c({dec_shift[0],dec_shift[0]}),
    .ce(u536_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(\dec_ch2/sh [18:17]),
    .mi({open_n2079,io_mcu_data_pad[0]}),
    .f({\dec_ch2/n229_lutinv ,\dec_ch2/n230_lutinv }),
    .q({open_n2095,sample_system_reset}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1780|reg67_b10  (
    .b({\dec_ch2/sh [17],\dec_ch2/n234_lutinv }),
    .c({dec_shift[0],dec_shift[1]}),
    .ce(mux82_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [16],\dec_ch2/n232_lutinv }),
    .mi({open_n2101,io_mcu_data_pad[2]}),
    .f({\dec_ch2/n231_lutinv ,_al_u1790_o}),
    .q({open_n2117,trigger_level16[10]}));  // zaklad.v(2867)
  // zaklad.v(1596)
  AL_PHY_LSLICE \_al_u1781|reg17_b5  (
    .a({_al_u1778_o,\dec_ch2/n231_lutinv }),
    .b({\dec_ch2/n227_lutinv ,\dec_ch2/n233_lutinv }),
    .c({\dec_ch2/n229_lutinv ,dec_shift[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n231_lutinv ,dec_shift[2]}),
    .e({dec_shift[1],open_n2119}),
    .mi({open_n2121,dec_sv[4]}),
    .f({_al_u1781_o,_al_u1834_o}),
    .q({open_n2137,dec_sv[5]}));  // zaklad.v(1596)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1783|reg65_b0  (
    .a({open_n2138,_al_u1556_o}),
    .b({\dec_ch2/n230_lutinv ,_al_u1445_o}),
    .c({dec_shift[1],_al_u1414_o}),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/n228_lutinv ,_al_u1426_o}),
    .mi({open_n2149,io_mcu_data_pad[0]}),
    .f({_al_u1783_o,mux82_b0_sel_is_3_o}),
    .q({open_n2154,dec_order[0]}));  // zaklad.v(2867)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1785|dec_ch2/reg28_b1  (
    .a({open_n2155,\dec_ch2/n118_lutinv }),
    .b({\dec_ch2/sh [12],\dec_ch2/n143_lutinv }),
    .c({dec_shift[0],_al_u891_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/sh [11],dec_shift[4]}),
    .e({open_n2156,dec_shift[5]}),
    .f({\dec_ch2/n236_lutinv ,open_n2172}),
    .q({open_n2176,\dec_ch2/sh [1]}));  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1786|_al_u1808  (
    .b({\dec_ch2/sh [9],\dec_ch2/sh [7]}),
    .c({dec_shift[0],dec_shift[0]}),
    .d({\dec_ch2/sh [10],\dec_ch2/sh [6]}),
    .f({\dec_ch2/n238_lutinv ,\dec_ch2/n241_lutinv }));
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1787|dec_ch2/reg17_b11  (
    .b({\dec_ch2/n238_lutinv ,\dec_ch2/n239_lutinv }),
    .c({dec_shift[1],dec_shift[1]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n236_lutinv ,\dec_ch2/n237_lutinv }),
    .mi({open_n2211,\dec_ch2/pk3 [11]}),
    .f({_al_u1787_o,_al_u1796_o}),
    .q({open_n2216,\dec_ch2/pk4 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1792|dec_ch2/reg17_b10  (
    .b({\dec_ch2/pk4 [9],_al_u1856_o}),
    .c({open_n2219,dec_shift[2]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,_al_u1819_o}),
    .mi({open_n2230,\dec_ch2/pk3 [10]}),
    .f({_al_u1792_o,_al_u1857_o}),
    .q({open_n2235,\dec_ch2/pk4 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1794|dec_ch2/reg28_b16  (
    .a({open_n2236,\dec_ch2/n119_lutinv }),
    .b({\dec_ch2/sh [11],\dec_ch2/n144_lutinv }),
    .c({dec_shift[0],dec_shift[4]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/sh [10],dec_shift[5]}),
    .f({\dec_ch2/n237_lutinv ,open_n2254}),
    .q({open_n2258,\dec_ch2/sh [16]}));  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1795|_al_u1798  (
    .b({\dec_ch2/sh [9],\dec_ch2/sh [13]}),
    .c({dec_shift[0],dec_shift[0]}),
    .d({\dec_ch2/sh [8],\dec_ch2/sh [12]}),
    .f({\dec_ch2/n239_lutinv ,\dec_ch2/n235_lutinv }));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1799|reg58_b1  (
    .a({open_n2281,\dec_ch2/n236_lutinv }),
    .b({\dec_ch2/n235_lutinv ,\dec_ch2/n234_lutinv }),
    .c({dec_shift[1],dec_shift[1]}),
    .ce(mux73_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/n233_lutinv ,dec_shift[2]}),
    .mi({open_n2285,io_mcu_data_pad[1]}),
    .f({_al_u1799_o,_al_u1844_o}),
    .q({open_n2301,time_base_set[1]}));  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u1803|_al_u1788  (
    .b({\dec_ch2/sh [8],dec_shift[0]}),
    .c({dec_shift[0],\dec_ch2/sh [16]}),
    .d({\dec_ch2/sh [7],\dec_ch2/sh [15]}),
    .f({\dec_ch2/n240_lutinv ,\dec_ch2/n232_lutinv }));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1810|dec_ch2/reg22_b23  (
    .a({_al_u1809_o,open_n2324}),
    .b({\dec_ch2/n237_lutinv ,_al_u1819_o}),
    .c({\dec_ch2/n235_lutinv ,dec_shift[2]}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[1],_al_u1796_o}),
    .e({dec_shift[2],open_n2325}),
    .mi({open_n2327,\dec_ch2/n78 [23]}),
    .f({_al_u1810_o,_al_u1820_o}),
    .q({open_n2343,\dec_ch2/c1 [23]}));  // zaklad.v(277)
  // zaklad.v(1596)
  AL_PHY_LSLICE \_al_u1828|reg17_b4_hfnopt2_2  (
    .a({_al_u1809_o,open_n2344}),
    .b({\dec_ch2/n243_lutinv ,\dec_ch2/n243_lutinv }),
    .c({\dec_ch2/n245_lutinv ,dec_shift[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[1],\dec_ch2/n241_lutinv }),
    .e({dec_shift[2],open_n2346}),
    .mi({open_n2348,\dec_sv[3]_hfnopt2_4 }),
    .f({\dec_ch2/fine [2],_al_u1819_o}),
    .q({open_n2364,\dec_sv[4]_hfnopt2_2 }));  // zaklad.v(1596)
  AL_PHY_MSLICE _al_u1831 (
    .a({_al_u1778_o,_al_u1778_o}),
    .b({\dec_ch2/n230_lutinv ,\dec_ch2/n230_lutinv }),
    .c({\dec_ch2/n232_lutinv ,\dec_ch2/n232_lutinv }),
    .d({dec_shift[1],dec_shift[1]}),
    .mi({open_n2377,dec_shift[2]}),
    .fx({open_n2382,_al_u1831_o}));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1846|dec_ch2/reg29_b3  (
    .a({open_n2385,_al_u1768_o}),
    .b({open_n2386,_al_u1776_o}),
    .c({peak_en,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/pk4 [11],\dec_ch2/fine [3]}),
    .e({open_n2387,_al_u1825_o}),
    .f({_al_u1846_o,open_n2403}),
    .q({open_n2407,cic_out2[3]}));  // zaklad.v(277)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u1848|reg58_b2  (
    .a({\dec_ch2/n237_lutinv ,_al_u1804_o}),
    .b({\dec_ch2/n235_lutinv ,\dec_ch2/n236_lutinv }),
    .c({dec_shift[1],\dec_ch2/n234_lutinv }),
    .ce(mux73_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(dec_shift[2:1]),
    .e({open_n2408,dec_shift[2]}),
    .mi({open_n2410,io_mcu_data_pad[2]}),
    .f({_al_u1848_o,_al_u1805_o}),
    .q({open_n2426,time_base_set[2]}));  // zaklad.v(2867)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1853|dec_ch2/reg17_b9  (
    .b({_al_u1852_o,_al_u1814_o}),
    .c({dec_shift[2],dec_shift[2]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1814_o,_al_u1787_o}),
    .mi({open_n2439,\dec_ch2/pk3 [9]}),
    .f({_al_u1853_o,_al_u1815_o}),
    .q({open_n2444,\dec_ch2/pk4 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1856|dec_ch2/reg17_b14  (
    .a({\dec_ch2/n245_lutinv ,\dec_ch2/n244_lutinv }),
    .b({\dec_ch2/sh [0],\dec_ch2/sh [1]}),
    .c({\dec_ch2/sh [1],\dec_ch2/sh [2]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[0],dec_shift[0]}),
    .e({dec_shift[1],dec_shift[1]}),
    .mi({open_n2446,\dec_ch2/pk3 [14]}),
    .f({_al_u1856_o,_al_u1852_o}),
    .q({open_n2462,\dec_ch2/pk4 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1861|dec_ch2/reg29_b8  (
    .a({open_n2463,_al_u1768_o}),
    .b({\dec_ch1/sh [20],_al_u1776_o}),
    .c({dec_shift[0],_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [19],_al_u1800_o}),
    .e({open_n2464,_al_u1801_o}),
    .f({\dec_ch1/n228_lutinv ,open_n2480}),
    .q({open_n2484,cic_out2[8]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1862|dec_ch2/reg29_b10  (
    .a({open_n2485,_al_u1768_o}),
    .b({\dec_ch1/n228_lutinv ,_al_u1776_o}),
    .c({dec_shift[1],_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n230_lutinv ,_al_u1849_o}),
    .e({open_n2486,_al_u1850_o}),
    .f({_al_u1862_o,open_n2502}),
    .q({open_n2506,cic_out2[10]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1865|dec_ch2/reg2_b0  (
    .a({open_n2507,_al_u1865_o}),
    .b({\dec_ch1/n229_lutinv ,_al_u1862_o}),
    .c({dec_shift[1],_al_u1867_o}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n231_lutinv ,_al_u1869_o}),
    .mi({open_n2512,\dec_ch2/pb [0]}),
    .f({_al_u1865_o,_al_u1870_o}),
    .q({open_n2528,pair_e2[0]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1867|dec_ch1/reg28_b1  (
    .a({open_n2529,\dec_ch1/n118_lutinv }),
    .b({\dec_ch1/n228_lutinv ,\dec_ch1/n143_lutinv }),
    .c({dec_shift[1],_al_u979_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n226_lutinv ,dec_shift[4]}),
    .e({open_n2530,dec_shift[5]}),
    .f({_al_u1867_o,open_n2546}),
    .q({open_n2550,\dec_ch1/sh [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1872|dec_ch2/reg29_b0  (
    .a({open_n2551,_al_u1768_o}),
    .b({\dec_ch1/sh [14],_al_u1776_o}),
    .c({dec_shift[0],_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [13],_al_u1857_o}),
    .e({open_n2552,_al_u1858_o}),
    .f({\dec_ch1/n234_lutinv ,open_n2568}),
    .q({open_n2572,cic_out2[0]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1873|dec_ch2/reg9_b7  (
    .b({\dec_ch1/n232_lutinv ,\dec_ch1/n236_lutinv }),
    .c({dec_shift[1],dec_shift[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n234_lutinv ,\dec_ch1/n234_lutinv }),
    .mi({open_n2586,\dec_ch2/pmn [7]}),
    .f({_al_u1873_o,_al_u1900_o}),
    .q({open_n2591,\dec_ch2/pdn [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1880|dec_ch1/reg28_b9  (
    .a({open_n2592,\dec_ch1/n17_lutinv }),
    .b({open_n2593,\dec_ch1/c3 [41]}),
    .c({_al_u1878_o,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1879_o,dec_shift[4]}),
    .e({open_n2594,dec_shift[5]}),
    .f({_al_u1880_o,open_n2610}),
    .q({open_n2614,\dec_ch1/sh [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1881|dec_ch1/reg28_b32  (
    .c({\dec_ch1/sh [24],_al_u806_o}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [30],\dec_ch1/n119_lutinv }),
    .f({_al_u1881_o,open_n2632}),
    .q({open_n2636,\dec_ch1/sh [32]}));  // zaklad.v(277)
  AL_PHY_MSLICE _al_u1882 (
    .a({_al_u1881_o,_al_u1881_o}),
    .b({\dec_ch1/sh [35],\dec_ch1/sh [35]}),
    .c({\dec_ch1/sh [34],\dec_ch1/sh [34]}),
    .d({dec_shift[0],dec_shift[0]}),
    .mi({open_n2649,\dec_ch1/sh [22]}),
    .fx({open_n2654,_al_u1882_o}));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1883|dec_ch1/reg28_b36  (
    .a({\dec_ch1/sh [29],open_n2657}),
    .b({\dec_ch1/sh [31],open_n2658}),
    .c({\dec_ch1/sh [37],_al_u806_o}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [36],\dec_ch1/n115_lutinv }),
    .f({_al_u1883_o,open_n2676}),
    .q({open_n2680,\dec_ch1/sh [36]}));  // zaklad.v(277)
  AL_PHY_LSLICE _al_u1884 (
    .a({open_n2681,\dec_ch1/sh [23]}),
    .b({open_n2682,\dec_ch1/sh [25]}),
    .c({open_n2683,\dec_ch1/sh [26]}),
    .d({open_n2686,\dec_ch1/sh [27]}),
    .f({open_n2704,_al_u1884_o}));
  AL_PHY_MSLICE \_al_u1885|_al_u781  (
    .a({_al_u1882_o,open_n2710}),
    .b({_al_u1884_o,cic_out2[14]}),
    .c({_al_u1883_o,adc2B_w[6]}),
    .d({\dec_ch1/sh [33],_al_u745_o}),
    .f({_al_u1885_o,sample_dia[30]}));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1888|dec_ch1/reg28_b25  (
    .a({open_n2731,\dec_ch1/n126_lutinv }),
    .b({\dec_ch1/sh [47],\dec_ch1/c3 [41]}),
    .c({peak_en,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [46],dec_shift[4]}),
    .e({open_n2732,dec_shift[5]}),
    .f({_al_u1888_o,open_n2748}),
    .q({open_n2752,\dec_ch1/sh [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1890|dec_ch2/reg22_b38  (
    .a({_al_u1880_o,cic_out1[11]}),
    .b({_al_u1885_o,cic_out1[3]}),
    .c({_al_u1887_o,_al_u699_o}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1889_o,trigger_channel}),
    .mi({open_n2756,\dec_ch2/n78 [38]}),
    .f({_al_u1890_o,dec_trig_sample[11]}),
    .q({open_n2772,\dec_ch2/c1 [38]}));  // zaklad.v(277)
  AL_PHY_LSLICE _al_u1892 (
    .b({open_n2775,\dec_ch1/sh [15]}),
    .c({open_n2776,dec_shift[0]}),
    .d({open_n2779,\dec_ch1/sh [14]}),
    .f({open_n2797,\dec_ch1/n233_lutinv }));
  AL_PHY_LSLICE _al_u1895 (
    .b({open_n2805,\dec_ch1/sh [11]}),
    .c({open_n2806,dec_shift[0]}),
    .d({open_n2809,\dec_ch1/sh [10]}),
    .f({open_n2827,\dec_ch1/n237_lutinv }));
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1907|dec_ch2/reg16_b4  (
    .b({\dec_ch1/n241_lutinv ,\dec_ch1/sh [3]}),
    .c(dec_shift[1:0]),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n239_lutinv ,\dec_ch1/sh [2]}),
    .mi({open_n2838,\dec_ch2/pk2 [4]}),
    .f({_al_u1907_o,\dec_ch1/n245_lutinv }),
    .q({open_n2854,\dec_ch2/pk3 [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1908|dec_ch1/reg29_b3  (
    .a({_al_u1870_o,_al_u1918_o}),
    .b({_al_u1905_o,_al_u1890_o}),
    .c({_al_u1907_o,_al_u1920_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[2],\dec_ch1/pk4 [3]}),
    .e({open_n2855,peak_en}),
    .f({_al_u1908_o,open_n2871}),
    .q({open_n2875,cic_out1[3]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1910|dec_ch2/reg17_b15  (
    .b({\dec_ch1/sh [6],open_n2878}),
    .c({dec_shift[0],peak_en}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [5],\dec_ch2/pk4 [10]}),
    .mi({open_n2889,\dec_ch2/pk3 [15]}),
    .f({\dec_ch1/n242_lutinv ,_al_u1850_o}),
    .q({open_n2894,\dec_ch2/pk4 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1911|dec_ch2/reg16_b6  (
    .b({\dec_ch1/n242_lutinv ,\dec_ch1/sh [4]}),
    .c(dec_shift[1:0]),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n240_lutinv ,\dec_ch1/sh [3]}),
    .mi({open_n2900,\dec_ch2/pk2 [6]}),
    .f({_al_u1911_o,\dec_ch1/n244_lutinv }),
    .q({open_n2916,\dec_ch2/pk3 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1915|dec_ch1/reg17_b15  (
    .a({open_n2917,\dec_ch1/n245_lutinv }),
    .b({\dec_ch1/n243_lutinv ,\dec_ch1/sh [0]}),
    .c({dec_shift[1],\dec_ch1/sh [1]}),
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n241_lutinv ,dec_shift[0]}),
    .e({open_n2918,dec_shift[1]}),
    .mi({open_n2920,\dec_ch1/pk3 [15]}),
    .f({_al_u1915_o,_al_u1942_o}),
    .q({open_n2936,\dec_ch1/pk4 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1920|dec_ch2/reg15_b7  (
    .a({_al_u1902_o,open_n2937}),
    .b({\dec_ch1/n242_lutinv ,\dec_ch1/n239_lutinv }),
    .c({\dec_ch1/n244_lutinv ,dec_shift[1]}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[1],\dec_ch1/n237_lutinv }),
    .e({dec_shift[2],open_n2938}),
    .mi({open_n2940,\dec_ch2/pk1 [7]}),
    .f({_al_u1920_o,_al_u1897_o}),
    .q({open_n2956,\dec_ch2/pk2 [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1925|dec_ch2/reg2_b1  (
    .a({\dec_ch1/n232_lutinv ,open_n2957}),
    .b({open_n2958,\dec_ch1/sh [16]}),
    .c(dec_shift[1:0]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n230_lutinv ,\dec_ch1/sh [15]}),
    .mi({open_n2970,\dec_ch2/pb [1]}),
    .f({_al_u1925_o,\dec_ch1/n232_lutinv }),
    .q({open_n2975,pair_e2[1]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u1926|dec_ch1/reg28_b3  (
    .a({_al_u1870_o,\dec_ch1/n116_lutinv }),
    .b({_al_u1867_o,\dec_ch1/n141_lutinv }),
    .c({_al_u1925_o,_al_u975_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[2],dec_shift[4]}),
    .e({open_n2976,dec_shift[5]}),
    .f({_al_u1926_o,open_n2992}),
    .q({open_n2996,\dec_ch1/sh [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u1928|dec_ch2/reg10_b3  (
    .a({open_n2997,_al_u1870_o}),
    .b({\dec_ch1/n233_lutinv ,_al_u1873_o}),
    .c({dec_shift[1],_al_u1862_o}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n231_lutinv ,dec_shift[2]}),
    .mi({open_n3008,\dec_ch2/rmn [3]}),
    .f({_al_u1928_o,_al_u1931_o}),
    .q({open_n3013,\dec_ch2/pkw [3]}));  // zaklad.v(277)
  // zaklad.v(2075)
  AL_PHY_LSLICE \_al_u1946|ssr_d_reg  (
    .a({_al_u1945_o,_al_u2164_o}),
    .b({o_adc1A_d[5],_al_u2030_o}),
    .c({o_adc1B_d[5],_al_u1966_o}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1415_o,trig_type[0]}),
    .e({mcu_command[1],open_n3015}),
    .mi({open_n3017,sample_system_reset}),
    .f({_al_u1946_o,_al_u2165_o}),
    .q({open_n3033,ssr_d}));  // zaklad.v(2075)
  // zaklad.v(1819)
  AL_PHY_MSLICE \_al_u1950|sample_write_enable_reg  (
    .a({open_n3034,sample_write_enable}),
    .b({open_n3035,swc_adv}),
    .c({_al_u1555_o,n222_lutinv}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1428_o,sample_system_reset}),
    .f({_al_u1950_o,open_n3050}),
    .q({open_n3054,sample_write_enable}));  // zaklad.v(1819)
  AL_PHY_LSLICE _al_u1952 (
    .c({open_n3059,_al_u1555_o}),
    .d({open_n3062,_al_u1437_o}),
    .f({open_n3080,_al_u1952_o}));
  AL_PHY_LSLICE \_al_u1953|_al_u2130  (
    .a({_al_u1952_o,_al_u1555_o}),
    .b({trigger_address[5],trigger_address[1]}),
    .c({mcu_state[0],trigger_address[9]}),
    .d({o_mcu_data[5],mcu_state[0]}),
    .e({open_n3088,o_mcu_data[1]}),
    .f({_al_u1953_o,_al_u2130_o}));
  AL_PHY_MSLICE _al_u1954 (
    .a({open_n3109,_al_u1953_o}),
    .b({open_n3110,_al_u1951_o}),
    .c({open_n3111,mcu_command[4]}),
    .d({open_n3114,mcu_command[5]}),
    .f({open_n3128,_al_u1954_o}));
  AL_PHY_MSLICE _al_u1960 (
    .a({oc_1A[5],oc_1A[5]}),
    .b({mcu_state[0],mcu_state[0]}),
    .c({mcu_state[1],mcu_state[1]}),
    .d({cap_sel_x[13],cap_sel_x[13]}),
    .mi({open_n3146,cap_sel_x[5]}),
    .fx({open_n3151,_al_u1960_o}));
  AL_PHY_MSLICE \_al_u1961|_al_u2084  (
    .a({oc_2B[13],oc_2B[14]}),
    .b({oc_2B[5],oc_2B[6]}),
    .c({mcu_state[0],mcu_state[0]}),
    .d({mcu_state[1],mcu_state[1]}),
    .f({\mux104_b13/B1_2 ,\mux104_b14/B1_2 }));
  // zaklad.v(1527)
  AL_PHY_LSLICE \_al_u1964|reg15_b4  (
    .a({oc_1B[13],oc_1B[15]}),
    .b({oc_1B[5],oc_1B[7]}),
    .c({_al_u1963_o,_al_u2119_o}),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({open_n3178,n144[4]}),
    .sr(sample_clock_enable),
    .f({_al_u1964_o,_al_u2120_o}),
    .q({open_n3193,sample_rate_counter[4]}));  // zaklad.v(1527)
  AL_PHY_LSLICE \_al_u1972|_al_u1756  (
    .a({open_n3194,time_base_timeout}),
    .b({str_s,n227}),
    .c({sampling_triggered,str_s}),
    .d({n227,trigger_mode_s}),
    .e({open_n3197,sampling_triggered}),
    .f({_al_u1972_o,n222_lutinv}));
  AL_PHY_MSLICE _al_u1974 (
    .a({_al_u1972_o,_al_u1972_o}),
    .b({time_base_timeout,time_base_timeout}),
    .c({_al_u1973_o,_al_u1973_o}),
    .d({trigger_mode_s,trigger_mode_s}),
    .mi({open_n3230,sampling_triggered}),
    .fx({open_n3235,n358}));
  // zaklad.v(1215)
  AL_PHY_MSLICE \_al_u1975|reg0_b1  (
    .b({open_n3240,mcu_command[3]}),
    .c({sample_system_reset,o_mcu_data[0]}),
    .clk(clk_200MHz),
    .d({ssr_d,\sel66_b0_var/B1_1 }),
    .mi({open_n3252,ext_sync[0]}),
    .f({_al_u1975_o,_al_u2151_o}),
    .q({open_n3257,ext_sync[1]}));  // zaklad.v(1215)
  AL_PHY_LSLICE \_al_u2011|_al_u2102  (
    .c({_al_u1418_o,_al_u1436_o}),
    .d({_al_u1437_o,_al_u1555_o}),
    .f({_al_u2011_o,_al_u2102_o}));
  AL_PHY_MSLICE _al_u2012 (
    .a({_al_u1555_o,_al_u1555_o}),
    .b({trigger_address[10],trigger_address[10]}),
    .c({trigger_address[2],trigger_address[2]}),
    .d({mcu_state[0],mcu_state[0]}),
    .mi({open_n3298,o_mcu_data[2]}),
    .fx({open_n3303,_al_u2012_o}));
  AL_PHY_MSLICE \_al_u2013|_al_u2104  (
    .a({_al_u2010_o,_al_u2101_o}),
    .b({o_mcu_data[2],_al_u2103_o}),
    .c({_al_u2012_o,_al_u1426_o}),
    .d({_al_u2011_o,mcu_command[4]}),
    .f({_al_u2013_o,\sel66_b6_var/B4_0 }));
  // zaklad.v(1805)
  AL_PHY_MSLICE \_al_u2014|reg34_b28  (
    .a({_al_u1555_o,mcu_command[5]}),
    .b({mcu_state[0],mcu_command[7]}),
    .c({dec_shift[2],mcu_command[6]}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({o_mcu_data[2],mcu_command[4]}),
    .mi({open_n3336,n217[28]}),
    .sr(sample_system_reset),
    .f({_al_u2014_o,_al_u1413_o}),
    .q({open_n3340,time_base_cnt[28]}));  // zaklad.v(1805)
  // zaklad.v(2774)
  AL_PHY_LSLICE \_al_u2026|reg50_b8  (
    .a({mcu_state[0],_al_u1960_o}),
    .b({cap_sel_x[10],\mux104_b13/B1_2 }),
    .c({cap_sel_x[2],_al_u1558_o}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[1],oc_1A[13]}),
    .e({open_n3342,mcu_state[3]}),
    .mi({open_n3344,sample_read_offset[8]}),
    .f({_al_u2026_o,_al_u1962_o}),
    .q({open_n3360,sample_read_addr_n[8]}));  // zaklad.v(2774)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u2028|lc_t_reg  (
    .a({oc_2B[10],lc_t}),
    .b({oc_2B[2],open_n3361}),
    .c({mcu_state[0],open_n3362}),
    .ce(u561_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[1],open_n3363}),
    .f({\mux104_b10/B1_2 ,open_n3377}),
    .q({open_n3381,lc_t}));  // zaklad.v(2867)
  AL_PHY_LSLICE _al_u2037 (
    .a({open_n3382,oc_1A[11]}),
    .b({open_n3383,oc_1A[3]}),
    .c({open_n3384,_al_u2036_o}),
    .d({open_n3387,mcu_state[1]}),
    .f({open_n3405,_al_u2037_o}));
  AL_PHY_LSLICE \_al_u2038|_al_u2145  (
    .a({oc_2B[11],oc_2B[1]}),
    .b({oc_2B[3],oc_2B[9]}),
    .c({mcu_state[0],mcu_state[0]}),
    .d({mcu_state[1],mcu_state[1]}),
    .e({open_n3413,mcu_state[3]}),
    .f({\mux104_b11/B1_2 ,_al_u2145_o}));
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u2040|l_str_reg  (
    .a({_al_u2033_o,_al_u2029_o}),
    .b({_al_u2039_o,_al_u2030_o}),
    .c({_al_u1420_o,_al_u1966_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({_al_u1426_o,_al_u1420_o}),
    .e({open_n3434,trig_pw_long}),
    .mi({open_n3436,str_q[1]}),
    .f({_al_u2040_o,_al_u2031_o}),
    .q({open_n3452,l_str}));  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u2048|reg25_b8  (
    .a({o_adc2A_d[3],_al_u2174_o}),
    .b({o_adc2B_d[3],_al_u2176_o}),
    .c({mcu_command[0],_al_u2178_o}),
    .ce(n179),
    .clk(clk_200MHz),
    .d({mcu_command[1],sel65_b0_def_0_sel_is_0_o}),
    .e({open_n3453,mcu_command[0]}),
    .mi({open_n3455,sample_write_address[8]}),
    .f({_al_u2048_o,_al_u2179_o}),
    .q({open_n3471,p_wa[8]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2062|reg33_b4  (
    .a({sel63_b4_var_o_lutinv,l_occ[10]}),
    .b({_al_u1576_o,l_occ[2]}),
    .c({mcu_state[3],mcu_state[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({o_mcu_data[4],mcu_state[1]}),
    .mi({open_n3482,occ[4]}),
    .f({_al_u2062_o,_al_u2018_o}),
    .q({open_n3487,l_occ[4]}));  // zaklad.v(1742)
  // zaklad.v(1527)
  AL_PHY_LSLICE \_al_u2065|reg15_b0  (
    .a({mcu_state[0],open_n3488}),
    .b({cap_sel_x[12],open_n3489}),
    .c({cap_sel_x[4],n144[0]}),
    .clk(clk_200MHz),
    .d({mcu_state[1],sample_clock_enable}),
    .f({_al_u2065_o,open_n3508}),
    .q({open_n3512,sample_rate_counter[0]}));  // zaklad.v(1527)
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u2067|reg32_b16  (
    .a({oc_2B[12],_al_u2092_o}),
    .b({oc_2B[4],_al_u2093_o}),
    .c({mcu_state[0],mcu_state[2]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[3]}),
    .e({open_n3513,o_mcu_data[6]}),
    .mi({open_n3515,lg_hi[0]}),
    .f({\mux104_b12/B1_2 ,_al_u2094_o}),
    .q({open_n3531,l_cnt[16]}));  // zaklad.v(1742)
  // zaklad.v(2774)
  AL_PHY_LSLICE \_al_u2069|reg50_b4  (
    .a({open_n3532,_al_u2025_o}),
    .b({_al_u1966_o,_al_u2027_o}),
    .c({_al_u1420_o,\mux104_b10/B1_2 }),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u2068_o,mcu_state[2]}),
    .e({open_n3534,mcu_state[3]}),
    .mi({open_n3536,sample_read_offset[4]}),
    .f({_al_u2069_o,_al_u2029_o}),
    .q({open_n3552,sample_read_addr_n[4]}));  // zaklad.v(2774)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u2074|dec_ch2/reg28_b31  (
    .a({o_adc1A_d[4],\dec_ch2/n120_lutinv }),
    .b({o_adc1B_d[4],\dec_ch2/c3 [47]}),
    .c({_al_u2073_o,dec_shift[3]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({mcu_command[1],dec_shift[4]}),
    .e({open_n3553,dec_shift[5]}),
    .f({_al_u2074_o,open_n3569}),
    .q({open_n3573,\dec_ch2/sh [31]}));  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u2076|_al_u2110  (
    .a({_al_u2075_o,_al_u2010_o}),
    .b({_al_u1423_o,_al_u1555_o}),
    .c({_al_u1948_o,_al_u1948_o}),
    .d({o_mcu_data[4],mcu_command[4]}),
    .e({open_n3576,mcu_command[5]}),
    .f({_al_u2076_o,_al_u2110_o}));
  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2077|reg22_b0  (
    .a({_al_u2074_o,_al_u2010_o}),
    .b({_al_u2076_o,o_mcu_data[3]}),
    .c({_al_u1415_o,_al_u1439_o}),
    .clk(clk_200MHz),
    .d({_al_u1439_o,_al_u1426_o}),
    .mi({open_n3608,rd_t}),
    .f({_al_u2077_o,_al_u2054_o}),
    .q({open_n3613,rd_rq[0]}));  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2078|_al_u2075  (
    .a({_al_u1950_o,_al_u1555_o}),
    .b({mcu_command[4],mcu_state[0]}),
    .c({mcu_command[5],dec_shift[4]}),
    .d({o_mcu_data[4],o_mcu_data[4]}),
    .f({_al_u2078_o,_al_u2075_o}));
  AL_PHY_LSLICE _al_u2079 (
    .b({open_n3636,trigger_address[4]}),
    .c({open_n3637,mcu_state[0]}),
    .d({open_n3640,trigger_address[12]}),
    .f({open_n3658,_al_u2079_o}));
  AL_PHY_LSLICE \_al_u2080|_al_u2103  (
    .a({_al_u1952_o,_al_u2102_o}),
    .b({_al_u2079_o,trigger_address[6]}),
    .c({_al_u1418_o,mcu_state[0]}),
    .d({o_mcu_data[4],o_mcu_data[6]}),
    .f({_al_u2080_o,_al_u2103_o}));
  // zaklad.v(1486)
  AL_PHY_LSLICE \_al_u2087|swc_sh_reg  (
    .a({oc_1B[14],open_n3688}),
    .b({oc_1B[6],open_n3689}),
    .c({_al_u2086_o,sample_write_clock}),
    .clk(clk_200MHz),
    .d({mcu_state[1],sample_clock_enable}),
    .f({_al_u2087_o,open_n3708}),
    .q({open_n3712,swc_sh}));  // zaklad.v(1486)
  // zaklad.v(2102)
  AL_PHY_MSLICE \_al_u2089|ho_st_q_reg  (
    .a({_al_u1451_o,open_n3713}),
    .b({_al_u1966_o,_al_u1414_o}),
    .c({_al_u1426_o,_al_u1441_o}),
    .clk(clk_200MHz),
    .d({enc_ok[0],_al_u1413_o}),
    .mi({open_n3725,sampling_triggered}),
    .f({_al_u2089_o,n650_lutinv}),
    .q({open_n3730,ho_st_q}));  // zaklad.v(2102)
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u2092|reg32_b17  (
    .a({l_lap,_al_u2042_o}),
    .b({l_wa[6],_al_u2044_o}),
    .c({_al_u2091_o,mcu_state[2]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[3]}),
    .e({open_n3731,o_mcu_data[3]}),
    .mi({open_n3733,lg_hi[1]}),
    .f({_al_u2092_o,_al_u2045_o}),
    .q({open_n3749,l_cnt[17]}));  // zaklad.v(1742)
  AL_PHY_MSLICE _al_u2099 (
    .a({_al_u1423_o,_al_u1423_o}),
    .b({_al_u1555_o,_al_u1555_o}),
    .c({_al_u1948_o,_al_u1948_o}),
    .d({_al_u2098_o,_al_u2098_o}),
    .mi({open_n3762,o_mcu_data[6]}),
    .fx({open_n3767,_al_u2099_o}));
  AL_PHY_MSLICE \_al_u2101|_al_u1951  (
    .b({mcu_state[0],mcu_state[0]}),
    .c(o_mcu_data[6:5]),
    .d({_al_u1950_o,_al_u1950_o}),
    .f({_al_u2101_o,_al_u1951_o}));
  AL_PHY_LSLICE \_al_u2111|_al_u2055  (
    .a({_al_u2011_o,_al_u1555_o}),
    .b({_al_u1555_o,trigger_address[11]}),
    .c({trigger_address[7],trigger_address[3]}),
    .d({mcu_state[0],mcu_state[0]}),
    .e({open_n3794,o_mcu_data[3]}),
    .f({_al_u2111_o,_al_u2055_o}));
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u2114|reg31_b9  (
    .a({l_str,_al_u2114_o}),
    .b({l_wa[7],_al_u2115_o}),
    .c({_al_u2113_o,mcu_state[2]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[3]}),
    .e({open_n3815,o_mcu_data[7]}),
    .mi({open_n3817,lg_wa[9]}),
    .f({_al_u2114_o,_al_u2116_o}),
    .q({open_n3833,l_wa[9]}));  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2131|_al_u2010  (
    .a({_al_u2010_o,_al_u1950_o}),
    .b({_al_u2011_o,_al_u1437_o}),
    .c({_al_u2130_o,mcu_command[4]}),
    .d({o_mcu_data[1],mcu_command[5]}),
    .f({_al_u2131_o,_al_u2010_o}));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u2132|reg55_b12  (
    .a({_al_u1555_o,_al_u1454_o}),
    .b({mcu_state[0],dec_sv[6]}),
    .c({\dec_order[1]_hfnopt2_2 ,sample_write_enable}),
    .ce(mux70_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({dec_shift[1],dec_order[0]}),
    .e({o_mcu_data[1],sampling_triggered}),
    .mi({open_n3855,io_mcu_data_pad[4]}),
    .f({_al_u2132_o,n379}),
    .q({open_n3871,pretrigger_samples[12]}));  // zaklad.v(2867)
  // zaklad.v(1805)
  AL_PHY_LSLICE \_al_u2133|reg34_b31  (
    .a({_al_u2129_o,open_n3872}),
    .b({_al_u2131_o,peak_en}),
    .c({_al_u2132_o,mcu_state[0]}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1423_o,fir_en}),
    .e({_al_u1439_o,open_n3873}),
    .mi({open_n3875,n217[31]}),
    .sr(sample_system_reset),
    .f({_al_u2133_o,_al_u2098_o}),
    .q({open_n3890,time_base_cnt[31]}));  // zaklad.v(1805)
  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2143|reg24_b1  (
    .a({open_n3891,o_adc2A_d[1]}),
    .b({open_n3892,o_adc2B_d[1]}),
    .c({oc_1A[1],mcu_command[0]}),
    .clk(clk_200MHz),
    .d({_al_u671_o,mcu_command[1]}),
    .mi({open_n3904,l_rq[0]}),
    .f({_al_u2143_o,_al_u2127_o}),
    .q({open_n3909,l_rq[1]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \_al_u2146|reg24_b0  (
    .a({_al_u2143_o,_al_u2035_o}),
    .b({_al_u2144_o,_al_u2037_o}),
    .c({_al_u2145_o,\mux104_b11/B1_2 }),
    .clk(clk_200MHz),
    .d({_al_u1420_o,mcu_state[2]}),
    .e({sel65_b0_def_0_sel_is_0_o,mcu_state[3]}),
    .mi({open_n3912,l_req}),
    .f({_al_u2146_o,_al_u2039_o}),
    .q({open_n3928,l_rq[0]}));  // zaklad.v(1742)
  // zaklad.v(2145)
  AL_PHY_LSLICE \_al_u2154|reg49_b0  (
    .a({open_n3929,time_base_timeout}),
    .b({trigger_address[8],n396[0]}),
    .c({mcu_state[0],trigger_read_address[0]}),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_address[0],trigger_mode_s}),
    .sr(sample_system_reset),
    .f({sel67_b8_var_o_lutinv,open_n3946}),
    .q({open_n3950,trigger_address[0]}));  // zaklad.v(2145)
  AL_PHY_MSLICE _al_u2160 (
    .a({oc_2B[0],oc_2B[0]}),
    .b({oc_2B[8],oc_2B[8]}),
    .c({mcu_state[0],mcu_state[0]}),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({open_n3963,mcu_state[3]}),
    .fx({open_n3968,_al_u2160_o}));
  AL_PHY_MSLICE _al_u2161 (
    .a({_al_u2158_o,_al_u2158_o}),
    .b({_al_u2159_o,_al_u2159_o}),
    .c({_al_u2160_o,_al_u2160_o}),
    .d({_al_u1420_o,_al_u1420_o}),
    .mi({open_n3983,sel65_b0_def_0_sel_is_0_o}),
    .fx({open_n3988,_al_u2161_o}));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u2164|reg83_b3  (
    .a({_al_u2161_o,open_n3991}),
    .b({_al_u2163_o,open_n3992}),
    .c(mcu_state[2:1]),
    .ce(mux98_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[3],mcu_state[0]}),
    .mi({open_n3996,io_mcu_data_pad[3]}),
    .f({_al_u2164_o,_al_u1558_o}),
    .q({open_n4012,rd_hi[3]}));  // zaklad.v(2867)
  AL_PHY_MSLICE _al_u2166 (
    .a({_al_u2165_o,_al_u2165_o}),
    .b({\lt21/o_1_lutinv ,\lt21/o_1_lutinv }),
    .c({enc_err,enc_err}),
    .d({mcu_command[2],mcu_command[2]}),
    .mi({open_n4025,mcu_command[3]}),
    .fx({open_n4030,_al_u2166_o}));
  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2167|p_rst_reg  (
    .a({o_adc2A_d[0],_al_u1558_o}),
    .b({o_adc2B_d[0],_al_u1414_o}),
    .c({mcu_command[0],mcu_state[2]}),
    .clk(clk_200MHz),
    .d({mcu_command[1],mcu_state[3]}),
    .mi({open_n4044,ssr_d}),
    .f({_al_u2167_o,_al_u1966_o}),
    .q({open_n4049,p_rst}));  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \_al_u2168|p_wr_reg  (
    .a({o_adc1A_d[0],open_n4050}),
    .b({o_adc1B_d[0],swe_d}),
    .c({_al_u2167_o,cap_st[0]}),
    .clk(clk_200MHz),
    .d({mcu_command[1],adv_d}),
    .f({_al_u2168_o,open_n4065}),
    .q({open_n4069,p_wr}));  // zaklad.v(1742)
  AL_PHY_MSLICE _al_u2169 (
    .a({_al_u1555_o,_al_u1555_o}),
    .b({mcu_state[0],mcu_state[0]}),
    .c({dec_order[0],dec_order[0]}),
    .d({dec_shift[0],dec_shift[0]}),
    .mi({open_n4082,o_mcu_data[0]}),
    .fx({open_n4087,n841[0]}));
  // zaklad.v(1739)
  AL_PHY_LSLICE \_al_u2170|str_s_reg  (
    .a({n841[0],_al_u1555_o}),
    .b({ext_level,_al_u745_o}),
    .c({_al_u1576_o,peak_en}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1423_o,mcu_state[0]}),
    .e({open_n4091,o_mcu_data[7]}),
    .mi({open_n4093,str_q[1]}),
    .f({_al_u2170_o,n841[7]}),
    .q({open_n4109,str_s}));  // zaklad.v(1739)
  AL_PHY_LSLICE \_al_u2194|_al_u1442  (
    .a({swc_adv_q,_al_u1440_o}),
    .b({ext_pending,_al_u1414_o}),
    .c({sampling_triggered,_al_u1441_o}),
    .d({swc_rose,n515}),
    .f({_al_u2194_o,mux103_b0_sel_is_3_o}));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u2196|reg58_b18  (
    .c({_al_u1440_o,mcu_command[3]}),
    .ce(mux73_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1428_o,mcu_command[2]}),
    .mi({open_n4141,io_mcu_data_pad[2]}),
    .f({n682_lutinv,_al_u1426_o}),
    .q({open_n4157,time_base_set[18]}));  // zaklad.v(2867)
  // zaklad.v(1596)
  AL_PHY_LSLICE \_al_u2197|reg17_b4  (
    .a({n647_lutinv,open_n4158}),
    .b({n679_lutinv,open_n4159}),
    .c({n653_lutinv,\dec_ch2/sh [29]}),
    .clk(sample_write_clock_gclk_net),
    .d({n682_lutinv,\dec_ch2/sh [24]}),
    .mi({open_n4164,\dec_sv[3]_hfnopt2_4 }),
    .f({_al_u2197_o,_al_u1774_o}),
    .q({open_n4180,dec_sv[4]}));  // zaklad.v(1596)
  // zaklad.v(1215)
  AL_PHY_LSLICE \_al_u2203|ext_pending_reg  (
    .a({n657_lutinv,_al_u1370_o}),
    .b({n658_lutinv,\lt21/o_1_lutinv }),
    .c({n431_lutinv,enc_ok[0]}),
    .ce(n100),
    .clk(clk_200MHz),
    .d({i_mcu_rws_pad,mcu_command[2]}),
    .mi({open_n4184,1'b1}),
    .sr(sample_system_reset),
    .f({_al_u2203_o,_al_u2071_o}),
    .q({open_n4199,ext_pending}));  // zaklad.v(1215)
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u2204|trig_src_ext_reg  (
    .b({\lt21/o_1_lutinv ,_al_u1420_o}),
    .c({_al_u1441_o,_al_u1441_o}),
    .ce(u540_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1445_o,_al_u1445_o}),
    .mi({open_n4205,io_mcu_data_pad[1]}),
    .f({n680_lutinv,n679_lutinv}),
    .q({open_n4221,trig_src_ext}));  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u2207|reg58_b11  (
    .a({n648_lutinv,open_n4222}),
    .b({_al_u1413_o,_al_u1421_o}),
    .c({_al_u1441_o,\lt21/o_1_lutinv }),
    .ce(mux73_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_command[1],_al_u1413_o}),
    .mi({open_n4233,io_mcu_data_pad[3]}),
    .f({_al_u2207_o,n648_lutinv}),
    .q({open_n4238,time_base_set[11]}));  // zaklad.v(2867)
  // zaklad.v(2806)
  AL_PHY_LSLICE \_al_u2208|reg52_b0  (
    .a({_al_u2203_o,_al_u1451_o}),
    .b({_al_u2205_o,_al_u1440_o}),
    .c({_al_u2207_o,_al_u1445_o}),
    .ce(n170),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u2206_o,_al_u1414_o}),
    .e({open_n4239,_al_u1426_o}),
    .mi({open_n4241,io_mcu_data_pad[0]}),
    .f({_al_u2208_o,_al_u2206_o}),
    .q({open_n4257,mcu_command[0]}));  // zaklad.v(2806)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u2209|dec_ch2/reg28_b36  (
    .a({_al_u1423_o,open_n4258}),
    .b({_al_u1428_o,open_n4259}),
    .c({_al_u1434_o,_al_u806_o}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1413_o,\dec_ch2/n115_lutinv }),
    .f({_al_u2209_o,open_n4273}),
    .q({open_n4277,\dec_ch2/sh [36]}));  // zaklad.v(277)
  // zaklad.v(2064)
  AL_PHY_MSLICE \_al_u2210|sampling_half_way_reg  (
    .a({_al_u2209_o,sampling_half_way}),
    .b({_al_u1437_o,open_n4278}),
    .c({_al_u1434_o,open_n4279}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({i_mcu_rws_pad,n346}),
    .sr(sample_system_reset),
    .f({_al_u2210_o,open_n4292}),
    .q({open_n4296,sampling_half_way}));  // zaklad.v(2064)
  AL_PHY_MSLICE \_al_u2216|_al_u2213  (
    .a({_al_u2208_o,_al_u1445_o}),
    .b({_al_u2212_o,mcu_command[1]}),
    .c({_al_u2214_o,mcu_command[2]}),
    .d({_al_u2215_o,mcu_command[3]}),
    .f({n479,_al_u2213_o}));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u389|ac_dc_1_reg  (
    .a({open_n4317,adv_d}),
    .b({open_n4318,ssr_d}),
    .c({p_v,swe_d}),
    .ce(u549_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({p_rst,cap_st[0]}),
    .mi({open_n4322,io_mcu_data_pad[0]}),
    .f({n186,n179}),
    .q({open_n4338,o_ac_dc_1_pad}));  // zaklad.v(2867)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u480|dec_ch2/reg20_b27  (
    .c({dec_order[1],\dec_ch2/i3 [25]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [29],\dec_ch1/k3_lutinv }),
    .mi({open_n4354,\dec_ch2/n76 [27]}),
    .f({\dec_ch2/n71 [29],\dec_ch2/n74 [25]}),
    .q({open_n4359,\dec_ch2/i3 [27]}));  // zaklad.v(277)
  // zaklad.v(1350)
  AL_PHY_MSLICE \_al_u481|reg7_b23  (
    .b({open_n4362,adc_dd2[23]}),
    .c({dec_order[1],cap_sel_x[6]}),
    .clk(clk_200MHz),
    .d({\dec_ch2/i2 [28],adc_dd1[23]}),
    .mi({open_n4374,adc_dd2[23]}),
    .f({\dec_ch2/n71 [28],_al_u1290_o}),
    .q({open_n4379,adc_e2[23]}));  // zaklad.v(1350)
  AL_PHY_MSLICE \_al_u483|_al_u485  (
    .c({dec_order[1],dec_order[1]}),
    .d({\dec_ch2/i2 [26],\dec_ch2/i2 [24]}),
    .f({\dec_ch2/n71 [26],\dec_ch2/n71 [24]}));
  AL_PHY_MSLICE _al_u484 (
    .c({open_n4408,dec_order[1]}),
    .d({open_n4411,\dec_ch2/i2 [25]}),
    .f({open_n4425,\dec_ch2/n71 [25]}));
  AL_PHY_LSLICE \_al_u487|_al_u489  (
    .c({dec_order[1],dec_order[1]}),
    .d({\dec_ch2/i2 [22],\dec_ch2/i2 [20]}),
    .f({\dec_ch2/n71 [22],\dec_ch2/n71 [20]}));
  AL_PHY_LSLICE \_al_u488|_al_u491  (
    .c({dec_order[1],dec_order[1]}),
    .d({\dec_ch2/i2 [21],\dec_ch2/i2 [19]}),
    .f({\dec_ch2/n71 [21],\dec_ch2/n71 [19]}));
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u501|dec_ch2/reg19_b0  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [1],\dec_ch2/i2 [2]}),
    .mi({open_n4502,\dec_ch2/n73 [0]}),
    .f({\dec_ch2/n71 [1],\dec_ch2/n71 [2]}),
    .q({open_n4507,\dec_ch2/i2 [0]}));  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u502|_al_u1125  (
    .c({dec_order[1],\dec_ch2/i3 [0]}),
    .d({\dec_ch2/i2 [0],\dec_ch1/k3_lutinv }),
    .f({\dec_ch2/n71 [0],\dec_ch2/n74 [0]}));
  // zaklad.v(2867)
  AL_PHY_LSLICE \_al_u600|reg61_b6  (
    .a({open_n4532,n324[6]}),
    .b({n324[0],n325[6]}),
    .c({n325[0],open_n4533}),
    .ce(mux76_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n323,n323}),
    .mi({open_n4537,io_mcu_data_pad[6]}),
    .f({n326[0],n326[6]}),
    .q({open_n4553,trig_holdoff[6]}));  // zaklad.v(2867)
  // zaklad.v(1898)
  AL_PHY_LSLICE \_al_u602|sampling_triggered_reg  (
    .a({open_n4554,_al_u2190_o}),
    .b({n324[2],_al_u2191_o}),
    .c({n325[2],n255}),
    .ce(trigger_check_enable),
    .clk(clk_200MHz),
    .d({n323,n251}),
    .e({open_n4555,_al_u2194_o}),
    .sr(sample_system_reset),
    .f({n326[2],open_n4570}),
    .q({open_n4574,sampling_triggered}));  // zaklad.v(1898)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u625|dec_ch2/reg21_b31  (
    .b({n314[1],open_n4577}),
    .c({n313[1],dec_order[1]}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({n312,\dec_ch2/i2 [39]}),
    .mi({open_n4581,\dec_ch2/i3 [31]}),
    .f({n315[1],\dec_ch2/n71 [39]}),
    .q({open_n4597,\dec_ch2/d0 [31]}));  // zaklad.v(277)
  // zaklad.v(1388)
  AL_PHY_LSLICE \_al_u626|reg12_b5  (
    .b({n314[2],open_n4600}),
    .c({n313[2],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({n312,\dec_ch2/i2 [45]}),
    .mi({open_n4605,cap_h[21]}),
    .f({n315[2],\dec_ch2/n71 [45]}),
    .q({open_n4621,adc2A_w[5]}));  // zaklad.v(1388)
  // zaklad.v(277)
  AL_PHY_MSLICE \_al_u686|dec_ch2/reg2_b6  (
    .b({open_n4624,dec_order[0]}),
    .c({trigger_edge,\dec_order[1]_hfnopt2_4 }),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,peak_en}),
    .mi({open_n4636,\dec_ch2/pb [6]}),
    .f({mux9_b10_sel_is_3_o,_al_u745_o}),
    .q({open_n4641,pair_e2[6]}));  // zaklad.v(277)
  // zaklad.v(2867)
  AL_PHY_MSLICE \_al_u754|reg86_b24  (
    .a({open_n4642,oc_2A[11]}),
    .b({open_n4643,oc_2A[3]}),
    .c({sample_rate_divider[19],mcu_state[0]}),
    .ce(mux101_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u745_o,mcu_state[1]}),
    .mi({open_n4654,io_mcu_data_pad[0]}),
    .f({sample_rate_divider_eff[19],_al_u2034_o}),
    .q({open_n4659,pat_wr_n[24]}));  // zaklad.v(2867)
  // zaklad.v(1461)
  AL_PHY_MSLICE \_al_u783|enc_cur_reg  (
    .a({open_n4660,trig_holdoff[4]}),
    .b({cic_out2[13],trig_holdoff[5]}),
    .c({adc2B_w[5],trig_holdoff[6]}),
    .clk(clk_200MHz),
    .d({_al_u745_o,trig_holdoff[7]}),
    .mi({open_n4672,enc_nxt}),
    .f({sample_dia[29],_al_u400_o}),
    .q({open_n4677,enc_cur}));  // zaklad.v(1461)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u786|dec_ch1/reg28_b7  (
    .a({open_n4678,\dec_ch1/n112_lutinv }),
    .b({cic_out2[10],\dec_ch1/n137_lutinv }),
    .c({adc2B_w[2],_al_u967_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,dec_shift[4]}),
    .e({open_n4679,dec_shift[5]}),
    .f({sample_dia[26],open_n4695}),
    .q({open_n4699,\dec_ch1/sh [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \_al_u788|dec_ch2/reg23_b47  (
    .a({open_n4700,_al_u1886_o}),
    .b({cic_out2[8],\dec_ch1/sh [42]}),
    .c({adc2B_w[0],\dec_ch1/sh [45]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,\dec_ch1/sh [44]}),
    .e({open_n4701,\dec_ch1/sh [43]}),
    .mi({open_n4703,\dec_ch2/d0 [47]}),
    .f({sample_dia[24],_al_u1887_o}),
    .q({open_n4719,\dec_ch2/d0p [47]}));  // zaklad.v(277)
  AL_PHY_MSLICE adc1_encB_reg (
    .b({open_n4722,n324[1]}),
    .c({open_n4723,n325[1]}),
    .clk(clk_ADCB),
    .d({open_n4725,n323}),
    .mi({open_n4736,enc_cur}),
    .f({open_n4738,n326[1]}),
    .q({open_n4742,adc1_encB}));  // zaklad.v(1467)
  AL_PHY_PAD \adc_iddr[0]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[0]),
    .rst(1'b0),
    .icomp(adc_q2[0]),
    .itrue(adc_q1[0]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[10]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[2]),
    .rst(1'b0),
    .icomp(adc_q2[10]),
    .itrue(adc_q1[10]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[11]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[3]),
    .rst(1'b0),
    .icomp(adc_q2[11]),
    .itrue(adc_q1[11]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[12]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[4]),
    .rst(1'b0),
    .icomp(adc_q2[12]),
    .itrue(adc_q1[12]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[13]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[5]),
    .rst(1'b0),
    .icomp(adc_q2[13]),
    .itrue(adc_q1[13]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[14]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[6]),
    .rst(1'b0),
    .icomp(adc_q2[14]),
    .itrue(adc_q1[14]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[15]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[7]),
    .rst(1'b0),
    .icomp(adc_q2[15]),
    .itrue(adc_q1[15]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[16]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[0]),
    .rst(1'b0),
    .icomp(adc_q2[16]),
    .itrue(adc_q1[16]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[17]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[1]),
    .rst(1'b0),
    .icomp(adc_q2[17]),
    .itrue(adc_q1[17]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[18]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[2]),
    .rst(1'b0),
    .icomp(adc_q2[18]),
    .itrue(adc_q1[18]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[19]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[3]),
    .rst(1'b0),
    .icomp(adc_q2[19]),
    .itrue(adc_q1[19]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[1]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[1]),
    .rst(1'b0),
    .icomp(adc_q2[1]),
    .itrue(adc_q1[1]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[20]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[4]),
    .rst(1'b0),
    .icomp(adc_q2[20]),
    .itrue(adc_q1[20]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[21]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[5]),
    .rst(1'b0),
    .icomp(adc_q2[21]),
    .itrue(adc_q1[21]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[22]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[6]),
    .rst(1'b0),
    .icomp(adc_q2[22]),
    .itrue(adc_q1[22]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[23]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2A_d[7]),
    .rst(1'b0),
    .icomp(adc_q2[23]),
    .itrue(adc_q1[23]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[24]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[0]),
    .rst(1'b0),
    .icomp(adc_q2[24]),
    .itrue(adc_q1[24]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[25]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[1]),
    .rst(1'b0),
    .icomp(adc_q2[25]),
    .itrue(adc_q1[25]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[26]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[2]),
    .rst(1'b0),
    .icomp(adc_q2[26]),
    .itrue(adc_q1[26]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[27]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[3]),
    .rst(1'b0),
    .icomp(adc_q2[27]),
    .itrue(adc_q1[27]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[28]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[4]),
    .rst(1'b0),
    .icomp(adc_q2[28]),
    .itrue(adc_q1[28]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[29]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[5]),
    .rst(1'b0),
    .icomp(adc_q2[29]),
    .itrue(adc_q1[29]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[2]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[2]),
    .rst(1'b0),
    .icomp(adc_q2[2]),
    .itrue(adc_q1[2]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[30]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[6]),
    .rst(1'b0),
    .icomp(adc_q2[30]),
    .itrue(adc_q1[30]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[31]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc2B_d[7]),
    .rst(1'b0),
    .icomp(adc_q2[31]),
    .itrue(adc_q1[31]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[3]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[3]),
    .rst(1'b0),
    .icomp(adc_q2[3]),
    .itrue(adc_q1[3]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[4]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[4]),
    .rst(1'b0),
    .icomp(adc_q2[4]),
    .itrue(adc_q1[4]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[5]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[5]),
    .rst(1'b0),
    .icomp(adc_q2[5]),
    .itrue(adc_q1[5]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[6]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[6]),
    .rst(1'b0),
    .icomp(adc_q2[6]),
    .itrue(adc_q1[6]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[7]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1A_d[7]),
    .rst(1'b0),
    .icomp(adc_q2[7]),
    .itrue(adc_q1[7]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[8]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[0]),
    .rst(1'b0),
    .icomp(adc_q2[8]),
    .itrue(adc_q1[8]));  // al3_io.v(7)
  AL_PHY_PAD \adc_iddr[9]$iddr/u_iddr_IN  (
    .clk(clk_200MHz),
    .ipad(i_adc1B_d[1]),
    .rst(1'b0),
    .icomp(adc_q2[9]),
    .itrue(adc_q1[9]));  // al3_io.v(7)
  AL_PHY_LSLICE \add0/u11_al_u2442  (
    .a({sample_rate_counter[13],sample_rate_counter[11]}),
    .b({sample_rate_counter[14],sample_rate_counter[12]}),
    .c(2'b00),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\add0/c11 ),
    .mi(n144[18:17]),
    .sr(sample_clock_enable),
    .f({n144[13],n144[11]}),
    .fco(\add0/c15 ),
    .fx({n144[14],n144[12]}),
    .q(sample_rate_counter[18:17]));
  AL_PHY_LSLICE \add0/u15_al_u2443  (
    .a({sample_rate_counter[17],sample_rate_counter[15]}),
    .b({sample_rate_counter[18],sample_rate_counter[16]}),
    .c(2'b00),
    .ce(u546_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add0/c15 ),
    .mi({open_n5011,n556}),
    .f({n144[17],n144[15]}),
    .fco(\add0/c19 ),
    .fx({n144[18],n144[16]}),
    .q({open_n5024,o_relay1_2_pad}));
  AL_PHY_LSLICE \add0/u19_al_u2444  (
    .a({open_n5025,sample_rate_counter[19]}),
    .c(2'b00),
    .clk(clk_200MHz),
    .d({open_n5029,1'b0}),
    .fci(\add0/c19 ),
    .mi({n144[19],n144[16]}),
    .sr(sample_clock_enable),
    .f({open_n5043,n144[19]}),
    .q({sample_rate_counter[19],sample_rate_counter[16]}));
  AL_PHY_LSLICE \add0/u3_al_u2440  (
    .a({sample_rate_counter[5],sample_rate_counter[3]}),
    .b({sample_rate_counter[6],sample_rate_counter[4]}),
    .c(2'b00),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\add0/c3 ),
    .mi(n144[9:8]),
    .sr(sample_clock_enable),
    .f({n144[5],n144[3]}),
    .fco(\add0/c7 ),
    .fx({n144[6],n144[4]}),
    .q(sample_rate_counter[9:8]));
  AL_PHY_LSLICE \add0/u7_al_u2441  (
    .a({sample_rate_counter[9],sample_rate_counter[7]}),
    .b({sample_rate_counter[10],sample_rate_counter[8]}),
    .c(2'b00),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\add0/c7 ),
    .mi({n144[7],n144[15]}),
    .sr(sample_clock_enable),
    .f({n144[9],n144[7]}),
    .fco(\add0/c11 ),
    .fx({n144[10],n144[8]}),
    .q({sample_rate_counter[7],sample_rate_counter[15]}));
  AL_PHY_LSLICE \add0/ucin_al_u2439  (
    .a({sample_rate_counter[1],1'b0}),
    .b({sample_rate_counter[2],sample_rate_counter[0]}),
    .c(2'b00),
    .clk(clk_200MHz),
    .d(2'b01),
    .e(2'b01),
    .mi(n144[6:5]),
    .sr(sample_clock_enable),
    .f({n144[1],open_n5084}),
    .fco(\add0/c3 ),
    .fx({n144[2],n144[0]}),
    .q(sample_rate_counter[6:5]));
  AL_PHY_MSLICE \add12/u0|add12/ucin  (
    .a({trigger_read_address[0],1'b0}),
    .b({1'b1,open_n5085}),
    .f({n360[0],open_n5105}),
    .fco(\add12/c1 ));
  AL_PHY_MSLICE \add12/u10|add12/u9  (
    .a(trigger_read_address[10:9]),
    .b(2'b00),
    .fci(\add12/c9 ),
    .f(n360[10:9]),
    .fco(\add12/c11 ));
  AL_PHY_MSLICE \add12/u12|add12/u11  (
    .a(trigger_read_address[12:11]),
    .b(2'b00),
    .fci(\add12/c11 ),
    .f(n360[12:11]));
  AL_PHY_MSLICE \add12/u2|add12/u1  (
    .a(trigger_read_address[2:1]),
    .b(2'b00),
    .fci(\add12/c1 ),
    .f(n360[2:1]),
    .fco(\add12/c3 ));
  AL_PHY_MSLICE \add12/u4|add12/u3  (
    .a(trigger_read_address[4:3]),
    .b(2'b00),
    .fci(\add12/c3 ),
    .f(n360[4:3]),
    .fco(\add12/c5 ));
  AL_PHY_MSLICE \add12/u6|add12/u5  (
    .a(trigger_read_address[6:5]),
    .b(2'b00),
    .fci(\add12/c5 ),
    .f(n360[6:5]),
    .fco(\add12/c7 ));
  AL_PHY_MSLICE \add12/u8|add12/u7  (
    .a(trigger_read_address[8:7]),
    .b(2'b00),
    .fci(\add12/c7 ),
    .f(n360[8:7]),
    .fco(\add12/c9 ));
  AL_PHY_MSLICE \add15/u0|add15/ucin  (
    .a({sample_read_offset[0],1'b0}),
    .b({1'b1,open_n5243}),
    .clk(clk_200MHz),
    .mi({p_wa[7],l_rq[1]}),
    .f({n501[0],open_n5260}),
    .fco(\add15/c1 ),
    .q({lg_wa[7],l_rq[2]}));
  AL_PHY_MSLICE \add15/u10|add15/u9  (
    .a(sample_read_offset[10:9]),
    .b(2'b00),
    .fci(\add15/c9 ),
    .f(n501[10:9]),
    .fco(\add15/c11 ));
  AL_PHY_MSLICE \add15/u12|add15/u11  (
    .a(sample_read_offset[12:11]),
    .b(2'b00),
    .fci(\add15/c11 ),
    .f(n501[12:11]));
  AL_PHY_MSLICE \add15/u2|add15/u1  (
    .a(sample_read_offset[2:1]),
    .b(2'b00),
    .clk(clk_200MHz),
    .fci(\add15/c1 ),
    .mi({p_wa[9],p_wa[10]}),
    .f(n501[2:1]),
    .fco(\add15/c3 ),
    .q({lg_wa[9],lg_wa[10]}));
  AL_PHY_MSLICE \add15/u4|add15/u3  (
    .a(sample_read_offset[4:3]),
    .b(2'b00),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\add15/c3 ),
    .mi(sample_read_offset[12:11]),
    .f(n501[4:3]),
    .fco(\add15/c5 ),
    .q(sample_read_addr_n[12:11]));
  AL_PHY_MSLICE \add15/u6|add15/u5  (
    .a(sample_read_offset[6:5]),
    .b(2'b00),
    .fci(\add15/c5 ),
    .f(n501[6:5]),
    .fco(\add15/c7 ));
  AL_PHY_MSLICE \add15/u8|add15/u7  (
    .a(sample_read_offset[8:7]),
    .b(2'b00),
    .fci(\add15/c7 ),
    .f(n501[8:7]),
    .fco(\add15/c9 ));
  AL_PHY_MSLICE \add5/u0|add5/ucin  (
    .a({occ[0],1'b0}),
    .b({1'b1,open_n5386}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .mi({open_n5401,lap}),
    .f({n196[0],open_n5403}),
    .fco(\add5/c1 ),
    .q({open_n5406,l_lap}));
  AL_PHY_MSLICE \add5/u10|add5/u9  (
    .a(occ[10:9]),
    .b(2'b00),
    .clk(clk_200MHz),
    .fci(\add5/c9 ),
    .mi({open_n5421,p_wa[6]}),
    .f(n196[10:9]),
    .fco(\add5/c11 ),
    .q({open_n5425,lg_wa[6]}));
  AL_PHY_MSLICE \add5/u12|add5/u11  (
    .a(occ[12:11]),
    .b(2'b00),
    .ce(l_cp),
    .clk(clk_200MHz),
    .fci(\add5/c11 ),
    .mi({occ[9],occ[5]}),
    .f(n196[12:11]),
    .fco(\add5/c13 ),
    .q({l_occ[9],l_occ[5]}));
  AL_PHY_MSLICE \add5/u2|add5/u1  (
    .a(occ[2:1]),
    .b(2'b00),
    .ce(l_cp),
    .clk(clk_200MHz),
    .fci(\add5/c1 ),
    .mi(lg_wa[2:1]),
    .f(n196[2:1]),
    .fco(\add5/c3 ),
    .q(l_wa[2:1]));
  AL_PHY_MSLICE \add5/u4|add5/u3  (
    .a(occ[4:3]),
    .b(2'b00),
    .ce(n206),
    .clk(clk_200MHz),
    .fci(\add5/c3 ),
    .mi({open_n5471,1'b1}),
    .sr(n202),
    .f(n196[4:3]),
    .fco(\add5/c5 ),
    .q({open_n5474,lap}));
  AL_PHY_MSLICE \add5/u6|add5/u5  (
    .a(occ[6:5]),
    .b(2'b00),
    .clk(clk_200MHz),
    .fci(\add5/c5 ),
    .mi(p_wa[4:3]),
    .f(n196[6:5]),
    .fco(\add5/c7 ),
    .q(lg_wa[4:3]));
  AL_PHY_MSLICE \add5/u8|add5/u7  (
    .a(occ[8:7]),
    .b(2'b00),
    .ce(l_cp),
    .clk(clk_200MHz),
    .fci(\add5/c7 ),
    .mi({open_n5505,lg_wa[6]}),
    .f(n196[8:7]),
    .fco(\add5/c9 ),
    .q({open_n5509,l_wa[6]}));
  AL_PHY_LSLICE \add6/u11_al_u2424  (
    .a({time_base_cnt[13],sample_write_address[11]}),
    .b({time_base_cnt[14],sample_write_address[12]}),
    .c(2'b00),
    .ce(mux70_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c11 ),
    .mi({io_mcu_data_pad[1],io_mcu_data_pad[2]}),
    .f({n217[13],open_n5522}),
    .fco(\add6/c15 ),
    .fx({n217[14],open_n5523}),
    .q({pretrigger_samples[9],pretrigger_samples[10]}));
  AL_PHY_LSLICE \add6/u15_al_u2425  (
    .a({time_base_cnt[17],time_base_cnt[15]}),
    .b({time_base_cnt[18],time_base_cnt[16]}),
    .c(2'b00),
    .ce(mux70_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c15 ),
    .mi({open_n5524,io_mcu_data_pad[3]}),
    .f({n217[17],n217[15]}),
    .fco(\add6/c19 ),
    .fx({n217[18],n217[16]}),
    .q({open_n5537,pretrigger_samples[11]}));
  AL_PHY_LSLICE \add6/u19_al_u2426  (
    .a({time_base_cnt[21],time_base_cnt[19]}),
    .b({time_base_cnt[22],time_base_cnt[20]}),
    .c(2'b00),
    .ce(mux73_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c19 ),
    .mi({open_n5538,io_mcu_data_pad[7]}),
    .f({n217[21],n217[19]}),
    .fco(\add6/c23 ),
    .fx({n217[22],n217[20]}),
    .q({open_n5551,time_base_set[23]}));
  AL_PHY_LSLICE \add6/u23_al_u2427  (
    .a({time_base_cnt[25],time_base_cnt[23]}),
    .b({time_base_cnt[26],time_base_cnt[24]}),
    .c(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c23 ),
    .mi({open_n5552,n217[26]}),
    .sr(sample_system_reset),
    .f({n217[25],n217[23]}),
    .fco(\add6/c27 ),
    .fx({n217[26],n217[24]}),
    .q({open_n5564,time_base_cnt[26]}));
  AL_PHY_LSLICE \add6/u27_al_u2428  (
    .a({time_base_cnt[29],time_base_cnt[27]}),
    .b({time_base_cnt[30],time_base_cnt[28]}),
    .c(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c27 ),
    .mi(n217[30:29]),
    .sr(sample_system_reset),
    .f({n217[29],n217[27]}),
    .fco(\add6/c31 ),
    .fx({n217[30],n217[28]}),
    .q(time_base_cnt[30:29]));
  AL_PHY_LSLICE \add6/u31_al_u2429  (
    .a({open_n5576,time_base_cnt[31]}),
    .c(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({open_n5579,1'b0}),
    .fci(\add6/c31 ),
    .mi({open_n5582,n217[27]}),
    .sr(sample_system_reset),
    .f({open_n5594,n217[31]}),
    .q({open_n5598,time_base_cnt[27]}));
  AL_PHY_LSLICE \add6/u3_al_u2422  (
    .a({sample_write_address[5],sample_write_address[3]}),
    .b({sample_write_address[6],sample_write_address[4]}),
    .c(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c3 ),
    .mi(n217[14:13]),
    .sr(sample_system_reset),
    .fco(\add6/c7 ),
    .q(time_base_cnt[14:13]));
  AL_PHY_LSLICE \add6/u7_al_u2423  (
    .a({sample_write_address[9],sample_write_address[7]}),
    .b({sample_write_address[10],sample_write_address[8]}),
    .c(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\add6/c7 ),
    .mi(n217[18:17]),
    .sr(sample_system_reset),
    .fco(\add6/c11 ),
    .q(time_base_cnt[18:17]));
  AL_PHY_LSLICE \add6/ucin_al_u2421  (
    .a({sample_write_address[1],1'b0}),
    .b({sample_write_address[2],sample_write_address[0]}),
    .c(2'b00),
    .ce(mux70_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b01),
    .e(2'b01),
    .mi(io_mcu_data_pad[3:2]),
    .fco(\add6/c3 ),
    .q(pretrigger_samples[3:2]));
  AL_PHY_MSLICE \add7/u0|add7/ucin  (
    .a({trigger_level[0],1'b0}),
    .b({trig_hyst[0],open_n5646}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi(pat_wr_f[4:3]),
    .f({hyst_hi9[0],open_n5662}),
    .fco(\add7/c1 ),
    .q(\u_sq/sh0 [4:3]));
  AL_PHY_MSLICE \add7/u2|add7/u1  (
    .a(trigger_level[2:1]),
    .b(trig_hyst[2:1]),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .fci(\add7/c1 ),
    .mi(pat_wr_f[6:5]),
    .f(hyst_hi9[2:1]),
    .fco(\add7/c3 ),
    .q(\u_sq/sh1 [6:5]));
  AL_PHY_MSLICE \add7/u4|add7/u3  (
    .a(trigger_level[4:3]),
    .b(trig_hyst[4:3]),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .fci(\add7/c3 ),
    .mi({open_n5694,\u_sq/sh1 [6]}),
    .f(hyst_hi9[4:3]),
    .fco(\add7/c5 ),
    .q({open_n5698,\u_sq/e1 [6]}));
  AL_PHY_MSLICE \add7/u6|add7/u5  (
    .a(trigger_level[6:5]),
    .b(trig_hyst[6:5]),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .fci(\add7/c5 ),
    .mi({open_n5712,pat_wr_n[0]}),
    .f(hyst_hi9[6:5]),
    .fco(\add7/c7 ),
    .q({open_n5716,\u_sq/sh1 [16]}));
  AL_PHY_MSLICE \add7/ucout|add7/u7  (
    .a({open_n5717,trigger_level[7]}),
    .b({open_n5718,trig_hyst[7]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .fci(\add7/c7 ),
    .mi(pat_wr_f[8:7]),
    .f(hyst_hi9[8:7]),
    .q(\u_sq/sh1 [8:7]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b0|channel1_dc_offset/add0/ucin  (
    .a({\channel1_dc_offset/count [0],1'b0}),
    .b({1'b1,open_n5736}),
    .clk(clk_50MHz_gclk_net),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c1 ),
    .q({\channel1_dc_offset/count [0],open_n5758}));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b10|channel1_dc_offset/reg0_b9  (
    .a(\channel1_dc_offset/count [10:9]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c9 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c11 ),
    .q(\channel1_dc_offset/count [10:9]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b12|channel1_dc_offset/reg0_b11  (
    .a(\channel1_dc_offset/count [12:11]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c11 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c13 ),
    .q(\channel1_dc_offset/count [12:11]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b14|channel1_dc_offset/reg0_b13  (
    .a(\channel1_dc_offset/count [14:13]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c13 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c15 ),
    .q(\channel1_dc_offset/count [14:13]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b15_al_u2462  (
    .a({open_n5819,\channel1_dc_offset/count [15]}),
    .b({open_n5820,1'b0}),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c15 ),
    .sr(\channel1_dc_offset/n0 ),
    .q({open_n5842,\channel1_dc_offset/count [15]}));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b2|channel1_dc_offset/reg0_b1  (
    .a(\channel1_dc_offset/count [2:1]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c1 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c3 ),
    .q(\channel1_dc_offset/count [2:1]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b4|channel1_dc_offset/reg0_b3  (
    .a(\channel1_dc_offset/count [4:3]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c3 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c5 ),
    .q(\channel1_dc_offset/count [4:3]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b6|channel1_dc_offset/reg0_b5  (
    .a(\channel1_dc_offset/count [6:5]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c5 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c7 ),
    .q(\channel1_dc_offset/count [6:5]));
  AL_PHY_MSLICE \channel1_dc_offset/reg0_b8|channel1_dc_offset/reg0_b7  (
    .a(\channel1_dc_offset/count [8:7]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\channel1_dc_offset/add0/c7 ),
    .sr(\channel1_dc_offset/n0 ),
    .fco(\channel1_dc_offset/add0/c9 ),
    .q(\channel1_dc_offset/count [8:7]));
  // zaklad.v(194)
  // zaklad.v(194)
  AL_PHY_LSLICE \channel2_dc_offset/pwm_reg|channel1_dc_offset/pwm_reg  (
    .a({_al_u1726_o,_al_u1708_o}),
    .b({_al_u1728_o,_al_u1712_o}),
    .c({_al_u1729_o,_al_u1710_o}),
    .ce(\channel1_dc_offset/n0 ),
    .clk(clk_50MHz_gclk_net),
    .d({_al_u1730_o,_al_u1713_o}),
    .q({o_offset_2_pad,o_offset_1_pad}));  // zaklad.v(194)
  AL_PHY_GCLK clk_50MHz_gclk_inst (
    .clki(clk_50MHz),
    .clko(clk_50MHz_gclk_net));
  AL_PHY_MSLICE \dec_ch1/add0/u0|dec_ch1/add0/ucin  (
    .a({pair_e1[1],1'b0}),
    .b({pair_e1[0],open_n5945}),
    .clk(sample_write_clock_gclk_net),
    .mi(pair_e1[1:0]),
    .f({\dec_ch1/n19 [0],open_n5962}),
    .fco(\dec_ch1/add0/c1 ),
    .q(\dec_ch1/pe [1:0]));
  AL_PHY_MSLICE \dec_ch1/add0/u2|dec_ch1/add0/u1  (
    .a(pair_e1[3:2]),
    .b(pair_e1[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add0/c1 ),
    .mi({open_n5979,pair_e1[3]}),
    .f(\dec_ch1/n19 [2:1]),
    .fco(\dec_ch1/add0/c3 ),
    .q({open_n5983,\dec_ch1/pe [3]}));
  AL_PHY_MSLICE \dec_ch1/add0/u4|dec_ch1/add0/u3  (
    .a(pair_e1[5:4]),
    .b(pair_e1[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add0/c3 ),
    .mi({open_n5998,pair_e1[4]}),
    .f(\dec_ch1/n19 [4:3]),
    .fco(\dec_ch1/add0/c5 ),
    .q({open_n6002,\dec_ch1/pe [4]}));
  AL_PHY_MSLICE \dec_ch1/add0/u6|dec_ch1/add0/u5  (
    .a(pair_e1[7:6]),
    .b(pair_e1[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add0/c5 ),
    .mi(pair_e1[6:5]),
    .f(\dec_ch1/n19 [6:5]),
    .fco(\dec_ch1/add0/c7 ),
    .q(\dec_ch1/pe [6:5]));
  AL_PHY_MSLICE \dec_ch1/add0/ucout|dec_ch1/add0/u7  (
    .a({open_n6020,1'b0}),
    .b({open_n6021,pair_e1[7]}),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add0/c7 ),
    .mi(\dec_ch1/n82 [9:8]),
    .f({\dec_ch1/n18 ,\dec_ch1/n19 [7]}),
    .q(\dec_ch1/c2 [9:8]));
  AL_PHY_MSLICE \dec_ch1/add1/u0|dec_ch1/add1/ucin  (
    .a({\dec_ch1/pl [1],1'b0}),
    .b({\dec_ch1/pl [0],open_n6039}),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n6055,pair_l1[0]}),
    .f({\dec_ch1/n22 [0],open_n6057}),
    .fco(\dec_ch1/add1/c1 ),
    .q({open_n6060,\dec_ch1/pl [0]}));
  AL_PHY_MSLICE \dec_ch1/add1/u2|dec_ch1/add1/u1  (
    .a(\dec_ch1/pl [3:2]),
    .b(\dec_ch1/pl [2:1]),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add1/c1 ),
    .mi(\dec_ch1/n78 [1:0]),
    .f(\dec_ch1/n22 [2:1]),
    .fco(\dec_ch1/add1/c3 ),
    .q(\dec_ch1/c1 [1:0]));
  AL_PHY_MSLICE \dec_ch1/add1/u4|dec_ch1/add1/u3  (
    .a(\dec_ch1/pl [5:4]),
    .b(\dec_ch1/pl [4:3]),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add1/c3 ),
    .mi({open_n6090,\dec_ch1/c1 [0]}),
    .f(\dec_ch1/n22 [4:3]),
    .fco(\dec_ch1/add1/c5 ),
    .q({open_n6094,\dec_ch1/c1p [0]}));
  AL_PHY_MSLICE \dec_ch1/add1/u6|dec_ch1/add1/u5  (
    .a(\dec_ch1/pl [7:6]),
    .b(\dec_ch1/pl [6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add1/c5 ),
    .mi(\dec_ch1/pmn [4:3]),
    .f(\dec_ch1/n22 [6:5]),
    .fco(\dec_ch1/add1/c7 ),
    .q(\dec_ch1/pdn [4:3]));
  AL_PHY_MSLICE \dec_ch1/add1/ucout|dec_ch1/add1/u7  (
    .a({open_n6112,1'b0}),
    .b({open_n6113,\dec_ch1/pl [7]}),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/add1/c7 ),
    .mi({\dec_ch1/n78 [3],\dec_ch1/n78 [10]}),
    .f({\dec_ch1/n21 ,\dec_ch1/n22 [7]}),
    .q({\dec_ch1/c1 [3],\dec_ch1/c1 [10]}));
  AL_PHY_LSLICE \dec_ch1/add5/u11_al_u2241  (
    .a({\dec_ch1/i1 [13],\dec_ch1/i1 [11]}),
    .b({\dec_ch1/i1 [14],\dec_ch1/i1 [12]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c11 ),
    .mi({\dec_ch1/i3 [9],\dec_ch1/i3 [7]}),
    .f({\dec_ch1/n70 [13],\dec_ch1/n70 [11]}),
    .fco(\dec_ch1/add5/c15 ),
    .fx({\dec_ch1/n70 [14],\dec_ch1/n70 [12]}),
    .q({\dec_ch1/d0 [9],\dec_ch1/d0 [7]}));
  AL_PHY_LSLICE \dec_ch1/add5/u15_al_u2242  (
    .a({\dec_ch1/i1 [17],\dec_ch1/i1 [15]}),
    .b({\dec_ch1/i1 [18],\dec_ch1/i1 [16]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c15 ),
    .mi({\dec_sv[0]_hfnopt2_2 ,\dec_ch1/n70 [22]}),
    .f({\dec_ch1/n70 [17],\dec_ch1/n70 [15]}),
    .fco(\dec_ch1/add5/c19 ),
    .fx({\dec_ch1/n70 [18],\dec_ch1/n70 [16]}),
    .q({\dec_sv[1]_hfnopt2_2 ,\dec_ch1/i1 [22]}));
  AL_PHY_LSLICE \dec_ch1/add5/u19_al_u2243  (
    .a({\dec_ch1/i1 [21],\dec_ch1/i1 [19]}),
    .b({\dec_ch1/i1 [22],\dec_ch1/i1 [20]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c19 ),
    .mi({\dec_ch1/i3 [17],\dec_ch1/i3 [15]}),
    .f({\dec_ch1/n70 [21],\dec_ch1/n70 [19]}),
    .fco(\dec_ch1/add5/c23 ),
    .fx({\dec_ch1/n70 [22],\dec_ch1/n70 [20]}),
    .q({\dec_ch1/d0 [17],\dec_ch1/d0 [15]}));
  AL_PHY_LSLICE \dec_ch1/add5/u23_al_u2244  (
    .a({\dec_ch1/i1 [25],\dec_ch1/i1 [23]}),
    .b({\dec_ch1/i1 [26],\dec_ch1/i1 [24]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c23 ),
    .mi({\dec_ch1/n70 [30],\dec_ch1/n70 [28]}),
    .f({\dec_ch1/n70 [25],\dec_ch1/n70 [23]}),
    .fco(\dec_ch1/add5/c27 ),
    .fx({\dec_ch1/n70 [26],\dec_ch1/n70 [24]}),
    .q({\dec_ch1/i1 [30],\dec_ch1/i1 [28]}));
  AL_PHY_LSLICE \dec_ch1/add5/u27_al_u2245  (
    .a({\dec_ch1/i1 [29],\dec_ch1/i1 [27]}),
    .b({\dec_ch1/i1 [30],\dec_ch1/i1 [28]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c27 ),
    .mi({\dec_ch1/i3 [21],\dec_ch1/i3 [19]}),
    .f({\dec_ch1/n70 [29],\dec_ch1/n70 [27]}),
    .fco(\dec_ch1/add5/c31 ),
    .fx({\dec_ch1/n70 [30],\dec_ch1/n70 [28]}),
    .q({\dec_ch1/d0 [21],\dec_ch1/d0 [19]}));
  AL_PHY_LSLICE \dec_ch1/add5/u31_al_u2246  (
    .a({\dec_ch1/i1 [33],\dec_ch1/i1 [31]}),
    .b({\dec_ch1/i1 [34],\dec_ch1/i1 [32]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c31 ),
    .mi({\dec_ch1/n70 [36],\dec_ch1/n70 [34]}),
    .f({\dec_ch1/n70 [33],\dec_ch1/n70 [31]}),
    .fco(\dec_ch1/add5/c35 ),
    .fx({\dec_ch1/n70 [34],\dec_ch1/n70 [32]}),
    .q({\dec_ch1/i1 [36],\dec_ch1/i1 [34]}));
  AL_PHY_LSLICE \dec_ch1/add5/u35_al_u2247  (
    .a({\dec_ch1/i1 [37],\dec_ch1/i1 [35]}),
    .b({\dec_ch1/i1 [38],\dec_ch1/i1 [36]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c35 ),
    .mi(\dec_ch1/n70 [38:37]),
    .f({\dec_ch1/n70 [37],\dec_ch1/n70 [35]}),
    .fco(\dec_ch1/add5/c39 ),
    .fx({\dec_ch1/n70 [38],\dec_ch1/n70 [36]}),
    .q(\dec_ch1/i1 [38:37]));
  AL_PHY_LSLICE \dec_ch1/add5/u39_al_u2248  (
    .a({\dec_ch1/i1 [41],\dec_ch1/i1 [39]}),
    .b({\dec_ch1/i1 [42],\dec_ch1/i1 [40]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c39 ),
    .mi(\dec_ch1/n70 [43:42]),
    .f({\dec_ch1/n70 [41],\dec_ch1/n70 [39]}),
    .fco(\dec_ch1/add5/c43 ),
    .fx({\dec_ch1/n70 [42],\dec_ch1/n70 [40]}),
    .q(\dec_ch1/i1 [43:42]));
  AL_PHY_LSLICE \dec_ch1/add5/u3_al_u2239  (
    .a({\dec_ch1/i1 [5],\dec_ch1/i1 [3]}),
    .b({\dec_ch1/i1 [6],\dec_ch1/i1 [4]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/f [5],\dec_ch1/f [3]}),
    .e({\dec_ch1/f [6],\dec_ch1/f [4]}),
    .fci(\dec_ch1/add5/c3 ),
    .mi(\dec_ch1/i3 [13:12]),
    .f({\dec_ch1/n70 [5],\dec_ch1/n70 [3]}),
    .fco(\dec_ch1/add5/c7 ),
    .fx({\dec_ch1/n70 [6],\dec_ch1/n70 [4]}),
    .q(\dec_ch1/d0 [13:12]));
  AL_PHY_LSLICE \dec_ch1/add5/u43_al_u2249  (
    .a({\dec_ch1/i1 [45],\dec_ch1/i1 [43]}),
    .b({\dec_ch1/i1 [46],\dec_ch1/i1 [44]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch1/add5/c43 ),
    .mi(\dec_ch1/n70 [45:44]),
    .f({\dec_ch1/n70 [45],\dec_ch1/n70 [43]}),
    .fco(\dec_ch1/add5/c47 ),
    .fx({\dec_ch1/n70 [46],\dec_ch1/n70 [44]}),
    .q(\dec_ch1/i1 [45:44]));
  AL_PHY_LSLICE \dec_ch1/add5/u47_al_u2250  (
    .a({open_n6257,\dec_ch1/i1 [47]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({open_n6261,1'b0}),
    .fci(\dec_ch1/add5/c47 ),
    .mi(\dec_ch1/n70 [47:46]),
    .f({open_n6276,\dec_ch1/n70 [47]}),
    .q(\dec_ch1/i1 [47:46]));
  AL_PHY_LSLICE \dec_ch1/add5/u7_al_u2240  (
    .a({\dec_ch1/i1 [9],\dec_ch1/i1 [7]}),
    .b({\dec_ch1/i1 [10],\dec_ch1/i1 [8]}),
    .c(2'b00),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/f [9],\dec_ch1/f [7]}),
    .e({\dec_ch1/f [10],\dec_ch1/f [8]}),
    .fci(\dec_ch1/add5/c7 ),
    .mi({open_n6280,\dec_ch1/d0 [10]}),
    .f({\dec_ch1/n70 [9],\dec_ch1/n70 [7]}),
    .fco(\dec_ch1/add5/c11 ),
    .fx({\dec_ch1/n70 [10],\dec_ch1/n70 [8]}),
    .q({open_n6293,\dec_ch1/d0p [10]}));
  AL_PHY_LSLICE \dec_ch1/add5/ucin_al_u2238  (
    .a({\dec_ch1/i1 [1],1'b0}),
    .b({\dec_ch1/i1 [2],\dec_ch1/i1 [0]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/f [1],1'b1}),
    .e({\dec_ch1/f [2],\dec_ch1/f [0]}),
    .mi(\dec_ch1/i3 [4:3]),
    .f({\dec_ch1/n70 [1],open_n6307}),
    .fco(\dec_ch1/add5/c3 ),
    .fx({\dec_ch1/n70 [2],\dec_ch1/n70 [0]}),
    .q(\dec_ch1/d0 [4:3]));
  AL_PHY_LSLICE \dec_ch1/add6/u11_al_u2254  (
    .a({\dec_ch1/n71 [13],\dec_ch1/n71 [11]}),
    .b({\dec_ch1/n71 [14],\dec_ch1/n71 [12]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [13],\dec_ch1/i1 [11]}),
    .e({\dec_ch1/i1 [14],\dec_ch1/i1 [12]}),
    .fci(\dec_ch1/add6/c11 ),
    .mi({\dec_ch1/n73 [22],\dec_ch1/n70 [21]}),
    .f({\dec_ch1/n73 [13],\dec_ch1/n73 [11]}),
    .fco(\dec_ch1/add6/c15 ),
    .fx({\dec_ch1/n73 [14],\dec_ch1/n73 [12]}),
    .q({\dec_ch1/i2 [22],\dec_ch1/i1 [21]}));
  AL_PHY_LSLICE \dec_ch1/add6/u15_al_u2255  (
    .a({\dec_ch1/n71 [17],\dec_ch1/n71 [15]}),
    .b({\dec_ch1/n71 [18],\dec_ch1/n71 [16]}),
    .c(2'b00),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch1/i1 [17],\dec_ch1/i1 [15]}),
    .e({\dec_ch1/i1 [18],\dec_ch1/i1 [16]}),
    .fci(\dec_ch1/add6/c15 ),
    .mi({open_n6321,io_mcu_data_pad[1]}),
    .f({\dec_ch1/n73 [17],\dec_ch1/n73 [15]}),
    .fco(\dec_ch1/add6/c19 ),
    .fx({\dec_ch1/n73 [18],\dec_ch1/n73 [16]}),
    .q({open_n6334,\dec_order[1]_hfnopt2_0 }));
  AL_PHY_LSLICE \dec_ch1/add6/u19_al_u2256  (
    .a({\dec_ch1/n71 [21],\dec_ch1/n71 [19]}),
    .b({\dec_ch1/n71 [22],\dec_ch1/n71 [20]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [21],\dec_ch1/i1 [19]}),
    .e({\dec_ch1/i1 [22],\dec_ch1/i1 [20]}),
    .fci(\dec_ch1/add6/c19 ),
    .mi({\dec_ch1/n76 [21],\dec_ch1/n76 [19]}),
    .f({\dec_ch1/n73 [21],\dec_ch1/n73 [19]}),
    .fco(\dec_ch1/add6/c23 ),
    .fx({\dec_ch1/n73 [22],\dec_ch1/n73 [20]}),
    .q({\dec_ch1/i3 [21],\dec_ch1/i3 [19]}));
  AL_PHY_LSLICE \dec_ch1/add6/u23_al_u2257  (
    .a({\dec_ch1/n71 [25],\dec_ch1/n71 [23]}),
    .b({\dec_ch1/n71 [26],\dec_ch1/n71 [24]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [25],\dec_ch1/i1 [23]}),
    .e({\dec_ch1/i1 [26],\dec_ch1/i1 [24]}),
    .fci(\dec_ch1/add6/c23 ),
    .mi({\dec_ch1/i3 [22],\dec_ch1/i3 [20]}),
    .f({\dec_ch1/n73 [25],\dec_ch1/n73 [23]}),
    .fco(\dec_ch1/add6/c27 ),
    .fx({\dec_ch1/n73 [26],\dec_ch1/n73 [24]}),
    .q({\dec_ch1/d0 [22],\dec_ch1/d0 [20]}));
  AL_PHY_LSLICE \dec_ch1/add6/u27_al_u2258  (
    .a({\dec_ch1/n71 [29],\dec_ch1/n71 [27]}),
    .b({\dec_ch1/n71 [30],\dec_ch1/n71 [28]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [29],\dec_ch1/i1 [27]}),
    .e({\dec_ch1/i1 [30],\dec_ch1/i1 [28]}),
    .fci(\dec_ch1/add6/c27 ),
    .mi(\dec_ch1/n73 [31:30]),
    .f({\dec_ch1/n73 [29],\dec_ch1/n73 [27]}),
    .fco(\dec_ch1/add6/c31 ),
    .fx({\dec_ch1/n73 [30],\dec_ch1/n73 [28]}),
    .q(\dec_ch1/i2 [31:30]));
  AL_PHY_LSLICE \dec_ch1/add6/u31_al_u2259  (
    .a({\dec_ch1/n71 [33],\dec_ch1/n71 [31]}),
    .b({\dec_ch1/n71 [34],\dec_ch1/n71 [32]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [33],\dec_ch1/i1 [31]}),
    .e({\dec_ch1/i1 [34],\dec_ch1/i1 [32]}),
    .fci(\dec_ch1/add6/c31 ),
    .mi(\dec_ch1/i3 [24:23]),
    .f({\dec_ch1/n73 [33],\dec_ch1/n73 [31]}),
    .fco(\dec_ch1/add6/c35 ),
    .fx({\dec_ch1/n73 [34],\dec_ch1/n73 [32]}),
    .q(\dec_ch1/d0 [24:23]));
  AL_PHY_LSLICE \dec_ch1/add6/u35_al_u2260  (
    .a({\dec_ch1/n71 [37],\dec_ch1/n71 [35]}),
    .b({\dec_ch1/n71 [38],\dec_ch1/n71 [36]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [37],\dec_ch1/i1 [35]}),
    .e({\dec_ch1/i1 [38],\dec_ch1/i1 [36]}),
    .fci(\dec_ch1/add6/c35 ),
    .mi(\dec_ch1/i3 [28:27]),
    .f({\dec_ch1/n73 [37],\dec_ch1/n73 [35]}),
    .fco(\dec_ch1/add6/c39 ),
    .fx({\dec_ch1/n73 [38],\dec_ch1/n73 [36]}),
    .q(\dec_ch1/d0 [28:27]));
  AL_PHY_LSLICE \dec_ch1/add6/u39_al_u2261  (
    .a({\dec_ch1/n71 [41],\dec_ch1/n71 [39]}),
    .b({\dec_ch1/n71 [42],\dec_ch1/n71 [40]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [41],\dec_ch1/i1 [39]}),
    .e({\dec_ch1/i1 [42],\dec_ch1/i1 [40]}),
    .fci(\dec_ch1/add6/c39 ),
    .mi(\dec_ch1/i3 [30:29]),
    .f({\dec_ch1/n73 [41],\dec_ch1/n73 [39]}),
    .fco(\dec_ch1/add6/c43 ),
    .fx({\dec_ch1/n73 [42],\dec_ch1/n73 [40]}),
    .q(\dec_ch1/d0 [30:29]));
  AL_PHY_LSLICE \dec_ch1/add6/u3_al_u2252  (
    .a({\dec_ch1/n71 [5],\dec_ch1/n71 [3]}),
    .b({\dec_ch1/n71 [6],\dec_ch1/n71 [4]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [5],\dec_ch1/i1 [3]}),
    .e({\dec_ch1/i1 [6],\dec_ch1/i1 [4]}),
    .fci(\dec_ch1/add6/c3 ),
    .mi(\dec_ch1/n76 [13:12]),
    .f({\dec_ch1/n73 [5],\dec_ch1/n73 [3]}),
    .fco(\dec_ch1/add6/c7 ),
    .fx({\dec_ch1/n73 [6],\dec_ch1/n73 [4]}),
    .q(\dec_ch1/i3 [13:12]));
  AL_PHY_LSLICE \dec_ch1/add6/u43_al_u2262  (
    .a({\dec_ch1/n71 [45],\dec_ch1/n71 [43]}),
    .b({\dec_ch1/n71 [46],\dec_ch1/n71 [44]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [45],\dec_ch1/i1 [43]}),
    .e({\dec_ch1/i1 [46],\dec_ch1/i1 [44]}),
    .fci(\dec_ch1/add6/c43 ),
    .mi({dec_sv[2],\dec_ch1/n73 [42]}),
    .f({\dec_ch1/n73 [45],\dec_ch1/n73 [43]}),
    .fco(\dec_ch1/add6/c47 ),
    .fx({\dec_ch1/n73 [46],\dec_ch1/n73 [44]}),
    .q({\dec_sv[3]_hfnopt2_1 ,\dec_ch1/i2 [42]}));
  AL_PHY_LSLICE \dec_ch1/add6/u47_al_u2263  (
    .a({open_n6435,\dec_ch1/n71 [47]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n6438,\dec_ch1/i1 [47]}),
    .fci(\dec_ch1/add6/c47 ),
    .mi({\dec_ch1/i3 [34],\dec_ch1/i3 [32]}),
    .f({open_n6453,\dec_ch1/n73 [47]}),
    .q({\dec_ch1/d0 [34],\dec_ch1/d0 [32]}));
  AL_PHY_LSLICE \dec_ch1/add6/u7_al_u2253  (
    .a({\dec_ch1/n71 [9],\dec_ch1/n71 [7]}),
    .b({\dec_ch1/n71 [10],\dec_ch1/n71 [8]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [9],\dec_ch1/i1 [7]}),
    .e({\dec_ch1/i1 [10],\dec_ch1/i1 [8]}),
    .fci(\dec_ch1/add6/c7 ),
    .mi({\dec_ch1/n73 [10],\dec_ch1/n70 [19]}),
    .f({\dec_ch1/n73 [9],\dec_ch1/n73 [7]}),
    .fco(\dec_ch1/add6/c11 ),
    .fx({\dec_ch1/n73 [10],\dec_ch1/n73 [8]}),
    .q({\dec_ch1/i2 [10],\dec_ch1/i1 [19]}));
  AL_PHY_LSLICE \dec_ch1/add6/ucin_al_u2251  (
    .a({\dec_ch1/n71 [1],1'b0}),
    .b({\dec_ch1/n71 [2],\dec_ch1/n71 [0]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i1 [1],1'b1}),
    .e({\dec_ch1/i1 [2],\dec_ch1/i1 [0]}),
    .mi({\dec_ch1/n76 [9],\dec_ch1/n76 [7]}),
    .f({\dec_ch1/n73 [1],open_n6484}),
    .fco(\dec_ch1/add6/c3 ),
    .fx({\dec_ch1/n73 [2],\dec_ch1/n73 [0]}),
    .q({\dec_ch1/i3 [9],\dec_ch1/i3 [7]}));
  AL_PHY_LSLICE \dec_ch1/add7/u11_al_u2267  (
    .a({\dec_ch1/n74 [13],\dec_ch1/n74 [11]}),
    .b({\dec_ch1/n74 [14],\dec_ch1/n74 [12]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [13],\dec_ch1/i2 [11]}),
    .e({\dec_ch1/i2 [14],\dec_ch1/i2 [12]}),
    .fci(\dec_ch1/add7/c11 ),
    .mi(\dec_ch1/n73 [16:15]),
    .f({\dec_ch1/n76 [13],\dec_ch1/n76 [11]}),
    .fco(\dec_ch1/add7/c15 ),
    .fx({\dec_ch1/n76 [14],\dec_ch1/n76 [12]}),
    .q(\dec_ch1/i2 [16:15]));
  AL_PHY_LSLICE \dec_ch1/add7/u15_al_u2268  (
    .a({\dec_ch1/n74 [17],\dec_ch1/n74 [15]}),
    .b({\dec_ch1/n74 [18],\dec_ch1/n74 [16]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [17],\dec_ch1/i2 [15]}),
    .e({\dec_ch1/i2 [18],\dec_ch1/i2 [16]}),
    .fci(\dec_ch1/add7/c15 ),
    .mi({\dec_ch1/n73 [23],\dec_ch1/n73 [21]}),
    .f({\dec_ch1/n76 [17],\dec_ch1/n76 [15]}),
    .fco(\dec_ch1/add7/c19 ),
    .fx({\dec_ch1/n76 [18],\dec_ch1/n76 [16]}),
    .q({\dec_ch1/i2 [23],\dec_ch1/i2 [21]}));
  AL_PHY_LSLICE \dec_ch1/add7/u19_al_u2269  (
    .a({\dec_ch1/n74 [21],\dec_ch1/n74 [19]}),
    .b({\dec_ch1/n74 [22],\dec_ch1/n74 [20]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [21],\dec_ch1/i2 [19]}),
    .e({\dec_ch1/i2 [22],\dec_ch1/i2 [20]}),
    .fci(\dec_ch1/add7/c19 ),
    .mi(\dec_ch1/n73 [25:24]),
    .f({\dec_ch1/n76 [21],\dec_ch1/n76 [19]}),
    .fco(\dec_ch1/add7/c23 ),
    .fx({\dec_ch1/n76 [22],\dec_ch1/n76 [20]}),
    .q(\dec_ch1/i2 [25:24]));
  AL_PHY_LSLICE \dec_ch1/add7/u23_al_u2270  (
    .a({\dec_ch1/n74 [25],\dec_ch1/n74 [23]}),
    .b({\dec_ch1/n74 [26],\dec_ch1/n74 [24]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [25],\dec_ch1/i2 [23]}),
    .e({\dec_ch1/i2 [26],\dec_ch1/i2 [24]}),
    .fci(\dec_ch1/add7/c23 ),
    .mi(\dec_ch1/n76 [26:25]),
    .f({\dec_ch1/n76 [25],\dec_ch1/n76 [23]}),
    .fco(\dec_ch1/add7/c27 ),
    .fx({\dec_ch1/n76 [26],\dec_ch1/n76 [24]}),
    .q(\dec_ch1/i3 [26:25]));
  AL_PHY_LSLICE \dec_ch1/add7/u27_al_u2271  (
    .a({\dec_ch1/n74 [29],\dec_ch1/n74 [27]}),
    .b({\dec_ch1/n74 [30],\dec_ch1/n74 [28]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [29],\dec_ch1/i2 [27]}),
    .e({\dec_ch1/i2 [30],\dec_ch1/i2 [28]}),
    .fci(\dec_ch1/add7/c27 ),
    .mi({\dec_ch1/n76 [27],\dec_ch1/n76 [24]}),
    .f({\dec_ch1/n76 [29],\dec_ch1/n76 [27]}),
    .fco(\dec_ch1/add7/c31 ),
    .fx({\dec_ch1/n76 [30],\dec_ch1/n76 [28]}),
    .q({\dec_ch1/i3 [27],\dec_ch1/i3 [24]}));
  AL_PHY_LSLICE \dec_ch1/add7/u31_al_u2272  (
    .a({\dec_ch1/n74 [33],\dec_ch1/n74 [31]}),
    .b({\dec_ch1/n74 [34],\dec_ch1/n74 [32]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [33],\dec_ch1/i2 [31]}),
    .e({\dec_ch1/i2 [34],\dec_ch1/i2 [32]}),
    .fci(\dec_ch1/add7/c31 ),
    .mi({\dec_ch1/n76 [31],\dec_ch1/n73 [35]}),
    .f({\dec_ch1/n76 [33],\dec_ch1/n76 [31]}),
    .fco(\dec_ch1/add7/c35 ),
    .fx({\dec_ch1/n76 [34],\dec_ch1/n76 [32]}),
    .q({\dec_ch1/i3 [31],\dec_ch1/i2 [35]}));
  AL_PHY_LSLICE \dec_ch1/add7/u35_al_u2273  (
    .a({\dec_ch1/n74 [37],\dec_ch1/n74 [35]}),
    .b({\dec_ch1/n74 [38],\dec_ch1/n74 [36]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [37],\dec_ch1/i2 [35]}),
    .e({\dec_ch1/i2 [38],\dec_ch1/i2 [36]}),
    .fci(\dec_ch1/add7/c35 ),
    .mi(\dec_ch1/n76 [34:33]),
    .f({\dec_ch1/n76 [37],\dec_ch1/n76 [35]}),
    .fco(\dec_ch1/add7/c39 ),
    .fx({\dec_ch1/n76 [38],\dec_ch1/n76 [36]}),
    .q(\dec_ch1/i3 [34:33]));
  AL_PHY_LSLICE \dec_ch1/add7/u39_al_u2274  (
    .a({\dec_ch1/n74 [41],\dec_ch1/n74 [39]}),
    .b({\dec_ch1/n74 [42],\dec_ch1/n74 [40]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [41],\dec_ch1/i2 [39]}),
    .e({\dec_ch1/i2 [42],\dec_ch1/i2 [40]}),
    .fci(\dec_ch1/add7/c39 ),
    .mi(\dec_ch1/n76 [36:35]),
    .f({\dec_ch1/n76 [41],\dec_ch1/n76 [39]}),
    .fco(\dec_ch1/add7/c43 ),
    .fx({\dec_ch1/n76 [42],\dec_ch1/n76 [40]}),
    .q(\dec_ch1/i3 [36:35]));
  AL_PHY_LSLICE \dec_ch1/add7/u3_al_u2265  (
    .a({\dec_ch1/n74 [5],\dec_ch1/n74 [3]}),
    .b({\dec_ch1/n74 [6],\dec_ch1/n74 [4]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [5],\dec_ch1/i2 [3]}),
    .e({\dec_ch1/i2 [6],\dec_ch1/i2 [4]}),
    .fci(\dec_ch1/add7/c3 ),
    .mi({\dec_ch1/n73 [7],\dec_ch1/n73 [0]}),
    .f({\dec_ch1/n76 [5],\dec_ch1/n76 [3]}),
    .fco(\dec_ch1/add7/c7 ),
    .fx({\dec_ch1/n76 [6],\dec_ch1/n76 [4]}),
    .q({\dec_ch1/i2 [7],\dec_ch1/i2 [0]}));
  AL_PHY_LSLICE \dec_ch1/add7/u43_al_u2275  (
    .a({\dec_ch1/n74 [45],\dec_ch1/n74 [43]}),
    .b({\dec_ch1/n74 [46],\dec_ch1/n74 [44]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [45],\dec_ch1/i2 [43]}),
    .e({\dec_ch1/i2 [46],\dec_ch1/i2 [44]}),
    .fci(\dec_ch1/add7/c43 ),
    .mi(\dec_ch1/n76 [38:37]),
    .f({\dec_ch1/n76 [45],\dec_ch1/n76 [43]}),
    .fco(\dec_ch1/add7/c47 ),
    .fx({\dec_ch1/n76 [46],\dec_ch1/n76 [44]}),
    .q(\dec_ch1/i3 [38:37]));
  AL_PHY_LSLICE \dec_ch1/add7/u47_al_u2276  (
    .a({open_n6615,\dec_ch1/n74 [47]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({open_n6619,\dec_ch1/i2 [47]}),
    .fci(\dec_ch1/add7/c47 ),
    .mi(\dec_ch1/n76 [46:45]),
    .f({open_n6634,\dec_ch1/n76 [47]}),
    .q(\dec_ch1/i3 [46:45]));
  AL_PHY_LSLICE \dec_ch1/add7/u7_al_u2266  (
    .a({\dec_ch1/n74 [9],\dec_ch1/n74 [7]}),
    .b({\dec_ch1/n74 [10],\dec_ch1/n74 [8]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [9],\dec_ch1/i2 [7]}),
    .e({\dec_ch1/i2 [10],\dec_ch1/i2 [8]}),
    .fci(\dec_ch1/add7/c7 ),
    .mi(\dec_ch1/n73 [12:11]),
    .f({\dec_ch1/n76 [9],\dec_ch1/n76 [7]}),
    .fco(\dec_ch1/add7/c11 ),
    .fx({\dec_ch1/n76 [10],\dec_ch1/n76 [8]}),
    .q(\dec_ch1/i2 [12:11]));
  AL_PHY_LSLICE \dec_ch1/add7/ucin_al_u2264  (
    .a({\dec_ch1/n74 [1],1'b0}),
    .b({\dec_ch1/n74 [2],\dec_ch1/n74 [0]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [1],1'b1}),
    .e({\dec_ch1/i2 [2],\dec_ch1/i2 [0]}),
    .mi({\dec_ch1/n76 [14],\dec_ch1/n73 [1]}),
    .f({\dec_ch1/n76 [1],open_n6665}),
    .fco(\dec_ch1/add7/c3 ),
    .fx({\dec_ch1/n76 [2],\dec_ch1/n76 [0]}),
    .q({\dec_ch1/i3 [14],\dec_ch1/i2 [1]}));
  AL_PHY_MSLICE \dec_ch1/lt0/u0|dec_ch1/lt0/ucin  (
    .a({pair_l1[0],1'b0}),
    .b({pair_e1[0],open_n6666}),
    .clk(clk_200MHz),
    .mi({adc_d2[5],adc_q2[5]}),
    .fco(\dec_ch1/lt0/c1 ),
    .q({adc_dd2[5],adc_d2[5]}));
  AL_PHY_MSLICE \dec_ch1/lt0/u2|dec_ch1/lt0/u1  (
    .a(pair_l1[2:1]),
    .b(pair_e1[2:1]),
    .clk(clk_200MHz),
    .fci(\dec_ch1/lt0/c1 ),
    .mi(adc_d1[6:5]),
    .fco(\dec_ch1/lt0/c3 ),
    .q(adc_dd1[6:5]));
  AL_PHY_MSLICE \dec_ch1/lt0/u4|dec_ch1/lt0/u3  (
    .a(pair_l1[4:3]),
    .b(pair_e1[4:3]),
    .clk(clk_200MHz),
    .fci(\dec_ch1/lt0/c3 ),
    .mi(adc_q1[5:4]),
    .fco(\dec_ch1/lt0/c5 ),
    .q(adc_d1[5:4]));
  AL_PHY_MSLICE \dec_ch1/lt0/u6|dec_ch1/lt0/u5  (
    .a(pair_l1[6:5]),
    .b(pair_e1[6:5]),
    .ce(\dec_sv[0]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt0/c5 ),
    .mi({open_n6738,\dec_ch2/pkw [14]}),
    .fco(\dec_ch1/lt0/c7 ),
    .q({open_n6744,\dec_ch2/pk0 [14]}));
  AL_PHY_MSLICE \dec_ch1/lt0/ucout|dec_ch1/lt0/u7  (
    .a({1'b0,pair_l1[7]}),
    .b({1'b1,pair_e1[7]}),
    .ce(\dec_sv[0]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt0/c7 ),
    .mi({open_n6758,\dec_ch2/pkw [10]}),
    .f({\dec_ch1/n53 ,open_n6760}),
    .q({open_n6764,\dec_ch2/pk0 [10]}));
  AL_PHY_MSLICE \dec_ch1/lt1/u0|dec_ch1/lt1/ucin  (
    .a({pair_e1[0],1'b0}),
    .b({pair_l1[0],open_n6765}),
    .clk(clk_200MHz),
    .mi(adc_d2[7:6]),
    .fco(\dec_ch1/lt1/c1 ),
    .q(adc_dd2[7:6]));
  AL_PHY_MSLICE \dec_ch1/lt1/u2|dec_ch1/lt1/u1  (
    .a(pair_e1[2:1]),
    .b(pair_l1[2:1]),
    .clk(clk_200MHz),
    .fci(\dec_ch1/lt1/c1 ),
    .mi({adc_d1[7],adc_q2[7]}),
    .fco(\dec_ch1/lt1/c3 ),
    .q({adc_dd1[7],adc_d2[7]}));
  AL_PHY_MSLICE \dec_ch1/lt1/u4|dec_ch1/lt1/u3  (
    .a(pair_e1[4:3]),
    .b(pair_l1[4:3]),
    .clk(clk_200MHz),
    .fci(\dec_ch1/lt1/c3 ),
    .mi({adc_q2[6],adc_q1[7]}),
    .fco(\dec_ch1/lt1/c5 ),
    .q({adc_d2[6],adc_d1[7]}));
  AL_PHY_MSLICE \dec_ch1/lt1/u6|dec_ch1/lt1/u5  (
    .a(pair_e1[6:5]),
    .b(pair_l1[6:5]),
    .clk(clk_200MHz),
    .fci(\dec_ch1/lt1/c5 ),
    .mi({open_n6838,adc_q1[6]}),
    .fco(\dec_ch1/lt1/c7 ),
    .q({open_n6844,adc_d1[6]}));
  AL_PHY_MSLICE \dec_ch1/lt1/ucout|dec_ch1/lt1/u7  (
    .a({1'b0,pair_e1[7]}),
    .b({1'b1,pair_l1[7]}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt1/c7 ),
    .mi({\dec_ch2/rmx [6],\dec_ch2/rmx [4]}),
    .f({\dec_ch1/n55 ,open_n6859}),
    .q({\dec_ch2/pkw [14],\dec_ch2/pkw [12]}));
  AL_PHY_MSLICE \dec_ch1/lt2/u0|dec_ch1/lt2/ucin  (
    .a({\dec_ch1/rmx [0],1'b0}),
    .b({\dec_ch1/pdx [0],open_n6863}),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/i3 [0],\dec_ch1/pkw [9]}),
    .fco(\dec_ch1/lt2/c1 ),
    .q({\dec_ch1/d0 [0],\dec_ch1/pk0 [9]}));
  AL_PHY_MSLICE \dec_ch1/lt2/u2|dec_ch1/lt2/u1  (
    .a(\dec_ch1/rmx [2:1]),
    .b(\dec_ch1/pdx [2:1]),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt2/c1 ),
    .mi(\dec_ch1/i3 [2:1]),
    .fco(\dec_ch1/lt2/c3 ),
    .q(\dec_ch1/d0 [2:1]));
  AL_PHY_MSLICE \dec_ch1/lt2/u4|dec_ch1/lt2/u3  (
    .a(\dec_ch1/rmx [4:3]),
    .b(\dec_ch1/pdx [4:3]),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt2/c3 ),
    .mi(\dec_ch1/i3 [6:5]),
    .fco(\dec_ch1/lt2/c5 ),
    .q(\dec_ch1/d0 [6:5]));
  AL_PHY_MSLICE \dec_ch1/lt2/u6|dec_ch1/lt2/u5  (
    .a(\dec_ch1/rmx [6:5]),
    .b(\dec_ch1/pdx [6:5]),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt2/c5 ),
    .mi(\dec_ch1/d0 [2:1]),
    .fco(\dec_ch1/lt2/c7 ),
    .q(\dec_ch1/d0p [2:1]));
  AL_PHY_MSLICE \dec_ch1/lt2/ucout|dec_ch1/lt2/u7  (
    .a({1'b0,\dec_ch1/rmx [7]}),
    .b({1'b1,\dec_ch1/pdx [7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt2/c7 ),
    .mi({n152,\dec_ch1/n70 [6]}),
    .f({\dec_ch1/n57 ,open_n6952}),
    .q({\dec_sv[0]_hfnopt2_2 ,\dec_ch1/i1 [6]}));
  AL_PHY_MSLICE \dec_ch1/lt3/u0|dec_ch1/lt3/ucin  (
    .a({\dec_ch1/pdn [0],1'b0}),
    .b({\dec_ch1/rmn [0],open_n6956}),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch1/d0 [13:12]),
    .fco(\dec_ch1/lt3/c1 ),
    .q(\dec_ch1/d0p [13:12]));
  AL_PHY_MSLICE \dec_ch1/lt3/u2|dec_ch1/lt3/u1  (
    .a(\dec_ch1/pdn [2:1]),
    .b(\dec_ch1/rmn [2:1]),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt3/c1 ),
    .mi({open_n6989,\dec_ch1/d0 [11]}),
    .fco(\dec_ch1/lt3/c3 ),
    .q({open_n6995,\dec_ch1/d0p [11]}));
  AL_PHY_MSLICE \dec_ch1/lt3/u4|dec_ch1/lt3/u3  (
    .a(\dec_ch1/pdn [4:3]),
    .b(\dec_ch1/rmn [4:3]),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt3/c3 ),
    .mi({\dec_ch1/d0 [17],\dec_ch1/d0 [15]}),
    .fco(\dec_ch1/lt3/c5 ),
    .q({\dec_ch1/d0p [17],\dec_ch1/d0p [15]}));
  AL_PHY_MSLICE \dec_ch1/lt3/u6|dec_ch1/lt3/u5  (
    .a(\dec_ch1/pdn [6:5]),
    .b(\dec_ch1/rmn [6:5]),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt3/c5 ),
    .mi({\dec_ch1/d0 [21],\dec_ch1/d0 [19]}),
    .fco(\dec_ch1/lt3/c7 ),
    .q({\dec_ch1/d0p [21],\dec_ch1/d0p [19]}));
  AL_PHY_MSLICE \dec_ch1/lt3/ucout|dec_ch1/lt3/u7  (
    .a({1'b0,\dec_ch1/pdn [7]}),
    .b({1'b1,\dec_ch1/rmn [7]}),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch1/lt3/c7 ),
    .mi(\dec_ch1/n78 [36:35]),
    .f({\dec_ch1/n59 ,open_n7046}),
    .q(\dec_ch1/c1 [36:35]));
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg0_b0|dec_ch1/reg0_b1  (
    .clk(sample_write_clock_gclk_net),
    .mi({adc1B_w[0],adc1B_w[1]}),
    .q({\dec_ch1/pb [0],\dec_ch1/pb [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg0_b2|dec_ch1/reg0_b3  (
    .clk(sample_write_clock_gclk_net),
    .mi({adc1B_w[2],adc1B_w[3]}),
    .q({\dec_ch1/pb [2],\dec_ch1/pb [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg0_b5|dec_ch1/reg0_b6  (
    .b(n302[4:3]),
    .c(n303[4:3]),
    .clk(sample_write_clock_gclk_net),
    .d({n301,n301}),
    .mi({adc1B_w[5],adc1B_w[6]}),
    .f(n304[4:3]),
    .q({\dec_ch1/pb [5],\dec_ch1/pb [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg10_b0|dec_ch1/reg10_b1  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmn [0],\dec_ch1/rmn [1]}),
    .q({\dec_ch1/pkw [0],\dec_ch1/pkw [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg10_b10|dec_ch1/reg10_b11  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmx [2],\dec_ch1/rmx [3]}),
    .q({\dec_ch1/pkw [10],\dec_ch1/pkw [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg10_b12|dec_ch1/reg10_b15  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmx [4],\dec_ch1/rmx [7]}),
    .q({\dec_ch1/pkw [12],\dec_ch1/pkw [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg10_b13|dec_ch1/reg10_b14  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmx [5],\dec_ch1/rmx [6]}),
    .q({\dec_ch1/pkw [13],\dec_ch1/pkw [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg10_b2|dec_ch1/reg10_b4  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmn [2],\dec_ch1/rmn [4]}),
    .q({\dec_ch1/pkw [2],\dec_ch1/pkw [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg10_b3|dec_ch1/reg10_b6  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmn [3],\dec_ch1/rmn [6]}),
    .q({\dec_ch1/pkw [3],\dec_ch1/pkw [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg10_b5|dec_ch1/reg10_b7  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmn [5],\dec_ch1/rmn [7]}),
    .q({\dec_ch1/pkw [5],\dec_ch1/pkw [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg10_b8|dec_ch1/reg10_b9  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/rmx [0],\dec_ch1/rmx [1]}),
    .q({\dec_ch1/pkw [8],\dec_ch1/pkw [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg11_b0|dec_ch1/reg11_b6  (
    .ce(\dec_ch1/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdx [0],\dec_ch1/pdx [6]}),
    .q({\dec_ch1/rmx [0],\dec_ch1/rmx [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg11_b1|dec_ch1/reg11_b5  (
    .ce(\dec_ch1/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdx [1],\dec_ch1/pdx [5]}),
    .q({\dec_ch1/rmx [1],\dec_ch1/rmx [5]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg11_b2  (
    .ce(\dec_ch1/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n7400,\dec_ch1/pdx [2]}),
    .q({open_n7418,\dec_ch1/rmx [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg11_b3|dec_ch1/reg11_b4  (
    .ce(\dec_ch1/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdx [3],\dec_ch1/pdx [4]}),
    .q({\dec_ch1/rmx [3],\dec_ch1/rmx [4]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg11_b7  (
    .c({open_n7447,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_ch1/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n7448,\dec_ch1/pl [0]}),
    .mi({open_n7459,\dec_ch1/pdx [7]}),
    .f({open_n7461,\dec_ch1/t_pl [0]}),
    .q({open_n7465,\dec_ch1/rmx [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg12_b0|dec_ch1/reg12_b2  (
    .ce(\dec_ch1/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdn [0],\dec_ch1/pdn [2]}),
    .q({\dec_ch1/rmn [0],\dec_ch1/rmn [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg12_b1|dec_ch1/reg12_b4  (
    .ce(\dec_ch1/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdn [1],\dec_ch1/pdn [4]}),
    .q({\dec_ch1/rmn [1],\dec_ch1/rmn [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg12_b3|dec_ch1/reg12_b6  (
    .ce(\dec_ch1/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdn [3],\dec_ch1/pdn [6]}),
    .q({\dec_ch1/rmn [3],\dec_ch1/rmn [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg12_b5|dec_ch1/reg12_b7  (
    .ce(\dec_ch1/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pdn [5],\dec_ch1/pdn [7]}),
    .q({\dec_ch1/rmn [5],\dec_ch1/rmn [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg13_b0|dec_ch1/reg13_b2  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pkw [0],\dec_ch1/pkw [2]}),
    .q({\dec_ch1/pk0 [0],\dec_ch1/pk0 [2]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg13_b1  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n7612,\dec_ch1/pkw [1]}),
    .q({open_n7619,\dec_ch1/pk0 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg13_b10|dec_ch1/reg13_b14  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pkw [10],\dec_ch1/pkw [14]}),
    .q({\dec_ch1/pk0 [10],\dec_ch1/pk0 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg13_b11|dec_ch1/reg13_b15  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pkw [11],\dec_ch1/pkw [15]}),
    .q({\dec_ch1/pk0 [11],\dec_ch1/pk0 [15]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg13_b12  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n7683,\dec_ch1/pkw [12]}),
    .q({open_n7701,\dec_ch1/pk0 [12]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg13_b13|dec_ch1/reg13_b8  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pkw [13],\dec_ch1/pkw [8]}),
    .q({\dec_ch1/pk0 [13],\dec_ch1/pk0 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg13_b3|dec_ch1/reg13_b6  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pkw [3],\dec_ch1/pkw [6]}),
    .q({\dec_ch1/pk0 [3],\dec_ch1/pk0 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg13_b4|dec_ch1/reg13_b5  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pkw [4],\dec_ch1/pkw [5]}),
    .q({\dec_ch1/pk0 [4],\dec_ch1/pk0 [5]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg13_b7  (
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n7800,\dec_ch1/pkw [7]}),
    .q({open_n7807,\dec_ch1/pk0 [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg14_b0|dec_ch1/reg14_b1  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [0],\dec_ch1/pk0 [1]}),
    .q({\dec_ch1/pk1 [0],\dec_ch1/pk1 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg14_b10|dec_ch1/reg14_b14  (
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [10],\dec_ch1/pk0 [14]}),
    .q({\dec_ch1/pk1 [10],\dec_ch1/pk1 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg14_b11|dec_ch1/reg14_b15  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [11],\dec_ch1/pk0 [15]}),
    .q({\dec_ch1/pk1 [11],\dec_ch1/pk1 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg14_b12|dec_ch1/reg14_b13  (
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [12],\dec_ch1/pk0 [13]}),
    .q({\dec_ch1/pk1 [12],\dec_ch1/pk1 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg14_b2|dec_ch1/reg14_b4  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [2],\dec_ch1/pk0 [4]}),
    .q({\dec_ch1/pk1 [2],\dec_ch1/pk1 [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg14_b3|dec_ch1/reg14_b6  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [3],\dec_ch1/pk0 [6]}),
    .q({\dec_ch1/pk1 [3],\dec_ch1/pk1 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg14_b5|dec_ch1/reg14_b7  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [5],\dec_ch1/pk0 [7]}),
    .q({\dec_ch1/pk1 [5],\dec_ch1/pk1 [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg14_b8|dec_ch1/reg14_b9  (
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk0 [8],\dec_ch1/pk0 [9]}),
    .q({\dec_ch1/pk1 [8],\dec_ch1/pk1 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg15_b0|dec_ch1/reg15_b2  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk1 [0],\dec_ch1/pk1 [2]}),
    .q({\dec_ch1/pk2 [0],\dec_ch1/pk2 [2]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg15_b1  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8054,\dec_ch1/pk1 [1]}),
    .q({open_n8061,\dec_ch1/pk2 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg15_b10|dec_ch1/reg15_b14  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk1 [10],\dec_ch1/pk1 [14]}),
    .q({\dec_ch1/pk2 [10],\dec_ch1/pk2 [14]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg15_b11  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8097,\dec_ch1/pk1 [11]}),
    .q({open_n8115,\dec_ch1/pk2 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg15_b12|dec_ch1/reg15_b13  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk1 [12],\dec_ch1/pk1 [13]}),
    .q({\dec_ch1/pk2 [12],\dec_ch1/pk2 [13]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg15_b15  (
    .c({open_n8148,\dec_ch1/i3 [20]}),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n8149,\dec_ch1/k3_lutinv }),
    .mi({open_n8160,\dec_ch1/pk1 [15]}),
    .f({open_n8162,\dec_ch1/n74 [20]}),
    .q({open_n8166,\dec_ch1/pk2 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg15_b3|dec_ch1/reg15_b4  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk1 [3],\dec_ch1/pk1 [4]}),
    .q({\dec_ch1/pk2 [3],\dec_ch1/pk2 [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg15_b5|dec_ch1/reg15_b7  (
    .c({\dec_ch1/i3 [28],\dec_ch1/i3 [30]}),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/pk1 [5],\dec_ch1/pk1 [7]}),
    .f({\dec_ch1/n74 [28],\dec_ch1/n74 [30]}),
    .q({\dec_ch1/pk2 [5],\dec_ch1/pk2 [7]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg15_b6  (
    .c({open_n8221,\dec_ch1/i3 [29]}),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n8222,\dec_ch1/k3_lutinv }),
    .mi({open_n8226,\dec_ch1/pk1 [6]}),
    .f({open_n8239,\dec_ch1/n74 [29]}),
    .q({open_n8243,\dec_ch1/pk2 [6]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg15_b8  (
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8262,\dec_ch1/pk1 [8]}),
    .q({open_n8269,\dec_ch1/pk2 [8]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg15_b9  (
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8281,\dec_ch1/pk1 [9]}),
    .q({open_n8299,\dec_ch1/pk2 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg16_b0|dec_ch1/reg16_b3  (
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk2 [0],\dec_ch1/pk2 [3]}),
    .q({\dec_ch1/pk3 [0],\dec_ch1/pk3 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg16_b11|dec_ch1/reg16_b2  (
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk2 [11],\dec_ch1/pk2 [2]}),
    .q({\dec_ch1/pk3 [11],\dec_ch1/pk3 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg16_b12|dec_ch1/reg16_b13  (
    .ce(\dec_sv[3]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk2 [12],\dec_ch1/pk2 [13]}),
    .q({\dec_ch1/pk3 [12],\dec_ch1/pk3 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg16_b14|dec_ch1/reg16_b15  (
    .ce(\dec_sv[3]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk2 [14],\dec_ch1/pk2 [15]}),
    .q({\dec_ch1/pk3 [14],\dec_ch1/pk3 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg16_b1|dec_ch1/reg16_b10  (
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk2 [1],\dec_ch1/pk2 [10]}),
    .q({\dec_ch1/pk3 [1],\dec_ch1/pk3 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg16_b4|dec_ch1/reg16_b5  (
    .c({\dec_ch1/i3 [39],\dec_ch1/i3 [40]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/pk2 [4],\dec_ch1/pk2 [5]}),
    .f({\dec_ch1/n74 [39],\dec_ch1/n74 [40]}),
    .q({\dec_ch1/pk3 [4],\dec_ch1/pk3 [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg16_b6|dec_ch1/reg16_b7  (
    .c({\dec_ch1/i3 [43],\dec_ch1/i3 [44]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/pk2 [6],\dec_ch1/pk2 [7]}),
    .f({\dec_ch1/n74 [43],\dec_ch1/n74 [44]}),
    .q({\dec_ch1/pk3 [6],\dec_ch1/pk3 [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg16_b8|dec_ch1/reg16_b9  (
    .ce(\dec_sv[3]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk2 [8],\dec_ch1/pk2 [9]}),
    .q({\dec_ch1/pk3 [8],\dec_ch1/pk3 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg17_b0|dec_ch1/reg17_b11  (
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk3 [0],\dec_ch1/pk3 [11]}),
    .q({\dec_ch1/pk4 [0],\dec_ch1/pk4 [11]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg17_b1  (
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8535,\dec_ch1/pk3 [1]}),
    .q({open_n8553,\dec_ch1/pk4 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg17_b10|dec_ch1/reg17_b14  (
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk3 [10],\dec_ch1/pk3 [14]}),
    .q({\dec_ch1/pk4 [10],\dec_ch1/pk4 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg17_b12|dec_ch1/reg17_b13  (
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk3 [12],\dec_ch1/pk3 [13]}),
    .q({\dec_ch1/pk4 [12],\dec_ch1/pk4 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg17_b2|dec_ch1/reg17_b3  (
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk3 [2],\dec_ch1/pk3 [3]}),
    .q({\dec_ch1/pk4 [2],\dec_ch1/pk4 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg17_b4|dec_ch1/reg17_b7  (
    .c({peak_en,\dec_ch2/pk4 [5]}),
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/pk4 [0],peak_en}),
    .mi({\dec_ch1/pk3 [4],\dec_ch1/pk3 [7]}),
    .f({_al_u1858_o,_al_u1816_o}),
    .q({\dec_ch1/pk4 [4],\dec_ch1/pk4 [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg17_b5|dec_ch1/reg17_b6  (
    .c({peak_en,peak_en}),
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/pk4 [1],\dec_ch2/pk4 [4]}),
    .mi({\dec_ch1/pk3 [5],\dec_ch1/pk3 [6]}),
    .f({_al_u1854_o,_al_u1821_o}),
    .q({\dec_ch1/pk4 [5],\dec_ch1/pk4 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg17_b8|dec_ch1/reg17_b9  (
    .ce(\dec_sv[4]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pk3 [8],\dec_ch1/pk3 [9]}),
    .q({\dec_ch1/pk4 [8],\dec_ch1/pk4 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b0|dec_ch1/reg18_b2  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [0],\dec_ch1/n70 [2]}),
    .q({\dec_ch1/i1 [0],\dec_ch1/i1 [2]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b1  (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8746,\dec_ch1/n70 [1]}),
    .q({open_n8753,\dec_ch1/i1 [1]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b10  (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8773,\dec_ch1/n70 [10]}),
    .q({open_n8780,\dec_ch1/i1 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b11|dec_ch1/reg18_b16  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [11],\dec_ch1/n70 [16]}),
    .q({\dec_ch1/i1 [11],\dec_ch1/i1 [16]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b12|dec_ch1/reg18_b14  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [12],\dec_ch1/n70 [14]}),
    .q({\dec_ch1/i1 [12],\dec_ch1/i1 [14]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b13  (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8847,\dec_ch1/n70 [13]}),
    .q({open_n8865,\dec_ch1/i1 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b15|dec_ch1/reg18_b17  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [15],\dec_ch1/n70 [17]}),
    .q({\dec_ch1/i1 [15],\dec_ch1/i1 [17]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b18  (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n8903,\dec_ch1/n70 [18]}),
    .q({open_n8921,\dec_ch1/i1 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b20|dec_ch1/reg18_b25  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [20],\dec_ch1/n70 [25]}),
    .q({\dec_ch1/i1 [20],\dec_ch1/i1 [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b23|dec_ch1/reg18_b29  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [23],\dec_ch1/n70 [29]}),
    .q({\dec_ch1/i1 [23],\dec_ch1/i1 [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b24|dec_ch1/reg18_b26  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [24],\dec_ch1/n70 [26]}),
    .q({\dec_ch1/i1 [24],\dec_ch1/i1 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b27|dec_ch1/reg18_b32  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [27],\dec_ch1/n70 [32]}),
    .q({\dec_ch1/i1 [27],\dec_ch1/i1 [32]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b31|dec_ch1/reg18_b33  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [31],\dec_ch1/n70 [33]}),
    .q({\dec_ch1/i1 [31],\dec_ch1/i1 [33]}));  // zaklad.v(277)
  // zaklad.v(1596)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b35|reg17_b0_hfnopt2_3  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [31],\dec_ch1/i2 [37]}),
    .mi({\dec_ch1/n70 [35],n152}),
    .f({\dec_ch1/n71 [31],\dec_ch1/n71 [37]}),
    .q({\dec_ch1/i1 [35],\dec_sv[0]_hfnopt2_3 }));  // zaklad.v(1596)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b3|dec_ch1/reg18_b4  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n70 [3],\dec_ch1/n70 [4]}),
    .q({\dec_ch1/i1 [3],\dec_ch1/i1 [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg18_b5|dec_ch1/reg20_b11  (
    .c({\dec_ch1/i3 [7],\dec_ch1/i3 [9]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n70 [5],\dec_ch1/n76 [11]}),
    .f({\dec_ch1/n74 [7],\dec_ch1/n74 [9]}),
    .q({\dec_ch1/i1 [5],\dec_ch1/i3 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg18_b7|dec_ch1/reg18_b9  (
    .c(\dec_ch1/i3 [12:11]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n70 [7],\dec_ch1/n70 [9]}),
    .f(\dec_ch1/n74 [12:11]),
    .q({\dec_ch1/i1 [7],\dec_ch1/i1 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b13|dec_ch1/reg18_b8  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_ch1/i3 [13]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [10],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n73 [13],\dec_ch1/n70 [8]}),
    .f({\dec_ch1/n71 [10],\dec_ch1/n74 [13]}),
    .q({\dec_ch1/i2 [13],\dec_ch1/i1 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b14|dec_ch1/reg20_b8  (
    .a({open_n9164,\dec_ch1/i3 [8]}),
    .b({\dec_ch1/i2 [7],open_n9165}),
    .c({\dec_order[1]_hfnopt2_0 ,\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n73 [14],\dec_ch1/n76 [8]}),
    .f({\dec_ch1/n71 [7],\dec_ch1/n74 [8]}),
    .q({\dec_ch1/i2 [14],\dec_ch1/i3 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b17|dec_ch1/reg20_b20  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [11],\dec_ch1/i2 [22]}),
    .mi({\dec_ch1/n73 [17],\dec_ch1/n76 [20]}),
    .f({\dec_ch1/n71 [11],\dec_ch1/n71 [22]}),
    .q({\dec_ch1/i2 [17],\dec_ch1/i3 [20]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b18|dec_ch1/reg19_b20  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [12],\dec_ch1/i2 [14]}),
    .mi({\dec_ch1/n73 [18],\dec_ch1/n73 [20]}),
    .f({\dec_ch1/n71 [12],\dec_ch1/n71 [14]}),
    .q({\dec_ch1/i2 [18],\dec_ch1/i2 [20]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b26|dec_ch1/reg19_b29  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [15],\dec_ch1/i2 [18]}),
    .mi({\dec_ch1/n73 [26],\dec_ch1/n73 [29]}),
    .f({\dec_ch1/n71 [15],\dec_ch1/n71 [18]}),
    .q({\dec_ch1/i2 [26],\dec_ch1/i2 [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b27|dec_ch1/reg19_b28  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [16],\dec_ch1/i2 [17]}),
    .mi({\dec_ch1/n73 [27],\dec_ch1/n73 [28]}),
    .f({\dec_ch1/n71 [16],\dec_ch1/n71 [17]}),
    .q({\dec_ch1/i2 [27],\dec_ch1/i2 [28]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b32|dec_ch1/reg19_b36  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [19],\dec_ch1/i2 [26]}),
    .mi({\dec_ch1/n73 [32],\dec_ch1/n73 [36]}),
    .f({\dec_ch1/n71 [19],\dec_ch1/n71 [26]}),
    .q({\dec_ch1/i2 [32],\dec_ch1/i2 [36]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b33|dec_ch1/reg19_b34  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [20],\dec_ch1/i2 [21]}),
    .mi({\dec_ch1/n73 [33],\dec_ch1/n73 [34]}),
    .f({\dec_ch1/n71 [20],\dec_ch1/n71 [21]}),
    .q({\dec_ch1/i2 [33],\dec_ch1/i2 [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b37|dec_ch1/reg19_b38  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [27],\dec_ch1/i2 [29]}),
    .mi({\dec_ch1/n73 [37],\dec_ch1/n73 [38]}),
    .f({\dec_ch1/n71 [27],\dec_ch1/n71 [29]}),
    .q({\dec_ch1/i2 [37],\dec_ch1/i2 [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b39|dec_ch1/reg19_b43  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [23],\dec_ch1/i2 [35]}),
    .mi({\dec_ch1/n73 [39],\dec_ch1/n73 [43]}),
    .f({\dec_ch1/n71 [23],\dec_ch1/n71 [35]}),
    .q({\dec_ch1/i2 [39],\dec_ch1/i2 [43]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b3|dec_ch1/reg19_b6  (
    .a({\dec_ch1/i2 [3],open_n9355}),
    .c({\dec_order[1]_hfnopt2_0 ,\dec_ch1/i3 [10]}),
    .clk(sample_write_clock_gclk_net),
    .d({open_n9359,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n73 [3],\dec_ch1/n73 [6]}),
    .f({\dec_ch1/n71 [3],\dec_ch1/n74 [10]}),
    .q({\dec_ch1/i2 [3],\dec_ch1/i2 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b40|dec_ch1/reg19_b41  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [24],\dec_ch1/i2 [25]}),
    .mi({\dec_ch1/n73 [40],\dec_ch1/n73 [41]}),
    .f({\dec_ch1/n71 [24],\dec_ch1/n71 [25]}),
    .q({\dec_ch1/i2 [40],\dec_ch1/i2 [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b44|dec_ch1/reg20_b39  (
    .c({\dec_ch1/i3 [31],\dec_ch1/i3 [33]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n73 [44],\dec_ch1/n76 [39]}),
    .f({\dec_ch1/n74 [31],\dec_ch1/n74 [33]}),
    .q({\dec_ch1/i2 [44],\dec_ch1/i3 [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b45|dec_ch1/reg19_b46  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [32],\dec_ch1/i2 [33]}),
    .mi({\dec_ch1/n73 [45],\dec_ch1/n73 [46]}),
    .f({\dec_ch1/n71 [32],\dec_ch1/n71 [33]}),
    .q({\dec_ch1/i2 [45],\dec_ch1/i2 [46]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b47|dec_ch1/reg20_b43  (
    .c({\dec_ch1/i3 [35],\dec_ch1/i3 [37]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n73 [47],\dec_ch1/n76 [43]}),
    .f({\dec_ch1/n74 [35],\dec_ch1/n74 [37]}),
    .q({\dec_ch1/i2 [47],\dec_ch1/i3 [43]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b4|dec_ch1/reg19_b2  (
    .a({\dec_ch1/i2 [4],open_n9458}),
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n9462,\dec_ch1/i2 [6]}),
    .mi({\dec_ch1/n73 [4],\dec_ch1/n73 [2]}),
    .f({\dec_ch1/n71 [4],\dec_ch1/n71 [6]}),
    .q({\dec_ch1/i2 [4],\dec_ch1/i2 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg19_b5|dec_ch1/reg19_b9  (
    .a({\dec_ch1/i2 [5],\dec_ch1/i2 [9]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .mi({\dec_ch1/n73 [5],\dec_ch1/n73 [9]}),
    .f({\dec_ch1/n71 [5],\dec_ch1/n71 [9]}),
    .q({\dec_ch1/i2 [5],\dec_ch1/i2 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg19_b8|dec_ch1/reg19_b19  (
    .a({\dec_ch1/i2 [8],open_n9500}),
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n9504,\dec_ch1/i2 [13]}),
    .mi({\dec_ch1/n73 [8],\dec_ch1/n73 [19]}),
    .f({\dec_ch1/n71 [8],\dec_ch1/n71 [13]}),
    .q({\dec_ch1/i2 [8],\dec_ch1/i2 [19]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg1_b0  (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n9531,\dec_ch1/pa [0]}),
    .q({open_n9549,pair_l1[0]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg1_b1|dec_ch1/reg1_b2  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pa [1],\dec_ch1/pa [2]}),
    .q({pair_l1[1],pair_l1[2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg1_b3|dec_ch1/reg1_b4  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pa [3],\dec_ch1/pa [4]}),
    .q({pair_l1[3],pair_l1[4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg1_b5|dec_ch1/reg1_b7  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pa [5],\dec_ch1/pa [7]}),
    .q({pair_l1[5],pair_l1[7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg20_b0|dec_ch1/reg20_b2  (
    .b({open_n9627,\dec_ch1/i3 [6]}),
    .c({\dec_order[1]_hfnopt2_0 ,\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [0],open_n9629}),
    .mi({\dec_ch1/n76 [0],\dec_ch1/n76 [2]}),
    .f({\dec_ch1/n71 [0],\dec_ch1/n74 [6]}),
    .q({\dec_ch1/i3 [0],\dec_ch1/i3 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b15|dec_ch1/reg20_b17  (
    .a({\dec_ch1/i3 [15],\dec_ch1/i3 [17]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n76 [15],\dec_ch1/n76 [17]}),
    .f({\dec_ch1/n74 [15],\dec_ch1/n74 [17]}),
    .q({\dec_ch1/i3 [15],\dec_ch1/i3 [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg20_b16|dec_ch1/reg20_b18  (
    .a({\dec_ch1/i3 [16],\dec_ch1/i3 [18]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n76 [16],\dec_ch1/n76 [18]}),
    .f({\dec_ch1/n74 [16],\dec_ch1/n74 [18]}),
    .q({\dec_ch1/i3 [16],\dec_ch1/i3 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b1|dec_ch1/reg20_b10  (
    .c({\dec_order[1]_hfnopt2_0 ,\dec_order[1]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [1],\dec_ch1/i2 [2]}),
    .mi({\dec_ch1/n76 [1],\dec_ch1/n76 [10]}),
    .f({\dec_ch1/n71 [1],\dec_ch1/n71 [2]}),
    .q({\dec_ch1/i3 [1],\dec_ch1/i3 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b22|dec_ch1/reg20_b29  (
    .a({\dec_ch1/i3 [22],open_n9709}),
    .c({open_n9712,\dec_ch1/i3 [25]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [22],\dec_ch1/n76 [29]}),
    .f({\dec_ch1/n74 [22],\dec_ch1/n74 [25]}),
    .q({\dec_ch1/i3 [22],\dec_ch1/i3 [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg20_b23|dec_ch1/reg20_b32  (
    .a({\dec_ch1/i3 [23],open_n9732}),
    .c({open_n9735,\dec_ch1/i3 [27]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [23],\dec_ch1/n76 [32]}),
    .f({\dec_ch1/n74 [23],\dec_ch1/n74 [27]}),
    .q({\dec_ch1/i3 [23],\dec_ch1/i3 [32]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b28|dec_ch1/reg20_b30  (
    .c({\dec_ch1/i3 [24],\dec_ch1/i3 [26]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [28],\dec_ch1/n76 [30]}),
    .f({\dec_ch1/n74 [24],\dec_ch1/n74 [26]}),
    .q({\dec_ch1/i3 [28],\dec_ch1/i3 [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b3|dec_ch1/reg20_b4  (
    .c({\dec_ch1/i3 [1],\dec_ch1/i3 [2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [3],\dec_ch1/n76 [4]}),
    .f({\dec_ch1/n74 [1],\dec_ch1/n74 [2]}),
    .q({\dec_ch1/i3 [3],\dec_ch1/i3 [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg20_b40|dec_ch1/reg20_b44  (
    .c({\dec_ch1/i3 [36],\dec_ch1/i3 [38]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [40],\dec_ch1/n76 [44]}),
    .f({\dec_ch1/n74 [36],\dec_ch1/n74 [38]}),
    .q({\dec_ch1/i3 [40],\dec_ch1/i3 [44]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b41|dec_ch1/reg20_b42  (
    .c({\dec_ch1/i3 [32],\dec_ch1/i3 [34]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [41],\dec_ch1/n76 [42]}),
    .f({\dec_ch1/n74 [32],\dec_ch1/n74 [34]}),
    .q({\dec_ch1/i3 [41],\dec_ch1/i3 [42]}));  // zaklad.v(277)
  // zaklad.v(1596)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b47|reg17_b2_hfnopt2_4  (
    .c({\dec_ch1/i3 [41],\dec_ch1/i3 [42]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [47],\dec_sv[1]_hfnopt2_3 }),
    .f({\dec_ch1/n74 [41],\dec_ch1/n74 [42]}),
    .q({\dec_ch1/i3 [47],\dec_sv[2]_hfnopt2_4 }));  // zaklad.v(1596)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg20_b5|dec_ch1/reg20_b6  (
    .c({\dec_ch1/i3 [3],\dec_ch1/i3 [4]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n76 [5],\dec_ch1/n76 [6]}),
    .f({\dec_ch1/n74 [3],\dec_ch1/n74 [4]}),
    .q({\dec_ch1/i3 [5],\dec_ch1/i3 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b10|dec_ch1/reg21_b14  (
    .c({\dec_ch1/i3 [5],\dec_ch1/i3 [0]}),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/i3 [10],\dec_ch1/i3 [14]}),
    .f({\dec_ch1/n74 [5],\dec_ch1/n74 [0]}),
    .q({\dec_ch1/d0 [10],\dec_ch1/d0 [14]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b11  (
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n9918,\dec_ch1/i3 [11]}),
    .q({open_n9936,\dec_ch1/d0 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg21_b16|dec_ch1/reg21_b18  (
    .c({\dec_ch1/i3 [19],\dec_ch1/i3 [21]}),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/i3 [16],\dec_ch1/i3 [18]}),
    .f({\dec_ch1/n74 [19],\dec_ch1/n74 [21]}),
    .q({\dec_ch1/d0 [16],\dec_ch1/d0 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg21_b25|dec_ch1/reg21_b31  (
    .b({open_n9957,\dec_ch1/i2 [34]}),
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [28],open_n9958}),
    .mi({\dec_ch1/i3 [25],\dec_ch1/i3 [31]}),
    .f({\dec_ch1/n71 [28],\dec_ch1/n71 [34]}),
    .q({\dec_ch1/d0 [25],\dec_ch1/d0 [31]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg21_b26  (
    .c({open_n9977,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n9978,\dec_ch1/i2 [30]}),
    .mi({open_n9989,\dec_ch1/i3 [26]}),
    .f({open_n9991,\dec_ch1/n71 [30]}),
    .q({open_n9995,\dec_ch1/d0 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b33|dec_ch1/reg21_b39  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [36],\dec_ch1/i2 [38]}),
    .mi({\dec_ch1/i3 [33],\dec_ch1/i3 [39]}),
    .f({\dec_ch1/n71 [36],\dec_ch1/n71 [38]}),
    .q({\dec_ch1/d0 [33],\dec_ch1/d0 [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b35|dec_ch1/reg21_b38  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [0],\dec_ch2/c1p [3]}),
    .mi({\dec_ch1/i3 [35],\dec_ch1/i3 [38]}),
    .f({\dec_ch2/n81 [0],\dec_ch2/n81 [3]}),
    .q({\dec_ch1/d0 [35],\dec_ch1/d0 [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg21_b36|dec_ch1/reg21_b37  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [1],\dec_ch2/c1p [2]}),
    .mi({\dec_ch1/i3 [36],\dec_ch1/i3 [37]}),
    .f({\dec_ch2/n81 [1],\dec_ch2/n81 [2]}),
    .q({\dec_ch1/d0 [36],\dec_ch1/d0 [37]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b40|dec_ch1/reg21_b41  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [39],\dec_ch1/i2 [40]}),
    .mi({\dec_ch1/i3 [40],\dec_ch1/i3 [41]}),
    .f({\dec_ch1/n71 [39],\dec_ch1/n71 [40]}),
    .q({\dec_ch1/d0 [40],\dec_ch1/d0 [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg21_b42|dec_ch1/reg21_b43  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [41],\dec_ch1/i2 [42]}),
    .mi({\dec_ch1/i3 [42],\dec_ch1/i3 [43]}),
    .f({\dec_ch1/n71 [41],\dec_ch1/n71 [42]}),
    .q({\dec_ch1/d0 [42],\dec_ch1/d0 [43]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b44|dec_ch1/reg21_b47  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [43],\dec_ch1/i2 [46]}),
    .mi({\dec_ch1/i3 [44],\dec_ch1/i3 [47]}),
    .f({\dec_ch1/n71 [43],\dec_ch1/n71 [46]}),
    .q({\dec_ch1/d0 [44],\dec_ch1/d0 [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg21_b45|dec_ch1/reg21_b46  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[0]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [44],\dec_ch1/i2 [45]}),
    .mi({\dec_ch1/i3 [45],\dec_ch1/i3 [46]}),
    .f({\dec_ch1/n71 [44],\dec_ch1/n71 [45]}),
    .q({\dec_ch1/d0 [45],\dec_ch1/d0 [46]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg21_b8  (
    .c({open_n10142,\dec_ch1/i3 [14]}),
    .ce(\dec_sv[0]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n10143,\dec_ch1/k3_lutinv }),
    .mi({open_n10147,\dec_ch1/i3 [8]}),
    .f({open_n10160,\dec_ch1/n74 [14]}),
    .q({open_n10164,\dec_ch1/d0 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b12|dec_ch1/reg22_b9  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [4],\dec_ch1/c1p [6]}),
    .mi({\dec_ch1/n78 [12],\dec_ch1/n78 [9]}),
    .f({\dec_ch1/n81 [4],\dec_ch1/n81 [6]}),
    .q({\dec_ch1/c1 [12],\dec_ch1/c1 [9]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b14  (
    .c({open_n10187,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n10188,\dec_ch1/c1p [5]}),
    .mi({open_n10192,\dec_ch1/n78 [14]}),
    .f({open_n10205,\dec_ch1/n81 [5]}),
    .q({open_n10209,\dec_ch1/c1 [14]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b15  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n10228,\dec_ch1/n78 [15]}),
    .q({open_n10235,\dec_ch1/c1 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b16|dec_ch1/reg22_b19  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n78 [16],\dec_ch1/n78 [19]}),
    .q({\dec_ch1/c1 [16],\dec_ch1/c1 [19]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b17|dec_ch1/reg22_b18  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n78 [17],\dec_ch1/n78 [18]}),
    .q({\dec_ch1/c1 [17],\dec_ch1/c1 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b20|dec_ch1/reg22_b22  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [10],\dec_ch1/c1p [8]}),
    .mi({\dec_ch1/n78 [20],\dec_ch1/n78 [22]}),
    .f({\dec_ch1/n81 [10],\dec_ch1/n81 [8]}),
    .q({\dec_ch1/c1 [20],\dec_ch1/c1 [22]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b21  (
    .c({open_n10310,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n10311,\dec_ch1/c1p [7]}),
    .mi({open_n10322,\dec_ch1/n78 [21]}),
    .f({open_n10324,\dec_ch1/n81 [7]}),
    .q({open_n10328,\dec_ch1/c1 [21]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b23|dec_ch1/reg22_b24  (
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n78 [23],\dec_ch1/n78 [24]}),
    .q({\dec_ch1/c1 [23],\dec_ch1/c1 [24]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b25|dec_ch1/reg22_b26  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [11],\dec_ch1/c1p [13]}),
    .mi({\dec_ch1/n78 [25],\dec_ch1/n78 [26]}),
    .f({\dec_ch1/n81 [11],\dec_ch1/n81 [13]}),
    .q({\dec_ch1/c1 [25],\dec_ch1/c1 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b29|dec_ch1/reg22_b30  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [28],\dec_ch1/c1p [30]}),
    .mi({\dec_ch1/n78 [29],\dec_ch1/n78 [30]}),
    .f({\dec_ch1/n81 [28],\dec_ch1/n81 [30]}),
    .q({\dec_ch1/c1 [29],\dec_ch1/c1 [30]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b31  (
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n10412,\dec_ch1/n78 [31]}),
    .q({open_n10430,\dec_ch1/c1 [31]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg22_b32|dec_ch1/reg23_b29  (
    .c({\dec_ch1/n59 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({n152,\dec_ch1/c1p [41]}),
    .mi({\dec_ch1/n78 [32],\dec_ch1/d0 [29]}),
    .f({\dec_ch1/mux11_b0_sel_is_0_o ,\dec_ch1/n81 [41]}),
    .q({\dec_ch1/c1 [32],\dec_ch1/d0p [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b37|dec_ch1/reg22_b38  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [35],\dec_ch1/c1p [37]}),
    .mi({\dec_ch1/n78 [37],\dec_ch1/n78 [38]}),
    .f({\dec_ch1/n81 [35],\dec_ch1/n81 [37]}),
    .q({\dec_ch1/c1 [37],\dec_ch1/c1 [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg22_b39|dec_ch1/reg22_b40  (
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n78 [39],\dec_ch1/n78 [40]}),
    .q({\dec_ch1/c1 [39],\dec_ch1/c1 [40]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg23_b0|dec_ch1/reg23_b6  (
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n22 [7],\dec_ch1/n21 }),
    .mi({\dec_ch1/d0 [0],\dec_ch1/d0 [6]}),
    .f({\dec_ch1/t_pl [8],\dec_ch1/t_pl [9]}),
    .q({\dec_ch1/d0p [0],\dec_ch1/d0p [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg23_b27|dec_ch1/reg23_b34  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [39],\dec_ch2/pl [0]}),
    .mi({\dec_ch1/d0 [27],\dec_ch1/d0 [34]}),
    .f({\dec_ch1/n81 [39],\dec_ch2/t_pl [0]}),
    .q({\dec_ch1/d0p [27],\dec_ch1/d0p [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg23_b28|dec_ch1/reg23_b30  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [40],\dec_ch1/c1p [42]}),
    .mi({\dec_ch1/d0 [28],\dec_ch1/d0 [30]}),
    .f({\dec_ch1/n81 [40],\dec_ch1/n81 [42]}),
    .q({\dec_ch1/d0p [28],\dec_ch1/d0p [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg23_b35|dec_ch1/reg23_b38  (
    .a({\dec_ch2/n22 [1],\dec_ch2/n22 [2]}),
    .b({\dec_ch2/pl [2],\dec_ch2/pl [3]}),
    .c({dec_order[0],dec_order[0]}),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .mi({\dec_ch1/d0 [35],\dec_ch1/d0 [38]}),
    .f({\dec_ch2/t_pl [2],\dec_ch2/t_pl [3]}),
    .q({\dec_ch1/d0p [35],\dec_ch1/d0p [38]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg23_b40  (
    .a({open_n10571,dec_order[0]}),
    .b({open_n10572,\dec_ch2/pl [4]}),
    .c({open_n10573,\dec_ch2/n22 [3]}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n10574,\dec_order[1]_hfnopt2_3 }),
    .mi({open_n10578,\dec_ch1/d0 [40]}),
    .f({open_n10591,\dec_ch2/t_pl [4]}),
    .q({open_n10595,\dec_ch1/d0p [40]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg23_b41|dec_ch1/reg23_b42  (
    .a({\dec_ch2/n22 [4],\dec_ch2/n22 [5]}),
    .b({\dec_ch2/pl [5],\dec_ch2/pl [6]}),
    .c({dec_order[0],dec_order[0]}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .mi({\dec_ch1/d0 [41],\dec_ch1/d0 [42]}),
    .f({\dec_ch2/t_pl [5],\dec_ch2/t_pl [6]}),
    .q({\dec_ch1/d0p [41],\dec_ch1/d0p [42]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg23_b43|dec_ch1/reg23_b46  (
    .a({\dec_ch2/n22 [6],open_n10614}),
    .b({\dec_ch2/pl [7],\dec_ch2/n22 [7]}),
    .c({dec_order[0],open_n10615}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_3 ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/d0 [43],\dec_ch1/d0 [46]}),
    .f({\dec_ch2/t_pl [7],\dec_ch2/t_pl [8]}),
    .q({\dec_ch1/d0p [43],\dec_ch1/d0p [46]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b0|dec_ch1/reg24_b2  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [0],\dec_ch1/n82 [2]}),
    .q({\dec_ch1/c2 [0],\dec_ch1/c2 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b11|dec_ch1/reg24_b14  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [11],\dec_ch1/n82 [14]}),
    .q({\dec_ch1/c2 [11],\dec_ch1/c2 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b12|dec_ch1/reg24_b13  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [12],\dec_ch1/n82 [13]}),
    .q({\dec_ch1/c2 [12],\dec_ch1/c2 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b15|dec_ch1/reg24_b18  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [15],\dec_ch1/n82 [18]}),
    .q({\dec_ch1/c2 [15],\dec_ch1/c2 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b16|dec_ch1/reg24_b17  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [16],\dec_ch1/n82 [17]}),
    .q({\dec_ch1/c2 [16],\dec_ch1/c2 [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b1|dec_ch1/reg24_b10  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [1],\dec_ch1/n82 [10]}),
    .q({\dec_ch1/c2 [1],\dec_ch1/c2 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b22|dec_ch1/reg24_b25  (
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n82 [22],\dec_ch1/n82 [25]}),
    .q({\dec_ch1/c2 [22],\dec_ch1/c2 [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b23|dec_ch1/reg24_b29  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [16],\dec_ch1/c1p [22]}),
    .mi({\dec_ch1/n82 [23],\dec_ch1/n82 [29]}),
    .f({\dec_ch1/n81 [16],\dec_ch1/n81 [22]}),
    .q({\dec_ch1/c2 [23],\dec_ch1/c2 [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b24|dec_ch1/reg24_b26  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [17],\dec_ch1/c1p [18]}),
    .mi({\dec_ch1/n82 [24],\dec_ch1/n82 [26]}),
    .f({\dec_ch1/n81 [17],\dec_ch1/n81 [18]}),
    .q({\dec_ch1/c2 [24],\dec_ch1/c2 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b27|dec_ch1/reg25_b20  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(\dec_ch1/c1p [20:19]),
    .mi({\dec_ch1/n82 [27],\dec_ch1/c1 [20]}),
    .f(\dec_ch1/n81 [20:19]),
    .q({\dec_ch1/c2 [27],\dec_ch1/c1p [20]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b28|dec_ch1/reg24_b31  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [21],\dec_ch1/c1p [25]}),
    .mi({\dec_ch1/n82 [28],\dec_ch1/n82 [31]}),
    .f({\dec_ch1/n81 [21],\dec_ch1/n81 [25]}),
    .q({\dec_ch1/c2 [28],\dec_ch1/c2 [31]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b3  (
    .c({open_n10894,\dec_ch1/pe [7]}),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n10895,\dec_ch1/k3_lutinv }),
    .mi({open_n10899,\dec_ch1/n82 [3]}),
    .f({open_n10912,\dec_ch1/t_pe [7]}),
    .q({open_n10916,\dec_ch1/c2 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b30|dec_ch1/reg24_b32  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [38],\dec_ch1/c1p [36]}),
    .mi({\dec_ch1/n82 [30],\dec_ch1/n82 [32]}),
    .f({\dec_ch1/n81 [38],\dec_ch1/n81 [36]}),
    .q({\dec_ch1/c2 [30],\dec_ch1/c2 [32]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b33|dec_ch1/reg25_b34  (
    .a({\dec_ch1/c1p [32],open_n10935}),
    .c({open_n10938,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_1 ,\dec_ch1/c1p [33]}),
    .mi({\dec_ch1/n82 [33],\dec_ch1/c1 [34]}),
    .f({\dec_ch1/n81 [32],\dec_ch1/n81 [33]}),
    .q({\dec_ch1/c2 [33],\dec_ch1/c1p [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b34|dec_ch1/reg24_b38  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [27],\dec_ch1/c1p [23]}),
    .mi({\dec_ch1/n82 [34],\dec_ch1/n82 [38]}),
    .f({\dec_ch1/n81 [27],\dec_ch1/n81 [23]}),
    .q({\dec_ch1/c2 [34],\dec_ch1/c2 [38]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b35  (
    .c({open_n10979,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n10980,\dec_ch1/c1p [29]}),
    .mi({open_n10991,\dec_ch1/n82 [35]}),
    .f({open_n10993,\dec_ch1/n81 [29]}),
    .q({open_n10997,\dec_ch1/c2 [35]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b39  (
    .c({open_n11002,\dec_ch1/c2p [35]}),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11003,\dec_ch1/k3_lutinv }),
    .mi({open_n11007,\dec_ch1/n82 [39]}),
    .f({open_n11020,\dec_ch1/n85 [35]}),
    .q({open_n11024,\dec_ch1/c2 [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b40|dec_ch1/reg24_b42  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_ch1/c2p [41]}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [31],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n82 [40],\dec_ch1/n82 [42]}),
    .f({\dec_ch1/n81 [31],\dec_ch1/n85 [41]}),
    .q({\dec_ch1/c2 [40],\dec_ch1/c2 [42]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b41|dec_ch1/reg25_b40  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [43],\dec_ch1/c1p [46]}),
    .mi({\dec_ch1/n82 [41],\dec_ch1/c1 [40]}),
    .f({\dec_ch1/n81 [43],\dec_ch1/n81 [46]}),
    .q({\dec_ch1/c2 [41],\dec_ch1/c1p [40]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b43|dec_ch1/reg25_b39  (
    .a({\dec_ch1/c1p [44],open_n11069}),
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11072,\dec_ch1/c1p [45]}),
    .mi({\dec_ch1/n82 [43],\dec_ch1/c1 [39]}),
    .f({\dec_ch1/n81 [44],\dec_ch1/n81 [45]}),
    .q({\dec_ch1/c2 [43],\dec_ch1/c1p [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b46|dec_ch1/reg24_b47  (
    .c({\dec_ch1/c2p [44],\dec_ch1/c2p [45]}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n82 [46],\dec_ch1/n82 [47]}),
    .f({\dec_ch1/n85 [44],\dec_ch1/n85 [45]}),
    .q({\dec_ch1/c2 [46],\dec_ch1/c2 [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg24_b4|dec_ch1/reg24_b6  (
    .a({open_n11105,dec_order[0]}),
    .b({open_n11106,pair_e1[5]}),
    .c({\dec_ch1/pe [1],pair_e1[6]}),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/n19 [5]}),
    .e({open_n11107,\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/n82 [4],\dec_ch1/n82 [6]}),
    .f({\dec_ch1/t_pe [1],\dec_ch1/t_xe [6]}),
    .q({\dec_ch1/c2 [4],\dec_ch1/c2 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg24_b5|dec_ch1/reg24_b7  (
    .c({\dec_ch1/pe [5],\dec_ch1/pe [6]}),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/n82 [5],\dec_ch1/n82 [7]}),
    .f({\dec_ch1/t_pe [5],\dec_ch1/t_pe [6]}),
    .q({\dec_ch1/c2 [5],\dec_ch1/c2 [7]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg25_b13  (
    .c({open_n11146,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11147,\dec_ch1/c1p [12]}),
    .mi({open_n11151,\dec_ch1/c1 [13]}),
    .f({open_n11164,\dec_ch1/n81 [12]}),
    .q({open_n11168,\dec_ch1/c1p [13]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg25_b15  (
    .a({open_n11169,\dec_ch1/c1p [15]}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11174,\dec_order[1]_hfnopt2_1 }),
    .mi({open_n11185,\dec_ch1/c1 [15]}),
    .f({open_n11187,\dec_ch1/n81 [15]}),
    .q({open_n11191,\dec_ch1/c1p [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg25_b1|dec_ch1/reg25_b6  (
    .a({open_n11192,\dec_ch1/n22 [6]}),
    .b({open_n11193,\dec_ch1/pl [7]}),
    .c({\dec_order[1]_hfnopt2_1 ,dec_order[0]}),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [0],\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/c1 [1],\dec_ch1/c1 [6]}),
    .f({\dec_ch1/n81 [0],\dec_ch1/t_pl [7]}),
    .q({\dec_ch1/c1p [1],\dec_ch1/c1p [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg25_b28|dec_ch1/reg25_b30  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [34],\dec_ch1/c1p [24]}),
    .mi({\dec_ch1/c1 [28],\dec_ch1/c1 [30]}),
    .f({\dec_ch1/n81 [34],\dec_ch1/n81 [24]}),
    .q({\dec_ch1/c1p [28],\dec_ch1/c1p [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg25_b2|dec_ch1/reg25_b5  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [1],\dec_ch1/c1p [3]}),
    .mi({\dec_ch1/c1 [2],\dec_ch1/c1 [5]}),
    .f({\dec_ch1/n81 [1],\dec_ch1/n81 [3]}),
    .q({\dec_ch1/c1p [2],\dec_ch1/c1p [5]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg25_b4  (
    .c({open_n11256,\dec_order[1]_hfnopt2_1 }),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11257,\dec_ch1/c1p [2]}),
    .mi({open_n11268,\dec_ch1/c1 [4]}),
    .f({open_n11270,\dec_ch1/n81 [2]}),
    .q({open_n11274,\dec_ch1/c1p [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg25_b44|dec_ch1/reg25_b43  (
    .a({open_n11275,\dec_ch2/n19 [2]}),
    .b({open_n11276,pair_e2[2]}),
    .c({\dec_ch1/k3_lutinv ,pair_e2[3]}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n21 ,dec_order[0]}),
    .e({open_n11277,\dec_order[1]_hfnopt2_3 }),
    .mi(\dec_ch1/c1 [44:43]),
    .f({\dec_ch2/t_pl [9],\dec_ch2/t_xe [3]}),
    .q(\dec_ch1/c1p [44:43]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg25_b47|dec_ch2/reg15_b8  (
    .a({\dec_ch1/c1p [47],open_n11294}),
    .b({open_n11295,dec_order[0]}),
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11296,pair_e2[0]}),
    .mi({\dec_ch1/c1 [47],\dec_ch2/pk1 [8]}),
    .f({\dec_ch1/n81 [47],\dec_ch2/t_xe [0]}),
    .q({\dec_ch1/c1p [47],\dec_ch2/pk2 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg25_b9|dec_ch1/reg24_b19  (
    .a({\dec_ch1/c1p [9],\dec_ch1/n19 [7]}),
    .b({open_n11311,pair_e1[7]}),
    .c({open_n11312,dec_order[0]}),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/c1 [9],\dec_ch1/n82 [19]}),
    .f({\dec_ch1/n81 [9],\dec_ch1/t_xe [8]}),
    .q({\dec_ch1/c1p [9],\dec_ch1/c2 [19]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b0|dec_ch1/reg26_b1  (
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [0],\dec_ch1/n86 [1]}),
    .q({\dec_ch1/c3 [0],\dec_ch1/c3 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b10|dec_ch1/reg26_b11  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [10],\dec_ch1/n86 [11]}),
    .q({\dec_ch1/c3 [10],\dec_ch1/c3 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg26_b12|dec_ch1/reg26_b14  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [12],\dec_ch1/n86 [14]}),
    .q({\dec_ch1/c3 [12],\dec_ch1/c3 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b13|dec_ch1/reg26_b39  (
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [13],\dec_ch1/n86 [39]}),
    .q({\dec_ch1/c3 [13],\dec_ch1/c3 [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg26_b15|dec_ch1/reg26_b16  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [15],\dec_ch1/n86 [16]}),
    .q({\dec_ch1/c3 [15],\dec_ch1/c3 [16]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b17|dec_ch1/reg26_b23  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [17],\dec_ch1/n86 [23]}),
    .q({\dec_ch1/c3 [17],\dec_ch1/c3 [23]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b18|dec_ch1/reg26_b19  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [18],\dec_ch1/n86 [19]}),
    .q({\dec_ch1/c3 [18],\dec_ch1/c3 [19]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg26_b26  (
    .c({open_n11507,\dec_ch1/c2p [36]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11508,\dec_ch1/k3_lutinv }),
    .mi({open_n11512,\dec_ch1/n86 [26]}),
    .f({open_n11525,\dec_ch1/n85 [36]}),
    .q({open_n11529,\dec_ch1/c3 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b38|dec_ch1/reg26_b41  (
    .b({\dec_ch1/c3 [8],\dec_ch1/c3 [24]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [0],\dec_ch1/c3 [16]}),
    .mi({\dec_ch1/n86 [38],\dec_ch1/n86 [41]}),
    .f({_al_u981_o,\dec_ch1/n144_lutinv }),
    .q({\dec_ch1/c3 [38],\dec_ch1/c3 [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg26_b3|dec_ch1/reg26_b34  (
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/n86 [3],\dec_ch1/n86 [34]}),
    .q({\dec_ch1/c3 [3],\dec_ch1/c3 [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg26_b45|dec_ch1/reg26_b5  (
    .a({open_n11574,\dec_ch1/n136_lutinv }),
    .b({\dec_ch1/c3 [9],\dec_ch1/c3 [16]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_ch1/c3 [8]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [1],\dec_shift[3]_hfnopt2_0 }),
    .e({open_n11575,dec_shift[4]}),
    .mi({\dec_ch1/n86 [45],\dec_ch1/n86 [5]}),
    .f({_al_u979_o,\dec_ch1/n95_lutinv }),
    .q({\dec_ch1/c3 [45],\dec_ch1/c3 [5]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg26_b6  (
    .c({open_n11596,\dec_ch1/c2p [23]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11597,\dec_ch1/k3_lutinv }),
    .mi({open_n11608,\dec_ch1/n86 [6]}),
    .f({open_n11610,\dec_ch1/n85 [23]}),
    .q({open_n11614,\dec_ch1/c3 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b0|dec_ch1/reg27_b3  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [0],\dec_ch1/c2 [3]}),
    .q({\dec_ch1/c2p [0],\dec_ch1/c2p [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b11|dec_ch1/reg27_b14  (
    .a({\dec_ch1/c2p [11],\dec_ch1/c2p [14]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [11],\dec_ch1/c2 [14]}),
    .f({\dec_ch1/n85 [11],\dec_ch1/n85 [14]}),
    .q({\dec_ch1/c2p [11],\dec_ch1/c2p [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b12|dec_ch1/reg27_b13  (
    .a({\dec_ch1/c2p [12],\dec_ch1/c2p [13]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [12],\dec_ch1/c2 [13]}),
    .f({\dec_ch1/n85 [12],\dec_ch1/n85 [13]}),
    .q({\dec_ch1/c2p [12],\dec_ch1/c2p [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b15|dec_ch1/reg26_b24  (
    .a({\dec_ch1/c2p [15],open_n11679}),
    .c({open_n11682,\dec_ch1/c2p [22]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [15],\dec_ch1/n86 [24]}),
    .f({\dec_ch1/n85 [15],\dec_ch1/n85 [22]}),
    .q({\dec_ch1/c2p [15],\dec_ch1/c3 [24]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b16|dec_ch1/reg27_b18  (
    .a({\dec_ch1/c2p [16],\dec_ch1/c2p [18]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [16],\dec_ch1/c2 [18]}),
    .f({\dec_ch1/n85 [16],\dec_ch1/n85 [18]}),
    .q({\dec_ch1/c2p [16],\dec_ch1/c2p [18]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b17  (
    .a({open_n11723,\dec_ch1/c2p [17]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11728,\dec_ch1/k3_lutinv }),
    .mi({open_n11732,\dec_ch1/c2 [17]}),
    .f({open_n11745,\dec_ch1/n85 [17]}),
    .q({open_n11749,\dec_ch1/c2p [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b19|dec_ch1/reg27_b21  (
    .a({\dec_ch1/c2p [19],\dec_ch1/c2p [21]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [19],\dec_ch1/c2 [21]}),
    .f({\dec_ch1/n85 [19],\dec_ch1/n85 [21]}),
    .q({\dec_ch1/c2p [19],\dec_ch1/c2p [21]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b1|dec_ch1/reg27_b2  (
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [1],\dec_ch1/c2 [2]}),
    .q({\dec_ch1/c2p [1],\dec_ch1/c2p [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b23|dec_ch1/reg27_b27  (
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/c2p [30]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c2p [27],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [23],\dec_ch1/c2 [27]}),
    .f({\dec_ch1/n85 [27],\dec_ch1/n85 [30]}),
    .q({\dec_ch1/c2p [23],\dec_ch1/c2p [27]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b24|dec_ch1/reg27_b28  (
    .a({\dec_ch1/c2p [24],open_n11818}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/c2p [29]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11821,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [24],\dec_ch1/c2 [28]}),
    .f({\dec_ch1/n85 [24],\dec_ch1/n85 [29]}),
    .q({\dec_ch1/c2p [24],\dec_ch1/c2p [28]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b26|dec_ch1/reg27_b29  (
    .c({\dec_ch1/c2p [28],\dec_ch1/c2p [25]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [26],\dec_ch1/c2 [29]}),
    .f({\dec_ch1/n85 [28],\dec_ch1/n85 [25]}),
    .q({\dec_ch1/c2p [26],\dec_ch1/c2p [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b31|dec_ch1/reg27_b33  (
    .a({\dec_ch1/c2p [31],\dec_ch1/c2p [33]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [31],\dec_ch1/c2 [33]}),
    .f({\dec_ch1/n85 [31],\dec_ch1/n85 [33]}),
    .q({\dec_ch1/c2p [31],\dec_ch1/c2p [33]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b32|dec_ch1/reg27_b34  (
    .a({\dec_ch1/c2p [32],\dec_ch1/c2p [34]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [32],\dec_ch1/c2 [34]}),
    .f({\dec_ch1/n85 [32],\dec_ch1/n85 [34]}),
    .q({\dec_ch1/c2p [32],\dec_ch1/c2p [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b37|dec_ch1/reg27_b38  (
    .a({\dec_ch1/c2p [37],\dec_ch1/c2p [38]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [37],\dec_ch1/c2 [38]}),
    .f({\dec_ch1/n85 [37],\dec_ch1/n85 [38]}),
    .q({\dec_ch1/c2p [37],\dec_ch1/c2p [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b42|dec_ch1/reg27_b40  (
    .b({\dec_ch1/c3 [28],open_n11914}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_ch1/c2p [43]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [20],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [42],\dec_ch1/c2 [40]}),
    .f({\dec_ch1/n140_lutinv ,\dec_ch1/n85 [43]}),
    .q({\dec_ch1/c2p [42],\dec_ch1/c2p [40]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b43|dec_ch1/reg27_b39  (
    .b({\dec_ch1/c3 [36],open_n11931}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_ch1/c2p [40]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [28],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [43],\dec_ch1/c2 [39]}),
    .f({\dec_ch1/n123_lutinv ,\dec_ch1/n85 [40]}),
    .q({\dec_ch1/c2p [43],\dec_ch1/c2p [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg27_b44|dec_ch1/reg27_b41  (
    .b({\dec_ch1/c3 [2],open_n11952}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_ch1/c2p [46]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [10],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [44],\dec_ch1/c2 [41]}),
    .f({_al_u977_o,\dec_ch1/n85 [46]}),
    .q({\dec_ch1/c2p [44],\dec_ch1/c2p [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b45|dec_ch1/reg27_b46  (
    .c({\dec_ch2/pe [0],\dec_ch2/pe [3]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [45],\dec_ch1/c2 [46]}),
    .f({\dec_ch2/t_pe [0],\dec_ch2/t_pe [3]}),
    .q({\dec_ch1/c2p [45],\dec_ch1/c2p [46]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b47  (
    .b({open_n11991,\dec_ch1/c3 [34]}),
    .c({open_n11992,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n11993,\dec_ch1/c3 [26]}),
    .mi({open_n11997,\dec_ch1/c2 [47]}),
    .f({open_n12010,\dec_ch1/n125_lutinv }),
    .q({open_n12014,\dec_ch1/c2p [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b4|dec_ch1/reg27_b7  (
    .c(\dec_ch1/c2p [10:9]),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [4],\dec_ch1/c2 [7]}),
    .f(\dec_ch1/n85 [10:9]),
    .q({\dec_ch1/c2p [4],\dec_ch1/c2p [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg27_b5|dec_ch1/reg27_b6  (
    .c({\dec_ch1/c2p [7],\dec_ch1/c2p [8]}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch1/c2 [5],\dec_ch1/c2 [6]}),
    .f({\dec_ch1/n85 [7],\dec_ch1/n85 [8]}),
    .q({\dec_ch1/c2p [5],\dec_ch1/c2p [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b0|dec_ch1/reg28_b4  (
    .a({\dec_ch1/n119_lutinv ,\dec_ch1/n115_lutinv }),
    .b({\dec_ch1/n144_lutinv ,\dec_ch1/n140_lutinv }),
    .c({_al_u981_o,_al_u973_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [0],\dec_ch1/sh [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b10|dec_ch1/reg28_b12  (
    .a({\dec_ch1/n16_lutinv ,\dec_ch1/n14_lutinv }),
    .b({\dec_ch1/c3 [42],\dec_ch1/c3 [44]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [10],\dec_ch1/sh [12]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b11|dec_ch1/reg28_b8  (
    .a({\dec_ch1/n15_lutinv ,\dec_ch1/n95_lutinv }),
    .b({\dec_ch1/c3 [43],\dec_ch1/c3 [40]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [11],\dec_ch1/sh [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b15|dec_ch1/reg28_b31  (
    .a({\dec_ch1/n11_lutinv ,\dec_ch1/n120_lutinv }),
    .b({\dec_ch1/c3 [47],\dec_ch1/c3 [47]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [15],\dec_ch1/sh [31]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg28_b16|dec_ch1/reg28_b20  (
    .a({\dec_ch1/n119_lutinv ,\dec_ch1/n115_lutinv }),
    .b({\dec_ch1/n144_lutinv ,\dec_ch1/n140_lutinv }),
    .c({dec_shift[4],dec_shift[4]}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [16],\dec_ch1/sh [20]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg28_b17|dec_ch1/reg28_b21  (
    .a({\dec_ch1/n118_lutinv ,\dec_ch1/n114_lutinv }),
    .b({\dec_ch1/n143_lutinv ,\dec_ch1/n139_lutinv }),
    .c({dec_shift[4],dec_shift[4]}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [17],\dec_ch1/sh [21]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b18  (
    .a({open_n12175,\dec_ch1/n117_lutinv }),
    .b({open_n12176,\dec_ch1/n142_lutinv }),
    .c({open_n12177,dec_shift[4]}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n12178,dec_shift[5]}),
    .q({open_n12201,\dec_ch1/sh [18]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b2  (
    .a({open_n12202,\dec_ch1/n117_lutinv }),
    .b({open_n12203,\dec_ch1/n142_lutinv }),
    .c({open_n12204,_al_u977_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n12205,dec_shift[4]}),
    .e({open_n12206,dec_shift[5]}),
    .q({open_n12227,\dec_ch1/sh [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b22|dec_ch1/reg28_b27  (
    .a({\dec_ch1/n113_lutinv ,\dec_ch1/n124_lutinv }),
    .b({\dec_ch1/n138_lutinv ,\dec_ch1/c3 [43]}),
    .c({dec_shift[4],\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(dec_shift[5:4]),
    .e({open_n12228,dec_shift[5]}),
    .q({\dec_ch1/sh [22],\dec_ch1/sh [27]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b23|dec_ch1/reg28_b30  (
    .a({\dec_ch1/n112_lutinv ,\dec_ch1/n121_lutinv }),
    .b({\dec_ch1/n137_lutinv ,\dec_ch1/c3 [46]}),
    .c({dec_shift[4],\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(dec_shift[5:4]),
    .e({open_n12249,dec_shift[5]}),
    .q({\dec_ch1/sh [23],\dec_ch1/sh [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b26|dec_ch1/reg28_b28  (
    .a({\dec_ch1/n125_lutinv ,\dec_ch1/n123_lutinv }),
    .b({\dec_ch1/c3 [42],\dec_ch1/c3 [44]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [26],\dec_ch1/sh [28]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg28_b33|dec_ch1/reg28_b35  (
    .c({_al_u806_o,_al_u806_o}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n118_lutinv ,\dec_ch1/n116_lutinv }),
    .q({\dec_ch1/sh [33],\dec_ch1/sh [35]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b34|dec_ch1/reg28_b19  (
    .a({open_n12312,\dec_ch1/n116_lutinv }),
    .b({open_n12313,\dec_ch1/n141_lutinv }),
    .c({_al_u806_o,dec_shift[4]}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n117_lutinv ,dec_shift[5]}),
    .q({\dec_ch1/sh [34],\dec_ch1/sh [19]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b37|dec_ch1/reg28_b41  (
    .b({open_n12338,\dec_ch1/c3 [41]}),
    .c({_al_u806_o,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n114_lutinv ,_al_u806_o}),
    .q({\dec_ch1/sh [37],\dec_ch1/sh [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg28_b38|dec_ch1/reg28_b40  (
    .b({open_n12363,\dec_ch1/c3 [40]}),
    .c({_al_u806_o,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n113_lutinv ,_al_u806_o}),
    .q({\dec_ch1/sh [38],\dec_ch1/sh [40]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b39  (
    .c({open_n12386,_al_u806_o}),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n12387,\dec_ch1/n112_lutinv }),
    .q({open_n12410,\dec_ch1/sh [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b42|dec_ch1/reg28_b45  (
    .b({\dec_ch1/c3 [42],\dec_ch1/c3 [45]}),
    .c({\dec_shift[3]_hfnopt2_1 ,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u806_o,_al_u806_o}),
    .q({\dec_ch1/sh [42],\dec_ch1/sh [45]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b43|dec_ch1/reg28_b24  (
    .a({open_n12435,\dec_ch1/n136_lutinv }),
    .b({\dec_ch1/c3 [43],\dec_ch1/c3 [40]}),
    .c({\dec_shift[3]_hfnopt2_1 ,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u806_o,dec_shift[4]}),
    .e({open_n12436,dec_shift[5]}),
    .q({\dec_ch1/sh [43],\dec_ch1/sh [24]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b44|dec_ch1/reg28_b29  (
    .a({open_n12457,\dec_ch1/n122_lutinv }),
    .b({\dec_ch1/c3 [44],\dec_ch1/c3 [45]}),
    .c({\dec_shift[3]_hfnopt2_1 ,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u806_o,dec_shift[4]}),
    .e({open_n12458,dec_shift[5]}),
    .q({\dec_ch1/sh [44],\dec_ch1/sh [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg28_b46|dec_ch1/reg28_b47  (
    .b({\dec_ch1/c3 [46],\dec_ch1/c3 [47]}),
    .c({\dec_shift[3]_hfnopt2_1 ,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u806_o,_al_u806_o}),
    .q({\dec_ch1/sh [46],\dec_ch1/sh [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b5|dec_ch1/reg28_b13  (
    .a({\dec_ch1/n114_lutinv ,\dec_ch1/n13_lutinv }),
    .b({\dec_ch1/n139_lutinv ,\dec_ch1/c3 [45]}),
    .c({_al_u971_o,\dec_shift[3]_hfnopt2_1 }),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [5],\dec_ch1/sh [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg28_b6|dec_ch1/reg28_b14  (
    .a({\dec_ch1/n113_lutinv ,\dec_ch1/n12_lutinv }),
    .b({\dec_ch1/n138_lutinv ,\dec_ch1/c3 [46]}),
    .c({_al_u969_o,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch1/sh [6],\dec_ch1/sh [14]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg29_b10  (
    .a({open_n12539,_al_u1937_o}),
    .b({open_n12540,_al_u1890_o}),
    .c({open_n12541,\dec_ch1/pk4 [10]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({open_n12542,peak_en}),
    .q({open_n12565,cic_out1[10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg29_b11|dec_ch1/reg29_b13  (
    .a({_al_u1935_o,_al_u1931_o}),
    .b({_al_u1890_o,_al_u1890_o}),
    .c({\dec_ch1/pk4 [11],\dec_ch1/pk4 [13]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,peak_en}),
    .q({cic_out1[11],cic_out1[13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg29_b12|dec_ch1/reg29_b14  (
    .a({_al_u1933_o,_al_u1929_o}),
    .b({_al_u1890_o,_al_u1890_o}),
    .c({\dec_ch1/pk4 [12],\dec_ch1/pk4 [14]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,peak_en}),
    .q({cic_out1[12],cic_out1[14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg29_b15|dec_ch1/reg29_b7  (
    .a({peak_en,_al_u1903_o}),
    .b({_al_u1890_o,_al_u1890_o}),
    .c({\dec_ch1/pk4 [15],\dec_ch1/pk4 [7]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1926_o,peak_en}),
    .q({cic_out1[15],cic_out1[7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg29_b1|dec_ch1/reg29_b2  (
    .a({_al_u1918_o,_al_u1918_o}),
    .b({_al_u1890_o,_al_u1890_o}),
    .c({\dec_ch1/fine [1],_al_u1923_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/pk4 [1],\dec_ch1/pk4 [2]}),
    .e({peak_en,peak_en}),
    .q({cic_out1[1],cic_out1[2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg29_b4|dec_ch1/reg29_b0  (
    .a({_al_u1916_o,_al_u1918_o}),
    .b({_al_u1890_o,_al_u1890_o}),
    .c({\dec_ch1/pk4 [4],\dec_ch1/fine [0]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,\dec_ch1/pk4 [0]}),
    .e({open_n12640,peak_en}),
    .q({cic_out1[4],cic_out1[0]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg29_b5|dec_ch1/reg29_b6  (
    .a({_al_u1912_o,_al_u1908_o}),
    .b({_al_u1890_o,_al_u1890_o}),
    .c({\dec_ch1/pk4 [5],\dec_ch1/pk4 [6]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,peak_en}),
    .q({cic_out1[5],cic_out1[6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg29_b8|dec_ch1/reg29_b9  (
    .a({_al_u1890_o,_al_u1877_o}),
    .b({_al_u1898_o,_al_u1890_o}),
    .c({\dec_ch1/pk4 [8],\dec_ch1/pk4 [9]}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({peak_en,peak_en}),
    .q({cic_out1[8],cic_out1[9]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg2_b0  (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n12717,\dec_ch1/pb [0]}),
    .q({open_n12735,pair_e1[0]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg2_b1|dec_ch1/reg2_b2  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pb [1],\dec_ch1/pb [2]}),
    .q({pair_e1[1],pair_e1[2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg2_b3|dec_ch1/reg2_b4  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/pb [3],\dec_ch1/pb [4]}),
    .q({pair_e1[3],pair_e1[4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg30_b1|dec_ch1/reg30_b7  (
    .b({\dec_ch1/c3 [6],\dec_ch1/c3 [30]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [14],\dec_ch1/c3 [22]}),
    .mi({adc1A_w[1],adc1A_w[7]}),
    .f({_al_u969_o,\dec_ch1/n138_lutinv }),
    .q({\dec_ch1/pa [1],\dec_ch1/pa [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg30_b5|dec_ch1/reg30_b6  (
    .a({open_n12807,\dec_ch1/n121_lutinv }),
    .b({\dec_ch1/c3 [4],\dec_ch1/c3 [14]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_ch1/c3 [22]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [12],\dec_shift[3]_hfnopt2_0 }),
    .e({open_n12809,dec_shift[4]}),
    .mi({adc1A_w[5],adc1A_w[6]}),
    .f({_al_u973_o,\dec_ch1/n12_lutinv }),
    .q({\dec_ch1/pa [5],\dec_ch1/pa [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg4_b1|dec_ch1/reg9_b6  (
    .b({dec_order[0],open_n12828}),
    .c({\dec_order[1]_hfnopt2_1 ,\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .d({pair_e1[0],\dec_ch1/n18 }),
    .mi({pair_l1[1],\dec_ch1/pmn [6]}),
    .f({\dec_ch1/t_xe [0],\dec_ch1/t_xe [9]}),
    .q({\dec_ch1/pl [1],\dec_ch1/pdn [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg4_b3|dec_ch1/reg4_b2  (
    .a({open_n12844,\dec_ch1/n19 [1]}),
    .b({open_n12845,pair_e1[1]}),
    .c({\dec_ch1/pe [2],pair_e1[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,dec_order[0]}),
    .e({open_n12847,\dec_order[1]_hfnopt2_1 }),
    .mi(pair_l1[3:2]),
    .f({\dec_ch1/t_pe [2],\dec_ch1/t_xe [2]}),
    .q(\dec_ch1/pl [3:2]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg4_b6|dec_ch1/reg4_b5  (
    .a({open_n12864,\dec_ch1/n19 [3]}),
    .b({open_n12865,pair_e1[3]}),
    .c({\dec_ch1/pe [3],pair_e1[4]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,dec_order[0]}),
    .e({open_n12867,\dec_order[1]_hfnopt2_1 }),
    .mi(pair_l1[6:5]),
    .f({\dec_ch1/t_pe [3],\dec_ch1/t_xe [4]}),
    .q(\dec_ch1/pl [6:5]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg4_b7|dec_ch1/reg3_b7  (
    .a({open_n12884,\dec_ch1/n19 [6]}),
    .b({open_n12885,pair_e1[6]}),
    .c({\dec_ch1/pe [4],pair_e1[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,dec_order[0]}),
    .e({open_n12887,\dec_order[1]_hfnopt2_1 }),
    .mi({pair_l1[7],pair_e1[7]}),
    .f({\dec_ch1/t_pe [4],\dec_ch1/t_xe [7]}),
    .q({\dec_ch1/pl [7],\dec_ch1/pe [7]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg5_b0|u3/ucin  (
    .a({\dec_ch1/t_xe [0],1'b0}),
    .b({n1[0],open_n12904}),
    .clk(sample_write_clock_gclk_net),
    .fco(\u3/c1 ),
    .q({\dec_ch1/f [0],open_n12927}));
  AL_PHY_MSLICE \dec_ch1/reg5_b10|dec_ch1/reg5_b9  (
    .a({1'b0,\dec_ch1/t_pl [9]}),
    .b(n1[10:9]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u3/c9 ),
    .q(\dec_ch1/f [10:9]));
  AL_PHY_MSLICE \dec_ch1/reg5_b2|dec_ch1/reg5_b1  (
    .a(n0[2:1]),
    .b(n1[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u3/c1 ),
    .fco(\u3/c3 ),
    .q(\dec_ch1/f [2:1]));
  AL_PHY_MSLICE \dec_ch1/reg5_b4|dec_ch1/reg5_b3  (
    .a(n0[4:3]),
    .b(n1[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u3/c3 ),
    .fco(\u3/c5 ),
    .q(\dec_ch1/f [4:3]));
  AL_PHY_MSLICE \dec_ch1/reg5_b6|dec_ch1/reg5_b5  (
    .a(n0[6:5]),
    .b(n1[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u3/c5 ),
    .fco(\u3/c7 ),
    .q(\dec_ch1/f [6:5]));
  AL_PHY_MSLICE \dec_ch1/reg5_b8|dec_ch1/reg5_b7  (
    .a(n0[8:7]),
    .b(n1[8:7]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u3/c7 ),
    .fco(\u3/c9 ),
    .q(\dec_ch1/f [8:7]));
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg6_b0|dec_ch1/reg6_b2  (
    .b({pair_l1[0],pair_l1[2]}),
    .c({pair_e1[0],pair_e1[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n53 ,\dec_ch1/n53 }),
    .q({\dec_ch1/pmx [0],\dec_ch1/pmx [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg6_b3|dec_ch1/reg6_b4  (
    .b({pair_l1[3],pair_l1[4]}),
    .c({pair_e1[3],pair_e1[4]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n53 ,\dec_ch1/n53 }),
    .q({\dec_ch1/pmx [3],\dec_ch1/pmx [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg6_b5|dec_ch1/reg6_b7  (
    .b({pair_l1[5],pair_l1[7]}),
    .c({pair_e1[5],pair_e1[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n53 ,\dec_ch1/n53 }),
    .q({\dec_ch1/pmx [5],\dec_ch1/pmx [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg6_b6|dec_ch1/reg7_b7  (
    .b({pair_l1[6],pair_l1[7]}),
    .c({pair_e1[6],pair_e1[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n53 ,\dec_ch1/n55 }),
    .q({\dec_ch1/pmx [6],\dec_ch1/pmn [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg7_b0|dec_ch1/reg6_b1  (
    .b({pair_l1[0],pair_l1[1]}),
    .c({pair_e1[0],pair_e1[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n55 ,\dec_ch1/n53 }),
    .q({\dec_ch1/pmn [0],\dec_ch1/pmx [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg7_b1|dec_ch1/reg7_b2  (
    .b({pair_l1[1],pair_l1[2]}),
    .c({pair_e1[1],pair_e1[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n55 ,\dec_ch1/n55 }),
    .q({\dec_ch1/pmn [1],\dec_ch1/pmn [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg7_b3|dec_ch1/reg7_b4  (
    .b({pair_l1[3],pair_l1[4]}),
    .c({pair_e1[3],pair_e1[4]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n55 ,\dec_ch1/n55 }),
    .q({\dec_ch1/pmn [3],\dec_ch1/pmn [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg7_b5|dec_ch1/reg7_b6  (
    .b({pair_l1[5],pair_l1[6]}),
    .c({pair_e1[5],pair_e1[6]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n55 ,\dec_ch1/n55 }),
    .q({\dec_ch1/pmn [5],\dec_ch1/pmn [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch1/reg8_b4|dec_ch1/reg8_b7  (
    .a({\dec_ch1/n22 [4],\dec_ch1/n22 [5]}),
    .b({\dec_ch1/pl [5],\dec_ch1/pl [6]}),
    .c({dec_order[0],dec_order[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/pmx [4],\dec_ch1/pmx [7]}),
    .f({\dec_ch1/t_pl [5],\dec_ch1/t_pl [6]}),
    .q({\dec_ch1/pdx [4],\dec_ch1/pdx [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg8_b5|dec_ch1/reg9_b0  (
    .a({\dec_ch1/n22 [3],\dec_ch1/n22 [1]}),
    .b({\dec_ch1/pl [4],\dec_ch1/pl [2]}),
    .c({dec_order[0],dec_order[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/pmx [5],\dec_ch1/pmn [0]}),
    .f({\dec_ch1/t_pl [4],\dec_ch1/t_pl [2]}),
    .q({\dec_ch1/pdx [5],\dec_ch1/pdn [0]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg8_b6|dec_ch1/reg9_b2  (
    .a({\dec_ch1/n22 [0],\dec_ch1/n22 [2]}),
    .b({\dec_ch1/pl [1],\dec_ch1/pl [3]}),
    .c({dec_order[0],dec_order[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/pmx [6],\dec_ch1/pmn [2]}),
    .f({\dec_ch1/t_pl [1],\dec_ch1/t_pl [3]}),
    .q({\dec_ch1/pdx [6],\dec_ch1/pdn [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg9_b5|dec_ch1/reg4_b4  (
    .a({\dec_ch1/n19 [4],\dec_ch1/n19 [2]}),
    .b({pair_e1[4],pair_e1[2]}),
    .c({pair_e1[5],pair_e1[3]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[0],dec_order[0]}),
    .e({\dec_order[1]_hfnopt2_1 ,\dec_order[1]_hfnopt2_1 }),
    .mi({\dec_ch1/pmn [5],pair_l1[4]}),
    .f({\dec_ch1/t_xe [5],\dec_ch1/t_xe [3]}),
    .q({\dec_ch1/pdn [5],\dec_ch1/pl [4]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/reg9_b7  (
    .c({open_n13292,\dec_order[1]_hfnopt2_1 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n13294,\dec_ch1/c1p [14]}),
    .mi({open_n13298,\dec_ch1/pmn [7]}),
    .f({open_n13311,\dec_ch1/n81 [14]}),
    .q({open_n13315,\dec_ch1/pdn [7]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch1/sub0/u11_al_u2280  (
    .a({\dec_ch1/d0 [13],\dec_ch1/d0 [11]}),
    .b({\dec_ch1/d0 [14],\dec_ch1/d0 [12]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [13],\dec_ch1/d0p [11]}),
    .e({\dec_ch1/d0p [14],\dec_ch1/d0p [12]}),
    .fci(\dec_ch1/sub0/c11 ),
    .mi({open_n13316,\dec_ch1/d0 [7]}),
    .f({\dec_ch1/n78 [13],\dec_ch1/n78 [11]}),
    .fco(\dec_ch1/sub0/c15 ),
    .fx({\dec_ch1/n78 [14],\dec_ch1/n78 [12]}),
    .q({open_n13329,\dec_ch1/d0p [7]}));
  AL_PHY_LSLICE \dec_ch1/sub0/u15_al_u2281  (
    .a({\dec_ch1/d0 [17],\dec_ch1/d0 [15]}),
    .b({\dec_ch1/d0 [18],\dec_ch1/d0 [16]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [17],\dec_ch1/d0p [15]}),
    .e({\dec_ch1/d0p [18],\dec_ch1/d0p [16]}),
    .fci(\dec_ch1/sub0/c15 ),
    .mi(\dec_ch1/n78 [28:27]),
    .f({\dec_ch1/n78 [17],\dec_ch1/n78 [15]}),
    .fco(\dec_ch1/sub0/c19 ),
    .fx({\dec_ch1/n78 [18],\dec_ch1/n78 [16]}),
    .q(\dec_ch1/c1 [28:27]));
  AL_PHY_LSLICE \dec_ch1/sub0/u19_al_u2282  (
    .a({\dec_ch1/d0 [21],\dec_ch1/d0 [19]}),
    .b({\dec_ch1/d0 [22],\dec_ch1/d0 [20]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [21],\dec_ch1/d0p [19]}),
    .e({\dec_ch1/d0p [22],\dec_ch1/d0p [20]}),
    .fci(\dec_ch1/sub0/c19 ),
    .mi({\dec_ch1/d0 [18],\dec_ch1/d0 [16]}),
    .f({\dec_ch1/n78 [21],\dec_ch1/n78 [19]}),
    .fco(\dec_ch1/sub0/c23 ),
    .fx({\dec_ch1/n78 [22],\dec_ch1/n78 [20]}),
    .q({\dec_ch1/d0p [18],\dec_ch1/d0p [16]}));
  AL_PHY_LSLICE \dec_ch1/sub0/u23_al_u2283  (
    .a({\dec_ch1/d0 [25],\dec_ch1/d0 [23]}),
    .b({\dec_ch1/d0 [26],\dec_ch1/d0 [24]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [25],\dec_ch1/d0p [23]}),
    .e({\dec_ch1/d0p [26],\dec_ch1/d0p [24]}),
    .fci(\dec_ch1/sub0/c23 ),
    .mi({\dec_ch1/d0 [22],\dec_ch1/d0 [20]}),
    .f({\dec_ch1/n78 [25],\dec_ch1/n78 [23]}),
    .fco(\dec_ch1/sub0/c27 ),
    .fx({\dec_ch1/n78 [26],\dec_ch1/n78 [24]}),
    .q({\dec_ch1/d0p [22],\dec_ch1/d0p [20]}));
  AL_PHY_LSLICE \dec_ch1/sub0/u27_al_u2284  (
    .a({\dec_ch1/d0 [29],\dec_ch1/d0 [27]}),
    .b({\dec_ch1/d0 [30],\dec_ch1/d0 [28]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [29],\dec_ch1/d0p [27]}),
    .e({\dec_ch1/d0p [30],\dec_ch1/d0p [28]}),
    .fci(\dec_ch1/sub0/c27 ),
    .mi(\dec_ch1/n78 [34:33]),
    .f({\dec_ch1/n78 [29],\dec_ch1/n78 [27]}),
    .fco(\dec_ch1/sub0/c31 ),
    .fx({\dec_ch1/n78 [30],\dec_ch1/n78 [28]}),
    .q(\dec_ch1/c1 [34:33]));
  AL_PHY_LSLICE \dec_ch1/sub0/u31_al_u2285  (
    .a({\dec_ch1/d0 [33],\dec_ch1/d0 [31]}),
    .b({\dec_ch1/d0 [34],\dec_ch1/d0 [32]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [33],\dec_ch1/d0p [31]}),
    .e({\dec_ch1/d0p [34],\dec_ch1/d0p [32]}),
    .fci(\dec_ch1/sub0/c31 ),
    .mi(\dec_ch1/d0 [24:23]),
    .f({\dec_ch1/n78 [33],\dec_ch1/n78 [31]}),
    .fco(\dec_ch1/sub0/c35 ),
    .fx({\dec_ch1/n78 [34],\dec_ch1/n78 [32]}),
    .q(\dec_ch1/d0p [24:23]));
  AL_PHY_LSLICE \dec_ch1/sub0/u35_al_u2286  (
    .a({\dec_ch1/d0 [37],\dec_ch1/d0 [35]}),
    .b({\dec_ch1/d0 [38],\dec_ch1/d0 [36]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [37],\dec_ch1/d0p [35]}),
    .e({\dec_ch1/d0p [38],\dec_ch1/d0p [36]}),
    .fci(\dec_ch1/sub0/c35 ),
    .mi(\dec_ch1/d0 [26:25]),
    .f({\dec_ch1/n78 [37],\dec_ch1/n78 [35]}),
    .fco(\dec_ch1/sub0/c39 ),
    .fx({\dec_ch1/n78 [38],\dec_ch1/n78 [36]}),
    .q(\dec_ch1/d0p [26:25]));
  AL_PHY_LSLICE \dec_ch1/sub0/u39_al_u2287  (
    .a({\dec_ch1/d0 [41],\dec_ch1/d0 [39]}),
    .b({\dec_ch1/d0 [42],\dec_ch1/d0 [40]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [41],\dec_ch1/d0p [39]}),
    .e({\dec_ch1/d0p [42],\dec_ch1/d0p [40]}),
    .fci(\dec_ch1/sub0/c39 ),
    .mi(\dec_ch1/n78 [42:41]),
    .f({\dec_ch1/n78 [41],\dec_ch1/n78 [39]}),
    .fco(\dec_ch1/sub0/c43 ),
    .fx({\dec_ch1/n78 [42],\dec_ch1/n78 [40]}),
    .q(\dec_ch1/c1 [42:41]));
  AL_PHY_LSLICE \dec_ch1/sub0/u3_al_u2278  (
    .a({\dec_ch1/d0 [5],\dec_ch1/d0 [3]}),
    .b({\dec_ch1/d0 [6],\dec_ch1/d0 [4]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [5],\dec_ch1/d0p [3]}),
    .e({\dec_ch1/d0p [6],\dec_ch1/d0p [4]}),
    .fci(\dec_ch1/sub0/c3 ),
    .mi({\dec_ch1/d0 [3],\dec_ch1/d0 [14]}),
    .f({\dec_ch1/n78 [5],\dec_ch1/n78 [3]}),
    .fco(\dec_ch1/sub0/c7 ),
    .fx({\dec_ch1/n78 [6],\dec_ch1/n78 [4]}),
    .q({\dec_ch1/d0p [3],\dec_ch1/d0p [14]}));
  AL_PHY_LSLICE \dec_ch1/sub0/u43_al_u2288  (
    .a({\dec_ch1/d0 [45],\dec_ch1/d0 [43]}),
    .b({\dec_ch1/d0 [46],\dec_ch1/d0 [44]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [45],\dec_ch1/d0p [43]}),
    .e({\dec_ch1/d0p [46],\dec_ch1/d0p [44]}),
    .fci(\dec_ch1/sub0/c43 ),
    .mi(\dec_ch1/n78 [44:43]),
    .f({\dec_ch1/n78 [45],\dec_ch1/n78 [43]}),
    .fco(\dec_ch1/sub0/c47 ),
    .fx({\dec_ch1/n78 [46],\dec_ch1/n78 [44]}),
    .q(\dec_ch1/c1 [44:43]));
  AL_PHY_LSLICE \dec_ch1/sub0/u47_al_u2289  (
    .a({open_n13438,\dec_ch1/d0 [47]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n13441,\dec_ch1/d0p [47]}),
    .fci(\dec_ch1/sub0/c47 ),
    .mi(\dec_ch1/d0 [33:32]),
    .f({open_n13456,\dec_ch1/n78 [47]}),
    .q(\dec_ch1/d0p [33:32]));
  AL_PHY_LSLICE \dec_ch1/sub0/u7_al_u2279  (
    .a({\dec_ch1/d0 [9],\dec_ch1/d0 [7]}),
    .b({\dec_ch1/d0 [10],\dec_ch1/d0 [8]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [9],\dec_ch1/d0p [7]}),
    .e({\dec_ch1/d0p [10],\dec_ch1/d0p [8]}),
    .fci(\dec_ch1/sub0/c7 ),
    .mi(\dec_ch1/d0 [9:8]),
    .f({\dec_ch1/n78 [9],\dec_ch1/n78 [7]}),
    .fco(\dec_ch1/sub0/c11 ),
    .fx({\dec_ch1/n78 [10],\dec_ch1/n78 [8]}),
    .q(\dec_ch1/d0p [9:8]));
  AL_PHY_LSLICE \dec_ch1/sub0/ucin_al_u2277  (
    .a({\dec_ch1/d0 [1],1'b0}),
    .b({\dec_ch1/d0 [2],\dec_ch1/d0 [0]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/d0p [1],1'b1}),
    .e({\dec_ch1/d0p [2],\dec_ch1/d0p [0]}),
    .mi(\dec_ch1/d0 [5:4]),
    .f({\dec_ch1/n78 [1],open_n13485}),
    .fco(\dec_ch1/sub0/c3 ),
    .fx({\dec_ch1/n78 [2],\dec_ch1/n78 [0]}),
    .q(\dec_ch1/d0p [5:4]));
  AL_PHY_LSLICE \dec_ch1/sub1/u11_al_u2293  (
    .a({\dec_ch1/c1 [13],\dec_ch1/c1 [11]}),
    .b({\dec_ch1/c1 [14],\dec_ch1/c1 [12]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [13],\dec_ch1/n81 [11]}),
    .e({\dec_ch1/n81 [14],\dec_ch1/n81 [12]}),
    .fci(\dec_ch1/sub1/c11 ),
    .mi(\dec_ch1/c1 [11:10]),
    .f({\dec_ch1/n82 [13],\dec_ch1/n82 [11]}),
    .fco(\dec_ch1/sub1/c15 ),
    .fx({\dec_ch1/n82 [14],\dec_ch1/n82 [12]}),
    .q(\dec_ch1/c1p [11:10]));
  AL_PHY_LSLICE \dec_ch1/sub1/u15_al_u2294  (
    .a({\dec_ch1/c1 [17],\dec_ch1/c1 [15]}),
    .b({\dec_ch1/c1 [18],\dec_ch1/c1 [16]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [17],\dec_ch1/n81 [15]}),
    .e({\dec_ch1/n81 [18],\dec_ch1/n81 [16]}),
    .fci(\dec_ch1/sub1/c15 ),
    .mi({\dec_ch1/c1 [19],\dec_ch1/n82 [21]}),
    .f({\dec_ch1/n82 [17],\dec_ch1/n82 [15]}),
    .fco(\dec_ch1/sub1/c19 ),
    .fx({\dec_ch1/n82 [18],\dec_ch1/n82 [16]}),
    .q({\dec_ch1/c1p [19],\dec_ch1/c2 [21]}));
  AL_PHY_LSLICE \dec_ch1/sub1/u19_al_u2295  (
    .a({\dec_ch1/c1 [21],\dec_ch1/c1 [19]}),
    .b({\dec_ch1/c1 [22],\dec_ch1/c1 [20]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [21],\dec_ch1/n81 [19]}),
    .e({\dec_ch1/n81 [22],\dec_ch1/n81 [20]}),
    .fci(\dec_ch1/sub1/c19 ),
    .mi(\dec_ch1/c1 [26:25]),
    .f({\dec_ch1/n82 [21],\dec_ch1/n82 [19]}),
    .fco(\dec_ch1/sub1/c23 ),
    .fx({\dec_ch1/n82 [22],\dec_ch1/n82 [20]}),
    .q(\dec_ch1/c1p [26:25]));
  AL_PHY_LSLICE \dec_ch1/sub1/u23_al_u2296  (
    .a({\dec_ch1/c1 [25],\dec_ch1/c1 [23]}),
    .b({\dec_ch1/c1 [26],\dec_ch1/c1 [24]}),
    .c(2'b11),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch1/n81 [25],\dec_ch1/n81 [23]}),
    .e({\dec_ch1/n81 [26],\dec_ch1/n81 [24]}),
    .fci(\dec_ch1/sub1/c23 ),
    .mi({open_n13522,io_mcu_data_pad[1]}),
    .f({\dec_ch1/n82 [25],\dec_ch1/n82 [23]}),
    .fco(\dec_ch1/sub1/c27 ),
    .fx({\dec_ch1/n82 [26],\dec_ch1/n82 [24]}),
    .q({open_n13535,\dec_order[1]_hfnopt2_1 }));
  AL_PHY_LSLICE \dec_ch1/sub1/u27_al_u2297  (
    .a({\dec_ch1/c1 [29],\dec_ch1/c1 [27]}),
    .b({\dec_ch1/c1 [30],\dec_ch1/c1 [28]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [29],\dec_ch1/n81 [27]}),
    .e({\dec_ch1/n81 [30],\dec_ch1/n81 [28]}),
    .fci(\dec_ch1/sub1/c27 ),
    .mi({\dec_ch1/c1 [29],\dec_ch1/c1 [27]}),
    .f({\dec_ch1/n82 [29],\dec_ch1/n82 [27]}),
    .fco(\dec_ch1/sub1/c31 ),
    .fx({\dec_ch1/n82 [30],\dec_ch1/n82 [28]}),
    .q({\dec_ch1/c1p [29],\dec_ch1/c1p [27]}));
  AL_PHY_LSLICE \dec_ch1/sub1/u31_al_u2298  (
    .a({\dec_ch1/c1 [33],\dec_ch1/c1 [31]}),
    .b({\dec_ch1/c1 [34],\dec_ch1/c1 [32]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [33],\dec_ch1/n81 [31]}),
    .e({\dec_ch1/n81 [34],\dec_ch1/n81 [32]}),
    .fci(\dec_ch1/sub1/c31 ),
    .mi(\dec_ch1/c1 [24:23]),
    .f({\dec_ch1/n82 [33],\dec_ch1/n82 [31]}),
    .fco(\dec_ch1/sub1/c35 ),
    .fx({\dec_ch1/n82 [34],\dec_ch1/n82 [32]}),
    .q(\dec_ch1/c1p [24:23]));
  AL_PHY_LSLICE \dec_ch1/sub1/u35_al_u2299  (
    .a({\dec_ch1/c1 [37],\dec_ch1/c1 [35]}),
    .b({\dec_ch1/c1 [38],\dec_ch1/c1 [36]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [37],\dec_ch1/n81 [35]}),
    .e({\dec_ch1/n81 [38],\dec_ch1/n81 [36]}),
    .fci(\dec_ch1/sub1/c35 ),
    .mi(\dec_ch1/n82 [37:36]),
    .f({\dec_ch1/n82 [37],\dec_ch1/n82 [35]}),
    .fco(\dec_ch1/sub1/c39 ),
    .fx({\dec_ch1/n82 [38],\dec_ch1/n82 [36]}),
    .q(\dec_ch1/c2 [37:36]));
  AL_PHY_LSLICE \dec_ch1/sub1/u39_al_u2300  (
    .a({\dec_ch1/c1 [41],\dec_ch1/c1 [39]}),
    .b({\dec_ch1/c1 [42],\dec_ch1/c1 [40]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [41],\dec_ch1/n81 [39]}),
    .e({\dec_ch1/n81 [42],\dec_ch1/n81 [40]}),
    .fci(\dec_ch1/sub1/c39 ),
    .mi(\dec_ch1/c1 [33:32]),
    .f({\dec_ch1/n82 [41],\dec_ch1/n82 [39]}),
    .fco(\dec_ch1/sub1/c43 ),
    .fx({\dec_ch1/n82 [42],\dec_ch1/n82 [40]}),
    .q(\dec_ch1/c1p [33:32]));
  AL_PHY_LSLICE \dec_ch1/sub1/u3_al_u2291  (
    .a({\dec_ch1/c1 [5],\dec_ch1/c1 [3]}),
    .b({\dec_ch1/c1 [6],\dec_ch1/c1 [4]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [5],\dec_ch1/n81 [3]}),
    .e({\dec_ch1/n81 [6],\dec_ch1/n81 [4]}),
    .fci(\dec_ch1/sub1/c3 ),
    .mi({\dec_ch1/n78 [13],\dec_ch1/n78 [11]}),
    .f({\dec_ch1/n82 [5],\dec_ch1/n82 [3]}),
    .fco(\dec_ch1/sub1/c7 ),
    .fx({\dec_ch1/n82 [6],\dec_ch1/n82 [4]}),
    .q({\dec_ch1/c1 [13],\dec_ch1/c1 [11]}));
  AL_PHY_LSLICE \dec_ch1/sub1/u43_al_u2301  (
    .a({\dec_ch1/c1 [45],\dec_ch1/c1 [43]}),
    .b({\dec_ch1/c1 [46],\dec_ch1/c1 [44]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [45],\dec_ch1/n81 [43]}),
    .e({\dec_ch1/n81 [46],\dec_ch1/n81 [44]}),
    .fci(\dec_ch1/sub1/c43 ),
    .mi({\dec_ch1/c1 [35],\dec_ch1/c1 [31]}),
    .f({\dec_ch1/n82 [45],\dec_ch1/n82 [43]}),
    .fco(\dec_ch1/sub1/c47 ),
    .fx({\dec_ch1/n82 [46],\dec_ch1/n82 [44]}),
    .q({\dec_ch1/c1p [35],\dec_ch1/c1p [31]}));
  AL_PHY_LSLICE \dec_ch1/sub1/u47_al_u2302  (
    .a({open_n13608,\dec_ch1/c1 [47]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n13611,\dec_ch1/n81 [47]}),
    .fci(\dec_ch1/sub1/c47 ),
    .mi(\dec_ch1/n82 [45:44]),
    .f({open_n13626,\dec_ch1/n82 [47]}),
    .q(\dec_ch1/c2 [45:44]));
  AL_PHY_LSLICE \dec_ch1/sub1/u7_al_u2292  (
    .a({\dec_ch1/c1 [9],\dec_ch1/c1 [7]}),
    .b({\dec_ch1/c1 [10],\dec_ch1/c1 [8]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [9],\dec_ch1/n81 [7]}),
    .e({\dec_ch1/n81 [10],\dec_ch1/n81 [8]}),
    .fci(\dec_ch1/sub1/c7 ),
    .mi(\dec_ch1/c1 [8:7]),
    .f({\dec_ch1/n82 [9],\dec_ch1/n82 [7]}),
    .fco(\dec_ch1/sub1/c11 ),
    .fx({\dec_ch1/n82 [10],\dec_ch1/n82 [8]}),
    .q(\dec_ch1/c1p [8:7]));
  AL_PHY_LSLICE \dec_ch1/sub1/ucin_al_u2290  (
    .a({\dec_ch1/c1 [1],1'b0}),
    .b({\dec_ch1/c1 [2],\dec_ch1/c1 [0]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n81 [1],1'b1}),
    .e({\dec_ch1/n81 [2],\dec_ch1/n81 [0]}),
    .mi({open_n13643,\dec_ch1/c1 [3]}),
    .f({\dec_ch1/n82 [1],open_n13656}),
    .fco(\dec_ch1/sub1/c3 ),
    .fx({\dec_ch1/n82 [2],\dec_ch1/n82 [0]}),
    .q({open_n13657,\dec_ch1/c1p [3]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u11_al_u2306  (
    .a({\dec_ch1/c2 [13],\dec_ch1/c2 [11]}),
    .b({\dec_ch1/c2 [14],\dec_ch1/c2 [12]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [13],\dec_ch1/n85 [11]}),
    .e({\dec_ch1/n85 [14],\dec_ch1/n85 [12]}),
    .fci(\dec_ch1/sub2/c11 ),
    .mi({\dec_ch1/c2 [10],\dec_ch1/n86 [9]}),
    .f({\dec_ch1/n86 [13],\dec_ch1/n86 [11]}),
    .fco(\dec_ch1/sub2/c15 ),
    .fx({\dec_ch1/n86 [14],\dec_ch1/n86 [12]}),
    .q({\dec_ch1/c2p [10],\dec_ch1/c3 [9]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u15_al_u2307  (
    .a({\dec_ch1/c2 [17],\dec_ch1/c2 [15]}),
    .b({\dec_ch1/c2 [18],\dec_ch1/c2 [16]}),
    .c(2'b11),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [17],\dec_ch1/n85 [15]}),
    .e({\dec_ch1/n85 [18],\dec_ch1/n85 [16]}),
    .fci(\dec_ch1/sub2/c15 ),
    .mi({open_n13671,\dec_sv[1]_hfnopt2_4 }),
    .f({\dec_ch1/n86 [17],\dec_ch1/n86 [15]}),
    .fco(\dec_ch1/sub2/c19 ),
    .fx({\dec_ch1/n86 [18],\dec_ch1/n86 [16]}),
    .q({open_n13684,\dec_sv[2]_hfnopt2_2 }));
  AL_PHY_LSLICE \dec_ch1/sub2/u19_al_u2308  (
    .a({\dec_ch1/c2 [21],\dec_ch1/c2 [19]}),
    .b({\dec_ch1/c2 [22],\dec_ch1/c2 [20]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [21],\dec_ch1/n85 [19]}),
    .e({\dec_ch1/n85 [22],\dec_ch1/n85 [20]}),
    .fci(\dec_ch1/sub2/c19 ),
    .mi({open_n13685,\dec_ch2/pk0 [14]}),
    .f({\dec_ch1/n86 [21],\dec_ch1/n86 [19]}),
    .fco(\dec_ch1/sub2/c23 ),
    .fx({\dec_ch1/n86 [22],\dec_ch1/n86 [20]}),
    .q({open_n13698,\dec_ch2/pk1 [14]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u23_al_u2309  (
    .a({\dec_ch1/c2 [25],\dec_ch1/c2 [23]}),
    .b({\dec_ch1/c2 [26],\dec_ch1/c2 [24]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [25],\dec_ch1/n85 [23]}),
    .e({\dec_ch1/n85 [26],\dec_ch1/n85 [24]}),
    .fci(\dec_ch1/sub2/c23 ),
    .mi({\dec_ch1/c2 [22],\dec_ch1/n86 [25]}),
    .f({\dec_ch1/n86 [25],\dec_ch1/n86 [23]}),
    .fco(\dec_ch1/sub2/c27 ),
    .fx({\dec_ch1/n86 [26],\dec_ch1/n86 [24]}),
    .q({\dec_ch1/c2p [22],\dec_ch1/c3 [25]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u27_al_u2310  (
    .a({\dec_ch1/c2 [29],\dec_ch1/c2 [27]}),
    .b({\dec_ch1/c2 [30],\dec_ch1/c2 [28]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [29],\dec_ch1/n85 [27]}),
    .e({\dec_ch1/n85 [30],\dec_ch1/n85 [28]}),
    .fci(\dec_ch1/sub2/c27 ),
    .mi({\dec_ch1/n86 [27],\dec_ch1/n86 [2]}),
    .f({\dec_ch1/n86 [29],\dec_ch1/n86 [27]}),
    .fco(\dec_ch1/sub2/c31 ),
    .fx({\dec_ch1/n86 [30],\dec_ch1/n86 [28]}),
    .q({\dec_ch1/c3 [27],\dec_ch1/c3 [2]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u31_al_u2311  (
    .a({\dec_ch1/c2 [33],\dec_ch1/c2 [31]}),
    .b({\dec_ch1/c2 [34],\dec_ch1/c2 [32]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [33],\dec_ch1/n85 [31]}),
    .e({\dec_ch1/n85 [34],\dec_ch1/n85 [32]}),
    .fci(\dec_ch1/sub2/c31 ),
    .mi({\dec_ch1/c2 [30],\dec_ch1/c2 [25]}),
    .f({\dec_ch1/n86 [33],\dec_ch1/n86 [31]}),
    .fco(\dec_ch1/sub2/c35 ),
    .fx({\dec_ch1/n86 [34],\dec_ch1/n86 [32]}),
    .q({\dec_ch1/c2p [30],\dec_ch1/c2p [25]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u35_al_u2312  (
    .a({\dec_ch1/c2 [37],\dec_ch1/c2 [35]}),
    .b({\dec_ch1/c2 [38],\dec_ch1/c2 [36]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [37],\dec_ch1/n85 [35]}),
    .e({\dec_ch1/n85 [38],\dec_ch1/n85 [36]}),
    .fci(\dec_ch1/sub2/c35 ),
    .mi({\dec_ch1/n86 [31],\dec_ch1/n86 [28]}),
    .f({\dec_ch1/n86 [37],\dec_ch1/n86 [35]}),
    .fco(\dec_ch1/sub2/c39 ),
    .fx({\dec_ch1/n86 [38],\dec_ch1/n86 [36]}),
    .q({\dec_ch1/c3 [31],\dec_ch1/c3 [28]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u39_al_u2313  (
    .a({\dec_ch1/c2 [41],\dec_ch1/c2 [39]}),
    .b({\dec_ch1/c2 [42],\dec_ch1/c2 [40]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [41],\dec_ch1/n85 [39]}),
    .e({\dec_ch1/n85 [42],\dec_ch1/n85 [40]}),
    .fci(\dec_ch1/sub2/c39 ),
    .mi(\dec_ch1/n86 [36:35]),
    .f({\dec_ch1/n86 [41],\dec_ch1/n86 [39]}),
    .fco(\dec_ch1/sub2/c43 ),
    .fx({\dec_ch1/n86 [42],\dec_ch1/n86 [40]}),
    .q(\dec_ch1/c3 [36:35]));
  AL_PHY_LSLICE \dec_ch1/sub2/u3_al_u2304  (
    .a({\dec_ch1/c2 [5],\dec_ch1/c2 [3]}),
    .b({\dec_ch1/c2 [6],\dec_ch1/c2 [4]}),
    .c(2'b11),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [5],\dec_ch1/n85 [3]}),
    .e({\dec_ch1/n85 [6],\dec_ch1/n85 [4]}),
    .fci(\dec_ch1/sub2/c3 ),
    .mi({open_n13759,\dec_ch2/rmx [5]}),
    .f({\dec_ch1/n86 [5],\dec_ch1/n86 [3]}),
    .fco(\dec_ch1/sub2/c7 ),
    .fx({\dec_ch1/n86 [6],\dec_ch1/n86 [4]}),
    .q({open_n13772,\dec_ch2/pkw [13]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u43_al_u2314  (
    .a({\dec_ch1/c2 [45],\dec_ch1/c2 [43]}),
    .b({\dec_ch1/c2 [46],\dec_ch1/c2 [44]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [45],\dec_ch1/n85 [43]}),
    .e({\dec_ch1/n85 [46],\dec_ch1/n85 [44]}),
    .fci(\dec_ch1/sub2/c43 ),
    .mi({\dec_ch1/c2 [35],\dec_ch1/n86 [40]}),
    .f({\dec_ch1/n86 [45],\dec_ch1/n86 [43]}),
    .fco(\dec_ch1/sub2/c47 ),
    .fx({\dec_ch1/n86 [46],\dec_ch1/n86 [44]}),
    .q({\dec_ch1/c2p [35],\dec_ch1/c3 [40]}));
  AL_PHY_LSLICE \dec_ch1/sub2/u47_al_u2315  (
    .a({open_n13785,\dec_ch1/c2 [47]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n13788,\dec_ch1/n85 [47]}),
    .fci(\dec_ch1/sub2/c47 ),
    .mi(\dec_ch1/n86 [47:46]),
    .f({open_n13803,\dec_ch1/n86 [47]}),
    .q(\dec_ch1/c3 [47:46]));
  AL_PHY_LSLICE \dec_ch1/sub2/u7_al_u2305  (
    .a({\dec_ch1/c2 [9],\dec_ch1/c2 [7]}),
    .b({\dec_ch1/c2 [10],\dec_ch1/c2 [8]}),
    .c(2'b11),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [9],\dec_ch1/n85 [7]}),
    .e({\dec_ch1/n85 [10],\dec_ch1/n85 [8]}),
    .fci(\dec_ch1/sub2/c7 ),
    .mi({open_n13808,\dec_sv[2]_hfnopt2_2 }),
    .f({\dec_ch1/n86 [9],\dec_ch1/n86 [7]}),
    .fco(\dec_ch1/sub2/c11 ),
    .fx({\dec_ch1/n86 [10],\dec_ch1/n86 [8]}),
    .q({open_n13821,\dec_sv[3]_hfnopt2_2 }));
  AL_PHY_LSLICE \dec_ch1/sub2/ucin_al_u2303  (
    .a({\dec_ch1/c2 [1],1'b0}),
    .b({\dec_ch1/c2 [2],\dec_ch1/c2 [0]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n85 [1],1'b1}),
    .e({\dec_ch1/n85 [2],\dec_ch1/n85 [0]}),
    .mi(\dec_ch1/c2 [9:8]),
    .f({\dec_ch1/n86 [1],open_n13835}),
    .fco(\dec_ch1/sub2/c3 ),
    .fx({\dec_ch1/n86 [2],\dec_ch1/n86 [0]}),
    .q(\dec_ch1/c2p [9:8]));
  AL_PHY_MSLICE \dec_ch2/add0/u0|dec_ch2/add0/ucin  (
    .a({pair_e2[1],1'b0}),
    .b({pair_e2[0],open_n13836}),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n13851,\dec_ch1/n78 [47]}),
    .f({\dec_ch2/n19 [0],open_n13853}),
    .fco(\dec_ch2/add0/c1 ),
    .q({open_n13856,\dec_ch1/c1 [47]}));
  AL_PHY_MSLICE \dec_ch2/add0/u2|dec_ch2/add0/u1  (
    .a(pair_e2[3:2]),
    .b(pair_e2[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add0/c1 ),
    .mi({open_n13871,pair_l2[5]}),
    .f(\dec_ch2/n19 [2:1]),
    .fco(\dec_ch2/add0/c3 ),
    .q({open_n13875,\dec_ch2/pl [5]}));
  AL_PHY_MSLICE \dec_ch2/add0/u4|dec_ch2/add0/u3  (
    .a(pair_e2[5:4]),
    .b(pair_e2[4:3]),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add0/c3 ),
    .mi({\dec_ch2/n78 [0],\dec_ch1/d0 [47]}),
    .f(\dec_ch2/n19 [4:3]),
    .fco(\dec_ch2/add0/c5 ),
    .q({\dec_ch2/c1 [0],\dec_ch1/d0p [47]}));
  AL_PHY_MSLICE \dec_ch2/add0/u6|dec_ch2/add0/u5  (
    .a(pair_e2[7:6]),
    .b(pair_e2[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add0/c5 ),
    .mi({open_n13906,pair_l2[7]}),
    .f(\dec_ch2/n19 [6:5]),
    .fco(\dec_ch2/add0/c7 ),
    .q({open_n13910,\dec_ch2/pl [7]}));
  AL_PHY_MSLICE \dec_ch2/add0/ucout|dec_ch2/add0/u7  (
    .a({open_n13911,1'b0}),
    .b({open_n13912,pair_e2[7]}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add0/c7 ),
    .mi({open_n13926,\dec_ch2/n78 [10]}),
    .f({\dec_ch2/n18 ,\dec_ch2/n19 [7]}),
    .q({open_n13931,\dec_ch2/c1 [10]}));
  AL_PHY_MSLICE \dec_ch2/add1/u0|dec_ch2/add1/ucin  (
    .a({\dec_ch2/pl [1],1'b0}),
    .b({\dec_ch2/pl [0],open_n13932}),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch1/n70 [41:40]),
    .f({\dec_ch2/n22 [0],open_n13949}),
    .fco(\dec_ch2/add1/c1 ),
    .q(\dec_ch1/i1 [41:40]));
  AL_PHY_MSLICE \dec_ch2/add1/u2|dec_ch2/add1/u1  (
    .a(\dec_ch2/pl [3:2]),
    .b(\dec_ch2/pl [2:1]),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add1/c1 ),
    .mi({open_n13965,\dec_ch1/d0 [31]}),
    .f(\dec_ch2/n22 [2:1]),
    .fco(\dec_ch2/add1/c3 ),
    .q({open_n13969,\dec_ch1/d0p [31]}));
  AL_PHY_MSLICE \dec_ch2/add1/u4|dec_ch2/add1/u3  (
    .a(\dec_ch2/pl [5:4]),
    .b(\dec_ch2/pl [4:3]),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add1/c3 ),
    .mi(\dec_ch1/d0 [37:36]),
    .f(\dec_ch2/n22 [4:3]),
    .fco(\dec_ch2/add1/c5 ),
    .q(\dec_ch1/d0p [37:36]));
  AL_PHY_MSLICE \dec_ch2/add1/u6|dec_ch2/add1/u5  (
    .a(\dec_ch2/pl [7:6]),
    .b(\dec_ch2/pl [6:5]),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add1/c5 ),
    .mi({open_n13999,\dec_ch1/d0 [39]}),
    .f(\dec_ch2/n22 [6:5]),
    .fco(\dec_ch2/add1/c7 ),
    .q({open_n14003,\dec_ch1/d0p [39]}));
  AL_PHY_MSLICE \dec_ch2/add1/ucout|dec_ch2/add1/u7  (
    .a({open_n14004,1'b0}),
    .b({open_n14005,\dec_ch2/pl [7]}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/add1/c7 ),
    .mi(\dec_ch1/d0 [45:44]),
    .f({\dec_ch2/n21 ,\dec_ch2/n22 [7]}),
    .q(\dec_ch1/d0p [45:44]));
  AL_PHY_LSLICE \dec_ch2/add5/u11_al_u2319  (
    .a({\dec_ch2/i1 [13],\dec_ch2/i1 [11]}),
    .b({\dec_ch2/i1 [14],\dec_ch2/i1 [12]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c11 ),
    .mi(\dec_ch2/i3 [6:5]),
    .f({\dec_ch2/n70 [13],\dec_ch2/n70 [11]}),
    .fco(\dec_ch2/add5/c15 ),
    .fx({\dec_ch2/n70 [14],\dec_ch2/n70 [12]}),
    .q(\dec_ch2/d0 [6:5]));
  AL_PHY_LSLICE \dec_ch2/add5/u15_al_u2320  (
    .a({\dec_ch2/i1 [17],\dec_ch2/i1 [15]}),
    .b({\dec_ch2/i1 [18],\dec_ch2/i1 [16]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c15 ),
    .mi(\dec_ch2/n70 [28:27]),
    .f({\dec_ch2/n70 [17],\dec_ch2/n70 [15]}),
    .fco(\dec_ch2/add5/c19 ),
    .fx({\dec_ch2/n70 [18],\dec_ch2/n70 [16]}),
    .q(\dec_ch2/i1 [28:27]));
  AL_PHY_LSLICE \dec_ch2/add5/u19_al_u2321  (
    .a({\dec_ch2/i1 [21],\dec_ch2/i1 [19]}),
    .b({\dec_ch2/i1 [22],\dec_ch2/i1 [20]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c19 ),
    .mi({\dec_ch2/i3 [7],\dec_ch2/i3 [10]}),
    .f({\dec_ch2/n70 [21],\dec_ch2/n70 [19]}),
    .fco(\dec_ch2/add5/c23 ),
    .fx({\dec_ch2/n70 [22],\dec_ch2/n70 [20]}),
    .q({\dec_ch2/d0 [7],\dec_ch2/d0 [10]}));
  AL_PHY_LSLICE \dec_ch2/add5/u23_al_u2322  (
    .a({\dec_ch2/i1 [25],\dec_ch2/i1 [23]}),
    .b({\dec_ch2/i1 [26],\dec_ch2/i1 [24]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c23 ),
    .mi(\dec_ch2/i3 [9:8]),
    .f({\dec_ch2/n70 [25],\dec_ch2/n70 [23]}),
    .fco(\dec_ch2/add5/c27 ),
    .fx({\dec_ch2/n70 [26],\dec_ch2/n70 [24]}),
    .q(\dec_ch2/d0 [9:8]));
  AL_PHY_LSLICE \dec_ch2/add5/u27_al_u2323  (
    .a({\dec_ch2/i1 [29],\dec_ch2/i1 [27]}),
    .b({\dec_ch2/i1 [30],\dec_ch2/i1 [28]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c27 ),
    .mi({\dec_ch2/i3 [13],\dec_ch2/i3 [11]}),
    .f({\dec_ch2/n70 [29],\dec_ch2/n70 [27]}),
    .fco(\dec_ch2/add5/c31 ),
    .fx({\dec_ch2/n70 [30],\dec_ch2/n70 [28]}),
    .q({\dec_ch2/d0 [13],\dec_ch2/d0 [11]}));
  AL_PHY_LSLICE \dec_ch2/add5/u31_al_u2324  (
    .a({\dec_ch2/i1 [33],\dec_ch2/i1 [31]}),
    .b({\dec_ch2/i1 [34],\dec_ch2/i1 [32]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c31 ),
    .mi(\dec_ch2/n70 [36:35]),
    .f({\dec_ch2/n70 [33],\dec_ch2/n70 [31]}),
    .fco(\dec_ch2/add5/c35 ),
    .fx({\dec_ch2/n70 [34],\dec_ch2/n70 [32]}),
    .q(\dec_ch2/i1 [36:35]));
  AL_PHY_LSLICE \dec_ch2/add5/u35_al_u2325  (
    .a({\dec_ch2/i1 [37],\dec_ch2/i1 [35]}),
    .b({\dec_ch2/i1 [38],\dec_ch2/i1 [36]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c35 ),
    .mi(\dec_ch2/n70 [38:37]),
    .f({\dec_ch2/n70 [37],\dec_ch2/n70 [35]}),
    .fco(\dec_ch2/add5/c39 ),
    .fx({\dec_ch2/n70 [38],\dec_ch2/n70 [36]}),
    .q(\dec_ch2/i1 [38:37]));
  AL_PHY_LSLICE \dec_ch2/add5/u39_al_u2326  (
    .a({\dec_ch2/i1 [41],\dec_ch2/i1 [39]}),
    .b({\dec_ch2/i1 [42],\dec_ch2/i1 [40]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c39 ),
    .mi({\dec_ch2/i3 [17],\dec_ch2/i3 [15]}),
    .f({\dec_ch2/n70 [41],\dec_ch2/n70 [39]}),
    .fco(\dec_ch2/add5/c43 ),
    .fx({\dec_ch2/n70 [42],\dec_ch2/n70 [40]}),
    .q({\dec_ch2/d0 [17],\dec_ch2/d0 [15]}));
  AL_PHY_LSLICE \dec_ch2/add5/u3_al_u2317  (
    .a({\dec_ch2/i1 [5],\dec_ch2/i1 [3]}),
    .b({\dec_ch2/i1 [6],\dec_ch2/i1 [4]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/f [5],\dec_ch2/f [3]}),
    .e({\dec_ch2/f [6],\dec_ch2/f [4]}),
    .fci(\dec_ch2/add5/c3 ),
    .mi(\dec_ch2/i3 [2:1]),
    .f({\dec_ch2/n70 [5],\dec_ch2/n70 [3]}),
    .fco(\dec_ch2/add5/c7 ),
    .fx({\dec_ch2/n70 [6],\dec_ch2/n70 [4]}),
    .q(\dec_ch2/d0 [2:1]));
  AL_PHY_LSLICE \dec_ch2/add5/u43_al_u2327  (
    .a({\dec_ch2/i1 [45],\dec_ch2/i1 [43]}),
    .b({\dec_ch2/i1 [46],\dec_ch2/i1 [44]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\dec_ch2/add5/c43 ),
    .mi(\dec_ch2/i3 [20:19]),
    .f({\dec_ch2/n70 [45],\dec_ch2/n70 [43]}),
    .fco(\dec_ch2/add5/c47 ),
    .fx({\dec_ch2/n70 [46],\dec_ch2/n70 [44]}),
    .q(\dec_ch2/d0 [20:19]));
  AL_PHY_LSLICE \dec_ch2/add5/u47_al_u2328  (
    .a({open_n14146,\dec_ch2/i1 [47]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({open_n14150,1'b0}),
    .fci(\dec_ch2/add5/c47 ),
    .mi(\dec_ch2/n70 [46:45]),
    .f({open_n14165,\dec_ch2/n70 [47]}),
    .q(\dec_ch2/i1 [46:45]));
  AL_PHY_LSLICE \dec_ch2/add5/u7_al_u2318  (
    .a({\dec_ch2/i1 [9],\dec_ch2/i1 [7]}),
    .b({\dec_ch2/i1 [10],\dec_ch2/i1 [8]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/f [9],\dec_ch2/f [7]}),
    .e({\dec_ch2/f [10],\dec_ch2/f [8]}),
    .fci(\dec_ch2/add5/c7 ),
    .mi(\dec_ch2/i3 [4:3]),
    .f({\dec_ch2/n70 [9],\dec_ch2/n70 [7]}),
    .fco(\dec_ch2/add5/c11 ),
    .fx({\dec_ch2/n70 [10],\dec_ch2/n70 [8]}),
    .q(\dec_ch2/d0 [4:3]));
  AL_PHY_LSLICE \dec_ch2/add5/ucin_al_u2316  (
    .a({\dec_ch2/i1 [1],1'b0}),
    .b({\dec_ch2/i1 [2],\dec_ch2/i1 [0]}),
    .c(2'b00),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/f [1],1'b1}),
    .e({\dec_ch2/f [2],\dec_ch2/f [0]}),
    .mi({open_n14182,\dec_ch2/i3 [0]}),
    .f({\dec_ch2/n70 [1],open_n14195}),
    .fco(\dec_ch2/add5/c3 ),
    .fx({\dec_ch2/n70 [2],\dec_ch2/n70 [0]}),
    .q({open_n14196,\dec_ch2/d0 [0]}));
  AL_PHY_LSLICE \dec_ch2/add6/u11_al_u2332  (
    .a({\dec_ch2/n71 [13],\dec_ch2/n71 [11]}),
    .b({\dec_ch2/n71 [14],\dec_ch2/n71 [12]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [13],\dec_ch2/i1 [11]}),
    .e({\dec_ch2/i1 [14],\dec_ch2/i1 [12]}),
    .fci(\dec_ch2/add6/c11 ),
    .mi(\dec_ch2/n76 [9:8]),
    .f({\dec_ch2/n73 [13],\dec_ch2/n73 [11]}),
    .fco(\dec_ch2/add6/c15 ),
    .fx({\dec_ch2/n73 [14],\dec_ch2/n73 [12]}),
    .q(\dec_ch2/i3 [9:8]));
  AL_PHY_LSLICE \dec_ch2/add6/u15_al_u2333  (
    .a({\dec_ch2/n71 [17],\dec_ch2/n71 [15]}),
    .b({\dec_ch2/n71 [18],\dec_ch2/n71 [16]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [17],\dec_ch2/i1 [15]}),
    .e({\dec_ch2/i1 [18],\dec_ch2/i1 [16]}),
    .fci(\dec_ch2/add6/c15 ),
    .mi({\dec_ch2/n76 [7],\dec_ch2/n76 [14]}),
    .f({\dec_ch2/n73 [17],\dec_ch2/n73 [15]}),
    .fco(\dec_ch2/add6/c19 ),
    .fx({\dec_ch2/n73 [18],\dec_ch2/n73 [16]}),
    .q({\dec_ch2/i3 [7],\dec_ch2/i3 [14]}));
  AL_PHY_LSLICE \dec_ch2/add6/u19_al_u2334  (
    .a({\dec_ch2/n71 [21],\dec_ch2/n71 [19]}),
    .b({\dec_ch2/n71 [22],\dec_ch2/n71 [20]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [21],\dec_ch2/i1 [19]}),
    .e({\dec_ch2/i1 [22],\dec_ch2/i1 [20]}),
    .fci(\dec_ch2/add6/c19 ),
    .mi({\dec_ch2/n76 [12],\dec_ch2/n73 [22]}),
    .f({\dec_ch2/n73 [21],\dec_ch2/n73 [19]}),
    .fco(\dec_ch2/add6/c23 ),
    .fx({\dec_ch2/n73 [22],\dec_ch2/n73 [20]}),
    .q({\dec_ch2/i3 [12],\dec_ch2/i2 [22]}));
  AL_PHY_LSLICE \dec_ch2/add6/u23_al_u2335  (
    .a({\dec_ch2/n71 [25],\dec_ch2/n71 [23]}),
    .b({\dec_ch2/n71 [26],\dec_ch2/n71 [24]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [25],\dec_ch2/i1 [23]}),
    .e({\dec_ch2/i1 [26],\dec_ch2/i1 [24]}),
    .fci(\dec_ch2/add6/c23 ),
    .mi({\dec_ch2/n73 [23],\dec_ch2/n70 [26]}),
    .f({\dec_ch2/n73 [25],\dec_ch2/n73 [23]}),
    .fco(\dec_ch2/add6/c27 ),
    .fx({\dec_ch2/n73 [26],\dec_ch2/n73 [24]}),
    .q({\dec_ch2/i2 [23],\dec_ch2/i1 [26]}));
  AL_PHY_LSLICE \dec_ch2/add6/u27_al_u2336  (
    .a({\dec_ch2/n71 [29],\dec_ch2/n71 [27]}),
    .b({\dec_ch2/n71 [30],\dec_ch2/n71 [28]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [29],\dec_ch2/i1 [27]}),
    .e({\dec_ch2/i1 [30],\dec_ch2/i1 [28]}),
    .fci(\dec_ch2/add6/c27 ),
    .mi(\dec_ch2/n73 [28:27]),
    .f({\dec_ch2/n73 [29],\dec_ch2/n73 [27]}),
    .fco(\dec_ch2/add6/c31 ),
    .fx({\dec_ch2/n73 [30],\dec_ch2/n73 [28]}),
    .q(\dec_ch2/i2 [28:27]));
  AL_PHY_LSLICE \dec_ch2/add6/u31_al_u2337  (
    .a({\dec_ch2/n71 [33],\dec_ch2/n71 [31]}),
    .b({\dec_ch2/n71 [34],\dec_ch2/n71 [32]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [33],\dec_ch2/i1 [31]}),
    .e({\dec_ch2/i1 [34],\dec_ch2/i1 [32]}),
    .fci(\dec_ch2/add6/c31 ),
    .mi({\dec_ch2/n76 [15],\dec_ch2/n73 [31]}),
    .f({\dec_ch2/n73 [33],\dec_ch2/n73 [31]}),
    .fco(\dec_ch2/add6/c35 ),
    .fx({\dec_ch2/n73 [34],\dec_ch2/n73 [32]}),
    .q({\dec_ch2/i3 [15],\dec_ch2/i2 [31]}));
  AL_PHY_LSLICE \dec_ch2/add6/u35_al_u2338  (
    .a({\dec_ch2/n71 [37],\dec_ch2/n71 [35]}),
    .b({\dec_ch2/n71 [38],\dec_ch2/n71 [36]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [37],\dec_ch2/i1 [35]}),
    .e({\dec_ch2/i1 [38],\dec_ch2/i1 [36]}),
    .fci(\dec_ch2/add6/c35 ),
    .mi(\dec_ch2/n73 [33:32]),
    .f({\dec_ch2/n73 [37],\dec_ch2/n73 [35]}),
    .fco(\dec_ch2/add6/c39 ),
    .fx({\dec_ch2/n73 [38],\dec_ch2/n73 [36]}),
    .q(\dec_ch2/i2 [33:32]));
  AL_PHY_LSLICE \dec_ch2/add6/u39_al_u2339  (
    .a({\dec_ch2/n71 [41],\dec_ch2/n71 [39]}),
    .b({\dec_ch2/n71 [42],\dec_ch2/n71 [40]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [41],\dec_ch2/i1 [39]}),
    .e({\dec_ch2/i1 [42],\dec_ch2/i1 [40]}),
    .fci(\dec_ch2/add6/c39 ),
    .mi(\dec_ch2/n73 [40:39]),
    .f({\dec_ch2/n73 [41],\dec_ch2/n73 [39]}),
    .fco(\dec_ch2/add6/c43 ),
    .fx({\dec_ch2/n73 [42],\dec_ch2/n73 [40]}),
    .q(\dec_ch2/i2 [40:39]));
  AL_PHY_LSLICE \dec_ch2/add6/u3_al_u2330  (
    .a({\dec_ch2/n71 [5],\dec_ch2/n71 [3]}),
    .b({\dec_ch2/n71 [6],\dec_ch2/n71 [4]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [5],\dec_ch2/i1 [3]}),
    .e({\dec_ch2/i1 [6],\dec_ch2/i1 [4]}),
    .fci(\dec_ch2/add6/c3 ),
    .mi(\dec_ch2/n76 [4:3]),
    .f({\dec_ch2/n73 [5],\dec_ch2/n73 [3]}),
    .fco(\dec_ch2/add6/c7 ),
    .fx({\dec_ch2/n73 [6],\dec_ch2/n73 [4]}),
    .q(\dec_ch2/i3 [4:3]));
  AL_PHY_LSLICE \dec_ch2/add6/u43_al_u2340  (
    .a({\dec_ch2/n71 [45],\dec_ch2/n71 [43]}),
    .b({\dec_ch2/n71 [46],\dec_ch2/n71 [44]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [45],\dec_ch2/i1 [43]}),
    .e({\dec_ch2/i1 [46],\dec_ch2/i1 [44]}),
    .fci(\dec_ch2/add6/c43 ),
    .mi({\dec_ch2/n73 [44],\dec_ch2/n73 [42]}),
    .f({\dec_ch2/n73 [45],\dec_ch2/n73 [43]}),
    .fco(\dec_ch2/add6/c47 ),
    .fx({\dec_ch2/n73 [46],\dec_ch2/n73 [44]}),
    .q({\dec_ch2/i2 [44],\dec_ch2/i2 [42]}));
  AL_PHY_LSLICE \dec_ch2/add6/u47_al_u2341  (
    .a({open_n14327,\dec_ch2/n71 [47]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({open_n14331,\dec_ch2/i1 [47]}),
    .fci(\dec_ch2/add6/c47 ),
    .mi(\dec_ch2/n73 [46:45]),
    .f({open_n14346,\dec_ch2/n73 [47]}),
    .q(\dec_ch2/i2 [46:45]));
  AL_PHY_LSLICE \dec_ch2/add6/u7_al_u2331  (
    .a({\dec_ch2/n71 [9],\dec_ch2/n71 [7]}),
    .b({\dec_ch2/n71 [10],\dec_ch2/n71 [8]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [9],\dec_ch2/i1 [7]}),
    .e({\dec_ch2/i1 [10],\dec_ch2/i1 [8]}),
    .fci(\dec_ch2/add6/c7 ),
    .mi({\dec_ch2/n73 [20],\dec_ch2/n70 [20]}),
    .f({\dec_ch2/n73 [9],\dec_ch2/n73 [7]}),
    .fco(\dec_ch2/add6/c11 ),
    .fx({\dec_ch2/n73 [10],\dec_ch2/n73 [8]}),
    .q({\dec_ch2/i2 [20],\dec_ch2/i1 [20]}));
  AL_PHY_LSLICE \dec_ch2/add6/ucin_al_u2329  (
    .a({\dec_ch2/n71 [1],1'b0}),
    .b({\dec_ch2/n71 [2],\dec_ch2/n71 [0]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i1 [1],1'b1}),
    .e({\dec_ch2/i1 [2],\dec_ch2/i1 [0]}),
    .mi(\dec_ch2/n76 [6:5]),
    .f({\dec_ch2/n73 [1],open_n14377}),
    .fco(\dec_ch2/add6/c3 ),
    .fx({\dec_ch2/n73 [2],\dec_ch2/n73 [0]}),
    .q(\dec_ch2/i3 [6:5]));
  AL_PHY_LSLICE \dec_ch2/add7/u11_al_u2345  (
    .a({\dec_ch2/n74 [13],\dec_ch2/n74 [11]}),
    .b({\dec_ch2/n74 [14],\dec_ch2/n74 [12]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [13],\dec_ch2/i2 [11]}),
    .e({\dec_ch2/i2 [14],\dec_ch2/i2 [12]}),
    .fci(\dec_ch2/add7/c11 ),
    .mi({\dec_ch2/n73 [21],\dec_ch2/n73 [19]}),
    .f({\dec_ch2/n76 [13],\dec_ch2/n76 [11]}),
    .fco(\dec_ch2/add7/c15 ),
    .fx({\dec_ch2/n76 [14],\dec_ch2/n76 [12]}),
    .q({\dec_ch2/i2 [21],\dec_ch2/i2 [19]}));
  AL_PHY_LSLICE \dec_ch2/add7/u15_al_u2346  (
    .a({\dec_ch2/n74 [17],\dec_ch2/n74 [15]}),
    .b({\dec_ch2/n74 [18],\dec_ch2/n74 [16]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [17],\dec_ch2/i2 [15]}),
    .e({\dec_ch2/i2 [18],\dec_ch2/i2 [16]}),
    .fci(\dec_ch2/add7/c15 ),
    .mi(\dec_ch2/n76 [22:21]),
    .f({\dec_ch2/n76 [17],\dec_ch2/n76 [15]}),
    .fco(\dec_ch2/add7/c19 ),
    .fx({\dec_ch2/n76 [18],\dec_ch2/n76 [16]}),
    .q(\dec_ch2/i3 [22:21]));
  AL_PHY_LSLICE \dec_ch2/add7/u19_al_u2347  (
    .a({\dec_ch2/n74 [21],\dec_ch2/n74 [19]}),
    .b({\dec_ch2/n74 [22],\dec_ch2/n74 [20]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [21],\dec_ch2/i2 [19]}),
    .e({\dec_ch2/i2 [22],\dec_ch2/i2 [20]}),
    .fci(\dec_ch2/add7/c19 ),
    .mi(\dec_ch2/n76 [20:19]),
    .f({\dec_ch2/n76 [21],\dec_ch2/n76 [19]}),
    .fco(\dec_ch2/add7/c23 ),
    .fx({\dec_ch2/n76 [22],\dec_ch2/n76 [20]}),
    .q(\dec_ch2/i3 [20:19]));
  AL_PHY_LSLICE \dec_ch2/add7/u23_al_u2348  (
    .a({\dec_ch2/n74 [25],\dec_ch2/n74 [23]}),
    .b({\dec_ch2/n74 [26],\dec_ch2/n74 [24]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [25],\dec_ch2/i2 [23]}),
    .e({\dec_ch2/i2 [26],\dec_ch2/i2 [24]}),
    .fci(\dec_ch2/add7/c23 ),
    .mi(\dec_ch2/n76 [26:25]),
    .f({\dec_ch2/n76 [25],\dec_ch2/n76 [23]}),
    .fco(\dec_ch2/add7/c27 ),
    .fx({\dec_ch2/n76 [26],\dec_ch2/n76 [24]}),
    .q(\dec_ch2/i3 [26:25]));
  AL_PHY_LSLICE \dec_ch2/add7/u27_al_u2349  (
    .a({\dec_ch2/n74 [29],\dec_ch2/n74 [27]}),
    .b({\dec_ch2/n74 [30],\dec_ch2/n74 [28]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [29],\dec_ch2/i2 [27]}),
    .e({\dec_ch2/i2 [30],\dec_ch2/i2 [28]}),
    .fci(\dec_ch2/add7/c27 ),
    .mi({\dec_ch2/n76 [30],\dec_ch2/n76 [28]}),
    .f({\dec_ch2/n76 [29],\dec_ch2/n76 [27]}),
    .fco(\dec_ch2/add7/c31 ),
    .fx({\dec_ch2/n76 [30],\dec_ch2/n76 [28]}),
    .q({\dec_ch2/i3 [30],\dec_ch2/i3 [28]}));
  AL_PHY_LSLICE \dec_ch2/add7/u31_al_u2350  (
    .a({\dec_ch2/n74 [33],\dec_ch2/n74 [31]}),
    .b({\dec_ch2/n74 [34],\dec_ch2/n74 [32]}),
    .c(2'b00),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [33],\dec_ch2/i2 [31]}),
    .e({\dec_ch2/i2 [34],\dec_ch2/i2 [32]}),
    .fci(\dec_ch2/add7/c31 ),
    .mi(\dec_ch2/i3 [29:28]),
    .f({\dec_ch2/n76 [33],\dec_ch2/n76 [31]}),
    .fco(\dec_ch2/add7/c35 ),
    .fx({\dec_ch2/n76 [34],\dec_ch2/n76 [32]}),
    .q(\dec_ch2/d0 [29:28]));
  AL_PHY_LSLICE \dec_ch2/add7/u35_al_u2351  (
    .a({\dec_ch2/n74 [37],\dec_ch2/n74 [35]}),
    .b({\dec_ch2/n74 [38],\dec_ch2/n74 [36]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [37],\dec_ch2/i2 [35]}),
    .e({\dec_ch2/i2 [38],\dec_ch2/i2 [36]}),
    .fci(\dec_ch2/add7/c35 ),
    .mi(\dec_ch2/n76 [34:33]),
    .f({\dec_ch2/n76 [37],\dec_ch2/n76 [35]}),
    .fco(\dec_ch2/add7/c39 ),
    .fx({\dec_ch2/n76 [38],\dec_ch2/n76 [36]}),
    .q(\dec_ch2/i3 [34:33]));
  AL_PHY_LSLICE \dec_ch2/add7/u39_al_u2352  (
    .a({\dec_ch2/n74 [41],\dec_ch2/n74 [39]}),
    .b({\dec_ch2/n74 [42],\dec_ch2/n74 [40]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [41],\dec_ch2/i2 [39]}),
    .e({\dec_ch2/i2 [42],\dec_ch2/i2 [40]}),
    .fci(\dec_ch2/add7/c39 ),
    .mi(\dec_ch2/n76 [37:36]),
    .f({\dec_ch2/n76 [41],\dec_ch2/n76 [39]}),
    .fco(\dec_ch2/add7/c43 ),
    .fx({\dec_ch2/n76 [42],\dec_ch2/n76 [40]}),
    .q(\dec_ch2/i3 [37:36]));
  AL_PHY_LSLICE \dec_ch2/add7/u3_al_u2343  (
    .a({\dec_ch2/n74 [5],\dec_ch2/n74 [3]}),
    .b({\dec_ch2/n74 [6],\dec_ch2/n74 [4]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [5],\dec_ch2/i2 [3]}),
    .e({\dec_ch2/i2 [6],\dec_ch2/i2 [4]}),
    .fci(\dec_ch2/add7/c3 ),
    .mi({open_n14482,\dec_ch2/n73 [11]}),
    .f({\dec_ch2/n76 [5],\dec_ch2/n76 [3]}),
    .fco(\dec_ch2/add7/c7 ),
    .fx({\dec_ch2/n76 [6],\dec_ch2/n76 [4]}),
    .q({open_n14495,\dec_ch2/i2 [11]}));
  AL_PHY_LSLICE \dec_ch2/add7/u43_al_u2353  (
    .a({\dec_ch2/n74 [45],\dec_ch2/n74 [43]}),
    .b({\dec_ch2/n74 [46],\dec_ch2/n74 [44]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [45],\dec_ch2/i2 [43]}),
    .e({\dec_ch2/i2 [46],\dec_ch2/i2 [44]}),
    .fci(\dec_ch2/add7/c43 ),
    .mi({\dec_ch2/n76 [39],\dec_ch2/n76 [35]}),
    .f({\dec_ch2/n76 [45],\dec_ch2/n76 [43]}),
    .fco(\dec_ch2/add7/c47 ),
    .fx({\dec_ch2/n76 [46],\dec_ch2/n76 [44]}),
    .q({\dec_ch2/i3 [39],\dec_ch2/i3 [35]}));
  AL_PHY_LSLICE \dec_ch2/add7/u47_al_u2354  (
    .a({open_n14509,\dec_ch2/n74 [47]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({open_n14513,\dec_ch2/i2 [47]}),
    .fci(\dec_ch2/add7/c47 ),
    .mi(\dec_ch2/n76 [42:41]),
    .f({open_n14528,\dec_ch2/n76 [47]}),
    .q(\dec_ch2/i3 [42:41]));
  AL_PHY_LSLICE \dec_ch2/add7/u7_al_u2344  (
    .a({\dec_ch2/n74 [9],\dec_ch2/n74 [7]}),
    .b({\dec_ch2/n74 [10],\dec_ch2/n74 [8]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [9],\dec_ch2/i2 [7]}),
    .e({\dec_ch2/i2 [10],\dec_ch2/i2 [8]}),
    .fci(\dec_ch2/add7/c7 ),
    .mi({\dec_ch2/n73 [17],\dec_ch2/n73 [15]}),
    .f({\dec_ch2/n76 [9],\dec_ch2/n76 [7]}),
    .fco(\dec_ch2/add7/c11 ),
    .fx({\dec_ch2/n76 [10],\dec_ch2/n76 [8]}),
    .q({\dec_ch2/i2 [17],\dec_ch2/i2 [15]}));
  AL_PHY_LSLICE \dec_ch2/add7/ucin_al_u2342  (
    .a({\dec_ch2/n74 [1],1'b0}),
    .b({\dec_ch2/n74 [2],\dec_ch2/n74 [0]}),
    .c(2'b00),
    .d({\dec_ch2/i2 [1],1'b1}),
    .e({\dec_ch2/i2 [2],\dec_ch2/i2 [0]}),
    .f({\dec_ch2/n76 [1],open_n14562}),
    .fco(\dec_ch2/add7/c3 ),
    .fx({\dec_ch2/n76 [2],\dec_ch2/n76 [0]}));
  AL_PHY_MSLICE \dec_ch2/lt0/u0|dec_ch2/lt0/ucin  (
    .a({pair_l2[0],1'b0}),
    .b({pair_e2[0],open_n14565}),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n14581,pair_e2[5]}),
    .fco(\dec_ch2/lt0/c1 ),
    .q({open_n14587,\dec_ch2/pe [5]}));
  AL_PHY_MSLICE \dec_ch2/lt0/u2|dec_ch2/lt0/u1  (
    .a(pair_l2[2:1]),
    .b(pair_e2[2:1]),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt0/c1 ),
    .mi({\dec_ch2/pk2 [15],\dec_ch2/pk2 [13]}),
    .fco(\dec_ch2/lt0/c3 ),
    .q({\dec_ch2/pk3 [15],\dec_ch2/pk3 [13]}));
  AL_PHY_MSLICE \dec_ch2/lt0/u4|dec_ch2/lt0/u3  (
    .a(pair_l2[4:3]),
    .b(pair_e2[4:3]),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt0/c3 ),
    .mi({\dec_ch2/pk2 [14],\dec_ch2/pk2 [12]}),
    .fco(\dec_ch2/lt0/c5 ),
    .q({\dec_ch2/pk3 [14],\dec_ch2/pk3 [12]}));
  AL_PHY_MSLICE \dec_ch2/lt0/u6|dec_ch2/lt0/u5  (
    .a(pair_l2[6:5]),
    .b(pair_e2[6:5]),
    .fci(\dec_ch2/lt0/c5 ),
    .fco(\dec_ch2/lt0/c7 ));
  AL_PHY_MSLICE \dec_ch2/lt0/ucout|dec_ch2/lt0/u7  (
    .a({1'b0,pair_l2[7]}),
    .b({1'b1,pair_e2[7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt0/c7 ),
    .mi({open_n14662,dec_sv[2]}),
    .f({\dec_ch2/n53 ,open_n14664}),
    .q({open_n14668,dec_sv[3]}));
  AL_PHY_MSLICE \dec_ch2/lt1/u0|dec_ch2/lt1/ucin  (
    .a({pair_e2[0],1'b0}),
    .b({pair_l2[0],open_n14669}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n14684,\dec_ch2/c1 [15]}),
    .fco(\dec_ch2/lt1/c1 ),
    .q({open_n14690,\dec_ch2/c1p [15]}));
  AL_PHY_MSLICE \dec_ch2/lt1/u2|dec_ch2/lt1/u1  (
    .a(pair_e2[2:1]),
    .b(pair_l2[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt1/c1 ),
    .mi({open_n14705,\dec_sv[3]_hfnopt2_4 }),
    .fco(\dec_ch2/lt1/c3 ),
    .q({open_n14711,\dec_sv[4]_hfnopt2_0 }));
  AL_PHY_MSLICE \dec_ch2/lt1/u4|dec_ch2/lt1/u3  (
    .a(pair_e2[4:3]),
    .b(pair_l2[4:3]),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt1/c3 ),
    .mi({\dec_ch2/n78 [17],\dec_ch2/n78 [12]}),
    .fco(\dec_ch2/lt1/c5 ),
    .q({\dec_ch2/c1 [17],\dec_ch2/c1 [12]}));
  AL_PHY_MSLICE \dec_ch2/lt1/u6|dec_ch2/lt1/u5  (
    .a(pair_e2[6:5]),
    .b(pair_l2[6:5]),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt1/c5 ),
    .mi({open_n14743,\dec_ch2/c1 [26]}),
    .fco(\dec_ch2/lt1/c7 ),
    .q({open_n14749,\dec_ch2/c1p [26]}));
  AL_PHY_MSLICE \dec_ch2/lt1/ucout|dec_ch2/lt1/u7  (
    .a({1'b0,pair_e2[7]}),
    .b({1'b1,pair_l2[7]}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt1/c7 ),
    .mi({\dec_ch2/c1 [32],\dec_ch2/c1 [30]}),
    .f({\dec_ch2/n55 ,open_n14764}),
    .q({\dec_ch2/c1p [32],\dec_ch2/c1p [30]}));
  AL_PHY_MSLICE \dec_ch2/lt2/u0|dec_ch2/lt2/ucin  (
    .a({\dec_ch2/rmx [0],1'b0}),
    .b({\dec_ch2/pdx [0],open_n14768}),
    .clk(sample_write_clock_gclk_net),
    .mi({n152,\dec_ch1/pb [6]}),
    .fco(\dec_ch2/lt2/c1 ),
    .q({\dec_sv[0]_hfnopt2_0 ,pair_e1[6]}));
  AL_PHY_MSLICE \dec_ch2/lt2/u2|dec_ch2/lt2/u1  (
    .a(\dec_ch2/rmx [2:1]),
    .b(\dec_ch2/pdx [2:1]),
    .ce(\dec_ch2/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt2/c1 ),
    .mi(\dec_ch2/pdx [2:1]),
    .fco(\dec_ch2/lt2/c3 ),
    .q(\dec_ch2/rmx [2:1]));
  AL_PHY_MSLICE \dec_ch2/lt2/u4|dec_ch2/lt2/u3  (
    .a(\dec_ch2/rmx [4:3]),
    .b(\dec_ch2/pdx [4:3]),
    .ce(\dec_ch2/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt2/c3 ),
    .mi(\dec_ch2/pdx [6:5]),
    .fco(\dec_ch2/lt2/c5 ),
    .q(\dec_ch2/rmx [6:5]));
  AL_PHY_MSLICE \dec_ch2/lt2/u6|dec_ch2/lt2/u5  (
    .a(\dec_ch2/rmx [6:5]),
    .b(\dec_ch2/pdx [6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt2/c5 ),
    .mi({\dec_ch2/pmx [4],\dec_ch1/pb [5]}),
    .fco(\dec_ch2/lt2/c7 ),
    .q({\dec_ch2/pdx [4],pair_e1[5]}));
  AL_PHY_MSLICE \dec_ch2/lt2/ucout|dec_ch2/lt2/u7  (
    .a({1'b0,\dec_ch2/rmx [7]}),
    .b({1'b1,\dec_ch2/pdx [7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt2/c7 ),
    .mi({\dec_ch2/pmx [6],\dec_ch1/pa [6]}),
    .f({\dec_ch2/n57 ,open_n14859}),
    .q({\dec_ch2/pdx [6],pair_l1[6]}));
  AL_PHY_MSLICE \dec_ch2/lt3/u0|dec_ch2/lt3/ucin  (
    .a({\dec_ch2/pdn [0],1'b0}),
    .b({\dec_ch2/rmn [0],open_n14863}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [36],\dec_ch1/n86 [42]}),
    .fco(\dec_ch2/lt3/c1 ),
    .q({\dec_ch1/c2p [36],\dec_ch1/c3 [42]}));
  AL_PHY_MSLICE \dec_ch2/lt3/u2|dec_ch2/lt3/u1  (
    .a(\dec_ch2/pdn [2:1]),
    .b(\dec_ch2/rmn [2:1]),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt3/c1 ),
    .mi(\dec_ch1/n86 [44:43]),
    .fco(\dec_ch2/lt3/c3 ),
    .q(\dec_ch1/c3 [44:43]));
  AL_PHY_MSLICE \dec_ch2/lt3/u4|dec_ch2/lt3/u3  (
    .a(\dec_ch2/pdn [4:3]),
    .b(\dec_ch2/rmn [4:3]),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt3/c3 ),
    .mi({open_n14914,\dec_ch2/pk1 [10]}),
    .fco(\dec_ch2/lt3/c5 ),
    .q({open_n14920,\dec_ch2/pk2 [10]}));
  AL_PHY_MSLICE \dec_ch2/lt3/u6|dec_ch2/lt3/u5  (
    .a(\dec_ch2/pdn [6:5]),
    .b(\dec_ch2/rmn [6:5]),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt3/c5 ),
    .mi({open_n14934,\dec_ch2/pk1 [11]}),
    .fco(\dec_ch2/lt3/c7 ),
    .q({open_n14940,\dec_ch2/pk2 [11]}));
  AL_PHY_MSLICE \dec_ch2/lt3/ucout|dec_ch2/lt3/u7  (
    .a({1'b0,\dec_ch2/pdn [7]}),
    .b({1'b1,\dec_ch2/rmn [7]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\dec_ch2/lt3/c7 ),
    .mi({open_n14954,\dec_ch2/pk0 [6]}),
    .f({\dec_ch2/n59 ,open_n14956}),
    .q({open_n14960,\dec_ch2/pk1 [6]}));
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg0_b1|dec_ch2/reg0_b2  (
    .b({cic_out2[11],cic_out2[9]}),
    .c({adc2B_w[3],adc2B_w[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({adc2B_w[1],adc2B_w[2]}),
    .f({sample_dia[27],sample_dia[25]}),
    .q({\dec_ch2/pb [1],\dec_ch2/pb [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg0_b3|dec_ch2/reg0_b6  (
    .b({cic_out2[12],cic_out2[15]}),
    .c({adc2B_w[4],adc2B_w[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({adc2B_w[3],adc2B_w[6]}),
    .f({sample_dia[28],sample_dia[31]}),
    .q({\dec_ch2/pb [3],\dec_ch2/pb [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg0_b4|dec_ch2/reg0_b5  (
    .a({_al_u745_o,_al_u745_o}),
    .b({trigger_previous[7],trigger_previous[7]}),
    .c({trig_arm_f,trig_arm_r}),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_edge,trigger_edge}),
    .e({trigger_ext,trigger_ext}),
    .mi({adc2B_w[4],adc2B_w[5]}),
    .f({n255,n251}),
    .q({\dec_ch2/pb [4],\dec_ch2/pb [5]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg10_b10  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n15031,\dec_ch2/rmx [2]}),
    .q({open_n15049,\dec_ch2/pkw [10]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg10_b15  (
    .b({open_n15052,cic_out1[8]}),
    .c({open_n15053,adc1B_w[0]}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15054,_al_u745_o}),
    .mi({open_n15058,\dec_ch2/rmx [7]}),
    .f({open_n15071,sample_dia[8]}),
    .q({open_n15075,\dec_ch2/pkw [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg10_b1|dec_ch2/reg10_b6  (
    .b({\dec_ch1/c3 [32],cic_out1[1]}),
    .c({\dec_shift[3]_hfnopt2_0 ,adc1A_w[1]}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [24],_al_u745_o}),
    .mi({\dec_ch2/rmn [1],\dec_ch2/rmn [6]}),
    .f({\dec_ch1/n136_lutinv ,sample_dia[1]}),
    .q({\dec_ch2/pkw [1],\dec_ch2/pkw [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg10_b2|dec_ch2/reg10_b7  (
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/rmn [2],\dec_ch2/rmn [7]}),
    .q({\dec_ch2/pkw [2],\dec_ch2/pkw [7]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg10_b5  (
    .a({open_n15116,\dec_ch1/n123_lutinv }),
    .b({open_n15117,\dec_ch1/c3 [12]}),
    .c({open_n15118,\dec_ch1/c3 [20]}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15119,\dec_shift[3]_hfnopt2_0 }),
    .e({open_n15120,dec_shift[4]}),
    .mi({open_n15122,\dec_ch2/rmn [5]}),
    .f({open_n15135,\dec_ch1/n14_lutinv }),
    .q({open_n15139,\dec_ch2/pkw [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg10_b8|dec_ch2/reg10_b9  (
    .c({\dec_ch1/c2p [4],\dec_ch1/c2p [0]}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/rmx [0],\dec_ch2/rmx [1]}),
    .f({\dec_ch1/n85 [4],\dec_ch1/n85 [0]}),
    .q({\dec_ch2/pkw [8],\dec_ch2/pkw [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg11_b0|dec_ch2/reg11_b4  (
    .b({open_n15160,\dec_ch1/c2p [2]}),
    .c({\dec_ch1/c2p [1],\dec_ch1/k3_lutinv }),
    .ce(\dec_ch2/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,open_n15161}),
    .mi({\dec_ch2/pdx [0],\dec_ch2/pdx [4]}),
    .f({\dec_ch1/n85 [1],\dec_ch1/n85 [2]}),
    .q({\dec_ch2/rmx [0],\dec_ch2/rmx [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg11_b3|dec_ch2/reg11_b7  (
    .c({\dec_ch2/n57 ,\dec_ch1/c2p [20]}),
    .ce(\dec_ch2/mux10_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .d({n152,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/pdx [3],\dec_ch2/pdx [7]}),
    .f({\dec_ch2/mux10_b0_sel_is_0_o ,\dec_ch1/n85 [20]}),
    .q({\dec_ch2/rmx [3],\dec_ch2/rmx [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg12_b0|dec_ch2/reg12_b1  (
    .b({\dec_ch1/c3 [29],\dec_ch1/c3 [35]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_ch2/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [21],\dec_ch1/c3 [27]}),
    .mi({\dec_ch2/pdn [0],\dec_ch2/pdn [1]}),
    .f({\dec_ch1/n139_lutinv ,\dec_ch1/n124_lutinv }),
    .q({\dec_ch2/rmn [0],\dec_ch2/rmn [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg12_b2|dec_ch2/reg12_b6  (
    .a({\dec_ch1/n126_lutinv ,\dec_ch1/n120_lutinv }),
    .b({\dec_ch1/c3 [17],\dec_ch1/c3 [15]}),
    .c({\dec_ch1/c3 [9],\dec_ch1/c3 [23]}),
    .ce(\dec_ch2/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .e({dec_shift[4],dec_shift[4]}),
    .mi({\dec_ch2/pdn [2],\dec_ch2/pdn [6]}),
    .f({\dec_ch1/n17_lutinv ,\dec_ch1/n11_lutinv }),
    .q({\dec_ch2/rmn [2],\dec_ch2/rmn [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg12_b4|dec_ch2/reg12_b5  (
    .b({\dec_ch1/c3 [25],\dec_ch1/c3 [44]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_ch2/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [17],\dec_ch1/c3 [36]}),
    .mi({\dec_ch2/pdn [4],\dec_ch2/pdn [5]}),
    .f({\dec_ch1/n143_lutinv ,\dec_ch1/n115_lutinv }),
    .q({\dec_ch2/rmn [4],\dec_ch2/rmn [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg13_b0|dec_ch2/reg13_b1  (
    .b(n291[2:1]),
    .c(n292[2:1]),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({n290,n290}),
    .mi({\dec_ch2/pkw [0],\dec_ch2/pkw [1]}),
    .f(n293[2:1]),
    .q({\dec_ch2/pk0 [0],\dec_ch2/pk0 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg13_b12|dec_ch2/reg13_b8  (
    .c({\dec_ch1/c2p [5],\dec_ch1/c2p [6]}),
    .ce(\dec_sv[0]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/pkw [12],\dec_ch2/pkw [8]}),
    .f({\dec_ch1/n85 [5],\dec_ch1/n85 [6]}),
    .q({\dec_ch2/pk0 [12],\dec_ch2/pk0 [8]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg13_b13  (
    .a({open_n15296,\dec_ch1/c2p [3]}),
    .c({open_n15299,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[0]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n15312,\dec_ch2/pkw [13]}),
    .f({open_n15314,\dec_ch1/n85 [3]}),
    .q({open_n15318,\dec_ch2/pk0 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg13_b15|dec_ch2/reg13_b9  (
    .b({cic_out1[9],cic_out1[10]}),
    .c({adc1B_w[1],adc1B_w[2]}),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/pkw [15],\dec_ch2/pkw [9]}),
    .f({sample_dia[9],sample_dia[10]}),
    .q({\dec_ch2/pk0 [15],\dec_ch2/pk0 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg13_b2|dec_ch2/reg13_b3  (
    .a({_al_u1870_o,_al_u1870_o}),
    .b({_al_u1873_o,_al_u1865_o}),
    .c({_al_u1876_o,_al_u1894_o}),
    .ce(\dec_sv[0]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[2],dec_shift[2]}),
    .mi({\dec_ch2/pkw [2],\dec_ch2/pkw [3]}),
    .f({_al_u1877_o,_al_u1933_o}),
    .q({\dec_ch2/pk0 [2],\dec_ch2/pk0 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg13_b4|dec_ch2/reg13_b6  (
    .b({cic_out1[6],cic_out1[0]}),
    .c({adc1A_w[6],adc1A_w[0]}),
    .ce(\dec_sv[0]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/pkw [4],\dec_ch2/pkw [6]}),
    .f({sample_dia[6],sample_dia[0]}),
    .q({\dec_ch2/pk0 [4],\dec_ch2/pk0 [6]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg13_b5  (
    .b({open_n15375,\dec_ch1/c3 [5]}),
    .c({open_n15376,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[0]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15377,\dec_ch1/c3 [13]}),
    .mi({open_n15388,\dec_ch2/pkw [5]}),
    .f({open_n15390,_al_u971_o}),
    .q({open_n15394,\dec_ch2/pk0 [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg14_b0|dec_ch2/reg23_b2  (
    .b({n291[0],n291[5]}),
    .c({n292[0],n292[5]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({n290,n290}),
    .mi({\dec_ch2/pk0 [0],\dec_ch2/d0 [2]}),
    .f({n293[0],n293[5]}),
    .q({\dec_ch2/pk1 [0],\dec_ch2/d0p [2]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg14_b10  (
    .b({open_n15417,cic_out1[12]}),
    .c({open_n15418,adc1B_w[4]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15419,_al_u745_o}),
    .mi({open_n15423,\dec_ch2/pk0 [10]}),
    .f({open_n15436,sample_dia[12]}),
    .q({open_n15440,\dec_ch2/pk1 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg14_b11|dec_ch2/reg14_b9  (
    .b({cic_out1[13],cic_out1[15]}),
    .c({adc1B_w[5],adc1B_w[7]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/pk0 [11],\dec_ch2/pk0 [9]}),
    .f({sample_dia[13],sample_dia[15]}),
    .q({\dec_ch2/pk1 [11],\dec_ch2/pk1 [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg14_b12|dec_ch2/reg14_b13  (
    .c({\dec_order[1]_hfnopt2_1 ,\dec_ch1/c2p [26]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c1p [26],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/pk0 [12],\dec_ch2/pk0 [13]}),
    .f({\dec_ch1/n81 [26],\dec_ch1/n85 [26]}),
    .q({\dec_ch2/pk1 [12],\dec_ch2/pk1 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg14_b2|dec_ch2/reg22_b28  (
    .a({open_n15479,_al_u1870_o}),
    .b({\dec_ch1/n237_lutinv ,_al_u1900_o}),
    .c({dec_shift[1],_al_u1902_o}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n235_lutinv ,dec_shift[2]}),
    .mi({\dec_ch2/pk0 [2],\dec_ch2/n78 [28]}),
    .f({_al_u1905_o,_al_u1903_o}),
    .q({\dec_ch2/pk1 [2],\dec_ch2/c1 [28]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg14_b3|dec_ch2/reg22_b15  (
    .a({open_n15498,_al_u1870_o}),
    .b({\dec_ch1/n238_lutinv ,_al_u1897_o}),
    .c({dec_shift[1],_al_u1915_o}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n236_lutinv ,dec_shift[2]}),
    .mi({\dec_ch2/pk0 [3],\dec_ch2/n78 [15]}),
    .f({_al_u1876_o,_al_u1916_o}),
    .q({\dec_ch2/pk1 [3],\dec_ch2/c1 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg14_b5|dec_ch2/reg14_b4  (
    .b({\dec_ch1/c3 [26],\dec_ch1/c3 [42]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [18],\dec_ch1/c3 [34]}),
    .mi(\dec_ch2/pk0 [5:4]),
    .f({\dec_ch1/n142_lutinv ,\dec_ch1/n117_lutinv }),
    .q(\dec_ch2/pk1 [5:4]));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg14_b7  (
    .c({open_n15537,\dec_ch2/n59 }),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15538,n152}),
    .mi({open_n15549,\dec_ch2/pk0 [7]}),
    .f({open_n15551,\dec_ch2/mux11_b0_sel_is_0_o }),
    .q({open_n15555,\dec_ch2/pk1 [7]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg14_b8  (
    .c({open_n15560,\dec_ch1/c2p [42]}),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15561,\dec_ch1/k3_lutinv }),
    .mi({open_n15572,\dec_ch2/pk0 [8]}),
    .f({open_n15574,\dec_ch1/n85 [42]}),
    .q({open_n15578,\dec_ch2/pk1 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg15_b0|dec_ch2/reg15_b9  (
    .a({\dec_ch1/n122_lutinv ,\dec_ch1/n124_lutinv }),
    .b({\dec_ch1/c3 [13],\dec_ch1/c3 [11]}),
    .c({\dec_ch1/c3 [21],\dec_ch1/c3 [19]}),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .e({dec_shift[4],dec_shift[4]}),
    .mi({\dec_ch2/pk1 [0],\dec_ch2/pk1 [9]}),
    .f({\dec_ch1/n13_lutinv ,\dec_ch1/n15_lutinv }),
    .q({\dec_ch2/pk2 [0],\dec_ch2/pk2 [9]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg15_b1  (
    .b({open_n15597,\dec_ch1/c3 [39]}),
    .c({open_n15598,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[2]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15599,\dec_ch1/c3 [31]}),
    .mi({open_n15610,\dec_ch2/pk1 [1]}),
    .f({open_n15612,\dec_ch1/n120_lutinv }),
    .q({open_n15616,\dec_ch2/pk2 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg15_b12|dec_ch2/reg15_b13  (
    .b({open_n15619,\dec_ch2/pe [1]}),
    .c({\dec_ch2/pe [2],open_n15620}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/pk1 [12],\dec_ch2/pk1 [13]}),
    .f(\dec_ch2/t_pe [2:1]),
    .q({\dec_ch2/pk2 [12],\dec_ch2/pk2 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg15_b2|dec_ch2/reg15_b3  (
    .b(\dec_ch1/sh [9:8]),
    .c({dec_shift[0],dec_shift[0]}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d(\dec_ch1/sh [8:7]),
    .mi({\dec_ch2/pk1 [2],\dec_ch2/pk1 [3]}),
    .f({\dec_ch1/n239_lutinv ,\dec_ch1/n240_lutinv }),
    .q({\dec_ch2/pk2 [2],\dec_ch2/pk2 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg15_b6|dec_ch2/reg15_b5  (
    .a({open_n15659,_al_u1907_o}),
    .b({_al_u1939_o,\dec_ch1/n243_lutinv }),
    .c({dec_shift[2],\dec_ch1/n245_lutinv }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1911_o,dec_shift[1]}),
    .e({open_n15660,dec_shift[2]}),
    .mi(\dec_ch2/pk1 [6:5]),
    .f({\dec_ch1/fine [1],_al_u1923_o}),
    .q(\dec_ch2/pk2 [6:5]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg16_b0|dec_ch2/reg16_b1  (
    .a({_al_u1870_o,_al_u1870_o}),
    .b({_al_u1905_o,_al_u1894_o}),
    .c({_al_u1928_o,_al_u1897_o}),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[2],dec_shift[2]}),
    .mi({\dec_ch2/pk2 [0],\dec_ch2/pk2 [1]}),
    .f({_al_u1937_o,_al_u1898_o}),
    .q({\dec_ch2/pk3 [0],\dec_ch2/pk3 [1]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg16_b10  (
    .b({open_n15697,_al_u1942_o}),
    .c({open_n15698,dec_shift[2]}),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15699,_al_u1915_o}),
    .mi({open_n15710,\dec_ch2/pk2 [10]}),
    .f({open_n15712,\dec_ch1/fine [0]}),
    .q({open_n15716,\dec_ch2/pk3 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg16_b2|dec_ch2/reg16_b3  (
    .b({\dec_ch2/n240_lutinv ,\dec_ch2/n242_lutinv }),
    .c({dec_shift[1],dec_shift[1]}),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n238_lutinv ,\dec_ch2/n240_lutinv }),
    .mi({\dec_ch2/pk2 [2],\dec_ch2/pk2 [3]}),
    .f({_al_u1804_o,_al_u1814_o}),
    .q({\dec_ch2/pk3 [2],\dec_ch2/pk3 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg16_b5|dec_ch2/reg16_b7  (
    .b({\dec_ch1/sh [5],\dec_ch1/sh [7]}),
    .c({dec_shift[0],dec_shift[0]}),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [4],\dec_ch1/sh [6]}),
    .mi({\dec_ch2/pk2 [5],\dec_ch2/pk2 [7]}),
    .f({\dec_ch1/n243_lutinv ,\dec_ch1/n241_lutinv }),
    .q({\dec_ch2/pk3 [5],\dec_ch2/pk3 [7]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg16_b8  (
    .c({open_n15757,peak_en}),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15758,\dec_ch2/pk4 [6]}),
    .mi({open_n15769,\dec_ch2/pk2 [8]}),
    .f({open_n15771,_al_u1811_o}),
    .q({open_n15775,\dec_ch2/pk3 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg16_b9|dec_ch2/reg16_b11  (
    .a({open_n15776,_al_u1870_o}),
    .b({\dec_ch1/n235_lutinv ,_al_u1876_o}),
    .c({dec_shift[1],_al_u1911_o}),
    .ce(dec_sv[3]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n233_lutinv ,dec_shift[2]}),
    .mi({\dec_ch2/pk2 [9],\dec_ch2/pk2 [11]}),
    .f({_al_u1894_o,_al_u1912_o}),
    .q({\dec_ch2/pk3 [9],\dec_ch2/pk3 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg17_b0|dec_ch2/reg17_b1  (
    .a({\dec_ch1/n238_lutinv ,open_n15791}),
    .b({dec_shift[1],\dec_ch1/sh [9]}),
    .c({\dec_ch1/n240_lutinv ,dec_shift[0]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15792,\dec_ch1/sh [10]}),
    .mi({\dec_ch2/pk3 [0],\dec_ch2/pk3 [1]}),
    .f({_al_u1902_o,\dec_ch1/n238_lutinv }),
    .q({\dec_ch2/pk4 [0],\dec_ch2/pk4 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg17_b12|dec_ch2/reg28_b2  (
    .a({\dec_ch2/pk4 [12],\dec_ch2/n117_lutinv }),
    .b({open_n15807,\dec_ch2/n142_lutinv }),
    .c({peak_en,_al_u889_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15808,dec_shift[4]}),
    .e({open_n15809,dec_shift[5]}),
    .mi({\dec_ch2/pk3 [12],open_n15811}),
    .f({_al_u1842_o,open_n15824}),
    .q({\dec_ch2/pk4 [12],\dec_ch2/sh [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg17_b13|dec_ch2/reg17_b5  (
    .a({\dec_ch2/pk4 [13],open_n15828}),
    .c({peak_en,peak_en}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n15831,\dec_ch2/pk4 [8]}),
    .mi({\dec_ch2/pk3 [13],\dec_ch2/pk3 [5]}),
    .f({_al_u1839_o,_al_u1801_o}),
    .q({\dec_ch2/pk4 [13],\dec_ch2/pk4 [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg17_b2|dec_ch2/reg17_b8  (
    .b(\dec_ch2/sh [6:5]),
    .c({dec_shift[0],dec_shift[0]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d(\dec_ch2/sh [5:4]),
    .mi({\dec_ch2/pk3 [2],\dec_ch2/pk3 [8]}),
    .f({\dec_ch2/n242_lutinv ,\dec_ch2/n243_lutinv }),
    .q({\dec_ch2/pk4 [2],\dec_ch2/pk4 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg17_b3|dec_ch2/reg17_b7  (
    .a({open_n15870,\dec_ch2/n244_lutinv }),
    .b({\dec_ch2/n241_lutinv ,\dec_ch2/n242_lutinv }),
    .c({dec_shift[1],_al_u1804_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n239_lutinv ,dec_shift[1]}),
    .e({open_n15871,dec_shift[2]}),
    .mi({\dec_ch2/pk3 [3],\dec_ch2/pk3 [7]}),
    .f({_al_u1809_o,\dec_ch2/fine [3]}),
    .q({\dec_ch2/pk4 [3],\dec_ch2/pk4 [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg17_b4|dec_ch2/reg17_b6  (
    .c({peak_en,peak_en}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/pk4 [14],\dec_ch2/pk4 [15]}),
    .mi({\dec_ch2/pk3 [4],\dec_ch2/pk3 [6]}),
    .f({_al_u1836_o,_al_u1832_o}),
    .q({\dec_ch2/pk4 [4],\dec_ch2/pk4 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg18_b0|dec_ch2/reg20_b0  (
    .c({\dec_ch2/i3 [1],\dec_ch2/i3 [2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n70 [0],\dec_ch2/n76 [0]}),
    .f({\dec_ch2/n74 [1],\dec_ch2/n74 [2]}),
    .q({\dec_ch2/i1 [0],\dec_ch2/i3 [0]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg18_b10|dec_ch2/reg18_b11  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n70 [10],\dec_ch2/n70 [11]}),
    .q({\dec_ch2/i1 [10],\dec_ch2/i1 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg18_b15|dec_ch2/reg18_b24  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n70 [15],\dec_ch2/n70 [24]}),
    .q({\dec_ch2/i1 [15],\dec_ch2/i1 [24]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg18_b19|dec_ch2/reg18_b21  (
    .b(n291[4:3]),
    .c(n292[4:3]),
    .clk(sample_write_clock_gclk_net),
    .d({n290,n290}),
    .mi({\dec_ch2/n70 [19],\dec_ch2/n70 [21]}),
    .f(n293[4:3]),
    .q({\dec_ch2/i1 [19],\dec_ch2/i1 [21]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg18_b23|dec_ch2/reg18_b25  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n70 [23],\dec_ch2/n70 [25]}),
    .q({\dec_ch2/i1 [23],\dec_ch2/i1 [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg18_b39|dec_ch2/reg18_b42  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n70 [39],\dec_ch2/n70 [42]}),
    .q({\dec_ch2/i1 [39],\dec_ch2/i1 [42]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg18_b40|dec_ch2/reg18_b41  (
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n70 [40],\dec_ch2/n70 [41]}),
    .q({\dec_ch2/i1 [40],\dec_ch2/i1 [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b10|dec_ch2/reg19_b9  (
    .a(\dec_ch2/i2 [10:9]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[1],dec_order[1]}),
    .mi(\dec_ch2/n73 [10:9]),
    .f(\dec_ch2/n71 [10:9]),
    .q(\dec_ch2/i2 [10:9]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b12|dec_ch2/reg19_b16  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [11],\dec_ch2/i2 [14]}),
    .mi({\dec_ch2/n73 [12],\dec_ch2/n73 [16]}),
    .f({\dec_ch2/n71 [11],\dec_ch2/n71 [14]}),
    .q({\dec_ch2/i2 [12],\dec_ch2/i2 [16]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b13|dec_ch2/reg19_b14  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [12],\dec_ch2/i2 [13]}),
    .mi({\dec_ch2/n73 [13],\dec_ch2/n73 [14]}),
    .f({\dec_ch2/n71 [12],\dec_ch2/n71 [13]}),
    .q({\dec_ch2/i2 [13],\dec_ch2/i2 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b18|dec_ch2/reg20_b18  (
    .a({open_n16148,\dec_ch2/i3 [18]}),
    .c({dec_order[1],\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [15],open_n16152}),
    .mi({\dec_ch2/n73 [18],\dec_ch2/n76 [18]}),
    .f({\dec_ch2/n71 [15],\dec_ch2/n74 [18]}),
    .q({\dec_ch2/i2 [18],\dec_ch2/i3 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b1|dec_ch2/reg19_b2  (
    .c({\dec_ch2/i3 [3],\dec_ch2/i3 [6]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n73 [1],\dec_ch2/n73 [2]}),
    .f({\dec_ch2/n74 [3],\dec_ch2/n74 [6]}),
    .q({\dec_ch2/i2 [1],\dec_ch2/i2 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b24|dec_ch2/reg19_b30  (
    .c({dec_order[1],\dec_ch2/i3 [14]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [16],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n73 [24],\dec_ch2/n73 [30]}),
    .f({\dec_ch2/n71 [16],\dec_ch2/n74 [14]}),
    .q({\dec_ch2/i2 [24],\dec_ch2/i2 [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b25|dec_ch2/reg19_b26  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [17],\dec_ch2/i2 [18]}),
    .mi({\dec_ch2/n73 [25],\dec_ch2/n73 [26]}),
    .f({\dec_ch2/n71 [17],\dec_ch2/n71 [18]}),
    .q({\dec_ch2/i2 [25],\dec_ch2/i2 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b29|dec_ch2/reg20_b11  (
    .c({\dec_ch2/i3 [12],\dec_ch2/i3 [7]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n73 [29],\dec_ch2/n76 [11]}),
    .f({\dec_ch2/n74 [12],\dec_ch2/n74 [7]}),
    .q({\dec_ch2/i2 [29],\dec_ch2/i3 [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b34|dec_ch2/reg20_b17  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [31],\dec_ch2/i2 [23]}),
    .mi({\dec_ch2/n73 [34],\dec_ch2/n76 [17]}),
    .f({\dec_ch2/n71 [31],\dec_ch2/n71 [23]}),
    .q({\dec_ch2/i2 [34],\dec_ch2/i3 [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b35|dec_ch2/reg20_b23  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [32],\dec_ch2/i2 [33]}),
    .mi({\dec_ch2/n73 [35],\dec_ch2/n76 [23]}),
    .f({\dec_ch2/n71 [32],\dec_ch2/n71 [33]}),
    .q({\dec_ch2/i2 [35],\dec_ch2/i3 [23]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b36|dec_ch2/reg20_b31  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [35],\dec_ch2/i2 [38]}),
    .mi({\dec_ch2/n73 [36],\dec_ch2/n76 [31]}),
    .f({\dec_ch2/n71 [35],\dec_ch2/n71 [38]}),
    .q({\dec_ch2/i2 [36],\dec_ch2/i3 [31]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b37|dec_ch2/reg19_b43  (
    .c({\dec_ch2/i2 [36],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[1],\dec_ch2/i2 [42]}),
    .mi({\dec_ch2/n73 [37],\dec_ch2/n73 [43]}),
    .f({\dec_ch2/n71 [36],\dec_ch2/n71 [42]}),
    .q({\dec_ch2/i2 [37],\dec_ch2/i2 [43]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b3|dec_ch2/reg19_b6  (
    .a({\dec_ch2/i2 [3],\dec_ch2/i2 [6]}),
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n73 [3],\dec_ch2/n73 [6]}),
    .f({\dec_ch2/n71 [3],\dec_ch2/n71 [6]}),
    .q({\dec_ch2/i2 [3],\dec_ch2/i2 [6]}));  // zaklad.v(277)
  // zaklad.v(1388)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b41|reg12_b6  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [40],\dec_ch2/i2 [41]}),
    .mi({\dec_ch2/n73 [41],cap_h[22]}),
    .f({\dec_ch2/n71 [40],\dec_ch2/n71 [41]}),
    .q({\dec_ch2/i2 [41],adc2A_w[6]}));  // zaklad.v(1388)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b47|dec_ch2/reg19_b38  (
    .b({n314[0],open_n16387}),
    .c({n313[0],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({n312,\dec_ch2/i2 [37]}),
    .mi({\dec_ch2/n73 [47],\dec_ch2/n73 [38]}),
    .f({n315[0],\dec_ch2/n71 [37]}),
    .q({\dec_ch2/i2 [47],\dec_ch2/i2 [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg19_b4|dec_ch2/reg19_b5  (
    .a({\dec_ch2/i2 [4],\dec_ch2/i2 [5]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[1],dec_order[1]}),
    .mi({\dec_ch2/n73 [4],\dec_ch2/n73 [5]}),
    .f({\dec_ch2/n71 [4],\dec_ch2/n71 [5]}),
    .q({\dec_ch2/i2 [4],\dec_ch2/i2 [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg19_b7|dec_ch2/reg19_b8  (
    .a({\dec_ch2/i2 [7],\dec_ch2/i2 [8]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[1],dec_order[1]}),
    .mi({\dec_ch2/n73 [7],\dec_ch2/n73 [8]}),
    .f({\dec_ch2/n71 [7],\dec_ch2/n71 [8]}),
    .q({\dec_ch2/i2 [7],\dec_ch2/i2 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg20_b10|dec_ch2/reg20_b13  (
    .a({\dec_ch2/i3 [10],open_n16445}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch2/i3 [8]}),
    .clk(sample_write_clock_gclk_net),
    .d({open_n16449,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n76 [10],\dec_ch2/n76 [13]}),
    .f({\dec_ch2/n74 [10],\dec_ch2/n74 [8]}),
    .q({\dec_ch2/i3 [10],\dec_ch2/i3 [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg20_b16|dec_ch2/reg20_b24  (
    .a({\dec_ch2/i3 [16],\dec_ch2/i3 [24]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n76 [16],\dec_ch2/n76 [24]}),
    .f({\dec_ch2/n74 [16],\dec_ch2/n74 [24]}),
    .q({\dec_ch2/i3 [16],\dec_ch2/i3 [24]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg20_b1|dec_ch2/reg20_b2  (
    .c({\dec_ch2/i3 [4],\dec_ch2/i3 [5]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n76 [1],\dec_ch2/n76 [2]}),
    .f({\dec_ch2/n74 [4],\dec_ch2/n74 [5]}),
    .q({\dec_ch2/i3 [1],\dec_ch2/i3 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg21_b12|dec_ch2/reg21_b14  (
    .c({\dec_ch2/i3 [11],\dec_ch2/i3 [13]}),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/i3 [12],\dec_ch2/i3 [14]}),
    .f({\dec_ch2/n74 [11],\dec_ch2/n74 [13]}),
    .q({\dec_ch2/d0 [12],\dec_ch2/d0 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg21_b16|dec_ch2/reg21_b18  (
    .c({\dec_ch2/i3 [15],\dec_ch2/i3 [17]}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/i3 [16],\dec_ch2/i3 [18]}),
    .f({\dec_ch2/n74 [15],\dec_ch2/n74 [17]}),
    .q({\dec_ch2/d0 [16],\dec_ch2/d0 [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg21_b21|dec_ch2/reg21_b22  (
    .c({\dec_ch2/i2 [27],dec_order[1]}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[1],\dec_ch2/i2 [30]}),
    .mi({\dec_ch2/i3 [21],\dec_ch2/i3 [22]}),
    .f({\dec_ch2/n71 [27],\dec_ch2/n71 [30]}),
    .q({\dec_ch2/d0 [21],\dec_ch2/d0 [22]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg21_b24|dec_ch2/reg21_b25  (
    .c({dec_order[1],\dec_ch2/i3 [23]}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [34],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/i3 [24],\dec_ch2/i3 [25]}),
    .f({\dec_ch2/n71 [34],\dec_ch2/n74 [23]}),
    .q({\dec_ch2/d0 [24],\dec_ch2/d0 [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg21_b45|dec_ch2/reg21_b43  (
    .c({trigger_level[0],trigger_level[2]}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_data[0],trigger_data[2]}),
    .mi({\dec_ch2/i3 [45],\dec_ch2/i3 [43]}),
    .f({_al_u2183_o,_al_u2184_o}),
    .q({\dec_ch2/d0 [45],\dec_ch2/d0 [43]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg21_b46|dec_ch2/reg21_b44  (
    .a({trigger_data[2],_al_u2182_o}),
    .b({trigger_data[3],_al_u2183_o}),
    .c({trigger_level[2],_al_u2184_o}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_level[3],trigger_data[1]}),
    .e({open_n16604,trigger_level[1]}),
    .mi({\dec_ch2/i3 [46],\dec_ch2/i3 [44]}),
    .f({_al_u2182_o,_al_u2185_o}),
    .q({\dec_ch2/d0 [46],\dec_ch2/d0 [44]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b16|dec_ch2/reg23_b17  (
    .b({\dec_ch1/c3 [33],cic_out1[5]}),
    .c({\dec_shift[3]_hfnopt2_0 ,adc1A_w[5]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [25],_al_u745_o}),
    .mi({\dec_ch2/n78 [16],\dec_ch2/d0 [17]}),
    .f({\dec_ch1/n126_lutinv ,sample_dia[5]}),
    .q({\dec_ch2/c1 [16],\dec_ch2/d0p [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b18|dec_ch2/reg22_b19  (
    .b({\dec_ch1/c3 [47],cic_out1[3]}),
    .c({\dec_shift[3]_hfnopt2_0 ,adc1A_w[3]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [39],_al_u745_o}),
    .mi({\dec_ch2/n78 [18],\dec_ch2/n78 [19]}),
    .f({\dec_ch1/n112_lutinv ,sample_dia[3]}),
    .q({\dec_ch2/c1 [18],\dec_ch2/c1 [19]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b22|dec_ch2/reg22_b20  (
    .a({open_n16657,cic_out1[1]}),
    .b({\dec_ch1/c3 [43],cic_out2[1]}),
    .c({\dec_shift[3]_hfnopt2_0 ,peak_en}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [35],trigger_channel}),
    .mi({\dec_ch2/n78 [22],\dec_ch2/n78 [20]}),
    .f({\dec_ch1/n116_lutinv ,dec_trig_sample[1]}),
    .q({\dec_ch2/c1 [22],\dec_ch2/c1 [20]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b25|dec_ch2/reg22_b24  (
    .a(cic_out1[1:0]),
    .b({cic_out1[9],cic_out2[0]}),
    .c({_al_u687_o,peak_en}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi(\dec_ch2/n78 [25:24]),
    .f({dec_trig_sample[9],dec_trig_sample[0]}),
    .q(\dec_ch2/c1 [25:24]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b27|dec_ch2/reg22_b31  (
    .a({cic_out1[12],cic_out1[14]}),
    .b({cic_out1[4],cic_out1[6]}),
    .c({_al_u697_o,_al_u693_o}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [27],\dec_ch2/n78 [31]}),
    .f({dec_trig_sample[12],dec_trig_sample[14]}),
    .q({\dec_ch2/c1 [27],\dec_ch2/c1 [31]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b29|dec_ch2/reg22_b30  (
    .a({cic_out1[10],cic_out1[6]}),
    .b({cic_out1[2],cic_out2[6]}),
    .c({_al_u701_o,peak_en}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [29],\dec_ch2/n78 [30]}),
    .f({dec_trig_sample[10],dec_trig_sample[6]}),
    .q({\dec_ch2/c1 [29],\dec_ch2/c1 [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b2|dec_ch2/reg22_b1  (
    .a({open_n16722,\dec_ch2/n19 [5]}),
    .b({open_n16723,pair_e2[5]}),
    .c({\dec_ch1/k3_lutinv ,pair_e2[6]}),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n18 ,dec_order[0]}),
    .e({open_n16724,\dec_order[1]_hfnopt2_3 }),
    .mi(\dec_ch2/n78 [2:1]),
    .f({\dec_ch2/t_xe [9],\dec_ch2/t_xe [6]}),
    .q(\dec_ch2/c1 [2:1]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b32|dec_ch2/reg22_b34  (
    .a({cic_out1[4],cic_out1[5]}),
    .b({cic_out2[4],cic_out2[5]}),
    .c({peak_en,peak_en}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [32],\dec_ch2/n78 [34]}),
    .f({dec_trig_sample[4],dec_trig_sample[5]}),
    .q({\dec_ch2/c1 [32],\dec_ch2/c1 [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b33|dec_ch2/reg22_b26  (
    .a({cic_out1[0],cic_out1[2]}),
    .b({cic_out1[8],cic_out2[2]}),
    .c({_al_u689_o,peak_en}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [33],\dec_ch2/n78 [26]}),
    .f({dec_trig_sample[8],dec_trig_sample[2]}),
    .q({\dec_ch2/c1 [33],\dec_ch2/c1 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b37|dec_ch2/reg22_b40  (
    .a({mux9_b10_sel_is_3_o,cic_out1[7]}),
    .b({cic_out2[2],cic_out2[7]}),
    .c({cic_out2[10],peak_en}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [37],\dec_ch2/n78 [40]}),
    .f({_al_u701_o,dec_trig_sample[7]}),
    .q({\dec_ch2/c1 [37],\dec_ch2/c1 [40]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b39|dec_ch2/reg23_b40  (
    .b({\dec_ch1/sh [28],\dec_ch1/c3 [41]}),
    .c({\dec_ch1/sh [32],\dec_shift[3]_hfnopt2_1 }),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1888_o,\dec_ch1/c3 [33]}),
    .mi({\dec_ch2/n78 [39],\dec_ch2/d0 [40]}),
    .f({_al_u1889_o,\dec_ch1/n118_lutinv }),
    .q({\dec_ch2/c1 [39],\dec_ch2/d0p [40]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b41|dec_ch2/reg22_b42  (
    .a({cic_out1[15],mux9_b10_sel_is_3_o}),
    .b({cic_out1[7],cic_out2[8]}),
    .c({_al_u691_o,cic_out2[0]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [41],\dec_ch2/n78 [42]}),
    .f({dec_trig_sample[15],_al_u689_o}),
    .q({\dec_ch2/c1 [41],\dec_ch2/c1 [42]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b43|dec_ch2/reg22_b45  (
    .a({mux9_b10_sel_is_3_o,mux9_b10_sel_is_3_o}),
    .b({cic_out2[9],cic_out2[5]}),
    .c({cic_out2[1],cic_out2[13]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [43],\dec_ch2/n78 [45]}),
    .f({_al_u687_o,_al_u695_o}),
    .q({\dec_ch2/c1 [43],\dec_ch2/c1 [45]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg22_b44|dec_ch2/reg22_b47  (
    .a({mux9_b10_sel_is_3_o,mux9_b10_sel_is_3_o}),
    .b({cic_out2[3],cic_out2[7]}),
    .c({cic_out2[11],cic_out2[15]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [44],\dec_ch2/n78 [47]}),
    .f({_al_u699_o,_al_u691_o}),
    .q({\dec_ch2/c1 [44],\dec_ch2/c1 [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b46|dec_ch2/reg23_b35  (
    .a({mux9_b10_sel_is_3_o,mux9_b10_sel_is_3_o}),
    .b({cic_out2[6],cic_out2[4]}),
    .c({cic_out2[14],cic_out2[12]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_ch2/n78 [46],\dec_ch2/d0 [35]}),
    .f({_al_u693_o,_al_u697_o}),
    .q({\dec_ch2/c1 [46],\dec_ch2/d0p [35]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b5|dec_ch2/reg22_b9  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [15],\dec_ch2/c1p [18]}),
    .mi({\dec_ch2/n78 [5],\dec_ch2/n78 [9]}),
    .f({\dec_ch2/n81 [15],\dec_ch2/n81 [18]}),
    .q({\dec_ch2/c1 [5],\dec_ch2/c1 [9]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg22_b6  (
    .c({open_n16889,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n16890,\dec_ch2/c1p [14]}),
    .mi({open_n16901,\dec_ch2/n78 [6]}),
    .f({open_n16903,\dec_ch2/n81 [14]}),
    .q({open_n16907,\dec_ch2/c1 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg23_b14|dec_ch2/reg23_b7  (
    .b({\dec_ch1/c3 [31],\dec_ch1/c3 [37]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [23],\dec_ch1/c3 [29]}),
    .mi({\dec_ch2/d0 [14],\dec_ch2/d0 [7]}),
    .f({\dec_ch1/n137_lutinv ,\dec_ch1/n122_lutinv }),
    .q({\dec_ch2/d0p [14],\dec_ch2/d0p [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg23_b18|dec_ch2/reg22_b14  (
    .b({\dec_ch1/c3 [46],cic_out1[4]}),
    .c({\dec_shift[3]_hfnopt2_0 ,adc1A_w[4]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [38],_al_u745_o}),
    .mi({\dec_ch2/d0 [18],\dec_ch2/n78 [14]}),
    .f({\dec_ch1/n113_lutinv ,sample_dia[4]}),
    .q({\dec_ch2/d0p [18],\dec_ch2/c1 [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg23_b1|dec_ch2/reg23_b6  (
    .b({n291[6],n291[7]}),
    .c({n292[6],n292[7]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({n290,n290}),
    .mi({\dec_ch2/d0 [1],\dec_ch2/d0 [6]}),
    .f({n293[6],n293[7]}),
    .q({\dec_ch2/d0p [1],\dec_ch2/d0p [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg23_b22|dec_ch2/reg22_b21  (
    .b({\dec_ch1/c3 [40],cic_out1[7]}),
    .c({\dec_shift[3]_hfnopt2_0 ,adc1A_w[7]}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [32],_al_u745_o}),
    .mi({\dec_ch2/d0 [22],\dec_ch2/n78 [21]}),
    .f({\dec_ch1/n119_lutinv ,sample_dia[7]}),
    .q({\dec_ch2/d0p [22],\dec_ch2/c1 [21]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg23_b25|dec_ch2/reg23_b37  (
    .b({cic_out2[0],cic_out2[3]}),
    .c({adc2A_w[0],adc2A_w[3]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/d0 [25],\dec_ch2/d0 [37]}),
    .f({sample_dia[16],sample_dia[19]}),
    .q({\dec_ch2/d0p [25],\dec_ch2/d0p [37]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg23_b28|dec_ch2/reg23_b30  (
    .b({cic_out2[2],cic_out2[6]}),
    .c({adc2A_w[2],adc2A_w[6]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/d0 [28],\dec_ch2/d0 [30]}),
    .f({sample_dia[18],sample_dia[22]}),
    .q({\dec_ch2/d0p [28],\dec_ch2/d0p [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg23_b29|dec_ch2/reg23_b32  (
    .b({cic_out2[1],cic_out2[5]}),
    .c({adc2A_w[1],adc2A_w[5]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/d0 [29],\dec_ch2/d0 [32]}),
    .f({sample_dia[17],sample_dia[21]}),
    .q({\dec_ch2/d0p [29],\dec_ch2/d0p [32]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg23_b31|dec_ch2/reg23_b42  (
    .b({cic_out2[4],cic_out2[7]}),
    .c({adc2A_w[4],adc2A_w[7]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\dec_ch2/d0 [31],\dec_ch2/d0 [42]}),
    .f({sample_dia[20],sample_dia[23]}),
    .q({\dec_ch2/d0p [31],\dec_ch2/d0p [42]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg23_b3|dec_ch2/reg14_b1  (
    .b({\dec_ch1/c3 [7],\dec_ch1/c3 [38]}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_shift[3]_hfnopt2_0 }),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [15],\dec_ch1/c3 [30]}),
    .mi({\dec_ch2/d0 [3],\dec_ch2/pk0 [1]}),
    .f({_al_u967_o,\dec_ch1/n121_lutinv }),
    .q({\dec_ch2/d0p [3],\dec_ch2/pk1 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b0|dec_ch2/reg24_b2  (
    .c({\dec_ch1/i3 [45],\dec_ch1/i3 [47]}),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n82 [0],\dec_ch2/n82 [2]}),
    .f({\dec_ch1/n74 [45],\dec_ch1/n74 [47]}),
    .q({\dec_ch2/c2 [0],\dec_ch2/c2 [2]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b10  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n17108,\dec_ch2/n82 [10]}),
    .q({open_n17115,\dec_ch2/c2 [10]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b11|dec_ch2/reg24_b13  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n82 [11],\dec_ch2/n82 [13]}),
    .q({\dec_ch2/c2 [11],\dec_ch2/c2 [13]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b12  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n17155,\dec_ch2/n82 [12]}),
    .q({open_n17173,\dec_ch2/c2 [12]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b14|dec_ch2/reg24_b1  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_ch1/i3 [46]}),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/i2 [47],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/n82 [14],\dec_ch2/n82 [1]}),
    .f({\dec_ch1/n71 [47],\dec_ch1/n74 [46]}),
    .q({\dec_ch2/c2 [14],\dec_ch2/c2 [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b15|dec_ch2/reg24_b16  (
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n82 [15],\dec_ch2/n82 [16]}),
    .q({\dec_ch2/c2 [15],\dec_ch2/c2 [16]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b17  (
    .b({open_n17218,\dec_ch2/c2p [29]}),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n17221,\dec_ch1/k3_lutinv }),
    .mi({open_n17232,\dec_ch2/n82 [17]}),
    .f({open_n17234,\dec_ch2/n85 [29]}),
    .q({open_n17238,\dec_ch2/c2 [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b18|dec_ch2/reg25_b7  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d(\dec_ch2/c1p [11:10]),
    .mi({\dec_ch2/n82 [18],\dec_ch2/c1 [7]}),
    .f(\dec_ch2/n81 [11:10]),
    .q({\dec_ch2/c2 [18],\dec_ch2/c1p [7]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b21  (
    .c({open_n17265,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n17266,\dec_ch2/c1p [40]}),
    .mi({open_n17270,\dec_ch2/n82 [21]}),
    .f({open_n17283,\dec_ch2/n81 [40]}),
    .q({open_n17287,\dec_ch2/c2 [21]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b23|dec_ch2/reg24_b27  (
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n82 [23],\dec_ch2/n82 [27]}),
    .q({\dec_ch2/c2 [23],\dec_ch2/c2 [27]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b24|dec_ch2/reg24_b28  (
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n82 [24],\dec_ch2/n82 [28]}),
    .q({\dec_ch2/c2 [24],\dec_ch2/c2 [28]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b25  (
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n17354,\dec_ch2/n82 [25]}),
    .q({open_n17361,\dec_ch2/c2 [25]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b26  (
    .c({open_n17366,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({open_n17367,\dec_ch2/c1p [19]}),
    .mi({open_n17378,\dec_ch2/n82 [26]}),
    .f({open_n17380,\dec_ch2/n81 [19]}),
    .q({open_n17384,\dec_ch2/c2 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b29|dec_ch2/reg25_b25  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [27],\dec_ch2/c1p [31]}),
    .mi({\dec_ch2/n82 [29],\dec_ch2/c1 [25]}),
    .f({\dec_ch2/n81 [27],\dec_ch2/n81 [31]}),
    .q({\dec_ch2/c2 [29],\dec_ch2/c1p [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b30|dec_ch2/reg25_b19  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [23],\dec_ch2/c1p [24]}),
    .mi({\dec_ch2/n82 [30],\dec_ch2/c1 [19]}),
    .f({\dec_ch2/n81 [23],\dec_ch2/n81 [24]}),
    .q({\dec_ch2/c2 [30],\dec_ch2/c1p [19]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b33|dec_ch2/reg24_b31  (
    .b({\dec_ch2/c3 [8],open_n17427}),
    .c({dec_shift[3],\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [0],\dec_ch2/c1p [25]}),
    .mi({\dec_ch2/n82 [33],\dec_ch2/n82 [31]}),
    .f({_al_u893_o,\dec_ch2/n81 [25]}),
    .q({\dec_ch2/c2 [33],\dec_ch2/c2 [31]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b35  (
    .a({open_n17442,\dec_ch2/n123_lutinv }),
    .b({open_n17443,\dec_ch2/c3 [12]}),
    .c({open_n17444,\dec_ch2/c3 [20]}),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n17445,dec_shift[3]}),
    .e({open_n17446,dec_shift[4]}),
    .mi({open_n17448,\dec_ch2/n82 [35]}),
    .f({open_n17461,\dec_ch2/n14_lutinv }),
    .q({open_n17465,\dec_ch2/c2 [35]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg24_b3|dec_ch2/reg24_b6  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [35],\dec_ch2/c1p [33]}),
    .mi({\dec_ch2/n82 [3],\dec_ch2/n82 [6]}),
    .f({\dec_ch2/n81 [35],\dec_ch2/n81 [33]}),
    .q({\dec_ch2/c2 [3],\dec_ch2/c2 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg24_b4|dec_ch2/reg24_b5  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [38],\dec_ch2/c1p [28]}),
    .mi({\dec_ch2/n82 [4],\dec_ch2/n82 [5]}),
    .f({\dec_ch2/n81 [38],\dec_ch2/n81 [28]}),
    .q({\dec_ch2/c2 [4],\dec_ch2/c2 [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b0|dec_ch2/reg25_b2  (
    .a({open_n17506,\dec_ch2/c1p [6]}),
    .c({\dec_ch2/c1p [4],open_n17509}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .mi({\dec_ch2/c1 [0],\dec_ch2/c1 [2]}),
    .f({\dec_ch2/n81 [4],\dec_ch2/n81 [6]}),
    .q({\dec_ch2/c1p [0],\dec_ch2/c1p [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b10|dec_ch2/reg25_b11  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [13],\dec_ch2/c1p [17]}),
    .mi({\dec_ch2/c1 [10],\dec_ch2/c1 [11]}),
    .f({\dec_ch2/n81 [13],\dec_ch2/n81 [17]}),
    .q({\dec_ch2/c1p [10],\dec_ch2/c1p [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b13|dec_ch2/reg25_b17  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [20],\dec_ch2/c1p [21]}),
    .mi({\dec_ch2/c1 [13],\dec_ch2/c1 [17]}),
    .f({\dec_ch2/n81 [20],\dec_ch2/n81 [21]}),
    .q({\dec_ch2/c1p [13],\dec_ch2/c1p [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b14|dec_ch2/reg25_b18  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [22],\dec_ch2/c1p [26]}),
    .mi({\dec_ch2/c1 [14],\dec_ch2/c1 [18]}),
    .f({\dec_ch2/n81 [22],\dec_ch2/n81 [26]}),
    .q({\dec_ch2/c1p [14],\dec_ch2/c1p [18]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b16|dec_ch2/reg25_b22  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [29],\dec_ch2/c1p [30]}),
    .mi({\dec_ch2/c1 [16],\dec_ch2/c1 [22]}),
    .f({\dec_ch2/n81 [29],\dec_ch2/n81 [30]}),
    .q({\dec_ch2/c1p [16],\dec_ch2/c1p [22]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b1|dec_ch2/reg25_b12  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [5],\dec_ch2/c1p [16]}),
    .mi({\dec_ch2/c1 [1],\dec_ch2/c1 [12]}),
    .f({\dec_ch2/n81 [5],\dec_ch2/n81 [16]}),
    .q({\dec_ch2/c1p [1],\dec_ch2/c1p [12]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b27|dec_ch2/reg25_b31  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [32],\dec_ch2/c1p [34]}),
    .mi({\dec_ch2/c1 [27],\dec_ch2/c1 [31]}),
    .f({\dec_ch2/n81 [32],\dec_ch2/n81 [34]}),
    .q({\dec_ch2/c1p [27],\dec_ch2/c1p [31]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b29|dec_ch2/reg25_b28  (
    .a({o_adc1A_d[6],open_n17648}),
    .b({o_adc1B_d[6],open_n17649}),
    .c({_al_u2096_o,peak_en}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({mcu_command[1],\dec_ch2/pk4 [2]}),
    .mi(\dec_ch2/c1 [29:28]),
    .f({_al_u2097_o,_al_u1829_o}),
    .q(\dec_ch2/c1p [29:28]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b33|dec_ch2/reg25_b34  (
    .c({peak_en,peak_en}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/pk4 [3],\dec_ch2/pk4 [7]}),
    .mi({\dec_ch2/c1 [33],\dec_ch2/c1 [34]}),
    .f({_al_u1825_o,_al_u1806_o}),
    .q({\dec_ch2/c1p [33],\dec_ch2/c1p [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b35|dec_ch2/reg25_b36  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [36],\dec_ch2/c1p [37]}),
    .mi({\dec_ch2/c1 [35],\dec_ch2/c1 [36]}),
    .f({\dec_ch2/n81 [36],\dec_ch2/n81 [37]}),
    .q({\dec_ch2/c1p [35],\dec_ch2/c1p [36]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b37|dec_ch2/reg25_b38  (
    .a({open_n17708,\dec_ch2/sh [2]}),
    .b({\dec_ch2/sh [4],open_n17709}),
    .c({dec_shift[0],dec_shift[0]}),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/sh [3],\dec_ch2/sh [3]}),
    .mi({\dec_ch2/c1 [37],\dec_ch2/c1 [38]}),
    .f({\dec_ch2/n244_lutinv ,\dec_ch2/n245_lutinv }),
    .q({\dec_ch2/c1p [37],\dec_ch2/c1p [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b43|dec_ch2/reg25_b39  (
    .a({open_n17724,\dec_ch2/c1p [39]}),
    .b({\dec_ch2/c3 [9],open_n17725}),
    .c({dec_shift[3],open_n17726}),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [1],\dec_order[1]_hfnopt2_3 }),
    .mi({\dec_ch2/c1 [43],\dec_ch2/c1 [39]}),
    .f({_al_u891_o,\dec_ch2/n81 [39]}),
    .q({\dec_ch2/c1p [43],\dec_ch2/c1p [39]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg25_b46|dec_ch2/reg25_b42  (
    .c({mcu_command[1],mcu_command[1]}),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({mcu_command[0],mcu_command[0]}),
    .mi({\dec_ch2/c1 [46],\dec_ch2/c1 [42]}),
    .f({_al_u1436_o,\lt21/o_1_lutinv }),
    .q({\dec_ch2/c1p [46],\dec_ch2/c1p [42]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg25_b8|dec_ch2/reg25_b9  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [7],\dec_ch2/c1p [8]}),
    .mi({\dec_ch2/c1 [8],\dec_ch2/c1 [9]}),
    .f({\dec_ch2/n81 [7],\dec_ch2/n81 [8]}),
    .q({\dec_ch2/c1p [8],\dec_ch2/c1p [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b0|dec_ch2/reg26_b2  (
    .a({o_adc2A_d[2],\dec_ch2/c3 [2]}),
    .b({o_adc2B_d[2],\dec_ch2/c3 [10]}),
    .c({mcu_command[0],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({mcu_command[1],open_n17781}),
    .mi({\dec_ch2/n86 [0],\dec_ch2/n86 [2]}),
    .f({_al_u2007_o,_al_u889_o}),
    .q({\dec_ch2/c3 [0],\dec_ch2/c3 [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b10|dec_ch2/reg26_b12  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [43],\dec_ch2/c1p [44]}),
    .mi({\dec_ch2/n86 [10],\dec_ch2/n86 [12]}),
    .f({\dec_ch2/n81 [43],\dec_ch2/n81 [44]}),
    .q({\dec_ch2/c3 [10],\dec_ch2/c3 [12]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b11|dec_ch2/reg26_b15  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [45],\dec_ch2/c1p [46]}),
    .mi({\dec_ch2/n86 [11],\dec_ch2/n86 [15]}),
    .f({\dec_ch2/n81 [45],\dec_ch2/n81 [46]}),
    .q({\dec_ch2/c3 [11],\dec_ch2/c3 [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b18|dec_ch2/reg26_b26  (
    .b({\dec_ch2/c3 [27],\dec_ch2/c3 [24]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [19],\dec_ch2/c3 [16]}),
    .mi({\dec_ch2/n86 [18],\dec_ch2/n86 [26]}),
    .f({\dec_ch2/n141_lutinv ,\dec_ch2/n144_lutinv }),
    .q({\dec_ch2/c3 [18],\dec_ch2/c3 [26]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b1|dec_ch2/reg26_b3  (
    .b({\dec_ch2/c3 [11],\dec_ch2/c3 [4]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [3],\dec_ch2/c3 [12]}),
    .mi({\dec_ch2/n86 [1],\dec_ch2/n86 [3]}),
    .f({_al_u887_o,_al_u885_o}),
    .q({\dec_ch2/c3 [1],\dec_ch2/c3 [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b20|dec_ch2/reg26_b8  (
    .b(\dec_ch2/c3 [6:5]),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d(\dec_ch2/c3 [14:13]),
    .mi({\dec_ch2/n86 [20],\dec_ch2/n86 [8]}),
    .f({_al_u881_o,_al_u883_o}),
    .q({\dec_ch2/c3 [20],\dec_ch2/c3 [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b27|dec_ch2/reg26_b28  (
    .b({\dec_ch2/c3 [26],\dec_ch2/c3 [35]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [18],\dec_ch2/c3 [27]}),
    .mi({\dec_ch2/n86 [27],\dec_ch2/n86 [28]}),
    .f({\dec_ch2/n142_lutinv ,\dec_ch2/n124_lutinv }),
    .q({\dec_ch2/c3 [27],\dec_ch2/c3 [28]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b34|dec_ch2/reg26_b25  (
    .a({open_n17904,\dec_ch2/n125_lutinv }),
    .b({\dec_ch2/c3 [43],\dec_ch2/c3 [10]}),
    .c({dec_shift[3],\dec_ch2/c3 [18]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [35],dec_shift[3]}),
    .e({open_n17905,dec_shift[4]}),
    .mi({\dec_ch2/n86 [34],\dec_ch2/n86 [25]}),
    .f({\dec_ch2/n116_lutinv ,\dec_ch2/n16_lutinv }),
    .q({\dec_ch2/c3 [34],\dec_ch2/c3 [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b35|dec_ch2/reg27_b33  (
    .b({\dec_ch2/c3 [28],\dec_ch2/c3 [34]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [20],\dec_ch2/c3 [26]}),
    .mi({\dec_ch2/n86 [35],\dec_ch2/c2 [33]}),
    .f({\dec_ch2/n140_lutinv ,\dec_ch2/n125_lutinv }),
    .q({\dec_ch2/c3 [35],\dec_ch2/c2p [33]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b39|dec_ch2/reg26_b43  (
    .b({\dec_ch2/c3 [37],\dec_ch2/c3 [38]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [29],\dec_ch2/c3 [30]}),
    .mi({\dec_ch2/n86 [39],\dec_ch2/n86 [43]}),
    .f({\dec_ch2/n122_lutinv ,\dec_ch2/n121_lutinv }),
    .q({\dec_ch2/c3 [39],\dec_ch2/c3 [43]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b41|dec_ch2/reg26_b36  (
    .a({open_n17958,\dec_ch2/n122_lutinv }),
    .b({\dec_ch2/c3 [7],\dec_ch2/c3 [13]}),
    .c({dec_shift[3],\dec_ch2/c3 [21]}),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [15],dec_shift[3]}),
    .e({open_n17959,dec_shift[4]}),
    .mi({\dec_ch2/n86 [41],\dec_ch2/n86 [36]}),
    .f({_al_u879_o,\dec_ch2/n13_lutinv }),
    .q({\dec_ch2/c3 [41],\dec_ch2/c3 [36]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg26_b42|dec_ch2/reg26_b44  (
    .b({\dec_ch2/c3 [30],\dec_ch2/c3 [33]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [22],\dec_ch2/c3 [25]}),
    .mi({\dec_ch2/n86 [42],\dec_ch2/n86 [44]}),
    .f({\dec_ch2/n138_lutinv ,\dec_ch2/n126_lutinv }),
    .q({\dec_ch2/c3 [42],\dec_ch2/c3 [44]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b45|dec_ch2/reg26_b46  (
    .b(\dec_ch2/c3 [32:31]),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d(\dec_ch2/c3 [24:23]),
    .mi({\dec_ch2/n86 [45],\dec_ch2/n86 [46]}),
    .f({\dec_ch2/n136_lutinv ,\dec_ch2/n137_lutinv }),
    .q({\dec_ch2/c3 [45],\dec_ch2/c3 [46]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b47|dec_ch2/reg27_b47  (
    .b({\dec_ch2/c3 [39],\dec_ch2/c3 [39]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [31],\dec_ch2/c3 [47]}),
    .mi({\dec_ch2/n86 [47],\dec_ch2/c2 [47]}),
    .f({\dec_ch2/n120_lutinv ,\dec_ch2/n112_lutinv }),
    .q({\dec_ch2/c3 [47],\dec_ch2/c2p [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b4|dec_ch2/reg26_b17  (
    .a({\dec_ch2/n124_lutinv ,\dec_ch2/n136_lutinv }),
    .b({\dec_ch2/c3 [11],\dec_ch2/c3 [16]}),
    .c({\dec_ch2/c3 [19],\dec_ch2/c3 [8]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[3],dec_shift[3]}),
    .e({dec_shift[4],dec_shift[4]}),
    .mi({\dec_ch2/n86 [4],\dec_ch2/n86 [17]}),
    .f({\dec_ch2/n15_lutinv ,\dec_ch2/n95_lutinv }),
    .q({\dec_ch2/c3 [4],\dec_ch2/c3 [17]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b5|dec_ch2/reg26_b6  (
    .c({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c1p [41],\dec_ch2/c1p [42]}),
    .mi({\dec_ch2/n86 [5],\dec_ch2/n86 [6]}),
    .f({\dec_ch2/n81 [41],\dec_ch2/n81 [42]}),
    .q({\dec_ch2/c3 [5],\dec_ch2/c3 [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg26_b7|dec_ch2/reg27_b35  (
    .a({open_n18070,\dec_ch2/n121_lutinv }),
    .b({\dec_ch2/c3 [36],\dec_ch2/c3 [14]}),
    .c({dec_shift[3],\dec_ch2/c3 [22]}),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c3 [28],dec_shift[3]}),
    .e({open_n18071,dec_shift[4]}),
    .mi({\dec_ch2/n86 [7],\dec_ch2/c2 [35]}),
    .f({\dec_ch2/n123_lutinv ,\dec_ch2/n12_lutinv }),
    .q({\dec_ch2/c3 [7],\dec_ch2/c2p [35]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg27_b0|dec_ch2/reg27_b2  (
    .a({\dec_ch2/c2p [0],\dec_ch2/c2p [2]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/c2 [0],\dec_ch2/c2 [2]}),
    .f({\dec_ch2/n85 [0],\dec_ch2/n85 [2]}),
    .q({\dec_ch2/c2p [0],\dec_ch2/c2p [2]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b1  (
    .a({open_n18106,\dec_ch2/c2p [1]}),
    .c({open_n18109,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n18115,\dec_ch2/c2 [1]}),
    .f({open_n18128,\dec_ch2/n85 [1]}),
    .q({open_n18132,\dec_ch2/c2p [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b11|dec_ch2/reg27_b13  (
    .c({\dec_ch2/c2p [10],\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch2/c2p [11]}),
    .mi({\dec_ch2/c2 [11],\dec_ch2/c2 [13]}),
    .f({\dec_ch2/n85 [10],\dec_ch2/n85 [11]}),
    .q({\dec_ch2/c2p [11],\dec_ch2/c2p [13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg27_b12|dec_ch2/reg27_b14  (
    .a({\dec_ch2/c2p [12],\dec_ch2/c2p [14]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/c2 [12],\dec_ch2/c2 [14]}),
    .f({\dec_ch2/n85 [12],\dec_ch2/n85 [14]}),
    .q({\dec_ch2/c2p [12],\dec_ch2/c2p [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg27_b15|dec_ch2/reg27_b16  (
    .a({\dec_ch2/c2p [15],\dec_ch2/c2p [16]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/c2 [15],\dec_ch2/c2 [16]}),
    .f({\dec_ch2/n85 [15],\dec_ch2/n85 [16]}),
    .q({\dec_ch2/c2p [15],\dec_ch2/c2p [16]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg27_b17|dec_ch2/reg27_b8  (
    .a({\dec_ch2/c2p [17],\dec_ch2/c2p [8]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/c2 [17],\dec_ch2/c2 [8]}),
    .f({\dec_ch2/n85 [17],\dec_ch2/n85 [8]}),
    .q({\dec_ch2/c2p [17],\dec_ch2/c2p [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg27_b18|dec_ch2/reg27_b21  (
    .a({\dec_ch2/c2p [18],\dec_ch2/c2p [21]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [18],\dec_ch2/c2 [21]}),
    .f({\dec_ch2/n85 [18],\dec_ch2/n85 [21]}),
    .q({\dec_ch2/c2p [18],\dec_ch2/c2p [21]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b20|dec_ch2/reg27_b22  (
    .a({\dec_ch2/c2p [20],\dec_ch2/c2p [22]}),
    .c({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/c2 [20],\dec_ch2/c2 [22]}),
    .f({\dec_ch2/n85 [20],\dec_ch2/n85 [22]}),
    .q({\dec_ch2/c2p [20],\dec_ch2/c2p [22]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b23|dec_ch2/reg27_b34  (
    .c({\dec_ch2/c2p [32],\dec_ch2/c2p [36]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [23],\dec_ch2/c2 [34]}),
    .f({\dec_ch2/n85 [32],\dec_ch2/n85 [36]}),
    .q({\dec_ch2/c2p [23],\dec_ch2/c2p [34]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b24|dec_ch2/reg27_b30  (
    .c({\dec_ch1/k3_lutinv ,\dec_ch2/c2p [27]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c2p [30],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [24],\dec_ch2/c2 [30]}),
    .f({\dec_ch2/n85 [30],\dec_ch2/n85 [27]}),
    .q({\dec_ch2/c2p [24],\dec_ch2/c2p [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b25|dec_ch2/reg27_b29  (
    .c({\dec_ch2/c2p [23],\dec_ch2/c2p [26]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [25],\dec_ch2/c2 [29]}),
    .f({\dec_ch2/n85 [23],\dec_ch2/n85 [26]}),
    .q({\dec_ch2/c2p [25],\dec_ch2/c2p [29]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b26|dec_ch2/reg27_b28  (
    .c({\dec_ch2/c2p [24],\dec_ch2/c2p [25]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [26],\dec_ch2/c2 [28]}),
    .f({\dec_ch2/n85 [24],\dec_ch2/n85 [25]}),
    .q({\dec_ch2/c2p [26],\dec_ch2/c2p [28]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b31|dec_ch2/reg27_b37  (
    .c({\dec_ch1/k3_lutinv ,\dec_ch2/c2p [38]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/c2p [37],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [31],\dec_ch2/c2 [37]}),
    .f({\dec_ch2/n85 [37],\dec_ch2/n85 [38]}),
    .q({\dec_ch2/c2p [31],\dec_ch2/c2p [37]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b32|dec_ch2/reg27_b38  (
    .c({\dec_ch2/c2p [33],\dec_ch2/c2p [35]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [32],\dec_ch2/c2 [38]}),
    .f({\dec_ch2/n85 [33],\dec_ch2/n85 [35]}),
    .q({\dec_ch2/c2p [32],\dec_ch2/c2p [38]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg27_b3|dec_ch2/reg27_b6  (
    .a({\dec_ch2/c2p [3],\dec_ch2/c2p [6]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [3],\dec_ch2/c2 [6]}),
    .f({\dec_ch2/n85 [3],\dec_ch2/n85 [6]}),
    .q({\dec_ch2/c2p [3],\dec_ch2/c2p [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b4|dec_ch2/reg27_b5  (
    .a({\dec_ch2/c2p [4],\dec_ch2/c2p [5]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [4],\dec_ch2/c2 [5]}),
    .f({\dec_ch2/n85 [4],\dec_ch2/n85 [5]}),
    .q({\dec_ch2/c2p [4],\dec_ch2/c2p [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg27_b7|dec_ch2/reg27_b9  (
    .a({\dec_ch2/c2p [7],\dec_ch2/c2p [9]}),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/c2 [7],\dec_ch2/c2 [9]}),
    .f({\dec_ch2/n85 [7],\dec_ch2/n85 [9]}),
    .q({\dec_ch2/c2p [7],\dec_ch2/c2p [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b0|dec_ch2/reg28_b3  (
    .a({\dec_ch2/n119_lutinv ,\dec_ch2/n116_lutinv }),
    .b({\dec_ch2/n144_lutinv ,\dec_ch2/n141_lutinv }),
    .c({_al_u893_o,_al_u887_o}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [0],\dec_ch2/sh [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b10|dec_ch2/reg28_b11  (
    .a({\dec_ch2/n16_lutinv ,\dec_ch2/n15_lutinv }),
    .b({\dec_ch2/c3 [42],\dec_ch2/c3 [43]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [10],\dec_ch2/sh [11]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b13|dec_ch2/reg28_b14  (
    .a({\dec_ch2/n13_lutinv ,\dec_ch2/n12_lutinv }),
    .b({\dec_ch2/c3 [45],\dec_ch2/c3 [46]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [13],\dec_ch2/sh [14]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg28_b17|dec_ch2/reg28_b20  (
    .a({\dec_ch2/n118_lutinv ,\dec_ch2/n115_lutinv }),
    .b({\dec_ch2/n143_lutinv ,\dec_ch2/n140_lutinv }),
    .c({dec_shift[4],dec_shift[4]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [17],\dec_ch2/sh [20]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b18|dec_ch2/reg28_b19  (
    .a({\dec_ch2/n117_lutinv ,\dec_ch2/n116_lutinv }),
    .b({\dec_ch2/n142_lutinv ,\dec_ch2/n141_lutinv }),
    .c({dec_shift[4],dec_shift[4]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [18],\dec_ch2/sh [19]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg28_b21|dec_ch2/reg28_b22  (
    .a({\dec_ch2/n114_lutinv ,\dec_ch2/n113_lutinv }),
    .b({\dec_ch2/n139_lutinv ,\dec_ch2/n138_lutinv }),
    .c({dec_shift[4],dec_shift[4]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [21],\dec_ch2/sh [22]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b23|dec_ch2/reg28_b24  (
    .a({\dec_ch2/n112_lutinv ,\dec_ch2/n136_lutinv }),
    .b({\dec_ch2/n137_lutinv ,\dec_ch2/c3 [40]}),
    .c(dec_shift[4:3]),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d(dec_shift[5:4]),
    .e({open_n18561,dec_shift[5]}),
    .q({\dec_ch2/sh [23],\dec_ch2/sh [24]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b26|dec_ch2/reg28_b28  (
    .a({\dec_ch2/n125_lutinv ,\dec_ch2/n123_lutinv }),
    .b({\dec_ch2/c3 [42],\dec_ch2/c3 [44]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [26],\dec_ch2/sh [28]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b27  (
    .a({open_n18602,\dec_ch2/n124_lutinv }),
    .b({open_n18603,\dec_ch2/c3 [43]}),
    .c({open_n18604,dec_shift[3]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({open_n18605,dec_shift[4]}),
    .e({open_n18606,dec_shift[5]}),
    .q({open_n18627,\dec_ch2/sh [27]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b29|dec_ch2/reg28_b30  (
    .a({\dec_ch2/n122_lutinv ,\dec_ch2/n121_lutinv }),
    .b({\dec_ch2/c3 [45],\dec_ch2/c3 [46]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [29],\dec_ch2/sh [30]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg28_b37|dec_ch2/reg28_b47  (
    .b({open_n18650,\dec_ch2/c3 [47]}),
    .c({_al_u806_o,\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n114_lutinv ,_al_u806_o}),
    .q({\dec_ch2/sh [37],\dec_ch2/sh [47]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg28_b38|dec_ch2/reg28_b41  (
    .b({open_n18671,\dec_ch2/c3 [41]}),
    .c({_al_u806_o,\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n113_lutinv ,_al_u806_o}),
    .q({\dec_ch2/sh [38],\dec_ch2/sh [41]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b39|dec_ch2/reg28_b45  (
    .b({open_n18692,\dec_ch2/c3 [45]}),
    .c({_al_u806_o,\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n112_lutinv ,_al_u806_o}),
    .q({\dec_ch2/sh [39],\dec_ch2/sh [45]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b43|dec_ch2/reg28_b46  (
    .b({\dec_ch2/c3 [43],\dec_ch2/c3 [46]}),
    .c({\dec_shift[3]_hfnopt2_3 ,\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u806_o,_al_u806_o}),
    .q({\dec_ch2/sh [43],\dec_ch2/sh [46]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b44|dec_ch2/reg28_b25  (
    .a({open_n18739,\dec_ch2/n126_lutinv }),
    .b({\dec_ch2/c3 [44],\dec_ch2/c3 [41]}),
    .c({\dec_shift[3]_hfnopt2_3 ,\dec_shift[3]_hfnopt2_3 }),
    .ce(dec_sv[4]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u806_o,dec_shift[4]}),
    .e({open_n18740,dec_shift[5]}),
    .q({\dec_ch2/sh [44],\dec_ch2/sh [25]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b4|dec_ch2/reg28_b8  (
    .a({\dec_ch2/n115_lutinv ,\dec_ch2/n95_lutinv }),
    .b({\dec_ch2/n140_lutinv ,\dec_ch2/c3 [40]}),
    .c({_al_u885_o,dec_shift[3]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [4],\dec_ch2/sh [8]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b5|dec_ch2/reg28_b9  (
    .a({\dec_ch2/n114_lutinv ,\dec_ch2/n17_lutinv }),
    .b({\dec_ch2/n139_lutinv ,\dec_ch2/c3 [41]}),
    .c({_al_u883_o,dec_shift[3]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [5],\dec_ch2/sh [9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b6|dec_ch2/reg28_b12  (
    .a({\dec_ch2/n113_lutinv ,\dec_ch2/n14_lutinv }),
    .b({\dec_ch2/n138_lutinv ,\dec_ch2/c3 [44]}),
    .c({_al_u881_o,dec_shift[3]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [6],\dec_ch2/sh [12]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg28_b7|dec_ch2/reg28_b15  (
    .a({\dec_ch2/n112_lutinv ,\dec_ch2/n11_lutinv }),
    .b({\dec_ch2/n137_lutinv ,\dec_ch2/c3 [47]}),
    .c({_al_u879_o,dec_shift[3]}),
    .ce(\dec_sv[4]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[4],dec_shift[4]}),
    .e({dec_shift[5],dec_shift[5]}),
    .q({\dec_ch2/sh [7],\dec_ch2/sh [15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg29_b11|dec_ch2/reg29_b13  (
    .a({_al_u1768_o,_al_u1768_o}),
    .b({_al_u1776_o,_al_u1776_o}),
    .c({_al_u1784_o,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1845_o,_al_u1838_o}),
    .e({_al_u1846_o,_al_u1839_o}),
    .q({cic_out2[11],cic_out2[13]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg29_b12|dec_ch2/reg29_b15  (
    .a({_al_u1768_o,_al_u1768_o}),
    .b({_al_u1776_o,_al_u1776_o}),
    .c({_al_u1784_o,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1841_o,_al_u1831_o}),
    .e({_al_u1842_o,_al_u1832_o}),
    .q({cic_out2[12],cic_out2[15]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg29_b14|dec_ch2/reg29_b9  (
    .a({_al_u1768_o,_al_u1768_o}),
    .b({_al_u1776_o,_al_u1776_o}),
    .c({_al_u1784_o,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1835_o,_al_u1791_o}),
    .e({_al_u1836_o,_al_u1792_o}),
    .q({cic_out2[14],cic_out2[9]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg29_b1|dec_ch2/reg29_b2  (
    .a({_al_u1768_o,_al_u1768_o}),
    .b({_al_u1776_o,_al_u1776_o}),
    .c({_al_u1784_o,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1853_o,\dec_ch2/fine [2]}),
    .e({_al_u1854_o,_al_u1829_o}),
    .q({cic_out2[1],cic_out2[2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg29_b4|dec_ch2/reg29_b5  (
    .a({_al_u1768_o,_al_u1768_o}),
    .b({_al_u1776_o,_al_u1776_o}),
    .c({_al_u1784_o,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1820_o,_al_u1815_o}),
    .e({_al_u1821_o,_al_u1816_o}),
    .q({cic_out2[4],cic_out2[5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg29_b6|dec_ch2/reg29_b7  (
    .a({_al_u1768_o,_al_u1768_o}),
    .b({_al_u1776_o,_al_u1776_o}),
    .c({_al_u1784_o,_al_u1784_o}),
    .ce(dec_sv[5]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1810_o,_al_u1805_o}),
    .e({_al_u1811_o,_al_u1806_o}),
    .q({cic_out2[6],cic_out2[7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg2_b2|dec_ch2/reg2_b7  (
    .a({\dec_ch1/n229_lutinv ,open_n18961}),
    .b({dec_shift[1],\dec_ch1/sh [19]}),
    .c({open_n18962,dec_shift[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/n227_lutinv ,\dec_ch1/sh [18]}),
    .mi({\dec_ch2/pb [2],\dec_ch2/pb [7]}),
    .f({_al_u1869_o,\dec_ch1/n229_lutinv }),
    .q({pair_e2[2],pair_e2[7]}));  // zaklad.v(277)
  // zaklad.v(1596)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg2_b3|reg17_b4_hfnopt2_1  (
    .a({\dec_ch1/n227_lutinv ,open_n18982}),
    .b({\dec_ch1/n226_lutinv ,\dec_ch1/sh [21]}),
    .c({_al_u1878_o,dec_shift[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[1],\dec_ch1/sh [20]}),
    .mi({\dec_ch2/pb [3],\dec_sv[3]_hfnopt2_4 }),
    .f({_al_u1879_o,\dec_ch1/n227_lutinv }),
    .q({pair_e2[3],\dec_sv[4]_hfnopt2_1 }));  // zaklad.v(1596)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg2_b5|dec_ch2/reg2_b4  (
    .b({open_n19000,\dec_ch1/sh [22]}),
    .c({\dec_ch1/sh [35],dec_shift[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [34],\dec_ch1/sh [21]}),
    .mi(\dec_ch2/pb [5:4]),
    .f({_al_u1878_o,\dec_ch1/n226_lutinv }),
    .q(pair_e2[5:4]));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg30_b5  (
    .b({open_n19018,\dec_ch1/c3 [45]}),
    .c({open_n19019,\dec_shift[3]_hfnopt2_1 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n19021,\dec_ch1/c3 [37]}),
    .mi({open_n19025,adc2A_w[5]}),
    .f({open_n19038,\dec_ch1/n114_lutinv }),
    .q({open_n19042,\dec_ch2/pa [5]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg3_b0|dec_ch2/reg3_b2  (
    .c(\dec_ch2/pe [5:4]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({pair_e2[0],pair_e2[2]}),
    .f(\dec_ch2/t_pe [5:4]),
    .q({\dec_ch2/pe [0],\dec_ch2/pe [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg4_b1|dec_ch2/reg4_b2  (
    .a({\dec_ch2/n19 [0],\dec_ch2/n19 [3]}),
    .b({pair_e2[0],pair_e2[3]}),
    .c({pair_e2[1],pair_e2[4]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[0],dec_order[0]}),
    .e({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .mi({pair_l2[1],pair_l2[2]}),
    .f({\dec_ch2/t_xe [1],\dec_ch2/t_xe [4]}),
    .q({\dec_ch2/pl [1],\dec_ch2/pl [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg4_b3|dec_ch2/reg4_b6  (
    .a({\dec_ch2/n19 [6],pair_e2[4]}),
    .b({pair_e2[6],\dec_ch2/n19 [4]}),
    .c({pair_e2[7],pair_e2[5]}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_order[0],dec_order[0]}),
    .e({\dec_order[1]_hfnopt2_3 ,\dec_order[1]_hfnopt2_3 }),
    .mi({pair_l2[3],pair_l2[6]}),
    .f({\dec_ch2/t_xe [7],\dec_ch2/t_xe [5]}),
    .q({\dec_ch2/pl [3],\dec_ch2/pl [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg4_b4|dec_ch2/reg4_b0  (
    .a({\dec_ch2/n19 [7],pair_e2[2]}),
    .b({pair_e2[7],pair_e2[1]}),
    .c({dec_order[0],\dec_ch2/n19 [1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_3 ,dec_order[0]}),
    .e({open_n19097,\dec_order[1]_hfnopt2_3 }),
    .mi({pair_l2[4],pair_l2[0]}),
    .f({\dec_ch2/t_xe [8],\dec_ch2/t_xe [2]}),
    .q({\dec_ch2/pl [4],\dec_ch2/pl [0]}));  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg5_b0|u6/ucin  (
    .a({\dec_ch2/t_xe [0],1'b0}),
    .b({n3[0],open_n19114}),
    .clk(sample_write_clock_gclk_net),
    .fco(\u6/c1 ),
    .q({\dec_ch2/f [0],open_n19137}));
  AL_PHY_MSLICE \dec_ch2/reg5_b10|dec_ch2/reg5_b9  (
    .a({1'b0,\dec_ch2/t_pl [9]}),
    .b(n3[10:9]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u6/c9 ),
    .q(\dec_ch2/f [10:9]));
  AL_PHY_MSLICE \dec_ch2/reg5_b2|dec_ch2/reg5_b1  (
    .a(n2[2:1]),
    .b(n3[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u6/c1 ),
    .fco(\u6/c3 ),
    .q(\dec_ch2/f [2:1]));
  AL_PHY_MSLICE \dec_ch2/reg5_b4|dec_ch2/reg5_b3  (
    .a(n2[4:3]),
    .b(n3[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u6/c3 ),
    .fco(\u6/c5 ),
    .q(\dec_ch2/f [4:3]));
  AL_PHY_MSLICE \dec_ch2/reg5_b6|dec_ch2/reg5_b5  (
    .a(n2[6:5]),
    .b(n3[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u6/c5 ),
    .fco(\u6/c7 ),
    .q(\dec_ch2/f [6:5]));
  AL_PHY_MSLICE \dec_ch2/reg5_b8|dec_ch2/reg5_b7  (
    .a(n2[8:7]),
    .b(n3[8:7]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u6/c7 ),
    .fco(\u6/c9 ),
    .q(\dec_ch2/f [8:7]));
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg6_b0|dec_ch2/reg3_b1  (
    .b({pair_l2[0],open_n19246}),
    .c({pair_e2[0],\dec_ch2/pe [6]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n53 ,\dec_ch1/k3_lutinv }),
    .mi({open_n19251,pair_e2[1]}),
    .f({open_n19264,\dec_ch2/t_pe [6]}),
    .q({\dec_ch2/pmx [0],\dec_ch2/pe [1]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg6_b1|dec_ch2/reg6_b3  (
    .b({pair_l2[1],pair_l2[3]}),
    .c({pair_e2[1],pair_e2[3]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n53 ,\dec_ch2/n53 }),
    .q({\dec_ch2/pmx [1],\dec_ch2/pmx [3]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg6_b2|dec_ch2/reg6_b4  (
    .b({pair_l2[2],pair_l2[4]}),
    .c({pair_e2[2],pair_e2[4]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n53 ,\dec_ch2/n53 }),
    .q({\dec_ch2/pmx [2],\dec_ch2/pmx [4]}));  // zaklad.v(277)
  // zaklad.v(1596)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg6_b5|reg17_b1_hfnopt2_3  (
    .b({pair_l2[5],open_n19320}),
    .c({pair_e2[5],\dec_order[1]_hfnopt2_3 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n53 ,\dec_ch2/c1p [12]}),
    .mi({open_n19332,\dec_sv[0]_hfnopt2_3 }),
    .f({open_n19334,\dec_ch2/n81 [12]}),
    .q({\dec_ch2/pmx [5],\dec_sv[1]_hfnopt2_3 }));  // zaklad.v(1596)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg6_b6|dec_ch2/reg6_b7  (
    .b({pair_l2[6],pair_l2[7]}),
    .c({pair_e2[6],pair_e2[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n53 ,\dec_ch2/n53 }),
    .q({\dec_ch2/pmx [6],\dec_ch2/pmx [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg7_b0|dec_ch2/reg3_b6  (
    .b({pair_l2[0],open_n19361}),
    .c({pair_e2[0],\dec_ch2/pe [7]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n55 ,\dec_ch1/k3_lutinv }),
    .mi({open_n19373,pair_e2[6]}),
    .f({open_n19375,\dec_ch2/t_pe [7]}),
    .q({\dec_ch2/pmn [0],\dec_ch2/pe [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg7_b1|dec_ch2/reg7_b2  (
    .b({pair_l2[1],pair_l2[2]}),
    .c({pair_e2[1],pair_e2[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n55 ,\dec_ch2/n55 }),
    .q({\dec_ch2/pmn [1],\dec_ch2/pmn [2]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg7_b3|dec_ch2/reg7_b4  (
    .b({pair_l2[3],pair_l2[4]}),
    .c({pair_e2[3],pair_e2[4]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n55 ,\dec_ch2/n55 }),
    .q({\dec_ch2/pmn [3],\dec_ch2/pmn [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg7_b5|dec_ch2/reg7_b6  (
    .b({pair_l2[5],pair_l2[6]}),
    .c({pair_e2[5],pair_e2[6]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n55 ,\dec_ch2/n55 }),
    .q({\dec_ch2/pmn [5],\dec_ch2/pmn [6]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg7_b7|dec_ch2/reg3_b7  (
    .a({open_n19450,\dec_ch1/n244_lutinv }),
    .b({pair_l2[7],\dec_ch1/sh [1]}),
    .c({pair_e2[7],\dec_ch1/sh [2]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n55 ,dec_shift[0]}),
    .e({open_n19452,dec_shift[1]}),
    .mi({open_n19454,pair_e2[7]}),
    .f({open_n19467,_al_u1939_o}),
    .q({\dec_ch2/pmn [7],\dec_ch2/pe [7]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg8_b0|dec_ch2/reg8_b3  (
    .a({open_n19471,\dec_ch1/n125_lutinv }),
    .b({open_n19472,\dec_ch1/c3 [10]}),
    .c({\dec_ch1/c2p [47],\dec_ch1/c3 [18]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_shift[3]_hfnopt2_0 }),
    .e({open_n19474,dec_shift[4]}),
    .mi({\dec_ch2/pmx [0],\dec_ch2/pmx [3]}),
    .f({\dec_ch1/n85 [47],\dec_ch1/n16_lutinv }),
    .q({\dec_ch2/pdx [0],\dec_ch2/pdx [3]}));  // zaklad.v(277)
  // zaklad.v(1596)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg8_b7|reg17_b3_hfnopt2_0  (
    .b({\dec_ch1/c3 [3],open_n19493}),
    .c({\dec_shift[3]_hfnopt2_0 ,\dec_ch1/c2p [39]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/c3 [11],\dec_ch1/k3_lutinv }),
    .mi({\dec_ch2/pmx [7],\dec_sv[2]_hfnopt2_2 }),
    .f({_al_u975_o,\dec_ch1/n85 [39]}),
    .q({\dec_ch2/pdx [7],\dec_sv[3]_hfnopt2_0 }));  // zaklad.v(1596)
  AL_PHY_MSLICE \dec_ch2/reg9_b0  (
    .b({open_n19515,\dec_ch1/c3 [27]}),
    .c({open_n19516,\dec_shift[3]_hfnopt2_0 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n19518,\dec_ch1/c3 [19]}),
    .mi({open_n19529,\dec_ch2/pmn [0]}),
    .f({open_n19531,\dec_ch1/n141_lutinv }),
    .q({open_n19535,\dec_ch2/pdn [0]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg9_b2|dec_ch2/reg9_b1  (
    .a({open_n19536,o_adc2A_d[6]}),
    .b({open_n19537,o_adc2B_d[6]}),
    .c({dec_shift[2],mcu_command[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1870_o,mcu_command[1]}),
    .mi(\dec_ch2/pmn [2:1]),
    .f({_al_u1918_o,_al_u2096_o}),
    .q(\dec_ch2/pdn [2:1]));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_MSLICE \dec_ch2/reg9_b3|dec_ch2/reg9_b4  (
    .a({_al_u1870_o,_al_u1870_o}),
    .b({_al_u1869_o,_al_u1900_o}),
    .c({_al_u1928_o,_al_u1925_o}),
    .clk(sample_write_clock_gclk_net),
    .d({dec_shift[2],dec_shift[2]}),
    .mi({\dec_ch2/pmn [3],\dec_ch2/pmn [4]}),
    .f({_al_u1929_o,_al_u1935_o}),
    .q({\dec_ch2/pdn [3],\dec_ch2/pdn [4]}));  // zaklad.v(277)
  // zaklad.v(277)
  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/reg9_b5|dec_ch2/reg9_b6  (
    .b({\dec_ch1/sh [12],\dec_ch1/sh [13]}),
    .c({dec_shift[0],dec_shift[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch1/sh [11],\dec_ch1/sh [12]}),
    .mi({\dec_ch2/pmn [5],\dec_ch2/pmn [6]}),
    .f({\dec_ch1/n236_lutinv ,\dec_ch1/n235_lutinv }),
    .q({\dec_ch2/pdn [5],\dec_ch2/pdn [6]}));  // zaklad.v(277)
  AL_PHY_LSLICE \dec_ch2/sub0/u11_al_u2358  (
    .a({\dec_ch2/d0 [13],\dec_ch2/d0 [11]}),
    .b({\dec_ch2/d0 [14],\dec_ch2/d0 [12]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [13],\dec_ch2/d0p [11]}),
    .e({\dec_ch2/d0p [14],\dec_ch2/d0p [12]}),
    .fci(\dec_ch2/sub0/c11 ),
    .mi({\dec_ch2/d0 [15],\dec_ch2/d0 [11]}),
    .f({\dec_ch2/n78 [13],\dec_ch2/n78 [11]}),
    .fco(\dec_ch2/sub0/c15 ),
    .fx({\dec_ch2/n78 [14],\dec_ch2/n78 [12]}),
    .q({\dec_ch2/d0p [15],\dec_ch2/d0p [11]}));
  AL_PHY_LSLICE \dec_ch2/sub0/u15_al_u2359  (
    .a({\dec_ch2/d0 [17],\dec_ch2/d0 [15]}),
    .b({\dec_ch2/d0 [18],\dec_ch2/d0 [16]}),
    .c(2'b11),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [17],\dec_ch2/d0p [15]}),
    .e({\dec_ch2/d0p [18],\dec_ch2/d0p [16]}),
    .fci(\dec_ch2/sub0/c15 ),
    .mi({n152,\dec_ch2/pa [0]}),
    .f({\dec_ch2/n78 [17],\dec_ch2/n78 [15]}),
    .fco(\dec_ch2/sub0/c19 ),
    .fx({\dec_ch2/n78 [18],\dec_ch2/n78 [16]}),
    .q({\dec_sv[0]_hfnopt2_4 ,pair_l2[0]}));
  AL_PHY_LSLICE \dec_ch2/sub0/u19_al_u2360  (
    .a({\dec_ch2/d0 [21],\dec_ch2/d0 [19]}),
    .b({\dec_ch2/d0 [22],\dec_ch2/d0 [20]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [21],\dec_ch2/d0p [19]}),
    .e({\dec_ch2/d0p [22],\dec_ch2/d0p [20]}),
    .fci(\dec_ch2/sub0/c19 ),
    .mi(\dec_ch2/d0 [21:20]),
    .f({\dec_ch2/n78 [21],\dec_ch2/n78 [19]}),
    .fco(\dec_ch2/sub0/c23 ),
    .fx({\dec_ch2/n78 [22],\dec_ch2/n78 [20]}),
    .q(\dec_ch2/d0p [21:20]));
  AL_PHY_LSLICE \dec_ch2/sub0/u23_al_u2361  (
    .a({\dec_ch2/d0 [25],\dec_ch2/d0 [23]}),
    .b({\dec_ch2/d0 [26],\dec_ch2/d0 [24]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [25],\dec_ch2/d0p [23]}),
    .e({\dec_ch2/d0p [26],\dec_ch2/d0p [24]}),
    .fci(\dec_ch2/sub0/c23 ),
    .mi({open_n19626,\dec_ch2/d0 [19]}),
    .f({\dec_ch2/n78 [25],\dec_ch2/n78 [23]}),
    .fco(\dec_ch2/sub0/c27 ),
    .fx({\dec_ch2/n78 [26],\dec_ch2/n78 [24]}),
    .q({open_n19639,\dec_ch2/d0p [19]}));
  AL_PHY_LSLICE \dec_ch2/sub0/u27_al_u2362  (
    .a({\dec_ch2/d0 [29],\dec_ch2/d0 [27]}),
    .b({\dec_ch2/d0 [30],\dec_ch2/d0 [28]}),
    .c(2'b11),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [29],\dec_ch2/d0p [27]}),
    .e({\dec_ch2/d0p [30],\dec_ch2/d0p [28]}),
    .fci(\dec_ch2/sub0/c27 ),
    .mi({open_n19640,\dec_ch2/d0 [24]}),
    .f({\dec_ch2/n78 [29],\dec_ch2/n78 [27]}),
    .fco(\dec_ch2/sub0/c31 ),
    .fx({\dec_ch2/n78 [30],\dec_ch2/n78 [28]}),
    .q({open_n19653,\dec_ch2/d0p [24]}));
  AL_PHY_LSLICE \dec_ch2/sub0/u31_al_u2363  (
    .a({\dec_ch2/d0 [33],\dec_ch2/d0 [31]}),
    .b({\dec_ch2/d0 [34],\dec_ch2/d0 [32]}),
    .c(2'b11),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [33],\dec_ch2/d0p [31]}),
    .e({\dec_ch2/d0p [34],\dec_ch2/d0p [32]}),
    .fci(\dec_ch2/sub0/c31 ),
    .mi(\dec_ch2/d0 [27:26]),
    .f({\dec_ch2/n78 [33],\dec_ch2/n78 [31]}),
    .fco(\dec_ch2/sub0/c35 ),
    .fx({\dec_ch2/n78 [34],\dec_ch2/n78 [32]}),
    .q(\dec_ch2/d0p [27:26]));
  AL_PHY_LSLICE \dec_ch2/sub0/u35_al_u2364  (
    .a({\dec_ch2/d0 [37],\dec_ch2/d0 [35]}),
    .b({\dec_ch2/d0 [38],\dec_ch2/d0 [36]}),
    .c(2'b11),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [37],\dec_ch2/d0p [35]}),
    .e({\dec_ch2/d0p [38],\dec_ch2/d0p [36]}),
    .fci(\dec_ch2/sub0/c35 ),
    .mi(\dec_ch2/pa [6:5]),
    .f({\dec_ch2/n78 [37],\dec_ch2/n78 [35]}),
    .fco(\dec_ch2/sub0/c39 ),
    .fx({\dec_ch2/n78 [38],\dec_ch2/n78 [36]}),
    .q(pair_l2[6:5]));
  AL_PHY_LSLICE \dec_ch2/sub0/u39_al_u2365  (
    .a({\dec_ch2/d0 [41],\dec_ch2/d0 [39]}),
    .b({\dec_ch2/d0 [42],\dec_ch2/d0 [40]}),
    .c(2'b11),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [41],\dec_ch2/d0p [39]}),
    .e({\dec_ch2/d0p [42],\dec_ch2/d0p [40]}),
    .fci(\dec_ch2/sub0/c39 ),
    .mi(\dec_ch2/n78 [36:35]),
    .f({\dec_ch2/n78 [41],\dec_ch2/n78 [39]}),
    .fco(\dec_ch2/sub0/c43 ),
    .fx({\dec_ch2/n78 [42],\dec_ch2/n78 [40]}),
    .q(\dec_ch2/c1 [36:35]));
  AL_PHY_LSLICE \dec_ch2/sub0/u3_al_u2356  (
    .a({\dec_ch2/d0 [5],\dec_ch2/d0 [3]}),
    .b({\dec_ch2/d0 [6],\dec_ch2/d0 [4]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [5],\dec_ch2/d0p [3]}),
    .e({\dec_ch2/d0p [6],\dec_ch2/d0p [4]}),
    .fci(\dec_ch2/sub0/c3 ),
    .mi(\dec_ch2/d0 [9:8]),
    .f({\dec_ch2/n78 [5],\dec_ch2/n78 [3]}),
    .fco(\dec_ch2/sub0/c7 ),
    .fx({\dec_ch2/n78 [6],\dec_ch2/n78 [4]}),
    .q(\dec_ch2/d0p [9:8]));
  AL_PHY_LSLICE \dec_ch2/sub0/u43_al_u2366  (
    .a({\dec_ch2/d0 [45],\dec_ch2/d0 [43]}),
    .b({\dec_ch2/d0 [46],\dec_ch2/d0 [44]}),
    .c(2'b11),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [45],\dec_ch2/d0p [43]}),
    .e({\dec_ch2/d0p [46],\dec_ch2/d0p [44]}),
    .fci(\dec_ch2/sub0/c43 ),
    .mi(\dec_ch2/d0 [34:33]),
    .f({\dec_ch2/n78 [45],\dec_ch2/n78 [43]}),
    .fco(\dec_ch2/sub0/c47 ),
    .fx({\dec_ch2/n78 [46],\dec_ch2/n78 [44]}),
    .q(\dec_ch2/d0p [34:33]));
  AL_PHY_LSLICE \dec_ch2/sub0/u47_al_u2367  (
    .a({open_n19715,\dec_ch2/d0 [47]}),
    .c(2'b11),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n19718,\dec_ch2/d0p [47]}),
    .fci(\dec_ch2/sub0/c47 ),
    .mi({open_n19721,io_mcu_data_pad[3]}),
    .f({open_n19734,\dec_ch2/n78 [47]}),
    .q({open_n19738,\dec_shift[3]_hfnopt2_1 }));
  AL_PHY_LSLICE \dec_ch2/sub0/u7_al_u2357  (
    .a({\dec_ch2/d0 [9],\dec_ch2/d0 [7]}),
    .b({\dec_ch2/d0 [10],\dec_ch2/d0 [8]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [9],\dec_ch2/d0p [7]}),
    .e({\dec_ch2/d0p [10],\dec_ch2/d0p [8]}),
    .fci(\dec_ch2/sub0/c7 ),
    .mi(\dec_ch2/d0 [13:12]),
    .f({\dec_ch2/n78 [9],\dec_ch2/n78 [7]}),
    .fco(\dec_ch2/sub0/c11 ),
    .fx({\dec_ch2/n78 [10],\dec_ch2/n78 [8]}),
    .q(\dec_ch2/d0p [13:12]));
  AL_PHY_LSLICE \dec_ch2/sub0/ucin_al_u2355  (
    .a({\dec_ch2/d0 [1],1'b0}),
    .b({\dec_ch2/d0 [2],\dec_ch2/d0 [0]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/d0p [1],1'b1}),
    .e({\dec_ch2/d0p [2],\dec_ch2/d0p [0]}),
    .mi(\dec_ch2/d0 [5:4]),
    .f({\dec_ch2/n78 [1],open_n19764}),
    .fco(\dec_ch2/sub0/c3 ),
    .fx({\dec_ch2/n78 [2],\dec_ch2/n78 [0]}),
    .q(\dec_ch2/d0p [5:4]));
  AL_PHY_LSLICE \dec_ch2/sub1/u11_al_u2371  (
    .a({\dec_ch2/c1 [13],\dec_ch2/c1 [11]}),
    .b({\dec_ch2/c1 [14],\dec_ch2/c1 [12]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [13],\dec_ch2/n81 [11]}),
    .e({\dec_ch2/n81 [14],\dec_ch2/n81 [12]}),
    .fci(\dec_ch2/sub1/c11 ),
    .mi(\dec_ch2/n78 [8:7]),
    .f({\dec_ch2/n82 [13],\dec_ch2/n82 [11]}),
    .fco(\dec_ch2/sub1/c15 ),
    .fx({\dec_ch2/n82 [14],\dec_ch2/n82 [12]}),
    .q(\dec_ch2/c1 [8:7]));
  AL_PHY_LSLICE \dec_ch2/sub1/u15_al_u2372  (
    .a({\dec_ch2/c1 [17],\dec_ch2/c1 [15]}),
    .b({\dec_ch2/c1 [18],\dec_ch2/c1 [16]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [17],\dec_ch2/n81 [15]}),
    .e({\dec_ch2/n81 [18],\dec_ch2/n81 [16]}),
    .fci(\dec_ch2/sub1/c15 ),
    .mi({\dec_ch2/n78 [13],\dec_ch2/n78 [11]}),
    .f({\dec_ch2/n82 [17],\dec_ch2/n82 [15]}),
    .fco(\dec_ch2/sub1/c19 ),
    .fx({\dec_ch2/n82 [18],\dec_ch2/n82 [16]}),
    .q({\dec_ch2/c1 [13],\dec_ch2/c1 [11]}));
  AL_PHY_LSLICE \dec_ch2/sub1/u19_al_u2373  (
    .a({\dec_ch2/c1 [21],\dec_ch2/c1 [19]}),
    .b({\dec_ch2/c1 [22],\dec_ch2/c1 [20]}),
    .c(2'b11),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [21],\dec_ch2/n81 [19]}),
    .e({\dec_ch2/n81 [22],\dec_ch2/n81 [20]}),
    .fci(\dec_ch2/sub1/c19 ),
    .mi({\dec_ch2/n82 [22],\dec_ch2/n82 [20]}),
    .f({\dec_ch2/n82 [21],\dec_ch2/n82 [19]}),
    .fco(\dec_ch2/sub1/c23 ),
    .fx({\dec_ch2/n82 [22],\dec_ch2/n82 [20]}),
    .q({\dec_ch2/c2 [22],\dec_ch2/c2 [20]}));
  AL_PHY_LSLICE \dec_ch2/sub1/u23_al_u2374  (
    .a({\dec_ch2/c1 [25],\dec_ch2/c1 [23]}),
    .b({\dec_ch2/c1 [26],\dec_ch2/c1 [24]}),
    .c(2'b11),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [25],\dec_ch2/n81 [23]}),
    .e({\dec_ch2/n81 [26],\dec_ch2/n81 [24]}),
    .fci(\dec_ch2/sub1/c23 ),
    .mi({open_n19802,\dec_sv[1]_hfnopt2_3 }),
    .f({\dec_ch2/n82 [25],\dec_ch2/n82 [23]}),
    .fco(\dec_ch2/sub1/c27 ),
    .fx({\dec_ch2/n82 [26],\dec_ch2/n82 [24]}),
    .q({open_n19815,dec_sv[2]}));
  AL_PHY_LSLICE \dec_ch2/sub1/u27_al_u2375  (
    .a({\dec_ch2/c1 [29],\dec_ch2/c1 [27]}),
    .b({\dec_ch2/c1 [30],\dec_ch2/c1 [28]}),
    .c(2'b11),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [29],\dec_ch2/n81 [27]}),
    .e({\dec_ch2/n81 [30],\dec_ch2/n81 [28]}),
    .fci(\dec_ch2/sub1/c27 ),
    .mi(\dec_ch2/c1 [21:20]),
    .f({\dec_ch2/n82 [29],\dec_ch2/n82 [27]}),
    .fco(\dec_ch2/sub1/c31 ),
    .fx({\dec_ch2/n82 [30],\dec_ch2/n82 [28]}),
    .q(\dec_ch2/c1p [21:20]));
  AL_PHY_LSLICE \dec_ch2/sub1/u31_al_u2376  (
    .a({\dec_ch2/c1 [33],\dec_ch2/c1 [31]}),
    .b({\dec_ch2/c1 [34],\dec_ch2/c1 [32]}),
    .c(2'b11),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [33],\dec_ch2/n81 [31]}),
    .e({\dec_ch2/n81 [34],\dec_ch2/n81 [32]}),
    .fci(\dec_ch2/sub1/c31 ),
    .mi(\dec_ch2/c1 [24:23]),
    .f({\dec_ch2/n82 [33],\dec_ch2/n82 [31]}),
    .fco(\dec_ch2/sub1/c35 ),
    .fx({\dec_ch2/n82 [34],\dec_ch2/n82 [32]}),
    .q(\dec_ch2/c1p [24:23]));
  AL_PHY_LSLICE \dec_ch2/sub1/u35_al_u2377  (
    .a({\dec_ch2/c1 [37],\dec_ch2/c1 [35]}),
    .b({\dec_ch2/c1 [38],\dec_ch2/c1 [36]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [37],\dec_ch2/n81 [35]}),
    .e({\dec_ch2/n81 [38],\dec_ch2/n81 [36]}),
    .fci(\dec_ch2/sub1/c35 ),
    .mi({\dec_ch2/n82 [34],\dec_ch2/n82 [32]}),
    .f({\dec_ch2/n82 [37],\dec_ch2/n82 [35]}),
    .fco(\dec_ch2/sub1/c39 ),
    .fx({\dec_ch2/n82 [38],\dec_ch2/n82 [36]}),
    .q({\dec_ch2/c2 [34],\dec_ch2/c2 [32]}));
  AL_PHY_LSLICE \dec_ch2/sub1/u39_al_u2378  (
    .a({\dec_ch2/c1 [41],\dec_ch2/c1 [39]}),
    .b({\dec_ch2/c1 [42],\dec_ch2/c1 [40]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [41],\dec_ch2/n81 [39]}),
    .e({\dec_ch2/n81 [42],\dec_ch2/n81 [40]}),
    .fci(\dec_ch2/sub1/c39 ),
    .mi(\dec_ch2/n82 [37:36]),
    .f({\dec_ch2/n82 [41],\dec_ch2/n82 [39]}),
    .fco(\dec_ch2/sub1/c43 ),
    .fx({\dec_ch2/n82 [42],\dec_ch2/n82 [40]}),
    .q(\dec_ch2/c2 [37:36]));
  AL_PHY_LSLICE \dec_ch2/sub1/u3_al_u2369  (
    .a({\dec_ch2/c1 [5],\dec_ch2/c1 [3]}),
    .b({\dec_ch2/c1 [6],\dec_ch2/c1 [4]}),
    .c(2'b11),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [5],\dec_ch2/n81 [3]}),
    .e({\dec_ch2/n81 [6],\dec_ch2/n81 [4]}),
    .fci(\dec_ch2/sub1/c3 ),
    .mi(\dec_ch2/c1 [6:5]),
    .f({\dec_ch2/n82 [5],\dec_ch2/n82 [3]}),
    .fco(\dec_ch2/sub1/c7 ),
    .fx({\dec_ch2/n82 [6],\dec_ch2/n82 [4]}),
    .q(\dec_ch2/c1p [6:5]));
  AL_PHY_LSLICE \dec_ch2/sub1/u43_al_u2379  (
    .a({\dec_ch2/c1 [45],\dec_ch2/c1 [43]}),
    .b({\dec_ch2/c1 [46],\dec_ch2/c1 [44]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [45],\dec_ch2/n81 [43]}),
    .e({\dec_ch2/n81 [46],\dec_ch2/n81 [44]}),
    .fci(\dec_ch2/sub1/c43 ),
    .mi(\dec_ch2/n82 [39:38]),
    .f({\dec_ch2/n82 [45],\dec_ch2/n82 [43]}),
    .fco(\dec_ch2/sub1/c47 ),
    .fx({\dec_ch2/n82 [46],\dec_ch2/n82 [44]}),
    .q(\dec_ch2/c2 [39:38]));
  AL_PHY_LSLICE \dec_ch2/sub1/u47_al_u2380  (
    .a({open_n19888,\dec_ch2/c1 [47]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n19891,\dec_ch2/n81 [47]}),
    .fci(\dec_ch2/sub1/c47 ),
    .mi(\dec_ch2/n82 [41:40]),
    .f({open_n19906,\dec_ch2/n82 [47]}),
    .q(\dec_ch2/c2 [41:40]));
  AL_PHY_LSLICE \dec_ch2/sub1/u7_al_u2370  (
    .a({\dec_ch2/c1 [9],\dec_ch2/c1 [7]}),
    .b({\dec_ch2/c1 [10],\dec_ch2/c1 [8]}),
    .c(2'b11),
    .ce(\dec_sv[1]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [9],\dec_ch2/n81 [7]}),
    .e({\dec_ch2/n81 [10],\dec_ch2/n81 [8]}),
    .fci(\dec_ch2/sub1/c7 ),
    .mi(\dec_ch2/n78 [4:3]),
    .f({\dec_ch2/n82 [9],\dec_ch2/n82 [7]}),
    .fco(\dec_ch2/sub1/c11 ),
    .fx({\dec_ch2/n82 [10],\dec_ch2/n82 [8]}),
    .q(\dec_ch2/c1 [4:3]));
  AL_PHY_LSLICE \dec_ch2/sub1/ucin_al_u2368  (
    .a({\dec_ch2/c1 [1],1'b0}),
    .b({\dec_ch2/c1 [2],\dec_ch2/c1 [0]}),
    .c(2'b11),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n81 [1],1'b1}),
    .e({\dec_ch2/n81 [2],\dec_ch2/n81 [0]}),
    .mi(\dec_ch2/c1 [4:3]),
    .f({\dec_ch2/n82 [1],open_n19935}),
    .fco(\dec_ch2/sub1/c3 ),
    .fx({\dec_ch2/n82 [2],\dec_ch2/n82 [0]}),
    .q(\dec_ch2/c1p [4:3]));
  AL_PHY_LSLICE \dec_ch2/sub2/u11_al_u2384  (
    .a({\dec_ch2/c2 [13],\dec_ch2/c2 [11]}),
    .b({\dec_ch2/c2 [14],\dec_ch2/c2 [12]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [13],\dec_ch2/n85 [11]}),
    .e({\dec_ch2/n85 [14],\dec_ch2/n85 [12]}),
    .fci(\dec_ch2/sub2/c11 ),
    .mi(\dec_ch2/n86 [14:13]),
    .f({\dec_ch2/n86 [13],\dec_ch2/n86 [11]}),
    .fco(\dec_ch2/sub2/c15 ),
    .fx({\dec_ch2/n86 [14],\dec_ch2/n86 [12]}),
    .q(\dec_ch2/c3 [14:13]));
  AL_PHY_LSLICE \dec_ch2/sub2/u15_al_u2385  (
    .a({\dec_ch2/c2 [17],\dec_ch2/c2 [15]}),
    .b({\dec_ch2/c2 [18],\dec_ch2/c2 [16]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [17],\dec_ch2/n85 [15]}),
    .e({\dec_ch2/n85 [18],\dec_ch2/n85 [16]}),
    .fci(\dec_ch2/sub2/c15 ),
    .mi({\dec_ch2/n86 [19],\dec_ch2/n86 [16]}),
    .f({\dec_ch2/n86 [17],\dec_ch2/n86 [15]}),
    .fco(\dec_ch2/sub2/c19 ),
    .fx({\dec_ch2/n86 [18],\dec_ch2/n86 [16]}),
    .q({\dec_ch2/c3 [19],\dec_ch2/c3 [16]}));
  AL_PHY_LSLICE \dec_ch2/sub2/u19_al_u2386  (
    .a({\dec_ch2/c2 [21],\dec_ch2/c2 [19]}),
    .b({\dec_ch2/c2 [22],\dec_ch2/c2 [20]}),
    .c(2'b11),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [21],\dec_ch2/n85 [19]}),
    .e({\dec_ch2/n85 [22],\dec_ch2/n85 [20]}),
    .fci(\dec_ch2/sub2/c19 ),
    .mi({open_n19961,\dec_sv[2]_hfnopt2_3 }),
    .f({\dec_ch2/n86 [21],\dec_ch2/n86 [19]}),
    .fco(\dec_ch2/sub2/c23 ),
    .fx({\dec_ch2/n86 [22],\dec_ch2/n86 [20]}),
    .q({open_n19974,\dec_sv[3]_hfnopt2_5 }));
  AL_PHY_LSLICE \dec_ch2/sub2/u23_al_u2387  (
    .a({\dec_ch2/c2 [25],\dec_ch2/c2 [23]}),
    .b({\dec_ch2/c2 [26],\dec_ch2/c2 [24]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [25],\dec_ch2/n85 [23]}),
    .e({\dec_ch2/n85 [26],\dec_ch2/n85 [24]}),
    .fci(\dec_ch2/sub2/c23 ),
    .mi(\dec_ch2/n86 [22:21]),
    .f({\dec_ch2/n86 [25],\dec_ch2/n86 [23]}),
    .fco(\dec_ch2/sub2/c27 ),
    .fx({\dec_ch2/n86 [26],\dec_ch2/n86 [24]}),
    .q(\dec_ch2/c3 [22:21]));
  AL_PHY_LSLICE \dec_ch2/sub2/u27_al_u2388  (
    .a({\dec_ch2/c2 [29],\dec_ch2/c2 [27]}),
    .b({\dec_ch2/c2 [30],\dec_ch2/c2 [28]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [29],\dec_ch2/n85 [27]}),
    .e({\dec_ch2/n85 [30],\dec_ch2/n85 [28]}),
    .fci(\dec_ch2/sub2/c27 ),
    .mi(\dec_ch2/n86 [24:23]),
    .f({\dec_ch2/n86 [29],\dec_ch2/n86 [27]}),
    .fco(\dec_ch2/sub2/c31 ),
    .fx({\dec_ch2/n86 [30],\dec_ch2/n86 [28]}),
    .q(\dec_ch2/c3 [24:23]));
  AL_PHY_LSLICE \dec_ch2/sub2/u31_al_u2389  (
    .a({\dec_ch2/c2 [33],\dec_ch2/c2 [31]}),
    .b({\dec_ch2/c2 [34],\dec_ch2/c2 [32]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [33],\dec_ch2/n85 [31]}),
    .e({\dec_ch2/n85 [34],\dec_ch2/n85 [32]}),
    .fci(\dec_ch2/sub2/c31 ),
    .mi(\dec_ch2/n86 [30:29]),
    .f({\dec_ch2/n86 [33],\dec_ch2/n86 [31]}),
    .fco(\dec_ch2/sub2/c35 ),
    .fx({\dec_ch2/n86 [34],\dec_ch2/n86 [32]}),
    .q(\dec_ch2/c3 [30:29]));
  AL_PHY_LSLICE \dec_ch2/sub2/u35_al_u2390  (
    .a({\dec_ch2/c2 [37],\dec_ch2/c2 [35]}),
    .b({\dec_ch2/c2 [38],\dec_ch2/c2 [36]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [37],\dec_ch2/n85 [35]}),
    .e({\dec_ch2/n85 [38],\dec_ch2/n85 [36]}),
    .fci(\dec_ch2/sub2/c35 ),
    .mi({open_n20011,\dec_ch2/n86 [32]}),
    .f({\dec_ch2/n86 [37],\dec_ch2/n86 [35]}),
    .fco(\dec_ch2/sub2/c39 ),
    .fx({\dec_ch2/n86 [38],\dec_ch2/n86 [36]}),
    .q({open_n20024,\dec_ch2/c3 [32]}));
  AL_PHY_LSLICE \dec_ch2/sub2/u39_al_u2391  (
    .a({\dec_ch2/c2 [41],\dec_ch2/c2 [39]}),
    .b({\dec_ch2/c2 [42],\dec_ch2/c2 [40]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_5 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [41],\dec_ch2/n85 [39]}),
    .e({\dec_ch2/n85 [42],\dec_ch2/n85 [40]}),
    .fci(\dec_ch2/sub2/c39 ),
    .mi({open_n20025,\dec_ch2/n86 [33]}),
    .f({\dec_ch2/n86 [41],\dec_ch2/n86 [39]}),
    .fco(\dec_ch2/sub2/c43 ),
    .fx({\dec_ch2/n86 [42],\dec_ch2/n86 [40]}),
    .q({open_n20038,\dec_ch2/c3 [33]}));
  AL_PHY_LSLICE \dec_ch2/sub2/u3_al_u2382  (
    .a({\dec_ch2/c2 [5],\dec_ch2/c2 [3]}),
    .b({\dec_ch2/c2 [6],\dec_ch2/c2 [4]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [5],\dec_ch2/n85 [3]}),
    .e({\dec_ch2/n85 [6],\dec_ch2/n85 [4]}),
    .fci(\dec_ch2/sub2/c3 ),
    .mi({open_n20039,\dec_ch2/c2 [10]}),
    .f({\dec_ch2/n86 [5],\dec_ch2/n86 [3]}),
    .fco(\dec_ch2/sub2/c7 ),
    .fx({\dec_ch2/n86 [6],\dec_ch2/n86 [4]}),
    .q({open_n20052,\dec_ch2/c2p [10]}));
  AL_PHY_LSLICE \dec_ch2/sub2/u43_al_u2392  (
    .a({\dec_ch2/c2 [45],\dec_ch2/c2 [43]}),
    .b({\dec_ch2/c2 [46],\dec_ch2/c2 [44]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [45],\dec_ch2/n85 [43]}),
    .e({\dec_ch2/n85 [46],\dec_ch2/n85 [44]}),
    .fci(\dec_ch2/sub2/c43 ),
    .mi(\dec_ch2/n86 [38:37]),
    .f({\dec_ch2/n86 [45],\dec_ch2/n86 [43]}),
    .fco(\dec_ch2/sub2/c47 ),
    .fx({\dec_ch2/n86 [46],\dec_ch2/n86 [44]}),
    .q(\dec_ch2/c3 [38:37]));
  AL_PHY_LSLICE \dec_ch2/sub2/u47_al_u2393  (
    .a({open_n20065,\dec_ch2/c2 [47]}),
    .c(2'b11),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({open_n20068,\dec_ch2/n85 [47]}),
    .fci(\dec_ch2/sub2/c47 ),
    .mi({\dec_ch2/n86 [40],\dec_ch2/n86 [31]}),
    .f({open_n20083,\dec_ch2/n86 [47]}),
    .q({\dec_ch2/c3 [40],\dec_ch2/c3 [31]}));
  AL_PHY_LSLICE \dec_ch2/sub2/u7_al_u2383  (
    .a({\dec_ch2/c2 [9],\dec_ch2/c2 [7]}),
    .b({\dec_ch2/c2 [10],\dec_ch2/c2 [8]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [9],\dec_ch2/n85 [7]}),
    .e({\dec_ch2/n85 [10],\dec_ch2/n85 [8]}),
    .fci(\dec_ch2/sub2/c7 ),
    .mi({\dec_ch2/n82 [7],\dec_ch2/n82 [19]}),
    .f({\dec_ch2/n86 [9],\dec_ch2/n86 [7]}),
    .fco(\dec_ch2/sub2/c11 ),
    .fx({\dec_ch2/n86 [10],\dec_ch2/n86 [8]}),
    .q({\dec_ch2/c2 [7],\dec_ch2/c2 [19]}));
  AL_PHY_LSLICE \dec_ch2/sub2/ucin_al_u2381  (
    .a({\dec_ch2/c2 [1],1'b0}),
    .b({\dec_ch2/c2 [2],\dec_ch2/c2 [0]}),
    .c(2'b11),
    .ce(\dec_sv[2]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/n85 [1],1'b1}),
    .e({\dec_ch2/n85 [2],\dec_ch2/n85 [0]}),
    .mi(\dec_ch2/n82 [9:8]),
    .f({\dec_ch2/n86 [1],open_n20112}),
    .fco(\dec_ch2/sub2/c3 ),
    .fx({\dec_ch2/n86 [2],\dec_ch2/n86 [0]}),
    .q(\dec_ch2/c2 [9:8]));
  AL_PHY_LSLICE \display_brightness/pwm_reg  (
    .a({open_n20113,_al_u1743_o}),
    .b({open_n20114,_al_u1747_o}),
    .c({open_n20115,_al_u1745_o}),
    .ce(\display_brightness/n0 ),
    .clk(clk_50MHz_gclk_net),
    .d({open_n20116,_al_u1748_o}),
    .q({open_n20139,o_pwm_display_pad}));  // zaklad.v(194)
  AL_PHY_MSLICE \display_brightness/reg0_b0|display_brightness/add0/ucin  (
    .a({\display_brightness/count [0],1'b0}),
    .b({1'b1,open_n20140}),
    .clk(clk_50MHz_gclk_net),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c1 ),
    .q({\display_brightness/count [0],open_n20162}));
  AL_PHY_MSLICE \display_brightness/reg0_b10|display_brightness/reg0_b9  (
    .a(\display_brightness/count [10:9]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c9 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c11 ),
    .q(\display_brightness/count [10:9]));
  AL_PHY_MSLICE \display_brightness/reg0_b12|display_brightness/reg0_b11  (
    .a(\display_brightness/count [12:11]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c11 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c13 ),
    .q(\display_brightness/count [12:11]));
  AL_PHY_MSLICE \display_brightness/reg0_b14|display_brightness/reg0_b13  (
    .a(\display_brightness/count [14:13]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c13 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c15 ),
    .q(\display_brightness/count [14:13]));
  AL_PHY_MSLICE \display_brightness/reg0_b15_al_u2463  (
    .a({open_n20223,\display_brightness/count [15]}),
    .b({open_n20224,1'b0}),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c15 ),
    .sr(\display_brightness/n0 ),
    .q({open_n20246,\display_brightness/count [15]}));
  AL_PHY_MSLICE \display_brightness/reg0_b2|display_brightness/reg0_b1  (
    .a(\display_brightness/count [2:1]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c1 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c3 ),
    .q(\display_brightness/count [2:1]));
  AL_PHY_MSLICE \display_brightness/reg0_b4|display_brightness/reg0_b3  (
    .a(\display_brightness/count [4:3]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c3 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c5 ),
    .q(\display_brightness/count [4:3]));
  AL_PHY_MSLICE \display_brightness/reg0_b6|display_brightness/reg0_b5  (
    .a(\display_brightness/count [6:5]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c5 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c7 ),
    .q(\display_brightness/count [6:5]));
  AL_PHY_MSLICE \display_brightness/reg0_b8|display_brightness/reg0_b7  (
    .a(\display_brightness/count [8:7]),
    .b(2'b00),
    .clk(clk_50MHz_gclk_net),
    .fci(\display_brightness/add0/c7 ),
    .sr(\display_brightness/n0 ),
    .fco(\display_brightness/add0/c9 ),
    .q(\display_brightness/count [8:7]));
  AL_PHY_MSLICE enc_cur_n_reg (
    .clk(clk_200MHz),
    .mi({open_n20346,enc_nxt_n}),
    .q({open_n20353,enc_cur_n}));  // zaklad.v(1461)
  AL_PHY_LSLICE enc_nxt_n_reg (
    .c({open_n20358,swc_sh}),
    .clk(clk_200MHz),
    .d({open_n20360,sce_q}),
    .f({open_n20378,n125}),
    .q({open_n20382,enc_nxt_n}));  // zaklad.v(1445)
  // zaklad.v(2102)
  // zaklad.v(1445)
  AL_PHY_LSLICE \enc_nxt_reg|ho_en_reg  (
    .a({open_n20383,_al_u401_o}),
    .b({open_n20384,_al_u403_o}),
    .c({open_n20385,_al_u404_o}),
    .clk(clk_200MHz),
    .d({n125,_al_u405_o}),
    .q({enc_nxt,ho_en}));  // zaklad.v(2102)
  AL_PHY_PAD \enc_oddr_1A/u_oddr_DO  (
    .clk(clk_ADCA),
    .ocomp(enc_cur_n),
    .otrue(enc_cur_n),
    .rst(1'b0),
    .opad(o_adc1_encA));  // al3_io.v(11)
  AL_PHY_PAD \enc_oddr_1B/u_oddr_DO  (
    .clk(clk_ADCB),
    .ocomp(enc_cur),
    .otrue(enc_cur),
    .rst(1'b0),
    .opad(o_adc1_encB));  // al3_io.v(11)
  AL_PHY_PAD \enc_oddr_2A/u_oddr_DO  (
    .clk(clk_ADCA),
    .ocomp(enc_cur_n),
    .otrue(enc_cur_n),
    .rst(1'b0),
    .opad(o_adc2_encA));  // al3_io.v(11)
  AL_PHY_PAD \enc_oddr_2B/u_oddr_DO  (
    .clk(clk_ADCB),
    .ocomp(enc_cur),
    .otrue(enc_cur),
    .rst(1'b0),
    .opad(o_adc2_encB));  // al3_io.v(11)
  AL_PHY_LSLICE enc_pred_ok_reg (
    .c({open_n20445,swc_sh}),
    .clk(clk_200MHz),
    .d({open_n20447,enc_cur}),
    .q({open_n20470,enc_pred_ok}));  // zaklad.v(1511)
  // zaklad.v(1215)
  // zaklad.v(1215)
  AL_PHY_MSLICE \ext_level_reg|reg1_b1  (
    .a({open_n20471,_al_u1434_o}),
    .b({ext_hist[0],\lt21/o_1_lutinv }),
    .c({ext_sync[1],_al_u1426_o}),
    .clk(clk_200MHz),
    .d({ext_hist[1],n515}),
    .mi({open_n20483,ext_hist[0]}),
    .f({open_n20485,u553_sel_is_3_o}),
    .q({ext_level,ext_hist[1]}));  // zaklad.v(1215)
  AL_PHY_MSLICE ho_clr_req_reg (
    .a({_al_u2197_o,ho_clr_req}),
    .b({n682_lutinv,n682_lutinv}),
    .c({io_mcu_data_pad[0],_al_u2197_o}),
    .ce(n515),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({ho_clr_req,io_mcu_data_pad[0]}),
    .mi({open_n20499,mcu_command[0]}),
    .q({open_n20506,ho_clr_req}));  // zaklad.v(2867)
  AL_PHY_GCLK i_mcu_clk_pad_gclk_inst (
    .clki(i_mcu_clk_pad),
    .clko(i_mcu_clk_pad_gclk_net));
  AL_PHY_LSLICE l_req_reg (
    .a({open_n20507,l_req}),
    .ce(n172),
    .clk(i_mcu_clk_pad_gclk_net),
    .q({open_n20536,l_req}));  // zaklad.v(1735)
  AL_PHY_MSLICE lo_ones_reg (
    .a({open_n20537,n8}),
    .b({open_n20538,_al_u1000_o}),
    .c({open_n20539,_al_u1001_o}),
    .clk(clk_200MHz),
    .d({open_n20541,_al_u1002_o}),
    .q({open_n20560,lo_ones}));  // zaklad.v(1742)
  AL_PHY_MSLICE \lt0/u0|lt0/ucin  (
    .a({sample_rate_divider_eff[0],1'b0}),
    .b({sample_rate_counter[0],open_n20561}),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n20576,n556}),
    .fco(\lt0/c1 ),
    .q({open_n20582,cap_sel_x[9]}));
  AL_PHY_MSLICE \lt0/u10|lt0/u9  (
    .a(sample_rate_divider_eff[10:9]),
    .b(sample_rate_counter[10:9]),
    .clk(clk_200MHz),
    .fci(\lt0/c9 ),
    .mi({open_n20597,n144[10]}),
    .sr(sample_clock_enable),
    .fco(\lt0/c11 ),
    .q({open_n20602,sample_rate_counter[10]}));
  AL_PHY_MSLICE \lt0/u12|lt0/u11  (
    .a(sample_rate_divider_eff[12:11]),
    .b(sample_rate_counter[12:11]),
    .clk(clk_200MHz),
    .fci(\lt0/c11 ),
    .mi(n144[12:11]),
    .sr(sample_clock_enable),
    .fco(\lt0/c13 ),
    .q(sample_rate_counter[12:11]));
  AL_PHY_MSLICE \lt0/u14|lt0/u13  (
    .a(sample_rate_divider_eff[14:13]),
    .b(sample_rate_counter[14:13]),
    .clk(clk_200MHz),
    .fci(\lt0/c13 ),
    .mi(n144[14:13]),
    .sr(sample_clock_enable),
    .fco(\lt0/c15 ),
    .q(sample_rate_counter[14:13]));
  AL_PHY_MSLICE \lt0/u16|lt0/u15  (
    .a(sample_rate_divider_eff[16:15]),
    .b(sample_rate_counter[16:15]),
    .ce(u546_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt0/c15 ),
    .mi({open_n20652,n557}),
    .fco(\lt0/c17 ),
    .q({open_n20658,o_relay1_3_pad}));
  AL_PHY_MSLICE \lt0/u18|lt0/u17  (
    .a(sample_rate_divider_eff[18:17]),
    .b(sample_rate_counter[18:17]),
    .fci(\lt0/c17 ),
    .fco(\lt0/c19 ));
  AL_PHY_MSLICE \lt0/u2|lt0/u1  (
    .a(sample_rate_divider_eff[2:1]),
    .b(sample_rate_counter[2:1]),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt0/c1 ),
    .mi({open_n20696,io_mcu_data_pad[4]}),
    .fco(\lt0/c3 ),
    .q({open_n20702,cap_sel_x[12]}));
  AL_PHY_MSLICE \lt0/u4|lt0/u3  (
    .a(sample_rate_divider_eff[4:3]),
    .b(sample_rate_counter[4:3]),
    .clk(clk_200MHz),
    .fci(\lt0/c3 ),
    .mi(n144[2:1]),
    .sr(sample_clock_enable),
    .fco(\lt0/c5 ),
    .q(sample_rate_counter[2:1]));
  AL_PHY_MSLICE \lt0/u6|lt0/u5  (
    .a(sample_rate_divider_eff[6:5]),
    .b(sample_rate_counter[6:5]),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt0/c5 ),
    .mi({open_n20734,n557}),
    .fco(\lt0/c7 ),
    .q({open_n20740,cap_sel_x[10]}));
  AL_PHY_MSLICE \lt0/u8|lt0/u7  (
    .a(sample_rate_divider_eff[8:7]),
    .b(sample_rate_counter[8:7]),
    .clk(clk_200MHz),
    .fci(\lt0/c7 ),
    .mi({open_n20755,n144[3]}),
    .sr(sample_clock_enable),
    .fco(\lt0/c9 ),
    .q({open_n20760,sample_rate_counter[3]}));
  AL_PHY_MSLICE \lt0/ucout|lt0/u19  (
    .a({1'b0,sample_rate_divider_eff[19]}),
    .b({1'b1,sample_rate_counter[19]}),
    .fci(\lt0/c19 ),
    .f({sample_clock_enable,open_n20779}));
  AL_PHY_MSLICE \lt1/u0|lt1/ucin  (
    .a({sample_rate_divider_eff[0],1'b1}),
    .b({sample_rate_counter[0],open_n20785}),
    .fco(\lt1/c1 ));
  AL_PHY_MSLICE \lt1/u10|lt1/u9  (
    .a(sample_rate_divider_eff[10:9]),
    .b(sample_rate_counter[10:9]),
    .fci(\lt1/c9 ),
    .fco(\lt1/c11 ));
  AL_PHY_MSLICE \lt1/u12|lt1/u11  (
    .a(sample_rate_divider_eff[12:11]),
    .b(sample_rate_counter[12:11]),
    .fci(\lt1/c11 ),
    .fco(\lt1/c13 ));
  AL_PHY_MSLICE \lt1/u14|lt1/u13  (
    .a(sample_rate_divider_eff[14:13]),
    .b(sample_rate_counter[14:13]),
    .fci(\lt1/c13 ),
    .fco(\lt1/c15 ));
  AL_PHY_MSLICE \lt1/u16|lt1/u15  (
    .a(sample_rate_divider_eff[16:15]),
    .b(sample_rate_counter[16:15]),
    .fci(\lt1/c15 ),
    .fco(\lt1/c17 ));
  AL_PHY_MSLICE \lt1/u18|lt1/u17  (
    .a(sample_rate_divider_eff[18:17]),
    .b(sample_rate_counter[18:17]),
    .fci(\lt1/c17 ),
    .fco(\lt1/c19 ));
  AL_PHY_MSLICE \lt1/u2|lt1/u1  (
    .a(sample_rate_divider_eff[2:1]),
    .b(sample_rate_counter[2:1]),
    .fci(\lt1/c1 ),
    .fco(\lt1/c3 ));
  AL_PHY_MSLICE \lt1/u4|lt1/u3  (
    .a(sample_rate_divider_eff[4:3]),
    .b(sample_rate_counter[4:3]),
    .fci(\lt1/c3 ),
    .fco(\lt1/c5 ));
  AL_PHY_MSLICE \lt1/u6|lt1/u5  (
    .a(sample_rate_divider_eff[6:5]),
    .b(sample_rate_counter[6:5]),
    .fci(\lt1/c5 ),
    .fco(\lt1/c7 ));
  AL_PHY_MSLICE \lt1/u8|lt1/u7  (
    .a(sample_rate_divider_eff[8:7]),
    .b(sample_rate_counter[8:7]),
    .fci(\lt1/c7 ),
    .fco(\lt1/c9 ));
  AL_PHY_MSLICE \lt1/ucout|lt1/u19  (
    .a({1'b0,sample_rate_divider_eff[19]}),
    .b({1'b1,sample_rate_counter[19]}),
    .fci(\lt1/c19 ),
    .f({n148,open_n21045}));
  AL_PHY_MSLICE \lt10/u0|lt10/ucin  (
    .a({trigger_level[0],1'b1}),
    .b({trigger_data[0],open_n21051}),
    .fco(\lt10/c1 ));
  AL_PHY_MSLICE \lt10/u2|lt10/u1  (
    .a(trigger_level[2:1]),
    .b(trigger_data[2:1]),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt10/c1 ),
    .mi({\dec_ch2/d0 [38],\dec_ch2/d0 [36]}),
    .fco(\lt10/c3 ),
    .q({\dec_ch2/d0p [38],\dec_ch2/d0p [36]}));
  AL_PHY_MSLICE \lt10/u4|lt10/u3  (
    .a(trigger_level[4:3]),
    .b(trigger_data[4:3]),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt10/c3 ),
    .mi(\dec_ch2/d0 [44:43]),
    .fco(\lt10/c5 ),
    .q(\dec_ch2/d0p [44:43]));
  AL_PHY_MSLICE \lt10/u6|lt10/u5  (
    .a(trigger_level[6:5]),
    .b(trigger_data[6:5]),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt10/c5 ),
    .mi(\dec_ch2/d0 [46:45]),
    .fco(\lt10/c7 ),
    .q(\dec_ch2/d0p [46:45]));
  AL_PHY_MSLICE \lt10/ucout|lt10/u7  (
    .a({1'b0,trigger_level[7]}),
    .b({1'b1,trigger_data[7]}),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt10/c7 ),
    .mi({\dec_ch2/d0 [41],\dec_ch2/d0 [39]}),
    .f({n266,open_n21145}),
    .q({\dec_ch2/d0p [41],\dec_ch2/d0p [39]}));
  AL_PHY_MSLICE \lt11/u0|lt11/ucin  (
    .a({\dec_ch1/pa [0],1'b0}),
    .b({adc1A_w[0],open_n21149}),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch1/c2 [20],\dec_ch1/n86 [20]}),
    .fco(\lt11/c1 ),
    .q({\dec_ch1/c2p [20],\dec_ch1/c3 [20]}));
  AL_PHY_MSLICE \lt11/u2|lt11/u1  (
    .a(\dec_ch1/pa [2:1]),
    .b(adc1A_w[2:1]),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt11/c1 ),
    .mi(\dec_ch1/n86 [22:21]),
    .fco(\lt11/c3 ),
    .q(\dec_ch1/c3 [22:21]));
  AL_PHY_MSLICE \lt11/u4|lt11/u3  (
    .a(\dec_ch1/pa [4:3]),
    .b(adc1A_w[4:3]),
    .ce(\dec_sv[3]_hfnopt2_2 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt11/c3 ),
    .mi(\dec_ch1/n86 [30:29]),
    .fco(\lt11/c5 ),
    .q(\dec_ch1/c3 [30:29]));
  AL_PHY_MSLICE \lt11/u6|lt11/u5  (
    .a(\dec_ch1/pa [6:5]),
    .b(adc1A_w[6:5]),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt11/c5 ),
    .mi({open_n21218,\dec_ch2/pk0 [15]}),
    .fco(\lt11/c7 ),
    .q({open_n21224,\dec_ch2/pk1 [15]}));
  AL_PHY_MSLICE \lt11/ucout|lt11/u7  (
    .a({1'b0,\dec_ch1/pa [7]}),
    .b({1'b1,adc1A_w[7]}),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt11/c7 ),
    .mi({\dec_ch1/n86 [4],\dec_ch1/n86 [32]}),
    .f({n290,open_n21239}),
    .q({\dec_ch1/c3 [4],\dec_ch1/c3 [32]}));
  AL_PHY_MSLICE \lt12/u0|lt12/ucin  (
    .a({cap_thr_x[0],1'b0}),
    .b({n293[0],open_n21243}),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch2/n70 [30:29]),
    .fco(\lt12/c1 ),
    .q(\dec_ch2/i1 [30:29]));
  AL_PHY_MSLICE \lt12/u2|lt12/u1  (
    .a(cap_thr_x[2:1]),
    .b(n293[2:1]),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt12/c1 ),
    .mi({open_n21277,\dec_ch2/d0 [0]}),
    .fco(\lt12/c3 ),
    .q({open_n21283,\dec_ch2/d0p [0]}));
  AL_PHY_MSLICE \lt12/u4|lt12/u3  (
    .a({cap_thr_x[4],cap_thr[3]}),
    .b(n293[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt12/c3 ),
    .mi(\dec_ch2/n70 [32:31]),
    .fco(\lt12/c5 ),
    .q(\dec_ch2/i1 [32:31]));
  AL_PHY_MSLICE \lt12/u6|lt12/u5  (
    .a(cap_thr_x[6:5]),
    .b(n293[6:5]),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt12/c5 ),
    .mi({open_n21316,\dec_ch2/d0 [10]}),
    .fco(\lt12/c7 ),
    .q({open_n21322,\dec_ch2/d0p [10]}));
  AL_PHY_MSLICE \lt12/ucout|lt12/u7  (
    .a({1'b0,cap_thr_x[7]}),
    .b({1'b1,n293[7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt12/c7 ),
    .mi(\dec_ch2/n70 [34:33]),
    .f({n294,open_n21338}),
    .q(\dec_ch2/i1 [34:33]));
  AL_PHY_MSLICE \lt13/u0|lt13/ucin  (
    .a({\dec_ch1/pb [0],1'b0}),
    .b({adc1B_w[0],open_n21342}),
    .clk(clk_200MHz),
    .mi(adc_d2[4:3]),
    .fco(\lt13/c1 ),
    .q(adc_dd2[4:3]));
  AL_PHY_MSLICE \lt13/u2|lt13/u1  (
    .a(\dec_ch1/pb [2:1]),
    .b(adc1B_w[2:1]),
    .clk(clk_200MHz),
    .fci(\lt13/c1 ),
    .mi({adc_d2[2],adc_q2[4]}),
    .fco(\lt13/c3 ),
    .q({adc_dd2[2],adc_d2[4]}));
  AL_PHY_MSLICE \lt13/u4|lt13/u3  (
    .a(\dec_ch1/pb [4:3]),
    .b(adc1B_w[4:3]),
    .clk(clk_200MHz),
    .fci(\lt13/c3 ),
    .mi(adc_d1[4:3]),
    .fco(\lt13/c5 ),
    .q(adc_dd1[4:3]));
  AL_PHY_MSLICE \lt13/u6|lt13/u5  (
    .a(\dec_ch1/pb [6:5]),
    .b(adc1B_w[6:5]),
    .clk(clk_200MHz),
    .fci(\lt13/c5 ),
    .mi({adc_d1[2],adc_q2[3]}),
    .fco(\lt13/c7 ),
    .q({adc_dd1[2],adc_d2[3]}));
  AL_PHY_MSLICE \lt13/ucout|lt13/u7  (
    .a({1'b0,\dec_ch1/pb [7]}),
    .b({1'b1,adc1B_w[7]}),
    .clk(clk_200MHz),
    .fci(\lt13/c7 ),
    .mi(adc_q1[3:2]),
    .f({n301,open_n21435}),
    .q(adc_d1[3:2]));
  AL_PHY_MSLICE \lt14/u0|lt14/ucin  (
    .a({cap_thr_x[0],1'b0}),
    .b({n304[0],open_n21439}),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch2/n70 [2:1]),
    .fco(\lt14/c1 ),
    .q(\dec_ch2/i1 [2:1]));
  AL_PHY_MSLICE \lt14/u2|lt14/u1  (
    .a(cap_thr_x[2:1]),
    .b(n304[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt14/c1 ),
    .mi(\dec_ch2/n70 [6:5]),
    .fco(\lt14/c3 ),
    .q(\dec_ch2/i1 [6:5]));
  AL_PHY_MSLICE \lt14/u4|lt14/u3  (
    .a({cap_thr_x[4],cap_thr[3]}),
    .b(n304[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt14/c3 ),
    .mi(\dec_ch2/n70 [4:3]),
    .fco(\lt14/c5 ),
    .q(\dec_ch2/i1 [4:3]));
  AL_PHY_MSLICE \lt14/u6|lt14/u5  (
    .a(cap_thr_x[6:5]),
    .b(n304[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt14/c5 ),
    .mi({\dec_ch2/n70 [7],\dec_ch2/n70 [13]}),
    .fco(\lt14/c7 ),
    .q({\dec_ch2/i1 [7],\dec_ch2/i1 [13]}));
  AL_PHY_MSLICE \lt14/ucout|lt14/u7  (
    .a({1'b0,cap_thr_x[7]}),
    .b({1'b1,n304[7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt14/c7 ),
    .mi(\dec_ch2/n70 [9:8]),
    .f({n305,open_n21532}),
    .q(\dec_ch2/i1 [9:8]));
  AL_PHY_MSLICE \lt15/u0|lt15/ucin  (
    .a({\dec_ch2/pa [0],1'b0}),
    .b({adc2A_w[0],open_n21536}),
    .ce(\dec_sv[1]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n21551,\dec_ch2/d0 [16]}),
    .fco(\lt15/c1 ),
    .q({open_n21557,\dec_ch2/d0p [16]}));
  AL_PHY_MSLICE \lt15/u2|lt15/u1  (
    .a(\dec_ch2/pa [2:1]),
    .b(adc2A_w[2:1]),
    .ce(dec_sv[1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt15/c1 ),
    .mi({open_n21571,\dec_ch2/d0 [23]}),
    .fco(\lt15/c3 ),
    .q({open_n21577,\dec_ch2/d0p [23]}));
  AL_PHY_MSLICE \lt15/u4|lt15/u3  (
    .a(\dec_ch2/pa [4:3]),
    .b(adc2A_w[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt15/c3 ),
    .mi({adc2A_w[0],\dec_ch2/n70 [43]}),
    .fco(\lt15/c5 ),
    .q({\dec_ch2/pa [0],\dec_ch2/i1 [43]}));
  AL_PHY_MSLICE \lt15/u6|lt15/u5  (
    .a(\dec_ch2/pa [6:5]),
    .b(adc2A_w[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt15/c5 ),
    .mi(adc2A_w[2:1]),
    .fco(\lt15/c7 ),
    .q(\dec_ch2/pa [2:1]));
  AL_PHY_MSLICE \lt15/ucout|lt15/u7  (
    .a({1'b0,\dec_ch2/pa [7]}),
    .b({1'b1,adc2A_w[7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt15/c7 ),
    .mi(adc2A_w[4:3]),
    .f({n312,open_n21631}),
    .q(\dec_ch2/pa [4:3]));
  AL_PHY_MSLICE \lt16/u0|lt16/ucin  (
    .a({cap_thr_x[0],1'b0}),
    .b({n315[0],open_n21635}),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n76 [43],\dec_ch2/n76 [40]}),
    .fco(\lt16/c1 ),
    .q({\dec_ch2/i3 [43],\dec_ch2/i3 [40]}));
  AL_PHY_MSLICE \lt16/u2|lt16/u1  (
    .a(cap_thr_x[2:1]),
    .b(n315[2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt16/c1 ),
    .mi(\dec_ch2/n76 [46:45]),
    .fco(\lt16/c3 ),
    .q(\dec_ch2/i3 [46:45]));
  AL_PHY_MSLICE \lt16/u4|lt16/u3  (
    .a({cap_thr_x[4],cap_thr[3]}),
    .b(n315[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt16/c3 ),
    .mi({open_n21689,\dec_ch2/n76 [47]}),
    .fco(\lt16/c5 ),
    .q({open_n21695,\dec_ch2/i3 [47]}));
  AL_PHY_MSLICE \lt16/u6|lt16/u5  (
    .a(cap_thr_x[6:5]),
    .b(n315[6:5]),
    .fci(\lt16/c5 ),
    .fco(\lt16/c7 ));
  AL_PHY_MSLICE \lt16/ucout|lt16/u7  (
    .a({1'b0,cap_thr_x[7]}),
    .b({1'b1,n315[7]}),
    .ce(mux77_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt16/c7 ),
    .mi(io_mcu_data_pad[6:5]),
    .f({n316,open_n21734}),
    .q(ch1_offset[6:5]));
  AL_PHY_MSLICE \lt17/u0|lt17/ucin  (
    .a({\dec_ch2/pb [0],1'b0}),
    .b({adc2B_w[0],open_n21738}),
    .ce(mux90_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n21753,io_mcu_data_pad[0]}),
    .fco(\lt17/c1 ),
    .q({open_n21759,cap_thr_x[0]}));
  AL_PHY_MSLICE \lt17/u2|lt17/u1  (
    .a(\dec_ch2/pb [2:1]),
    .b(adc2B_w[2:1]),
    .ce(mux90_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt17/c1 ),
    .mi(io_mcu_data_pad[2:1]),
    .fco(\lt17/c3 ),
    .q(cap_thr_x[2:1]));
  AL_PHY_MSLICE \lt17/u4|lt17/u3  (
    .a(\dec_ch2/pb [4:3]),
    .b(adc2B_w[4:3]),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt17/c3 ),
    .mi({open_n21791,trigger_data[7]}),
    .sr(sample_system_reset),
    .fco(\lt17/c5 ),
    .q({open_n21796,trigger_previous[7]}));
  AL_PHY_MSLICE \lt17/u6|lt17/u5  (
    .a(\dec_ch2/pb [6:5]),
    .b(adc2B_w[6:5]),
    .ce(mux90_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt17/c5 ),
    .mi(io_mcu_data_pad[6:5]),
    .fco(\lt17/c7 ),
    .q(cap_thr_x[6:5]));
  AL_PHY_MSLICE \lt17/ucout|lt17/u7  (
    .a({1'b0,\dec_ch2/pb [7]}),
    .b({1'b1,adc2B_w[7]}),
    .ce(mux72_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt17/c7 ),
    .mi({open_n21828,io_mcu_data_pad[1]}),
    .f({n323,open_n21830}),
    .q({open_n21834,sample_rate_divider[1]}));
  AL_PHY_MSLICE \lt18/u0|lt18/ucin  (
    .a({cap_thr_x[0],1'b0}),
    .b({n326[0],open_n21835}),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n21850,io_mcu_data_pad[1]}),
    .fco(\lt18/c1 ),
    .q({open_n21856,\dec_order[1]_hfnopt2_4 }));
  AL_PHY_MSLICE \lt18/u2|lt18/u1  (
    .a(cap_thr_x[2:1]),
    .b(n326[2:1]),
    .fci(\lt18/c1 ),
    .fco(\lt18/c3 ));
  AL_PHY_MSLICE \lt18/u4|lt18/u3  (
    .a({cap_thr_x[4],cap_thr[3]}),
    .b(n326[4:3]),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt18/c3 ),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[0]}),
    .fco(\lt18/c5 ),
    .q({dec_shift[4],dec_shift[0]}));
  AL_PHY_MSLICE \lt18/u6|lt18/u5  (
    .a(cap_thr_x[6:5]),
    .b(n326[6:5]),
    .ce(mux76_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt18/c5 ),
    .mi({open_n21912,io_mcu_data_pad[0]}),
    .fco(\lt18/c7 ),
    .q({open_n21918,trig_holdoff[0]}));
  AL_PHY_MSLICE \lt18/ucout|lt18/u7  (
    .a({1'b0,cap_thr_x[7]}),
    .b({1'b1,n326[7]}),
    .fci(\lt18/c7 ),
    .f({n327,open_n21937}));
  AL_PHY_MSLICE \lt19/u0|lt19/ucin  (
    .a({pretrigger_samples[0],1'b1}),
    .b({sample_write_address[0],open_n21943}),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch2/n82 [43:42]),
    .fco(\lt19/c1 ),
    .q(\dec_ch2/c2 [43:42]));
  AL_PHY_MSLICE \lt19/u10|lt19/u9  (
    .a(pretrigger_samples[10:9]),
    .b(sample_write_address[10:9]),
    .ce(mux71_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt19/c9 ),
    .mi(io_mcu_data_pad[1:0]),
    .fco(\lt19/c11 ),
    .q(total_samples[1:0]));
  AL_PHY_MSLICE \lt19/u12|lt19/u11  (
    .a(pretrigger_samples[12:11]),
    .b(sample_write_address[12:11]),
    .ce(mux70_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt19/c11 ),
    .mi(io_mcu_data_pad[6:5]),
    .fco(\lt19/c13 ),
    .q(pretrigger_samples[6:5]));
  AL_PHY_MSLICE \lt19/u2|lt19/u1  (
    .a(pretrigger_samples[2:1]),
    .b(sample_write_address[2:1]),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt19/c1 ),
    .mi(\dec_ch2/n82 [45:44]),
    .fco(\lt19/c3 ),
    .q(\dec_ch2/c2 [45:44]));
  AL_PHY_MSLICE \lt19/u4|lt19/u3  (
    .a(pretrigger_samples[4:3]),
    .b(sample_write_address[4:3]),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt19/c3 ),
    .mi(\dec_ch2/n82 [47:46]),
    .fco(\lt19/c5 ),
    .q(\dec_ch2/c2 [47:46]));
  AL_PHY_MSLICE \lt19/u6|lt19/u5  (
    .a(pretrigger_samples[6:5]),
    .b(sample_write_address[6:5]),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt19/c5 ),
    .mi({open_n22048,\dec_ch2/n86 [9]}),
    .fco(\lt19/c7 ),
    .q({open_n22054,\dec_ch2/c3 [9]}));
  AL_PHY_MSLICE \lt19/u8|lt19/u7  (
    .a(pretrigger_samples[8:7]),
    .b(sample_write_address[8:7]),
    .ce(mux70_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt19/c7 ),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[1]}),
    .fco(\lt19/c9 ),
    .q({pretrigger_samples[4],pretrigger_samples[1]}));
  AL_PHY_MSLICE \lt19/ucout_al_u2464  (
    .a({open_n22073,1'b0}),
    .b({open_n22074,1'b1}),
    .ce(mux71_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt19/c13 ),
    .mi({open_n22088,io_mcu_data_pad[2]}),
    .f({open_n22090,n346}),
    .q({open_n22094,total_samples[10]}));
  AL_PHY_MSLICE \lt2/u0|lt2/ucin  (
    .a({sample_rate_divider[1],1'b0}),
    .b({dec_pc[0],open_n22095}),
    .ce(mux72_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi(io_mcu_data_pad[3:2]),
    .fco(\lt2/c1 ),
    .q(sample_rate_divider[3:2]));
  AL_PHY_MSLICE \lt2/u10|lt2/u9  (
    .a(sample_rate_divider[11:10]),
    .b(dec_pc[10:9]),
    .ce(mux72_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt2/c9 ),
    .mi({open_n22128,io_mcu_data_pad[2]}),
    .fco(\lt2/c11 ),
    .q({open_n22134,sample_rate_divider[10]}));
  AL_PHY_MSLICE \lt2/u12|lt2/u11  (
    .a(sample_rate_divider[13:12]),
    .b(dec_pc[12:11]),
    .ce(mux101_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt2/c11 ),
    .mi(io_mcu_data_pad[5:4]),
    .fco(\lt2/c13 ),
    .q(pat_wr_n[5:4]));
  AL_PHY_MSLICE \lt2/u14|lt2/u13  (
    .a(sample_rate_divider[15:14]),
    .b(dec_pc[14:13]),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .fci(\lt2/c13 ),
    .mi({open_n22166,pat_wr_n[3]}),
    .fco(\lt2/c15 ),
    .q({open_n22172,\u_sq/sh0 [19]}));
  AL_PHY_MSLICE \lt2/u16|lt2/u15  (
    .a(sample_rate_divider[17:16]),
    .b(dec_pc[16:15]),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .fci(\lt2/c15 ),
    .mi({open_n22186,pat_wr_n[3]}),
    .fco(\lt2/c17 ),
    .q({open_n22192,\u_sq/sh1 [19]}));
  AL_PHY_MSLICE \lt2/u18|lt2/u17  (
    .a(sample_rate_divider[19:18]),
    .b(dec_pc[18:17]),
    .ce(\u_sq/ct_ev ),
    .clk(clk_200MHz),
    .fci(\lt2/c17 ),
    .mi(pat_ctl[1:0]),
    .fco(\lt2/c19 ),
    .q(\u_sq/mode ));
  AL_PHY_MSLICE \lt2/u2|lt2/u1  (
    .a(sample_rate_divider[3:2]),
    .b(dec_pc[2:1]),
    .ce(mux72_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt2/c1 ),
    .mi({open_n22224,io_mcu_data_pad[4]}),
    .fco(\lt2/c3 ),
    .q({open_n22230,sample_rate_divider[4]}));
  AL_PHY_MSLICE \lt2/u4|lt2/u3  (
    .a(sample_rate_divider[5:4]),
    .b(dec_pc[4:3]),
    .fci(\lt2/c3 ),
    .fco(\lt2/c5 ));
  AL_PHY_MSLICE \lt2/u6|lt2/u5  (
    .a(sample_rate_divider[7:6]),
    .b(dec_pc[6:5]),
    .fci(\lt2/c5 ),
    .fco(\lt2/c7 ));
  AL_PHY_MSLICE \lt2/u8|lt2/u7  (
    .a(sample_rate_divider[9:8]),
    .b(dec_pc[8:7]),
    .fci(\lt2/c7 ),
    .fco(\lt2/c9 ));
  AL_PHY_MSLICE \lt2/ucout_al_u2465  (
    .a({open_n22303,1'b0}),
    .b({open_n22304,1'b1}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .fci(\lt2/c19 ),
    .mi({open_n22318,pat_wr_n[7]}),
    .f({open_n22320,n153}),
    .q({open_n22324,\u_sq/sh0 [23]}));
  AL_PHY_MSLICE \lt3/u0|lt3/ucin  (
    .a({trigger_level16[0],1'b1}),
    .b({dec_trig_sample[0],open_n22325}),
    .ce(\dec_sv[0]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n22340,\dec_ch2/pkw [7]}),
    .fco(\lt3/c1 ),
    .q({open_n22346,\dec_ch2/pk0 [7]}));
  AL_PHY_MSLICE \lt3/u10|lt3/u9  (
    .a(trigger_level16[10:9]),
    .b(dec_trig_sample[10:9]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt3/c9 ),
    .mi({open_n22361,\dec_ch2/pa [7]}),
    .fco(\lt3/c11 ),
    .q({open_n22367,pair_l2[7]}));
  AL_PHY_MSLICE \lt3/u12|lt3/u11  (
    .a(trigger_level16[12:11]),
    .b(dec_trig_sample[12:11]),
    .ce(mux82_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt3/c11 ),
    .mi(io_mcu_data_pad[1:0]),
    .fco(\lt3/c13 ),
    .q(trigger_level16[1:0]));
  AL_PHY_MSLICE \lt3/u14|lt3/u13  (
    .a(trigger_level16[14:13]),
    .b(dec_trig_sample[14:13]),
    .ce(mux82_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt3/c13 ),
    .mi(io_mcu_data_pad[3:2]),
    .fco(\lt3/c15 ),
    .q(trigger_level16[3:2]));
  AL_PHY_MSLICE \lt3/u2|lt3/u1  (
    .a(trigger_level16[2:1]),
    .b(dec_trig_sample[2:1]),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt3/c1 ),
    .mi({open_n22417,io_mcu_data_pad[3]}),
    .fco(\lt3/c3 ),
    .q({open_n22423,\dec_shift[3]_hfnopt2_0 }));
  AL_PHY_MSLICE \lt3/u4|lt3/u3  (
    .a(trigger_level16[4:3]),
    .b(dec_trig_sample[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt3/c3 ),
    .mi(\dec_ch2/pa [2:1]),
    .fco(\lt3/c5 ),
    .q(pair_l2[2:1]));
  AL_PHY_MSLICE \lt3/u6|lt3/u5  (
    .a(trigger_level16[6:5]),
    .b(dec_trig_sample[6:5]),
    .ce(\dec_ch2/mux11_b0_sel_is_0_o ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt3/c5 ),
    .mi({\dec_ch2/pdn [7],\dec_ch2/pdn [3]}),
    .fco(\lt3/c7 ),
    .q({\dec_ch2/rmn [7],\dec_ch2/rmn [3]}));
  AL_PHY_MSLICE \lt3/u8|lt3/u7  (
    .a(trigger_level16[8:7]),
    .b(dec_trig_sample[8:7]),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt3/c7 ),
    .mi({open_n22475,\dec_ch2/pa [4]}),
    .fco(\lt3/c9 ),
    .q({open_n22481,pair_l2[4]}));
  AL_PHY_MSLICE \lt3/ucout|lt3/u15  (
    .a({1'b0,trigger_level16[15]}),
    .b({1'b1,dec_trig_sample[15]}),
    .ce(mux82_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt3/c15 ),
    .mi({open_n22495,io_mcu_data_pad[4]}),
    .f({dec_trig_ge,open_n22497}),
    .q({open_n22501,trigger_level16[4]}));
  AL_PHY_MSLICE \lt4/u0|lt4/ucin  (
    .a({time_base_set[0],1'b0}),
    .b({sample_write_address[0],open_n22502}),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch2/c1 [41:40]),
    .fco(\lt4/c1 ),
    .q(\dec_ch2/c1p [41:40]));
  AL_PHY_MSLICE \lt4/u10|lt4/u9  (
    .a(time_base_set[10:9]),
    .b(sample_write_address[10:9]),
    .ce(mux73_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c9 ),
    .mi({open_n22535,io_mcu_data_pad[7]}),
    .fco(\lt4/c11 ),
    .q({open_n22541,time_base_set[7]}));
  AL_PHY_MSLICE \lt4/u12|lt4/u11  (
    .a(time_base_set[12:11]),
    .b(sample_write_address[12:11]),
    .ce(mux73_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c11 ),
    .mi(io_mcu_data_pad[7:6]),
    .fco(\lt4/c13 ),
    .q(time_base_set[15:14]));
  AL_PHY_MSLICE \lt4/u14|lt4/u13  (
    .a(time_base_set[14:13]),
    .b(time_base_cnt[14:13]),
    .ce(mux73_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c13 ),
    .mi(io_mcu_data_pad[5:4]),
    .fco(\lt4/c15 ),
    .q(time_base_set[13:12]));
  AL_PHY_MSLICE \lt4/u16|lt4/u15  (
    .a(time_base_set[16:15]),
    .b(time_base_cnt[16:15]),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c15 ),
    .mi(n217[16:15]),
    .sr(sample_system_reset),
    .fco(\lt4/c17 ),
    .q(time_base_cnt[16:15]));
  AL_PHY_MSLICE \lt4/u18|lt4/u17  (
    .a(time_base_set[18:17]),
    .b(time_base_cnt[18:17]),
    .ce(mux73_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c17 ),
    .mi(io_mcu_data_pad[6:5]),
    .fco(\lt4/c19 ),
    .q(time_base_set[22:21]));
  AL_PHY_MSLICE \lt4/u20|lt4/u19  (
    .a(time_base_set[20:19]),
    .b(time_base_cnt[20:19]),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c19 ),
    .mi(n217[22:21]),
    .sr(sample_system_reset),
    .fco(\lt4/c21 ),
    .q(time_base_cnt[22:21]));
  AL_PHY_MSLICE \lt4/u22|lt4/u21  (
    .a(time_base_set[22:21]),
    .b(time_base_cnt[22:21]),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c21 ),
    .mi(n217[20:19]),
    .sr(sample_system_reset),
    .fco(\lt4/c23 ),
    .q(time_base_cnt[20:19]));
  AL_PHY_MSLICE \lt4/u24|lt4/u23  (
    .a(time_base_set[24:23]),
    .b(time_base_cnt[24:23]),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c23 ),
    .mi(n217[25:24]),
    .sr(sample_system_reset),
    .fco(\lt4/c25 ),
    .q(time_base_cnt[25:24]));
  AL_PHY_MSLICE \lt4/u26|lt4/u25  (
    .a(time_base_set[26:25]),
    .b(time_base_cnt[26:25]),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c25 ),
    .mi({open_n22677,n217[23]}),
    .sr(sample_system_reset),
    .fco(\lt4/c27 ),
    .q({open_n22682,time_base_cnt[23]}));
  AL_PHY_MSLICE \lt4/u28|lt4/u27  (
    .a(time_base_set[28:27]),
    .b(time_base_cnt[28:27]),
    .ce(mux73_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c27 ),
    .mi(io_mcu_data_pad[1:0]),
    .fco(\lt4/c29 ),
    .q(time_base_set[25:24]));
  AL_PHY_MSLICE \lt4/u2|lt4/u1  (
    .a(time_base_set[2:1]),
    .b(sample_write_address[2:1]),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c1 ),
    .mi(\dec_ch2/c1 [45:44]),
    .fco(\lt4/c3 ),
    .q(\dec_ch2/c1p [45:44]));
  AL_PHY_MSLICE \lt4/u30|lt4/u29  (
    .a(time_base_set[30:29]),
    .b(time_base_cnt[30:29]),
    .ce(mux73_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c29 ),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[3]}),
    .fco(\lt4/c31 ),
    .q({time_base_set[29],time_base_set[27]}));
  AL_PHY_MSLICE \lt4/u4|lt4/u3  (
    .a(time_base_set[4:3]),
    .b(sample_write_address[4:3]),
    .fci(\lt4/c3 ),
    .fco(\lt4/c5 ));
  AL_PHY_MSLICE \lt4/u6|lt4/u5  (
    .a(time_base_set[6:5]),
    .b(sample_write_address[6:5]),
    .ce(\dec_sv[2]_hfnopt2_3 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\lt4/c5 ),
    .mi({open_n22774,\dec_ch2/c1 [47]}),
    .fco(\lt4/c7 ),
    .q({open_n22780,\dec_ch2/c1p [47]}));
  AL_PHY_MSLICE \lt4/u8|lt4/u7  (
    .a(time_base_set[8:7]),
    .b(sample_write_address[8:7]),
    .ce(mux73_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c7 ),
    .mi(io_mcu_data_pad[6:5]),
    .fco(\lt4/c9 ),
    .q(time_base_set[6:5]));
  AL_PHY_MSLICE \lt4/ucout|lt4/u31  (
    .a({1'b0,time_base_set[31]}),
    .b({1'b1,time_base_cnt[31]}),
    .ce(mux73_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt4/c31 ),
    .mi({open_n22812,io_mcu_data_pad[7]}),
    .f({time_base_timeout,open_n22814}),
    .q({open_n22818,time_base_set[31]}));
  AL_PHY_MSLICE \lt5/u0|lt5/ucin  (
    .a({post_words[0],1'b1}),
    .b({addr_delta[0],open_n22819}),
    .fco(\lt5/c1 ));
  AL_PHY_MSLICE \lt5/u10|lt5/u9  (
    .a(post_words[10:9]),
    .b(addr_delta[10:9]),
    .fci(\lt5/c9 ),
    .fco(\lt5/c11 ));
  AL_PHY_MSLICE \lt5/u12|lt5/u11  (
    .a(post_words[12:11]),
    .b(addr_delta[12:11]),
    .fci(\lt5/c11 ),
    .fco(\lt5/c13 ));
  AL_PHY_MSLICE \lt5/u2|lt5/u1  (
    .a(post_words[2:1]),
    .b(addr_delta[2:1]),
    .fci(\lt5/c1 ),
    .fco(\lt5/c3 ));
  AL_PHY_MSLICE \lt5/u4|lt5/u3  (
    .a(post_words[4:3]),
    .b(addr_delta[4:3]),
    .fci(\lt5/c3 ),
    .fco(\lt5/c5 ));
  AL_PHY_MSLICE \lt5/u6|lt5/u5  (
    .a(post_words[6:5]),
    .b(addr_delta[6:5]),
    .fci(\lt5/c5 ),
    .fco(\lt5/c7 ));
  AL_PHY_MSLICE \lt5/u8|lt5/u7  (
    .a(post_words[8:7]),
    .b(addr_delta[8:7]),
    .fci(\lt5/c7 ),
    .fco(\lt5/c9 ));
  AL_PHY_MSLICE \lt5/ucout_al_u2466  (
    .a({open_n22989,1'b0}),
    .b({open_n22990,1'b1}),
    .fci(\lt5/c13 ),
    .f({open_n23009,n227}));
  AL_PHY_MSLICE \lt8/u0|lt8/ucin  (
    .a({trigger_data[0],1'b0}),
    .b({hyst_lo[0],open_n23015}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/i3 [47],\dec_ch2/i3 [39]}),
    .fco(\lt8/c1 ),
    .q({\dec_ch2/d0 [47],\dec_ch2/d0 [39]}));
  AL_PHY_MSLICE \lt8/u2|lt8/u1  (
    .a(trigger_data[2:1]),
    .b(hyst_lo[2:1]),
    .ce(mux75_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt8/c1 ),
    .mi({open_n23048,io_mcu_data_pad[4]}),
    .fco(\lt8/c3 ),
    .q({open_n23054,trig_hyst[4]}));
  AL_PHY_MSLICE \lt8/u4|lt8/u3  (
    .a(trigger_data[4:3]),
    .b(hyst_lo[4:3]),
    .ce(mux75_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt8/c3 ),
    .mi(io_mcu_data_pad[7:6]),
    .fco(\lt8/c5 ),
    .q(trig_hyst[7:6]));
  AL_PHY_MSLICE \lt8/u6|lt8/u5  (
    .a(trigger_data[6:5]),
    .b(hyst_lo[6:5]),
    .ce(mux102_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt8/c5 ),
    .mi({open_n23086,io_mcu_data_pad[3]}),
    .fco(\lt8/c7 ),
    .q({open_n23092,pat_wr_f[3]}));
  AL_PHY_MSLICE \lt8/ucout|lt8/u7  (
    .a({1'b0,trigger_data[7]}),
    .b({1'b1,hyst_lo[7]}),
    .ce(mux102_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt8/c7 ),
    .mi(io_mcu_data_pad[4:3]),
    .f({hyst_below,open_n23107}),
    .q(pat_wr_f[12:11]));
  AL_PHY_MSLICE \lt9/u0|lt9/ucin  (
    .a({hyst_hi[0],1'b1}),
    .b({trigger_data[0],open_n23111}),
    .ce(mux79_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi(io_mcu_data_pad[3:2]),
    .fco(\lt9/c1 ),
    .q(display_brigthness[3:2]));
  AL_PHY_MSLICE \lt9/u2|lt9/u1  (
    .a(hyst_hi[2:1]),
    .b(trigger_data[2:1]),
    .ce(mux79_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt9/c1 ),
    .mi({open_n23144,io_mcu_data_pad[0]}),
    .fco(\lt9/c3 ),
    .q({open_n23150,display_brigthness[0]}));
  AL_PHY_MSLICE \lt9/u4|lt9/u3  (
    .a(hyst_hi[4:3]),
    .b(trigger_data[4:3]),
    .ce(mux79_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt9/c3 ),
    .mi({open_n23164,io_mcu_data_pad[2]}),
    .fco(\lt9/c5 ),
    .q({open_n23170,display_brigthness[10]}));
  AL_PHY_MSLICE \lt9/u6|lt9/u5  (
    .a(hyst_hi[6:5]),
    .b(trigger_data[6:5]),
    .ce(mux79_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt9/c5 ),
    .mi({io_mcu_data_pad[0],io_mcu_data_pad[4]}),
    .fco(\lt9/c7 ),
    .q({display_brigthness[8],display_brigthness[12]}));
  AL_PHY_MSLICE \lt9/ucout|lt9/u7  (
    .a({1'b0,hyst_hi[7]}),
    .b({1'b1,trigger_data[7]}),
    .ce(mux102_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\lt9/c7 ),
    .mi(io_mcu_data_pad[2:1]),
    .f({hyst_above,open_n23203}),
    .q(pat_wr_f[2:1]));
  AL_PHY_GCLK \main_clock/bufg_feedback  (
    .clki(\main_clock/clk0_buf ),
    .clko(clk_200MHz));  // al_ip/pll.v(45)
  AL_PHY_PLL \main_clock/pll_inst  (
    .fbclk(clk_200MHz),
    .load_reg(1'b0),
    .phasestep(1'b0),
    .phaseupdown(1'b0),
    .phcntsel(3'b000),
    .pllreset(1'b0),
    .refclk(i_xtal_pad),
    .scanclk(1'b0),
    .stdby(1'b0),
    .clkc({open_n23207,clk_ADCA,clk_ADCB,open_n23208,\main_clock/clk0_buf }));  // al_ip/pll.v(79)
  AL_PHY_MSLICE pat_ctl_t_reg (
    .a({open_n23211,pat_ctl_t}),
    .ce(mux103_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .q({open_n23236,pat_ctl_t}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \pat_wr_lvl_reg|reg85_b0  (
    .a({n687_lutinv,n687_lutinv}),
    .b({_al_u1549_o,_al_u1558_o}),
    .c({_al_u1588_o,sel65_b0_def_0_sel_is_0_o}),
    .ce(mux100_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n515,n515}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[0]}),
    .f({mux101_b0_sel_is_3_o,mux101_b16_sel_is_3_o}),
    .q({pat_wr_lvl,pat_wr_idx[0]}));  // zaklad.v(2867)
  AL_PHY_LSLICE pat_wr_t_reg (
    .a({open_n23255,pat_wr_t}),
    .ce(mux102_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .q({open_n23284,pat_wr_t}));  // zaklad.v(2867)
  // zaklad.v(2317)
  // zaklad.v(2317)
  AL_PHY_LSLICE \q_rs1_reg|q_rs2_reg  (
    .a({_al_u2014_o,_al_u2022_o}),
    .b({_al_u2015_o,\lt21/o_1_lutinv }),
    .c({mcu_command[0],mcu_command[2]}),
    .clk(clk_200MHz),
    .d({mcu_command[1],mcu_command[3]}),
    .e({open_n23286,o_mcu_data[2]}),
    .mi({sample_system_reset,q_rs1}),
    .f({_al_u2016_o,_al_u2023_o}),
    .q({q_rs1,q_rs2}));  // zaklad.v(2317)
  AL_PHY_MSLICE rd_ld_reg (
    .a({open_n23303,rd_rq[1]}),
    .clk(clk_200MHz),
    .d({open_n23309,rd_rq[2]}),
    .f({open_n23323,n181}),
    .q({open_n23327,rd_ld}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1215)
  AL_PHY_LSLICE \reg0_b0|reg26_b0  (
    .a({_al_u2168_o,_al_u2107_o}),
    .b({_al_u2170_o,n841[7]}),
    .c({o_mcu_data[0],_al_u1423_o}),
    .clk(clk_200MHz),
    .d({_al_u1415_o,_al_u1415_o}),
    .e({_al_u1948_o,_al_u1439_o}),
    .mi({o_1khz_calib_pad,p_wa[0]}),
    .f({_al_u2171_o,_al_u2109_o}),
    .q({ext_sync[0],lg_wa[0]}));  // zaklad.v(1742)
  // zaklad.v(277)
  // zaklad.v(1388)
  AL_PHY_LSLICE \reg10_b0|dec_ch1/reg0_b4  (
    .a({open_n23345,n302[6]}),
    .b({n301,n303[6]}),
    .c({n303[5],open_n23346}),
    .clk(sample_write_clock_gclk_net),
    .d({n302[5],n301}),
    .mi({cap_h[0],adc1B_w[4]}),
    .f({n304[5],n304[6]}),
    .q({adc1A_w[0],\dec_ch1/pb [4]}));  // zaklad.v(277)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_MSLICE \reg10_b6|reg10_b7  (
    .b({cic_out1[14],cic_out1[11]}),
    .c({adc1B_w[6],adc1B_w[3]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u745_o,_al_u745_o}),
    .mi({cap_h[6],cap_h[7]}),
    .f({sample_dia[14],sample_dia[11]}),
    .q({adc1A_w[6],adc1A_w[7]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_LSLICE \reg11_b1|reg10_b1  (
    .b({n302[0],n302[7]}),
    .c({n303[0],n303[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({n301,n301}),
    .mi({cap_h[9],cap_h[1]}),
    .f({n304[0],n304[7]}),
    .q({adc1B_w[1],adc1A_w[1]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_LSLICE \reg11_b2|reg11_b3  (
    .b(n302[2:1]),
    .c(n303[2:1]),
    .clk(sample_write_clock_gclk_net),
    .d({n301,n301}),
    .mi({cap_h[10],cap_h[11]}),
    .f(n304[2:1]),
    .q({adc1B_w[2],adc1B_w[3]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_MSLICE \reg12_b0|reg12_b1  (
    .b(n314[6:5]),
    .c(n313[6:5]),
    .clk(sample_write_clock_gclk_net),
    .d({n312,n312}),
    .mi({cap_h[16],cap_h[17]}),
    .f(n315[6:5]),
    .q({adc2A_w[0],adc2A_w[1]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_MSLICE \reg12_b2|reg12_b3  (
    .b(n314[4:3]),
    .c(n313[4:3]),
    .clk(sample_write_clock_gclk_net),
    .d({n312,n312}),
    .mi({cap_h[18],cap_h[19]}),
    .f(n315[4:3]),
    .q({adc2A_w[2],adc2A_w[3]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_MSLICE \reg12_b4|reg12_b7  (
    .c({dec_order[1],dec_order[1]}),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_ch2/i2 [44],\dec_ch2/i2 [46]}),
    .mi({cap_h[20],cap_h[23]}),
    .f({\dec_ch2/n71 [44],\dec_ch2/n71 [46]}),
    .q({adc2A_w[4],adc2A_w[7]}));  // zaklad.v(1388)
  AL_PHY_MSLICE reg13_b0 (
    .c({open_n23482,hyst_hi9[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({open_n23484,hyst_hi9[8]}),
    .mi({open_n23495,cap_h[24]}),
    .f({open_n23497,hyst_hi[0]}),
    .q({open_n23501,adc2B_w[0]}));  // zaklad.v(1388)
  AL_PHY_LSLICE reg13_b1 (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n23514,cap_h[25]}),
    .q({open_n23532,adc2B_w[1]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_MSLICE \reg13_b2|reg13_b3  (
    .clk(sample_write_clock_gclk_net),
    .mi({cap_h[26],cap_h[27]}),
    .q({adc2B_w[2],adc2B_w[3]}));  // zaklad.v(1388)
  // zaklad.v(1388)
  // zaklad.v(1388)
  AL_PHY_MSLICE \reg13_b4|reg13_b5  (
    .clk(sample_write_clock_gclk_net),
    .mi({cap_h[28],cap_h[29]}),
    .q({adc2B_w[4],adc2B_w[5]}));  // zaklad.v(1388)
  AL_PHY_MSLICE reg14_b0 (
    .c({open_n23587,enc_cur}),
    .clk(clk_200MHz),
    .d({open_n23589,adc1_encB}),
    .q({open_n23608,enc_ok[0]}));  // zaklad.v(1511)
  AL_PHY_MSLICE reg14_b1 (
    .c({open_n23613,enc_cur}),
    .clk(clk_200MHz),
    .d({open_n23615,adc1_encA}),
    .q({open_n23634,enc_ok[1]}));  // zaklad.v(1511)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg16_b0|reg16_b1  (
    .b({n155[0],n155[1]}),
    .c({sample_rate_divider[1],sample_rate_divider[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[0],dec_pc[1]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg16_b10|reg16_b9  (
    .b(n155[10:9]),
    .c(sample_rate_divider[11:10]),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q(dec_pc[10:9]));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_MSLICE \reg16_b11|reg16_b12  (
    .b({n155[11],n155[12]}),
    .c({sample_rate_divider[12],sample_rate_divider[13]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[11],dec_pc[12]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_MSLICE \reg16_b13|reg16_b16  (
    .b({n155[13],n155[16]}),
    .c({sample_rate_divider[14],sample_rate_divider[17]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[13],dec_pc[16]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg16_b14|reg16_b18  (
    .b({n155[14],n155[18]}),
    .c({sample_rate_divider[15],sample_rate_divider[19]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[14],dec_pc[18]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg16_b15|reg16_b17  (
    .b({n155[15],n155[17]}),
    .c({sample_rate_divider[16],sample_rate_divider[18]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[15],dec_pc[17]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg16_b2|reg17_b0  (
    .a({open_n23777,_al_u1404_o}),
    .b({n155[2],_al_u1405_o}),
    .c({sample_rate_divider[3],_al_u1406_o}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1407_o}),
    .f({open_n23796,n152}),
    .q({dec_pc[2],dec_sv[0]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_MSLICE \reg16_b3|reg16_b5  (
    .b({n155[3],n155[5]}),
    .c({sample_rate_divider[4],sample_rate_divider[6]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[3],dec_pc[5]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_MSLICE \reg16_b4|reg16_b6  (
    .b({n155[4],n155[6]}),
    .c({sample_rate_divider[5],sample_rate_divider[7]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[4],dec_pc[6]}));  // zaklad.v(1596)
  // zaklad.v(1596)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg16_b7|reg16_b8  (
    .b({n155[7],n155[8]}),
    .c({sample_rate_divider[8],sample_rate_divider[9]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1608_o,_al_u1608_o}),
    .q({dec_pc[7],dec_pc[8]}));  // zaklad.v(1596)
  // zaklad.v(277)
  // zaklad.v(1596)
  AL_PHY_LSLICE \reg17_b1_hfnopt2_0|dec_ch1/reg18_b39  (
    .a({\dec_ch2/n22 [0],open_n23867}),
    .b({\dec_ch2/pl [1],open_n23868}),
    .c({dec_order[0],\dec_order[1]_hfnopt2_3 }),
    .clk(sample_write_clock_gclk_net),
    .d({\dec_order[1]_hfnopt2_3 ,dec_order[0]}),
    .mi({\dec_sv[0]_hfnopt2_3 ,\dec_ch1/n70 [39]}),
    .f({\dec_ch2/t_pl [1],\dec_ch1/k3_lutinv }),
    .q({\dec_sv[1]_hfnopt2_0 ,\dec_ch1/i1 [39]}));  // zaklad.v(277)
  AL_PHY_LSLICE reg17_b1_hfnopt2_1 (
    .c({open_n23892,\dec_ch1/n57 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n23894,n152}),
    .mi({open_n23898,\dec_sv[0]_hfnopt2_2 }),
    .f({open_n23911,\dec_ch1/mux10_b0_sel_is_0_o }),
    .q({open_n23915,\dec_sv[1]_hfnopt2_1 }));  // zaklad.v(1596)
  AL_PHY_LSLICE reg17_b1_hfnopt2_4 (
    .b({open_n23918,cic_out1[2]}),
    .c({open_n23919,adc1A_w[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({open_n23921,_al_u745_o}),
    .mi({open_n23925,\dec_sv[0]_hfnopt2_4 }),
    .f({open_n23938,sample_dia[2]}),
    .q({open_n23942,\dec_sv[1]_hfnopt2_4 }));  // zaklad.v(1596)
  // zaklad.v(277)
  // zaklad.v(1596)
  AL_PHY_MSLICE \reg17_b1|dec_ch2/reg1_b3  (
    .a({cic_out1[13],cic_out1[3]}),
    .b({cic_out1[5],cic_out2[3]}),
    .c({_al_u695_o,peak_en}),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_channel,trigger_channel}),
    .mi({\dec_sv[0]_hfnopt2_4 ,\dec_ch2/pa [3]}),
    .f({dec_trig_sample[13],dec_trig_sample[3]}),
    .q({dec_sv[1],pair_l2[3]}));  // zaklad.v(277)
  AL_PHY_MSLICE reg17_b2_hfnopt2_3 (
    .c({open_n23962,\dec_order[1]_hfnopt2_3 }),
    .clk(sample_write_clock_gclk_net),
    .d({open_n23964,\dec_ch2/c1p [47]}),
    .mi({open_n23975,\dec_sv[1]_hfnopt2_3 }),
    .f({open_n23977,\dec_ch2/n81 [47]}),
    .q({open_n23981,\dec_sv[2]_hfnopt2_3 }));  // zaklad.v(1596)
  AL_PHY_LSLICE reg17_b3_hfnopt2_3 (
    .c({open_n23986,\dec_ch2/c2p [13]}),
    .clk(sample_write_clock_gclk_net),
    .d({open_n23988,\dec_ch1/k3_lutinv }),
    .mi({open_n23992,\dec_sv[2]_hfnopt2_4 }),
    .f({open_n24005,\dec_ch2/n85 [13]}),
    .q({open_n24009,\dec_sv[3]_hfnopt2_3 }));  // zaklad.v(1596)
  AL_PHY_MSLICE reg17_b6 (
    .clk(sample_write_clock_gclk_net),
    .mi({open_n24029,dec_sv[5]}),
    .q({open_n24036,dec_sv[6]}));  // zaklad.v(1596)
  AL_PHY_MSLICE \reg20_b0|add2/ucin  (
    .a({sample_write_address[0],1'b0}),
    .b({1'b1,open_n24037}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .f({n167[0],open_n24054}),
    .fco(\add2/c1 ),
    .q({sample_write_address[0],open_n24057}));
  AL_PHY_MSLICE \reg20_b10|reg20_b9  (
    .a(sample_write_address[10:9]),
    .b(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\add2/c9 ),
    .sr(sample_system_reset),
    .f(n167[10:9]),
    .fco(\add2/c11 ),
    .q(sample_write_address[10:9]));
  AL_PHY_MSLICE \reg20_b12|reg20_b11  (
    .a(sample_write_address[12:11]),
    .b(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\add2/c11 ),
    .sr(sample_system_reset),
    .f(n167[12:11]),
    .q(sample_write_address[12:11]));
  AL_PHY_MSLICE \reg20_b2|reg20_b1  (
    .a(sample_write_address[2:1]),
    .b(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\add2/c1 ),
    .sr(sample_system_reset),
    .f(n167[2:1]),
    .fco(\add2/c3 ),
    .q(sample_write_address[2:1]));
  AL_PHY_MSLICE \reg20_b4|reg20_b3  (
    .a(sample_write_address[4:3]),
    .b(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\add2/c3 ),
    .sr(sample_system_reset),
    .f(n167[4:3]),
    .fco(\add2/c5 ),
    .q(sample_write_address[4:3]));
  AL_PHY_MSLICE \reg20_b6|reg20_b5  (
    .a(sample_write_address[6:5]),
    .b(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\add2/c5 ),
    .sr(sample_system_reset),
    .f(n167[6:5]),
    .fco(\add2/c7 ),
    .q(sample_write_address[6:5]));
  AL_PHY_MSLICE \reg20_b8|reg20_b7  (
    .a(sample_write_address[8:7]),
    .b(2'b00),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .fci(\add2/c7 ),
    .sr(sample_system_reset),
    .f(n167[8:7]),
    .fco(\add2/c9 ),
    .q(sample_write_address[8:7]));
  // zaklad.v(1215)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg21_b0|reg1_b0  (
    .b({mcu_command[6],_al_u1440_o}),
    .c({mcu_command[7],n515}),
    .clk(clk_200MHz),
    .d({_al_u1433_o,_al_u1423_o}),
    .mi({str,ext_sync[1]}),
    .f({_al_u1434_o,u560_sel_is_3_o}),
    .q({str_q[0],ext_hist[0]}));  // zaklad.v(1215)
  // zaklad.v(1215)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg21_b1|ext_level_prev_reg  (
    .a({open_n24178,ext_level_prev}),
    .b({open_n24179,trigger_edge}),
    .c({ext_level,open_n24180}),
    .clk(clk_200MHz),
    .d({ext_level_prev,ext_level}),
    .mi({str_q[0],ext_level}),
    .f({n96,_al_u1457_o}),
    .q({str_q[1],ext_level_prev}));  // zaklad.v(1215)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg22_b2|reg22_b1  (
    .a({_al_u2109_o,_al_u2009_o}),
    .b({_al_u2110_o,_al_u2013_o}),
    .c({_al_u2111_o,_al_u2016_o}),
    .clk(clk_200MHz),
    .d({o_mcu_data[7],_al_u1421_o}),
    .e({open_n24197,_al_u1439_o}),
    .mi(rd_rq[1:0]),
    .f({_al_u2112_o,_al_u2017_o}),
    .q(rd_rq[2:1]));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg23_b1|reg23_b0  (
    .a({ext_activity,_al_u1555_o}),
    .b({mcu_command[1],mcu_state[0]}),
    .c({mcu_state[3],\dec_shift[3]_hfnopt2_2 }),
    .clk(clk_200MHz),
    .d({o_mcu_data[2],o_mcu_data[3]}),
    .mi({lc_rq[0],lc_t}),
    .f({_al_u2015_o,_al_u2051_o}),
    .q(lc_rq[1:0]));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg25_b2|reg25_b0  (
    .c({i_mcu_rws_pad,mcu_state[1]}),
    .ce(n179),
    .clk(clk_200MHz),
    .d({i_mcu_dcs_pad,sel65_b0_def_0_sel_is_0_o}),
    .mi({sample_write_address[2],sample_write_address[0]}),
    .f({n170,_al_u1555_o}),
    .q({p_wa[2],p_wa[0]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg25_b3|reg25_b4  (
    .a({_al_u2062_o,_al_u2021_o}),
    .b({_al_u2069_o,mcu_command[0]}),
    .c({_al_u1969_o,mcu_command[1]}),
    .ce(n179),
    .clk(clk_200MHz),
    .d({_al_u1426_o,mcu_state[3]}),
    .e({o_mcu_data[4],o_mcu_data[2]}),
    .mi({sample_write_address[3],sample_write_address[4]}),
    .f({_al_u2070_o,_al_u2022_o}),
    .q({p_wa[3],p_wa[4]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg25_b6|reg25_b5  (
    .a({open_n24263,_al_u2128_o}),
    .b({open_n24264,_al_u1576_o}),
    .c({mcu_command[3],_al_u1948_o}),
    .ce(n179),
    .clk(clk_200MHz),
    .d({_al_u1968_o,gen_out_enable}),
    .e({open_n24265,o_mcu_data[1]}),
    .mi(sample_write_address[6:5]),
    .f({_al_u1969_o,_al_u2129_o}),
    .q(p_wa[6:5]));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg25_b7|reg25_b9  (
    .a({_al_u2083_o,open_n24282}),
    .b({\mux104_b14/B1_2 ,open_n24283}),
    .c(mcu_state[2:1]),
    .ce(n179),
    .clk(clk_200MHz),
    .d({mcu_state[3],mcu_state[0]}),
    .mi({sample_write_address[7],sample_write_address[9]}),
    .f({_al_u2085_o,_al_u1549_o}),
    .q({p_wa[7],p_wa[9]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg26_b12|reg26_b11  (
    .a({_al_u2134_o,_al_u2173_o}),
    .b({_al_u1549_o,mcu_state[2]}),
    .c({l_wa[9],mcu_state[3]}),
    .clk(clk_200MHz),
    .d({mcu_state[2],o_mcu_data[0]}),
    .mi(p_wa[12:11]),
    .f({_al_u2135_o,_al_u2174_o}),
    .q(lg_wa[12:11]));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg26_b1|reg23_b2  (
    .a({_al_u2049_o,open_n24313}),
    .b({_al_u2052_o,open_n24314}),
    .c({_al_u1415_o,io_mcu_data_pad[1]}),
    .clk(clk_200MHz),
    .d({_al_u1439_o,u560_sel_is_3_o}),
    .mi({p_wa[1],lc_rq[1]}),
    .f({_al_u2053_o,u561_sel_is_3_o}),
    .q({lg_wa[1],lc_rq[2]}));  // zaklad.v(1742)
  AL_PHY_LSLICE reg26_b2 (
    .c({open_n24334,lc_rq[2]}),
    .clk(clk_200MHz),
    .d({open_n24336,lc_rq[1]}),
    .mi({open_n24340,p_wa[2]}),
    .f({open_n24353,n202}),
    .q({open_n24357,lg_wa[2]}));  // zaklad.v(1742)
  AL_PHY_LSLICE reg26_b5 (
    .a({open_n24358,p_wr}),
    .b({open_n24359,rd_ld}),
    .c({open_n24360,str_q[1]}),
    .clk(clk_200MHz),
    .d({open_n24362,occ[13]}),
    .mi({open_n24366,p_wa[5]}),
    .f({open_n24379,n206}),
    .q({open_n24383,lg_wa[5]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg27_b0|reg27_b2  (
    .a({_al_u2088_o,_al_u2179_o}),
    .b({_al_u2089_o,_al_u1968_o}),
    .c({_al_u1969_o,mcu_command[3]}),
    .ce(n181),
    .clk(clk_200MHz),
    .d({o_mcu_data[6],o_mcu_data[0]}),
    .mi({log_rd[0],log_rd[2]}),
    .sr(q_rs2),
    .f({_al_u2090_o,_al_u2180_o}),
    .q({rd_200[0],rd_200[2]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg27_b1|reg27_b3  (
    .a({open_n24397,_al_u2127_o}),
    .b({open_n24398,o_adc1A_d[1]}),
    .c({i_mcu_rws_pad,o_adc1B_d[1]}),
    .ce(n181),
    .clk(clk_200MHz),
    .d({i_mcu_dcs_pad,_al_u1415_o}),
    .e({open_n24399,mcu_command[1]}),
    .mi({log_rd[1],log_rd[3]}),
    .sr(q_rs2),
    .f({n515,_al_u2128_o}),
    .q({rd_200[1],rd_200[3]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg27_b8|reg27_b12  (
    .a({_al_u1959_o,_al_u2138_o}),
    .b({_al_u1965_o,mcu_command[0]}),
    .c({_al_u1967_o,mcu_command[1]}),
    .ce(n181),
    .clk(clk_200MHz),
    .d({_al_u1969_o,mcu_state[3]}),
    .e({o_mcu_data[5],o_mcu_data[1]}),
    .mi({log_rd[8],log_rd[12]}),
    .sr(q_rs2),
    .f({_al_u1970_o,_al_u2139_o}),
    .q({rd_200[8],rd_200[12]}));  // zaklad.v(1742)
  AL_PHY_MSLICE \reg28_b0|add3/ucin  (
    .a({lg_lo[0],1'b0}),
    .b({1'b1,open_n24430}),
    .ce(p_wr),
    .clk(clk_200MHz),
    .sr(n186),
    .fco(\add3/c1 ),
    .q({lg_lo[0],open_n24451}));
  AL_PHY_MSLICE \reg28_b10|reg28_b9  (
    .a(lg_lo[10:9]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c9 ),
    .sr(n186),
    .fco(\add3/c11 ),
    .q(lg_lo[10:9]));
  AL_PHY_MSLICE \reg28_b12|reg28_b11  (
    .a(lg_lo[12:11]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c11 ),
    .sr(n186),
    .fco(\add3/c13 ),
    .q(lg_lo[12:11]));
  AL_PHY_MSLICE \reg28_b14|reg28_b13  (
    .a(lg_lo[14:13]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c13 ),
    .sr(n186),
    .fco(\add3/c15 ),
    .q(lg_lo[14:13]));
  AL_PHY_MSLICE reg28_b15_al_u2457 (
    .a({open_n24509,lg_lo[15]}),
    .b({open_n24510,1'b0}),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c15 ),
    .sr(n186),
    .q({open_n24531,lg_lo[15]}));
  AL_PHY_MSLICE \reg28_b2|reg28_b1  (
    .a(lg_lo[2:1]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c1 ),
    .sr(n186),
    .fco(\add3/c3 ),
    .q(lg_lo[2:1]));
  AL_PHY_MSLICE \reg28_b4|reg28_b3  (
    .a(lg_lo[4:3]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c3 ),
    .sr(n186),
    .fco(\add3/c5 ),
    .q(lg_lo[4:3]));
  AL_PHY_MSLICE \reg28_b6|reg28_b5  (
    .a(lg_lo[6:5]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c5 ),
    .sr(n186),
    .fco(\add3/c7 ),
    .q(lg_lo[6:5]));
  AL_PHY_MSLICE \reg28_b8|reg28_b7  (
    .a(lg_lo[8:7]),
    .b(2'b00),
    .ce(p_wr),
    .clk(clk_200MHz),
    .fci(\add3/c7 ),
    .sr(n186),
    .fco(\add3/c9 ),
    .q(lg_lo[8:7]));
  AL_PHY_MSLICE \reg29_b0|add4/ucin  (
    .a({lg_hi[0],1'b0}),
    .b({1'b1,open_n24608}),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .sr(n186),
    .fco(\add4/c1 ),
    .q({lg_hi[0],open_n24629}));
  AL_PHY_MSLICE \reg29_b10|reg29_b9  (
    .a(lg_hi[10:9]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c9 ),
    .sr(n186),
    .fco(\add4/c11 ),
    .q(lg_hi[10:9]));
  AL_PHY_MSLICE \reg29_b12|reg29_b11  (
    .a(lg_hi[12:11]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c11 ),
    .sr(n186),
    .fco(\add4/c13 ),
    .q(lg_hi[12:11]));
  AL_PHY_MSLICE \reg29_b14|reg29_b13  (
    .a(lg_hi[14:13]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c13 ),
    .sr(n186),
    .fco(\add4/c15 ),
    .q(lg_hi[14:13]));
  AL_PHY_MSLICE reg29_b15_al_u2458 (
    .a({open_n24687,lg_hi[15]}),
    .b({open_n24688,1'b0}),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c15 ),
    .sr(n186),
    .q({open_n24709,lg_hi[15]}));
  AL_PHY_MSLICE \reg29_b2|reg29_b1  (
    .a(lg_hi[2:1]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c1 ),
    .sr(n186),
    .fco(\add4/c3 ),
    .q(lg_hi[2:1]));
  AL_PHY_MSLICE \reg29_b4|reg29_b3  (
    .a(lg_hi[4:3]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c3 ),
    .sr(n186),
    .fco(\add4/c5 ),
    .q(lg_hi[4:3]));
  AL_PHY_MSLICE \reg29_b6|reg29_b5  (
    .a(lg_hi[6:5]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c5 ),
    .sr(n186),
    .fco(\add4/c7 ),
    .q(lg_hi[6:5]));
  AL_PHY_MSLICE \reg29_b8|reg29_b7  (
    .a(lg_hi[8:7]),
    .b(2'b00),
    .ce(mux18_b0_sel_is_3_o),
    .clk(clk_200MHz),
    .fci(\add4/c7 ),
    .sr(n186),
    .fco(\add4/c9 ),
    .q(lg_hi[8:7]));
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg2_b0|reg2_b1  (
    .clk(clk_200MHz),
    .mi({adc_q1[0],adc_q1[1]}),
    .q({adc_d1[0],adc_d1[1]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg2_b10|reg5_b10  (
    .clk(clk_200MHz),
    .mi({adc_q1[10],adc_d2[10]}),
    .q({adc_d1[10],adc_dd2[10]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b11|reg5_b11  (
    .clk(clk_200MHz),
    .mi({adc_q1[11],adc_d2[11]}),
    .q({adc_d1[11],adc_dd2[11]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b12|reg5_b12  (
    .clk(clk_200MHz),
    .mi({adc_q1[12],adc_d2[12]}),
    .q({adc_d1[12],adc_dd2[12]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg2_b13|reg5_b13  (
    .clk(clk_200MHz),
    .mi({adc_q1[13],adc_d2[13]}),
    .q({adc_d1[13],adc_dd2[13]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b14|reg4_b14  (
    .clk(clk_200MHz),
    .mi({adc_q1[14],adc_d1[14]}),
    .q({adc_d1[14],adc_dd1[14]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b15|reg4_b15  (
    .clk(clk_200MHz),
    .mi({adc_q1[15],adc_d1[15]}),
    .q({adc_d1[15],adc_dd1[15]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b16|reg3_b16  (
    .a({open_n24977,_al_u1727_o}),
    .b({ch1_offset[15],ch2_offset[14]}),
    .c({\channel1_dc_offset/count [15],ch2_offset[15]}),
    .clk(clk_200MHz),
    .d({_al_u1711_o,\channel1_dc_offset/count [14]}),
    .e({open_n24979,\channel1_dc_offset/count [15]}),
    .mi({adc_q1[16],adc_q2[16]}),
    .f({_al_u1712_o,_al_u1728_o}),
    .q({adc_d1[16],adc_d2[16]}));  // zaklad.v(1350)
  // zaklad.v(694)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg2_b17|u_sq/reg3_b0  (
    .a({ch1_offset[12],open_n24996}),
    .b({ch1_offset[14],\u_sq/e1f_n [0]}),
    .c({\channel1_dc_offset/count [12],\u_sq/e0f_n [0]}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [14],\u_sq/cur_n_lutinv }),
    .mi({adc_q1[17],open_n25008}),
    .f({_al_u1713_o,open_n25010}),
    .q({adc_d1[17],\u_sq/f_next [0]}));  // zaklad.v(694)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b18|reg4_b19  (
    .a({ch2_offset[10],_al_u1719_o}),
    .b({ch2_offset[9],\channel2_dc_offset/lt0/less_6_11_inst/o_4_lutinv }),
    .c({\channel1_dc_offset/count [10],_al_u1725_o}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [9],ch2_offset[11]}),
    .e({open_n25015,\channel1_dc_offset/count [11]}),
    .mi({adc_q1[18],adc_d1[19]}),
    .f({_al_u1715_o,_al_u1726_o}),
    .q({adc_d1[18],adc_dd1[19]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b19|reg5_b21  (
    .a({open_n25032,_al_u1394_o}),
    .b({ch2_offset[10],_al_u1395_o}),
    .c({\channel1_dc_offset/count [10],_al_u1396_o}),
    .clk(clk_200MHz),
    .d({\channel2_dc_offset/lt0/less_6_11_inst/o_3_lutinv ,_al_u1397_o}),
    .mi({adc_q1[19],adc_d2[21]}),
    .f({\channel2_dc_offset/lt0/less_6_11_inst/o_4_lutinv ,\channel1_dc_offset/n0 }),
    .q({adc_d1[19],adc_dd2[21]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b22|reg2_b21  (
    .a({ch2_offset[0],_al_u1697_o}),
    .b({ch2_offset[1],ch1_offset[2]}),
    .c({\channel1_dc_offset/count [0],ch1_offset[3]}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [1],\channel1_dc_offset/count [2]}),
    .e({open_n25053,\channel1_dc_offset/count [3]}),
    .mi(adc_q1[22:21]),
    .f({_al_u1723_o,\channel1_dc_offset/lt0/o_3_lutinv }),
    .q(adc_d1[22:21]));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b23|reg4_b23  (
    .c(\dec_ch2/i3 [27:26]),
    .clk(clk_200MHz),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({adc_q1[23],adc_d1[23]}),
    .f(\dec_ch2/n74 [27:26]),
    .q({adc_d1[23],adc_dd1[23]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b27|reg5_b27  (
    .clk(clk_200MHz),
    .mi({adc_q1[27],adc_d2[27]}),
    .q({adc_d1[27],adc_dd2[27]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b28|reg5_b28  (
    .clk(clk_200MHz),
    .mi({adc_q1[28],adc_d2[28]}),
    .q({adc_d1[28],adc_dd2[28]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg2_b9|reg5_b9  (
    .clk(clk_200MHz),
    .mi({adc_q1[9],adc_d2[9]}),
    .q({adc_d1[9],adc_dd2[9]}));  // zaklad.v(1350)
  AL_PHY_LSLICE reg30_b0 (
    .a({open_n25180,occ[0]}),
    .b({open_n25181,n196[0]}),
    .c({open_n25182,n192[0]}),
    .clk(clk_200MHz),
    .d({open_n25184,rd_ld}),
    .e({open_n25185,n194}),
    .sr(n186),
    .q({open_n25205,occ[0]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg30_b10|reg30_b9  (
    .a(occ[10:9]),
    .b(n192[10:9]),
    .c({n194,n194}),
    .clk(clk_200MHz),
    .d({rd_ld,rd_ld}),
    .e(n196[10:9]),
    .sr(n186),
    .q(occ[10:9]));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg30_b11|reg30_b12  (
    .a({occ[11],occ[12]}),
    .b({n192[11],n192[12]}),
    .c({n194,n194}),
    .clk(clk_200MHz),
    .d({rd_ld,rd_ld}),
    .e({n196[11],n196[12]}),
    .sr(n186),
    .q({occ[11],occ[12]}));  // zaklad.v(1742)
  AL_PHY_MSLICE reg30_b13_al_u2459 (
    .a({open_n25246,occ[13]}),
    .b({open_n25247,1'b0}),
    .ce(n194),
    .clk(clk_200MHz),
    .fci(\add5/c13 ),
    .sr(mux23_b13_sel_is_0_o),
    .q({open_n25268,occ[13]}));
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg30_b1|reg30_b2  (
    .a({occ[1],n196[2]}),
    .b({n192[1],n192[2]}),
    .c({n194,n194}),
    .clk(clk_200MHz),
    .d({n196[1],rd_ld}),
    .e({rd_ld,occ[2]}),
    .sr(n186),
    .q({occ[1],occ[2]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg30_b3|reg30_b5  (
    .a({occ[3],occ[5]}),
    .b({n192[3],n192[5]}),
    .c({n196[3],n194}),
    .clk(clk_200MHz),
    .d({rd_ld,n196[5]}),
    .e({n194,rd_ld}),
    .sr(n186),
    .q({occ[3],occ[5]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg30_b4|reg30_b6  (
    .a({occ[4],occ[6]}),
    .b({n192[4],n196[6]}),
    .c({n194,n194}),
    .clk(clk_200MHz),
    .d({rd_ld,rd_ld}),
    .e({n196[4],n192[6]}),
    .sr(n186),
    .q({occ[4],occ[6]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg30_b7|reg30_b8  (
    .a({occ[7],occ[8]}),
    .b({n192[7],n192[8]}),
    .c({n194,n194}),
    .clk(clk_200MHz),
    .d({rd_ld,rd_ld}),
    .e({n196[7],n196[8]}),
    .sr(n186),
    .q({occ[7],occ[8]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg31_b10|reg31_b11  (
    .a({_al_u2135_o,_al_u2019_o}),
    .b({_al_u2137_o,_al_u2020_o}),
    .c({mcu_command[1],_al_u1549_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[3],l_wa[10]}),
    .e({open_n25349,mcu_state[2]}),
    .mi({lg_wa[10],lg_wa[11]}),
    .f({_al_u2138_o,_al_u2021_o}),
    .q({l_wa[10],l_wa[11]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg31_b3|reg31_b4  (
    .a({mcu_command[3],o_adc2A_d[4]}),
    .b({mcu_command[2],o_adc2B_d[4]}),
    .c({_al_u2008_o,mcu_command[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({o_mcu_data[2],mcu_command[1]}),
    .mi({lg_wa[3],lg_wa[4]}),
    .f({_al_u2009_o,_al_u2073_o}),
    .q({l_wa[3],l_wa[4]}));  // zaklad.v(1742)
  AL_PHY_MSLICE reg31_b7 (
    .c({open_n25388,l_rq[2]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({open_n25389,l_rq[1]}),
    .mi({open_n25400,lg_wa[7]}),
    .f({open_n25402,l_cp}),
    .q({open_n25406,l_wa[7]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg31_b8|reg31_b5  (
    .a({_al_u1958_o,l_wa[0]}),
    .b({_al_u1576_o,mcu_state[1]}),
    .c({mcu_state[3],_al_u2177_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({o_mcu_data[5],l_wa[8]}),
    .mi({lg_wa[8],lg_wa[5]}),
    .f({_al_u1959_o,_al_u2178_o}),
    .q({l_wa[8],l_wa[5]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b0|reg32_b1  (
    .ce(l_cp),
    .clk(clk_200MHz),
    .mi({lg_lo[0],lg_lo[1]}),
    .q({l_cnt[0],l_cnt[1]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b11|reg32_b12  (
    .ce(l_cp),
    .clk(clk_200MHz),
    .mi({lg_lo[11],lg_lo[12]}),
    .q({l_cnt[11],l_cnt[12]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b13|reg32_b10  (
    .a({l_wa[5],l_cnt[15]}),
    .b({l_cnt[29],l_cnt[7]}),
    .c({mcu_state[0],l_occ[7]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d(mcu_state[1:0]),
    .e({open_n25481,mcu_state[1]}),
    .mi({lg_lo[13],lg_lo[10]}),
    .f({_al_u1957_o,_al_u2115_o}),
    .q({l_cnt[13],l_cnt[10]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg32_b14|reg32_b6  (
    .a({lg_lo[2],lg_lo[0]}),
    .b({lg_lo[3],lg_lo[1]}),
    .c({lg_lo[4],lg_lo[10]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({lg_lo[5],lg_lo[11]}),
    .mi({lg_lo[14],lg_lo[6]}),
    .f({_al_u1002_o,_al_u1000_o}),
    .q({l_cnt[14],l_cnt[6]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b15|reg32_b9  (
    .a({lg_lo[12],l_cnt[23]}),
    .b({lg_lo[13],l_cnt[31]}),
    .c({lg_lo[14],mcu_state[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({lg_lo[15],mcu_state[1]}),
    .mi({lg_lo[15],lg_lo[9]}),
    .f({n8,_al_u2113_o}),
    .q({l_cnt[15],l_cnt[9]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b18|reg32_b19  (
    .a({open_n25530,l_wa[2]}),
    .b({_al_u2060_o,mcu_state[0]}),
    .c({mcu_state[2],l_cnt[26]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({_al_u2058_o,l_cnt[18]}),
    .e({open_n25531,mcu_state[1]}),
    .mi({lg_hi[2],lg_hi[3]}),
    .f({sel63_b4_var_o_lutinv,_al_u2020_o}),
    .q({l_cnt[18],l_cnt[19]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b20|reg32_b22  (
    .a({l_cnt[16],l_wa[1]}),
    .b({l_cnt[24],l_cnt[17]}),
    .c({mcu_state[0],l_cnt[25]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d(mcu_state[1:0]),
    .e({open_n25548,mcu_state[1]}),
    .mi({lg_hi[4],lg_hi[6]}),
    .f({_al_u2177_o,_al_u2134_o}),
    .q({l_cnt[20],l_cnt[22]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b21|reg32_b2  (
    .a(l_wa[12:11]),
    .b(l_wa[4:3]),
    .c({_al_u2057_o,_al_u2041_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({lg_hi[5],lg_lo[2]}),
    .f({_al_u2058_o,_al_u2042_o}),
    .q({l_cnt[21],l_cnt[2]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b23|reg32_b3  (
    .a({l_cnt[10],l_occ[11]}),
    .b({l_cnt[2],l_occ[3]}),
    .c({_al_u2018_o,mcu_state[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({lg_hi[7],lg_lo[3]}),
    .f({_al_u2019_o,_al_u2043_o}),
    .q({l_cnt[23],l_cnt[3]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b24|reg32_b29  (
    .a({open_n25601,l_cnt[12]}),
    .b({open_n25602,l_cnt[4]}),
    .c({p_wr,_al_u2059_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({lo_ones,mcu_state[1]}),
    .mi({lg_hi[8],lg_hi[13]}),
    .f({mux18_b0_sel_is_3_o,_al_u2060_o}),
    .q({l_cnt[24],l_cnt[29]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b26|reg32_b27  (
    .a({l_cnt[11],l_cnt[22]}),
    .b({l_cnt[3],l_cnt[30]}),
    .c({_al_u2043_o,mcu_state[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({lg_hi[10],lg_hi[11]}),
    .f({_al_u2044_o,_al_u2091_o}),
    .q({l_cnt[26],l_cnt[27]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg32_b28|reg32_b31  (
    .a({l_cnt[28],l_cnt[19]}),
    .b({l_cnt[20],l_cnt[27]}),
    .c({mcu_state[0],mcu_state[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({lg_hi[12],lg_hi[15]}),
    .f({_al_u2057_o,_al_u2041_o}),
    .q({l_cnt[28],l_cnt[31]}));  // zaklad.v(1742)
  AL_PHY_LSLICE reg32_b30 (
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({open_n25659,i_mcu_rws_pad}),
    .mi({open_n25663,lg_hi[14]}),
    .f({open_n25676,n477}),
    .q({open_n25680,l_cnt[30]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b4|reg32_b25  (
    .a({l_occ[12],l_cnt[14]}),
    .b({l_occ[4],l_cnt[6]}),
    .c({mcu_state[0],l_occ[6]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d(mcu_state[1:0]),
    .e({open_n25681,mcu_state[1]}),
    .mi({lg_lo[4],lg_hi[9]}),
    .f({_al_u2059_o,_al_u2093_o}),
    .q({l_cnt[4],l_cnt[25]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b5|reg31_b12  (
    .a({l_occ[13],_al_u1956_o}),
    .b({l_occ[5],_al_u1957_o}),
    .c({mcu_state[0],_al_u671_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],l_cnt[21]}),
    .e({open_n25698,mcu_state[2]}),
    .mi({lg_lo[5],lg_wa[12]}),
    .f({_al_u1955_o,_al_u1958_o}),
    .q({l_cnt[5],l_wa[12]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg32_b7|reg32_b8  (
    .a({lg_lo[6],l_cnt[13]}),
    .b({lg_lo[7],l_cnt[5]}),
    .c({lg_lo[8],_al_u1955_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({lg_lo[9],mcu_state[1]}),
    .mi({lg_lo[7],lg_lo[8]}),
    .f({_al_u1001_o,_al_u1956_o}),
    .q({l_cnt[7],l_cnt[8]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg33_b0|reg31_b0  (
    .a({_al_u2040_o,open_n25733}),
    .b({_al_u2046_o,open_n25734}),
    .c({_al_u1433_o,mcu_command[2]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_command[3],mcu_command[1]}),
    .mi({occ[0],lg_wa[0]}),
    .f({_al_u2047_o,_al_u1968_o}),
    .q({l_occ[0],l_wa[0]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg33_b11|reg33_b12  (
    .a({l_cnt[0],_al_u2136_o}),
    .b({l_cnt[8],l_cnt[1]}),
    .c({_al_u2172_o,l_cnt[9]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .e({open_n25749,mcu_state[2]}),
    .mi({occ[11],occ[12]}),
    .f({_al_u2173_o,_al_u2137_o}),
    .q({l_occ[11],l_occ[12]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg33_b1|reg33_b2  (
    .a({_al_u2090_o,_al_u1946_o}),
    .b({_al_u2094_o,_al_u1947_o}),
    .c({_al_u1576_o,_al_u1948_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({_al_u1433_o,_al_u1439_o}),
    .e({open_n25766,o_mcu_data[5]}),
    .mi({occ[1],occ[2]}),
    .f({_al_u2095_o,_al_u1949_o}),
    .q({l_occ[1],l_occ[2]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg33_b3|reg33_b6  (
    .a({_al_u2045_o,o_adc1A_d[2]}),
    .b({_al_u1968_o,o_adc1B_d[2]}),
    .c({mcu_command[0],_al_u2007_o}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({o_mcu_data[3],mcu_command[1]}),
    .mi({occ[3],occ[6]}),
    .f({_al_u2046_o,_al_u2008_o}),
    .q({l_occ[3],l_occ[6]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_LSLICE \reg33_b7|reg33_b13  (
    .c({occ[13],rd_ld}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({p_wr,n186}),
    .mi({occ[7],occ[13]}),
    .f({n194,mux23_b13_sel_is_0_o}),
    .q({l_occ[7],l_occ[13]}));  // zaklad.v(1742)
  // zaklad.v(1742)
  // zaklad.v(1742)
  AL_PHY_MSLICE \reg33_b8|reg33_b10  (
    .a({l_occ[8],l_occ[1]}),
    .b({l_occ[0],l_occ[9]}),
    .c({mcu_state[0],mcu_state[0]}),
    .ce(l_cp),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({occ[8],occ[10]}),
    .f({_al_u2172_o,_al_u2136_o}),
    .q({l_occ[8],l_occ[10]}));  // zaklad.v(1742)
  // zaklad.v(1907)
  // zaklad.v(1907)
  AL_PHY_LSLICE \reg36_b0|reg36_b1  (
    .a({dec_trig_ge,dec_trig_ge}),
    .b({_al_u745_o,_al_u745_o}),
    .c({adc1A_w[0],adc1A_w[1]}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({adc2A_w[0],adc2A_w[1]}),
    .e({trigger_channel,trigger_channel}),
    .sr(sample_system_reset),
    .q({trigger_data[0],trigger_data[1]}));  // zaklad.v(1907)
  // zaklad.v(1907)
  // zaklad.v(1907)
  AL_PHY_LSLICE \reg36_b2|reg36_b3  (
    .a({dec_trig_ge,dec_trig_ge}),
    .b({_al_u745_o,_al_u745_o}),
    .c({adc1A_w[2],adc1A_w[3]}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({adc2A_w[2],adc2A_w[3]}),
    .e({trigger_channel,trigger_channel}),
    .sr(sample_system_reset),
    .q({trigger_data[2],trigger_data[3]}));  // zaklad.v(1907)
  // zaklad.v(1907)
  // zaklad.v(1907)
  AL_PHY_LSLICE \reg36_b4|reg36_b6  (
    .a({dec_trig_ge,dec_trig_ge}),
    .b({_al_u745_o,_al_u745_o}),
    .c({adc1A_w[4],adc1A_w[6]}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({adc2A_w[4],adc2A_w[6]}),
    .e({trigger_channel,trigger_channel}),
    .sr(sample_system_reset),
    .q({trigger_data[4],trigger_data[6]}));  // zaklad.v(1907)
  // zaklad.v(1907)
  // zaklad.v(1907)
  AL_PHY_LSLICE \reg36_b5|reg36_b7  (
    .a({dec_trig_ge,dec_trig_ge}),
    .b({_al_u745_o,_al_u745_o}),
    .c({adc1A_w[5],adc1A_w[7]}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .d({adc2A_w[5],adc2A_w[7]}),
    .e({trigger_channel,trigger_channel}),
    .sr(sample_system_reset),
    .q({trigger_data[5],trigger_data[7]}));  // zaklad.v(1907)
  AL_PHY_MSLICE reg3_b0 (
    .clk(clk_200MHz),
    .mi({open_n25928,adc_q2[0]}),
    .q({open_n25935,adc_d2[0]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg3_b10|reg3_b9  (
    .clk(clk_200MHz),
    .mi(adc_q2[10:9]),
    .q(adc_d2[10:9]));  // zaklad.v(1350)
  AL_PHY_MSLICE reg3_b11 (
    .clk(clk_200MHz),
    .mi({open_n25980,adc_q2[11]}),
    .q({open_n25987,adc_d2[11]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg3_b12|reg4_b13  (
    .clk(clk_200MHz),
    .mi({adc_q2[12],adc_d1[13]}),
    .q({adc_d2[12],adc_dd1[13]}));  // zaklad.v(1350)
  AL_PHY_LSLICE reg3_b13 (
    .clk(clk_200MHz),
    .mi({open_n26025,adc_q2[13]}),
    .q({open_n26043,adc_d2[13]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg3_b14|reg3_b15  (
    .clk(clk_200MHz),
    .mi({adc_q2[14],adc_q2[15]}),
    .q({adc_d2[14],adc_d2[15]}));  // zaklad.v(1350)
  AL_PHY_MSLICE reg3_b17 (
    .clk(clk_200MHz),
    .mi({open_n26092,adc_q2[17]}),
    .q({open_n26099,adc_d2[17]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg3_b18|reg3_b19  (
    .clk(clk_200MHz),
    .mi({adc_q2[18],adc_q2[19]}),
    .q({adc_d2[18],adc_d2[19]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg3_b1|reg3_b2  (
    .clk(clk_200MHz),
    .mi({adc_q2[1],adc_q2[2]}),
    .q({adc_d2[1],adc_d2[2]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg3_b20|reg3_b21  (
    .clk(clk_200MHz),
    .mi({adc_q2[20],adc_q2[21]}),
    .q({adc_d2[20],adc_d2[21]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg3_b22|reg3_b23  (
    .clk(clk_200MHz),
    .mi({adc_q2[22],adc_q2[23]}),
    .q({adc_d2[22],adc_d2[23]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg3_b26|reg2_b26  (
    .clk(clk_200MHz),
    .mi({adc_q2[26],adc_q1[26]}),
    .q({adc_d2[26],adc_d1[26]}));  // zaklad.v(1350)
  AL_PHY_MSLICE reg3_b27 (
    .clk(clk_200MHz),
    .mi({open_n26256,adc_q2[27]}),
    .q({open_n26263,adc_d2[27]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg3_b28|reg3_b29  (
    .clk(clk_200MHz),
    .mi({adc_q2[28],adc_q2[29]}),
    .q({adc_d2[28],adc_d2[29]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg3_b30|reg5_b31  (
    .clk(clk_200MHz),
    .mi({adc_q2[30],adc_d2[31]}),
    .q({adc_d2[30],adc_dd2[31]}));  // zaklad.v(1350)
  AL_PHY_LSLICE reg3_b31 (
    .clk(clk_200MHz),
    .mi({open_n26330,adc_q2[31]}),
    .q({open_n26348,adc_d2[31]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg3_b8|reg2_b8  (
    .clk(clk_200MHz),
    .mi({adc_q2[8],adc_q1[8]}),
    .q({adc_d2[8],adc_d1[8]}));  // zaklad.v(1350)
  AL_PHY_MSLICE \reg41_b0|add8/ucin  (
    .a({oc_1A[0],1'b0}),
    .b({1'b1,open_n26378}),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .fco(\add8/c1 ),
    .q({oc_1A[0],open_n26399}));
  AL_PHY_MSLICE \reg41_b10|reg41_b9  (
    .a(oc_1A[10:9]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c9 ),
    .sr(sample_system_reset),
    .fco(\add8/c11 ),
    .q(oc_1A[10:9]));
  AL_PHY_MSLICE \reg41_b12|reg41_b11  (
    .a(oc_1A[12:11]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c11 ),
    .sr(sample_system_reset),
    .fco(\add8/c13 ),
    .q(oc_1A[12:11]));
  AL_PHY_MSLICE \reg41_b14|reg41_b13  (
    .a(oc_1A[14:13]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c13 ),
    .sr(sample_system_reset),
    .fco(\add8/c15 ),
    .q(oc_1A[14:13]));
  AL_PHY_MSLICE reg41_b15_al_u2460 (
    .a({open_n26457,oc_1A[15]}),
    .b({open_n26458,1'b0}),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c15 ),
    .sr(sample_system_reset),
    .q({open_n26479,oc_1A[15]}));
  AL_PHY_MSLICE \reg41_b2|reg41_b1  (
    .a(oc_1A[2:1]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c1 ),
    .sr(sample_system_reset),
    .fco(\add8/c3 ),
    .q(oc_1A[2:1]));
  AL_PHY_MSLICE \reg41_b4|reg41_b3  (
    .a(oc_1A[4:3]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c3 ),
    .sr(sample_system_reset),
    .fco(\add8/c5 ),
    .q(oc_1A[4:3]));
  AL_PHY_MSLICE \reg41_b6|reg41_b5  (
    .a(oc_1A[6:5]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c5 ),
    .sr(sample_system_reset),
    .fco(\add8/c7 ),
    .q(oc_1A[6:5]));
  AL_PHY_MSLICE \reg41_b8|reg41_b7  (
    .a(oc_1A[8:7]),
    .b(2'b00),
    .ce(mux47_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add8/c7 ),
    .sr(sample_system_reset),
    .fco(\add8/c9 ),
    .q(oc_1A[8:7]));
  AL_PHY_MSLICE \reg42_b0|add9/ucin  (
    .a({oc_1B[0],1'b0}),
    .b({1'b1,open_n26556}),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .fco(\add9/c1 ),
    .q({oc_1B[0],open_n26577}));
  AL_PHY_MSLICE \reg42_b10|reg42_b9  (
    .a(oc_1B[10:9]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c9 ),
    .sr(sample_system_reset),
    .fco(\add9/c11 ),
    .q(oc_1B[10:9]));
  AL_PHY_MSLICE \reg42_b12|reg42_b11  (
    .a(oc_1B[12:11]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c11 ),
    .sr(sample_system_reset),
    .fco(\add9/c13 ),
    .q(oc_1B[12:11]));
  AL_PHY_MSLICE \reg42_b14|reg42_b13  (
    .a(oc_1B[14:13]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c13 ),
    .sr(sample_system_reset),
    .fco(\add9/c15 ),
    .q(oc_1B[14:13]));
  AL_PHY_MSLICE reg42_b15_al_u2461 (
    .a({open_n26635,oc_1B[15]}),
    .b({open_n26636,1'b0}),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c15 ),
    .sr(sample_system_reset),
    .q({open_n26657,oc_1B[15]}));
  AL_PHY_MSLICE \reg42_b2|reg42_b1  (
    .a(oc_1B[2:1]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c1 ),
    .sr(sample_system_reset),
    .fco(\add9/c3 ),
    .q(oc_1B[2:1]));
  AL_PHY_MSLICE \reg42_b4|reg42_b3  (
    .a(oc_1B[4:3]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c3 ),
    .sr(sample_system_reset),
    .fco(\add9/c5 ),
    .q(oc_1B[4:3]));
  AL_PHY_MSLICE \reg42_b6|reg42_b5  (
    .a(oc_1B[6:5]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c5 ),
    .sr(sample_system_reset),
    .fco(\add9/c7 ),
    .q(oc_1B[6:5]));
  AL_PHY_MSLICE \reg42_b8|reg42_b7  (
    .a(oc_1B[8:7]),
    .b(2'b00),
    .ce(mux48_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add9/c7 ),
    .sr(sample_system_reset),
    .fco(\add9/c9 ),
    .q(oc_1B[8:7]));
  AL_PHY_MSLICE \reg43_b0|add10/ucin  (
    .a({oc_2A[0],1'b0}),
    .b({1'b1,open_n26734}),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .fco(\add10/c1 ),
    .q({oc_2A[0],open_n26755}));
  AL_PHY_MSLICE \reg43_b10|reg43_b9  (
    .a(oc_2A[10:9]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c9 ),
    .sr(sample_system_reset),
    .fco(\add10/c11 ),
    .q(oc_2A[10:9]));
  AL_PHY_MSLICE \reg43_b12|reg43_b11  (
    .a(oc_2A[12:11]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c11 ),
    .sr(sample_system_reset),
    .fco(\add10/c13 ),
    .q(oc_2A[12:11]));
  AL_PHY_MSLICE \reg43_b14|reg43_b13  (
    .a(oc_2A[14:13]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c13 ),
    .sr(sample_system_reset),
    .fco(\add10/c15 ),
    .q(oc_2A[14:13]));
  AL_PHY_MSLICE reg43_b15_al_u2455 (
    .a({open_n26813,oc_2A[15]}),
    .b({open_n26814,1'b0}),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c15 ),
    .sr(sample_system_reset),
    .q({open_n26835,oc_2A[15]}));
  AL_PHY_MSLICE \reg43_b2|reg43_b1  (
    .a(oc_2A[2:1]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c1 ),
    .sr(sample_system_reset),
    .fco(\add10/c3 ),
    .q(oc_2A[2:1]));
  AL_PHY_MSLICE \reg43_b4|reg43_b3  (
    .a(oc_2A[4:3]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c3 ),
    .sr(sample_system_reset),
    .fco(\add10/c5 ),
    .q(oc_2A[4:3]));
  AL_PHY_MSLICE \reg43_b6|reg43_b5  (
    .a(oc_2A[6:5]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c5 ),
    .sr(sample_system_reset),
    .fco(\add10/c7 ),
    .q(oc_2A[6:5]));
  AL_PHY_MSLICE \reg43_b8|reg43_b7  (
    .a(oc_2A[8:7]),
    .b(2'b00),
    .ce(mux49_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add10/c7 ),
    .sr(sample_system_reset),
    .fco(\add10/c9 ),
    .q(oc_2A[8:7]));
  AL_PHY_MSLICE \reg44_b0|add11/ucin  (
    .a({oc_2B[0],1'b0}),
    .b({1'b1,open_n26912}),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .fco(\add11/c1 ),
    .q({oc_2B[0],open_n26933}));
  AL_PHY_MSLICE \reg44_b10|reg44_b9  (
    .a(oc_2B[10:9]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c9 ),
    .sr(sample_system_reset),
    .fco(\add11/c11 ),
    .q(oc_2B[10:9]));
  AL_PHY_MSLICE \reg44_b12|reg44_b11  (
    .a(oc_2B[12:11]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c11 ),
    .sr(sample_system_reset),
    .fco(\add11/c13 ),
    .q(oc_2B[12:11]));
  AL_PHY_MSLICE \reg44_b14|reg44_b13  (
    .a(oc_2B[14:13]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c13 ),
    .sr(sample_system_reset),
    .fco(\add11/c15 ),
    .q(oc_2B[14:13]));
  AL_PHY_MSLICE reg44_b15_al_u2456 (
    .a({open_n26991,oc_2B[15]}),
    .b({open_n26992,1'b0}),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c15 ),
    .sr(sample_system_reset),
    .q({open_n27013,oc_2B[15]}));
  AL_PHY_MSLICE \reg44_b2|reg44_b1  (
    .a(oc_2B[2:1]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c1 ),
    .sr(sample_system_reset),
    .fco(\add11/c3 ),
    .q(oc_2B[2:1]));
  AL_PHY_MSLICE \reg44_b4|reg44_b3  (
    .a(oc_2B[4:3]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c3 ),
    .sr(sample_system_reset),
    .fco(\add11/c5 ),
    .q(oc_2B[4:3]));
  AL_PHY_MSLICE \reg44_b6|reg44_b5  (
    .a(oc_2B[6:5]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c5 ),
    .sr(sample_system_reset),
    .fco(\add11/c7 ),
    .q(oc_2B[6:5]));
  AL_PHY_MSLICE \reg44_b8|reg44_b7  (
    .a(oc_2B[8:7]),
    .b(2'b00),
    .ce(mux50_b0_sel_is_3_o),
    .clk(sample_write_clock_gclk_net),
    .fci(\add11/c7 ),
    .sr(sample_system_reset),
    .fco(\add11/c9 ),
    .q(oc_2B[8:7]));
  // zaklad.v(2043)
  // zaklad.v(2043)
  AL_PHY_LSLICE \reg45_b1|reg45_b0  (
    .a({n687_lutinv,_al_u1370_o}),
    .b({_al_u1596_o,sample_write_enable}),
    .c({_al_u2213_o,sampling_half_way}),
    .ce(sample_write_enable),
    .clk(sample_write_clock_gclk_net),
    .d({n651_lutinv,str_q[1]}),
    .e({mcu_command[0],sampling_triggered}),
    .mi({oc_v[0],1'b1}),
    .sr(sample_system_reset),
    .f({_al_u2214_o,trigger_check_enable}),
    .q(oc_v));  // zaklad.v(2043)
  // zaklad.v(2075)
  // zaklad.v(2075)
  AL_PHY_LSLICE \reg46_b10|reg46_b9  (
    .a(trigger_read_address[10:9]),
    .b(n360[10:9]),
    .c({_al_u1975_o,_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({n358,n358}),
    .e(pretrigger_samples[10:9]),
    .q(trigger_read_address[10:9]));  // zaklad.v(2075)
  // zaklad.v(2075)
  // zaklad.v(2075)
  AL_PHY_LSLICE \reg46_b11|reg46_b12  (
    .a({trigger_read_address[11],trigger_read_address[12]}),
    .b({n360[11],n360[12]}),
    .c({_al_u1975_o,_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({n358,n358}),
    .e({pretrigger_samples[11],pretrigger_samples[12]}),
    .q({trigger_read_address[11],trigger_read_address[12]}));  // zaklad.v(2075)
  // zaklad.v(2075)
  // zaklad.v(2075)
  AL_PHY_LSLICE \reg46_b1|reg46_b4  (
    .a({trigger_read_address[1],trigger_read_address[4]}),
    .b({n360[1],n360[4]}),
    .c({_al_u1975_o,_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({n358,n358}),
    .e({pretrigger_samples[1],pretrigger_samples[4]}),
    .q({trigger_read_address[1],trigger_read_address[4]}));  // zaklad.v(2075)
  // zaklad.v(2075)
  // zaklad.v(2075)
  AL_PHY_LSLICE \reg46_b2|reg46_b3  (
    .a({trigger_read_address[2],trigger_read_address[3]}),
    .b({n360[2],n360[3]}),
    .c({_al_u1975_o,_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({n358,n358}),
    .e({pretrigger_samples[2],pretrigger_samples[3]}),
    .q({trigger_read_address[2],trigger_read_address[3]}));  // zaklad.v(2075)
  // zaklad.v(2075)
  // zaklad.v(2075)
  AL_PHY_LSLICE \reg46_b5|reg46_b6  (
    .a({trigger_read_address[5],trigger_read_address[6]}),
    .b({n360[5],n360[6]}),
    .c({_al_u1975_o,_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({n358,n358}),
    .e({pretrigger_samples[5],pretrigger_samples[6]}),
    .q({trigger_read_address[5],trigger_read_address[6]}));  // zaklad.v(2075)
  // zaklad.v(2075)
  // zaklad.v(2075)
  AL_PHY_LSLICE \reg46_b7|reg46_b8  (
    .a({trigger_read_address[7],trigger_read_address[8]}),
    .b({n360[7],n360[8]}),
    .c({_al_u1975_o,_al_u1975_o}),
    .clk(sample_write_clock_gclk_net),
    .d({n358,n358}),
    .e({pretrigger_samples[7],pretrigger_samples[8]}),
    .q({trigger_read_address[7],trigger_read_address[8]}));  // zaklad.v(2075)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b10|reg48_b7  (
    .a({n369[10],n369[7]}),
    .b({n4[9],n4[6]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[10],ho_cnt[7]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b11|reg48_b12  (
    .a({n369[11],n369[12]}),
    .b({n4[10],n4[11]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[11],ho_cnt[12]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b13|reg48_b14  (
    .a({n369[13],n369[14]}),
    .b({n4[12],n4[13]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[13],ho_cnt[14]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b15|reg48_b16  (
    .a({n4[14],n369[16]}),
    .b({n369[15],n4[15]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[15],ho_cnt[16]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b17|reg48_b18  (
    .a({sampling_triggered,n369[18]}),
    .b({n4[16],n4[17]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({n369[17],sampling_triggered}),
    .q({ho_cnt[17],ho_cnt[18]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b19|reg48_b20  (
    .a({n369[19],n369[20]}),
    .b({n4[18],n4[19]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[19],ho_cnt[20]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b21|reg48_b22  (
    .a({n369[21],n369[22]}),
    .b({n4[20],n4[21]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[21],ho_cnt[22]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b23|reg48_b24  (
    .a({n369[23],n369[24]}),
    .b({n4[22],n4[23]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[23],ho_cnt[24]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b25|reg48_b26  (
    .a({n369[25],n369[26]}),
    .b({n4[24],n4[25]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[25],ho_cnt[26]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b27|reg48_b28  (
    .a({n369[27],n369[28]}),
    .b({n4[26],n4[27]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[27],ho_cnt[28]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b29|reg48_b30  (
    .a({n369[29],n369[30]}),
    .b({n4[28],n4[29]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[29],ho_cnt[30]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b2|reg48_b0  (
    .a({n369[2],n369[0]}),
    .b({n4[1],ho_st_q}),
    .c({ho_st_q,trig_holdoff[0]}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[2],ho_cnt[0]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b31|reg48_b32  (
    .a({n369[31],n369[32]}),
    .b({n4[30],n4[31]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[31],ho_cnt[32]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b3|reg48_b4  (
    .a({n369[3],n369[4]}),
    .b({n4[2],n4[3]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[3],ho_cnt[4]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_MSLICE \reg48_b5|reg48_b6  (
    .a({n369[5],n369[6]}),
    .b({n4[4],n4[5]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[5],ho_cnt[6]}));  // zaklad.v(2102)
  // zaklad.v(2102)
  // zaklad.v(2102)
  AL_PHY_LSLICE \reg48_b8|reg48_b9  (
    .a({n369[8],n369[9]}),
    .b({n4[7],n4[8]}),
    .c({ho_st_q,ho_st_q}),
    .ce(n365),
    .clk(clk_200MHz),
    .d({sampling_triggered,sampling_triggered}),
    .q({ho_cnt[8],ho_cnt[9]}));  // zaklad.v(2102)
  // zaklad.v(2145)
  // zaklad.v(2145)
  AL_PHY_MSLICE \reg49_b10|reg49_b9  (
    .a(n396[10:9]),
    .b({time_base_timeout,time_base_timeout}),
    .c(trigger_read_address[10:9]),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_mode_s,trigger_mode_s}),
    .sr(sample_system_reset),
    .q(trigger_address[10:9]));  // zaklad.v(2145)
  // zaklad.v(2145)
  // zaklad.v(2145)
  AL_PHY_LSLICE \reg49_b11|reg49_b12  (
    .a({n396[11],n396[12]}),
    .b({time_base_timeout,time_base_timeout}),
    .c({trigger_read_address[11],trigger_read_address[12]}),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_mode_s,trigger_mode_s}),
    .sr(sample_system_reset),
    .q({trigger_address[11],trigger_address[12]}));  // zaklad.v(2145)
  // zaklad.v(2145)
  // zaklad.v(2145)
  AL_PHY_MSLICE \reg49_b1|reg49_b3  (
    .a({time_base_timeout,n396[3]}),
    .b({n396[1],time_base_timeout}),
    .c({trigger_read_address[1],trigger_read_address[3]}),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_mode_s,trigger_mode_s}),
    .sr(sample_system_reset),
    .q({trigger_address[1],trigger_address[3]}));  // zaklad.v(2145)
  // zaklad.v(2145)
  // zaklad.v(2145)
  AL_PHY_MSLICE \reg49_b2|reg49_b4  (
    .a({n396[2],n396[4]}),
    .b({time_base_timeout,time_base_timeout}),
    .c({trigger_read_address[2],trigger_read_address[4]}),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_mode_s,trigger_mode_s}),
    .sr(sample_system_reset),
    .q({trigger_address[2],trigger_address[4]}));  // zaklad.v(2145)
  // zaklad.v(2145)
  // zaklad.v(2145)
  AL_PHY_LSLICE \reg49_b5|reg49_b6  (
    .a({n396[5],n396[6]}),
    .b({time_base_timeout,time_base_timeout}),
    .c({trigger_read_address[5],trigger_read_address[6]}),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_mode_s,trigger_mode_s}),
    .sr(sample_system_reset),
    .q({trigger_address[5],trigger_address[6]}));  // zaklad.v(2145)
  // zaklad.v(2145)
  // zaklad.v(2145)
  AL_PHY_LSLICE \reg49_b7|reg49_b8  (
    .a({n396[7],n396[8]}),
    .b({time_base_timeout,time_base_timeout}),
    .c({trigger_read_address[7],trigger_read_address[8]}),
    .ce(n379),
    .clk(sample_write_clock_gclk_net),
    .d({trigger_mode_s,trigger_mode_s}),
    .sr(sample_system_reset),
    .q({trigger_address[7],trigger_address[8]}));  // zaklad.v(2145)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg4_b10|reg4_b9  (
    .clk(clk_200MHz),
    .mi(adc_d1[10:9]),
    .q(adc_dd1[10:9]));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg4_b11|reg4_b12  (
    .clk(clk_200MHz),
    .mi({adc_d1[11],adc_d1[12]}),
    .q({adc_dd1[11],adc_dd1[12]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg4_b21|reg6_b21  (
    .a({ch1_offset[0],_al_u1723_o}),
    .b({ch1_offset[1],ch2_offset[2]}),
    .c({\channel1_dc_offset/count [0],ch2_offset[3]}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [1],\channel1_dc_offset/count [3]}),
    .e({open_n27720,\channel1_dc_offset/count [2]}),
    .mi({adc_d1[21],adc_dd1[21]}),
    .f({_al_u1697_o,\channel2_dc_offset/lt0/o_3_lutinv }),
    .q({adc_dd1[21],adc_e1[21]}));  // zaklad.v(1350)
  // zaklad.v(2774)
  // zaklad.v(2774)
  AL_PHY_LSLICE \reg50_b2|reg50_b1  (
    .a({_al_u2117_o,_al_u1555_o}),
    .b({_al_u1421_o,sample_system_state}),
    .c(mcu_command[1:0]),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({o_mcu_data[7],mcu_command[1]}),
    .e({open_n27738,o_mcu_data[0]}),
    .mi(sample_read_offset[2:1]),
    .f({_al_u2118_o,\sel66_b0_var/B1_1 }),
    .q(sample_read_addr_n[2:1]));  // zaklad.v(2774)
  // zaklad.v(2774)
  // zaklad.v(2774)
  AL_PHY_LSLICE \reg50_b3|reg50_b7  (
    .a({_al_u2085_o,_al_u2064_o}),
    .b({_al_u1428_o,_al_u2066_o}),
    .c({_al_u2087_o,\mux104_b12/B1_2 }),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1588_o,mcu_state[2]}),
    .e({open_n27756,mcu_state[3]}),
    .mi({sample_read_offset[3],sample_read_offset[7]}),
    .f({_al_u2088_o,_al_u2068_o}),
    .q({sample_read_addr_n[3],sample_read_addr_n[7]}));  // zaklad.v(2774)
  // zaklad.v(2774)
  // zaklad.v(2774)
  AL_PHY_MSLICE \reg50_b5|reg50_b6  (
    .a({open_n27773,oc_1A[10]}),
    .b({mcu_state[2],oc_1A[2]}),
    .c({mcu_state[3],_al_u2026_o}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u2141_o,mcu_state[1]}),
    .mi({sample_read_offset[5],sample_read_offset[6]}),
    .f({_al_u2142_o,_al_u2027_o}),
    .q({sample_read_addr_n[5],sample_read_addr_n[6]}));  // zaklad.v(2774)
  // zaklad.v(2774)
  // zaklad.v(2774)
  AL_PHY_LSLICE \reg50_b9|reg50_b10  (
    .a({_al_u2120_o,_al_u1962_o}),
    .b({_al_u2122_o,_al_u1428_o}),
    .c({\mux104_b15/B1_2 ,_al_u1964_o}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[2],mcu_state[2]}),
    .e({mcu_state[3],mcu_state[3]}),
    .mi({sample_read_offset[9],sample_read_offset[10]}),
    .f({_al_u2124_o,_al_u1965_o}),
    .q({sample_read_addr_n[9],sample_read_addr_n[10]}));  // zaklad.v(2774)
  AL_PHY_LSLICE reg51_b0 (
    .a({open_n27806,sample_system_reset_count[0]}),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .q({open_n27835,sample_system_reset_count[0]}));  // zaklad.v(2786)
  // zaklad.v(2786)
  // zaklad.v(2786)
  AL_PHY_MSLICE \reg51_b1|reg51_b2  (
    .a({sample_system_reset_count[1],sample_system_reset_count[2]}),
    .c({sample_system_reset_count[0],sample_system_reset_count[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({open_n27839,sample_system_reset_count[1]}),
    .sr(sample_system_reset),
    .q({sample_system_reset_count[1],sample_system_reset_count[2]}));  // zaklad.v(2786)
  // zaklad.v(2786)
  // zaklad.v(2786)
  AL_PHY_LSLICE \reg51_b3|sample_system_state_reg  (
    .a({sample_system_reset_count[3],sample_system_state}),
    .b({sample_system_reset_count[1],sample_system_reset_count[1]}),
    .c({sample_system_reset_count[2],sample_system_reset_count[2]}),
    .clk(sample_write_clock_gclk_net),
    .d({sample_system_reset_count[0],sample_system_reset_count[3]}),
    .e({open_n27858,sample_system_reset_count[0]}),
    .sr(sample_system_reset),
    .q({sample_system_reset_count[3],sample_system_state}));  // zaklad.v(2786)
  // zaklad.v(2806)
  // zaklad.v(2806)
  AL_PHY_LSLICE \reg52_b2|reg52_b1  (
    .a({open_n27878,n680_lutinv}),
    .b({_al_u1765_o,_al_u1440_o}),
    .c({_al_u1767_o,_al_u1415_o}),
    .ce(n170),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1762_o,_al_u1436_o}),
    .mi(io_mcu_data_pad[2:1]),
    .f({_al_u1768_o,_al_u2205_o}),
    .q(mcu_command[2:1]));  // zaklad.v(2806)
  // zaklad.v(2806)
  // zaklad.v(2806)
  AL_PHY_LSLICE \reg52_b4|reg52_b5  (
    .a({\dec_ch2/sh [27],_al_u2210_o}),
    .b({\dec_ch2/sh [31],_al_u2211_o}),
    .c({\dec_ch2/sh [37],mcu_command[6]}),
    .ce(n170),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [42],mcu_command[7]}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[5]}),
    .f({_al_u1759_o,_al_u2212_o}),
    .q({mcu_command[4],mcu_command[5]}));  // zaklad.v(2806)
  // zaklad.v(2806)
  // zaklad.v(2806)
  AL_PHY_LSLICE \reg52_b7|reg52_b6  (
    .b({\dec_ch2/sh [46],open_n27917}),
    .c({\dec_ch2/sh [40],mcu_command[3]}),
    .ce(n170),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/sh [30],mcu_command[2]}),
    .mi(io_mcu_data_pad[7:6]),
    .f({_al_u1761_o,_al_u1441_o}),
    .q(mcu_command[7:6]));  // zaklad.v(2806)
  AL_PHY_MSLICE reg53_b0 (
    .a({open_n27936,mcu_state[0]}),
    .ce(n479),
    .clk(i_mcu_clk_pad_gclk_net),
    .sr(i_mcu_dcs_pad),
    .q({open_n27960,mcu_state[0]}));  // zaklad.v(2817)
  AL_PHY_MSLICE reg53_b2 (
    .a({open_n27961,mcu_state[2]}),
    .ce(n479),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n27966,_al_u671_o}),
    .sr(i_mcu_dcs_pad),
    .q({open_n27984,mcu_state[2]}));  // zaklad.v(2817)
  // zaklad.v(2817)
  // zaklad.v(2817)
  AL_PHY_LSLICE \reg53_b3|reg53_b1  (
    .a({mcu_state[3],mcu_state[1]}),
    .c({mcu_state[2],open_n27987}),
    .ce(n479),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u671_o,mcu_state[0]}),
    .sr(i_mcu_dcs_pad),
    .q({mcu_state[3],mcu_state[1]}));  // zaklad.v(2817)
  AL_PHY_MSLICE reg54_b0 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[0]}),
    .b({n499,n499}),
    .c({n501[0],n501[0]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[0],mux68_b0_sel_is_3_o}),
    .mi({open_n28020,io_mcu_data_pad[0]}),
    .q({open_n28027,sample_read_offset[0]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b1 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[1]}),
    .b({n499,n499}),
    .c({n501[1],n501[1]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[1],mux68_b0_sel_is_3_o}),
    .mi({open_n28039,io_mcu_data_pad[1]}),
    .q({open_n28046,sample_read_offset[1]}));  // zaklad.v(2844)
  // zaklad.v(2844)
  // zaklad.v(2844)
  AL_PHY_LSLICE \reg54_b10|reg54_b9  (
    .a(sample_read_offset[10:9]),
    .b({n499,n499}),
    .c(n501[10:9]),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mux68_b10_sel_is_3_o,mux68_b10_sel_is_3_o}),
    .e(io_mcu_data_pad[2:1]),
    .q(sample_read_offset[10:9]));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b11 (
    .a({mux68_b10_sel_is_3_o,sample_read_offset[11]}),
    .b({n499,n499}),
    .c({n501[11],n501[11]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[11],mux68_b10_sel_is_3_o}),
    .mi({open_n28079,io_mcu_data_pad[3]}),
    .q({open_n28086,sample_read_offset[11]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b12 (
    .a({mux68_b10_sel_is_3_o,sample_read_offset[12]}),
    .b({n499,n499}),
    .c({n501[12],n501[12]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[12],mux68_b10_sel_is_3_o}),
    .mi({open_n28098,io_mcu_data_pad[4]}),
    .q({open_n28105,sample_read_offset[12]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b2 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[2]}),
    .b({n499,n499}),
    .c({n501[2],n501[2]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[2],mux68_b0_sel_is_3_o}),
    .mi({open_n28117,io_mcu_data_pad[2]}),
    .q({open_n28124,sample_read_offset[2]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b3 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[3]}),
    .b({n499,n499}),
    .c({n501[3],n501[3]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[3],mux68_b0_sel_is_3_o}),
    .mi({open_n28136,io_mcu_data_pad[3]}),
    .q({open_n28143,sample_read_offset[3]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b4 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[4]}),
    .b({n499,n499}),
    .c({n501[4],n501[4]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[4],mux68_b0_sel_is_3_o}),
    .mi({open_n28155,io_mcu_data_pad[4]}),
    .q({open_n28162,sample_read_offset[4]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b5 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[5]}),
    .b({n499,n499}),
    .c({n501[5],n501[5]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[5],mux68_b0_sel_is_3_o}),
    .mi({open_n28174,io_mcu_data_pad[5]}),
    .q({open_n28181,sample_read_offset[5]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b6 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[6]}),
    .b({n499,n499}),
    .c({n501[6],n501[6]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[6],mux68_b0_sel_is_3_o}),
    .mi({open_n28193,io_mcu_data_pad[6]}),
    .q({open_n28200,sample_read_offset[6]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b7 (
    .a({mux68_b0_sel_is_3_o,sample_read_offset[7]}),
    .b({n499,n499}),
    .c({n501[7],n501[7]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[7],mux68_b0_sel_is_3_o}),
    .mi({open_n28212,io_mcu_data_pad[7]}),
    .q({open_n28219,sample_read_offset[7]}));  // zaklad.v(2844)
  AL_PHY_MSLICE reg54_b8 (
    .a({mux68_b10_sel_is_3_o,sample_read_offset[8]}),
    .b({n499,n499}),
    .c({n501[8],n501[8]}),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_read_offset[8],mux68_b10_sel_is_3_o}),
    .mi({open_n28231,io_mcu_data_pad[0]}),
    .q({open_n28238,sample_read_offset[8]}));  // zaklad.v(2844)
  AL_PHY_LSLICE reg55_b0 (
    .a({open_n28239,\dec_ch2/n126_lutinv }),
    .b({open_n28240,\dec_ch2/c3 [17]}),
    .c({open_n28241,\dec_ch2/c3 [9]}),
    .ce(mux70_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28242,dec_shift[3]}),
    .e({open_n28243,dec_shift[4]}),
    .mi({open_n28245,io_mcu_data_pad[0]}),
    .f({open_n28258,\dec_ch2/n17_lutinv }),
    .q({open_n28262,pretrigger_samples[0]}));  // zaklad.v(2867)
  AL_PHY_MSLICE reg55_b8 (
    .c({open_n28267,mcu_command[3]}),
    .ce(mux70_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28268,mcu_command[2]}),
    .mi({open_n28279,io_mcu_data_pad[0]}),
    .f({open_n28281,_al_u1415_o}),
    .q({open_n28285,pretrigger_samples[8]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg56_b2 (
    .b({open_n28288,\dec_ch2/c3 [25]}),
    .c({open_n28289,dec_shift[3]}),
    .ce(mux71_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28290,\dec_ch2/c3 [17]}),
    .mi({open_n28294,io_mcu_data_pad[2]}),
    .f({open_n28307,\dec_ch2/n143_lutinv }),
    .q({open_n28311,total_samples[2]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg56_b4|reg56_b3  (
    .b({\dec_ch2/c3 [40],\dec_ch2/c3 [44]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(mux71_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/c3 [32],\dec_ch2/c3 [36]}),
    .mi(io_mcu_data_pad[4:3]),
    .f({\dec_ch2/n119_lutinv ,\dec_ch2/n115_lutinv }),
    .q(total_samples[4:3]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg56_b6|reg56_b5  (
    .b(\dec_ch2/c3 [46:45]),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(mux71_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(\dec_ch2/c3 [38:37]),
    .mi(io_mcu_data_pad[6:5]),
    .f({\dec_ch2/n113_lutinv ,\dec_ch2/n114_lutinv }),
    .q(total_samples[6:5]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg56_b9|reg56_b8  (
    .b({\dec_ch2/c3 [41],\dec_ch2/c3 [42]}),
    .c({dec_shift[3],dec_shift[3]}),
    .ce(mux71_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/c3 [33],\dec_ch2/c3 [34]}),
    .mi(io_mcu_data_pad[1:0]),
    .f({\dec_ch2/n118_lutinv ,\dec_ch2/n117_lutinv }),
    .q(total_samples[9:8]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg57_b13|reg57_b12  (
    .ce(mux72_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi(io_mcu_data_pad[5:4]),
    .q(sample_rate_divider[13:12]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg57_b14|reg57_b15  (
    .ce(mux72_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({io_mcu_data_pad[6],io_mcu_data_pad[7]}),
    .q({sample_rate_divider[14],sample_rate_divider[15]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg57_b17|reg57_b16  (
    .a({n687_lutinv,io_mcu_data_pad[5]}),
    .b({_al_u671_o,io_mcu_data_pad[4]}),
    .c({sel65_b0_def_0_sel_is_0_o,io_mcu_data_pad[3]}),
    .ce(mux72_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n515,io_mcu_data_pad[2]}),
    .mi(io_mcu_data_pad[1:0]),
    .f({mux101_b10_sel_is_3_o,_al_u1391_o}),
    .q(sample_rate_divider[17:16]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg57_b19|reg57_b18  (
    .a({n687_lutinv,n650_lutinv}),
    .b({_al_u1558_o,_al_u1558_o}),
    .c({_al_u1588_o,sel65_b0_def_0_sel_is_0_o}),
    .ce(mux72_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n515,n515}),
    .mi(io_mcu_data_pad[3:2]),
    .f({mux102_b0_sel_is_3_o,mux72_b10_sel_is_3_o}),
    .q(sample_rate_divider[19:18]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg57_b6|reg57_b5  (
    .a({_al_u397_o,trig_holdoff[10]}),
    .b({_al_u400_o,trig_holdoff[9]}),
    .c({_al_u399_o,trig_holdoff[8]}),
    .ce(mux72_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u398_o,trig_holdoff[11]}),
    .mi(io_mcu_data_pad[6:5]),
    .f({_al_u401_o,_al_u398_o}),
    .q(sample_rate_divider[6:5]));  // zaklad.v(2867)
  AL_PHY_MSLICE reg57_b7 (
    .a({open_n28474,trig_holdoff[12]}),
    .b({open_n28475,trig_holdoff[13]}),
    .c({open_n28476,trig_holdoff[14]}),
    .ce(mux72_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28477,trig_holdoff[15]}),
    .mi({open_n28488,io_mcu_data_pad[7]}),
    .f({open_n28490,_al_u397_o}),
    .q({open_n28494,sample_rate_divider[7]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg57_b9 (
    .c({open_n28499,n657_lutinv}),
    .ce(mux72_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28500,_al_u1556_o}),
    .mi({open_n28504,io_mcu_data_pad[1]}),
    .f({open_n28517,mux76_b16_sel_is_3_o}),
    .q({open_n28521,sample_rate_divider[9]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg58_b16|reg58_b19  (
    .c({n648_lutinv,mcu_command[3]}),
    .ce(mux73_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1552_o,_al_u1436_o}),
    .mi({io_mcu_data_pad[0],io_mcu_data_pad[3]}),
    .f({mux70_b10_sel_is_3_o,_al_u1565_o}),
    .q({time_base_set[16],time_base_set[19]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg58_b20|reg58_b17  (
    .a({open_n28540,_al_u1556_o}),
    .b({open_n28541,_al_u1565_o}),
    .c({mcu_command[3],_al_u1413_o}),
    .ce(mux73_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_command[2],mcu_command[2]}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[1]}),
    .f({_al_u1421_o,mux71_b0_sel_is_3_o}),
    .q({time_base_set[20],time_base_set[17]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg58_b26|reg58_b30  (
    .b({mcu_command[6],sample_write_enable}),
    .c({mcu_command[7],sampling_half_way}),
    .ce(mux73_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1439_o,swc_adv}),
    .mi({io_mcu_data_pad[2],io_mcu_data_pad[6]}),
    .f({_al_u1440_o,_al_u1973_o}),
    .q({time_base_set[26],time_base_set[30]}));  // zaklad.v(2867)
  AL_PHY_LSLICE \reg58_b28|_al_u2211  (
    .a({n327,_al_u2011_o}),
    .b({_al_u1546_o,_al_u1421_o}),
    .c({oc_v[1],_al_u1439_o}),
    .ce(mux73_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_write_enable,mcu_command[0]}),
    .e({open_n28572,mcu_command[1]}),
    .mi({io_mcu_data_pad[4],open_n28574}),
    .f({mux50_b0_sel_is_3_o,_al_u2211_o}),
    .q({time_base_set[28],open_n28590}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg58_b3|reg58_b0  (
    .b(\dec_ch2/sh [15:14]),
    .c({dec_shift[0],dec_shift[0]}),
    .ce(mux73_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(\dec_ch2/sh [14:13]),
    .mi({io_mcu_data_pad[3],io_mcu_data_pad[0]}),
    .f({\dec_ch2/n233_lutinv ,\dec_ch2/n234_lutinv }),
    .q({time_base_set[3],time_base_set[0]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg58_b9|reg58_b8  (
    .c({n648_lutinv,mcu_command[1]}),
    .ce(mux73_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1556_o,mcu_command[0]}),
    .mi(io_mcu_data_pad[1:0]),
    .f({mux70_b0_sel_is_3_o,_al_u1420_o}),
    .q(time_base_set[9:8]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg59_b1|reg59_b0  (
    .a(trigger_data[4:3]),
    .b(trigger_data[5:4]),
    .c(trigger_level[4:3]),
    .ce(mux74_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(trigger_level[5:4]),
    .mi(io_mcu_data_pad[1:0]),
    .f({_al_u2188_o,_al_u2189_o}),
    .q(trigger_level[1:0]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg59_b2|reg59_b3  (
    .a({_al_u745_o,_al_u745_o}),
    .b({trigger_data[5],trigger_data[6]}),
    .c({trigger_data[6],trigger_data[7]}),
    .ce(mux74_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({trigger_level[5],trigger_level[6]}),
    .e({trigger_level[6],trigger_level[7]}),
    .mi({io_mcu_data_pad[2],io_mcu_data_pad[3]}),
    .f({_al_u2186_o,_al_u2187_o}),
    .q({trigger_level[2],trigger_level[3]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg59_b5|reg59_b4  (
    .a({\dec_ch1/sh [38],_al_u2185_o}),
    .b({\dec_ch1/sh [39],_al_u2186_o}),
    .c({\dec_ch1/sh [40],_al_u2187_o}),
    .ce(mux74_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch1/sh [41],_al_u2188_o}),
    .e({open_n28663,_al_u2189_o}),
    .mi(io_mcu_data_pad[5:4]),
    .f({_al_u1886_o,_al_u2190_o}),
    .q(trigger_level[5:4]));  // zaklad.v(2867)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg5_b14|reg5_b15  (
    .clk(clk_200MHz),
    .mi({adc_d2[14],adc_d2[15]}),
    .q({adc_dd2[14],adc_dd2[15]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg5_b16|reg6_b16  (
    .a({adc_dd2[16],adc_e1[16]}),
    .b({adc_dd1[16],cap_sel_x[6]}),
    .c({cap_sel_x[6],adc_e2[16]}),
    .clk(clk_200MHz),
    .d({open_n28706,cap_sel_x[7]}),
    .mi({adc_d2[16],adc_dd1[16]}),
    .f({_al_u1329_o,_al_u1328_o}),
    .q({adc_dd2[16],adc_e1[16]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg5_b17|reg4_b17  (
    .a({_al_u1400_o,\display_brightness/count [0]}),
    .b({_al_u1399_o,\display_brightness/count [1]}),
    .c({_al_u1401_o,\display_brightness/count [10]}),
    .clk(clk_200MHz),
    .d({_al_u1402_o,\display_brightness/count [11]}),
    .mi({adc_d2[17],adc_d1[17]}),
    .f({\display_brightness/n0 ,_al_u1400_o}),
    .q({adc_dd2[17],adc_dd1[17]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg5_b18|reg5_b19  (
    .a({\display_brightness/count [2],\channel1_dc_offset/count [12]}),
    .b({\display_brightness/count [3],\channel1_dc_offset/count [13]}),
    .c({\display_brightness/count [4],\channel1_dc_offset/count [14]}),
    .clk(clk_200MHz),
    .d({\display_brightness/count [5],\channel1_dc_offset/count [15]}),
    .mi({adc_d2[18],adc_d2[19]}),
    .f({_al_u1402_o,_al_u1394_o}),
    .q({adc_dd2[18],adc_dd2[19]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg5_b20|reg6_b20  (
    .a({\channel1_dc_offset/count [0],open_n28755}),
    .b({\channel1_dc_offset/count [1],adc_dd1[20]}),
    .c({\channel1_dc_offset/count [11],cap_sel_x[6]}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [10],adc_dd2[20]}),
    .mi({adc_d2[20],adc_dd1[20]}),
    .f({_al_u1395_o,_al_u1299_o}),
    .q({adc_dd2[20],adc_e1[20]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg5_b22|reg7_b20  (
    .a({\channel1_dc_offset/count [2],adc_e2[20]}),
    .b({\channel1_dc_offset/count [3],cap_sel_x[6]}),
    .c({\channel1_dc_offset/count [4],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({\channel1_dc_offset/count [5],adc_e1[20]}),
    .mi({adc_d2[22],adc_dd2[20]}),
    .f({_al_u1397_o,_al_u1298_o}),
    .q({adc_dd2[22],adc_e2[20]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg5_b23|reg7_b21  (
    .a({open_n28794,adc_e2[21]}),
    .b({adc_dd2[21],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[21],adc_e1[21]}),
    .mi({adc_d2[23],adc_dd2[21]}),
    .f({_al_u1296_o,_al_u1295_o}),
    .q({adc_dd2[23],adc_e2[21]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg5_b29|reg5_b30  (
    .clk(clk_200MHz),
    .mi({adc_d2[29],adc_d2[30]}),
    .q({adc_dd2[29],adc_dd2[30]}));  // zaklad.v(1350)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg60_b1|reg60_b0  (
    .b({open_n28841,n314[7]}),
    .c({hyst_lo9[2],n313[7]}),
    .ce(mux75_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_lo9[8],n312}),
    .mi(io_mcu_data_pad[1:0]),
    .f({hyst_lo[2],n315[7]}),
    .q(trig_hyst[1:0]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg60_b2|reg60_b3  (
    .a({_al_u1470_o,trigger_level[0]}),
    .b({_al_u1469_o,trigger_level[1]}),
    .c({_al_u1467_o,trigger_level[2]}),
    .ce(mux75_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_lo9[0],trigger_level[3]}),
    .mi({io_mcu_data_pad[2],io_mcu_data_pad[3]}),
    .f({hyst_lo[0],_al_u1470_o}),
    .q({trig_hyst[2],trig_hyst[3]}));  // zaklad.v(2867)
  AL_PHY_MSLICE reg60_b5 (
    .c({open_n28878,hyst_lo9[3]}),
    .ce(mux75_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28879,hyst_lo9[8]}),
    .mi({open_n28890,io_mcu_data_pad[5]}),
    .f({open_n28892,hyst_lo[3]}),
    .q({open_n28896,trig_hyst[5]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg61_b12 (
    .c({open_n28901,n661_lutinv}),
    .ce(mux76_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n28902,n664_lutinv}),
    .mi({open_n28906,io_mcu_data_pad[4]}),
    .f({open_n28919,_al_u2215_o}),
    .q({open_n28923,trig_holdoff[12]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg61_b13|reg61_b11  (
    .a({open_n28924,trig_holdoff[0]}),
    .b({n324[7],trig_holdoff[1]}),
    .c({n325[7],trig_holdoff[2]}),
    .ce(mux76_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n323,trig_holdoff[3]}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[3]}),
    .f({n326[7],_al_u399_o}),
    .q({trig_holdoff[13],trig_holdoff[11]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg61_b16|reg61_b19  (
    .a({open_n28939,_al_u1451_o}),
    .b({enc_ok[0],_al_u1966_o}),
    .c({enc_ok[1],_al_u1426_o}),
    .ce(mux76_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({enc_pred_ok,enc_ok[1]}),
    .mi({io_mcu_data_pad[0],io_mcu_data_pad[3]}),
    .f({n139,_al_u1967_o}),
    .q({trig_holdoff[16],trig_holdoff[19]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg61_b29|reg61_b30  (
    .a({n294,n657_lutinv}),
    .b({_al_u1528_o,_al_u671_o}),
    .c({oc_v[1],sel65_b0_def_0_sel_is_0_o}),
    .ce(mux76_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({sample_write_enable,n515}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[6]}),
    .f({mux47_b0_sel_is_3_o,mux76_b0_sel_is_3_o}),
    .q({trig_holdoff[29],trig_holdoff[30]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg61_b31|reg61_b28  (
    .a({n657_lutinv,n650_lutinv}),
    .b({_al_u1558_o,_al_u671_o}),
    .c({sel65_b0_def_0_sel_is_0_o,sel65_b0_def_0_sel_is_0_o}),
    .ce(mux76_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n515,n515}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[4]}),
    .f({mux76_b10_sel_is_3_o,mux72_b0_sel_is_3_o}),
    .q({trig_holdoff[31],trig_holdoff[28]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg61_b3|reg61_b1  (
    .a({open_n28990,_al_u1419_o}),
    .b({_al_u1419_o,\lt21/o_1_lutinv }),
    .c({n515,_al_u1426_o}),
    .ce(mux76_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1423_o,n515}),
    .mi({io_mcu_data_pad[3],io_mcu_data_pad[1]}),
    .f({mux75_b0_sel_is_3_o,mux74_b0_sel_is_3_o}),
    .q({trig_holdoff[3],trig_holdoff[1]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg61_b4|reg61_b2  (
    .a({n324[4],open_n29009}),
    .b({n325[4],_al_u1414_o}),
    .c({n323,_al_u1426_o}),
    .ce(mux76_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29010,_al_u1434_o}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[2]}),
    .f({n326[4],n661_lutinv}),
    .q({trig_holdoff[4],trig_holdoff[2]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg61_b7|reg61_b5  (
    .b({n324[5],n324[3]}),
    .c({n325[5],n325[3]}),
    .ce(mux76_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({n323,n323}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[5]}),
    .f({n326[5],n326[3]}),
    .q({trig_holdoff[7],trig_holdoff[5]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg62_b10|reg62_b9  (
    .a({_al_u1736_o,\display_brightness/lt0/o_3_lutinv }),
    .b({display_brigthness[2],display_brigthness[4]}),
    .c({display_brigthness[3],display_brigthness[5]}),
    .ce(mux77_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\display_brightness/count [2],\display_brightness/count [4]}),
    .e({\display_brightness/count [3],\display_brightness/count [5]}),
    .mi(io_mcu_data_pad[2:1]),
    .f({\display_brightness/lt0/o_3_lutinv ,_al_u1738_o}),
    .q(ch1_offset[10:9]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg62_b13|reg62_b12  (
    .a({ch1_offset[13],ch2_offset[12]}),
    .b({\channel1_dc_offset/count [13],ch2_offset[13]}),
    .c({\channel1_dc_offset/count [12],\channel1_dc_offset/count [12]}),
    .ce(mux77_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({ch1_offset[12],\channel1_dc_offset/count [13]}),
    .mi(io_mcu_data_pad[5:4]),
    .f({_al_u1709_o,_al_u1727_o}),
    .q(ch1_offset[13:12]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg62_b14|reg62_b15  (
    .a({display_brigthness[6],ch2_offset[12]}),
    .b({display_brigthness[7],ch2_offset[13]}),
    .c({\display_brightness/count [6],\channel1_dc_offset/count [12]}),
    .ce(mux77_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\display_brightness/count [7],\channel1_dc_offset/count [13]}),
    .mi({io_mcu_data_pad[6],io_mcu_data_pad[7]}),
    .f({_al_u1739_o,_al_u1730_o}),
    .q({ch1_offset[14],ch1_offset[15]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg62_b1|reg62_b0  (
    .a({ch1_offset[6],_al_u1699_o}),
    .b({ch1_offset[7],_al_u1701_o}),
    .c({\channel1_dc_offset/count [6],_al_u1702_o}),
    .ce(mux77_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\channel1_dc_offset/count [7],ch1_offset[8]}),
    .e({open_n29093,\channel1_dc_offset/count [8]}),
    .mi(io_mcu_data_pad[1:0]),
    .f({_al_u1704_o,_al_u1703_o}),
    .q(ch1_offset[1:0]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg62_b2|reg62_b3  (
    .c({\dec_ch2/i3 [45],\dec_ch2/i3 [46]}),
    .ce(mux77_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch1/k3_lutinv ,\dec_ch1/k3_lutinv }),
    .mi({io_mcu_data_pad[2],io_mcu_data_pad[3]}),
    .f({\dec_ch2/n74 [45],\dec_ch2/n74 [46]}),
    .q({ch1_offset[2],ch1_offset[3]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg62_b4|reg62_b7  (
    .c({dec_order[1],\dec_ch2/i3 [47]}),
    .ce(mux77_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\dec_ch2/i2 [47],\dec_ch1/k3_lutinv }),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[7]}),
    .f({\dec_ch2/n71 [47],\dec_ch2/n74 [47]}),
    .q({ch1_offset[4],ch1_offset[7]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg63_b11|reg63_b8  (
    .a({display_brigthness[6],_al_u1703_o}),
    .b({display_brigthness[7],_al_u1706_o}),
    .c({\display_brightness/count [6],\channel1_dc_offset/count [11]}),
    .ce(mux78_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\display_brightness/count [7],ch1_offset[11]}),
    .mi({io_mcu_data_pad[3],io_mcu_data_pad[0]}),
    .f({_al_u1734_o,_al_u1707_o}),
    .q({ch2_offset[11],ch2_offset[8]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg63_b14|reg63_b15  (
    .a({ch1_offset[13],_al_u1739_o}),
    .b({ch1_offset[14],display_brigthness[8]}),
    .c({\channel1_dc_offset/count [13],display_brigthness[9]}),
    .ce(mux78_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\channel1_dc_offset/count [14],\display_brightness/count [8]}),
    .e({open_n29168,\display_brightness/count [9]}),
    .mi({io_mcu_data_pad[6],io_mcu_data_pad[7]}),
    .f({_al_u1710_o,\display_brightness/lt0/less_6_11_inst/o_3_lutinv }),
    .q({ch2_offset[14],ch2_offset[15]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg63_b1|reg63_b2  (
    .a({ch1_offset[6],\channel1_dc_offset/lt0/o_3_lutinv }),
    .b({ch1_offset[7],ch1_offset[4]}),
    .c({\channel1_dc_offset/count [6],ch1_offset[5]}),
    .ce(mux78_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\channel1_dc_offset/count [7],\channel1_dc_offset/count [4]}),
    .e({open_n29185,\channel1_dc_offset/count [5]}),
    .mi({io_mcu_data_pad[1],io_mcu_data_pad[2]}),
    .f({_al_u1702_o,_al_u1699_o}),
    .q({ch2_offset[1],ch2_offset[2]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg63_b3|reg63_b0  (
    .a({ch2_offset[6],ch2_offset[6]}),
    .b({ch2_offset[7],ch2_offset[7]}),
    .c({\channel1_dc_offset/count [6],\channel1_dc_offset/count [6]}),
    .ce(mux78_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\channel1_dc_offset/count [7],\channel1_dc_offset/count [7]}),
    .mi({io_mcu_data_pad[3],io_mcu_data_pad[0]}),
    .f({_al_u1720_o,_al_u1717_o}),
    .q({ch2_offset[3],ch2_offset[0]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg63_b6|reg63_b5  (
    .a({ch1_offset[10],_al_u1704_o}),
    .b(ch1_offset[9:8]),
    .c({\channel1_dc_offset/count [10],ch1_offset[9]}),
    .ce(mux78_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(\channel1_dc_offset/count [9:8]),
    .e({open_n29220,\channel1_dc_offset/count [9]}),
    .mi(io_mcu_data_pad[6:5]),
    .f({_al_u1700_o,\channel1_dc_offset/lt0/less_6_11_inst/o_3_lutinv }),
    .q(ch2_offset[6:5]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg63_b7|reg63_b4  (
    .b({ch1_offset[10],ch2_offset[11]}),
    .c({\channel1_dc_offset/count [10],\channel1_dc_offset/count [11]}),
    .ce(mux78_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({\channel1_dc_offset/lt0/less_6_11_inst/o_3_lutinv ,_al_u1715_o}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[4]}),
    .f({_al_u1706_o,_al_u1716_o}),
    .q({ch2_offset[7],ch2_offset[4]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg64_b11 (
    .c({open_n29261,hyst_hi9[1]}),
    .ce(mux79_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29262,hyst_hi9[8]}),
    .mi({open_n29266,io_mcu_data_pad[3]}),
    .f({open_n29279,hyst_hi[1]}),
    .q({open_n29283,display_brigthness[11]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg64_b15|reg64_b9  (
    .a({open_n29284,_al_u1735_o}),
    .b({display_brigthness[11],_al_u1738_o}),
    .c({\display_brightness/count [11],_al_u1741_o}),
    .ce(mux79_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1732_o,\display_brightness/lt0/diff [15]}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[1]}),
    .f({_al_u1733_o,_al_u1743_o}),
    .q({display_brigthness[15],display_brigthness[9]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg64_b4|reg64_b1  (
    .b({_al_u1466_o,open_n29305}),
    .c({hyst_lo9[8],hyst_lo9[1]}),
    .ce(mux79_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1465_o,_al_u1467_o}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[1]}),
    .f({_al_u1467_o,hyst_lo[1]}),
    .q({display_brigthness[4],display_brigthness[1]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg64_b6 (
    .a({open_n29320,_al_u1733_o}),
    .b({open_n29321,_al_u1734_o}),
    .c({open_n29322,display_brigthness[8]}),
    .ce(mux79_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29323,\display_brightness/count [8]}),
    .mi({open_n29327,io_mcu_data_pad[6]}),
    .f({open_n29340,_al_u1735_o}),
    .q({open_n29344,display_brigthness[6]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg64_b7|reg64_b5  (
    .a({open_n29345,hyst_lo9[3]}),
    .b({open_n29346,hyst_lo9[2]}),
    .c({hyst_hi9[2],hyst_lo9[1]}),
    .ce(mux79_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_hi9[8],hyst_lo9[0]}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[5]}),
    .f({hyst_hi[2],_al_u1466_o}),
    .q({display_brigthness[7],display_brigthness[5]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg65_b1 (
    .c({open_n29365,\dec_ch2/i3 [9]}),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29366,\dec_ch1/k3_lutinv }),
    .mi({open_n29370,io_mcu_data_pad[1]}),
    .f({open_n29383,\dec_ch2/n74 [9]}),
    .q({open_n29387,dec_order[1]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg65_b1_hfnopt2_2 (
    .a({open_n29388,\dec_order[1]_hfnopt2_2 }),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29393,peak_en}),
    .mi({open_n29397,io_mcu_data_pad[1]}),
    .f({open_n29410,_al_u1454_o}),
    .q({open_n29414,\dec_order[1]_hfnopt2_2 }));  // zaklad.v(2867)
  AL_PHY_MSLICE reg65_b1_hfnopt2_3 (
    .a({open_n29415,\dec_order[1]_hfnopt2_3 }),
    .ce(mux80_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29420,\dec_ch2/c1p [9]}),
    .mi({open_n29431,io_mcu_data_pad[1]}),
    .f({open_n29433,\dec_ch2/n81 [9]}),
    .q({open_n29437,\dec_order[1]_hfnopt2_3 }));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg66_b2|reg66_b1  (
    .a({open_n29438,n679_lutinv}),
    .b({_al_u1445_o,trig_pol}),
    .c({n515,io_mcu_data_pad[2]}),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1451_o,io_mcu_data_pad[1]}),
    .e({open_n29439,io_mcu_data_pad[0]}),
    .mi(io_mcu_data_pad[2:1]),
    .f({mux80_b0_sel_is_3_o,\sel32/B0 }),
    .q(dec_shift[2:1]));  // zaklad.v(2867)
  AL_PHY_LSLICE reg66_b3 (
    .a({open_n29456,dec_shift[3]}),
    .b({open_n29457,\dec_ch2/c3 [29]}),
    .c({open_n29458,\dec_ch2/c3 [21]}),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n29464,io_mcu_data_pad[3]}),
    .f({open_n29477,\dec_ch2/n139_lutinv }),
    .q({open_n29481,dec_shift[3]}));  // zaklad.v(2867)
  AL_PHY_MSLICE reg66_b3_hfnopt2_2 (
    .c({open_n29486,mcu_command[5]}),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29487,mcu_command[4]}),
    .mi({open_n29498,io_mcu_data_pad[3]}),
    .f({open_n29500,_al_u1433_o}),
    .q({open_n29504,\dec_shift[3]_hfnopt2_2 }));  // zaklad.v(2867)
  AL_PHY_MSLICE reg66_b3_hfnopt2_3 (
    .b({open_n29507,mcu_command[6]}),
    .c({open_n29508,mcu_command[7]}),
    .ce(mux81_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29509,_al_u1418_o}),
    .mi({open_n29520,io_mcu_data_pad[3]}),
    .f({open_n29522,_al_u1419_o}),
    .q({open_n29526,\dec_shift[3]_hfnopt2_3 }));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg67_b12|reg67_b13  (
    .a({\dec_ch2/n230_lutinv ,_al_u1799_o}),
    .b({\dec_ch2/n232_lutinv ,\dec_ch2/n229_lutinv }),
    .c({_al_u1844_o,\dec_ch2/n231_lutinv }),
    .ce(mux82_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(dec_shift[2:1]),
    .e({open_n29527,dec_shift[2]}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[5]}),
    .f({_al_u1845_o,_al_u1841_o}),
    .q({trigger_level16[12],trigger_level16[13]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg67_b15|reg67_b11  (
    .a({\dec_ch2/n227_lutinv ,open_n29544}),
    .b({\dec_ch2/n229_lutinv ,_al_u1783_o}),
    .c({_al_u1834_o,dec_shift[2]}),
    .ce(mux82_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({dec_shift[2],_al_u1781_o}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[3]}),
    .f({_al_u1835_o,_al_u1784_o}),
    .q({trigger_level16[15],trigger_level16[11]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg67_b6|reg67_b5  (
    .a({\dec_ch1/sh [17],\dec_ch1/sh [17]}),
    .b({\dec_ch1/sh [18],dec_shift[0]}),
    .c({dec_shift[0],open_n29559}),
    .ce(mux82_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29560,\dec_ch1/sh [16]}),
    .mi(io_mcu_data_pad[6:5]),
    .f({\dec_ch1/n230_lutinv ,\dec_ch1/n231_lutinv }),
    .q(trigger_level16[6:5]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg67_b9|reg67_b8  (
    .b({_al_u1790_o,_al_u1799_o}),
    .c({dec_shift[2],dec_shift[2]}),
    .ce(mux82_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1787_o,_al_u1796_o}),
    .mi(io_mcu_data_pad[1:0]),
    .f({_al_u1791_o,_al_u1800_o}),
    .q(trigger_level16[9:8]));  // zaklad.v(2867)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b0|reg7_b0  (
    .a({open_n29599,adc_e2[0]}),
    .b({adc_dd2[0],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[0],adc_e1[0]}),
    .mi({adc_dd1[0],adc_dd2[0]}),
    .f({_al_u1281_o,_al_u1280_o}),
    .q({adc_e1[0],adc_e2[0]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b17|reg7_b17  (
    .a({open_n29615,adc_e2[17]}),
    .b({adc_dd2[17],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[17],adc_e1[17]}),
    .mi({adc_dd1[17],adc_dd2[17]}),
    .f({_al_u1326_o,_al_u1325_o}),
    .q({adc_e1[17],adc_e2[17]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b18|reg7_b18  (
    .a({open_n29635,adc_e2[18]}),
    .b({adc_dd1[18],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd2[18],adc_e1[18]}),
    .mi({adc_dd1[18],adc_dd2[18]}),
    .f({_al_u1305_o,_al_u1304_o}),
    .q({adc_e1[18],adc_e2[18]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b19|reg7_b19  (
    .a({open_n29655,adc_e2[19]}),
    .b({adc_dd2[19],cap_sel_x[6]}),
    .c({adc_dd1[19],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({cap_sel_x[6],adc_e1[19]}),
    .mi({adc_dd1[19],adc_dd2[19]}),
    .f({_al_u1302_o,_al_u1301_o}),
    .q({adc_e1[19],adc_e2[19]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b1|reg7_b1  (
    .a({open_n29671,adc_e2[1]}),
    .b({adc_dd2[1],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[1],adc_e1[1]}),
    .mi({adc_dd1[1],adc_dd2[1]}),
    .f({_al_u1278_o,_al_u1277_o}),
    .q({adc_e1[1],adc_e2[1]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b22|reg7_b22  (
    .a({open_n29687,adc_e2[22]}),
    .b({adc_dd2[22],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[22],adc_e1[22]}),
    .mi({adc_dd1[22],adc_dd2[22]}),
    .f({_al_u1293_o,_al_u1292_o}),
    .q({adc_e1[22],adc_e2[22]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b23|reg4_b22  (
    .a({adc_e1[23],open_n29703}),
    .b({cap_sel_x[6],open_n29704}),
    .c({cap_sel_x[7],\dec_ch2/i3 [30]}),
    .clk(clk_200MHz),
    .d({adc_e2[23],\dec_ch1/k3_lutinv }),
    .mi({adc_dd1[23],adc_d1[22]}),
    .f({_al_u1289_o,\dec_ch2/n74 [30]}),
    .q({adc_e1[23],adc_dd1[22]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b26|reg7_b26  (
    .a({open_n29724,adc_e2[26]}),
    .b({adc_dd2[26],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[26],adc_e1[26]}),
    .mi({adc_dd1[26],adc_dd2[26]}),
    .f({_al_u1323_o,_al_u1322_o}),
    .q({adc_e1[26],adc_e2[26]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b28|reg7_b27  (
    .a({open_n29740,adc_e2[27]}),
    .b({adc_dd2[27],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[27],adc_e1[27]}),
    .mi({adc_dd1[28],adc_dd2[27]}),
    .f({_al_u1320_o,_al_u1319_o}),
    .q({adc_e1[28],adc_e2[27]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b2|reg7_b2  (
    .a({open_n29760,adc_e2[2]}),
    .b({adc_dd2[2],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[2],adc_e1[2]}),
    .mi({adc_dd1[2],adc_dd2[2]}),
    .f({_al_u1257_o,_al_u1256_o}),
    .q({adc_e1[2],adc_e2[2]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b30|reg6_b29  (
    .a({open_n29776,adc_e1[29]}),
    .b({adc_dd2[29],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[29],adc_e2[29]}),
    .mi(adc_dd1[30:29]),
    .f({_al_u1314_o,_al_u1313_o}),
    .q(adc_e1[30:29]));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b31|reg7_b29  (
    .a({open_n29796,adc_e1[30]}),
    .b({adc_dd2[30],adc_e2[30]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[30],cap_sel_x[6]}),
    .mi({adc_dd1[31],adc_dd2[29]}),
    .f({_al_u1311_o,_al_u1310_o}),
    .q({adc_e1[31],adc_e2[29]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg6_b3|reg6_b4  (
    .a({adc_e1[3],adc_e1[4]}),
    .b({cap_sel_x[0],cap_sel_x[0]}),
    .c({cap_sel_x[1],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_e2[3],adc_e2[4]}),
    .mi({adc_dd1[3],adc_dd1[4]}),
    .f({_al_u1253_o,_al_u1250_o}),
    .q({adc_e1[3],adc_e1[4]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b6|reg6_b7  (
    .a({adc_e1[6],adc_e1[7]}),
    .b({adc_e2[6],cap_sel_x[0]}),
    .c({cap_sel_x[1],adc_e2[7]}),
    .clk(clk_200MHz),
    .d({cap_sel_x[0],cap_sel_x[1]}),
    .mi({adc_dd1[6],adc_dd1[7]}),
    .f({_al_u1244_o,_al_u1241_o}),
    .q({adc_e1[6],adc_e1[7]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg6_b8|reg7_b8  (
    .a({open_n29846,adc_e2[8]}),
    .b({adc_dd2[8],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[8],adc_e1[8]}),
    .mi({adc_dd1[8],adc_dd2[8]}),
    .f({_al_u1239_o,_al_u1238_o}),
    .q({adc_e1[8],adc_e2[8]}));  // zaklad.v(1350)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg74_b0|reg74_b1  (
    .a({open_n29866,oc_1B[11]}),
    .b({open_n29867,oc_1B[3]}),
    .c({open_n29868,_al_u2034_o}),
    .ce(mux89_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({io_mcu_data_pad[0],mcu_state[1]}),
    .mi({open_n29879,n556}),
    .f({open_n29881,_al_u2035_o}),
    .q({cap_sel_x[0],cap_sel_x[1]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg74_b15|reg74_b14  (
    .a({o_adc2A_d[7],oc_1B[12]}),
    .b({o_adc2B_d[7],oc_1B[4]}),
    .c({mcu_command[0],_al_u2063_o}),
    .ce(mux89_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_command[1],mcu_state[1]}),
    .mi(io_mcu_data_pad[7:6]),
    .f({_al_u2106_o,_al_u2064_o}),
    .q(cap_sel_x[15:14]));  // zaklad.v(2867)
  AL_PHY_MSLICE reg74_b4 (
    .ce(mux89_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29905,io_mcu_data_pad[4]}),
    .q({open_n29924,cap_sel_x[4]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg74_b5|reg74_b2  (
    .a({oc_1A[14],oc_1A[15]}),
    .b({oc_1A[6],oc_1A[7]}),
    .c({_al_u2082_o,_al_u2121_o}),
    .ce(mux89_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[2]}),
    .f({_al_u2083_o,_al_u2122_o}),
    .q({cap_sel_x[5],cap_sel_x[2]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg74_b6|reg74_b7  (
    .ce(mux89_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({io_mcu_data_pad[6],io_mcu_data_pad[7]}),
    .q({cap_sel_x[6],cap_sel_x[7]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg75_b3 (
    .ce(mux90_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n29973,io_mcu_data_pad[3]}),
    .f({open_n29991,\io_mcu_data_pad[3]_neg }),
    .q({open_n29995,cap_thr_x[3]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg75_b4|reg75_b7  (
    .c({trigger_level[7],n153}),
    .ce(mux90_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({trigger_data[7],n152}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[7]}),
    .f({_al_u2191_o,_al_u1608_o}),
    .q({cap_thr_x[4],cap_thr_x[7]}));  // zaklad.v(2867)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b10|reg6_b10  (
    .a({open_n30018,adc_e1[10]}),
    .b({adc_dd2[10],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[10],adc_e2[10]}),
    .mi({adc_dd2[10],adc_dd1[10]}),
    .f({_al_u1275_o,_al_u1274_o}),
    .q({adc_e2[10],adc_e1[10]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b11|reg6_b11  (
    .a({open_n30038,adc_e1[11]}),
    .b({adc_dd1[11],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd2[11],adc_e2[11]}),
    .mi({adc_dd2[11],adc_dd1[11]}),
    .f({_al_u1272_o,_al_u1271_o}),
    .q({adc_e2[11],adc_e1[11]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b12|reg6_b12  (
    .a({open_n30058,adc_e1[12]}),
    .b({adc_dd2[12],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[12],adc_e2[12]}),
    .mi({adc_dd2[12],adc_dd1[12]}),
    .f({_al_u1269_o,_al_u1268_o}),
    .q({adc_e2[12],adc_e1[12]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b13|reg6_b13  (
    .a({open_n30074,adc_e1[13]}),
    .b({adc_dd2[13],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[13],adc_e2[13]}),
    .mi({adc_dd2[13],adc_dd1[13]}),
    .f({_al_u1266_o,_al_u1265_o}),
    .q({adc_e2[13],adc_e1[13]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b14|reg6_b14  (
    .a({adc_dd2[14],adc_e1[14]}),
    .b({cap_sel_x[0],cap_sel_x[0]}),
    .c({open_n30090,cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[14],adc_e2[14]}),
    .mi({adc_dd2[14],adc_dd1[14]}),
    .f({_al_u1263_o,_al_u1262_o}),
    .q({adc_e2[14],adc_e1[14]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b15|reg6_b15  (
    .a({open_n30110,adc_e1[15]}),
    .b({adc_dd2[15],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[15],adc_e2[15]}),
    .mi({adc_dd2[15],adc_dd1[15]}),
    .f({_al_u1260_o,_al_u1259_o}),
    .q({adc_e2[15],adc_e1[15]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b16|reg4_b16  (
    .a({\display_brightness/count [6],ch2_offset[14]}),
    .b({\display_brightness/count [7],ch2_offset[15]}),
    .c({\display_brightness/count [8],\channel1_dc_offset/count [14]}),
    .clk(clk_200MHz),
    .d({\display_brightness/count [9],\channel1_dc_offset/count [15]}),
    .mi({adc_dd2[16],adc_d1[16]}),
    .f({_al_u1401_o,_al_u1729_o}),
    .q({adc_e2[16],adc_dd1[16]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b24|reg6_b24  (
    .a({open_n30145,adc_e1[24]}),
    .b({adc_dd2[24],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[24],adc_e2[24]}),
    .mi({adc_dd2[24],adc_dd1[24]}),
    .f({_al_u1287_o,_al_u1286_o}),
    .q({adc_e2[24],adc_e1[24]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b25|reg6_b25  (
    .a({open_n30161,adc_e1[25]}),
    .b({adc_dd2[25],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[25],adc_e2[25]}),
    .mi({adc_dd2[25],adc_dd1[25]}),
    .f({_al_u1284_o,_al_u1283_o}),
    .q({adc_e2[25],adc_e1[25]}));  // zaklad.v(1350)
  // zaklad.v(694)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b28|u_sq/reg1_b0  (
    .a({open_n30181,adc_e1[28]}),
    .b({adc_dd2[28],cap_sel_x[6]}),
    .c({cap_sel_x[6],cap_sel_x[7]}),
    .clk(clk_200MHz),
    .d({adc_dd1[28],adc_e2[28]}),
    .mi({adc_dd2[28],\u_sq/go }),
    .f({_al_u1317_o,_al_u1316_o}),
    .q({adc_e2[28],\u_sq/go_d [0]}));  // zaklad.v(694)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b31|reg7_b30  (
    .a({open_n30197,cap_sel_x[7]}),
    .b({adc_dd2[31],cap_sel_x[6]}),
    .c({cap_sel_x[6],adc_e1[31]}),
    .clk(clk_200MHz),
    .d({adc_dd1[31],adc_e2[31]}),
    .mi(adc_dd2[31:30]),
    .f({_al_u1308_o,_al_u1307_o}),
    .q(adc_e2[31:30]));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b3|reg7_b4  (
    .b({adc_dd2[3],adc_dd2[4]}),
    .c({cap_sel_x[0],cap_sel_x[0]}),
    .clk(clk_200MHz),
    .d({adc_dd1[3],adc_dd1[4]}),
    .mi({adc_dd2[3],adc_dd2[4]}),
    .f({_al_u1254_o,_al_u1251_o}),
    .q({adc_e2[3],adc_e2[4]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_MSLICE \reg7_b5|reg6_b5  (
    .a({open_n30230,adc_e1[5]}),
    .b({adc_dd2[5],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[5],adc_e2[5]}),
    .mi({adc_dd2[5],adc_dd1[5]}),
    .f({_al_u1248_o,_al_u1247_o}),
    .q({adc_e2[5],adc_e1[5]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b6|reg7_b7  (
    .a({adc_dd1[6],open_n30246}),
    .b({adc_dd2[6],adc_dd2[7]}),
    .c({cap_sel_x[0],cap_sel_x[0]}),
    .clk(clk_200MHz),
    .d({open_n30248,adc_dd1[7]}),
    .mi({adc_dd2[6],adc_dd2[7]}),
    .f({_al_u1245_o,_al_u1242_o}),
    .q({adc_e2[6],adc_e2[7]}));  // zaklad.v(1350)
  // zaklad.v(1350)
  // zaklad.v(1350)
  AL_PHY_LSLICE \reg7_b9|reg6_b9  (
    .a({open_n30267,adc_e1[9]}),
    .b({adc_dd2[9],cap_sel_x[0]}),
    .c({cap_sel_x[0],cap_sel_x[1]}),
    .clk(clk_200MHz),
    .d({adc_dd1[9],adc_e2[9]}),
    .mi({adc_dd2[9],adc_dd1[9]}),
    .f({_al_u1236_o,_al_u1235_o}),
    .q({adc_e2[9],adc_e1[9]}));  // zaklad.v(1350)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg83_b2|reg83_b0  (
    .c({n431_lutinv,n431_lutinv}),
    .ce(mux98_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1556_o,_al_u1552_o}),
    .mi({io_mcu_data_pad[2],io_mcu_data_pad[0]}),
    .f({mux68_b0_sel_is_3_o,mux68_b10_sel_is_3_o}),
    .q({rd_hi[2],rd_hi[0]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg83_b4|reg83_b1  (
    .c({oc_1A[8],sel65_b0_def_0_sel_is_0_o}),
    .ce(mux98_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1558_o,_al_u1549_o}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[1]}),
    .f({_al_u2158_o,_al_u1551_o}),
    .q({rd_hi[4],rd_hi[1]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg84_b11|reg84_b10  (
    .a({o_adc1A_d[7],_al_u2030_o}),
    .b({o_adc1B_d[7],_al_u2142_o}),
    .c({_al_u2106_o,_al_u2146_o}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_command[1],_al_u1966_o}),
    .e({open_n30327,trig_type[1]}),
    .mi(rd_hi[3:2]),
    .f({_al_u2107_o,_al_u2147_o}),
    .q(log_rd[11:10]));  // zaklad.v(2867)
  AL_PHY_MSLICE reg84_b12 (
    .a({open_n30344,_al_u2048_o}),
    .b({open_n30345,o_adc1B_d[3]}),
    .c({open_n30346,o_adc1A_d[3]}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30347,mcu_command[1]}),
    .mi({open_n30358,rd_hi[4]}),
    .f({open_n30360,_al_u2049_o}),
    .q({open_n30364,log_rd[12]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg84_b2|reg84_b1  (
    .a({_al_u1423_o,_al_u1991_o}),
    .b({_al_u2051_o,_al_u1421_o}),
    .c({_al_u2050_o,\lt21/o_1_lutinv }),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1420_o,mcu_command[3]}),
    .e({_al_u1421_o,mcu_command[4]}),
    .mi(io_mcu_data_pad[2:1]),
    .f({_al_u2052_o,n499}),
    .q(log_rd[2:1]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg84_b3|reg84_b0  (
    .b({_al_u2152_o,open_n30383}),
    .c({mcu_command[2],_al_u1436_o}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u2151_o,_al_u1421_o}),
    .mi({io_mcu_data_pad[3],io_mcu_data_pad[0]}),
    .f({_al_u2153_o,_al_u1576_o}),
    .q({log_rd[3],log_rd[0]}));  // zaklad.v(2867)
  AL_PHY_LSLICE \reg84_b4|_al_u2157  (
    .a({mcu_command[6],_al_u2153_o}),
    .b({mcu_command[7],_al_u2155_o}),
    .c({i_mcu_dcs_pad,_al_u2156_o}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({i_mcu_rws_pad,mcu_command[4]}),
    .e({open_n30398,mcu_command[5]}),
    .mi({io_mcu_data_pad[4],open_n30400}),
    .f({mux105_b0_sel_is_3_o,_al_u2157_o}),
    .q({log_rd[4],open_n30416}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg84_b5|reg84_b7  (
    .a({_al_u2070_o,_al_u1551_o}),
    .b({_al_u2071_o,mcu_state[3]}),
    .c({_al_u1433_o,o_mcu_data[3]}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_command[3],seq_raw}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[7]}),
    .f({_al_u2072_o,_al_u2050_o}),
    .q({log_rd[5],log_rd[7]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg84_b6 (
    .b({open_n30433,_al_u1426_o}),
    .c({open_n30434,mcu_command[5]}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30435,mux105_b0_sel_is_3_o}),
    .mi({open_n30439,io_mcu_data_pad[6]}),
    .f({open_n30452,_al_u1991_o}),
    .q({open_n30456,log_rd[6]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg84_b9|reg84_b8  (
    .a({_al_u1967_o,_al_u2139_o}),
    .b({_al_u2124_o,_al_u2147_o}),
    .c({_al_u1428_o,mcu_command[2]}),
    .ce(mux99_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1441_o,mcu_command[3]}),
    .e({o_mcu_data[7],o_mcu_data[1]}),
    .mi(rd_hi[1:0]),
    .f({_al_u2125_o,_al_u2148_o}),
    .q(log_rd[9:8]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg85_b1|reg85_b3  (
    .a({open_n30473,mcu_state[0]}),
    .b({open_n30474,cap_sel_x[11]}),
    .c({sample_rate_divider[0],cap_sel_x[3]}),
    .ce(mux100_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u745_o,mcu_state[1]}),
    .mi({io_mcu_data_pad[1],io_mcu_data_pad[3]}),
    .f({sample_rate_divider_eff[0],_al_u2036_o}),
    .q({pat_wr_idx[1],pat_wr_idx[3]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg85_b4|reg85_b2  (
    .a({open_n30489,oc_1B[10]}),
    .b({_al_u1451_o,oc_1B[2]}),
    .c({_al_u1434_o,_al_u2024_o}),
    .ce(mux100_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1694_o,mcu_state[1]}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[2]}),
    .f({u546_sel_is_3_o,_al_u2025_o}),
    .q({pat_wr_idx[4],pat_wr_idx[2]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg86_b15|reg86_b9  (
    .a({oc_1B[0],_al_u1693_o}),
    .b({oc_1B[8],n515}),
    .c({_al_u2162_o,io_mcu_data_pad[2]}),
    .ce(mux101_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[1],io_mcu_data_pad[1]}),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[1]}),
    .f({_al_u2163_o,_al_u1694_o}),
    .q({pat_wr_n[15],pat_wr_n[9]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg86_b17 (
    .a({open_n30522,oc_1B[4]}),
    .b({open_n30523,oc_1B[5]}),
    .c({open_n30524,oc_1B[6]}),
    .ce(mux101_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30525,oc_1B[7]}),
    .mi({open_n30529,io_mcu_data_pad[1]}),
    .f({open_n30542,n45}),
    .q({open_n30546,pat_wr_n[17]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg86_b18|reg86_b16  (
    .a({oc_1B[10],oc_1B[1]}),
    .b({oc_1B[11],oc_1B[9]}),
    .c({oc_1B[8],_al_u2140_o}),
    .ce(mux101_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({oc_1B[9],mcu_state[1]}),
    .mi({io_mcu_data_pad[2],io_mcu_data_pad[0]}),
    .f({n41,_al_u2141_o}),
    .q({pat_wr_n[18],pat_wr_n[16]}));  // zaklad.v(2867)
  AL_PHY_MSLICE reg86_b19 (
    .c({open_n30569,sample_rate_divider[16]}),
    .ce(mux101_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30570,_al_u745_o}),
    .mi({open_n30581,io_mcu_data_pad[3]}),
    .f({open_n30583,sample_rate_divider_eff[16]}),
    .q({open_n30587,pat_wr_n[19]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg86_b1|reg86_b0  (
    .a({trig_holdoff[16],n305}),
    .b({trig_holdoff[17],_al_u1534_o}),
    .c({trig_holdoff[18],oc_v[1]}),
    .ce(mux101_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({trig_holdoff[19],sample_write_enable}),
    .mi(io_mcu_data_pad[1:0]),
    .f({_al_u402_o,mux48_b0_sel_is_3_o}),
    .q(pat_wr_n[1:0]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg86_b20|reg86_b23  (
    .a({open_n30602,mcu_state[0]}),
    .b({open_n30603,cap_sel_x[15]}),
    .c({sample_rate_divider[18],mcu_state[1]}),
    .ce(mux101_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u745_o,cap_sel_x[7]}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[7]}),
    .f({sample_rate_divider_eff[18],_al_u2121_o}),
    .q({pat_wr_n[20],pat_wr_n[23]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg86_b21|reg86_b22  (
    .a({open_n30622,mcu_state[0]}),
    .b({open_n30623,cap_sel_x[14]}),
    .c({sample_rate_divider[17],cap_sel_x[6]}),
    .ce(mux101_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u745_o,mcu_state[1]}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[6]}),
    .f({sample_rate_divider_eff[17],_al_u2082_o}),
    .q({pat_wr_n[21],pat_wr_n[22]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg86_b26|reg86_b25  (
    .a({oc_2A[13],oc_2A[14]}),
    .b({oc_2A[5],oc_2A[6]}),
    .c({mcu_state[0],mcu_state[0]}),
    .ce(mux101_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({mcu_state[1],mcu_state[1]}),
    .mi(io_mcu_data_pad[2:1]),
    .f({_al_u1963_o,_al_u2086_o}),
    .q(pat_wr_n[26:25]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg86_b29|reg86_b27  (
    .ce(mux101_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[3]}),
    .q({pat_wr_n[29],pat_wr_n[27]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg86_b31|reg86_b28  (
    .ce(mux101_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({io_mcu_data_pad[7],io_mcu_data_pad[4]}),
    .q({pat_wr_n[31],pat_wr_n[28]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg86_b6|reg86_b2  (
    .a({trig_holdoff[24],open_n30704}),
    .b({trig_holdoff[25],open_n30705}),
    .c({trig_holdoff[26],n657_lutinv}),
    .ce(mux101_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({trig_holdoff[27],_al_u1552_o}),
    .mi({io_mcu_data_pad[6],io_mcu_data_pad[2]}),
    .f({_al_u404_o,mux76_b24_sel_is_3_o}),
    .q({pat_wr_n[6],pat_wr_n[2]}));  // zaklad.v(2867)
  AL_PHY_MSLICE reg86_b7 (
    .c({open_n30728,n650_lutinv}),
    .ce(mux101_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30729,_al_u1556_o}),
    .mi({open_n30740,io_mcu_data_pad[7]}),
    .f({open_n30742,mux72_b16_sel_is_3_o}),
    .q({open_n30746,pat_wr_n[7]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg86_b8 (
    .a({open_n30747,n38}),
    .b({open_n30748,n48}),
    .c({open_n30749,n45}),
    .ce(mux101_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30750,n41}),
    .mi({open_n30754,io_mcu_data_pad[0]}),
    .f({open_n30767,_al_u1534_o}),
    .q({open_n30771,pat_wr_n[8]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg87_b13|reg87_b10  (
    .c(hyst_hi9[4:3]),
    .ce(mux102_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_hi9[8],hyst_hi9[8]}),
    .mi({io_mcu_data_pad[5],io_mcu_data_pad[2]}),
    .f(hyst_hi[4:3]),
    .q({pat_wr_f[13],pat_wr_f[10]}));  // zaklad.v(2867)
  AL_PHY_MSLICE reg87_b14 (
    .ce(mux102_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30800,cap_thr_x[3]}),
    .mi({open_n30811,io_mcu_data_pad[6]}),
    .f({open_n30813,cap_thr[3]}),
    .q({open_n30817,pat_wr_f[14]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg87_b15 (
    .ce(mux102_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n30829,io_mcu_data_pad[7]}),
    .q({open_n30847,pat_wr_f[15]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg87_b4|reg87_b5  (
    .a({open_n30848,trigger_level[4]}),
    .b({open_n30849,trigger_level[5]}),
    .c({hyst_lo9[4],trigger_level[6]}),
    .ce(mux102_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_lo9[8],trigger_level[7]}),
    .mi({io_mcu_data_pad[4],io_mcu_data_pad[5]}),
    .f({hyst_lo[4],_al_u1469_o}),
    .q({pat_wr_f[4],pat_wr_f[5]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg87_b6|reg87_b0  (
    .a({open_n30864,hyst_lo9[7]}),
    .b({open_n30865,hyst_lo9[6]}),
    .c({hyst_lo9[5],hyst_lo9[5]}),
    .ce(mux102_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_lo9[8],hyst_lo9[4]}),
    .mi({io_mcu_data_pad[6],io_mcu_data_pad[0]}),
    .f({hyst_lo[5],_al_u1465_o}),
    .q({pat_wr_f[6],pat_wr_f[0]}));  // zaklad.v(2867)
  AL_PHY_LSLICE reg87_b7 (
    .a({open_n30880,dec_pc[0]}),
    .b({open_n30881,dec_pc[1]}),
    .c({open_n30882,dec_pc[2]}),
    .ce(mux102_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n30883,dec_pc[3]}),
    .mi({open_n30887,io_mcu_data_pad[7]}),
    .f({open_n30900,_al_u1407_o}),
    .q({open_n30904,pat_wr_f[7]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg87_b9|reg87_b8  (
    .c(hyst_lo9[7:6]),
    .ce(mux102_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({hyst_lo9[8],hyst_lo9[8]}),
    .mi(io_mcu_data_pad[1:0]),
    .f(hyst_lo[7:6]),
    .q(pat_wr_f[9:8]));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \reg88_b0|reg88_b5  (
    .a({open_n30923,_al_u402_o}),
    .b({open_n30924,trig_holdoff[20]}),
    .c({dec_shift[5],trig_holdoff[21]}),
    .ce(mux103_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({dec_shift[4],trig_holdoff[22]}),
    .e({open_n30925,trig_holdoff[23]}),
    .mi({io_mcu_data_pad[0],io_mcu_data_pad[5]}),
    .f({_al_u806_o,_al_u403_o}),
    .q({pat_ctl[0],pat_ctl[5]}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \reg88_b2|reg88_b1  (
    .a({oc_1B[0],trig_holdoff[28]}),
    .b({oc_1B[1],trig_holdoff[29]}),
    .c({oc_1B[2],trig_holdoff[30]}),
    .ce(mux103_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({oc_1B[3],trig_holdoff[31]}),
    .mi(io_mcu_data_pad[2:1]),
    .f({n48,_al_u405_o}),
    .q(pat_ctl[2:1]));  // zaklad.v(2867)
  AL_PHY_MSLICE reg89_b1 (
    .a({_al_u2133_o,_al_u2133_o}),
    .b({_al_u2148_o,_al_u2148_o}),
    .c({_al_u1451_o,_al_u1451_o}),
    .ce(mux105_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1433_o,_al_u1433_o}),
    .mi({open_n30966,enc_pred_ok}),
    .q({open_n30973,o_mcu_data[1]}));  // zaklad.v(3287)
  AL_PHY_MSLICE reg89_b2 (
    .a({_al_u2017_o,_al_u2017_o}),
    .b({_al_u2023_o,_al_u2023_o}),
    .c({_al_u2031_o,_al_u2031_o}),
    .ce(mux105_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1426_o,_al_u1426_o}),
    .mi({open_n30984,_al_u1433_o}),
    .q({open_n30991,o_mcu_data[2]}));  // zaklad.v(3287)
  AL_PHY_MSLICE reg89_b3 (
    .a({_al_u2047_o,_al_u2047_o}),
    .b({_al_u2054_o,_al_u2054_o}),
    .c({_al_u2053_o,_al_u2053_o}),
    .ce(mux105_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u2011_o,_al_u2011_o}),
    .mi({open_n31002,_al_u2055_o}),
    .q({open_n31009,o_mcu_data[3]}));  // zaklad.v(3287)
  // zaklad.v(3287)
  // zaklad.v(3287)
  AL_PHY_MSLICE \reg89_b4|reg89_b6  (
    .a({_al_u2072_o,_al_u2095_o}),
    .b({_al_u2077_o,_al_u2100_o}),
    .c({_al_u2078_o,\sel66_b6_var/B4_0 }),
    .ce(mux105_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u2080_o,mcu_command[5]}),
    .q({o_mcu_data[4],o_mcu_data[6]}));  // zaklad.v(3287)
  AL_PHY_LSLICE \reg89_b5|_al_u1947  (
    .a({_al_u1949_o,_al_u1423_o}),
    .b({_al_u1954_o,_al_u1555_o}),
    .c({_al_u1970_o,mcu_state[0]}),
    .ce(mux105_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1433_o,o_mcu_data[5]}),
    .e({open_n31028,dec_shift[5]}),
    .f({open_n31044,_al_u1947_o}),
    .q({o_mcu_data[5],open_n31048}));  // zaklad.v(3287)
  // zaklad.v(3287)
  // zaklad.v(3287)
  AL_PHY_LSLICE \reg89_b7|reg89_b0  (
    .a({_al_u2112_o,_al_u2157_o}),
    .b({_al_u2118_o,_al_u2166_o}),
    .c({_al_u2125_o,_al_u2171_o}),
    .ce(mux105_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1433_o,_al_u2180_o}),
    .e({open_n31049,mcu_command[5]}),
    .q({o_mcu_data[7],o_mcu_data[0]}));  // zaklad.v(3287)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b0|reg9_b8  (
    .a({_al_u1280_o,adc_q1[8]}),
    .b({_al_u1281_o,_al_u1239_o}),
    .c({adc_q1[0],_al_u1238_o}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q({cap_h[0],cap_h[8]}));  // zaklad.v(1376)
  AL_PHY_LSLICE reg9_b1 (
    .a({open_n31090,_al_u1277_o}),
    .b({open_n31091,_al_u1278_o}),
    .c({open_n31092,adc_q1[1]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({open_n31093,cap_full}),
    .e({open_n31094,cap_sel_x[1]}),
    .q({open_n31115,cap_h[1]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b10|reg9_b9  (
    .a({adc_q1[10],_al_u1235_o}),
    .b({_al_u1275_o,_al_u1236_o}),
    .c({_al_u1274_o,adc_q1[9]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q(cap_h[10:9]));  // zaklad.v(1376)
  AL_PHY_LSLICE reg9_b11 (
    .a({open_n31136,_al_u1271_o}),
    .b({open_n31137,_al_u1272_o}),
    .c({open_n31138,adc_q1[11]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({open_n31139,cap_full}),
    .e({open_n31140,cap_sel_x[1]}),
    .q({open_n31161,cap_h[11]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b12|reg9_b13  (
    .a({_al_u1268_o,_al_u1265_o}),
    .b({_al_u1269_o,_al_u1266_o}),
    .c({adc_q1[12],adc_q1[13]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q({cap_h[12],cap_h[13]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b14|reg9_b15  (
    .a({_al_u1262_o,_al_u1259_o}),
    .b({_al_u1263_o,_al_u1260_o}),
    .c({adc_q1[14],adc_q1[15]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q({cap_h[14],cap_h[15]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b16|reg9_b17  (
    .a({_al_u1328_o,_al_u1325_o}),
    .b({_al_u1329_o,_al_u1326_o}),
    .c({adc_q1[16],adc_q1[17]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[16],cap_h[17]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b18|reg9_b19  (
    .a({_al_u1304_o,_al_u1301_o}),
    .b({_al_u1305_o,_al_u1302_o}),
    .c({adc_q1[18],adc_q1[19]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[18],cap_h[19]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b20|reg9_b21  (
    .a({_al_u1298_o,_al_u1295_o}),
    .b({_al_u1299_o,_al_u1296_o}),
    .c({adc_q1[20],adc_q1[21]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[20],cap_h[21]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b22|reg9_b23  (
    .a({_al_u1292_o,_al_u1290_o}),
    .b({_al_u1293_o,_al_u1289_o}),
    .c({adc_q1[22],adc_q1[23]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[22],cap_h[23]}));  // zaklad.v(1376)
  AL_PHY_LSLICE reg9_b24 (
    .a({open_n31282,_al_u1286_o}),
    .b({open_n31283,_al_u1287_o}),
    .c({open_n31284,adc_q1[24]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({open_n31285,cap_full}),
    .e({open_n31286,cap_sel_x[7]}),
    .q({open_n31307,cap_h[24]}));  // zaklad.v(1376)
  AL_PHY_LSLICE reg9_b25 (
    .a({open_n31308,_al_u1283_o}),
    .b({open_n31309,_al_u1284_o}),
    .c({open_n31310,adc_q1[25]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({open_n31311,cap_full}),
    .e({open_n31312,cap_sel_x[7]}),
    .q({open_n31333,cap_h[25]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b26|reg9_b27  (
    .a({adc_q1[26],_al_u1319_o}),
    .b({_al_u1323_o,_al_u1320_o}),
    .c({_al_u1322_o,adc_q1[27]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[26],cap_h[27]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b28|reg9_b29  (
    .a({_al_u1316_o,_al_u1313_o}),
    .b({_al_u1317_o,_al_u1314_o}),
    .c({adc_q1[28],adc_q1[29]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[28],cap_h[29]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b2|reg9_b3  (
    .a({_al_u1256_o,_al_u1253_o}),
    .b({_al_u1257_o,_al_u1254_o}),
    .c({adc_q1[2],adc_q1[3]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q({cap_h[2],cap_h[3]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b30|reg9_b31  (
    .a({_al_u1310_o,_al_u1307_o}),
    .b({_al_u1311_o,_al_u1308_o}),
    .c({adc_q1[30],adc_q1[31]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[7],cap_sel_x[7]}),
    .q({cap_h[30],cap_h[31]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b4|reg9_b5  (
    .a({_al_u1250_o,_al_u1247_o}),
    .b({adc_q1[4],_al_u1248_o}),
    .c({_al_u1251_o,adc_q1[5]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q({cap_h[4],cap_h[5]}));  // zaklad.v(1376)
  // zaklad.v(1376)
  // zaklad.v(1376)
  AL_PHY_LSLICE \reg9_b6|reg9_b7  (
    .a({_al_u1244_o,_al_u1241_o}),
    .b({_al_u1245_o,_al_u1242_o}),
    .c({adc_q1[6],adc_q1[7]}),
    .ce(p_v),
    .clk(clk_200MHz),
    .d({cap_full,cap_full}),
    .e({cap_sel_x[1],cap_sel_x[1]}),
    .q({cap_h[6],cap_h[7]}));  // zaklad.v(1376)
  AL_PHY_MSLICE relay1_1_reg (
    .a({open_n31454,sample_rate_divider_eff[19]}),
    .b({open_n31455,sample_rate_divider_eff[18]}),
    .c({open_n31456,sample_rate_divider_eff[17]}),
    .ce(u546_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n31457,sample_rate_divider_eff[16]}),
    .mi({open_n31468,io_mcu_data_pad[0]}),
    .f({open_n31470,_al_u1750_o}),
    .q({open_n31474,o_relay1_1_pad}));  // zaklad.v(2867)
  AL_PHY_LSLICE relay2_2_reg (
    .ce(u550_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({open_n31481,io_mcu_data_pad[1]}),
    .f({open_n31499,n556}),
    .q({open_n31503,o_relay2_2_pad}));  // zaklad.v(2867)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_MSLICE \relay2_3_reg|relay2_1_reg  (
    .c({open_n31508,mcu_state[1]}),
    .ce(u550_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({io_mcu_data_pad[2],mcu_state[0]}),
    .mi({open_n31519,io_mcu_data_pad[0]}),
    .f({n557,_al_u671_o}),
    .q({o_relay2_3_pad,o_relay2_1_pad}));  // zaklad.v(2867)
  AL_PHY_GCLK sample_write_clock_gclk_inst (
    .clki(sample_write_clock),
    .clko(sample_write_clock_gclk_net));
  AL_PHY_LSLICE sample_write_clock_reg (
    .a({open_n31524,sample_write_clock}),
    .ce(sample_clock_enable),
    .clk(clk_200MHz),
    .q({open_n31553,sample_write_clock}));  // zaklad.v(1486)
  // address_offset=0;data_offset=0;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_000  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31561,open_n31562,open_n31563,open_n31564,open_n31565,open_n31566,open_n31567,sample_dia[0],open_n31568}),
    .dob({open_n31593,open_n31594,open_n31595,open_n31596,open_n31597,open_n31598,open_n31599,open_n31600,o_adc1A_d[0]}));
  // address_offset=0;data_offset=1;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_001  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31608,open_n31609,open_n31610,open_n31611,open_n31612,open_n31613,open_n31614,sample_dia[1],open_n31615}),
    .dob({open_n31640,open_n31641,open_n31642,open_n31643,open_n31644,open_n31645,open_n31646,open_n31647,o_adc1A_d[1]}));
  // address_offset=0;data_offset=2;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_002  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31655,open_n31656,open_n31657,open_n31658,open_n31659,open_n31660,open_n31661,sample_dia[2],open_n31662}),
    .dob({open_n31687,open_n31688,open_n31689,open_n31690,open_n31691,open_n31692,open_n31693,open_n31694,o_adc1A_d[2]}));
  // address_offset=0;data_offset=3;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_003  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31702,open_n31703,open_n31704,open_n31705,open_n31706,open_n31707,open_n31708,sample_dia[3],open_n31709}),
    .dob({open_n31734,open_n31735,open_n31736,open_n31737,open_n31738,open_n31739,open_n31740,open_n31741,o_adc1A_d[3]}));
  // address_offset=0;data_offset=4;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_004  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31749,open_n31750,open_n31751,open_n31752,open_n31753,open_n31754,open_n31755,sample_dia[4],open_n31756}),
    .dob({open_n31781,open_n31782,open_n31783,open_n31784,open_n31785,open_n31786,open_n31787,open_n31788,o_adc1A_d[4]}));
  // address_offset=0;data_offset=5;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_005  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31796,open_n31797,open_n31798,open_n31799,open_n31800,open_n31801,open_n31802,sample_dia[5],open_n31803}),
    .dob({open_n31828,open_n31829,open_n31830,open_n31831,open_n31832,open_n31833,open_n31834,open_n31835,o_adc1A_d[5]}));
  // address_offset=0;data_offset=6;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_006  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31843,open_n31844,open_n31845,open_n31846,open_n31847,open_n31848,open_n31849,sample_dia[6],open_n31850}),
    .dob({open_n31875,open_n31876,open_n31877,open_n31878,open_n31879,open_n31880,open_n31881,open_n31882,o_adc1A_d[6]}));
  // address_offset=0;data_offset=7;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_007  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31890,open_n31891,open_n31892,open_n31893,open_n31894,open_n31895,open_n31896,sample_dia[7],open_n31897}),
    .dob({open_n31922,open_n31923,open_n31924,open_n31925,open_n31926,open_n31927,open_n31928,open_n31929,o_adc1A_d[7]}));
  // address_offset=0;data_offset=8;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_008  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31937,open_n31938,open_n31939,open_n31940,open_n31941,open_n31942,open_n31943,sample_dia[8],open_n31944}),
    .dob({open_n31969,open_n31970,open_n31971,open_n31972,open_n31973,open_n31974,open_n31975,open_n31976,o_adc1B_d[0]}));
  // address_offset=0;data_offset=9;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_009  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n31984,open_n31985,open_n31986,open_n31987,open_n31988,open_n31989,open_n31990,sample_dia[9],open_n31991}),
    .dob({open_n32016,open_n32017,open_n32018,open_n32019,open_n32020,open_n32021,open_n32022,open_n32023,o_adc1B_d[1]}));
  // address_offset=0;data_offset=10;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_010  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32031,open_n32032,open_n32033,open_n32034,open_n32035,open_n32036,open_n32037,sample_dia[10],open_n32038}),
    .dob({open_n32063,open_n32064,open_n32065,open_n32066,open_n32067,open_n32068,open_n32069,open_n32070,o_adc1B_d[2]}));
  // address_offset=0;data_offset=11;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_011  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32078,open_n32079,open_n32080,open_n32081,open_n32082,open_n32083,open_n32084,sample_dia[11],open_n32085}),
    .dob({open_n32110,open_n32111,open_n32112,open_n32113,open_n32114,open_n32115,open_n32116,open_n32117,o_adc1B_d[3]}));
  // address_offset=0;data_offset=12;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_012  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32125,open_n32126,open_n32127,open_n32128,open_n32129,open_n32130,open_n32131,sample_dia[12],open_n32132}),
    .dob({open_n32157,open_n32158,open_n32159,open_n32160,open_n32161,open_n32162,open_n32163,open_n32164,o_adc1B_d[4]}));
  // address_offset=0;data_offset=13;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_013  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32172,open_n32173,open_n32174,open_n32175,open_n32176,open_n32177,open_n32178,sample_dia[13],open_n32179}),
    .dob({open_n32204,open_n32205,open_n32206,open_n32207,open_n32208,open_n32209,open_n32210,open_n32211,o_adc1B_d[5]}));
  // address_offset=0;data_offset=14;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_014  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32219,open_n32220,open_n32221,open_n32222,open_n32223,open_n32224,open_n32225,sample_dia[14],open_n32226}),
    .dob({open_n32251,open_n32252,open_n32253,open_n32254,open_n32255,open_n32256,open_n32257,open_n32258,o_adc1B_d[6]}));
  // address_offset=0;data_offset=15;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_015  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32266,open_n32267,open_n32268,open_n32269,open_n32270,open_n32271,open_n32272,sample_dia[15],open_n32273}),
    .dob({open_n32298,open_n32299,open_n32300,open_n32301,open_n32302,open_n32303,open_n32304,open_n32305,o_adc1B_d[7]}));
  // address_offset=0;data_offset=16;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_016  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32313,open_n32314,open_n32315,open_n32316,open_n32317,open_n32318,open_n32319,sample_dia[16],open_n32320}),
    .dob({open_n32345,open_n32346,open_n32347,open_n32348,open_n32349,open_n32350,open_n32351,open_n32352,o_adc2A_d[0]}));
  // address_offset=0;data_offset=17;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_017  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32360,open_n32361,open_n32362,open_n32363,open_n32364,open_n32365,open_n32366,sample_dia[17],open_n32367}),
    .dob({open_n32392,open_n32393,open_n32394,open_n32395,open_n32396,open_n32397,open_n32398,open_n32399,o_adc2A_d[1]}));
  // address_offset=0;data_offset=18;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_018  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32407,open_n32408,open_n32409,open_n32410,open_n32411,open_n32412,open_n32413,sample_dia[18],open_n32414}),
    .dob({open_n32439,open_n32440,open_n32441,open_n32442,open_n32443,open_n32444,open_n32445,open_n32446,o_adc2A_d[2]}));
  // address_offset=0;data_offset=19;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_019  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32454,open_n32455,open_n32456,open_n32457,open_n32458,open_n32459,open_n32460,sample_dia[19],open_n32461}),
    .dob({open_n32486,open_n32487,open_n32488,open_n32489,open_n32490,open_n32491,open_n32492,open_n32493,o_adc2A_d[3]}));
  // address_offset=0;data_offset=20;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_020  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32501,open_n32502,open_n32503,open_n32504,open_n32505,open_n32506,open_n32507,sample_dia[20],open_n32508}),
    .dob({open_n32533,open_n32534,open_n32535,open_n32536,open_n32537,open_n32538,open_n32539,open_n32540,o_adc2A_d[4]}));
  // address_offset=0;data_offset=21;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_021  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32548,open_n32549,open_n32550,open_n32551,open_n32552,open_n32553,open_n32554,sample_dia[21],open_n32555}),
    .dob({open_n32580,open_n32581,open_n32582,open_n32583,open_n32584,open_n32585,open_n32586,open_n32587,o_adc2A_d[5]}));
  // address_offset=0;data_offset=22;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_022  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32595,open_n32596,open_n32597,open_n32598,open_n32599,open_n32600,open_n32601,sample_dia[22],open_n32602}),
    .dob({open_n32627,open_n32628,open_n32629,open_n32630,open_n32631,open_n32632,open_n32633,open_n32634,o_adc2A_d[6]}));
  // address_offset=0;data_offset=23;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_023  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32642,open_n32643,open_n32644,open_n32645,open_n32646,open_n32647,open_n32648,sample_dia[23],open_n32649}),
    .dob({open_n32674,open_n32675,open_n32676,open_n32677,open_n32678,open_n32679,open_n32680,open_n32681,o_adc2A_d[7]}));
  // address_offset=0;data_offset=24;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_024  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32689,open_n32690,open_n32691,open_n32692,open_n32693,open_n32694,open_n32695,sample_dia[24],open_n32696}),
    .dob({open_n32721,open_n32722,open_n32723,open_n32724,open_n32725,open_n32726,open_n32727,open_n32728,o_adc2B_d[0]}));
  // address_offset=0;data_offset=25;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_025  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32736,open_n32737,open_n32738,open_n32739,open_n32740,open_n32741,open_n32742,sample_dia[25],open_n32743}),
    .dob({open_n32768,open_n32769,open_n32770,open_n32771,open_n32772,open_n32773,open_n32774,open_n32775,o_adc2B_d[1]}));
  // address_offset=0;data_offset=26;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_026  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32783,open_n32784,open_n32785,open_n32786,open_n32787,open_n32788,open_n32789,sample_dia[26],open_n32790}),
    .dob({open_n32815,open_n32816,open_n32817,open_n32818,open_n32819,open_n32820,open_n32821,open_n32822,o_adc2B_d[2]}));
  // address_offset=0;data_offset=27;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_027  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32830,open_n32831,open_n32832,open_n32833,open_n32834,open_n32835,open_n32836,sample_dia[27],open_n32837}),
    .dob({open_n32862,open_n32863,open_n32864,open_n32865,open_n32866,open_n32867,open_n32868,open_n32869,o_adc2B_d[3]}));
  // address_offset=0;data_offset=28;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_028  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32877,open_n32878,open_n32879,open_n32880,open_n32881,open_n32882,open_n32883,sample_dia[28],open_n32884}),
    .dob({open_n32909,open_n32910,open_n32911,open_n32912,open_n32913,open_n32914,open_n32915,open_n32916,o_adc2B_d[4]}));
  // address_offset=0;data_offset=29;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_029  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32924,open_n32925,open_n32926,open_n32927,open_n32928,open_n32929,open_n32930,sample_dia[29],open_n32931}),
    .dob({open_n32956,open_n32957,open_n32958,open_n32959,open_n32960,open_n32961,open_n32962,open_n32963,o_adc2B_d[5]}));
  // address_offset=0;data_offset=30;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_030  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n32971,open_n32972,open_n32973,open_n32974,open_n32975,open_n32976,open_n32977,sample_dia[30],open_n32978}),
    .dob({open_n33003,open_n33004,open_n33005,open_n33006,open_n33007,open_n33008,open_n33009,open_n33010,o_adc2B_d[6]}));
  // address_offset=0;data_offset=31;depth=8192;width=1;num_section=1;width_per_section=1;section_size=32;working_depth=8192;working_width=1;mode_ecc=0;address_step=1;bytes_in_per_section=1;
  AL_PHY_BRAM \samples/inst_8192x32_sub_000000_031  (
    .addra(sample_write_address),
    .addrb(sample_read_addr_n),
    .cea(n122),
    .clka(sample_write_clock_gclk_net),
    .clkb(i_mcu_clk_pad_gclk_net),
    .dia({open_n33018,open_n33019,open_n33020,open_n33021,open_n33022,open_n33023,open_n33024,sample_dia[31],open_n33025}),
    .dob({open_n33050,open_n33051,open_n33052,open_n33053,open_n33054,open_n33055,open_n33056,open_n33057,o_adc2B_d[7]}));
  AL_PHY_LSLICE \sub0/u11_al_u2448  (
    .a({dec_pc[13],dec_pc[11]}),
    .b({dec_pc[14],dec_pc[12]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub0/c11 ),
    .mi({open_n33059,pat_ctl_t}),
    .f({n155[13],n155[11]}),
    .fco(\sub0/c15 ),
    .fx({n155[14],n155[12]}),
    .q({open_n33072,\u_sq/ct_s [0]}));
  AL_PHY_LSLICE \sub0/u15_al_u2449  (
    .a({dec_pc[17],dec_pc[15]}),
    .b({dec_pc[18],dec_pc[16]}),
    .c(2'b11),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub0/c15 ),
    .mi(pat_wr_n[2:1]),
    .f({n155[17],n155[15]}),
    .fx({n155[18],n155[16]}),
    .q(\u_sq/sh0 [18:17]));
  AL_PHY_LSLICE \sub0/u3_al_u2446  (
    .a({dec_pc[5],dec_pc[3]}),
    .b({dec_pc[6],dec_pc[4]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub0/c3 ),
    .f({n155[5],n155[3]}),
    .fco(\sub0/c7 ),
    .fx({n155[6],n155[4]}));
  AL_PHY_LSLICE \sub0/u7_al_u2447  (
    .a({dec_pc[9],dec_pc[7]}),
    .b({dec_pc[10],dec_pc[8]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub0/c7 ),
    .f({n155[9],n155[7]}),
    .fco(\sub0/c11 ),
    .fx({n155[10],n155[8]}));
  AL_PHY_LSLICE \sub0/ucin_al_u2445  (
    .a({dec_pc[1],1'b0}),
    .b({dec_pc[2],dec_pc[0]}),
    .c(2'b11),
    .ce(mux74_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b01),
    .e(2'b01),
    .mi(io_mcu_data_pad[7:6]),
    .f({n155[1],open_n33135}),
    .fco(\sub0/c3 ),
    .fx({n155[2],n155[0]}),
    .q(trigger_level[7:6]));
  AL_PHY_MSLICE \sub1/u0|sub1/ucin  (
    .a({p_wa[0],1'b0}),
    .b({rd_200[0],open_n33136}),
    .ce(n181),
    .clk(clk_200MHz),
    .mi({open_n33151,log_rd[4]}),
    .sr(q_rs2),
    .f({n192[0],open_n33152}),
    .fco(\sub1/c1 ),
    .q({open_n33155,rd_200[4]}));
  AL_PHY_MSLICE \sub1/u10|sub1/u9  (
    .a(p_wa[10:9]),
    .b(rd_200[10:9]),
    .clk(clk_200MHz),
    .fci(\sub1/c9 ),
    .mi({open_n33170,p_wa[8]}),
    .f(n192[10:9]),
    .fco(\sub1/c11 ),
    .q({open_n33174,lg_wa[8]}));
  AL_PHY_MSLICE \sub1/u12|sub1/u11  (
    .a(p_wa[12:11]),
    .b(rd_200[12:11]),
    .ce(n179),
    .clk(clk_200MHz),
    .fci(\sub1/c11 ),
    .mi(sample_write_address[12:11]),
    .f(n192[12:11]),
    .q(p_wa[12:11]));
  AL_PHY_MSLICE \sub1/u2|sub1/u1  (
    .a(p_wa[2:1]),
    .b(rd_200[2:1]),
    .ce(n181),
    .clk(clk_200MHz),
    .fci(\sub1/c1 ),
    .mi(log_rd[6:5]),
    .sr(q_rs2),
    .f(n192[2:1]),
    .fco(\sub1/c3 ),
    .q(rd_200[6:5]));
  AL_PHY_MSLICE \sub1/u4|sub1/u3  (
    .a(p_wa[4:3]),
    .b(rd_200[4:3]),
    .ce(n181),
    .clk(clk_200MHz),
    .fci(\sub1/c3 ),
    .mi({open_n33220,log_rd[7]}),
    .sr(q_rs2),
    .f(n192[4:3]),
    .fco(\sub1/c5 ),
    .q({open_n33223,rd_200[7]}));
  AL_PHY_MSLICE \sub1/u6|sub1/u5  (
    .a(p_wa[6:5]),
    .b(rd_200[6:5]),
    .ce(n181),
    .clk(clk_200MHz),
    .fci(\sub1/c5 ),
    .mi({log_rd[9],log_rd[10]}),
    .sr(q_rs2),
    .f(n192[6:5]),
    .fco(\sub1/c7 ),
    .q({rd_200[9],rd_200[10]}));
  AL_PHY_MSLICE \sub1/u8|sub1/u7  (
    .a(p_wa[8:7]),
    .b(rd_200[8:7]),
    .ce(n181),
    .clk(clk_200MHz),
    .fci(\sub1/c7 ),
    .mi({open_n33252,log_rd[11]}),
    .sr(q_rs2),
    .f(n192[8:7]),
    .fco(\sub1/c9 ),
    .q({open_n33255,rd_200[11]}));
  AL_PHY_MSLICE \sub10/u0|sub10/ucin  (
    .a({\dec_ch2/pa [0],1'b0}),
    .b({adc2A_w[0],open_n33256}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/i3 [26],\dec_ch2/i3 [23]}),
    .f({n314[0],open_n33272}),
    .fco(\sub10/c1 ),
    .q({\dec_ch2/d0 [26],\dec_ch2/d0 [23]}));
  AL_PHY_MSLICE \sub10/u2|sub10/u1  (
    .a(\dec_ch2/pa [2:1]),
    .b(adc2A_w[2:1]),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub10/c1 ),
    .mi(\dec_ch2/i3 [33:32]),
    .f(n314[2:1]),
    .fco(\sub10/c3 ),
    .q(\dec_ch2/d0 [33:32]));
  AL_PHY_MSLICE \sub10/u4|sub10/u3  (
    .a(\dec_ch2/pa [4:3]),
    .b(adc2A_w[4:3]),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub10/c3 ),
    .mi(\dec_ch2/i3 [37:36]),
    .f(n314[4:3]),
    .fco(\sub10/c5 ),
    .q(\dec_ch2/d0 [37:36]));
  AL_PHY_MSLICE \sub10/u6|sub10/u5  (
    .a(\dec_ch2/pa [6:5]),
    .b(adc2A_w[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub10/c5 ),
    .mi({open_n33321,adc2A_w[6]}),
    .f(n314[6:5]),
    .fco(\sub10/c7 ),
    .q({open_n33325,\dec_ch2/pa [6]}));
  AL_PHY_MSLICE \sub10/u7_al_u2467  (
    .a({open_n33326,\dec_ch2/pa [7]}),
    .b({open_n33327,adc2A_w[7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub10/c7 ),
    .mi({open_n33342,adc2A_w[7]}),
    .f({open_n33344,n314[7]}),
    .q({open_n33348,\dec_ch2/pa [7]}));
  AL_PHY_MSLICE \sub11/u0|sub11/ucin  (
    .a({adc2B_w[0],1'b0}),
    .b({\dec_ch2/pb [0],open_n33349}),
    .f({n324[0],open_n33369}),
    .fco(\sub11/c1 ));
  AL_PHY_MSLICE \sub11/u2|sub11/u1  (
    .a(adc2B_w[2:1]),
    .b(\dec_ch2/pb [2:1]),
    .fci(\sub11/c1 ),
    .f(n324[2:1]),
    .fco(\sub11/c3 ));
  AL_PHY_MSLICE \sub11/u4|sub11/u3  (
    .a(adc2B_w[4:3]),
    .b(\dec_ch2/pb [4:3]),
    .fci(\sub11/c3 ),
    .f(n324[4:3]),
    .fco(\sub11/c5 ));
  AL_PHY_MSLICE \sub11/u6|sub11/u5  (
    .a(adc2B_w[6:5]),
    .b(\dec_ch2/pb [6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub11/c5 ),
    .mi({open_n33432,adc2B_w[0]}),
    .f(n324[6:5]),
    .fco(\sub11/c7 ),
    .q({open_n33436,\dec_ch2/pb [0]}));
  AL_PHY_MSLICE \sub11/u7_al_u2468  (
    .a({open_n33437,adc2B_w[7]}),
    .b({open_n33438,\dec_ch2/pb [7]}),
    .fci(\sub11/c7 ),
    .f({open_n33457,n324[7]}));
  AL_PHY_MSLICE \sub12/u0|sub12/ucin  (
    .a({\dec_ch2/pb [0],1'b0}),
    .b({adc2B_w[0],open_n33463}),
    .clk(sample_write_clock_gclk_net),
    .mi({open_n33479,adc2B_w[7]}),
    .f({n325[0],open_n33481}),
    .fco(\sub12/c1 ),
    .q({open_n33484,\dec_ch2/pb [7]}));
  AL_PHY_MSLICE \sub12/u2|sub12/u1  (
    .a(\dec_ch2/pb [2:1]),
    .b(adc2B_w[2:1]),
    .ce(mux76_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub12/c1 ),
    .mi({open_n33498,io_mcu_data_pad[2]}),
    .f(n325[2:1]),
    .fco(\sub12/c3 ),
    .q({open_n33502,trig_holdoff[10]}));
  AL_PHY_MSLICE \sub12/u4|sub12/u3  (
    .a(\dec_ch2/pb [4:3]),
    .b(adc2B_w[4:3]),
    .ce(mux76_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub12/c3 ),
    .mi(io_mcu_data_pad[1:0]),
    .f(n325[4:3]),
    .fco(\sub12/c5 ),
    .q(trig_holdoff[9:8]));
  AL_PHY_MSLICE \sub12/u6|sub12/u5  (
    .a(\dec_ch2/pb [6:5]),
    .b(adc2B_w[6:5]),
    .ce(mux76_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub12/c5 ),
    .mi(io_mcu_data_pad[7:6]),
    .f(n325[6:5]),
    .fco(\sub12/c7 ),
    .q(trig_holdoff[15:14]));
  AL_PHY_MSLICE \sub12/u7_al_u2469  (
    .a({open_n33535,\dec_ch2/pb [7]}),
    .b({open_n33536,adc2B_w[7]}),
    .ce(mux76_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub12/c7 ),
    .mi(io_mcu_data_pad[7:6]),
    .f({open_n33551,n325[7]}),
    .q(trig_holdoff[23:22]));
  AL_PHY_LSLICE \sub13/u11_al_u2433  (
    .a({trig_holdoff[14],trig_holdoff[12]}),
    .b({trig_holdoff[15],trig_holdoff[13]}),
    .c(2'b11),
    .ce(mux76_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c11 ),
    .mi(io_mcu_data_pad[1:0]),
    .f({n4[13],n4[11]}),
    .fco(\sub13/c15 ),
    .fx({n4[14],n4[12]}),
    .q(trig_holdoff[25:24]));
  AL_PHY_LSLICE \sub13/u15_al_u2434  (
    .a({trig_holdoff[18],trig_holdoff[16]}),
    .b({trig_holdoff[19],trig_holdoff[17]}),
    .c(2'b11),
    .ce(mux76_b24_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c15 ),
    .mi(io_mcu_data_pad[3:2]),
    .f({n4[17],n4[15]}),
    .fco(\sub13/c19 ),
    .fx({n4[18],n4[16]}),
    .q(trig_holdoff[27:26]));
  AL_PHY_LSLICE \sub13/u19_al_u2435  (
    .a({trig_holdoff[22],trig_holdoff[20]}),
    .b({trig_holdoff[23],trig_holdoff[21]}),
    .c(2'b11),
    .ce(mux101_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c19 ),
    .mi({open_n33579,io_mcu_data_pad[3]}),
    .f({n4[21],n4[19]}),
    .fco(\sub13/c23 ),
    .fx({n4[22],n4[20]}),
    .q({open_n33592,pat_wr_n[3]}));
  AL_PHY_LSLICE \sub13/u23_al_u2436  (
    .a({trig_holdoff[26],trig_holdoff[24]}),
    .b({trig_holdoff[27],trig_holdoff[25]}),
    .c(2'b11),
    .ce(mux101_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c23 ),
    .mi({open_n33593,io_mcu_data_pad[2]}),
    .f({n4[25],n4[23]}),
    .fco(\sub13/c27 ),
    .fx({n4[26],n4[24]}),
    .q({open_n33606,pat_wr_n[10]}));
  AL_PHY_LSLICE \sub13/u27_al_u2437  (
    .a({trig_holdoff[30],trig_holdoff[28]}),
    .b({trig_holdoff[31],trig_holdoff[29]}),
    .c(2'b11),
    .ce(mux101_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c27 ),
    .mi(io_mcu_data_pad[4:3]),
    .f({n4[29],n4[27]}),
    .fco(\sub13/c31 ),
    .fx({n4[30],n4[28]}),
    .q(pat_wr_n[12:11]));
  AL_PHY_LSLICE \sub13/u3_al_u2431  (
    .a({trig_holdoff[6],trig_holdoff[4]}),
    .b({trig_holdoff[7],trig_holdoff[5]}),
    .c(2'b11),
    .ce(mux76_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c3 ),
    .mi(io_mcu_data_pad[5:4]),
    .f({n4[5],n4[3]}),
    .fco(\sub13/c7 ),
    .fx({n4[6],n4[4]}),
    .q(trig_holdoff[21:20]));
  AL_PHY_LSLICE \sub13/u7_al_u2432  (
    .a({trig_holdoff[10],trig_holdoff[8]}),
    .b({trig_holdoff[11],trig_holdoff[9]}),
    .c(2'b11),
    .ce(mux72_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub13/c7 ),
    .mi({io_mcu_data_pad[0],io_mcu_data_pad[3]}),
    .f({n4[9],n4[7]}),
    .fco(\sub13/c11 ),
    .fx({n4[10],n4[8]}),
    .q({sample_rate_divider[8],sample_rate_divider[11]}));
  AL_PHY_LSLICE \sub13/ucin_al_u2430  (
    .a({trig_holdoff[2],1'b0}),
    .b({trig_holdoff[3],trig_holdoff[1]}),
    .c(2'b11),
    .ce(mux76_b16_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d(2'b01),
    .e(2'b01),
    .mi(io_mcu_data_pad[2:1]),
    .f({n4[1],open_n33656}),
    .fco(\sub13/c3 ),
    .fx({n4[2],n4[0]}),
    .q(trig_holdoff[18:17]));
  AL_PHY_LSLICE \sub13/ucout_al_u2438  (
    .c(2'b11),
    .ce(mux101_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub13/c31 ),
    .mi(io_mcu_data_pad[6:5]),
    .f({open_n33677,n4[31]}),
    .q(pat_wr_n[14:13]));
  AL_PHY_LSLICE \sub14/u11_al_u2397  (
    .a({ho_cnt[13],ho_cnt[11]}),
    .b({ho_cnt[14],ho_cnt[12]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c11 ),
    .f({n369[13],n369[11]}),
    .fco(\sub14/c15 ),
    .fx({n369[14],n369[12]}));
  AL_PHY_LSLICE \sub14/u15_al_u2398  (
    .a({ho_cnt[17],ho_cnt[15]}),
    .b({ho_cnt[18],ho_cnt[16]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c15 ),
    .f({n369[17],n369[15]}),
    .fco(\sub14/c19 ),
    .fx({n369[18],n369[16]}));
  AL_PHY_LSLICE \sub14/u19_al_u2399  (
    .a({ho_cnt[21],ho_cnt[19]}),
    .b({ho_cnt[22],ho_cnt[20]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c19 ),
    .f({n369[21],n369[19]}),
    .fco(\sub14/c23 ),
    .fx({n369[22],n369[20]}));
  AL_PHY_LSLICE \sub14/u23_al_u2400  (
    .a({ho_cnt[25],ho_cnt[23]}),
    .b({ho_cnt[26],ho_cnt[24]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c23 ),
    .f({n369[25],n369[23]}),
    .fco(\sub14/c27 ),
    .fx({n369[26],n369[24]}));
  AL_PHY_LSLICE \sub14/u27_al_u2401  (
    .a({ho_cnt[29],ho_cnt[27]}),
    .b({ho_cnt[30],ho_cnt[28]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c27 ),
    .f({n369[29],n369[27]}),
    .fco(\sub14/c31 ),
    .fx({n369[30],n369[28]}));
  AL_PHY_LSLICE \sub14/u31_al_u2402  (
    .a({open_n33771,ho_cnt[31]}),
    .b({open_n33772,ho_cnt[32]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d({open_n33774,1'b0}),
    .e({open_n33775,1'b0}),
    .fci(\sub14/c31 ),
    .mi({open_n33776,cap_st[0]}),
    .f({open_n33789,n369[31]}),
    .fx({open_n33791,n369[32]}),
    .q({open_n33792,p_v}));
  AL_PHY_LSLICE \sub14/u3_al_u2395  (
    .a({ho_cnt[5],ho_cnt[3]}),
    .b({ho_cnt[6],ho_cnt[4]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c3 ),
    .f({n369[5],n369[3]}),
    .fco(\sub14/c7 ),
    .fx({n369[6],n369[4]}));
  AL_PHY_LSLICE \sub14/u7_al_u2396  (
    .a({ho_cnt[9],ho_cnt[7]}),
    .b({ho_cnt[10],ho_cnt[8]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\sub14/c7 ),
    .f({n369[9],n369[7]}),
    .fco(\sub14/c11 ),
    .fx({n369[10],n369[8]}));
  AL_PHY_LSLICE \sub14/ucin_al_u2394  (
    .a({ho_cnt[1],1'b0}),
    .b({ho_cnt[2],ho_cnt[0]}),
    .c(2'b11),
    .ce(n139),
    .clk(clk_200MHz),
    .d(2'b01),
    .e(2'b01),
    .mi({open_n33830,1'b1}),
    .sr(sample_system_reset),
    .f({n369[1],open_n33842}),
    .fco(\sub14/c3 ),
    .fx({n369[2],n369[0]}),
    .q({open_n33843,enc_err}));
  AL_PHY_MSLICE \sub15/u0|sub15/ucin  (
    .a({n167[0],1'b0}),
    .b({post_words[0],open_n33844}),
    .ce(mux71_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n33859,io_mcu_data_pad[7]}),
    .f({n396[0],open_n33861}),
    .fco(\sub15/c1 ),
    .q({open_n33864,total_samples[7]}));
  AL_PHY_MSLICE \sub15/u10|sub15/u9  (
    .a(n167[10:9]),
    .b(post_words[10:9]),
    .fci(\sub15/c9 ),
    .f(n396[10:9]),
    .fco(\sub15/c11 ));
  AL_PHY_MSLICE \sub15/u12|sub15/u11  (
    .a(n167[12:11]),
    .b(post_words[12:11]),
    .fci(\sub15/c11 ),
    .f(n396[12:11]));
  AL_PHY_MSLICE \sub15/u2|sub15/u1  (
    .a(n167[2:1]),
    .b(post_words[2:1]),
    .ce(mux71_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub15/c1 ),
    .mi(io_mcu_data_pad[4:3]),
    .f(n396[2:1]),
    .fco(\sub15/c3 ),
    .q(total_samples[12:11]));
  AL_PHY_MSLICE \sub15/u4|sub15/u3  (
    .a(n167[4:3]),
    .b(post_words[4:3]),
    .fci(\sub15/c3 ),
    .f(n396[4:3]),
    .fco(\sub15/c5 ));
  AL_PHY_MSLICE \sub15/u6|sub15/u5  (
    .a(n167[6:5]),
    .b(post_words[6:5]),
    .fci(\sub15/c5 ),
    .f(n396[6:5]),
    .fco(\sub15/c7 ));
  AL_PHY_MSLICE \sub15/u8|sub15/u7  (
    .a(n167[8:7]),
    .b(post_words[8:7]),
    .fci(\sub15/c7 ),
    .f(n396[8:7]),
    .fco(\sub15/c9 ));
  AL_PHY_MSLICE \sub2/u0|sub2/ucin  (
    .a({trigger_read_address[0],1'b0}),
    .b({trigger_address[0],open_n33992}),
    .f({addr_delta[0],open_n34012}),
    .fco(\sub2/c1 ));
  AL_PHY_MSLICE \sub2/u10|sub2/u9  (
    .a(trigger_read_address[10:9]),
    .b(trigger_address[10:9]),
    .fci(\sub2/c9 ),
    .f(addr_delta[10:9]),
    .fco(\sub2/c11 ));
  AL_PHY_MSLICE \sub2/u12|sub2/u11  (
    .a(trigger_read_address[12:11]),
    .b(trigger_address[12:11]),
    .fci(\sub2/c11 ),
    .f(addr_delta[12:11]));
  AL_PHY_MSLICE \sub2/u2|sub2/u1  (
    .a(trigger_read_address[2:1]),
    .b(trigger_address[2:1]),
    .fci(\sub2/c1 ),
    .f(addr_delta[2:1]),
    .fco(\sub2/c3 ));
  AL_PHY_MSLICE \sub2/u4|sub2/u3  (
    .a(trigger_read_address[4:3]),
    .b(trigger_address[4:3]),
    .fci(\sub2/c3 ),
    .f(addr_delta[4:3]),
    .fco(\sub2/c5 ));
  AL_PHY_MSLICE \sub2/u6|sub2/u5  (
    .a(trigger_read_address[6:5]),
    .b(trigger_address[6:5]),
    .fci(\sub2/c5 ),
    .f(addr_delta[6:5]),
    .fco(\sub2/c7 ));
  AL_PHY_MSLICE \sub2/u8|sub2/u7  (
    .a(trigger_read_address[8:7]),
    .b(trigger_address[8:7]),
    .fci(\sub2/c7 ),
    .f(addr_delta[8:7]),
    .fco(\sub2/c9 ));
  AL_PHY_MSLICE \sub3/u0|sub3/ucin  (
    .a({total_samples[0],1'b0}),
    .b({pretrigger_samples[0],open_n34150}),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch2/c2 [40:39]),
    .f({post_words[0],open_n34166}),
    .fco(\sub3/c1 ),
    .q(\dec_ch2/c2p [40:39]));
  AL_PHY_MSLICE \sub3/u10|sub3/u9  (
    .a(total_samples[10:9]),
    .b(pretrigger_samples[10:9]),
    .fci(\sub3/c9 ),
    .f(post_words[10:9]),
    .fco(\sub3/c11 ));
  AL_PHY_MSLICE \sub3/u12|sub3/u11  (
    .a(total_samples[12:11]),
    .b(pretrigger_samples[12:11]),
    .fci(\sub3/c11 ),
    .f(post_words[12:11]));
  AL_PHY_MSLICE \sub3/u2|sub3/u1  (
    .a(total_samples[2:1]),
    .b(pretrigger_samples[2:1]),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub3/c1 ),
    .mi(\dec_ch2/c2 [42:41]),
    .f(post_words[2:1]),
    .fco(\sub3/c3 ),
    .q(\dec_ch2/c2p [42:41]));
  AL_PHY_MSLICE \sub3/u4|sub3/u3  (
    .a(total_samples[4:3]),
    .b(pretrigger_samples[4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub3/c3 ),
    .mi({open_n34244,\dec_sv[2]_hfnopt2_3 }),
    .f(post_words[4:3]),
    .fco(\sub3/c5 ),
    .q({open_n34248,\dec_sv[3]_hfnopt2_4 }));
  AL_PHY_MSLICE \sub3/u6|sub3/u5  (
    .a(total_samples[6:5]),
    .b(pretrigger_samples[6:5]),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub3/c5 ),
    .mi(\dec_ch2/c2 [46:45]),
    .f(post_words[6:5]),
    .fco(\sub3/c7 ),
    .q(\dec_ch2/c2p [46:45]));
  AL_PHY_MSLICE \sub3/u8|sub3/u7  (
    .a(total_samples[8:7]),
    .b(pretrigger_samples[8:7]),
    .ce(\dec_sv[3]_hfnopt2_4 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub3/c7 ),
    .mi(\dec_ch2/c2 [44:43]),
    .f(post_words[8:7]),
    .fco(\sub3/c9 ),
    .q(\dec_ch2/c2p [44:43]));
  AL_PHY_MSLICE \sub4/u0|sub4/ucin  (
    .a({trigger_level[0],1'b0}),
    .b({trig_hyst[0],open_n34281}),
    .ce(mux78_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .mi({open_n34296,io_mcu_data_pad[2]}),
    .f({hyst_lo9[0],open_n34298}),
    .fco(\sub4/c1 ),
    .q({open_n34301,ch2_offset[10]}));
  AL_PHY_MSLICE \sub4/u2|sub4/u1  (
    .a(trigger_level[2:1]),
    .b(trig_hyst[2:1]),
    .ce(mux77_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub4/c1 ),
    .mi({io_mcu_data_pad[0],io_mcu_data_pad[3]}),
    .f(hyst_lo9[2:1]),
    .fco(\sub4/c3 ),
    .q({ch1_offset[8],ch1_offset[11]}));
  AL_PHY_MSLICE \sub4/u4|sub4/u3  (
    .a(trigger_level[4:3]),
    .b(trig_hyst[4:3]),
    .ce(mux78_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub4/c3 ),
    .mi(io_mcu_data_pad[5:4]),
    .f(hyst_lo9[4:3]),
    .fco(\sub4/c5 ),
    .q(ch2_offset[13:12]));
  AL_PHY_MSLICE \sub4/u6|sub4/u5  (
    .a(trigger_level[6:5]),
    .b(trig_hyst[6:5]),
    .ce(mux79_b10_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .fci(\sub4/c5 ),
    .mi(io_mcu_data_pad[6:5]),
    .f(hyst_lo9[6:5]),
    .fco(\sub4/c7 ),
    .q(display_brigthness[14:13]));
  AL_PHY_MSLICE \sub4/ucout|sub4/u7  (
    .a({open_n34350,trigger_level[7]}),
    .b({open_n34351,trig_hyst[7]}),
    .fci(\sub4/c7 ),
    .f(hyst_lo9[8:7]));
  AL_PHY_MSLICE \sub5/u0|sub5/ucin  (
    .a({adc1A_w[0],1'b0}),
    .b({\dec_ch1/pa [0],open_n34375}),
    .clk(sample_write_clock_gclk_net),
    .mi({cap_h[5],adc1A_w[0]}),
    .f({n291[0],open_n34392}),
    .fco(\sub5/c1 ),
    .q({adc1A_w[5],\dec_ch1/pa [0]}));
  AL_PHY_MSLICE \sub5/u2|sub5/u1  (
    .a(adc1A_w[2:1]),
    .b(\dec_ch1/pa [2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub5/c1 ),
    .mi({\dec_ch2/n70 [14],\dec_ch2/n70 [12]}),
    .f(n291[2:1]),
    .fco(\sub5/c3 ),
    .q({\dec_ch2/i1 [14],\dec_ch2/i1 [12]}));
  AL_PHY_MSLICE \sub5/u4|sub5/u3  (
    .a(adc1A_w[4:3]),
    .b(\dec_ch1/pa [4:3]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub5/c3 ),
    .mi({\dec_ch2/n70 [16],adc1A_w[2]}),
    .f(n291[4:3]),
    .fco(\sub5/c5 ),
    .q({\dec_ch2/i1 [16],\dec_ch1/pa [2]}));
  AL_PHY_MSLICE \sub5/u6|sub5/u5  (
    .a(adc1A_w[6:5]),
    .b(\dec_ch1/pa [6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub5/c5 ),
    .mi(\dec_ch2/n70 [18:17]),
    .f(n291[6:5]),
    .fco(\sub5/c7 ),
    .q(\dec_ch2/i1 [18:17]));
  AL_PHY_MSLICE \sub5/u7_al_u2470  (
    .a({open_n34446,adc1A_w[7]}),
    .b({open_n34447,\dec_ch1/pa [7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub5/c7 ),
    .mi({n152,\dec_ch2/n70 [22]}),
    .f({open_n34463,n291[7]}),
    .q({\dec_sv[0]_hfnopt2_1 ,\dec_ch2/i1 [22]}));
  AL_PHY_MSLICE \sub6/u0|sub6/ucin  (
    .a({\dec_ch1/pa [0],1'b0}),
    .b({adc1A_w[0],open_n34467}),
    .clk(sample_write_clock_gclk_net),
    .mi(adc1A_w[4:3]),
    .f({n292[0],open_n34484}),
    .fco(\sub6/c1 ),
    .q(\dec_ch1/pa [4:3]));
  AL_PHY_MSLICE \sub6/u2|sub6/u1  (
    .a(\dec_ch1/pa [2:1]),
    .b(adc1A_w[2:1]),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub6/c1 ),
    .mi({\dec_ch1/n86 [37],\dec_ch1/n86 [33]}),
    .f(n292[2:1]),
    .fco(\sub6/c3 ),
    .q({\dec_ch1/c3 [37],\dec_ch1/c3 [33]}));
  AL_PHY_MSLICE \sub6/u4|sub6/u3  (
    .a(\dec_ch1/pa [4:3]),
    .b(adc1A_w[4:3]),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub6/c3 ),
    .mi({open_n34516,\dec_ch2/rmn [0]}),
    .f(n292[4:3]),
    .fco(\sub6/c5 ),
    .q({open_n34520,\dec_ch2/pkw [0]}));
  AL_PHY_MSLICE \sub6/u6|sub6/u5  (
    .a(\dec_ch1/pa [6:5]),
    .b(adc1A_w[6:5]),
    .ce(\dec_sv[3]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub6/c5 ),
    .mi(\dec_ch1/n86 [8:7]),
    .f(n292[6:5]),
    .fco(\sub6/c7 ),
    .q(\dec_ch1/c3 [8:7]));
  AL_PHY_MSLICE \sub6/u7_al_u2471  (
    .a({open_n34537,\dec_ch1/pa [7]}),
    .b({open_n34538,adc1A_w[7]}),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub6/c7 ),
    .mi({open_n34552,\dec_ch2/rmn [4]}),
    .f({open_n34554,n292[7]}),
    .q({open_n34558,\dec_ch2/pkw [4]}));
  AL_PHY_MSLICE \sub7/u0|sub7/ucin  (
    .a({adc1B_w[0],1'b0}),
    .b({\dec_ch1/pb [0],open_n34559}),
    .clk(sample_write_clock_gclk_net),
    .mi({cap_h[8],\dec_ch1/pb [7]}),
    .f({n302[0],open_n34576}),
    .fco(\sub7/c1 ),
    .q({adc1B_w[0],pair_e1[7]}));
  AL_PHY_MSLICE \sub7/u2|sub7/u1  (
    .a(adc1B_w[2:1]),
    .b(\dec_ch1/pb [2:1]),
    .ce(n152),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub7/c1 ),
    .mi({open_n34592,\dec_ch2/rmx [3]}),
    .f(n302[2:1]),
    .fco(\sub7/c3 ),
    .q({open_n34596,\dec_ch2/pkw [11]}));
  AL_PHY_MSLICE \sub7/u4|sub7/u3  (
    .a(adc1B_w[4:3]),
    .b(\dec_ch1/pb [4:3]),
    .ce(\dec_sv[0]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub7/c3 ),
    .mi({open_n34610,\dec_ch2/pkw [11]}),
    .f(n302[4:3]),
    .fco(\sub7/c5 ),
    .q({open_n34614,\dec_ch2/pk0 [11]}));
  AL_PHY_MSLICE \sub7/u6|sub7/u5  (
    .a(adc1B_w[6:5]),
    .b(\dec_ch1/pb [6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub7/c5 ),
    .mi({cap_h[2],adc1B_w[7]}),
    .f(n302[6:5]),
    .fco(\sub7/c7 ),
    .q({adc1A_w[2],\dec_ch1/pb [7]}));
  AL_PHY_MSLICE \sub7/u7_al_u2472  (
    .a({open_n34632,adc1B_w[7]}),
    .b({open_n34633,\dec_ch1/pb [7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub7/c7 ),
    .mi(cap_h[4:3]),
    .f({open_n34649,n302[7]}),
    .q(adc1A_w[4:3]));
  AL_PHY_MSLICE \sub8/u0|sub8/ucin  (
    .a({\dec_ch1/pb [0],1'b0}),
    .b({adc1B_w[0],open_n34653}),
    .clk(clk_200MHz),
    .mi({adc_d2[8],adc_d2[1]}),
    .f({n303[0],open_n34670}),
    .fco(\sub8/c1 ),
    .q({adc_dd2[8],adc_dd2[1]}));
  AL_PHY_MSLICE \sub8/u2|sub8/u1  (
    .a(\dec_ch1/pb [2:1]),
    .b(adc1B_w[2:1]),
    .clk(clk_200MHz),
    .fci(\sub8/c1 ),
    .mi({adc_d2[0],adc_d1[8]}),
    .f(n303[2:1]),
    .fco(\sub8/c3 ),
    .q({adc_dd2[0],adc_dd1[8]}));
  AL_PHY_MSLICE \sub8/u4|sub8/u3  (
    .a(\dec_ch1/pb [4:3]),
    .b(adc1B_w[4:3]),
    .clk(clk_200MHz),
    .fci(\sub8/c3 ),
    .mi(adc_d1[1:0]),
    .f(n303[4:3]),
    .fco(\sub8/c5 ),
    .q(adc_dd1[1:0]));
  AL_PHY_MSLICE \sub8/u6|sub8/u5  (
    .a(\dec_ch1/pb [6:5]),
    .b(adc1B_w[6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub8/c5 ),
    .mi(cap_h[14:13]),
    .f(n303[6:5]),
    .fco(\sub8/c7 ),
    .q(adc1B_w[6:5]));
  AL_PHY_MSLICE \sub8/u7_al_u2473  (
    .a({open_n34724,\dec_ch1/pb [7]}),
    .b({open_n34725,adc1B_w[7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub8/c7 ),
    .mi({cap_h[15],cap_h[12]}),
    .f({open_n34741,n303[7]}),
    .q({adc1B_w[7],adc1B_w[4]}));
  AL_PHY_MSLICE \sub9/u0|sub9/ucin  (
    .a({adc2A_w[0],1'b0}),
    .b({\dec_ch2/pa [0],open_n34745}),
    .clk(sample_write_clock_gclk_net),
    .mi({\dec_ch2/n70 [47],\dec_ch2/n70 [44]}),
    .f({n313[0],open_n34762}),
    .fco(\sub9/c1 ),
    .q({\dec_ch2/i1 [47],\dec_ch2/i1 [44]}));
  AL_PHY_MSLICE \sub9/u2|sub9/u1  (
    .a(adc2A_w[2:1]),
    .b(\dec_ch2/pa [2:1]),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub9/c1 ),
    .mi({\dec_ch2/i3 [30],\dec_ch2/i3 [27]}),
    .f(n313[2:1]),
    .fco(\sub9/c3 ),
    .q({\dec_ch2/d0 [30],\dec_ch2/d0 [27]}));
  AL_PHY_MSLICE \sub9/u4|sub9/u3  (
    .a(adc2A_w[4:3]),
    .b(\dec_ch2/pa [4:3]),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub9/c3 ),
    .mi(\dec_ch2/i3 [35:34]),
    .f(n313[4:3]),
    .fco(\sub9/c5 ),
    .q(\dec_ch2/d0 [35:34]));
  AL_PHY_MSLICE \sub9/u6|sub9/u5  (
    .a(adc2A_w[6:5]),
    .b(\dec_ch2/pa [6:5]),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub9/c5 ),
    .mi({\dec_ch2/i3 [40],\dec_ch2/i3 [38]}),
    .f(n313[6:5]),
    .fco(\sub9/c7 ),
    .q({\dec_ch2/d0 [40],\dec_ch2/d0 [38]}));
  AL_PHY_MSLICE \sub9/u7_al_u2474  (
    .a({open_n34813,adc2A_w[7]}),
    .b({open_n34814,\dec_ch2/pa [7]}),
    .ce(dec_sv[0]),
    .clk(sample_write_clock_gclk_net),
    .fci(\sub9/c7 ),
    .mi(\dec_ch2/i3 [42:41]),
    .f({open_n34829,n313[7]}),
    .q(\dec_ch2/d0 [42:41]));
  // zaklad.v(2184)
  // zaklad.v(2184)
  AL_PHY_LSLICE \swe_d_reg|adv_d_reg  (
    .a({open_n34833,_al_u2030_o}),
    .b({_al_u1596_o,trig_type[2]}),
    .c({mcu_command[3],\lt21/o_1_lutinv }),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1556_o,_al_u1966_o}),
    .e({open_n34835,trig_src_ext}),
    .mi({sample_write_enable,swc_adv}),
    .f({mux99_b0_sel_is_3_o,_al_u2033_o}),
    .q({swe_d,adv_d}));  // zaklad.v(2184)
  // zaklad.v(1907)
  // zaklad.v(1907)
  AL_PHY_LSLICE \trig_arm_f_reg|trig_arm_r_reg  (
    .a({trig_arm_f,trig_arm_r}),
    .b({n266,n266}),
    .c({hyst_above,hyst_below}),
    .ce(swc_adv),
    .clk(sample_write_clock_gclk_net),
    .sr(sample_system_reset),
    .q({trig_arm_f,trig_arm_r}));  // zaklad.v(1907)
  // zaklad.v(2867)
  // zaklad.v(2867)
  AL_PHY_LSLICE \trig_pw_long_reg|reg76_b2  (
    .a({open_n34875,n237}),
    .b({_al_u1420_o,_al_u1457_o}),
    .c({mcu_command[2],_al_u1370_o}),
    .ce(mux91_b0_sel_is_3_o),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({_al_u1440_o,str_q[1]}),
    .e({open_n34876,trigger_ext}),
    .mi(io_mcu_data_pad[3:2]),
    .f({_al_u1596_o,n100}),
    .q({trig_pw_long,trig_type[2]}));  // zaklad.v(2867)
  AL_PHY_MSLICE trigger_edge_reg (
    .a({\sel32/B0 ,trigger_edge}),
    .b({io_mcu_data_pad[0],\sel32/B0 }),
    .c({n653_lutinv,n653_lutinv}),
    .ce(n515),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({trigger_edge,io_mcu_data_pad[0]}),
    .mi({open_n34903,n679_lutinv}),
    .q({open_n34910,trigger_edge}));  // zaklad.v(2867)
  AL_PHY_MSLICE trigger_ext_reg (
    .a({n679_lutinv,trigger_ext}),
    .b({n652_lutinv,n652_lutinv}),
    .c({n602,n602}),
    .ce(n515),
    .clk(i_mcu_clk_pad_gclk_net),
    .d({trigger_ext,n679_lutinv}),
    .mi({open_n34921,io_mcu_data_pad[1]}),
    .q({open_n34928,trigger_ext}));  // zaklad.v(2867)
  // zaklad.v(1596)
  // zaklad.v(1838)
  AL_PHY_LSLICE \trigger_mode_s_reg|swc_adv_q_reg  (
    .a({_al_u2097_o,dec_sv[6]}),
    .b({_al_u2099_o,peak_en}),
    .c({_al_u1415_o,dec_order[0]}),
    .clk(sample_write_clock_gclk_net),
    .d({_al_u1439_o,\dec_order[1]_hfnopt2_2 }),
    .mi({trigger_mode_s1,open_n34933}),
    .f({_al_u2100_o,swc_adv}),
    .q({trigger_mode_s,swc_adv_q}));  // zaklad.v(1596)
  AL_PHY_MSLICE \u1/u0|u1/ucin  (
    .a({pair_l1[0],1'b0}),
    .b({\dec_ch1/t_pe [0],open_n34949}),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch1/n78 [8:7]),
    .f({n0[0],open_n34965}),
    .fco(\u1/c1 ),
    .q(\dec_ch1/c1 [8:7]));
  AL_PHY_MSLICE \u1/u2|u1/u1  (
    .a(pair_l1[2:1]),
    .b(\dec_ch1/t_pe [2:1]),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u1/c1 ),
    .mi({\dec_ch1/c1 [14],\dec_ch1/c1 [12]}),
    .f(n0[2:1]),
    .fco(\u1/c3 ),
    .q({\dec_ch1/c1p [14],\dec_ch1/c1p [12]}));
  AL_PHY_MSLICE \u1/u4|u1/u3  (
    .a(pair_l1[4:3]),
    .b(\dec_ch1/t_pe [4:3]),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u1/c3 ),
    .mi(\dec_ch1/c1 [18:17]),
    .f(n0[4:3]),
    .fco(\u1/c5 ),
    .q(\dec_ch1/c1p [18:17]));
  AL_PHY_MSLICE \u1/u6|u1/u5  (
    .a(pair_l1[6:5]),
    .b(\dec_ch1/t_pe [6:5]),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u1/c5 ),
    .mi({\dec_ch1/c1 [16],\dec_ch1/n82 [20]}),
    .f(n0[6:5]),
    .fco(\u1/c7 ),
    .q({\dec_ch1/c1p [16],\dec_ch1/c2 [20]}));
  AL_PHY_MSLICE \u1/ucout|u1/u7  (
    .a({open_n35016,pair_l1[7]}),
    .b({open_n35017,\dec_ch1/t_pe [7]}),
    .ce(\dec_sv[2]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u1/c7 ),
    .mi(\dec_ch1/c1 [22:21]),
    .f(n0[8:7]),
    .q(\dec_ch1/c1p [22:21]));
  AL_PHY_MSLICE \u2/u0|u2/ucin  (
    .a({n0[0],1'b0}),
    .b({\dec_ch1/t_pl [0],open_n35035}),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch1/pmx [3:2]),
    .f({n1[0],open_n35052}),
    .fco(\u2/c1 ),
    .q(\dec_ch1/pdx [3:2]));
  AL_PHY_MSLICE \u2/u2|u2/u1  (
    .a(\dec_ch1/t_xe [2:1]),
    .b(\dec_ch1/t_pl [2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u2/c1 ),
    .mi(\dec_ch1/pmx [1:0]),
    .f(n1[2:1]),
    .fco(\u2/c3 ),
    .q(\dec_ch1/pdx [1:0]));
  AL_PHY_MSLICE \u2/u4|u2/u3  (
    .a(\dec_ch1/t_xe [4:3]),
    .b(\dec_ch1/t_pl [4:3]),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u2/c3 ),
    .mi({\dec_ch1/n78 [4],\dec_ch1/n78 [2]}),
    .f(n1[4:3]),
    .fco(\u2/c5 ),
    .q({\dec_ch1/c1 [4],\dec_ch1/c1 [2]}));
  AL_PHY_MSLICE \u2/u6|u2/u5  (
    .a(\dec_ch1/t_xe [6:5]),
    .b(\dec_ch1/t_pl [6:5]),
    .ce(\dec_sv[1]_hfnopt2_1 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u2/c5 ),
    .mi(\dec_ch1/n78 [6:5]),
    .f(n1[6:5]),
    .fco(\u2/c7 ),
    .q(\dec_ch1/c1 [6:5]));
  AL_PHY_MSLICE \u2/u8|u2/u7  (
    .a(\dec_ch1/t_xe [8:7]),
    .b(\dec_ch1/t_pl [8:7]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u2/c7 ),
    .mi({open_n35118,\dec_ch1/pmn [1]}),
    .f(n1[8:7]),
    .fco(\u2/c9 ),
    .q({open_n35122,\dec_ch1/pdn [1]}));
  AL_PHY_MSLICE \u2/ucout|u2/u9  (
    .a({open_n35123,\dec_ch1/t_xe [9]}),
    .b({open_n35124,1'b0}),
    .clk(sample_write_clock_gclk_net),
    .fci(\u2/c9 ),
    .mi({open_n35139,\dec_sv[1]_hfnopt2_2 }),
    .f(n1[10:9]),
    .q({open_n35144,\dec_sv[2]_hfnopt2_1 }));
  AL_PHY_MSLICE \u4/u0|u4/ucin  (
    .a({pair_l2[0],1'b0}),
    .b({\dec_ch2/t_pe [0],open_n35145}),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch2/pmx [2:1]),
    .f({n2[0],open_n35162}),
    .fco(\u4/c1 ),
    .q(\dec_ch2/pdx [2:1]));
  AL_PHY_MSLICE \u4/u2|u4/u1  (
    .a(pair_l2[2:1]),
    .b(\dec_ch2/t_pe [2:1]),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u4/c1 ),
    .mi(\dec_ch2/pk1 [15:14]),
    .f(n2[2:1]),
    .fco(\u4/c3 ),
    .q(\dec_ch2/pk2 [15:14]));
  AL_PHY_MSLICE \u4/u4|u4/u3  (
    .a(pair_l2[4:3]),
    .b(\dec_ch2/t_pe [4:3]),
    .ce(dec_sv[2]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u4/c3 ),
    .mi({open_n35194,\dec_ch2/pk1 [4]}),
    .f(n2[4:3]),
    .fco(\u4/c5 ),
    .q({open_n35198,\dec_ch2/pk2 [4]}));
  AL_PHY_MSLICE \u4/u6|u4/u5  (
    .a(pair_l2[6:5]),
    .b(\dec_ch2/t_pe [6:5]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u4/c5 ),
    .mi({open_n35213,\dec_ch2/pmx [5]}),
    .f(n2[6:5]),
    .fco(\u4/c7 ),
    .q({open_n35217,\dec_ch2/pdx [5]}));
  AL_PHY_MSLICE \u4/ucout|u4/u7  (
    .a({open_n35218,pair_l2[7]}),
    .b({open_n35219,\dec_ch2/t_pe [7]}),
    .clk(sample_write_clock_gclk_net),
    .fci(\u4/c7 ),
    .mi(pair_e2[4:3]),
    .f(n2[8:7]),
    .q(\dec_ch2/pe [4:3]));
  AL_PHY_MSLICE \u5/u0|u5/ucin  (
    .a({n2[0],1'b0}),
    .b({\dec_ch2/t_pl [0],open_n35238}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .mi(\dec_ch1/c1 [38:37]),
    .f({n3[0],open_n35254}),
    .fco(\u5/c1 ),
    .q(\dec_ch1/c1p [38:37]));
  AL_PHY_MSLICE \u5/u2|u5/u1  (
    .a(\dec_ch2/t_xe [2:1]),
    .b(\dec_ch2/t_pl [2:1]),
    .clk(sample_write_clock_gclk_net),
    .fci(\u5/c1 ),
    .mi({open_n35271,\dec_sv[1]_hfnopt2_0 }),
    .f(n3[2:1]),
    .fco(\u5/c3 ),
    .q({open_n35275,\dec_sv[2]_hfnopt2_0 }));
  AL_PHY_MSLICE \u5/u4|u5/u3  (
    .a(\dec_ch2/t_xe [4:3]),
    .b(\dec_ch2/t_pl [4:3]),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u5/c3 ),
    .mi({open_n35289,\dec_ch1/c1 [36]}),
    .f(n3[4:3]),
    .fco(\u5/c5 ),
    .q({open_n35293,\dec_ch1/c1p [36]}));
  AL_PHY_MSLICE \u5/u6|u5/u5  (
    .a(\dec_ch2/t_xe [6:5]),
    .b(\dec_ch2/t_pl [6:5]),
    .ce(\dec_sv[1]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u5/c5 ),
    .mi(\dec_ch1/n78 [46:45]),
    .f(n3[6:5]),
    .fco(\u5/c7 ),
    .q(\dec_ch1/c1 [46:45]));
  AL_PHY_MSLICE \u5/u8|u5/u7  (
    .a(\dec_ch2/t_xe [8:7]),
    .b(\dec_ch2/t_pl [8:7]),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u5/c7 ),
    .mi(\dec_ch1/c1 [42:41]),
    .f(n3[8:7]),
    .fco(\u5/c9 ),
    .q(\dec_ch1/c1p [42:41]));
  AL_PHY_MSLICE \u5/ucout|u5/u9  (
    .a({open_n35326,\dec_ch2/t_xe [9]}),
    .b({open_n35327,1'b0}),
    .ce(\dec_sv[2]_hfnopt2_0 ),
    .clk(sample_write_clock_gclk_net),
    .fci(\u5/c9 ),
    .mi(\dec_ch1/c1 [46:45]),
    .f(n3[10:9]),
    .q(\dec_ch1/c1p [46:45]));
  AL_PHY_LSLICE \u_sq/add0/u11_al_u2453  (
    .a({\u_sq/acc_sum [13],\u_sq/acc_sum [11]}),
    .b({\u_sq/acc_sum [14],\u_sq/acc_sum [12]}),
    .c(2'b00),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({\u_sq/f_nn [13],\u_sq/f_nn [11]}),
    .e({\u_sq/f_nn [14],\u_sq/f_nn [12]}),
    .fci(\u_sq/add0/c11 ),
    .mi(pat_wr_f[12:11]),
    .f({\u_sq/n18 [13],\u_sq/n18 [11]}),
    .fco(\u_sq/add0/c15 ),
    .fx({\u_sq/n18 [14],\u_sq/n18 [12]}),
    .q(\u_sq/sh1 [12:11]));
  AL_PHY_LSLICE \u_sq/add0/u15_al_u2454  (
    .a({open_n35357,\u_sq/acc_sum [15]}),
    .c(2'b00),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({open_n35360,\u_sq/f_nn [15]}),
    .fci(\u_sq/add0/c15 ),
    .mi(pat_wr_f[15:14]),
    .f({open_n35375,\u_sq/n18 [15]}),
    .fx({open_n35377,\u_sq/n17 }),
    .q(\u_sq/sh1 [15:14]));
  AL_PHY_LSLICE \u_sq/add0/u3_al_u2451  (
    .a({\u_sq/acc_sum [5],\u_sq/acc_sum [3]}),
    .b({\u_sq/acc_sum [6],\u_sq/acc_sum [4]}),
    .c(2'b00),
    .d({\u_sq/f_nn [5],\u_sq/f_nn [3]}),
    .e({\u_sq/f_nn [6],\u_sq/f_nn [4]}),
    .fci(\u_sq/add0/c3 ),
    .f({\u_sq/n18 [5],\u_sq/n18 [3]}),
    .fco(\u_sq/add0/c7 ),
    .fx({\u_sq/n18 [6],\u_sq/n18 [4]}));
  AL_PHY_LSLICE \u_sq/add0/u7_al_u2452  (
    .a({\u_sq/acc_sum [9],\u_sq/acc_sum [7]}),
    .b({\u_sq/acc_sum [10],\u_sq/acc_sum [8]}),
    .c(2'b00),
    .clk(sample_write_clock_gclk_net),
    .d({\u_sq/f_nn [9],\u_sq/f_nn [7]}),
    .e({\u_sq/f_nn [10],\u_sq/f_nn [8]}),
    .fci(\u_sq/add0/c7 ),
    .mi(cap_h[31:30]),
    .f({\u_sq/n18 [9],\u_sq/n18 [7]}),
    .fco(\u_sq/add0/c11 ),
    .fx({\u_sq/n18 [10],\u_sq/n18 [8]}),
    .q(adc2B_w[7:6]));
  AL_PHY_LSLICE \u_sq/add0/ucin_al_u2450  (
    .a({\u_sq/acc_sum [1],1'b0}),
    .b({\u_sq/acc_sum [2],\u_sq/acc_sum [0]}),
    .c(2'b00),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({\u_sq/f_nn [1],1'b1}),
    .e({\u_sq/f_nn [2],\u_sq/f_nn [0]}),
    .mi({pat_wr_f[8],pat_wr_f[5]}),
    .f({\u_sq/n18 [1],open_n35422}),
    .fco(\u_sq/add0/c3 ),
    .fx({\u_sq/n18 [2],\u_sq/n18 [0]}),
    .q({\u_sq/sh0 [8],\u_sq/sh0 [5]}));
  AL_PHY_MSLICE \u_sq/add1/u0|u_sq/add1/ucin  (
    .a({\u_sq/acc [0],1'b0}),
    .b({\u_sq/f_next [0],open_n35423}),
    .f({\u_sq/n20 [0],open_n35443}),
    .fco(\u_sq/add1/c1 ));
  AL_PHY_MSLICE \u_sq/add1/u10|u_sq/add1/u9  (
    .a(\u_sq/acc [10:9]),
    .b(\u_sq/f_next [10:9]),
    .clk(clk_200MHz),
    .fci(\u_sq/add1/c9 ),
    .mi({adc_q2[24],adc_q1[25]}),
    .f(\u_sq/n20 [10:9]),
    .fco(\u_sq/add1/c11 ),
    .q({adc_d2[24],adc_d1[25]}));
  AL_PHY_MSLICE \u_sq/add1/u12|u_sq/add1/u11  (
    .a(\u_sq/acc [12:11]),
    .b(\u_sq/f_next [12:11]),
    .clk(clk_200MHz),
    .fci(\u_sq/add1/c11 ),
    .mi({adc_d1[25],adc_q2[25]}),
    .f(\u_sq/n20 [12:11]),
    .fco(\u_sq/add1/c13 ),
    .q({adc_dd1[25],adc_d2[25]}));
  AL_PHY_MSLICE \u_sq/add1/u14|u_sq/add1/u13  (
    .a(\u_sq/acc [14:13]),
    .b(\u_sq/f_next [14:13]),
    .clk(clk_200MHz),
    .fci(\u_sq/add1/c13 ),
    .mi({adc_d2[25],adc_d1[26]}),
    .f(\u_sq/n20 [14:13]),
    .fco(\u_sq/add1/c15 ),
    .q({adc_dd2[25],adc_dd1[26]}));
  AL_PHY_MSLICE \u_sq/add1/u2|u_sq/add1/u1  (
    .a({\u_sq/acc [2],\u_sq/f_next [1]}),
    .b({\u_sq/f_next [2],\u_sq/acc [1]}),
    .fci(\u_sq/add1/c1 ),
    .f(\u_sq/n20 [2:1]),
    .fco(\u_sq/add1/c3 ));
  AL_PHY_MSLICE \u_sq/add1/u4|u_sq/add1/u3  (
    .a(\u_sq/acc [4:3]),
    .b(\u_sq/f_next [4:3]),
    .clk(clk_200MHz),
    .fci(\u_sq/add1/c3 ),
    .mi({open_n35535,adc_d1[24]}),
    .f(\u_sq/n20 [4:3]),
    .fco(\u_sq/add1/c5 ),
    .q({open_n35539,adc_dd1[24]}));
  AL_PHY_MSLICE \u_sq/add1/u6|u_sq/add1/u5  (
    .a(\u_sq/acc [6:5]),
    .b(\u_sq/f_next [6:5]),
    .clk(clk_200MHz),
    .fci(\u_sq/add1/c5 ),
    .mi({adc_d2[24],adc_q1[24]}),
    .f(\u_sq/n20 [6:5]),
    .fco(\u_sq/add1/c7 ),
    .q({adc_dd2[24],adc_d1[24]}));
  AL_PHY_MSLICE \u_sq/add1/u8|u_sq/add1/u7  (
    .a(\u_sq/acc [8:7]),
    .b(\u_sq/f_next [8:7]),
    .fci(\u_sq/add1/c7 ),
    .f(\u_sq/n20 [8:7]),
    .fco(\u_sq/add1/c9 ));
  AL_PHY_MSLICE \u_sq/add1/ucout|u_sq/add1/u15  (
    .a({open_n35579,\u_sq/f_next [15]}),
    .b({open_n35580,\u_sq/acc [15]}),
    .clk(clk_200MHz),
    .fci(\u_sq/add1/c15 ),
    .mi({adc_dd1[27],adc_d2[26]}),
    .f({\u_sq/n19 ,\u_sq/n20 [15]}),
    .q({adc_e1[27],adc_dd2[26]}));
  AL_PHY_LSLICE \u_sq/add2/u11_al_u2406  (
    .a({\u_sq/nx_e [29],\u_sq/nx_e [27]}),
    .b({\u_sq/nx_e [30],\u_sq/nx_e [28]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c11 ),
    .mi({\u_sq/sh0 [36],\u_sq/sh0 [34]}),
    .f({\u_sq/n51 [13],\u_sq/n51 [11]}),
    .fco(\u_sq/add2/c15 ),
    .fx({\u_sq/n51 [14],\u_sq/n51 [12]}),
    .q({\u_sq/e0 [36],\u_sq/e0 [34]}));
  AL_PHY_LSLICE \u_sq/add2/u15_al_u2407  (
    .a({\u_sq/nx_e [33],\u_sq/nx_e [31]}),
    .b({\u_sq/nx_e [34],\u_sq/nx_e [32]}),
    .c(2'b00),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c15 ),
    .mi(\u_sq/sh1 [34:33]),
    .f({\u_sq/n51 [17],\u_sq/n51 [15]}),
    .fco(\u_sq/add2/c19 ),
    .fx({\u_sq/n51 [18],\u_sq/n51 [16]}),
    .q(\u_sq/e1 [34:33]));
  AL_PHY_LSLICE \u_sq/add2/u19_al_u2408  (
    .a({\u_sq/nx_e [37],\u_sq/nx_e [35]}),
    .b({\u_sq/nx_e [38],\u_sq/nx_e [36]}),
    .c(2'b00),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c19 ),
    .mi({open_n35623,\u_sq/sh1 [32]}),
    .f({\u_sq/n51 [21],\u_sq/n51 [19]}),
    .fco(\u_sq/add2/c23 ),
    .fx({\u_sq/n51 [22],\u_sq/n51 [20]}),
    .q({open_n35636,\u_sq/e1 [32]}));
  AL_PHY_LSLICE \u_sq/add2/u23_al_u2409  (
    .a({\u_sq/nx_e [41],\u_sq/nx_e [39]}),
    .b({\u_sq/nx_e [42],\u_sq/nx_e [40]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c23 ),
    .mi(\u_sq/sh0 [41:40]),
    .f({\u_sq/n51 [25],\u_sq/n51 [23]}),
    .fco(\u_sq/add2/c27 ),
    .fx({\u_sq/n51 [26],\u_sq/n51 [24]}),
    .q(\u_sq/e0 [41:40]));
  AL_PHY_LSLICE \u_sq/add2/u27_al_u2410  (
    .a({\u_sq/nx_e [45],\u_sq/nx_e [43]}),
    .b({\u_sq/nx_e [46],\u_sq/nx_e [44]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c27 ),
    .mi(\u_sq/sh1 [41:40]),
    .f({\u_sq/n51 [29],\u_sq/n51 [27]}),
    .fco(\u_sq/add2/c31 ),
    .fx({\u_sq/n51 [30],\u_sq/n51 [28]}),
    .q(\u_sq/e1 [41:40]));
  AL_PHY_LSLICE \u_sq/add2/u31_al_u2411  (
    .a({open_n35661,\u_sq/nx_e [47]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .d({open_n35664,1'b1}),
    .fci(\u_sq/add2/c31 ),
    .mi(\u_sq/sh1 [44:43]),
    .f({open_n35679,\u_sq/n51 [31]}),
    .fx({open_n35681,\u_sq/n49 }),
    .q(\u_sq/e1 [44:43]));
  AL_PHY_LSLICE \u_sq/add2/u3_al_u2404  (
    .a({\u_sq/nx_e [21],\u_sq/nx_e [19]}),
    .b({\u_sq/nx_e [22],\u_sq/nx_e [20]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c3 ),
    .mi({\u_sq/sh1 [28],\u_sq/sh0 [29]}),
    .f({\u_sq/n51 [5],\u_sq/n51 [3]}),
    .fco(\u_sq/add2/c7 ),
    .fx({\u_sq/n51 [6],\u_sq/n51 [4]}),
    .q({\u_sq/e1 [28],\u_sq/e0 [29]}));
  AL_PHY_LSLICE \u_sq/add2/u7_al_u2405  (
    .a({\u_sq/nx_e [25],\u_sq/nx_e [23]}),
    .b({\u_sq/nx_e [26],\u_sq/nx_e [24]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e(2'b11),
    .fci(\u_sq/add2/c7 ),
    .mi(\u_sq/sh0 [33:32]),
    .f({\u_sq/n51 [9],\u_sq/n51 [7]}),
    .fco(\u_sq/add2/c11 ),
    .fx({\u_sq/n51 [10],\u_sq/n51 [8]}),
    .q(\u_sq/e0 [33:32]));
  AL_PHY_LSLICE \u_sq/add2/ucin_al_u2403  (
    .a({\u_sq/nx_e [17],1'b0}),
    .b({\u_sq/nx_e [18],\u_sq/nx_e [16]}),
    .c(2'b00),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d(2'b11),
    .e({1'b1,\u_sq/acc_sum [16]}),
    .mi(\u_sq/sh1 [30:29]),
    .f({\u_sq/n51 [1],open_n35719}),
    .fco(\u_sq/add2/c3 ),
    .fx({\u_sq/n51 [2],\u_sq/n51 [0]}),
    .q(\u_sq/e1 [30:29]));
  AL_PHY_MSLICE \u_sq/cur_reg  (
    .a({open_n35720,\u_sq/cur }),
    .b({open_n35721,\u_sq/n9 }),
    .c({open_n35722,\u_sq/n8_lutinv }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({open_n35723,\u_sq/go }),
    .q({open_n35742,\u_sq/cur }));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/idle_lv_reg  (
    .ce(\u_sq/ct_ev ),
    .clk(clk_200MHz),
    .mi({open_n35754,pat_ctl[2]}),
    .q({open_n35772,\u_sq/idle_lv }));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg0_b2|u_sq/reg0_b1  (
    .a({open_n35773,dec_pc[4]}),
    .b({open_n35774,dec_pc[5]}),
    .c({n661_lutinv,dec_pc[6]}),
    .clk(clk_200MHz),
    .d({_al_u1556_o,dec_pc[7]}),
    .e({open_n35776,dec_pc[8]}),
    .mi(\u_sq/ct_s [1:0]),
    .f({mux78_b0_sel_is_3_o,_al_u1406_o}),
    .q(\u_sq/ct_s [2:1]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b10|u_sq/reg11_b9  (
    .a(\u_sq/acc [10:9]),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e(\u_sq/acc_sum [10:9]),
    .q(\u_sq/acc [10:9]));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b11  (
    .a({open_n35813,\u_sq/acc [11]}),
    .b({open_n35814,\u_sq/n9 }),
    .c({open_n35815,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({open_n35816,\u_sq/n8_lutinv }),
    .e({open_n35817,\u_sq/acc_sum [11]}),
    .q({open_n35838,\u_sq/acc [11]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b12|u_sq/reg11_b13  (
    .a({\u_sq/acc [12],\u_sq/acc [13]}),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e({\u_sq/acc_sum [12],\u_sq/acc_sum [13]}),
    .q({\u_sq/acc [12],\u_sq/acc [13]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b14|u_sq/reg11_b15  (
    .a({\u_sq/acc [14],\u_sq/acc [15]}),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e({\u_sq/acc_sum [14],\u_sq/acc_sum [15]}),
    .q({\u_sq/acc [14],\u_sq/acc [15]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b1|u_sq/reg11_b2  (
    .a({\u_sq/acc [1],\u_sq/acc [2]}),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e({\u_sq/acc_sum [1],\u_sq/acc_sum [2]}),
    .q({\u_sq/acc [1],\u_sq/acc [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b3|u_sq/reg11_b4  (
    .a({\u_sq/acc [3],\u_sq/acc [4]}),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e({\u_sq/acc_sum [3],\u_sq/acc_sum [4]}),
    .q({\u_sq/acc [3],\u_sq/acc [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b5|u_sq/reg11_b6  (
    .a({\u_sq/acc [5],\u_sq/acc [6]}),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e({\u_sq/acc_sum [5],\u_sq/acc_sum [6]}),
    .q({\u_sq/acc [5],\u_sq/acc [6]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg11_b7|u_sq/reg11_b8  (
    .a({\u_sq/acc [7],\u_sq/acc [8]}),
    .b({\u_sq/n9 ,\u_sq/n9 }),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/stop ),
    .clk(clk_200MHz),
    .d({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .e({\u_sq/acc_sum [7],\u_sq/acc_sum [8]}),
    .q({\u_sq/acc [7],\u_sq/acc [8]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b0  (
    .a({open_n35959,\u_sq/bd }),
    .b({open_n35960,\u_sq/stop }),
    .c({open_n35961,\u_sq/n51 [0]}),
    .clk(clk_200MHz),
    .d({open_n35963,\u_sq/n52 [0]}),
    .sr(\u_sq/n46 ),
    .q({open_n35981,\u_sq/cnt [0]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b10|u_sq/reg12_b7  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [10],\u_sq/n51 [7]}),
    .c({\u_sq/n52 [10],\u_sq/n52 [7]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [10],\u_sq/cnt [7]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b11|u_sq/reg12_b12  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [11],\u_sq/n51 [12]}),
    .c({\u_sq/n52 [11],\u_sq/n52 [12]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [11],\u_sq/cnt [12]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b13|u_sq/reg12_b14  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [13],\u_sq/n51 [14]}),
    .c({\u_sq/n52 [13],\u_sq/n52 [14]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [13],\u_sq/cnt [14]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b15|u_sq/reg12_b16  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n52 [15],\u_sq/n51 [16]}),
    .c({\u_sq/n51 [15],\u_sq/n52 [16]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [15],\u_sq/cnt [16]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b17|u_sq/reg12_b18  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [17],\u_sq/n51 [18]}),
    .c({\u_sq/stop ,\u_sq/n52 [18]}),
    .clk(clk_200MHz),
    .d({\u_sq/n52 [17],\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [17],\u_sq/cnt [18]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b19|u_sq/reg12_b20  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [19],\u_sq/n51 [20]}),
    .c({\u_sq/n52 [19],\u_sq/n52 [20]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [19],\u_sq/cnt [20]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b1|u_sq/reg12_b2  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/stop ,\u_sq/stop }),
    .c({\u_sq/n51 [1],\u_sq/n51 [2]}),
    .clk(clk_200MHz),
    .d({\u_sq/n52 [1],\u_sq/n52 [2]}),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [1],\u_sq/cnt [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b21|u_sq/reg12_b22  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [21],\u_sq/n51 [22]}),
    .c({\u_sq/n52 [21],\u_sq/n52 [22]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [21],\u_sq/cnt [22]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b23|u_sq/reg12_b24  (
    .a({\u_sq/n52 [23],\u_sq/n51 [24]}),
    .b({\u_sq/n51 [23],\u_sq/n52 [24]}),
    .c({\u_sq/bd ,\u_sq/bd }),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [23],\u_sq/cnt [24]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b25|u_sq/reg12_b26  (
    .a({\u_sq/n51 [25],\u_sq/n51 [26]}),
    .b({\u_sq/n52 [25],\u_sq/n52 [26]}),
    .c({\u_sq/bd ,\u_sq/bd }),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [25],\u_sq/cnt [26]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b27|u_sq/reg12_b28  (
    .a({\u_sq/n51 [27],\u_sq/n51 [28]}),
    .b({\u_sq/n52 [27],\u_sq/n52 [28]}),
    .c({\u_sq/bd ,\u_sq/bd }),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [27],\u_sq/cnt [28]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b29|u_sq/reg12_b31  (
    .a({\u_sq/n51 [29],\u_sq/n52 [31]}),
    .b({\u_sq/n52 [29],\u_sq/n51 [31]}),
    .c({\u_sq/bd ,\u_sq/bd }),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [29],\u_sq/cnt [31]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b30|u_sq/reg12_b32  (
    .a({\u_sq/n51 [30],\u_sq/n49 }),
    .b({\u_sq/n52 [30],\u_sq/n52 [32]}),
    .c({\u_sq/bd ,\u_sq/bd }),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [30],\u_sq/cnt [32]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b3|u_sq/reg12_b4  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/stop ,\u_sq/stop }),
    .c({\u_sq/n52 [3],\u_sq/n51 [4]}),
    .clk(clk_200MHz),
    .d({\u_sq/n51 [3],\u_sq/n52 [4]}),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [3],\u_sq/cnt [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg12_b5|u_sq/reg12_b6  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [5],\u_sq/n51 [6]}),
    .c({\u_sq/n52 [5],\u_sq/n52 [6]}),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/stop }),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [5],\u_sq/cnt [6]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg12_b8|u_sq/reg12_b9  (
    .a({\u_sq/bd ,\u_sq/bd }),
    .b({\u_sq/n51 [8],\u_sq/n51 [9]}),
    .c({\u_sq/n52 [8],\u_sq/stop }),
    .clk(clk_200MHz),
    .d({\u_sq/stop ,\u_sq/n52 [9]}),
    .sr(\u_sq/n46 ),
    .q({\u_sq/cnt [8],\u_sq/cnt [9]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg13_b0  (
    .a({open_n36302,oc_1B[12]}),
    .b({open_n36303,oc_1B[13]}),
    .c({open_n36304,oc_1B[14]}),
    .clk(clk_200MHz),
    .d({open_n36306,oc_1B[15]}),
    .mi({open_n36310,pat_wr_t}),
    .f({open_n36323,n38}),
    .q({open_n36327,\u_sq/wr_s [0]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg13_b1|u_sq/reg13_b2  (
    .b({pat_wr_idx[3],open_n36330}),
    .c({pat_wr_idx[4],sample_rate_divider[13]}),
    .clk(clk_200MHz),
    .d({pat_wr_idx[2],_al_u745_o}),
    .mi({\u_sq/wr_s [0],\u_sq/wr_s [1]}),
    .f({_al_u1365_o,sample_rate_divider_eff[13]}),
    .q({\u_sq/wr_s [1],\u_sq/wr_s [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg1_b1|u_sq/reg1_b2  (
    .a({\u_sq/go_d [1],\u_sq/go_d [2]}),
    .b({open_n36350,\u_sq/cnt [32]}),
    .c({\u_sq/go_d [0],\u_sq/go_d [0]}),
    .clk(clk_200MHz),
    .d(\u_sq/go_d [2:1]),
    .e({open_n36352,\u_sq/u39_sel_is_2_o }),
    .mi({\u_sq/go_d [0],\u_sq/go_d [1]}),
    .f({\u_sq/n8_lutinv ,\u_sq/bd }),
    .q({\u_sq/go_d [1],\u_sq/go_d [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b16|u_sq/reg2_b18  (
    .b({\u_sq/e0 [16],\u_sq/e0 [18]}),
    .c({\u_sq/e1 [16],\u_sq/e1 [18]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [16],\u_sq/nx_e [18]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b17  (
    .b({open_n36392,\u_sq/e0 [17]}),
    .c({open_n36393,\u_sq/e1 [17]}),
    .clk(clk_200MHz),
    .d({open_n36395,\u_sq/cur }),
    .q({open_n36418,\u_sq/nx_e [17]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b19|u_sq/reg2_b23  (
    .b({\u_sq/e0 [19],\u_sq/e0 [23]}),
    .c({\u_sq/e1 [19],\u_sq/cur }),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/e1 [23]}),
    .q({\u_sq/nx_e [19],\u_sq/nx_e [23]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b20|u_sq/reg2_b22  (
    .b({\u_sq/e0 [20],\u_sq/e0 [22]}),
    .c({\u_sq/e1 [20],\u_sq/e1 [22]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [20],\u_sq/nx_e [22]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b21|u_sq/go_reg  (
    .b({\u_sq/e0 [21],\u_sq/n8_lutinv }),
    .c({\u_sq/e1 [21],\u_sq/ct_ev }),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,_al_u1603_o}),
    .q({\u_sq/nx_e [21],\u_sq/go }));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b24|u_sq/reg2_b27  (
    .b({\u_sq/e1 [24],\u_sq/e0 [27]}),
    .c({\u_sq/e0 [24],\u_sq/e1 [27]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [24],\u_sq/nx_e [27]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b25|u_sq/reg2_b48  (
    .b({\u_sq/e0 [25],\u_sq/e0 [48]}),
    .c({\u_sq/e1 [25],\u_sq/e1 [48]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [25],\u_sq/nx_e [48]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b26|u_sq/reg2_b29  (
    .b({\u_sq/e0 [26],\u_sq/e0 [29]}),
    .c({\u_sq/e1 [26],\u_sq/e1 [29]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [26],\u_sq/nx_e [29]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b28|u_sq/reg2_b30  (
    .b({\u_sq/e0 [28],\u_sq/e0 [30]}),
    .c({\u_sq/e1 [28],\u_sq/e1 [30]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [28],\u_sq/nx_e [30]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b31|u_sq/level_reg  (
    .a({open_n36582,_al_u1606_o}),
    .b({\u_sq/e0 [31],\u_sq/stop }),
    .c({\u_sq/e1 [31],_al_u1605_o}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,pat_ctl[2]}),
    .q({\u_sq/nx_e [31],pat_level}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b32|u_sq/reg2_b34  (
    .b({\u_sq/e0 [32],\u_sq/e0 [34]}),
    .c({\u_sq/e1 [32],\u_sq/e1 [34]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [32],\u_sq/nx_e [34]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b33|u_sq/reg2_b35  (
    .b({\u_sq/e0 [33],\u_sq/e0 [35]}),
    .c({\u_sq/e1 [33],\u_sq/e1 [35]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [33],\u_sq/nx_e [35]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b36|u_sq/reg2_b38  (
    .b({\u_sq/e0 [36],\u_sq/e0 [38]}),
    .c({\u_sq/e1 [36],\u_sq/e1 [38]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [36],\u_sq/nx_e [38]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b37|u_sq/reg2_b39  (
    .b({\u_sq/e0 [37],\u_sq/e0 [39]}),
    .c({\u_sq/e1 [37],\u_sq/e1 [39]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [37],\u_sq/nx_e [39]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b40|u_sq/reg2_b41  (
    .b({\u_sq/e0 [40],\u_sq/e0 [41]}),
    .c({\u_sq/e1 [40],\u_sq/e1 [41]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [40],\u_sq/nx_e [41]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b42|u_sq/reg2_b46  (
    .b({\u_sq/e0 [42],\u_sq/e0 [46]}),
    .c({\u_sq/e1 [42],\u_sq/e1 [46]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [42],\u_sq/nx_e [46]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg2_b43|u_sq/reg2_b44  (
    .b({\u_sq/e0 [43],\u_sq/e0 [44]}),
    .c({\u_sq/e1 [43],\u_sq/e1 [44]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [43],\u_sq/nx_e [44]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg2_b45|u_sq/reg2_b47  (
    .b({\u_sq/e0 [45],\u_sq/e0 [47]}),
    .c({\u_sq/e1 [45],\u_sq/e1 [47]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur ,\u_sq/cur }),
    .q({\u_sq/nx_e [45],\u_sq/nx_e [47]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg3_b10|u_sq/reg3_b9  (
    .b(\u_sq/e1f_n [10:9]),
    .c(\u_sq/e0f_n [10:9]),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q(\u_sq/f_next [10:9]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg3_b11|u_sq/reg3_b12  (
    .b({\u_sq/e1f_n [11],\u_sq/e1f_n [12]}),
    .c({\u_sq/e0f_n [11],\u_sq/e0f_n [12]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [11],\u_sq/f_next [12]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg3_b13|u_sq/reg3_b14  (
    .b({\u_sq/e1f_n [13],\u_sq/e1f_n [14]}),
    .c({\u_sq/e0f_n [13],\u_sq/e0f_n [14]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [13],\u_sq/f_next [14]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg3_b15|u_sq/reg4_b15  (
    .b({\u_sq/e0f_n [15],\u_sq/e0f_n [15]}),
    .c({\u_sq/e1f_n [15],\u_sq/e1f_n [15]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [15],\u_sq/f_nn [15]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg3_b1|u_sq/reg3_b4  (
    .b({\u_sq/e0f_n [1],\u_sq/e1f_n [4]}),
    .c({\u_sq/e1f_n [1],\u_sq/e0f_n [4]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [1],\u_sq/f_next [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg3_b2|u_sq/reg4_b0  (
    .b({\u_sq/e1f_n [2],\u_sq/e1f_n [0]}),
    .c({\u_sq/e0f_n [2],\u_sq/e0f_n [0]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [2],\u_sq/f_nn [0]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg3_b3|u_sq/reg5_b0  (
    .a({open_n36928,\u_sq/n8_lutinv }),
    .b({\u_sq/e1f_n [3],\u_sq/u39_sel_is_2_o }),
    .c({\u_sq/e0f_n [3],\u_sq/n18 [0]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/n20 [0]}),
    .e({open_n36930,\u_sq/cnt [32]}),
    .q({\u_sq/f_next [3],\u_sq/acc_sum [0]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg3_b5|u_sq/reg3_b6  (
    .b({\u_sq/e0f_n [5],\u_sq/e0f_n [6]}),
    .c({\u_sq/e1f_n [5],\u_sq/e1f_n [6]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [5],\u_sq/f_next [6]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg3_b7|u_sq/reg4_b7  (
    .b({\u_sq/e0f_n [7],\u_sq/e0f_n [7]}),
    .c({\u_sq/e1f_n [7],\u_sq/e1f_n [7]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_next [7],\u_sq/f_nn [7]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg3_b8|u_sq/reg4_b8  (
    .b({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .c({\u_sq/e1f_n [8],\u_sq/e1f_n [8]}),
    .clk(clk_200MHz),
    .d({\u_sq/e0f_n [8],\u_sq/e0f_n [8]}),
    .q({\u_sq/f_next [8],\u_sq/f_nn [8]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg4_b10|u_sq/reg4_b9  (
    .b({\u_sq/e0f_n [10],\u_sq/e1f_n [9]}),
    .c({\u_sq/e1f_n [10],\u_sq/e0f_n [9]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q(\u_sq/f_nn [10:9]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg4_b11|u_sq/reg4_b12  (
    .b({\u_sq/e1f_n [11],\u_sq/e1f_n [12]}),
    .c({\u_sq/e0f_n [11],\u_sq/e0f_n [12]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_nn [11],\u_sq/f_nn [12]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg4_b13|u_sq/reg4_b14  (
    .b({\u_sq/e1f_n [13],\u_sq/e1f_n [14]}),
    .c({\u_sq/e0f_n [13],\u_sq/e0f_n [14]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_nn [13],\u_sq/f_nn [14]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg4_b1|u_sq/reg4_b2  (
    .b({\u_sq/e0f_n [1],\u_sq/e1f_n [2]}),
    .c({\u_sq/e1f_n [1],\u_sq/e0f_n [2]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_nn [1],\u_sq/f_nn [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg4_b3|u_sq/reg4_b4  (
    .a({\u_sq/e1f_n [3],open_n37114}),
    .b({\u_sq/e0f_n [3],\u_sq/cur_n_lutinv }),
    .c({\u_sq/cur_n_lutinv ,\u_sq/e0f_n [4]}),
    .clk(clk_200MHz),
    .d({open_n37116,\u_sq/e1f_n [4]}),
    .q({\u_sq/f_nn [3],\u_sq/f_nn [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg4_b5|u_sq/reg4_b6  (
    .b({\u_sq/e0f_n [5],\u_sq/e0f_n [6]}),
    .c({\u_sq/e1f_n [5],\u_sq/e1f_n [6]}),
    .clk(clk_200MHz),
    .d({\u_sq/cur_n_lutinv ,\u_sq/cur_n_lutinv }),
    .q({\u_sq/f_nn [5],\u_sq/f_nn [6]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b10|u_sq/reg5_b9  (
    .a(\u_sq/n18 [10:9]),
    .b(\u_sq/n20 [10:9]),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q(\u_sq/acc_sum [10:9]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b12|u_sq/reg5_b13  (
    .a({\u_sq/n18 [12],\u_sq/n18 [13]}),
    .b({\u_sq/n20 [12],\u_sq/n20 [13]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [12],\u_sq/acc_sum [13]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b14|u_sq/reg5_b15  (
    .a({\u_sq/n18 [14],\u_sq/n18 [15]}),
    .b({\u_sq/n20 [14],\u_sq/n20 [15]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [14],\u_sq/acc_sum [15]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b16|u_sq/reg5_b11  (
    .a({\u_sq/n17 ,\u_sq/n18 [11]}),
    .b({\u_sq/n19 ,\u_sq/n20 [11]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [16],\u_sq/acc_sum [11]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b1|u_sq/reg5_b2  (
    .a({\u_sq/n18 [1],\u_sq/n18 [2]}),
    .b({\u_sq/n20 [1],\u_sq/n20 [2]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [1],\u_sq/acc_sum [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b3|u_sq/reg5_b4  (
    .a({\u_sq/n18 [3],\u_sq/n18 [4]}),
    .b({\u_sq/n20 [3],\u_sq/n20 [4]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [3],\u_sq/acc_sum [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b5|u_sq/reg5_b6  (
    .a({\u_sq/n18 [5],\u_sq/n18 [6]}),
    .b({\u_sq/n20 [5],\u_sq/n20 [6]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [5],\u_sq/acc_sum [6]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg5_b7|u_sq/reg5_b8  (
    .a({\u_sq/n18 [7],\u_sq/n18 [8]}),
    .b({\u_sq/n20 [7],\u_sq/n20 [8]}),
    .c({\u_sq/n8_lutinv ,\u_sq/n8_lutinv }),
    .clk(clk_200MHz),
    .d({\u_sq/u39_sel_is_2_o ,\u_sq/u39_sel_is_2_o }),
    .e({\u_sq/cnt [32],\u_sq/cnt [32]}),
    .q({\u_sq/acc_sum [7],\u_sq/acc_sum [8]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b0|u_sq/reg6_b6  (
    .a({open_n37328,pat_ctl[5]}),
    .b({open_n37329,\u_sq/ct_s [1]}),
    .c({hyst_hi9[5],\u_sq/ct_s [2]}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({hyst_hi9[8],\u_sq/sh0 [0]}),
    .e({open_n37330,\u_sq/e0 [0]}),
    .mi({pat_wr_f[0],pat_wr_f[6]}),
    .f({hyst_hi[5],\u_sq/e0f_n [0]}),
    .q({\u_sq/sh0 [0],\u_sq/sh0 [6]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b10  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({open_n37365,pat_wr_f[10]}),
    .q({open_n37372,\u_sq/sh0 [10]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b11|u_sq/reg6_b12  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_f[11],pat_wr_f[12]}),
    .q({\u_sq/sh0 [11],\u_sq/sh0 [12]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b13|u_sq/reg6_b14  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_f[13],pat_wr_f[14]}),
    .q({\u_sq/sh0 [13],\u_sq/sh0 [14]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b16  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({open_n37447,pat_wr_n[0]}),
    .q({open_n37454,\u_sq/sh0 [16]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b2  (
    .c({open_n37459,hyst_hi9[6]}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({open_n37460,hyst_hi9[8]}),
    .mi({open_n37471,pat_wr_f[2]}),
    .f({open_n37473,hyst_hi[6]}),
    .q({open_n37477,\u_sq/sh0 [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b20|u_sq/reg6_b22  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[4],pat_wr_n[6]}),
    .q({\u_sq/sh0 [20],\u_sq/sh0 [22]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b21  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({open_n37517,pat_wr_n[5]}),
    .q({open_n37535,\u_sq/sh0 [21]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b24|u_sq/reg6_b31  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[8],pat_wr_n[15]}),
    .q({\u_sq/sh0 [24],\u_sq/sh0 [31]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b25  (
    .a({open_n37564,n687_lutinv}),
    .b({open_n37565,_al_u1588_o}),
    .c({open_n37566,n515}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({open_n37567,mcu_state[0]}),
    .e({open_n37568,mcu_state[1]}),
    .mi({open_n37570,pat_wr_n[9]}),
    .f({open_n37583,mux102_b10_sel_is_3_o}),
    .q({open_n37587,\u_sq/sh0 [25]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b26  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({open_n37606,pat_wr_n[10]}),
    .q({open_n37613,\u_sq/sh0 [26]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b27|u_sq/reg6_b28  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[11],pat_wr_n[12]}),
    .q({\u_sq/sh0 [27],\u_sq/sh0 [28]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b29|u_sq/reg6_b30  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[13],pat_wr_n[14]}),
    .q({\u_sq/sh0 [29],\u_sq/sh0 [30]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b32|u_sq/reg6_b38  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[16],pat_wr_n[22]}),
    .q({\u_sq/sh0 [32],\u_sq/sh0 [38]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b33|u_sq/reg6_b34  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[17],pat_wr_n[18]}),
    .q({\u_sq/sh0 [33],\u_sq/sh0 [34]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b35|u_sq/reg6_b48  (
    .c({sample_rate_divider[14],sample_rate_divider[12]}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({_al_u745_o,_al_u745_o}),
    .mi({pat_wr_n[19],pat_wr_lvl}),
    .f({sample_rate_divider_eff[14],sample_rate_divider_eff[12]}),
    .q({\u_sq/sh0 [35],\u_sq/sh0 [48]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b36|u_sq/reg6_b40  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[20],pat_wr_n[24]}),
    .q({\u_sq/sh0 [36],\u_sq/sh0 [40]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b37  (
    .c({open_n37768,sample_rate_divider[15]}),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d({open_n37769,_al_u745_o}),
    .mi({open_n37780,pat_wr_n[21]}),
    .f({open_n37782,sample_rate_divider_eff[15]}),
    .q({open_n37786,\u_sq/sh0 [37]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b39|u_sq/reg6_b42  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[23],pat_wr_n[26]}),
    .q({\u_sq/sh0 [39],\u_sq/sh0 [42]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b41|u_sq/reg6_b43  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[25],pat_wr_n[27]}),
    .q({\u_sq/sh0 [41],\u_sq/sh0 [43]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b44|u_sq/reg6_b46  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[28],pat_wr_n[30]}),
    .q({\u_sq/sh0 [44],\u_sq/sh0 [46]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg6_b45|u_sq/reg6_b47  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[29],pat_wr_n[31]}),
    .q({\u_sq/sh0 [45],\u_sq/sh0 [47]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg6_b7|u_sq/reg6_b9  (
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .mi({pat_wr_f[7],pat_wr_f[9]}),
    .q({\u_sq/sh0 [7],\u_sq/sh0 [9]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b13  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({open_n37926,pat_wr_f[13]}),
    .q({open_n37944,\u_sq/sh1 [13]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b17  (
    .a({open_n37945,dec_pc[10]}),
    .b({open_n37946,dec_pc[11]}),
    .c({open_n37947,dec_pc[12]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({open_n37948,dec_pc[13]}),
    .e({open_n37949,dec_pc[9]}),
    .mi({open_n37951,pat_wr_n[1]}),
    .f({open_n37964,_al_u1404_o}),
    .q({open_n37968,\u_sq/sh1 [17]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b18  (
    .c({open_n37973,hyst_hi9[7]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({open_n37974,hyst_hi9[8]}),
    .mi({open_n37978,pat_wr_n[2]}),
    .f({open_n37991,hyst_hi[7]}),
    .q({open_n37995,\u_sq/sh1 [18]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b1|u_sq/reg7_b4  (
    .a({open_n37996,pat_ctl[5]}),
    .b({open_n37997,\u_sq/ct_s [1]}),
    .c({\display_brightness/count [12],\u_sq/ct_s [2]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({display_brigthness[12],\u_sq/sh1 [1]}),
    .e({open_n37998,\u_sq/e1 [1]}),
    .mi({pat_wr_f[1],pat_wr_f[4]}),
    .f({_al_u1748_o,\u_sq/e1f_n [1]}),
    .q({\u_sq/sh1 [1],\u_sq/sh1 [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b20|u_sq/reg7_b22  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[4],pat_wr_n[6]}),
    .q({\u_sq/sh1 [20],\u_sq/sh1 [22]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b21  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({open_n38061,pat_wr_n[5]}),
    .q({open_n38068,\u_sq/sh1 [21]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b23  (
    .c({open_n38073,io_mcu_data_pad[6]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({open_n38074,io_mcu_data_pad[7]}),
    .mi({open_n38078,pat_wr_n[7]}),
    .f({open_n38091,_al_u1392_o}),
    .q({open_n38095,\u_sq/sh1 [23]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b25|u_sq/reg7_b24  (
    .a({open_n38096,_al_u1392_o}),
    .b({open_n38097,io_mcu_data_pad[5]}),
    .c({n687_lutinv,io_mcu_data_pad[4]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({_al_u1552_o,io_mcu_data_pad[3]}),
    .mi(pat_wr_n[9:8]),
    .f({mux100_b0_sel_is_3_o,_al_u1693_o}),
    .q(\u_sq/sh1 [25:24]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b26|u_sq/reg7_b30  (
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/ct_s [2],\u_sq/ct_s [2]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({pat_ctl[5],pat_ctl[5]}),
    .mi({pat_wr_n[10],pat_wr_n[14]}),
    .f({\u_sq/commit ,\u_sq/commit_hfnopt2_2 }),
    .q({\u_sq/sh1 [26],\u_sq/sh1 [30]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b27  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({open_n38139,pat_wr_n[11]}),
    .q({open_n38157,\u_sq/sh1 [27]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b28|u_sq/reg7_b29  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[12],pat_wr_n[13]}),
    .q({\u_sq/sh1 [28],\u_sq/sh1 [29]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b2|u_sq/reg7_b0  (
    .a({display_brigthness[12],\u_sq/sh1 [0]}),
    .b({display_brigthness[13],\u_sq/e1 [0]}),
    .c({\display_brightness/count [12],open_n38182}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({\display_brightness/count [13],\u_sq/commit_hfnopt2_1 }),
    .mi({pat_wr_f[2],pat_wr_f[0]}),
    .f({_al_u1744_o,\u_sq/e1f_n [0]}),
    .q({\u_sq/sh1 [2],\u_sq/sh1 [0]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b3  (
    .a({open_n38201,_al_u1744_o}),
    .b({open_n38202,_al_u1745_o}),
    .c({open_n38203,display_brigthness[14]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({open_n38204,\display_brightness/count [14]}),
    .mi({open_n38208,pat_wr_f[3]}),
    .f({open_n38221,_al_u1746_o}),
    .q({open_n38225,\u_sq/sh1 [3]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b31|u_sq/reg7_b48  (
    .c(sample_rate_divider[11:10]),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({_al_u745_o,_al_u745_o}),
    .mi({pat_wr_n[15],pat_wr_lvl}),
    .f(sample_rate_divider_eff[11:10]),
    .q({\u_sq/sh1 [31],\u_sq/sh1 [48]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b32|u_sq/reg7_b34  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[16],pat_wr_n[18]}),
    .q({\u_sq/sh1 [32],\u_sq/sh1 [34]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b33  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({open_n38290,pat_wr_n[17]}),
    .q({open_n38297,\u_sq/sh1 [33]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b35|u_sq/reg7_b37  (
    .a({oc_2A[0],oc_2A[10]}),
    .b({oc_2A[8],oc_2A[2]}),
    .c({mcu_state[0],mcu_state[0]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({mcu_state[1],mcu_state[1]}),
    .mi({pat_wr_n[19],pat_wr_n[21]}),
    .f({_al_u2162_o,_al_u2024_o}),
    .q({\u_sq/sh1 [35],\u_sq/sh1 [37]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b36  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({open_n38327,pat_wr_n[20]}),
    .q({open_n38345,\u_sq/sh1 [36]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b38|u_sq/reg7_b39  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[22],pat_wr_n[23]}),
    .q({\u_sq/sh1 [38],\u_sq/sh1 [39]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b40|u_sq/reg7_b44  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[24],pat_wr_n[28]}),
    .q({\u_sq/sh1 [40],\u_sq/sh1 [44]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b41|u_sq/reg7_b43  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[25],pat_wr_n[27]}),
    .q({\u_sq/sh1 [41],\u_sq/sh1 [43]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b42|u_sq/reg7_b46  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[26],pat_wr_n[30]}),
    .q({\u_sq/sh1 [42],\u_sq/sh1 [46]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg7_b45|u_sq/reg7_b47  (
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .mi({pat_wr_n[29],pat_wr_n[31]}),
    .q({\u_sq/sh1 [45],\u_sq/sh1 [47]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg7_b9|u_sq/reg7_b10  (
    .a({open_n38474,pat_ctl[5]}),
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/ct_s [2],\u_sq/ct_s [2]}),
    .ce(\u_sq/n26 ),
    .clk(clk_200MHz),
    .d({pat_ctl[5],\u_sq/sh1 [5]}),
    .e({open_n38475,\u_sq/e1 [5]}),
    .mi({pat_wr_f[9],pat_wr_f[10]}),
    .f({\u_sq/commit_hfnopt2_1 ,\u_sq/e1f_n [5]}),
    .q({\u_sq/sh1 [9],\u_sq/sh1 [10]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b1  (
    .a({open_n38492,display_brigthness[13]}),
    .b({open_n38493,display_brigthness[14]}),
    .c({open_n38494,\display_brightness/count [13]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({open_n38495,\display_brightness/count [14]}),
    .mi({open_n38506,\u_sq/sh0 [1]}),
    .f({open_n38508,_al_u1745_o}),
    .q({open_n38512,\u_sq/e0 [1]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b10|u_sq/reg8_b5  (
    .a({\u_sq/e0 [10],\u_sq/e0 [5]}),
    .c({\u_sq/sh0 [10],\u_sq/sh0 [5]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({\u_sq/commit_hfnopt2_1 ,\u_sq/commit_hfnopt2_1 }),
    .mi({\u_sq/sh0 [10],\u_sq/sh0 [5]}),
    .f({\u_sq/e0f_n [10],\u_sq/e0f_n [5]}),
    .q({\u_sq/e0 [10],\u_sq/e0 [5]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b11|u_sq/reg9_b7  (
    .a({open_n38529,\u_sq/e1 [7]}),
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/ct_s [2],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({pat_ctl[5],\u_sq/sh1 [7]}),
    .e({open_n38530,pat_ctl[5]}),
    .mi({\u_sq/sh0 [11],\u_sq/sh1 [7]}),
    .f({\u_sq/commit_hfnopt2_0 ,\u_sq/e1f_n [7]}),
    .q({\u_sq/e0 [11],\u_sq/e1 [7]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b13|u_sq/reg8_b14  (
    .a({pat_ctl[5],pat_ctl[5]}),
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/ct_s [2],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({\u_sq/sh0 [11],\u_sq/sh0 [12]}),
    .e({\u_sq/e0 [11],\u_sq/e0 [12]}),
    .mi({\u_sq/sh0 [13],\u_sq/sh0 [14]}),
    .f({\u_sq/e0f_n [11],\u_sq/e0f_n [12]}),
    .q({\u_sq/e0 [13],\u_sq/e0 [14]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b16  (
    .c({open_n38567,n658_lutinv}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({open_n38568,_al_u1556_o}),
    .mi({open_n38579,\u_sq/sh0 [16]}),
    .f({open_n38581,mux77_b0_sel_is_3_o}),
    .q({open_n38585,\u_sq/e0 [16]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b17|u_sq/reg8_b18  (
    .c({n661_lutinv,_al_u1556_o}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({_al_u1552_o,n664_lutinv}),
    .mi({\u_sq/sh0 [17],\u_sq/sh0 [18]}),
    .f({mux78_b10_sel_is_3_o,mux79_b0_sel_is_3_o}),
    .q({\u_sq/e0 [17],\u_sq/e0 [18]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b2  (
    .b({open_n38610,display_brigthness[15]}),
    .c({open_n38611,\display_brightness/count [15]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({open_n38612,_al_u1746_o}),
    .mi({open_n38616,\u_sq/sh0 [2]}),
    .f({open_n38629,_al_u1747_o}),
    .q({open_n38633,\u_sq/e0 [2]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b20|u_sq/reg8_b12  (
    .a({pat_ctl[5],pat_ctl[5]}),
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/ct_s [2],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d(\u_sq/sh0 [14:13]),
    .e(\u_sq/e0 [14:13]),
    .mi({\u_sq/sh0 [20],\u_sq/sh0 [12]}),
    .f(\u_sq/e0f_n [14:13]),
    .q({\u_sq/e0 [20],\u_sq/e0 [12]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b22|u_sq/reg8_b21  (
    .a({pat_ctl[0],pat_ctl[0]}),
    .b({pat_ctl[1],pat_ctl[1]}),
    .c({\u_sq/go ,\u_sq/go }),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({pat_running,\u_sq/ct_s [1]}),
    .e({open_n38650,\u_sq/ct_s [2]}),
    .mi(\u_sq/sh0 [22:21]),
    .f({_al_u1603_o,\u_sq/n46 }),
    .q(\u_sq/e0 [22:21]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b23|u_sq/reg8_b27  (
    .c(sample_rate_divider[2:1]),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\u_sq/sh0 [23],\u_sq/sh0 [27]}),
    .f(sample_rate_divider_eff[2:1]),
    .q({\u_sq/e0 [23],\u_sq/e0 [27]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b24  (
    .b({open_n38691,\u_sq/mode [0]}),
    .c({open_n38692,\u_sq/mode [1]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({open_n38693,_al_u671_o}),
    .mi({open_n38704,\u_sq/sh0 [24]}),
    .f({open_n38706,_al_u2175_o}),
    .q({open_n38710,\u_sq/e0 [24]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b25|u_sq/reg9_b25  (
    .c(sample_rate_divider[6:5]),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\u_sq/sh0 [25],\u_sq/sh1 [25]}),
    .f(sample_rate_divider_eff[6:5]),
    .q({\u_sq/e0 [25],\u_sq/e1 [25]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b28  (
    .c({open_n38733,pat_running}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({open_n38734,\u_sq/go }),
    .mi({open_n38745,\u_sq/sh0 [28]}),
    .f({open_n38747,\u_sq/u39_sel_is_2_o }),
    .q({open_n38751,\u_sq/e0 [28]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b30|u_sq/reg8_b31  (
    .a({open_n38752,_al_u2175_o}),
    .b({\u_sq/idle_lv ,_al_u1549_o}),
    .c({pat_running,\u_sq/cur }),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({\u_sq/go ,pat_running}),
    .mi({\u_sq/sh0 [30],\u_sq/sh0 [31]}),
    .f({_al_u1606_o,_al_u2176_o}),
    .q({\u_sq/e0 [30],\u_sq/e0 [31]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b37|u_sq/reg9_b48  (
    .c({sample_rate_divider[7],sample_rate_divider[9]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({_al_u745_o,_al_u745_o}),
    .mi({\u_sq/sh0 [37],\u_sq/sh1 [48]}),
    .f({sample_rate_divider_eff[7],sample_rate_divider_eff[9]}),
    .q({\u_sq/e0 [37],\u_sq/e1 [48]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b39  (
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .mi({open_n38811,\u_sq/sh0 [39]}),
    .q({open_n38818,\u_sq/e0 [39]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b42  (
    .a({open_n38819,oc_2A[12]}),
    .b({open_n38820,oc_2A[13]}),
    .c({open_n38821,oc_2A[14]}),
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .d({open_n38822,oc_2A[15]}),
    .mi({open_n38833,\u_sq/sh0 [42]}),
    .f({open_n38835,n53}),
    .q({open_n38839,\u_sq/e0 [42]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b43  (
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .mi({open_n38851,\u_sq/sh0 [43]}),
    .q({open_n38869,\u_sq/e0 [43]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b44|u_sq/reg8_b46  (
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .mi({\u_sq/sh0 [44],\u_sq/sh0 [46]}),
    .q({\u_sq/e0 [44],\u_sq/e0 [46]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b45|u_sq/reg9_b45  (
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .mi({\u_sq/sh0 [45],\u_sq/sh1 [45]}),
    .q({\u_sq/e0 [45],\u_sq/e1 [45]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b47|u_sq/reg9_b47  (
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .mi({\u_sq/sh0 [47],\u_sq/sh1 [47]}),
    .q({\u_sq/e0 [47],\u_sq/e1 [47]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b48|u_sq/reg8_b35  (
    .a({open_n38946,oc_2A[1]}),
    .b({open_n38947,oc_2A[9]}),
    .c({sample_rate_divider[8],mcu_state[0]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({_al_u745_o,mcu_state[1]}),
    .mi({\u_sq/sh0 [48],\u_sq/sh0 [35]}),
    .f({sample_rate_divider_eff[8],_al_u2140_o}),
    .q({\u_sq/e0 [48],\u_sq/e0 [35]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b4|u_sq/reg9_b5  (
    .a({pat_ctl[5],pat_ctl[5]}),
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/e0 [3],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({\u_sq/sh0 [3],\u_sq/e0 [4]}),
    .e({\u_sq/ct_s [2],\u_sq/sh0 [4]}),
    .mi({\u_sq/sh0 [4],\u_sq/sh1 [5]}),
    .f({\u_sq/e0f_n [3],\u_sq/e0f_n [4]}),
    .q({\u_sq/e0 [4],\u_sq/e1 [5]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b6|u_sq/reg8_b3  (
    .a({\u_sq/e0 [6],pat_ctl[5]}),
    .b({open_n38982,\u_sq/ct_s [1]}),
    .c({\u_sq/sh0 [6],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({\u_sq/commit_hfnopt2_1 ,\u_sq/sh1 [6]}),
    .e({open_n38983,\u_sq/e1 [6]}),
    .mi({\u_sq/sh0 [6],\u_sq/sh0 [3]}),
    .f({\u_sq/e0f_n [6],\u_sq/e1f_n [6]}),
    .q({\u_sq/e0 [6],\u_sq/e0 [3]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b7|u_sq/reg9_b10  (
    .a({pat_ctl[5],pat_ctl[5]}),
    .b({\u_sq/ct_s [1],\u_sq/ct_s [1]}),
    .c({\u_sq/ct_s [2],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({\u_sq/e1 [10],\u_sq/sh0 [9]}),
    .e({\u_sq/sh1 [10],\u_sq/e0 [9]}),
    .mi({\u_sq/sh0 [7],\u_sq/sh1 [10]}),
    .f({\u_sq/e1f_n [10],\u_sq/e0f_n [9]}),
    .q({\u_sq/e0 [7],\u_sq/e1 [10]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg8_b8|u_sq/reg9_b9  (
    .b({\u_sq/sh1 [9],\u_sq/sh0 [8]}),
    .c({\u_sq/commit_hfnopt2_1 ,\u_sq/commit_hfnopt2_1 }),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({\u_sq/e1 [9],\u_sq/e0 [8]}),
    .mi({\u_sq/sh0 [8],\u_sq/sh1 [9]}),
    .f({\u_sq/e1f_n [9],\u_sq/e0f_n [8]}),
    .q({\u_sq/e0 [8],\u_sq/e1 [9]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg8_b9|u_sq/reg9_b8  (
    .a({open_n39032,\u_sq/e1 [8]}),
    .b({\u_sq/sh0 [7],\u_sq/ct_s [1]}),
    .c({\u_sq/e0 [7],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({\u_sq/commit_hfnopt2_0 ,\u_sq/sh1 [8]}),
    .e({open_n39033,pat_ctl[5]}),
    .mi({\u_sq/sh0 [9],\u_sq/sh1 [8]}),
    .f({\u_sq/e0f_n [7],\u_sq/e1f_n [8]}),
    .q({\u_sq/e0 [9],\u_sq/e1 [8]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b11|u_sq/reg9_b13  (
    .a({\u_sq/commit ,open_n39050}),
    .c({\u_sq/sh1 [12],pat_running}),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d({\u_sq/e1 [12],\u_sq/cnt [32]}),
    .mi({\u_sq/sh1 [11],\u_sq/sh1 [13]}),
    .f({\u_sq/e1f_n [12],\u_sq/n9 }),
    .q({\u_sq/e1 [11],\u_sq/e1 [13]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b12|u_sq/reg8_b26  (
    .a({open_n39071,pat_ctl[5]}),
    .b({\u_sq/sh1 [11],\u_sq/ct_s [1]}),
    .c({\u_sq/e1 [11],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d({\u_sq/commit ,\u_sq/sh1 [15]}),
    .e({open_n39072,\u_sq/e1 [15]}),
    .mi({\u_sq/sh1 [12],\u_sq/sh0 [26]}),
    .f({\u_sq/e1f_n [11],\u_sq/e1f_n [15]}),
    .q({\u_sq/e1 [12],\u_sq/e0 [26]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b14|u_sq/reg9_b15  (
    .a({open_n39089,\u_sq/stop }),
    .b({\u_sq/sh1 [13],\u_sq/n8_lutinv }),
    .c({\u_sq/e1 [13],\u_sq/n9 }),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d({\u_sq/commit ,\u_sq/cur }),
    .e({open_n39090,\u_sq/go }),
    .mi({\u_sq/sh1 [14],\u_sq/sh1 [15]}),
    .f({\u_sq/e1f_n [13],\u_sq/cur_n_lutinv }),
    .q({\u_sq/e1 [14],\u_sq/e1 [15]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b16|u_sq/reg9_b17  (
    .a({open_n39107,dec_pc[14]}),
    .b({open_n39108,dec_pc[15]}),
    .c({n658_lutinv,dec_pc[16]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({_al_u1552_o,dec_pc[17]}),
    .e({open_n39109,dec_pc[18]}),
    .mi({\u_sq/sh1 [16],\u_sq/sh1 [17]}),
    .f({mux77_b10_sel_is_3_o,_al_u1405_o}),
    .q({\u_sq/e1 [16],\u_sq/e1 [17]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b18|u_sq/reg9_b22  (
    .c({n664_lutinv,\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({_al_u1552_o,\u_sq/ct_s [1]}),
    .mi({\u_sq/sh1 [18],\u_sq/sh1 [22]}),
    .f({mux79_b10_sel_is_3_o,\u_sq/ct_ev }),
    .q({\u_sq/e1 [18],\u_sq/e1 [22]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b19|u_sq/reg8_b19  (
    .a({n316,open_n39148}),
    .b({_al_u1540_o,open_n39149}),
    .c({oc_v[1],sample_rate_divider[3]}),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({sample_write_enable,_al_u745_o}),
    .mi({\u_sq/sh1 [19],\u_sq/sh0 [19]}),
    .f({mux49_b0_sel_is_3_o,sample_rate_divider_eff[3]}),
    .q({\u_sq/e1 [19],\u_sq/e0 [19]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b1|u_sq/reg8_b0  (
    .a({open_n39168,pat_ctl[5]}),
    .b({open_n39169,\u_sq/ct_s [1]}),
    .c({\display_brightness/count [15],\u_sq/ct_s [2]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({display_brigthness[15],\u_sq/sh0 [2]}),
    .e({open_n39170,\u_sq/e0 [2]}),
    .mi({\u_sq/sh1 [1],\u_sq/sh0 [0]}),
    .f({\display_brightness/lt0/diff [15],\u_sq/e0f_n [2]}),
    .q({\u_sq/e1 [1],\u_sq/e0 [0]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg9_b21|u_sq/reg9_b20  (
    .a({open_n39187,pat_ctl[0]}),
    .b({\u_sq/ct_s [1],pat_ctl[1]}),
    .c(\u_sq/ct_s [2:1]),
    .ce(\u_sq/commit_hfnopt2_0 ),
    .clk(clk_200MHz),
    .d({pat_ctl[5],\u_sq/ct_s [2]}),
    .mi(\u_sq/sh1 [21:20]),
    .f({\u_sq/commit_hfnopt2_3 ,\u_sq/stop }),
    .q(\u_sq/e1 [21:20]));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg9_b24|u_sq/reg9_b23  (
    .a({_al_u2116_o,open_n39202}),
    .b({_al_u1551_o,open_n39203}),
    .c({mcu_command[0],sample_rate_divider[4]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({pat_running,_al_u745_o}),
    .mi(\u_sq/sh1 [24:23]),
    .f({_al_u2117_o,sample_rate_divider_eff[4]}),
    .q(\u_sq/e1 [24:23]));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg9_b26  (
    .b({open_n39220,\u_sq/sh1 [14]}),
    .c({open_n39221,\u_sq/commit }),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d({open_n39222,\u_sq/e1 [14]}),
    .mi({open_n39233,\u_sq/sh1 [26]}),
    .f({open_n39235,\u_sq/e1f_n [14]}),
    .q({open_n39239,\u_sq/e1 [26]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b27|u_sq/reg9_b36  (
    .a({open_n39240,\u_sq/n8_lutinv }),
    .b({open_n39241,pat_level}),
    .c({n687_lutinv,\u_sq/u39_sel_is_2_o }),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({_al_u1556_o,\u_sq/cnt [32]}),
    .e({open_n39242,\u_sq/nx_e [48]}),
    .mi({\u_sq/sh1 [27],\u_sq/sh1 [36]}),
    .f({mux101_b24_sel_is_3_o,_al_u1605_o}),
    .q({\u_sq/e1 [27],\u_sq/e1 [36]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b2|u_sq/reg9_b0  (
    .a({\u_sq/e1 [2],open_n39259}),
    .b({\u_sq/sh1 [2],\u_sq/sh0 [1]}),
    .c({\u_sq/commit_hfnopt2_1 ,\u_sq/e0 [1]}),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .d({open_n39260,\u_sq/commit_hfnopt2_1 }),
    .mi({\u_sq/sh1 [2],\u_sq/sh1 [0]}),
    .f({\u_sq/e1f_n [2],\u_sq/e0f_n [1]}),
    .q({\u_sq/e1 [2],\u_sq/e1 [0]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b31|u_sq/reg8_b38  (
    .a({_al_u1365_o,_al_u1365_o}),
    .b({\u_sq/wr_ev_lutinv ,\u_sq/wr_ev_lutinv }),
    .c({pat_wr_idx[0],pat_wr_idx[0]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({pat_wr_idx[1],pat_wr_idx[1]}),
    .mi({\u_sq/sh1 [31],\u_sq/sh0 [38]}),
    .f({\u_sq/n26 ,\u_sq/n23 }),
    .q({\u_sq/e1 [31],\u_sq/e0 [38]}));  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg9_b35  (
    .c({open_n39301,\u_sq/wr_s [2]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({open_n39302,\u_sq/wr_s [1]}),
    .mi({open_n39313,\u_sq/sh1 [35]}),
    .f({open_n39315,\u_sq/wr_ev_lutinv }),
    .q({open_n39319,\u_sq/e1 [35]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b37|u_sq/reg9_b38  (
    .a({n78,oc_2A[0]}),
    .b({n53,oc_2A[1]}),
    .c({n61,oc_2A[2]}),
    .ce(\u_sq/commit_hfnopt2_3 ),
    .clk(clk_200MHz),
    .d({n58,oc_2A[3]}),
    .mi({\u_sq/sh1 [37],\u_sq/sh1 [38]}),
    .f({_al_u1540_o,n78}),
    .q({\u_sq/e1 [37],\u_sq/e1 [38]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b39  (
    .a({open_n39338,oc_2A[4]}),
    .b({open_n39339,oc_2A[5]}),
    .c({open_n39340,oc_2A[7]}),
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .d({open_n39341,oc_2A[6]}),
    .mi({open_n39345,\u_sq/sh1 [39]}),
    .f({open_n39358,n61}),
    .q({open_n39362,\u_sq/e1 [39]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_MSLICE \u_sq/reg9_b3|u_sq/reg9_b4  (
    .a({\u_sq/e1 [3],\u_sq/e1 [4]}),
    .b({\u_sq/commit_hfnopt2_1 ,\u_sq/sh1 [4]}),
    .c({\u_sq/sh1 [3],\u_sq/commit_hfnopt2_1 }),
    .ce(\u_sq/commit_hfnopt2_1 ),
    .clk(clk_200MHz),
    .mi({\u_sq/sh1 [3],\u_sq/sh1 [4]}),
    .f({\u_sq/e1f_n [3],\u_sq/e1f_n [4]}),
    .q({\u_sq/e1 [3],\u_sq/e1 [4]}));  // zaklad.v(694)
  // zaklad.v(694)
  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/reg9_b46|u_sq/reg9_b42  (
    .a({oc_2A[10],oc_2A[12]}),
    .b({oc_2A[9],oc_2A[4]}),
    .c({oc_2A[8],mcu_state[0]}),
    .ce(\u_sq/commit_hfnopt2_2 ),
    .clk(clk_200MHz),
    .d({oc_2A[11],mcu_state[1]}),
    .mi({\u_sq/sh1 [46],\u_sq/sh1 [42]}),
    .f({n58,_al_u2063_o}),
    .q({\u_sq/e1 [46],\u_sq/e1 [42]}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/running_reg  (
    .b({open_n39399,\u_sq/sh0 [15]}),
    .c({open_n39400,\u_sq/e0 [15]}),
    .ce(\u_sq/go ),
    .clk(clk_200MHz),
    .d({open_n39401,\u_sq/commit }),
    .mi({open_n39405,1'b1}),
    .sr(\u_sq/stop ),
    .f({open_n39417,\u_sq/e0f_n [15]}),
    .q({open_n39421,pat_running}));  // zaklad.v(694)
  AL_PHY_LSLICE \u_sq/sub0/u11_al_u2415  (
    .a({\u_sq/cnt [13],\u_sq/cnt [11]}),
    .b({\u_sq/cnt [14],\u_sq/cnt [12]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c11 ),
    .mi({adc_d1[29],adc_q1[29]}),
    .f({\u_sq/n52 [13],\u_sq/n52 [11]}),
    .fco(\u_sq/sub0/c15 ),
    .fx({\u_sq/n52 [14],\u_sq/n52 [12]}),
    .q({adc_dd1[29],adc_d1[29]}));
  AL_PHY_LSLICE \u_sq/sub0/u15_al_u2416  (
    .a({\u_sq/cnt [17],\u_sq/cnt [15]}),
    .b({\u_sq/cnt [18],\u_sq/cnt [16]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c15 ),
    .mi({adc_d1[30],adc_q1[30]}),
    .f({\u_sq/n52 [17],\u_sq/n52 [15]}),
    .fco(\u_sq/sub0/c19 ),
    .fx({\u_sq/n52 [18],\u_sq/n52 [16]}),
    .q({adc_dd1[30],adc_d1[30]}));
  AL_PHY_LSLICE \u_sq/sub0/u19_al_u2417  (
    .a({\u_sq/cnt [21],\u_sq/cnt [19]}),
    .b({\u_sq/cnt [22],\u_sq/cnt [20]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c19 ),
    .mi({open_n39449,adc_d1[31]}),
    .f({\u_sq/n52 [21],\u_sq/n52 [19]}),
    .fco(\u_sq/sub0/c23 ),
    .fx({\u_sq/n52 [22],\u_sq/n52 [20]}),
    .q({open_n39462,adc_dd1[31]}));
  AL_PHY_LSLICE \u_sq/sub0/u23_al_u2418  (
    .a({\u_sq/cnt [25],\u_sq/cnt [23]}),
    .b({\u_sq/cnt [26],\u_sq/cnt [24]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c23 ),
    .mi({open_n39464,adc_q1[31]}),
    .f({\u_sq/n52 [25],\u_sq/n52 [23]}),
    .fco(\u_sq/sub0/c27 ),
    .fx({\u_sq/n52 [26],\u_sq/n52 [24]}),
    .q({open_n39477,adc_d1[31]}));
  AL_PHY_LSLICE \u_sq/sub0/u27_al_u2419  (
    .a({\u_sq/cnt [29],\u_sq/cnt [27]}),
    .b({\u_sq/cnt [30],\u_sq/cnt [28]}),
    .c(2'b11),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c27 ),
    .f({\u_sq/n52 [29],\u_sq/n52 [27]}),
    .fco(\u_sq/sub0/c31 ),
    .fx({\u_sq/n52 [30],\u_sq/n52 [28]}));
  AL_PHY_LSLICE \u_sq/sub0/u31_al_u2420  (
    .a({open_n39496,\u_sq/cnt [31]}),
    .b({open_n39497,\u_sq/cnt [32]}),
    .c(2'b11),
    .d({open_n39500,1'b0}),
    .e({open_n39501,1'b0}),
    .fci(\u_sq/sub0/c31 ),
    .f({open_n39516,\u_sq/n52 [31]}),
    .fx({open_n39518,\u_sq/n52 [32]}));
  AL_PHY_LSLICE \u_sq/sub0/u3_al_u2413  (
    .a({\u_sq/cnt [5],\u_sq/cnt [3]}),
    .b({\u_sq/cnt [6],\u_sq/cnt [4]}),
    .c(2'b11),
    .ce(\u_sq/n23 ),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c3 ),
    .mi({open_n39521,pat_wr_f[15]}),
    .f({\u_sq/n52 [5],\u_sq/n52 [3]}),
    .fco(\u_sq/sub0/c7 ),
    .fx({\u_sq/n52 [6],\u_sq/n52 [4]}),
    .q({open_n39534,\u_sq/sh0 [15]}));
  AL_PHY_LSLICE \u_sq/sub0/u7_al_u2414  (
    .a({\u_sq/cnt [9],\u_sq/cnt [7]}),
    .b({\u_sq/cnt [10],\u_sq/cnt [8]}),
    .c(2'b11),
    .clk(clk_200MHz),
    .d(2'b00),
    .e(2'b00),
    .fci(\u_sq/sub0/c7 ),
    .mi(adc_d1[28:27]),
    .f({\u_sq/n52 [9],\u_sq/n52 [7]}),
    .fco(\u_sq/sub0/c11 ),
    .fx({\u_sq/n52 [10],\u_sq/n52 [8]}),
    .q(adc_dd1[28:27]));
  AL_PHY_LSLICE \u_sq/sub0/ucin_al_u2412  (
    .a({\u_sq/cnt [1],1'b0}),
    .b({\u_sq/cnt [2],\u_sq/cnt [0]}),
    .c(2'b11),
    .ce(\u_sq/commit ),
    .clk(clk_200MHz),
    .d(2'b01),
    .e(2'b01),
    .mi({open_n39549,\u_sq/sh0 [15]}),
    .f({\u_sq/n52 [1],open_n39562}),
    .fco(\u_sq/sub0/c3 ),
    .fx({\u_sq/n52 [2],\u_sq/n52 [0]}),
    .q({open_n39563,\u_sq/e0 [15]}));

endmodule 

