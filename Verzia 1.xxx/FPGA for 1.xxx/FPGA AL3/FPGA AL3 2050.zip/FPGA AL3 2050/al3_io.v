//-------------------------------------------------------------------------------------
// AL3A10 build of the EF2L45 port: ef2_iddr / ef2_oddr (the wrappers zaklad.v instantiates) on the AL3 macros,
// exactly as MCP 0x153F instantiated them: AL_LOGIC_IDDR q1 = rising-edge sample, q2 = falling-edge sample;
// AL_LOGIC_ODDR d1 = high half, d2 = low half (zaklad.v ties d1 = d2).
//-------------------------------------------------------------------------------------
module ef2_iddr (output q1, output q2, input clk, input d, input rst);
  AL_LOGIC_IDDR #(.SRMODE("SYNC")) u_iddr (.q1(q1), .q2(q2), .clk(clk), .d(d), .rst(rst));
endmodule

module ef2_oddr (output q, input clk, input d1, input d2, input rst);
  AL_LOGIC_ODDR u_oddr (.q(q), .clk(clk), .d1(d1), .d2(d2), .rst(rst));
endmodule
