//******************************************************************************
/* 
 * File:   generator.c
 * Author: dk
 * 
 * Created on November 26, 2025, 9:52 AM
 */
//******************************************************************************


#include "types.h"
#include "menu.h"
#include "test.h"
#include "scope_functions.h"
#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "spi_control.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "DS3231.h"

#include "usb_interface.h"
#include "cdc_class.h"
#include "variables.h"

#include "PC_interface.h"

#include "generator.h"

//#include <stdint.h>
//#include <stdbool.h>

#define NUMBUF_MAX 12   // + / - + max 10 číslic

char numbuf[NUMBUF_MAX];
uint8 numbuf_len = 0;


//------------------------------------------------------------
// Vymaže buffer
//------------------------------------------------------------
void buffer_clear(void)
{
    numbuf_len = 12;
    //numbuf[0] = '\0';
  while (numbuf_len) {numbuf[numbuf_len] = ' ';numbuf_len--;}
  numbuf[0] = '_';
  //numbuf[0] = '\0';
}


//------------------------------------------------------------
// Nastaví znamienko.
// '+' alebo '-'
// Ak buffer začína číslom, znamienko sa vloží na začiatok.
//------------------------------------------------------------
void buffer_set_sign(char sign)
{
    if (sign != '+' && sign != '-')
        return;

    if (numbuf_len == 0) {
        // prázdny buffer -> vložíme znamienko
        numbuf[0] = sign;
        numbuf[1] = '\0';
        numbuf_len = 1;
        return;
    }

    if (numbuf[0] == '+' || numbuf[0] == '-') {
        // znamienko už existuje → prepíšeme
        numbuf[0] = sign;
    } else {
        // buffer začína číslicou → vložíme znamienko pred ňu
        if (numbuf_len < NUMBUF_MAX - 1) {
            // posun doprava
            for (int i = numbuf_len; i > 0; i--) {
                numbuf[i] = numbuf[i - 1];
            }
            numbuf[0] = sign;
            numbuf_len++;
            numbuf[numbuf_len] = '\0';
        }
    }
}


//------------------------------------------------------------
// Pridanie číslice na koniec
//------------------------------------------------------------
void buffer_add_digit(char digit)
{
    if (digit < '0' || digit > '9')
        return;

    if (numbuf_len < NUMBUF_MAX - 1) {
        numbuf[numbuf_len++] = digit;
        numbuf[numbuf_len] = '\0';
    }
}


//------------------------------------------------------------
// Backspace – zmaže posledný znak.
// Ak zmaže znamienko a ostanú čísla → buffer bez znamienka je OK.
//------------------------------------------------------------
void buffer_backspace(void)
{
    if (numbuf_len == 0)
        return;

    numbuf_len--;

    if (numbuf_len == 0) {
        numbuf[0] = '\0';
        numbuf[0] = '_';
        return;
    }

    numbuf[numbuf_len] = '\0';
}


//------------------------------------------------------------
// Konverzia buffra na int32
//------------------------------------------------------------
int32 buffer_to_int32(void)
{
    int64 value = 0;
    int sign = 1;  // +1 alebo -1
    uint8 start = 0;

    if (numbuf_len == 0)
        return 0;

    if (numbuf[0] == '-') {
        sign = -1;
        start = 1;
    } else if (numbuf[0] == '+') {
        start = 1;
    }

    for (uint8 i = start; i < numbuf_len; i++) {
        value = value * 10 + (numbuf[i] - '0');

        // kontrola pretečenia int32
        if (value > 2147483647LL) {
            if (sign == -1 && value == 2147483648LL)
                return -2147483648;
            return (sign == -1 ? -2147483648 : 2147483647);
        }
    }

    return (int32)(value * sign);
}

//==============================================================================

void buffer_set_number(int32 value)
{
    // vymazanie buffra
    buffer_clear();

    // načítanie znamienka
    if (value < 0) {
        buffer_set_sign('-');
        value = -value;
    } 
    //else { buffer_set_sign('+'); }

    // dočasné pole na prepis čísla
    char tmp[12];
    int len = 0;

    // špeciálny prípad 0
    if (value == 0) {
        buffer_add_digit('0');
        return;
    }

    // rozloženie čísla odzadu
    while (value > 0 && (len < (int)sizeof(tmp))) {
        tmp[len++] = '0' + (value % 10);
        value /= 10;
    }

    // teraz otočíme číslo a vložíme ho do buffra
    for (int i = len - 1; i >= 0; i--) {
        buffer_add_digit(tmp[i]);
    }
}


/*
 
 buffer_clear();
if (value < 0)
    value = -value;

 */