//******************************************************************************
/* 
 * File:   generator.h
 * Author: dk
 *
 * Created on November 26, 2025, 9:52 AM
 */
//******************************************************************************
#ifndef GENERATOR_H
#define GENERATOR_H
//==============================================================================

void buffer_clear(void);
void buffer_set_sign(char sign);
void buffer_add_digit(char digit);
void buffer_backspace(void);
int32 buffer_to_int32(void);



//==============================================================================
#endif /* GENERATOR_H */
