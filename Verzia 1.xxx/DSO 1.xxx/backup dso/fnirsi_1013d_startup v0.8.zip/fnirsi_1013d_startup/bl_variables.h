//----------------------------------------------------------------------------------------------------------------------------------

#ifndef BL_VARIABLES_H
#define BL_VARIABLES_H

//----------------------------------------------------------------------------------------------------------------------------------

#include "types.h"
#include "bl_font_structs.h"

#define VERSION_STRING             "v0.8" // check fpga off, set to wait 1s

#define BLACK_COLOR            0x00000000   //*
#define DARKGREY_COLOR         0x00181818   //*
#define LIGHTGREY_COLOR        0x00333333   //*
#define GREY_COLOR             0x00444444   //* 
#define LIGHTGREY1_COLOR       0x00606060   //* 
#define WHITE_COLOR            0x00FFFFFF   //*
#define RED_COLOR              0x00FF0000   //*
#define YELLOW_COLOR           0x00FFFF00   //*
#define DARKGREEN_COLOR        0x0000BB00   //*
#define GREEN_COLOR            0x0000FF00   //*
#define BLUE_COLOR             0x0000FFFF   //*
#define DARKBLUE_COLOR         0x00000078   //* 
#define ORANGE_COLOR           0x00FF8000   //*
#define MAGENTA_COLOR          0x00FF00FF   //*

//----------------------------------------------------------------------------------------------------------------------------------
//Screen information
//----------------------------------------------------------------------------------------------------------------------------------

#define SCREEN_WIDTH    800
#define SCREEN_HEIGHT   480

#define SCREEN_SIZE     (SCREEN_WIDTH * SCREEN_HEIGHT)

//----------------------------------------------------------------------------------------------------------------------------------
//Display data
//----------------------------------------------------------------------------------------------------------------------------------

//This first buffer is defined as 32 bits to be able to write it to file
extern uint32 maindisplaybuffer[SCREEN_SIZE / 2];

//----------------------------------------------------------------------------------------------------------------------------------

extern FONTDATA font_0;

//----------------------------------------------------------------------------------------------------------------------------------
//Touch data
//----------------------------------------------------------------------------------------------------------------------------------

#ifndef USE_TP_CONFIG
extern uint8 tp_config_data[186];

extern uint32 xscaler;
extern uint32 yscaler;
#endif

extern uint8  havetouch;
extern uint16 xtouch;
extern uint16 ytouch;

extern uint8 xswap;
extern uint8 yswap;

extern uint8 config_valid;

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------

#endif /* BL_VARIABLES_H */

//----------------------------------------------------------------------------------------------------------------------------------
