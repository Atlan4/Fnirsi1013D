//----------------------------------------------------------------------------------------------------------------------------------

#include "arm32.h"
#include "ccu_control.h"

#include "touchpanel.h"	    //add 0.025c

#include "dram_control.h"
#include "display_control.h"
#include "spi_control.h"
#include "bl_display_lib.h"
#include "bl-uart.h"
#include "bl_fpga_control.h"
#include "bl_sd_card_interface.h"
#include "bl_variables.h"

#include <string.h>

void load_from_SDcard(uint32 address);
//----------------------------------------------------------------------------------------------------------------------------------
// This code now works but needs a debug flag to disable the displaying of information
//
// For the 1014D a new version that only loads the main code without showing messages and does not wait for the FPGA
// can be distilled and tested.
//
// There is a problem with the SD card code though when used with a specific 4GB card. Could be a speed issue
//----------------------------------------------------------------------------------------------------------------------------------
// The bootloader itself starts on sector 16, so in the package the firmware should be copied in from address 0x8000
//  to allow for 32KB boot loader
//----------------------------------------------------------------------------------------------------------------------------------

#define UPDATE_PROGRAM_START_SECTOR    80
#define DSO_PROGRAM_START_SECTOR      750
#define DISPLAY_CONFIG_SECTOR         710

#define STARTUP_CONFIG_ADDRESS    (uint8*)0x81BFFC1F //value for default start firmware (0-pepco,1-fnirsi, 2-FEL, <3 skip menu)

//----------------------------------------------------------------------------------------------------------------------------------

//Buffer for reading header from SD card
unsigned char buffer[512];

unsigned int length;
//----------------------------------------------------------------------------------------------------------------------------------

int main(void)
{
  unsigned int address = 0x80000000; 
  int choice = 0;
  int i,j;
  uint32 waittime = 0;
  uint32 time = 0;
  
  //Initialize the clock system
  sys_clock_init();
  
  //Initialize the internal DRAM
  sys_dram_init();

  //Instead of full memory management just the caches enabled
  arm32_icache_enable();
  arm32_dcache_enable();
  
  //Initialize display (PORT D + DEBE)
  sys_init_display(SCREEN_WIDTH, SCREEN_HEIGHT, (uint16 *)maindisplaybuffer);
  
  //Setup the display lib
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_dimensions(SCREEN_WIDTH, SCREEN_HEIGHT);
  
  //Initialize FPGA (PORT E)
  fpga_init();
  
  //Got some time to spare
  for(j=0;j<1000;j++)       
  {
    //At 600MHz CPU_CLK 1000 = ~200uS
    for(i=0;i<1000;i++);
  }
  
  //Wait and make sure FPGA is ready
  //fpga_check_ready();   
  
  //Got some time to spare
  for(j=0;j<1000;j++)       //wait 1s
  {
    //At 600MHz CPU_CLK 1000 = ~200uS
    for(i=0;i<5000;i++);//5000 = 1ms
  }

  //Turn on the display brightness
  //fpga_set_backlight_brightness(0x4E20);//0xEA60-100%
  
  //Turn of the display brightness
  fpga_set_backlight_brightness(0x20);
  
  //Setup for error message display
  display_set_font(&font_0);
  
  //************* Display configuration reading and setting ********************
  
  //Initialize the SD card
  if(sd_card_init() != SD_OK)
  {
    display_set_fg_color(RED_COLOR);
    display_text(328, 300, "SD card init failed"); 

    //On error just frees
    while(1);
  }
  
  //Load the display configuration sector to DRAM before the startup screen program
  if(sd_card_read(DISPLAY_CONFIG_SECTOR, 1, (void *)0x81BFFC00) != SD_OK)
  {
    display_set_fg_color(BLACK_COLOR);
    //Fill the settings background
    display_fill_rect(0, 0, 800, 480); 
          
    display_set_fg_color(RED_COLOR);
    display_text(190, 300, "SD card, Failed reading display configuration sector");
      
    //On error just frees
    while(1);
  }
  
  //Set display with load configuration from DRAM (SD card)
  set_display_config();
  
  //Display the text with yellow color
  display_set_fg_color(YELLOW_COLOR);
  display_text(205, 430, "Many thanks to PECO, and small thanks to Atlan :)"); 
  
 //*****************************************************************************
  
  //Setup the touch panel interface
  tp_i2c_setup();
  havetouch = 0;
  xtouch = 0;
  ytouch = 0;
  
  //Scan the touch panel to see if there is user input
  //tp_i2c_read_status();
  
  //check SDcart startup settings
  uint8 *ptr = STARTUP_CONFIG_ADDRESS;
  choice = ptr[0];  //choice 1 for fnirsi firmware, 0 for peco firmware, 2 for FEL mode, 4 view choice menu
  //if ((choice > 3)||(havetouch == 1))  // choice>3 or touch detected view choice menu
  if (choice > 3)  // choice>3 view choice menu
  { choice &= 0x03; //choice 1 for fnirsi firmware, 0 for peco firmware, 2 for FEL mode
//------------------------------------------------------------------------------
  
    display_set_fg_color(LIGHTGREY_COLOR);
    //Fill the settings background
    display_fill_rect(40,  50, 122, 35);  //y55 d25 y52 d31
    display_fill_rect(340, 50, 130, 35);  
    display_fill_rect(620, 50, 138, 35); 
    display_fill_rect(360, 380, 80, 35); 
  
    //Set green rect on default settings
    display_set_fg_color(GREEN_COLOR);
    if(choice == 0) display_draw_rect(40,  50, 122, 35);  //PECO 40,  55, 122, 25
    if(choice == 2) display_draw_rect(340, 50, 130, 35);  //FEL mode 340, 55, 130, 25
    if(choice == 1) display_draw_rect(620, 50, 138, 35);  //FNIRSI 620, 55, 138, 25
      
    display_set_fg_color(WHITE_COLOR);
    //Setup the choices texts
    display_text(50,  60, "PECO firmware");
    display_text(350, 60, "Start FEL mode");
    display_text(630, 60, "FNIRSI firmware");
    display_text(377, 390, "Update");
  
    display_text(300, 150, "Reaming time to action:  s"); //Reaming time to action
    display_text( 40, 430, "BOOT fw "VERSION_STRING); 
    
    //Display the text with green color
    display_set_fg_color(GREEN_COLOR);
    display_text(300, 200, "Choices mode on the screen"); 
  
    waittime = 7000;  //~2s
  
    //Scan the touch panel to see if there is user input
    while(havetouch == 0) 
    //while(choice == 0)    
    {
        tp_i2c_read_status();
        if(havetouch == 1) waittime = 30000; //if touch increse time to 10sec
        havetouch = 0; 
      
        /*
        display_set_fg_color(BLACK_COLOR);
        //Fill the settings background
        display_fill_rect(50, 200, 200, 13);  //x , y , sirka, vyska
        display_set_fg_color(WHITE_COLOR);
        display_text(50,  180, "xtouch  ytouch");
        display_decimal(50,   200, xtouch);
        display_decimal(100,  200, ytouch);
    
        display_set_fg_color(RED_COLOR);
        display_text(337, 300, "Not an executable");
        //display_text(305, 320, "SD card first read failed");
        display_text(295, 320, "SD card program read failed");
        display_text(190, 340, "SD card, Failed reading display configuration sector");
        display_text(328, 360, "SD card init failed");
        */  
        //Display the button with green color
        display_set_fg_color(GREEN_COLOR);
    
        //Scan for where the touch is applied, PECO firmware - SDcart
        //if((xtouch >= 40) && (xtouch <= 160) && (ytouch >= 50) && (ytouch <= 90)) 
        if((xtouch >= 40) && (xtouch <= 160) && (ytouch >= 45) && (ytouch <= 95))  
        {   choice = 0; havetouch = 1; waittime = 1;
            //Fill the settings background
            display_fill_rect(40,  50, 122, 35);  
            display_set_fg_color(LIGHTGREY_COLOR);
            //Fill the settings background
            display_draw_rect(340, 50, 130, 35);  //340, 55, 130, 25
            display_draw_rect(620, 50, 138, 35); 
            display_set_fg_color(BLACK_COLOR);
            //Setup the choices texts
            display_text(50,  60, "PECO firmware");
        }
         
        //Scan for where the touch is applied, FEL mode - RAM
        if((xtouch >= 340) && (xtouch <= 470) && (ytouch >= 45) && (ytouch <= 95)) 
        {   choice = 2; havetouch = 1; waittime = 1;
            //Fill the settings background
            display_fill_rect(340, 50, 130, 35);  
            display_set_fg_color(LIGHTGREY_COLOR);
            //Fill the settings background
            display_draw_rect(40,  50, 122, 35); 
            display_draw_rect(620, 50, 138, 35); 
            display_set_fg_color(BLACK_COLOR);
            //Setup the choices texts
            display_text(350, 60, "Start FEL mode");
        }
          
        //Scan for where the touch is applied, Fnirsi firmware - SPI Flash
        //if((xtouch >= 620) && (xtouch <= 760) && (ytouch >= 50) && (ytouch <= 90)) 
        if((xtouch >= 620) && (xtouch <= 760) && (ytouch >= 45) && (ytouch <= 95)) 
        {   choice = 1; havetouch = 1; waittime = 1;
            //Fill the settings background
            display_fill_rect(620, 50, 138, 35); 
            display_set_fg_color(LIGHTGREY_COLOR);
            //Fill the settings background
            display_draw_rect(40,  50, 122, 35); 
            display_draw_rect(340, 50, 130, 35);  
            display_set_fg_color(BLACK_COLOR);
            //Setup the choices texts
            display_text(630, 60, "FNIRSI firmware");
        }
        
        //Scan for where the touch is applied, Update firmware
        if((xtouch >= 360) && (xtouch <= 450) && (ytouch >= 385) && (ytouch <= 420))  
        {   choice = 3; havetouch = 1; waittime = 1;
            //Fill the settings background
            //display_fill_rect(620, 50, 138, 35); 
            display_fill_rect(360, 380, 80, 35); 
            display_set_fg_color(LIGHTGREY_COLOR);
            //Fill the settings background
            display_draw_rect(40,  50, 122, 35); 
            display_draw_rect(340, 50, 130, 35);
            display_draw_rect(620, 50, 138, 35); 
            display_set_fg_color(BLACK_COLOR);
            //Setup the choices texts
            display_text(377, 390, "Update");
        } 
    
        if(waittime == 10) {havetouch = 1;} //10500 is 5sec, 5500 2.5s 
        //if(waittime>5500) choice = 1; //10500 is 5sec, 5500 2.5s
        waittime--;
    
    
        if (time != waittime/3200) 
        {   
            time = waittime/3200;
            display_set_fg_color(BLACK_COLOR);
            //Fill the settings background
            display_fill_rect(490, 150, 10, 13);  //x , y , sirka, vyska
    
            display_set_fg_color(WHITE_COLOR);
            display_decimal(490, 150, time);
        }
          
    }// end while(havetouch == 0) 
  } //end if (choice>3)

  //display_set_fg_color(WHITE_COLOR);
  //Fill the settings background
  //display_fill_rect(0, 0, 800, 480);  //x , y , sirka, vyska

  //Display the text with green color
  display_set_fg_color(ORANGE_COLOR);
  display_text(360, 250, "LOADING...");

  //Wait until the 500 milliseconds have passed
  for(j=0;j<500;j++)       //500 is 500ms ,1000 is 1s
  {
    //At 600MHz CPU_CLK 5000 = ~2000uS
    for(i=0;i<5000;i++);
  }
 
  choice = choice & 3;    //mask view menu
  //Load the chosen program
  
  //***************************** SD CARD **************************************  
  if(choice == 0)
  {
    //Set the address to run the loaded main program
    load_from_SDcard(DSO_PROGRAM_START_SECTOR);
  }
  else if(choice == 3)
  {
    //Set the address to run the loaded updater program
    load_from_SDcard(UPDATE_PROGRAM_START_SECTOR);
  }
  //***************************** SPI Flash ************************************
  else if(choice == 1)
  {
    //Initialize SPI for flash (PORT C + SPI0)
    sys_spi_flash_init();
  
    //Load the main program from flash
    //Get the header first
    sys_spi_flash_read(0x27000, buffer, 32);

    //Original boot loader checks on eGON.EXE file identifier

    //Get the length from the header and take of the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]) - 32;

    //Read the main program into DRAM. 
    sys_spi_flash_read(0x27020, (unsigned char *)0x80000000, length);
  }
  //********************************* FEL **************************************
  else
  {
    //Clear the screen
    display_set_fg_color(BLACK_COLOR);
    display_fill_rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    //Show the scope is in FEL mode
    display_set_fg_color(WHITE_COLOR);
    display_text(340, 230, "Running FEL mode");
    
    //Set the address to run the FEL code
    address = 0xFFFF0020;
  }
  //****************************************************************************
  
  //Start the chosen code
  __asm__ __volatile__ ("mov pc, %0\n" :"=r"(address):"0"(address));
}


void load_from_SDcard(uint32 address)
{   
  unsigned int blocks;
  int retval;
  
    //Load the first program sector from the SD card
    if(sd_card_read(address, 1, buffer) != SD_OK)
    {
      display_set_fg_color(RED_COLOR);
      //display_text(305, 300, "SD card first read failed");
      display_text(295, 300, "SD card program read failed");

      //On error just frees
      while(1);
    }

    //Check if there is a brom header there
    if(memcmp(&buffer[4], "eGON.EXE", 8) != 0)
    {
      display_set_fg_color(RED_COLOR);
      display_text(335, 300, "Not an executable");//337

      //On error just frees
      while(1);
    }

    //Get the length from the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]);

    //Calculate the number of sectors to read
    blocks = (length + 511) / 512;

    //Copy the first program bytes to DRAM (So the eGON header is skipped)
    memcpy((void *)0x80000000, &buffer[32], 480);

    //Check if more data needs to be read
    if(blocks > 1)
    {
      //Already read the first block
      blocks--;

      //Load the remainder of the program from the SD card
      if((retval = sd_card_read(address + 1, blocks, (void *)0x800001E0)) != SD_OK)
      {
        display_set_fg_color(BLACK_COLOR);
        //Fill the settings background
        display_fill_rect(0, 0, 800, 480);  //x , y , sirka, vyska
          
        display_set_fg_color(RED_COLOR);
        display_text(190, 100, "SD card, Failed reading program sector");
        display_text(190, 130, "Error: ");
        display_text(190, 160, "Sector: ");
        display_set_fg_color(WHITE_COLOR);
        display_decimal(350, 130, retval);
        display_decimal(350, 160, blocks);

        //On error just frees
        while(1);
      }
    }
}