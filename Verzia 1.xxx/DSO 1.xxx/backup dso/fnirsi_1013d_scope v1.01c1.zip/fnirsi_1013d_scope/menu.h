//----------------------------------------------------------------------------------------------------------------------------------

#include "fnirsi_1013d_scope.h"
#include "variables.h"

//----------------------------------------------------------------------------------------------------------------------------------
void scope_setup_display_lib(void);
//----------------------------------------------------------------------------------------------------------------------------------
void scope_setup_main_screen(void);

void scope_setup_restore_screen(void);

void scope_setup_view_screen(void);

void scope_setup_usb_screen(void);

//void scope_diagnostic_screen(void);
//----------------------------------------------------------------------------------------------------------------------------------
void scope_setup_right_control_menu(void);

void scope_setup_right_file_menu(void);
//----------------------------------------------------------------------------------------------------------------------------------
void scope_setup_bottom_file_menu(int mode);
//----------------------------------------------------------------------------------------------------------------------------------
// Right side bar functions
//----------------------------------------------------------------------------------------------------------------------------------
  
void scope_control_button(int mode);
void scope_run_stop_button(int mode);
void scope_auto_set_button(int mode);
void scope_next_wave_button(int mode);
void scope_previous_wave_button(int mode);
void scope_t_cursor_button(int mode);
void scope_v_cursor_button(int mode);
void scope_measures_button(int mode);
void scope_save_picture_button(int mode);
void scope_save_wave_button(int mode);
void scope_delete_wave_button(int mode);
void scope_saved_view_right_menu(void);     //v1.00v7
void scope_50_percent_trigger_button(int mode);
void scope_show_grid_button(int mode);   
void scope_next_cal_button(int mode); 
void scope_end_cal_button(int mode); 

void scope_channel_sensitivity_control(PCHANNELSETTINGS settings, int type, int mode);

void scope_return_button(int mode);
void scope_select_all_button(int mode);
void scope_select_button(int mode);
void scope_delete_button(int mode);
void scope_page_up_button(int mode);
void scope_page_down_button(int mode);

//----------------------------------------------------------------------------------------------------------------------------------
// Bitmap control bar functions
//----------------------------------------------------------------------------------------------------------------------------------

void scope_bmp_return_button(int mode);
void scope_bmp_delete_button(int mode);
void scope_bmp_previous_button(int mode);
void scope_bmp_next_button(int mode);

//----------------------------------------------------------------------------------------------------------------------------------
// Top bar functions
//----------------------------------------------------------------------------------------------------------------------------------

void scope_menu_button(int mode);
void scope_main_return_button(int mode);
void scope_maxlight_item(int mode);
void scope_set_maxlight(int mode);
void scope_run_stop_text(void);
void scope_channel_settings(PCHANNELSETTINGS settings, int mode);

void scope_channel_dcshift_value(void);

void scope_acqusition_settings(int mode);
void scope_move_speed(int mode);

void watchdog_reset_now(void);


void scope_trigger_settings(int mode);

void scope_generator_settings(int mode);

void scope_battery_status(void);

//----------------------------------------------------------------------------------------------------------------------------------
// Menu functions
//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_main_menu(void);
void scope_main_menu_item(int row, int mode);
void scope_draw_record_overview(int32 wx, int32 ww);
void scope_main_menu_system_settings(int mode);
void scope_main_menu_picture_view(int mode);
void scope_main_menu_waveform_view(int mode);
void scope_main_menu_diagnostic_view(int mode);
void scope_main_menu_usb_connection(int mode);
//----------------------------------------------------------------------
void scope_open_channel_menu(PCHANNELSETTINGS settings);
void scope_channel_enable_select(PCHANNELSETTINGS settings);
void scope_channel_fft_show(PCHANNELSETTINGS settings);
void scope_channel_i2c_select(PCHANNELSETTINGS settings);     //v1.01a2
uint32 scope_text_width(const char *text);     //v1.01b2
void scope_right_decoder_button(int mode);
void scope_right_list_button(int mode);
#define RIGHT_MENU_DECODER   5     //v1.01b2: the decoder page of the right bar
//#define RIGHT_DEC_BUTTON1_Y  59    //v1.01b3: the decoder buttons on the V/div page under CTRL
//#define RIGHT_DEC_BUTTON2_Y 105
//#define RIGHT_DEC_BUTTON_H   42
#define RIGHT_DEC_BUTTON1_Y  62    //v1.01b5: 7 px between CTRL, Decode, List and CH1 V+ (were 4 / 4 / 5)
#define RIGHT_DEC_BUTTON2_Y 109
#define RIGHT_DEC_BUTTON_H   40
void scope_channel_invert_select(PCHANNELSETTINGS settings);
void scope_channel_coupling_select(PCHANNELSETTINGS settings);
void scope_channel_VA_select(PCHANNELSETTINGS settings);
void scope_channel_probe_magnification_select(PCHANNELSETTINGS settings);
void scope_channel_sensitivity_select(PCHANNELSETTINGS settings);

void scope_channel_ref_menu_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_open_ref_menu(PCHANNELSETTINGS settings);
//void scope_channel_open_ref_menu(PCHANNELSETTINGS settings, PCHANNELSETTINGS REFsettings);
void scope_channel_ref_select(PCHANNELSETTINGS settings);
//void scope_channel_ref_select(PCHANNELSETTINGS settings, PCHANNELSETTINGS REFsettings);


void scope_channel_COPYtoREF1_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_COPYtoREF2_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_COPYtoREF3_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_COPYtoREF4_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_CLEAR_REF_ALL_item(PCHANNELSETTINGS settings, int mode);

void scope_channel_LOADtoREF1_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_LOADtoREF2_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_LOADtoREF3_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_LOADtoREF4_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_LOAD_REF_ALL_item(PCHANNELSETTINGS settings, int mode);

void scope_channel_SAVE_REF1_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_SAVE_REF2_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_SAVE_REF3_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_SAVE_REF4_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_SAVE_REF_ALL_item(PCHANNELSETTINGS settings, int mode);

void scope_channel_math_menu_item(PCHANNELSETTINGS settings, int mode);
void scope_channel_open_math_menu(PCHANNELSETTINGS settings);
void scope_channel_math_select(PCHANNELSETTINGS settings);
//----------------------------------------------------------------------
void scope_open_keyboard_menu(void);
void scope_keyboard_select(void);
void display_dim_rect(uint32 x, uint32 y, uint32 w, uint32 h);   //v1.00y3
extern uint32 settings_confirm_frame;                             //v1.00z0
extern uint8 trigger_symbol_grey;                                 //v1.00z2
//void scope_keyboard_select(int16 menuxpos);
//----------------------------------------------------------------------
void scope_open_acquisition_menu(void);
void scope_acquisition_speed_select(void);
void scope_acquisition_timeperdiv_select(void);
void scope_acquisition_ACQ_mode_select(void);
void scope_acquisition_Average_mode_select(void);
void scope_acquisition_Long_memory_select(void);

void scope_acquisition_memory_deep_select(void);
uint32 acq_memory_choice(uint32 i);      //v1.00z4: Memory column, normal or roll record length
uint32 acq_memory_max(void);
uint32 acq_memory_current(void);
void scope_acquisition_trace_select(void);
void scope_acquisition_more_select(void);                    //v1.00w5
uint32 scope_acquisition_more_touch(uint32 xt, uint32 yt);   //v1.00w5
void scope_acquisition_persist_select(void);                 //v1.00x1
void scope_acquisition_persist_touch(void);                  //v1.00x1
uint32 scope_acquisition_avg_persist_touch(uint32 xt, uint32 yt);   //v1.00x2
void scope_acquisition_acq_button(void);                     //v1.00x2
void scope_acquisition_clear_button(uint32 pressed);         //v1.00x2
void scope_acquisition_clear_touch(void);                    //v1.00x2
void scope_acquisition_Average_mode_select_old(void);        //v1.00x2 (old button, unused)
void scope_acquisition_persist_select_old(void);             //v1.00x2 (old button, unused)
//----------------------------------------------------------------------

void scope_open_trigger_menu(void);
void scope_trigger_mode_select(void);
void scope_trigger_edge_select(void);
void scope_trigger_channel_select(void);

void scope_trigger_position_select(void);

void scope_hold_off_select(void);

void scope_always_trigger50_select(void);

void scope_trigger_symbol(int x, int y);
//----------------------------------------------------------------------
void scope_open_generator_menu(void);
void gen_enable_select(void);
void gen_wave_select(void);
void gen_freq_select(void);
void gen_duty_select(void);
void gen_ampl_select(void);
void gen_offset_select(void);
void gen_phase_select(void);


//void display_frequency(uint32 f);

//----------------------------------------------------------------------
void scope_open_system_settings_menu(void);
void scope_system_settings_screen_brightness_item(int mode);
void scope_system_settings_screen_brightness_value(void);
void scope_system_settings_grid_brightness_item(int mode);
void scope_system_settings_grid_brightness_value(void);

void scope_system_settings_other_settings_item(int mode);
void scope_system_settings_open_other_settings_menu(void);

void scope_system_settings_other_settings_boot_menu_item(void);
void scope_system_settings_other_settings_default_start_item(void);
void scope_system_settings_other_settings_new_autosetup_item(void);
void scope_system_settings_other_settings_lock_cursor_item(void);
void scope_system_settings_other_settings_dc_shift_cal_item(void);
void scope_system_settings_other_settings_CH340_mode_item(void);
void scope_system_settings_other_settings_dev_mode_item(void);
void scope_system_settings_other_settings_BMP_mark_item(void);
void scope_system_settings_other_settings_ref_on_start_item(void);
//void scope_system_settings_other_settings_ine_mark_item(void);

void scope_system_settings_calibration_item(int mode);
void scope_system_settings_x_y_mode_item(int mode);
void scope_system_settings_confirmation_item(int mode);

//v1.00s4: Display panel and the grouped Other settings menu
void scope_open_display_panel(void);
void scope_display_panel_transparent_item(void);
void scope_system_settings_other_settings_confirmation_item(void);

#define OS_BOOT           0
#define OS_DEFSTART       1
#define OS_REFSTART       2
#define OS_AUTOSETUP      3
#define OS_LOCKCUR        4
#define OS_CONFIRM        5
#define OS_BMPTAG         6
#define OS_USBSERIAL      7
#define OS_DCSHIFT        8
#define OS_DEVMODE        9
#define OS_TRANSPARENT    10
#define OS_SCREENBRIGHT   11
#define OS_GRIDBRIGHT     12
#define OS_XYMODE         13
#define OS_BASECAL        14
#define OS_CLOCKON        15
#define OS_HOUR           16
#define OS_MINUTE         17
#define OS_DAY            18
#define OS_MONTH          19
#define OS_YEAR           20
#define OS_CLOCKNOW       21
#define OS_INPUTCAL       22
#define OS_CSVSCOPE       23    //v1.00v3: CSV export switches
#define OS_CSVBODE        24
#define OS_CSVSPEC        25
//#define OS_ITEMS          26
#define OS_TRIGMIN        26    //v1.00x9: trigger position Min (0..45 %), slider
#define OS_TRIGMAX        27    //v1.00x9: trigger position Max (55..100 %), slider
#define OS_TRIGHYST       28    //v1.00x9: trigger hysteresis (ADC codes, FPGA 0x2050), slider
//#define OS_ITEMS          29
#define OS_ADCCAL         29    //v1.00y1: ADC capture timing calibration (FPGA 0x2050, 0x63 / 0x36)
//#define OS_ITEMS          30
#define OS_BODEHINT       30    //v1.00y6: start hint of the frequency response view on / off
#define OS_TAPVDIV        31    //v1.00y6: V/div by a tap at the top / bottom edge of the trace area on / off
//#define OS_ITEMS          32
#define OS_LASTVIEW       32    //v1.00z4: start in the last view (scope, spectrum, frequency response) on / off
//#define OS_ITEMS          33
#define OS_I2CON          33    //v1.01a3: I2C decoder on / off (Settings > Measure > Decoder)
#define OS_I2CAUTO        34    //v1.01a3: automatic threshold (50 %)
#define OS_I2C10          35    //v1.01a3: 10 bit addresses
#define OS_I2CDEC         36    //v1.01a3: values in decimal
#define OS_ITEMS          37
#define OS_GROUPS         4
#define OS_HEADING_H      18
#define OS_ITEM_H         34

int os_heading_y(int group);
int os_item_y(int item);
int os_item_at(int y);

//v1.00s7: all settings on a full screen page with tabs and framed sections, and the transparent switch in MEASURES
#define SETTINGS_TABS          6
#define SETTINGS_TAB_CLOCK     5
#define SETTINGS_SECTIONS      4
#define SETTINGS_SECTION_ITEMS 6
#define MEASURES_STRIP_Y       202

typedef struct
{
  const char *title;                          //0: no section
  uint8       col;                            //0 left, 1 right, 2 full width
  signed char items[SETTINGS_SECTION_ITEMS];  //OS_* ids, -1 ends the list (signed: int8 is unsigned char here)
} SETTINGSSECTION;

int  settings_item_id(int tab, int sec, int idx);
void settings_item_pos(int tab, int sec, int idx, int *x, int *y);
int  settings_item_at(int tab, int x, int y, int *sec, int *idx);
int  settings_tab_at(int x, int y);
void settings_page_item(int tab, int sec, int idx, int active);
int  settings_item_w(int tab, int sec);
void settings_slider_bar(int x, int w, int *bx, int *bw);
void settings_slider_draw(int x, int y, int w, int id);
int    settings_is_slider(int id);                                     //v1.00x9
uint8 *settings_slider_value(int id);                                  //v1.00x9
void   settings_slider_range(int id, int *min, int *max, int *step);  //v1.00x9
int    settings_slider_enabled(int id);                                //v1.00x9
void settings_clock_buttons(int x, int w, int *minus, int *value, int *plus);
void settings_clock_row(int x, int y, int w, int id, int active);
void settings_page_draw(int tab);
void settings_clock_now(int x, int y, int w);
int  settings_confirm(const char *line1, const char *line2, const char *line3);
void scope_measures_transparent_item(void);
void scope_system_settings_RTC_settings_item(int mode);
void scope_open_RTC_settings_menu(void);

void scope_system_settings_hour_item(void);
void scope_system_settings_hour_item_value(void);
void scope_system_settings_minute_item(void);
void scope_system_settings_minute_item_value(void);
void scope_system_settings_day_item(void);
void scope_system_settings_day_item_value(void);
void scope_system_settings_month_item(void);
void scope_system_settings_month_item_value(void);
void scope_system_settings_year_item(void);
void scope_system_settings_year_item_value(void);
void scope_system_settings_ONOFF_RTC_item(void);
//----------------------------------------------------------------------
void scope_open_diagnostic_view(void);
//----------------------------------------------------------------------
void scope_open_calibration_start_text(void);
void scope_show_calibrating_text(void);
void scope_show_calibration_done_text(void);
void scope_show_calibration_fail(void);

void scope_show_Input_calibration(void);
void scope_show_calibrating_300mV_text(void);
void scope_show_calibrating_600mV_text(void);
void scope_show_calibrating_1_5V_text(void);
void scope_show_calibrating_3V_text(void);
void scope_show_calibrating_7_5V_text(void);
void scope_show_calibrating_15V_text(void);
void scope_show_Input_calibration_done(void);
void scope_show_Input_calibration_fail(void);
//----------------------------------------------------------------------
//void scope_open_t_cursor_menu(void);
//void scope_open_v_cursor_menu(void);

void scope_open_measures_menu(void);
void scope_source1_measures_menu_item(void);
void scope_source2_measures_menu_item(void);
void scope_hide_measures_menu_item(void);
void scope_measures_menu_item(int channel, int item);

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_slider(uint16 xpos, uint16 ypos, uint8 position);
void scope_display_slider(uint16 xpos, uint16 ypos, uint8 position);
int  scope_move_slider(uint16 xpos, uint16 ypos, uint8 *position);

void scope_display_slide_button(uint16 xpos, uint16 ypos, uint8 state, uint32 color);
void scope_display_ok_button(uint16 xpos, uint16 ypos, uint8 mode);

void scope_default_button(uint16 xpos, uint16 ypos, uint8 mode);
void scope_restore_button(uint16 xpos, uint16 ypos, uint8 mode);
void scope_reset_button(uint16 xpos, uint16 ypos, uint8 mode);
void scope_boot_button(uint16 xpos, uint16 ypos);
void scope_exit_button(uint16 xpos, uint16 ypos, uint8 mode);

void scope_display_error(void);



//----------------------------------------------------------------------------------------------------------------------------------
//void scope_adjust_timebase(void);
//----------------------------------------------------------------------------------------------------------------------------------
// Grid and cursor functions
//----------------------------------------------------------------------------------------------------------------------------------

void scope_draw_grid(void);
//void scope_draw_pointers(void);
void scope_draw_time_cursors(void);
void scope_draw_volt_cursors(void);
//----------------------------------------------------------------------------------------------------------------------------------




//----------------------------------------------------------------------------------------------------------------------------------

//void u32_to_hexstr(uint32 value, char *buffer);  
void make_freq_to_text(char *dst, uint32 f);
void make_freq_to_long_text(char *dst, uint32 f);
void make_value_to_text(char *dst, uint32 d, char c);
void make_volt_to_long_text(char *dst, uint32 f);

//void centering_text(char *dst, uint8 width);
void align_text(char *dst, uint8 width, uint8 mode);

void format_version_full(uint32 value, char *buffer); //for Show the additional info of error MESSAGE_ERROR_VERSION_MISMATCH
void extract_version_string(uint32 word1, uint32 word2, char *buffer);
        
//----------------------------------------------------------------------------------------------------------------------------------        