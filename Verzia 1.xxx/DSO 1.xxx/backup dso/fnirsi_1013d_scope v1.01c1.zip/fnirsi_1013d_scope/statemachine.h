//----------------------------------------------------------------------------------------------------------------------------------

#ifndef STATEMACHINE_H
#define STATEMACHINE_H

//----------------------------------------------------------------------------------------------------------------------------------

#include "types.h"
#include "variables.h"

//----------------------------------------------------------------------------------------------------------------------------------

void touch_handler(void);

void scan_for_touch(void);

void handle_main_menu_touch(void);
//v1.00y5: channel menu items blocked in the frequency response / spectrum views
#define CHI_ENABLE   0
#define CHI_FFT      1
#define CHI_INVERT   2
#define CHI_VA       3
#define CHI_50       4
#define CHI_MATH     5
#define CHI_REF      6
int  chmenu_blocked(int item);
void chmenu_dim(PCHANNELSETTINGS settings);
void handle_channel_menu_touch(PCHANNELSETTINGS settings);
void handle_acquisition_menu_touch(void);
void handle_trigger_menu_touch(void);

void handle_generator_menu_touch(void);

void handle_keyboard_menu_touch(void);

//v1.00x5: hold-off entry (keyboard)
#define HOLDOFF_UNIT_MS   0
#define HOLDOFF_UNIT_US   1
#define HOLDOFF_UNIT_NS   2
#define HOLDOFF_UNIT_S    3     //v1.00x6
extern uint8 holdoff_unit;
void   holdoff_add_comma(void);
void   holdoff_show_unit(void);
uint32 holdoff_buffer_to_ticks(void);
void   holdoff_ticks_to_buffer(uint32 ticks);

void handle_right_basic_menu_touch(void);
void handle_right_volts_div_menu_touch(void);

void handle_measures_menu_touch(void);

void handle_view_mode_touch(void);       //need to finish this function (trace display for waveform view) Check the comments!!
                                         //waveform view functionality also needs to be added to handle_right_basic_menu_touch
void handle_picture_view_touch(void);

void handle_diagnostic_view_touch(void);

int32 handle_confirm_delete(void);

//v1.00v7: the right bar of the saved frequency response / spectrum viewer, what the viewer has to do next
#define SAVED_VIEW_NONE       0
#define SAVED_VIEW_LOAD       1     //another file selected (viewcurrentindex), load it
#define SAVED_VIEW_EXIT       2     //no file left, back to the list
#define SAVED_VIEW_TCURSOR    3
#define SAVED_VIEW_VCURSOR    4
#define SAVED_VIEW_MEASURES   5
#define SAVED_VIEW_REDRAW     6     //a dialog or message covered the screen

int32 handle_saved_view_right_touch(void);

//----------------------------------------------------------------------------------------------------------------------------------

void close_open_menus(uint32 closemain);
void handle_record_slider_touch(void);
void handle_settings_page(void);
void handle_rtc_touch(void);
int  handle_calibration_touch(void);
void settings_calibration_close(void);
void scope_save_boot_settings(void);

void close_open_channel_menus(PCHANNELSETTINGS settings, uint32 closemain);

void close_open_trigger_menus( uint32 closemain);

void close_open_gen_menus( uint32 closemain);


//----------------------------------------------------------------------------------------------------------------------------------

void move_trigger_point_position(void);

//void change_channel_1_HW_offset(void);

void change_channel_1_offset(void);
void change_channel_2_offset(void);

void change_trigger_level_offset(void);

void move_left_time_cursor_position(void);
void move_right_time_cursor_position(void);

void move_top_volt_cursor_position(void);
void move_bottom_volt_cursor_position(void);

void move_ref1_position(void);
void move_ref2_position(void);
void move_ref3_position(void);
void move_ref4_position(void);
void move_ref5_position(void);
void move_ref6_position(void);
void move_ref7_position(void);
void move_ref8_position(void);

//----------------------------------------------------------------------------------------------------------------------------------

void match_volt_per_div_settings(PCHANNELSETTINGS settings);

void set_trigger_mode(uint32 mode);

void calculate_trigger_position_mem(void);

void check_trigger_visual_limits(void);

//----------------------------------------------------------------------------------------------------------------------------------

#endif /* STATEMACHINE_H */

