//----------------------------------------------------------------------------------------------------------------------------------

#include "fpga_control.h"
#include "touchpanel.h"
#include "timer.h"
#include "variables.h"
#include "spectrum.h"     //v1.00y2: spectrum_is_active / bode_is_active for the hardware peak detect
#include "bode.h"

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_init(void)
{
  //First set pin high in data register to avoid spikes when changing from input to output
  FPGA_CLK_INIT();
  
  //Initialize the three control lines for output
  FPGA_CTRL_INIT();
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_write_cmd(uint8 command)
{
  //Set the control lines for writing a command
  FPGA_CMD_WRITE();

  //Set the bus for writing
  FPGA_BUS_DIR_OUT();

  //Write the data to the bus  
  FPGA_SET_DATA(command);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
}

//----------------------------------------------------------------------------------------------------------------------------------

uint8 fpga_read_cmd(void)
{
  //Set the bus for reading
  FPGA_BUS_DIR_IN();
  
  //Set the control lines for reading a command
  FPGA_CMD_READ();

  //Clock the data to the output of the FPGA
  FPGA_PULSE_CLK();
 
  //Read the data
  return(FPGA_GET_DATA());
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_write_byte(uint8 data)
{
  //Set the control lines for writing a command
  FPGA_DATA_WRITE();

  //Set the bus for writing
  FPGA_BUS_DIR_OUT();
  
  //Write the data to the bus  
  FPGA_SET_DATA(data);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
}

//----------------------------------------------------------------------------------------------------------------------------------

uint8 fpga_read_byte(void)
{
  //Set the bus for reading
  FPGA_BUS_DIR_IN();
  
  //Set the control lines for reading a command
  FPGA_DATA_READ();

  //Clock the data to the output of the FPGA
  FPGA_PULSE_CLK();
 
  //Read the data
  return(FPGA_GET_DATA());
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_write_short(uint16 data)
{
  //Set the control lines for writing a command
  FPGA_DATA_WRITE();

  //Set the bus for writing
  FPGA_BUS_DIR_OUT();
  
  //Write the msb to the bus  
  FPGA_SET_DATA(data >> 8);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
  
  //Write the lsb to the bus  
  FPGA_SET_DATA(data);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
}

//----------------------------------------------------------------------------------------------------------------------------------

uint16 fpga_read_short(void)
{
  uint16 data;
  
  //Set the bus for reading
  FPGA_BUS_DIR_IN();
  
  //Set the control lines for reading a command
  FPGA_DATA_READ();

  //Clock the data to the output of the FPGA
  FPGA_PULSE_CLK();

  //Get the msb
  data = FPGA_GET_DATA() << 8;

  //Clock the data to the output of the FPGA
  FPGA_PULSE_CLK();

  //Get the lsb
  data |= FPGA_GET_DATA();
  
  //Read the data
  return(data);
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_write_int(uint32 data)
{
  //Set the control lines for writing a command
  FPGA_DATA_WRITE();

  //Set the bus for writing
  FPGA_BUS_DIR_OUT();
  
  //Write the msb to the bus  
  FPGA_SET_DATA(data >> 24);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();

  //Write the mlsb to the bus  
  FPGA_SET_DATA(data >> 16);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
  
  //Write the lmsb to the bus  
  FPGA_SET_DATA(data >> 8);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
  
  //Write the lsb to the bus  
  FPGA_SET_DATA(data);
  
  //Clock the data into the FPGA
  FPGA_PULSE_CLK();
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_backlight_brightness(uint16 brightness)
{
  fpga_write_cmd(0x38);
  fpga_write_short(brightness);
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_translated_brightness(void)
{
  uint16 data;
  
  //Translate the 0 - 100 brightness value into data for the FPGA
  data = (scopesettings.screenbrightness * 560) + 4000;
  
  //Write it to the FPGA
  fpga_set_backlight_brightness(data);
}

//----------------------------------------------------------------------------------------------------------------------------------

uint16 fpga_get_version(void)
{
  uint16  fw_version;
  fpgasettings.fw_FPGA = 0;
  
  fpga_write_cmd(0x06);
  fw_version = fpga_read_short();
/*
   uint8 family = (fw_version >> 8);  // upper byte = family FPGA
  
  if(fw_version == 0x1432) fpgasettings.fw_FPGA = 1;  //fnirsi fw in FPGA
  else if(family == 0x15)  fpgasettings.fw_FPGA = 2;  //PECO fw in FPGA AL3
  else if(family == 0x16)  fpgasettings.fw_FPGA = 3;  //PECO fw in FPGA EF2
 
 */
  
  uint8 family = (fw_version >> 12);  // upper byte = family FPGA
  
  if(family == 0x1)      fpgasettings.fw_FPGA = 1;  //fnirsi fw in FPGA
  else if(family == 0x2) fpgasettings.fw_FPGA = 2;  //PECO fw in FPGA EF2
  else if(family == 0x3) fpgasettings.fw_FPGA = 3;  //PECO fw in FPGA AL3
  else if(family == 0x4) fpgasettings.fw_FPGA = 4;  //PECO fw in FPGA EP4

  //v1.00x3: the version word and, for EF2 (0x2zzz, z decimal digits), the revision zzz as a decimal number
  fpgasettings.fpga_version  = fw_version;
  fpgasettings.fpga_revision = (((fw_version >> 8) & 0x0F) * 100) + (((fw_version >> 4) & 0x0F) * 10) + (fw_version & 0x0F);

  return(fw_version);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00x3: FPGA 0x2050 (EF2 port of MCP's 0x153F)

//Words in the sample memory: 8192 on 0x2050 and the AL3 / EP4 designs, 6144 on the own EF2 design 0x2000
uint32 fpga_memory_words(void)
{
  if((fpgasettings.fw_FPGA == 2) && !FPGA_IS_153F_PORT())
    return(6144);

  return(8192);
}

//v1.00x4: record length per channel. A memory word holds both ADC cores (A and B) of a channel, so a record has two
//samples per word: 6144 words = 12288 samples (own 0x2000), 8192 words = 16384 samples (0x2050, AL3, EP4); the sample
//buffers hold MAX_SAMPLE_BUFFER_SIZE (16382). The original FNIRSI FPGA: 3000.
uint32 fpga_max_samples(void)
{
  uint32 n;

  if(fpgasettings.fw_FPGA == 1)
    return(3000);

  n = fpga_memory_words() * 2;

  if(n > MAX_SAMPLE_BUFFER_SIZE)
    n = MAX_SAMPLE_BUFFER_SIZE;

  return(n);
}

//v1.00x4: the record lengths of the ACQ menu Memory column: 3000, 6000, 9000, 12000 and as the last 16000 when the
//memory holds it (else 15000, which then does not fit the own 0x2000 design either and is shown grey)
uint32 fpga_memory_choice(uint32 i)
{
  if(i < 4)
    return((i + 1) * 3000);

  return((fpga_max_samples() >= 16000) ? 16000 : 15000);
}

//v1.00x4: a record length that does not fit the FPGA goes down to the longest choice that does
void fpga_limit_record_length(void)
{
  int32 i;

  if(scopesettings.samplecount <= fpga_max_samples())
    return;

  for(i = 4; i > 0; i--)
  {
    if(fpga_memory_choice(i) <= fpga_max_samples())
      break;
  }

  scopesettings.samplecount = fpga_memory_choice(i);
  fpgasettings.totalsamples = scopesettings.samplecount;
  scopesettings.nofsamples  = scopesettings.samplecount / 2;
}

//Trigger hold-off: 0x1B, u32 in 5 ns clocks of 200 MHz, 0 = off. The setting is in ms (0 = off), the FPGA takes up to
//21.47 s. Only 0x2050 has it (the own 0x2000 design never used 0x1B).
#define FPGA_HOLDOFF_MAX_MS   21000

//v1.00x5: the value is kept in 5 ns clocks (fpgasettings.holdoff_ticks, 5 ns .. 21.47 s), the old ms value below
void fpga_set_holdoff(void)
{
#if 0
  uint32 ms = fpgasettings.value_holdoff_trigger;

  if(!FPGA_IS_153F_PORT())
    return;

  if(!fpgasettings.en_holdoff_trigger)
    ms = 0;

  if(ms > FPGA_HOLDOFF_MAX_MS)
    ms = FPGA_HOLDOFF_MAX_MS;

  fpga_write_cmd(0x1B);
  fpga_write_int(ms * 200000);
#endif

  if(!FPGA_IS_153F_PORT())
    return;

  fpga_write_cmd(0x1B);
  fpga_write_int(fpgasettings.en_holdoff_trigger ? fpgasettings.holdoff_ticks : 0);
}

//v1.00x9: trigger hysteresis (0x2050 write 0x19, 1 byte, ADC codes): rising arms on a sample < level - H and fires
//on the first sample >= level, falling the other way round; 0 = as before (no hysteresis)
void fpga_set_trigger_hysteresis(void)
{
  if(!FPGA_IS_153F_PORT())
    return;

  fpga_write_cmd(0x19);
  fpga_write_byte((scopesettings.trighyst > TRIG_HYST_MAX) ? TRIG_HYST_MAX : scopesettings.trighyst);
}

//v1.00x9: hold-off clear request (0x2050 write 0x66 bit 0): the next sampling reset (0x01 = 1) also clears the
//hold-off timer, so after RUN / a trigger mode change the first trigger is taken at once (one-shot in the FPGA)
void fpga_holdoff_clear_request(void)
{
  if(!FPGA_IS_153F_PORT())
    return;

  fpga_write_cmd(0x66);
  fpga_write_byte(0x01);
}

//v1.00x9: ADC encode self-check (0x2050 read 0x33, 1 byte). Bit 0 sticky: a check failed since the last 0x01 = 1;
//bit 1 the last write clock prediction was right; bits 3:2 = 01 encode convention; bits 7:4 the last pin check
//{ CH2 A, CH2 B, CH1 A, CH1 B }, 1 = right. A good arm reads 0xF6. Returns -1 when the FPGA does not have it.
int32 fpga_read_encode_check(void)
{
  if(!FPGA_IS_153F_PORT())
    return(-1);

  fpga_write_cmd(0x33);
  return(fpga_read_byte());
}

//v1.00y1: ADC capture stages (0x2050 write 0x63, 2 bytes): bits 2..0 CH1 stage, 8..6 CH2 stage (both cores of the
//chip, 2..5, used at 200 MSa/s only); the stage is written into the B fields (5..3, 11..9) too, as MCP does.
//0 = not calibrated: nothing is written, the FPGA keeps its power-on 0x06DB.
#define FPGA_CAPSEL_POWERON   0x06DB

static uint16 fpga_capsel_value(uint32 s1, uint32 s2)
{
  return((uint16)(((s2 & 7) << 9) | ((s2 & 7) << 6) | ((s1 & 7) << 3) | (s1 & 7)));
}

void fpga_set_adc_capture(uint16 capsel)
{
  if(!FPGA_IS_153F_PORT() || (capsel == 0))
    return;

  fpga_write_cmd(0x63);
  fpga_write_short(capsel);
}

//v1.00y4: the first version (v1.00y1) kept for reference: on a quiet input at one offset every stage counted 0 (the
//data bits hardly change there, so even a capture inside the data transition shows no outlier) and stage 2 was taken
#if 0
//v1.00y1: ADC capture calibration (as MCP's wizard): with no signal on the inputs every stage 2..5 is tried at
//200 MSa/s, 3 records each, and the outlier counters of 0x36 (words whose sample differs from the previous one by more
//than the 0x64 threshold, 8 codes) are summed per channel. A well captured core counts 0, one sampled inside its data
//transition nearly every word. Per channel the stage with the lowest count wins, a tie goes to the stage whose
//neighbours (2..5 in a ring) count least, so the choice lies in the middle of the good range. The chosen value is in
//the FPGA on return (the caller keeps or undoes it); counts get the four sums per channel. Returns the 0x63 value.
uint16 fpga_adc_capture_calibrate(uint32 *ch1counts, uint32 *ch2counts)
{
  uint32 s, r, i, t0, best1 = 2, best2 = 2;
  uint32 score, bestscore1 = 0xFFFFFFFF, bestscore2 = 0xFFFFFFFF;
  uint16 c[4];
  uint16 v;

  if(!FPGA_IS_153F_PORT())
    return(0);

  //Auto trigger, 200 MSa/s, outlier threshold 8 codes
  fpga_write_cmd(0x1A);
  fpga_write_byte(0x00);
  fpga_set_sample_rate(0);
  fpga_write_cmd(0x64);
  fpga_write_byte(8);

  for(s = 2; s <= 5; s++)
  {
    ch1counts[s - 2] = 0;
    ch2counts[s - 2] = 0;

    fpga_write_cmd(0x63);
    fpga_write_short(fpga_capsel_value(s, s));

    for(r = 0; r < 3; r++)
    {
      fpga_do_conversion();

      //Wait for the record (auto trigger ends it), at most 500 ms
      t0 = timer0_get_ticks();

      while(!fpga_done_conversion() && ((timer0_get_ticks() - t0) < 500));

      //{ stages, CH1 A, CH1 B, CH2 A, CH2 B }, 16 bits each, high byte first
      fpga_write_cmd(0x36);
      (void)fpga_read_byte();
      (void)fpga_read_byte();

      for(i = 0; i < 4; i++)
      {
        c[i]  = fpga_read_byte() << 8;
        c[i] |= fpga_read_byte();
      }

      ch1counts[s - 2] += c[0] + c[1];
      ch2counts[s - 2] += c[2] + c[3];
    }
  }

  for(s = 0; s < 4; s++)
  {
    score = (ch1counts[s] * 4) + ch1counts[(s + 3) & 3] + ch1counts[(s + 1) & 3];

    if(score < bestscore1)
    {
      bestscore1 = score;
      best1 = s + 2;
    }

    score = (ch2counts[s] * 4) + ch2counts[(s + 3) & 3] + ch2counts[(s + 1) & 3];

    if(score < bestscore2)
    {
      bestscore2 = score;
      best2 = s + 2;
    }
  }

  v = fpga_capsel_value(best1, best2);

  fpga_write_cmd(0x63);
  fpga_write_short(v);

  //The scope's own trigger mode and sample rate again
  fpga_set_trigger_mode();
  fpga_set_sample_rate(scopesettings.samplerate);

  return(v);
}

#endif

//v1.00y4: ADC capture calibration as MCP's wizard does it (firmware/scope/cap_stage.h of fnirsi-1013d-mcp): with quiet
//inputs (probes off) each channel's input is parked by its offset PWM at the codes 8k - 0.5 (k = 8 .. 24, 63.5 ..
//191.5), the carries where the noise flips 4 and more bits, and at every point each stage 2..5 gets 2 records at
//200 MSa/s; the 0x36 outlier counts (threshold 0x64 = 32) are summed per channel. A capture inside the AD9288 data
//transition garbles at the carries and counts; a clean stage counts 0. Per channel the pick among the clean stages:
//the widest run of adjacent clean stages, then 3 or 4 before 2 / 5, then the farther from the run's ends, then the
//lower ({2..5} -> 3, {3,4,5} -> 4, {4,5} -> 4, {2,5} -> 2, as MCP without its tie pass).
//The offset to code relation is measured first (mean code of 256 raw words at two offsets); when the code does not
//move with the offset the data path is not trusted and there is no result.
//Returns CAPCAL_*; value = the new 0x63 (in the FPGA on return when CAPCAL_OK), counts per channel and stage.

static uint32 fpga_capcal_mean16(uint8 adccmd)
{
  uint32 i, sum = 0;

  //256 words from the middle of the record, core A of the channel (the first byte read is a dummy)
  fpga_write_cmd(0x1F);
  fpga_write_short(1000);
  fpga_write_cmd(adccmd);
  (void)fpga_read_byte();

  for(i = 0; i < 256; i++)
    sum += fpga_read_byte();

  return(sum / 16);     //mean in 1/16 code
}

static void fpga_capcal_record(void)
{
  uint32 t0;

  fpga_do_conversion();
  t0 = timer0_get_ticks();

  while(!fpga_done_conversion() && ((timer0_get_ticks() - t0) < 500));
}

static void fpga_capcal_offsets(uint32 pwm1, uint32 pwm2)
{
  fpga_write_cmd(scopesettings.channel1.offsetcommand);
  fpga_write_short((uint16)pwm1);
  fpga_write_cmd(scopesettings.channel2.offsetcommand);
  fpga_write_short((uint16)pwm2);

  //The offset filter settles
  timer0_delay(30);
}

//Pick among the clean stages (bit s - 2 of clean set): see above; 0 when none is clean
static uint32 fpga_capcal_pick(uint32 clean)
{
  int32 s, best = 0, bestscore = -1, lo, hi, score;

  for(s = 2; s <= 5; s++)
  {
    if(!(clean & (1 << (s - 2))))
      continue;

    for(lo = s; (lo > 2) && (clean & (1 << (lo - 3))); lo--);
    for(hi = s; (hi < 5) && (clean & (1 << (hi - 1))); hi++);

    //width, then 3 / 4, then distance to the run's nearer end (each in its own decimal place)
    score = ((hi - lo + 1) * 100) + (((s == 3) || (s == 4)) ? 10 : 0) + (((s - lo) < (hi - s)) ? (s - lo) : (hi - s));

    if(score > bestscore)
    {
      bestscore = score;
      best = s;
    }
  }

  return(best);
}

uint32 fpga_adc_capture_calibrate(uint32 *ch1counts, uint32 *ch2counts, uint16 *value)
{
  int32  base1, base2, step, d1, d2, m01, m02, m11, m12, k, target16, p1, p2;
  uint32 s, r, i, clean1 = 0, clean2 = 0, best1, best2, result;
  uint16 c[4];

  *value = 0;

  for(s = 0; s < 4; s++)
  {
    ch1counts[s] = 0;
    ch2counts[s] = 0;
  }

  if(!FPGA_IS_153F_PORT())
    return(CAPCAL_NO_RESULT);

  //Auto trigger, 200 MSa/s, outlier threshold 32 codes (MCP's training value), the power-on stages while measuring
  fpga_write_cmd(0x1A);
  fpga_write_byte(0x00);
  fpga_set_sample_rate(0);
  fpga_write_cmd(0x64);
  fpga_write_byte(32);
  fpga_write_cmd(0x63);
  fpga_write_short(FPGA_CAPSEL_POWERON);

  base1 = scopesettings.channel1.dc_calibration_offset[scopesettings.channel1.samplevoltperdiv] + scopesettings.channel1.dcoffset;
  base2 = scopesettings.channel2.dc_calibration_offset[scopesettings.channel2.samplevoltperdiv] + scopesettings.channel2.dcoffset;

  //Offset to code: the mean at the offset in use and at a step away, the step doubled until the code moves 16 codes
  fpga_capcal_offsets(base1, base2);
  fpga_capcal_record();
  m01 = fpga_capcal_mean16(scopesettings.channel1.adc1command);
  m02 = fpga_capcal_mean16(scopesettings.channel2.adc1command);

  for(step = 500, d1 = 0, d2 = 0; step <= 16000; step *= 2)
  {
    fpga_capcal_offsets(base1 + step, base2 + step);
    fpga_capcal_record();
    m11 = fpga_capcal_mean16(scopesettings.channel1.adc1command);
    m12 = fpga_capcal_mean16(scopesettings.channel2.adc1command);

    d1 = m11 - m01;
    d2 = m12 - m02;

    if(((d1 > 256) || (d1 < -256)) && ((d2 > 256) || (d2 < -256)))
      break;
  }

  //The code did not follow the offset: no trustworthy data, nothing to calibrate with
  if(((d1 <= 256) && (d1 >= -256)) || ((d2 <= 256) && (d2 >= -256)))
  {
    result = CAPCAL_NO_RESULT;
    goto done;
  }

  //The points: offsets for the codes 8k - 0.5, k = 8 .. 24 (linear from the two measurements)
  for(k = 8; k <= 24; k++)
  {
    target16 = (k * 128) - 8;

    p1 = base1 + (int32)(((int64)(target16 - m01) * step) / d1);
    p2 = base2 + (int32)(((int64)(target16 - m02) * step) / d2);

    if((p1 < 0) || (p1 > 65535) || (p2 < 0) || (p2 > 65535))
      continue;

    fpga_capcal_offsets(p1, p2);

    for(s = 2; s <= 5; s++)
    {
      fpga_write_cmd(0x63);
      fpga_write_short(fpga_capsel_value(s, s));

      for(r = 0; r < 2; r++)
      {
        fpga_capcal_record();

        //{ stages, CH1 A, CH1 B, CH2 A, CH2 B }, 16 bits each, high byte first
        fpga_write_cmd(0x36);
        (void)fpga_read_byte();
        (void)fpga_read_byte();

        for(i = 0; i < 4; i++)
        {
          c[i]  = fpga_read_byte() << 8;
          c[i] |= fpga_read_byte();
        }

        ch1counts[s - 2] += c[0] + c[1];
        ch2counts[s - 2] += c[2] + c[3];
      }
    }
  }

  for(s = 0; s < 4; s++)
  {
    if(ch1counts[s] == 0) clean1 |= 1 << s;
    if(ch2counts[s] == 0) clean2 |= 1 << s;
  }

  best1 = fpga_capcal_pick(clean1);
  best2 = fpga_capcal_pick(clean2);

  if(!best1 || !best2)
  {
    //A channel without a clean stage: nothing changes
    result = CAPCAL_FAILED;
  }
  else
  {
    *value = fpga_capsel_value(best1, best2);
    result = (*value == fpga_capsel_value(3, 3)) ? CAPCAL_SAME : CAPCAL_OK;
  }

done:
  //Stages: the new ones on success, else the ones in use before; the scope's offsets, threshold, trigger and rate
  fpga_write_cmd(0x63);
  fpga_write_short((result == CAPCAL_OK) ? *value : (fpgasettings.adc_capsel ? fpgasettings.adc_capsel : FPGA_CAPSEL_POWERON));
  fpga_write_cmd(0x64);
  fpga_write_byte(8);
  fpga_set_channel_offset(&scopesettings.channel1);
  fpga_set_channel_offset(&scopesettings.channel2);
  fpga_set_trigger_mode();
  fpga_set_sample_rate(scopesettings.samplerate);

  return(result);
}

//v1.00y1: back to a stored value (or the power-on one when none is stored)
void fpga_restore_adc_capture(void)
{
  if(!FPGA_IS_153F_PORT())
    return;

  fpga_write_cmd(0x63);
  fpga_write_short(fpgasettings.adc_capsel ? fpgasettings.adc_capsel : FPGA_CAPSEL_POWERON);
}

//v1.00y2: hardware peak detect of FPGA 0x2050 (0x56 bit 1): on for the Peak trace mode, and for Auto when it draws
//Peak, with more than one sample per pixel at the short time base and below 200 MSa/s; not in roll mode, spectrum or
//frequency response
uint8 fpga_hw_peak_on = 0;
uint8 fpga_hw_peak_block = 0;     //v1.00y7: 1 while AUTO SET measures (no peak detect then)

uint32 fpga_hw_peak_wanted(uint32 samplerate)
{
  uint32 mode = scopesettings.ACQ_trace;
  double xpps;

  if(!FPGA_IS_153F_PORT() || fpga_hw_peak_block || scopesettings.long_mode || (samplerate == 0) || (samplerate > 17) || spectrum_is_active() || bode_is_active())
    return(0);

  if((mode != 2) && (mode != TRACE_MODE_AUTO))
    return(0);

  //Samples per pixel above one (pixels per sample below one)
  xpps = (50.0 * (double)frequency_per_div[scopesettings.timeperdiv]) / (double)sample_rate[samplerate];

  return(xpps < 1.0);
}

//v1.01a1: hardware Hi-Res (0x2050 / 0x3050 boxcar, 0x53 = 1): for the Hi-Res trace mode with at least two samples per
//pixel at the short time base and below 200 MSa/s (same limits as the peak detect otherwise). A memory word then holds
//the sum of a window of N = 2 (d + 1) raw samples at 200 MSa/s (the time of a normal word, two samples at the set
//rate) >> shift as 16 bits; fpga_read_sample_data turns it into the mean code and puts it in both sample places of the
//word, so the record keeps its length and time base, every sample place is the mean of all ADC samples of its time
//(no aliasing, less noise), and the software Hi-Res averages the pixel on top.
uint8  fpga_hw_hires_on    = 0;
uint8  fpga_hw_hires_shift = 0;
uint32 fpga_hw_hires_n     = 1;

uint32 fpga_hw_hires_wanted(uint32 samplerate)
{
  double xpps;

  if(!FPGA_IS_153F_PORT() || fpga_hw_peak_block || scopesettings.long_mode || (samplerate == 0) || (samplerate > 17) || spectrum_is_active() || bode_is_active())
    return(0);

  if(scopesettings.ACQ_trace != TRACE_MODE_HIRES)
    return(0);

  //Two samples per pixel or more: a mean per word (two sample times) still leaves one per pixel
  xpps = (50.0 * (double)frequency_per_div[scopesettings.timeperdiv]) / (double)sample_rate[samplerate];

  return(xpps <= 0.5);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00y9: streaming logger of the 0x153F port (0x2050 / 0x3050; MCP firmware/scope/fpga_log.c and pc_hal_scope.c
//pc_glue_roll_*). With 0x69 bit 0 the capture never stops and never triggers: the FPGA writes words into its 8192 word
//ring for ever at the 0x0D divider. Read 0x38 gives 8 bytes from one snapshot { stream, lap, 0, W[12:8] }, W[7:0] (next
//word to be written), u32 words written since the arm, u16 unread words; 0x6A is the next word the firmware reads. The
//firmware reads the new words lane by lane (0x21 CH1 core B, 0x20 CH1 core A, 0x23 / 0x22 CH2: one byte per lane and
//word, after one dummy strobe as MCP), checks with a second snapshot that the writer did not come round meanwhile
//(else the chunk is dropped and counted as a gap) and moves 0x6A on. The legacy roll (reads 0x24 / 0x26) does not work
//on the port: those reads were removed in 0x153C, which is why roll showed nothing there.

#define FLOG_RING     8192u
#define FLOG_SAFE     (FLOG_RING - 16u)

static struct
{
  uint8  running;
  uint8  snap[8];
  uint16 base;
  uint32 count;           //words written since the arm (FPGA counter)
  uint32 consumed;        //words read
} flog;

static void flog_snapshot(void)
{
  uint32 i;

  fpga_write_cmd(0x38);

  for(i = 0; i < 8; i++)
    flog.snap[i] = fpga_read_byte();

  flog.count = ((uint32)flog.snap[2] << 24) | ((uint32)flog.snap[3] << 16) | ((uint32)flog.snap[4] << 8) | flog.snap[5];
}

static void flog_reader(void)
{
  fpga_write_cmd(0x6A);
  fpga_write_short((uint16)((flog.base + flog.consumed) & (FLOG_RING - 1)));
}

static int flog_lapped(void)
{
  return((flog.snap[0] & 0x40) || ((flog.count - flog.consumed) > FLOG_SAFE));
}

//Words lost: go on from the newest word, the lap flag cleared (stream stays on)
static void flog_gap(void)
{
  flog.consumed = flog.count;
  flog_reader();
  fpga_write_cmd(0x69);
  fpga_write_byte(0x03);
  flog.snap[0] &= (uint8)~0x40;
}

uint32 fpga_logger_running(void)
{
  return(flog.running);
}

//v1.01a0: raw samples per word with the window processing, N = 2 (floor(divider / 2) + 1), and the boxcar output
//shift max(0, bitlen(255 N) - 16) (FPGA commands.txt, 0x53 / 0x54)
uint32 fpga_logger_window(uint32 divider)
{
  return(2 * ((divider / 2) + 1));
}

uint32 fpga_logger_shift(uint32 n)
{
  uint32 v = 255 * n, bits = 0;

  while(v)
  {
    bits++;
    v >>= 1;
  }

  return((bits > 16) ? (bits - 16) : 0);
}

//Start the stream at the given 0x0D divider; 0 when it runs
//v1.01a0: hw = FLOG_SKIP (as before), FLOG_PEAK (0x56 bit 1) or FLOG_BOXCAR (0x53 = 1, 0x54 = shift); the filter needs
//(K + 10) N 5 ns + 1 us to settle after the writes before the reset
uint32 fpga_logger_start(uint32 divider, uint32 hw)
{
  uint32 n = 0, wn, t0, ms;

  if(!FPGA_IS_153F_PORT())
    return(1);

  //The divider, stream on before the reset, sequencer off, auto mode
  fpga_write_cmd(0x0D);
  fpga_write_int(divider);

  wn = fpga_logger_window(divider);

  fpga_write_cmd(0x56);
  fpga_write_byte((hw == FLOG_PEAK) ? 0x02 : 0x00);
  fpga_write_cmd(0x54);
  fpga_write_byte((hw == FLOG_BOXCAR) ? (uint8)fpga_logger_shift(wn) : 0);
  fpga_write_cmd(0x53);
  fpga_write_byte((hw == FLOG_BOXCAR) ? 0x01 : 0x00);

  if(hw != FLOG_SKIP)
  {
    ms = (uint32)(((uint64)11 * wn * 5) / 1000000) + 2;
    t0 = timer0_get_ticks();

    while((timer0_get_ticks() - t0) < ms);
  }
  fpga_write_cmd(0x69);
  fpga_write_byte(0x01);
  fpga_write_cmd(0x57);
  fpga_write_byte(0x00);
  fpga_write_cmd(0x1A);
  fpga_write_byte(0x00);

  //Arm: no pretrigger / total, reset, wait for ready, again in the window, 0x0E = 0, release
  fpga_write_cmd(0x0B);
  fpga_write_short(0);
  fpga_write_cmd(0x0C);
  fpga_write_short(0);
  fpga_write_cmd(0x01);
  fpga_write_byte(0x01);
  fpga_write_cmd(0x05);

  while((fpga_read_byte() & 1) == 0)
  {
    if(++n > 2000000)
    {
      fpga_write_cmd(0x01);
      fpga_write_byte(0x00);
      fpga_write_cmd(0x69);
      fpga_write_byte(0x00);
      return(2);
    }
  }

  fpga_write_cmd(0x0B);
  fpga_write_short(0);
  fpga_write_cmd(0x0C);
  fpga_write_short(0);
  fpga_write_cmd(0x0E);
  fpga_write_int(0);
  fpga_write_cmd(0x01);
  fpga_write_byte(0x00);

  //Word 0 of the stream in the ring, the reader on it, a lap flag of before cleared
  flog_snapshot();
  flog.base     = (uint16)((((uint32)((flog.snap[0] & 0x1F) << 8) | flog.snap[1]) - flog.count) & (FLOG_RING - 1));
  flog.consumed = flog.count;
  flog_reader();
  fpga_write_cmd(0x69);
  fpga_write_byte(0x03);

  flog.running = 1;
  return(0);
}

//Stream off; restore = 1 puts the scope's own divider back into 0x0D
void fpga_logger_stop(uint32 restore)
{
  if(!flog.running)
    return;

  flog.running = 0;
  fpga_write_cmd(0x69);
  fpga_write_byte(0x00);

  //v1.01a0: no window processing left for the normal capture (fpga_set_sample_rate sets 0x56 again for its peak)
  fpga_write_cmd(0x53);
  fpga_write_byte(0x00);
  fpga_write_cmd(0x56);
  fpga_write_byte(0x00);

  if(restore)
    fpga_set_sample_rate(scopesettings.samplerate);
}

//The new words (at most maxwords, 4 bytes each: CH1 B, CH1 A, CH2 B, CH2 A) into dst. Returns the words read, 0 for none
//or a gap (*gap = 1: words were lost before the next ones), -1 when the FPGA left stream mode
int32 fpga_logger_read(uint8 *dst, uint32 maxwords, uint32 *gap)
{
  static const uint8 lanes[4] = { 0x21, 0x20, 0x23, 0x22 };
  uint32 n, k, start, part, i, left;
  uint8 *p;

  *gap = 0;

  if(!flog.running)
    return(-1);

  flog_snapshot();

  if(!(flog.snap[0] & 0x80))
  {
    fpga_logger_stop(1);
    return(-1);
  }

  if(flog_lapped())
  {
    flog_gap();
    *gap = 1;
    return(0);
  }

  n = flog.count - flog.consumed;

  if(n > maxwords)
    n = maxwords;

  if(n == 0)
    return(0);

  start = (flog.base + flog.consumed) & (FLOG_RING - 1);

  for(k = 0; k < 4; k++)
  {
    p    = dst + k;
    left = n;
    i    = start;

    while(left)
    {
      part = FLOG_RING - i;

      if(part > left)
        part = left;

      fpga_write_cmd(0x1F);
      fpga_write_short((uint16)i);
      fpga_write_cmd(lanes[k]);
      (void)fpga_read_byte();     //dummy strobe

      left -= part;

      while(part--)
      {
        *p = fpga_read_byte();
        p += 4;
      }

      i = 0;
    }
  }

  //Were the words still there when the last lane was read?
  flog_snapshot();

  if(flog_lapped())
  {
    flog_gap();
    *gap = 1;
    return(0);
  }

  flog.consumed += n;
  flog_reader();

  return((int32)n);
}

//v1.00y9: diagnostics: the stream for 20 ms at 1 Mword/s (divider 99); returns the words the FPGA counted (0: no data,
//-1: not available / could not start). The scope's divider is put back.
int32 fpga_logger_selftest(void)
{
  uint32 t0;
  int32  words;

  if(!FPGA_IS_153F_PORT())
    return(-1);

  if(fpga_logger_start(99, FLOG_SKIP))
    return(-1);

  t0 = timer0_get_ticks();

  while((timer0_get_ticks() - t0) < 20);

  flog_snapshot();
  words = (flog.snap[0] & 0x80) ? (int32)flog.count : 0;

  fpga_logger_stop(1);

  return(words);
}

//Square generator of 0x2050 (0x6C entries high / low, 0x6D control): the period in 1/65536 clocks of 5 ns, so the
//frequency is near exact (Bode). f in mHz, duty in %. Returns the frequency the FPGA really makes (mHz).
//Duty 0 / 100 or f = 0: a static low / high level.
static uint8 fpga_square_running = 0;

static void fpga_square_entry(uint32 index, uint32 level, uint64 p16)
{
  fpga_write_cmd(0x6C);
  fpga_write_byte((uint8)((level ? 0x20 : 0x00) | (index & 0x1F)));
  fpga_write_int((uint32)(p16 >> 16));
  fpga_write_short((uint16)(p16 & 0xFFFF));
}

uint64 fpga_square_set(uint64 f_mhz, uint32 duty)
{
  uint64 p16, h16, l16;

  if((f_mhz == 0) || (duty == 0) || (duty >= 100))
  {
    //Static level: 0x6D = 0x04 high, 0x00 low (mode off)
    fpga_write_cmd(0x6D);
    fpga_write_byte(((duty >= 100) && f_mhz) ? 0x04 : 0x00);
    fpga_square_running = 0;
    return(0);
  }

  //Period: 200 MHz * 65536 * 1000 / f (mHz)
  p16 = 13107200000000000ull / f_mhz;

  h16 = (p16 * duty) / 100;

  //Each step at least 2 clocks
  if(h16 < (2ull << 16))
    h16 = 2ull << 16;

  l16 = (p16 > h16) ? (p16 - h16) : 0;

  if(l16 < (2ull << 16))
    l16 = 2ull << 16;

  if(!fpga_square_running)
  {
    fpga_write_cmd(0x6D);
    fpga_write_byte(0x00);
  }

  fpga_square_entry(0, 1, h16);
  fpga_square_entry(1, 0, l16);

  //Start (mode 3, start, commit) or a change on the run (mode 3, commit)
  fpga_write_cmd(0x6D);
  fpga_write_byte(fpga_square_running ? 0x23 : 0x33);
  fpga_square_running = 1;

  return(13107200000000000ull / (h16 + l16));
}

void fpga_square_off(void)
{
  fpga_write_cmd(0x6D);
  fpga_write_byte(0x00);
  fpga_square_running = 0;
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_check_ready(void)
{
  int i;
  
  //Check if the FPGA is up and running by reading the version number
  while(fpga_get_version() != 0x1432)
  {
    //if not just wait a bit and try it again
    //At 600MHz CPU_CLK 1000 = ~200uS
    for(i=0;i<1000;i++)
    {
      __asm__ ("nop");
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_enable_system(void)
{
  //This command is only ever set with 1 as data and this function is only called at setup and check hardware
  fpga_write_cmd(0x04);
  fpga_write_byte(0x01);
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_on_off_generator(void)
{
  //v1.00x3: 0x2050 has no DDS, the square generator makes the frequency and duty
  if(FPGA_IS_153F_PORT())
  {
    if(fpgasettings.gen_enable == 1)
      fpga_square_set((uint64)fpgasettings.gen_freq * 1000, fpgasettings.gen_duty);
    else
      fpga_square_off();

    fpga_write_cmd(0x50);
    fpga_write_int(fpgasettings.gen_enable == 1);
    return;
  }

  if (fpgasettings.gen_enable == 1)
  {
    fpga_set_generator_freq(fpgasettings.gen_freq);
    fpga_set_generator_duty(fpgasettings.gen_duty);
    
    // Send the command for switch output
    fpga_write_cmd(0x50);

    // Switch output to on
    //fpga_write_byte(1);
    fpga_write_int(1);
  }
  else
  { // To be safe, we will turn off signal generation.
    fpga_set_generator_freq(100); //100Hz
    fpga_set_generator_duty(0);   //duty 0%
    
    // Send the command for switch output
    fpga_write_cmd(0x50);

    // Switch output off to tristate
    //fpga_write_byte(0);
    fpga_write_int(0);
  }
}

//------------------------------------------------------------------------------

void fpga_set_generator_freq(uint32 freq_hz)
{
  //Fout = (phase_inc * Fclk) / 2^32
  //phase_inc = (Fout * 2^32) / Fclk
  //phase_inc = (Fout * 4294967296) / 50000000

  uint64 t = (uint64)freq_hz * 4294967296ULL;

  //v1.00x3: 0x2050: square generator with the set duty
  if(FPGA_IS_153F_PORT())
  {
    fpga_square_set((uint64)freq_hz * 1000, fpgasettings.gen_duty);
    return;
  }

  // Send the command for settings frequency
  fpga_write_cmd(0x51);

  // Set frequency - send divider (32-bit)
  fpga_write_int((t / 50000000ULL));

}

//------------------------------------------------------------------------------

void fpga_set_generator_duty(uint8 duty_pct) //50 is 50%
{
    // threshold = duty_pct * (2^32 - 1) / 100
    uint64 d = (uint64)duty_pct * 0xFFFFFFFFULL;

    //v1.00x3: 0x2050: square generator with the set frequency
    if(FPGA_IS_153F_PORT())
    {
      fpga_square_set((uint64)fpgasettings.gen_freq * 1000, duty_pct);
      return;
    }

    //Send the command for settings duty cycle
    fpga_write_cmd(0x52);

    //Set duty cycle
    fpga_write_int((uint32)(d / 100ULL));
}
  
//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_channel_enable(PCHANNELSETTINGS settings)
{
  //Send the command for channel enable to the FPGA
  fpga_write_cmd(settings->enablecommand);
  
  //Write the needed data based on the setting
  if(settings->enable == 0)
  {
    //Disable the channel
    fpga_write_byte(0x00);
  }
  else
  {
    //Enable the channel
    fpga_write_byte(0x01);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_channel_coupling(PCHANNELSETTINGS settings)
{
  //Send the command for channel 1 coupling to the FPGA
  fpga_write_cmd(settings->couplingcommand);
  
  //Write the needed data based on the setting
  if(settings->coupling == 0)
  {
    //Set the DC coupling for the channel
    fpga_write_byte(0x01);
  }
  else
  {
    //Set the AC coupling for the channel
    fpga_write_byte(0x00);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_channel_voltperdiv(PCHANNELSETTINGS settings)
{
  register uint32 setting = settings->samplevoltperdiv;
  
  //Send the command for channel 1 volts per div to the FPGA
  fpga_write_cmd(settings->voltperdivcommand);
  
  //Check if setting in range of what is allowed
  if(setting > 5)
    setting = 5;
  
  //Write it to the FPGA
  fpga_write_byte(setting);
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_channel_offset(PCHANNELSETTINGS settings)
{
  //uint32 offset;
    
  //Send the command for channel DC offset to the FPGA scopesettings.channel1.traceposition
  fpga_write_cmd(settings->offsetcommand);

  //Write the center offset data for this channel and volt per div setting
  //fpga_write_short(settings->dc_calibration_offset[settings->samplevoltperdiv];
  fpga_write_short(settings->dc_calibration_offset[settings->samplevoltperdiv]+(settings->dcoffset));
  //fpga_write_short(settings->dc_calibration_offset[settings->samplevoltperdiv]-(settings->dcoffset));
  //offset = (signal_adjusters[0] * (settings->dcoffset)/2) / signal_adjusters[settings->samplevoltperdiv];
  
  //offset = (multiply * (settings->traceposition)) / signal_adjusters[settings->displayvoltperdiv];
  
  //fpga_write_short(settings->dc_calibration_offset[settings->samplevoltperdiv]-(offset));
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_sample_rate(uint32 samplerate)
{
  //Translate the time per div setting to what the FPGA needs
  //22-11-2021 Since the long time base settings have been removed and the system does things differently a translation is needed here
  //Old time base was 0 for 50S/div to 29 for 10nS/div
  //This is no longer the case. 0 means 200mS/div but needs the setting for 50mS/div. Same for 100mS/div. Simplest solution is a translation table
  
  //This most likely needs to be based on the acquisition speed and no longer the time per div setting, but that needs further investigation
  
  //Make sure the setting is in range of the table
  if(samplerate < (sizeof(sample_rate_settings) / sizeof(uint32)))
  {
    //v1.00y9: a rate write while the roll stream runs ends the stream (its divider is overwritten); the roll pass
    //starts it again for its time base
    if(flog.running)
    {
      flog.running = 0;
      fpga_write_cmd(0x69);
      fpga_write_byte(0x00);

      //v1.01a0: and its boxcar off (0x56 is written below)
      fpga_write_cmd(0x53);
      fpga_write_byte(0x00);
    }

    //v1.00y2: hardware peak detect (FPGA 0x2050) for Peak / Auto at slow sample rates
    uint32 divider = sample_rate_settings[samplerate];
    uint32 peak    = fpga_hw_peak_wanted(samplerate);
    uint32 hires   = peak ? 0 : fpga_hw_hires_wanted(samplerate);     //v1.01a1
    uint32 hires_was = fpga_hw_hires_on, n_was = fpga_hw_hires_n;

    //Peak words { max, min } of a window of N = 2 * (floor(divider / 2) + 1) raw samples at 200 MSa/s; the divider
    //2 * d + 1 gives N = 2 * (d + 1), so a word spans the time of a normal word (two samples at the set rate) and the
    //two bytes (min as core A, max as core B) take the places of the two samples: time base and record as before
    if(peak || hires)
      divider = (2 * divider) + 1;

    //Write the command to the FPGA
    fpga_write_cmd(0x0D);

    //Write the time base clock setting to the FPGA
    //fpga_write_int(sample_rate_settings[samplerate]);
    fpga_write_int(divider);

    if(FPGA_IS_153F_PORT())
    {
      fpga_write_cmd(0x56);
      fpga_write_byte(peak ? 0x02 : 0x00);

      fpga_hw_peak_on = peak;

      //v1.01a1: the boxcar for the hardware Hi-Res (0x54 shift, 0x53 K = 1), off otherwise
      fpga_hw_hires_on = hires;

      if(hires)
      {
        fpga_hw_hires_n     = fpga_logger_window(divider);
        fpga_hw_hires_shift = (uint8)fpga_logger_shift(fpga_hw_hires_n);
        fpga_write_cmd(0x54);
        fpga_write_byte(fpga_hw_hires_shift);
      }

      fpga_write_cmd(0x53);
      fpga_write_byte(hires ? 0x01 : 0x00);

      //The filter settles in (K + 10) N 5 ns + 1 us after it is switched on or its window changes
      if(hires && (!hires_was || (n_was != fpga_hw_hires_n)))
      {
        uint32 t0 = timer0_get_ticks(), ms = (uint32)(((uint64)11 * fpga_hw_hires_n * 5) / 1000000) + 2;

        while((timer0_get_ticks() - t0) < ms);
      }

      //The trigger level in the form the path in use needs
      if(peak)
      {
        fpga_write_cmd(0x55);
        fpga_write_short((uint16)(scopesettings.trigger_A << 8));
      }

      if(hires)
      {
        fpga_write_cmd(0x55);
        fpga_write_short(fpga_hw_hires_level());
      }
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00z7: 1 while the EXT trigger has the calibration pin as input (generator pin off)
static uint8 fpga_ext_trigger_on = 0;

void fpga_set_trigger_channel(void)
{
  //v1.00z7: 0x2050 / 0x3050 has a real EXT trigger: source 2 = the calibration pin (P133, 3.3 V logic), edge from 0x16,
  //the level (0x17) unused. The pin is an input only with the generator output off (0x50 = 0). Leaving EXT gives the
  //pin back to the generator setting. Older FPGAs: as before (EXT is not sent, the FPGA keeps CH1 / CH2).
  if(FPGA_IS_153F_PORT() && (scopesettings.triggerchannel == 2))
  {
    fpga_write_cmd(0x50);
    fpga_write_int(0);

    fpga_write_cmd(0x15);
    fpga_write_byte(0x02);

    fpga_ext_trigger_on = 1;
    return;
  }

  //Send the command for selecting the trigger channel to the FPGA
  fpga_write_cmd(0x15);
  
  //Write the needed data based on the setting
  if(scopesettings.triggerchannel == 0)
  {
    //Set channel 1 as trigger input
    fpga_write_byte(0x00);
  }
  else
  {
    //Set channel 2 as trigger input
    fpga_write_byte(0x01);
  }

  //v1.00z7: back from EXT: the calibration pin as the generator setting says
  if(fpga_ext_trigger_on)
  {
    fpga_ext_trigger_on = 0;
    fpga_on_off_generator();
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_trigger_edge(void)
{
  //Send the command for selecting the trigger channel to the FPGA
  fpga_write_cmd(0x16);
  
  //Write the needed data based on the setting
  if(scopesettings.triggeredge == 0)
  {
    //Set trigger edge to rising
    fpga_write_byte(0x00);
  }
  else
  {
    //Set trigger edge to falling
    fpga_write_byte(0x01);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_swap_trigger_channel(void)
{
  //v1.00z7: a real EXT trigger (0x2050 / 0x3050) does not depend on the enabled channels
  if(FPGA_IS_153F_PORT() && (scopesettings.triggerchannel == 2))
    return;

  //Check if channel 1 is disabled or channel 2 is enabled
  if((scopesettings.channel1.enable == 0) || (scopesettings.channel2.enable))
  {
    //Check if both channels are disabled
    if(scopesettings.channel2.enable == 0)
    {
      //If so do nothing
      return;
    }
    
    //Else check if channel 1 is enabled
    if(scopesettings.channel1.enable)
    {
      //Assume the correct setting is already in the FPGA and do nothing
      return;
    }
    
    //Only channel 2 enabled so set it as source
    scopesettings.triggerchannel = 1;
  }
  else
  {
    //Only channel 1 enabled so set that as source
    scopesettings.triggerchannel = 0;
  }
  
  //Write it the new setting to the FPGA
  fpga_set_trigger_channel();
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_trigger_level(void)
{
  uint32 voltperdiv;
  uint32 traceposition;
  int32 dcoffset;
  int32  level;
  int32  level_raw;

  //The trace position on screen equals to ADC reading 128
  //The trigger vertical position is relative to the trace position.
  //The screen position values are volt/div related, so conversion to ADC level is needed
  
  //Check which channel is used for triggering
  if(scopesettings.triggerchannel == 0)
  {
    //Channel 1, so use its data
    voltperdiv    = scopesettings.channel1.samplevoltperdiv;
    traceposition = scopesettings.channel1.traceposition;
    //dcoffset = scopesettings.channel1.dcoffset/2;
    //dcoffset = (scopesettings.channel1.dcoffset*100)/220;//195
    dcoffset = (scopesettings.channel1.dcoffset*100)/scopesettings.channel1.dc_shift_size;
    scopesettings.channel1.triggerverticalposition = scopesettings.triggerverticalposition;
  }
  else
  {
    //Channel 2, so use its data
    voltperdiv    = scopesettings.channel2.samplevoltperdiv;
    traceposition = scopesettings.channel2.traceposition;
    //dcoffset = scopesettings.channel2.dcoffset/2;
    //dcoffset = (scopesettings.channel2.dcoffset*100)/220;//230
    dcoffset = (scopesettings.channel2.dcoffset*100)/scopesettings.channel2.dc_shift_size;
    scopesettings.channel2.triggerverticalposition = scopesettings.triggerverticalposition;
  }
  
  //The difference between the two positions determines the level offset on 128, but it needs to be scaled back first
  //level = ((((int32)scopesettings.triggerverticalposition - (int32)traceposition) * 4194304) / signal_adjusters[voltperdiv]) + 128;
  //level = ((((int32)scopesettings.triggerverticalposition - (int32)traceposition) * 2100000) / signal_adjusters[voltperdiv]) + 130;
  //level = ((((int32)scopesettings.triggerverticalposition - (int32)traceposition) * 2097152) / signal_adjusters[voltperdiv]) + 128;
  
    level = ((((int32)(scopesettings.triggerverticalposition - dcoffset) - (int32)traceposition) * 2097152) / signal_adjusters[voltperdiv]) + 128;
  //level = scopesettings.channel1.center-255+traceposition+scopesettings.triggerverticalposition;
  
  
  if (scopesettings.triggeredge == 0) level = level | 0x01;      //Trigger edge to rising
  else if (scopesettings.triggeredge == 1) level = level & 0xFE; //Trigger edge to falling
  
  //Limit on extremes
  if(level < 0)
  {
    level = 0;
  }
  else if(level > 255)
  {
    level = 255;
  }
  
      //Set the new level in the settings
  scopesettings.triggerlevel = level;
  
  //scopesettings.triggerlevel stays in corrected units (the software trigger in scope_process_trigger uses it on the
  //corrected trace buffer). The FPGA however compares the RAW sample of ADC core A of the selected channel (zaklad.v:
  //trigger_data <= trigger_channel ? adc2A : adc1A), and a displayed sample = raw + adc1compensation,
  //so the FPGA gets the raw threshold = level - adc1compensation.
  if(scopesettings.triggerchannel == 0) level_raw = (int32)scopesettings.triggerlevel - scopesettings.channel1.adc1compensation;
  else                                  level_raw = (int32)scopesettings.triggerlevel - scopesettings.channel2.adc1compensation;

  //Limit on extremes (in int32, before the edge bit is set)
  if(level_raw < 0)
  {
    level_raw = 0;
  }
  else if(level_raw > 255)
  {
    level_raw = 255;
  }

  //Bit 0 by edge only after the correction and the clipping, so the result stays within 0..255
  if (scopesettings.triggeredge == 0) level_raw = level_raw | 0x01;      //Trigger edge to rising
  else if (scopesettings.triggeredge == 1) level_raw = level_raw & 0xFE; //Trigger edge to falling

  scopesettings.trigger_A = level_raw;

  //Trigger for ADC core B is commented out: the FPGA (0x153F and own zaklad.v 0x2000) has a single trigger_level (0x17),
  //compares core A only, and 0x18 is a read command (sampling_triggered), so a write is ignored.
  //If the FPGA ever gets a comparator for core B as well, the raw threshold B = level - adc2compensation.
  //   // Correction for core B so that it physically matches core A
  //// Formula: trigger_B = level + KOR_A - KOR_B
  //  //Check which channel is used for triggering
  //if(scopesettings.triggerchannel == 0) scopesettings.trigger_B = level + scopesettings.channel1.adc1compensation - scopesettings.channel1.adc2compensation;
  //  else scopesettings.trigger_B = level + scopesettings.channel2.adc1compensation - scopesettings.channel2.adc2compensation;
  //
  //    //Limit on extremes
  //if(scopesettings.trigger_B < 0)
  //{
  //  scopesettings.trigger_B = 0;
  //}
  //else if(scopesettings.trigger_B > 255)
  //{
  //  scopesettings.trigger_B = 255;
  //}

  //Send the command for setting the trigger level channel A to the FPGA
  fpga_write_cmd(0x17);

  //Write the actual level channel A to the FPGA
  fpga_write_byte(scopesettings.trigger_A);

  //v1.00y2: with the hardware peak detect the FPGA compares 16-bit words { max, min }: the level goes to 0x55 as
  //level << 8 (rising compares the window maximum, falling the minimum)
  if(fpga_hw_peak_on)
  {
    fpga_write_cmd(0x55);
    fpga_write_short((uint16)(scopesettings.trigger_A << 8));
  }

  //v1.01a1: with the hardware Hi-Res the FPGA compares the 16-bit window sum >> shift
  if(fpga_hw_hires_on)
  {
    fpga_write_cmd(0x55);
    fpga_write_short(fpga_hw_hires_level());
  }

  ////Send the command for setting the trigger level channel b to the FPGA
  //fpga_write_cmd(0x18);
  //
  ////Write the actual level channel B to the FPGA
  //fpga_write_byte(scopesettings.trigger_B);
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_trigger_mode(void)
{
  //Send the command for selecting the trigger mode to the FPGA
  fpga_write_cmd(0x1A);
  
  //Write the needed data based on the setting
  if(scopesettings.triggermode == 0)
  {
    //Set trigger mode to auto
    fpga_write_byte(0x00);
  }
  else
  {
    //Set trigger mode to single or normal
    fpga_write_byte(0x01);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//short time base
void fpga_set_time_base(uint32 timebase) //len pre rezim auto, urcuje max cas po ktory sa odoberaju vzorky
{
//  uint32 set_time_automode = 0;
    
  //Make sure setting is in range
  if(timebase < (sizeof(timebase_settings) / sizeof(uint32)))
  {
    //Write the command to set the short time base data to the FPGA
    fpga_write_cmd(0x0E);
    
    //Table settings ranges from setting 0 (200mS/div) to 23 (5nS/div)
    if(fpgasettings.fw_FPGA == 1)
    {
    fpga_write_int(timebase_settings[timebase]);
    }
    else 
    {
      /*/
      if(timebase < 21)  set_time_automode = scopesettings.samplecount;
      if(timebase < 24)  set_time_automode = scopesettings.samplecount * 2;
      if(timebase == 24) set_time_automode = scopesettings.samplecount * 4;
      if(timebase == 25) set_time_automode = scopesettings.samplecount * 6;
      if(timebase == 26) set_time_automode = scopesettings.samplecount * 10;
      if(timebase == 27) set_time_automode = scopesettings.samplecount * 20;
      if(timebase == 28) set_time_automode = scopesettings.samplecount * 40;
      if(timebase == 29) set_time_automode = scopesettings.samplecount * 80;
      if(timebase > 29)  set_time_automode = scopesettings.samplecount * 160;
         
      fpga_write_int(set_time_automode);
      */
      fpga_write_int(scopesettings.samplecount);
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_set_long_timebase(uint32 timebase)
{
  //Send the data, which is always 2000
  //fpga_write_int(2000);//0x07d0 is 2000
  
  //Make sure setting is in range
  if(timebase < (sizeof(timebase_settings) / sizeof(uint32)))
  {
    //Send the command for long time base to the FPGA
    //fpga_write_cmd(0x0D);
  
    //Table settings ranges from setting 0 (200mS/div) to 23 (5nS/div)
    //fpga_write_int(timebase_settings[timebase]);
  }
 
  //The command 0x0D sets the rate with which the ADC is clocked. The 0x07D0 means 100KSa/s.
  //With the command 0x28 the mode is selected. Needs to be set to 0x01 for the roll mode sampling. Not sure if it is needed for every read of the sampl
  
  //Disable trigger system???
  fpga_write_cmd(0x0F);
  fpga_write_byte(0x01);
  
  //Some mode select command for the FPGA (0x01 for long time base)
  //fpga_write_cmd(0x28); //0X28 not support in FPGA???
  //fpga_write_byte(0x01);
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_do_conversion(void)
{ 
  //v1.00y9: a normal capture takes the FPGA from the roll stream
  fpga_logger_stop(1);

  scopesettings.conversion_done = 0;    //flag for conversion, 0-start
  
  //Check if sampling with trigger system enabled
  if(scopesettings.samplemode == 1)
  {
    //Enable trigger system???
    fpga_write_cmd(0x0F);
    fpga_write_byte(0x00);
  }
  else
  {
    //Disable the trigger circuit??
    fpga_write_cmd(0x0F);
    fpga_write_byte(0x01);
  }

  //Reset the sample system
  fpga_write_cmd(0x01);
  fpga_write_byte(0x01);
  
  //Send check on ready command
  fpga_write_cmd(0x05);
  
  //Wait for the flag to become 1
  while((fpga_read_byte() & 1) == 0);
  
  //Test again to make sure it was no glitch?????
  //while((fpga_read_byte() & 1) == 0);
  
  //posielat ked je sytem v resete, aby neprepisal udaje zachodu
  
  if(fpgasettings.fw_FPGA > 1) 
  {
    //Write the command to set the pretrigger_samples to the FPGA
    fpga_write_cmd(0x0B);
    fpga_write_short(fpgasettings.settriggerpoint/2);

    //Write the command to set the total_samples to the FPGA
    fpga_write_cmd(0x0C);
    fpga_write_short(fpgasettings.totalsamples/2);

    //set time to automode
    //fpga_set_time_base(scopesettings.timeperdiv); //11.3 vratene a scope aquire v1.00p0
  }
  
  //Done with reset
  fpga_write_cmd(0x01);
  fpga_write_byte(0x00);
}
//----------------------------------------------------------------------------------------------------------------------------------

uint8 fpga_done_conversion(void)
{
  //Send check on triggered or buffer full command to the FPGA
  fpga_write_cmd(0x0A);
  
  //Check if sampling with trigger system enabled
  if(scopesettings.samplemode == 1)
  {
    if (((fpga_read_byte() & 1) == 1))
    {
        //Disable trigger system???
        fpga_write_cmd(0x0F);
        fpga_write_byte(0x01);
        scopesettings.conversion_done = 1;
    }
  }
  else
  {
    //Check for the FPGA to signal triggered or buffer full
    if (((fpga_read_byte() & 1) == 1)) scopesettings.conversion_done = 1;
  }
  
  //Scan the touch panel
  tp_i2c_read_status();
  if (havetouch == 1) scopesettings.display_data_done = 1;
      
  return (scopesettings.conversion_done);
}

//----------------------------------------------------------------------------------------------------------------------------------

uint16 fpga_prepare_for_transfer(void)
{
  uint32 data;
  
  //Send the command for getting trigger address from the FPGA
  fpga_write_cmd(0x14);
  
  //Just read a short, and with 0x0FFF and add 2
  //Have to see if the add 2 is needed
  //data = (fpga_read_short() & 0x0FFF) + 2;    
  data = (fpga_read_short() & 0x1FFF);  //change 11.12.2025
 
  return(data & 0x1FFF);
}

//----------------------------------------------------------------------------------------------------------------------------------

//See https://en.wikipedia.org/wiki/Methods_of_computing_square_roots#Binary_numeral_system_.28base_2.29
uint32 isqrt(uint32 n) {
  uint32 x = n;
  uint32 c = 0;
  uint32 d = 1 << 30;

  while (d > n) d >>= 2;

  while (d != 0) {
    if (x >= c + d) {
      x -= c + d;
      c = (c >> 1) + d;
    } else {
      c >>= 1;
    }
    d >>= 2;
  }
  return c;
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.01a1: the trigger level code in the units of the boxcar output (N x level >> shift)
uint16 fpga_hw_hires_level(void)
{
  uint32 v = ((uint32)scopesettings.trigger_A * fpga_hw_hires_n) >> fpga_hw_hires_shift;

  return((uint16)((v > 65535) ? 65535 : v));
}

//v1.01a1: one lane of the record (low byte 0x20 / 0x22 or high byte 0x21 / 0x23) into every other place of the buffer
static void fpga_read_lane(uint8 cmd, uint32 triggerpoint, uint8 *dst)
{
  register uint32 count = scopesettings.nofsamples;

  fpga_write_cmd(0x1F);
  fpga_write_short(triggerpoint);
  fpga_write_cmd(cmd);

  FPGA_BUS_DIR_IN();
  FPGA_DATA_READ();

  while(count)
  {
    FPGA_PULSE_CLK();
    *dst = FPGA_GET_DATA();
    dst += 2;
    count--;
  }
}

//v1.01a1: the record of the hardware Hi-Res: the mean code of each word (both cores' compensation as their mean, as in
//the roll) in both places of the word, and the measurements as fpga_read_sample_data / fpga_read_adc_data make them
//(min / max / average / rms with the DC shift, the frequency from the crossings counted per word)
static void fpga_read_hires_data(PCHANNELSETTINGS settings, uint32 triggerpoint)
{
  uint8  *b = settings->tracebuffer;
  uint32  n = scopesettings.nofsamples, i, threshold, x, idx;
  int32   v, s, comp = (settings->adc1compensation + settings->adc2compensation) / 2;

  //Low bytes to the odd places, high bytes to the even ones, then the mean in both
  fpga_read_lane(settings->adc1command, triggerpoint, &b[1]);
  fpga_read_lane(settings->adc2command, triggerpoint, &b[0]);

  settings->min     = 0x7FFFFFFF;
  settings->max     = 0;
  settings->average = 0;
  settings->rms     = 0;
  settings->minDC   = 0x7FFFFFFF;
  settings->maxDC   = 0;

  for(i = 0; i < n; i++)
  {
    x = ((uint32)b[2 * i] << 8) | b[(2 * i) + 1];
    v = (int32)((((uint64)x << fpga_hw_hires_shift) + (fpga_hw_hires_n / 2)) / fpga_hw_hires_n) + comp;

    if(v < 0)   v = 0;
    if(v > 255) v = 255;

    if(v == 0)   settings->ADoverload |= 1;
    if(v == 255) settings->ADoverload |= 254;

    if(settings->invert)
      v = 255 - v;

    b[2 * i]       = (uint8)v;
    b[(2 * i) + 1] = (uint8)v;

    if(v < settings->minDC) settings->minDC = v;
    if(v > settings->maxDC) settings->maxDC = v;

    s = v + ((settings->dcoffset * 100) / settings->dc_shift_value);

    if(s < settings->min) settings->min = s;
    if(s > settings->max) settings->max = s;

    //Both places of the word count
    settings->average += 2 * s;
    settings->rms     += 2 * (s - 128) * (s - 128);
  }

  settings->centerDC   = (settings->maxDC + settings->minDC) / 2;
  settings->peakpeakDC = settings->maxDC - settings->minDC;

  threshold = ((settings->maxDC - settings->minDC) / 10) + 2;
  settings->highlevel = settings->centerDC + threshold;
  settings->lowlevel  = settings->centerDC - threshold;

  settings->zerocrossings   = 0;
  settings->lowsamplecount  = 0;
  settings->lowdivider      = 0;
  settings->highsamplecount = 0;
  settings->highdivider     = 0;
  settings->previousindex   = 0;
  settings->state           = (b[1] > settings->highlevel) ? 1 : 0;

  //Crossings with the word index, as fpga_read_adc_data (the times are doubled below to samples)
  for(idx = 0; idx < n; idx++)
  {
    v = b[(2 * idx) + 1];

    if((v > (int32)settings->highlevel) && (settings->state == 0))
    {
      settings->state = 1;

      if(settings->zerocrossings)
      {
        settings->lowsamplecount += idx - settings->previousindex;
        settings->lowdivider++;
      }

      settings->previousindex = idx;
      settings->zerocrossings++;
    }
    else if((v < (int32)settings->lowlevel) && (settings->state == 1))
    {
      settings->state = 0;

      if(settings->zerocrossings)
      {
        settings->highsamplecount += idx - settings->previousindex;
        settings->highdivider++;
      }

      settings->previousindex = idx;
      settings->zerocrossings++;
    }
  }

  settings->average /= scopesettings.samplecount;
  settings->rms      = isqrt(settings->rms / scopesettings.samplecount);
  settings->peakpeak = settings->max - settings->min;
  settings->center   = (settings->max + settings->min) / 2;

  if((settings->zerocrossings > 2) && settings->highdivider && settings->lowdivider)
  {
    settings->frequencyvalid = 1;
    settings->hightime   = (((uint64)settings->highsamplecount << 16) / settings->highdivider) * 2;
    settings->lowtime    = (((uint64)settings->lowsamplecount << 16) / settings->lowdivider) * 2;
    settings->periodtime = settings->hightime + settings->lowtime;
    settings->frequency  = ((uint64)freq_calc_data[scopesettings.samplerate].sample_rate << 16) / settings->periodtime;
  }
  else
    settings->frequencyvalid = 0;
}

void fpga_read_sample_data(PCHANNELSETTINGS settings, uint32 triggerpoint)
{
  uint32 threshold;

  //v1.01a1: hardware Hi-Res record of a scope channel
  if(fpga_hw_hires_on && ((settings == &scopesettings.channel1) || (settings == &scopesettings.channel2)))
  {
    fpga_read_hires_data(settings, triggerpoint);
    return;
  }
  
  //Clear min and max and average for new calculations
  settings->min     = 0x7FFFFFFF;
  settings->max     = 0;
  settings->average = 0;
  settings->rms     = 0;
  
  settings->minDC     = 0x7FFFFFFF;
  settings->maxDC     = 0;
  
  //Send command 0x1F to the FPGA followed by the translated data returned from command 0x14
  fpga_write_cmd(0x1F);
  fpga_write_short(triggerpoint);
  
  //Send a command for getting ADC1 trace data from the FPGA
  fpga_write_cmd(settings->adc1command);
  
  //Signal no checking on the first ADC when compensating
  settings->checkfirstadc = 0;
  
  //Setup for reading the first ADC
  settings->compensation = settings->adc1compensation;
  settings->buffer = &settings->tracebuffer[1];
  
  //Read the data for the first ADC. Samples start on the second location, skipping every other sample
  fpga_read_adc_data(settings);

  //Save the calculated measurements
  settings->adc1rawaverage = settings->rawaverage;
  

  //Calculate the signal center for frequency determination
  //Calculate the signal center for autosetup dc shift  
  settings->centerDC = (settings->maxDC + settings->minDC) / 2;
  
  //Calculate the peak to peak value for autosetup dc shift
  settings->peakpeakDC = settings->maxDC - settings->minDC;
  
    //Calculate the signal center for frequency determination
  //settings->center = (settings->max + settings->min) / 2;
  
  //Calculate a zero crossing threshold value
  threshold = ((settings->maxDC - settings->minDC) / 10) + 2;
  
  //Set levels for detecting zero crossings
  settings->highlevel = settings->centerDC + threshold;
  settings->lowlevel  = settings->centerDC - threshold;
  
  
  /*
  //Calculate the signal center for frequency determination
  settings->center = (settings->max + settings->min) / 2;
  
  //Calculate a zero crossing threshold value
  threshold = ((settings->max - settings->min) / 10) + 2;
  
  //Set levels for detecting zero crossings
  settings->highlevel = settings->center + threshold;
  settings->lowlevel  = settings->center - threshold;
  */
  
  //Initialize the frequency determination
  settings->zerocrossings   = 0;
  settings->lowsamplecount  = 0;
  settings->lowdivider      = 0;
  settings->highsamplecount = 0;
  settings->highdivider     = 0;
  
  settings->previousindex = 0;
  
  //See in which state the signal starts
  if(settings->tracebuffer[1] > settings->highlevel)
  {
    //Above high it is a one
    settings->state = 1;
  }
  else
  {
    //Below start with a zero
    settings->state = 0;
  }
  
  //Send command 0x1F to the FPGA followed by the translated data returned from command 0x14
  fpga_write_cmd(0x1F);
  fpga_write_short(triggerpoint);
  
  //Send a command for getting ADC2 trace data from the FPGA
  fpga_write_cmd(settings->adc2command);

  //Signal to check the readings of the first ADC on being zero when compensating
  settings->checkfirstadc = 1;

  //Setup for reading the first ADC
  settings->compensation = settings->adc2compensation;
  settings->buffer = &settings->tracebuffer[0];
  
  //Read the data for the second ADC. Samples start on the first location, skipping every other sample
  fpga_read_adc_data(settings);

  //Save the calculated measurements
  settings->adc2rawaverage = settings->rawaverage;
  
  //Calculate the overall average
  settings->average /= scopesettings.samplecount;

  //Calculate the RMS
  settings->rms = isqrt(settings->rms / scopesettings.samplecount);

  //Calculate the peak to peak value
  settings->peakpeak = settings->max - settings->min;
  
  //Calculate the signal center
  settings->center = (settings->max + settings->min) / 2;
  
  //===================================
  /*
  //Calculate the frequency if possible
#define FP_SHIFT 20

if(settings->zerocrossings > 2 &&
   settings->highdivider &&
   settings->lowdivider)
{
  settings->frequencyvalid = 1;

  // Average HIGH time (Q16.16 samples)
  settings->hightime =
    ((uint64)settings->highsamplecount << FP_SHIFT)
    / settings->highdivider;

  // Average LOW time (Q16.16 samples)
  settings->lowtime =
    ((uint64)settings->lowsamplecount << FP_SHIFT)
    / settings->lowdivider;

  // FULL PERIOD = 2 × (HIGH + LOW)
  settings->periodtime =
    (settings->hightime + settings->lowtime) << 1;

  // Frequency
  settings->frequency =
    ((uint64)freq_calc_data[scopesettings.samplerate].sample_rate << FP_SHIFT)
    / settings->periodtime;
}
else
{
  settings->frequencyvalid = 0;
}

*/
  
  //=============================
/*
    // --------------------------------------------------------------
     // FREQUENCY + TIME CALCULATION
     // --------------------------------------------------------------
    if ((settings->zerocrossings >= 4) && (settings->highdivider > 0) && (settings->lowdivider > 0))
    {
        // Average HIGH and LOW time in SAMPLES 
        settings->hightime = settings->highsamplecount / settings->highdivider;

        settings->lowtime = settings->lowsamplecount / settings->lowdivider;

        settings->periodtime = settings->hightime + settings->lowtime;

        if (settings->periodtime > 0)
        {
            settings->frequency = (freq_calc_data[scopesettings.samplerate].sample_rate / settings->periodtime) / 2;

            settings->frequencyvalid = 1;
        }
        else
        {
            settings->frequencyvalid = 0;
        }
    }
    else
    {
        settings->frequencyvalid = 0;
    }
  
uint32 sr = freq_calc_data[scopesettings.samplerate].sample_rate;

settings->hightime =
    (uint64)settings->hightime * 1000000ULL / sr;

settings->lowtime =
    (uint64)settings->lowtime * 1000000ULL / sr;

        settings->periodtime = settings->hightime + settings->lowtime;
*/

//}

  
  
  
//=========================================
  

   //Calculate the frequency if possible
  if(settings->zerocrossings > 2)
  {
    //Signal valid frequency determination possible
    settings->frequencyvalid = 1;
    

                     //Calculate the average high time of the signal expressed in samples
    settings->hightime = (((uint64)settings->highsamplecount << 16) / settings->highdivider) * 2;
    
    //Calculate the average low time of the signal expressed in samples
    settings->lowtime = (((uint64)settings->lowsamplecount << 16) / settings->lowdivider) * 2;
    
    //Calculate the period time expressed in samples
    settings->periodtime = settings->hightime + settings->lowtime;
 
      //Calculate the frequency
    settings->frequency = ((uint64)freq_calc_data[scopesettings.samplerate].sample_rate << 16) / settings->periodtime;
 
 
/*
    settings->hightime = (settings->highsamplecount * 2) / settings->highdivider;

    settings->lowtime = (settings->lowsamplecount * 2) / settings->lowdivider;

    settings->periodtime = settings->hightime + settings->lowtime;

    settings->frequency = (uint64)freq_calc_data[scopesettings.samplerate].sample_rate / settings->periodtime;

*/
    
    //Calculate the frequency
   // settings->frequency = ((uint64)freq_calc_data[scopesettings.samplerate].sample_rate << 20) / settings->periodtime;
/*
     
            settings->hightime = settings->highsamplecount / settings->highdivider;

        settings->lowtime = settings->lowsamplecount / settings->lowdivider;

        settings->periodtime = settings->hightime + settings->lowtime;


            settings->frequency = (freq_calc_data[scopesettings.samplerate].sample_rate / settings->periodtime) / 2;
 */
            
/*
 
                 //Calculate the average high time of the signal expressed in samples
    settings->hightime = (((uint64)settings->highsamplecount << 20) / settings->highdivider) * 2;
    
    //Calculate the average low time of the signal expressed in samples
    settings->lowtime = (((uint64)settings->lowsamplecount << 20) / settings->lowdivider) * 2;
    
    //Calculate the period time expressed in samples
    settings->periodtime = settings->hightime + settings->lowtime;
 */
            
  }
  else
  {
    //Signal no valid frequency determination possible
    settings->frequencyvalid = 0;
  }
  
}

//----------------------------------------------------------------------------------------------------------------------------------

void fpga_read_adc_data(PCHANNELSETTINGS settings)
{
  register int32  sample;
  register uint32 count;
  register uint32 sum = 0;
  
  //static uint64 global_sample_counter = 0;
  
  //Set the bus for reading
  FPGA_BUS_DIR_IN();
  
  //Set the control lines for reading a command
  FPGA_DATA_READ();
  
  //Set the number of samples to read
  count = scopesettings.nofsamples;
  //count = fpgasettings.totalsamples/2;
  
  //Read the data as long as there is count
  while(count)
  {
    //Clock the data to the output of the FPGA
    FPGA_PULSE_CLK();

    //Read the data
    sample = FPGA_GET_DATA();
    
    //Sum the raw data for ADC difference calibration
    sum += sample;

    //Compensate the value for ADC in equality
    sample += settings->compensation;
     
    //Check if sample became negative
    if(sample < 0)
    {
      //Keep it on zero if so
      sample = 0;
    }
    
    //Check if sample over its max
    if(sample > 255)
    {
      //Keep it on max if so
      sample = 255;
    }
      
 //*****************************************************************************   
    //Check if sample overload ADC
    if (sample == 0)    settings->ADoverload |= 1;
    if (sample == 255)  settings->ADoverload |= 254;    //=255
 //*****************************************************************************   
    
    //Check if busy with second ADC data
    if(settings->checkfirstadc)
    {
      //When ADC1 compensation is positive, ADC1 bottoms out on this value
      //Near the top ADC2 reaches the top value first, so same method is needed
      if(settings->adc1compensation > 0)
      {
        //So when the compensated ADC2 sample is below the ADC1 compensation value the reading needs to be matched
        if(sample < settings->adc1compensation)
        {
          //Match the two readings when within compensation range
          settings->buffer[1] = sample;
        }
        //Or when the compensated ADC1 sample is above max value ADC2 can reach the reading also needs to be matched
        else if(settings->buffer[1] > (255 + settings->adc2compensation))
        {
          //Use the compensated ADC1 sample in that case
          sample = settings->buffer[1];
        }
      }
      //When ADC1 compensation is negative, ADC2 bottoms out on it's compensation value
      else if(settings->adc1compensation < 0)
      {
        //So when the compensated ADC1 sample is below the ADC2 compensation value the reading needs to be matched
        if(settings->buffer[1] < settings->adc2compensation)
        {
          //Use the compensated ADC1 sample in that case
          sample = settings->buffer[1];
        }
        //Or when the compensated ADC2 sample is above max value ADC1 can reach the reading also needs to be matched
        else if(sample > (255 + settings->adc1compensation))
        {
          //Match the two readings when within compensation range
          settings->buffer[1] = sample;
        }
      }
    }
    
    if (settings->invert) sample = 255-sample;  //Invert channel settings 1-signal inverted 
    
    //Store the data
    *settings->buffer = sample;
    
//-*****************************************************************************    
    
        //Get the minimum value of the samples
    if(sample < settings->minDC)
    {
      //Keep the lowest
      settings->minDC = sample;
    }
    
    //Get the maximum value of the samples
    if(sample > settings->maxDC)
    {
      //Keep the highest
      settings->maxDC = sample;
    }
  //************** 
    /* ------------------------------------------------------------------
 * Robust zero-crossing + frequency + time+ / time- measurement
 * Time is measured ONLY in samples using a monotonic counter
 * ------------------------------------------------------------------ */


    /* --------------------------------------------------------------
     * GLOBAL MONOTONIC SAMPLE COUNTER
     * -------------------------------------------------------------- */
    
    //global_sample_counter++;

    /* --------------------------------------------------------------
     * ZERO-CROSSING / TIME MEASUREMENT
     * -------------------------------------------------------------- */
    /*
    if (settings->checkfirstadc)
    {
        uint64 idx = global_sample_counter;   // TRUE TIME IN SAMPLES

        // Rising edge: LOW -> HIGH 
        if (sample > settings->highlevel)
        {
            if (settings->state == 0)
            {
                settings->state = 1;

                if (settings->zerocrossings > 0)
                {
                    uint64 dt = idx - settings->previousindex;
                    settings->lowsamplecount += dt;
                    settings->lowdivider++;
                }

                settings->previousindex = idx;
                settings->zerocrossings++;
            }
        }
        // Falling edge: HIGH -> LOW 
        else if (sample < settings->lowlevel)
        {
            if (settings->state == 1)
            {
                settings->state = 0;

                if (settings->zerocrossings > 0)
                {
                    uint64 dt = idx - settings->previousindex;
                    settings->highsamplecount += dt;
                    settings->highdivider++;
                }

                settings->previousindex = idx;
                settings->zerocrossings++;
            }
        }
    }

*/

    //======================
        // ---- zero-crossing / frequency detection (robust pre veľké nofsamples) ---- 
    
    if (settings->checkfirstadc)
    {
        // compute a stable up-counting sample index (0 .. nofsamples-1) 
        uint64 idx = (scopesettings.nofsamples - count); // up-counter 

        // Use current sample (already compensated/inverted) 
        if (sample > settings->highlevel)
        {
            // Rising edge: Low -> High 
            if (settings->state == 0)
            {
                settings->state = 1;

                if (settings->zerocrossings == 0)
                {
                    // first crossing: just record the index 
                    settings->previousindex = idx;
                }
                else
                {
                    // interval that was LOW 
                    uint64 dt = idx - settings->previousindex;
                    settings->lowsamplecount += dt;
                    settings->lowdivider++;
                    settings->previousindex = idx;
                }

                settings->zerocrossings++;
            }
        }
        else if (sample < settings->lowlevel)
        {
            // Falling edge: High -> Low 
            if (settings->state == 1)
            {
                settings->state = 0;

                if (settings->zerocrossings == 0)
                {
                    settings->previousindex = idx;
                }
                else
                {
                    // interval that was HIGH 
                    uint64 dt = idx - settings->previousindex;
                    settings->highsamplecount += dt;
                    settings->highdivider++;
                    settings->previousindex = idx;
                }

                settings->zerocrossings++;
            }
        }
    }

    
    //=====================
    /*
    //Check if busy with second ADC data to see if frequency determination can be done
    if(settings->checkfirstadc)
    {
      //Check against the high level
      if(sample > settings->highlevel)
      {
        //If above, check if in low state
        if(settings->state == 0)
        {
          //If so flip the state
          settings->state = 1;
          
          //Check if first zero crossing detected
          if(settings->zerocrossings == 0)
          {
            //Set the previous index if so
            settings->previousindex = count;
          }
          else
          {
            //Calculate the total number of samples in the low parts of the signal
            settings->lowsamplecount += settings->previousindex - count;
            
            //Add one to the low divider for average calculation
            settings->lowdivider++;
            
            //Set the new previous index
            settings->previousindex = count;
          }

          //Found a zero crossing
          settings->zerocrossings++;
        }
      }
      //Check against the low level
      else if(sample < settings->lowlevel)
      {
        //If below check if in high state
        if(settings->state == 1)
        {
          //If so flip the state
          settings->state = 0;

          //Check if first zero crossing detected
          if(settings->zerocrossings == 0)
          {
            //Set the previous index if so
            settings->previousindex = count;
          }
          else
          {
            //Calculate the total number of samples in the high parts of the signal
            settings->highsamplecount += settings->previousindex - count;
            
            //Add one to the low divider for average calculation
            settings->highdivider++;
            
            //Set the new previous index
            settings->previousindex = count;
          }
          
          //Found a zero crossing
          settings->zerocrossings++;
        }
      }
    }  
    */
  //***************  
    //For dc shift in DC mode  
    //385 korekcia nameranej hodnoty (avg=0 pri DC s offsetom aj AC mode), vecie cislo-nizsia zobrazena hodnota
    //sample+=((settings->dcoffset*100)/385); //386 = -200mV, 385 = +100mV
    sample+=((settings->dcoffset*100)/(settings->dc_shift_value)); //386 = -200mV, 385 = +100mV
    
    //Get the minimum value of the samples
    if(sample < settings->min)
    {
      //Keep the lowest
      settings->min = sample;
    }
    
    //Get the maximum value of the samples
    if(sample > settings->max)
    {
      //Keep the highest
      settings->max = sample;
    }
    
    //Add the samples for average calculation
    settings->average += sample;

	//Add squares of the samples for RMS calculation
	settings->rms += (sample - 128) * (sample - 128);
     
    //Skip a sample to allow for ADC2 data to be placed into
    settings->buffer += 2;
    //fpga fifo RAM    
    //settings->buffer += 1;
         
    //One read done
    count--;
  }
 
  //Calculate the raw average
  settings->rawaverage = sum / scopesettings.nofsamples;
}

//----------------------------------------------------------------------------------------------------------------------------------

uint16 fpga_average_trace_data(PCHANNELSETTINGS settings)
{
  //Read ten bytes of trace data and average them
  uint16 data = 0;
  int16  datatmp = 0;
  uint32 count = 10;
  
  //register uint32 setting = settings->samplevoltperdiv;
  
  //Send a command for getting trace data from the FPGA
  fpga_write_cmd(settings->averagecommand);
  
  //Set the bus for reading
  FPGA_BUS_DIR_IN();
  
  //Set the control lines for reading a command
  FPGA_DATA_READ();

  //Read the data as long as there is count
  while(count)
  {
    //Clock the data to the output of the FPGA
    FPGA_PULSE_CLK();
 
    //Read the data CH1 or CH2
    datatmp = FPGA_GET_DATA() + settings->adc1compensation; 
    
    //Check limits
    if (datatmp > 255)  datatmp = 255;
    if (datatmp < 0)    datatmp = 0;
        
        
    data += (uint16)datatmp;
    
    //One read done
    count--;
  }
  
  //Calculate the average and return it
  //data = data / 10;
  //data = (data * multiply) >> VOLTAGE_SHIFTER;
  return(data / 10);
}

uint16 fpga_average_trace_data_long(PCHANNELSETTINGS settings)
{
  //Read ten bytes of trace data and average them
  uint16 data = 0;
  int16 datatmp = 0;
  uint32 count = 100;
  
  //register uint32 setting = settings->samplevoltperdiv;
  
  //Send a command for getting trace data from the FPGA
  fpga_write_cmd(settings->averagecommand);
  
  
  //Set the bus for reading
  FPGA_BUS_DIR_IN();
  
  //Set the control lines for reading a command
  FPGA_DATA_READ();

  //Read the data as long as there is count
  while(count)
  {
    //Clock the data to the output of the FPGA
    FPGA_PULSE_CLK();
 
    //Read the data CH1 or CH2
    datatmp = FPGA_GET_DATA() + settings->adc1compensation; 
    
    //Check limits
    if (datatmp > 255)  datatmp = 255;
    if (datatmp < 0)    datatmp = 0;
        
        
    data += (uint16)datatmp;
    
    //One read done
    count--;
  }
  
  //Calculate the average and return it
  //data = data / 10;
  //data = (data * multiply) >> VOLTAGE_SHIFTER;
    
  return(data);
}


//----------------------------------------------------------------------------------------------------------------------------------
/*
void fpga_set_battery_level(void)
{
  //Send the command for setting the battery level to the FPGA??
  fpga_write_cmd(0x3C);
  
  //Write the data
  fpga_write_short(32431);
}
*/
//----------------------------------------------------------------------------------------------------------------------------------

void fpga_delay(uint32 usec)
{
  uint32 loops = usec * 54;

  __asm__ __volatile__ ("1:\n" "subs %0, %1, #1\n"  "bne 1b":"=r"(loops):"0"(loops));
}

//----------------------------------------------------------------------------------------------------------------------------------
