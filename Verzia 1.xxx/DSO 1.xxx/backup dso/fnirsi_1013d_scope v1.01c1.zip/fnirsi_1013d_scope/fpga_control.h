//----------------------------------------------------------------------------------------------------------------------------------

#ifndef FPGA_CONTROL_H
#define FPGA_CONTROL_H

//----------------------------------------------------------------------------------------------------------------------------------

#include "types.h"
#include "variables.h"

//----------------------------------------------------------------------------------------------------------------------------------

//FPGA port registers (Port E on the F1C100s)
#define FPGA_BUS_CFG_REG        ((volatile uint32 *)(0x01C20890))
#define FPGA_CTRL_CFG_REG       ((volatile uint32 *)(0x01C20894))
#define FPGA_DATA_REG           ((volatile uint32 *)(0x01C208A0))

//Initialize the control lines for communication with the FPGA (PE8:10 output)
#define FPGA_CTRL_INIT()        *FPGA_CTRL_CFG_REG = (*FPGA_CTRL_CFG_REG & 0xFFFFF000) | 0x00000111

//Initialize the clock line to high
#define FPGA_CLK_INIT()         (*FPGA_DATA_REG |= 0x00000100)

//Set the different target options for communication with the FPGA
#define FPGA_CMD_WRITE()        (*FPGA_DATA_REG = (*FPGA_DATA_REG & 0xFFFFF9FF) | 0x00000600)
#define FPGA_CMD_READ()         (*FPGA_DATA_REG = (*FPGA_DATA_REG & 0xFFFFF9FF) | 0x00000400)
#define FPGA_DATA_WRITE()       (*FPGA_DATA_REG = (*FPGA_DATA_REG & 0xFFFFF9FF) | 0x00000200)
#define FPGA_DATA_READ()        (*FPGA_DATA_REG = (*FPGA_DATA_REG & 0xFFFFF9FF) | 0x00000000)

//Clock control
#define FPGA_PULSE_CLK()        (*FPGA_DATA_REG &= 0xFFFFFEFF);(*FPGA_DATA_REG |= 0x00000100)

//Control the direction of the FPGA databus
#define FPGA_BUS_DIR_IN()       *FPGA_BUS_CFG_REG  = 0x00000000
#define FPGA_BUS_DIR_OUT()      *FPGA_BUS_CFG_REG  = 0x11111111

//Put data on or get data from the FPGA databus
#define FPGA_SET_DATA(x)        (*FPGA_DATA_REG = (*FPGA_DATA_REG & 0xFFFFFF00) | (x & 0x000000FF))
#define FPGA_GET_DATA()         (*FPGA_DATA_REG & 0x000000FF)

//----------------------------------------------------------------------------------------------------------------------------------

void   fpga_init(void);

void   fpga_write_cmd(uint8 command);
uint8  fpga_read_cmd(void);

void   fpga_write_byte(uint8 data);
uint8  fpga_read_byte(void);

void   fpga_write_short(uint16 data);
uint16 fpga_read_short(void);

void   fpga_write_int(uint32 data);

void   fpga_set_backlight_brightness(uint16 brightness);
void   fpga_set_translated_brightness(void);

uint16 fpga_get_version(void);
uint32 fpga_memory_words(void);                     //v1.00x3
uint32 fpga_max_samples(void);                      //v1.00x4
uint32 fpga_memory_choice(uint32 i);                //v1.00x4
void   fpga_limit_record_length(void);              //v1.00x4
void   fpga_set_holdoff(void);                      //v1.00x3
void   fpga_set_trigger_hysteresis(void);           //v1.00x9
void   fpga_holdoff_clear_request(void);            //v1.00x9
int32  fpga_read_encode_check(void);                //v1.00x9
uint32 fpga_logger_running(void);                   //v1.00y9: streaming logger (0x2050 / 0x3050)
#define FLOG_SKIP     0       //v1.01a0: logger words: sample skipping (two samples per word)
#define FLOG_PEAK     1       //{ max, min } of a window of raw samples at 200 MSa/s (0x56 bit 1)
#define FLOG_BOXCAR   2       //sum of a window >> shift (0x53 = 1, 0x54)
uint32 fpga_logger_start(uint32 divider, uint32 hw);
uint32 fpga_logger_window(uint32 divider);
uint32 fpga_logger_shift(uint32 n);
uint16 fpga_hw_hires_level(void);     //v1.01a1: hardware Hi-Res (boxcar) trigger level
extern uint8 fpga_hw_hires_on;
void   fpga_logger_stop(uint32 restore);
int32  fpga_logger_read(uint8 *dst, uint32 maxwords, uint32 *gap);
int32  fpga_logger_selftest(void);
extern uint8 fpga_hw_peak_on;                       //v1.00y2: the hardware peak detect is in use
extern uint8 fpga_hw_peak_block;                    //v1.00y7: 1 = no peak detect (AUTO SET measuring)
uint32 fpga_hw_peak_wanted(uint32 samplerate);      //v1.00y2
void   fpga_set_adc_capture(uint16 capsel);         //v1.00y1
void   fpga_restore_adc_capture(void);              //v1.00y1
//uint16 fpga_adc_capture_calibrate(uint32 *ch1counts, uint32 *ch2counts);   //v1.00y1
#define CAPCAL_NO_RESULT   0      //v1.00y4: the data did not follow the offset (nothing measured)
#define CAPCAL_OK          1      //new stages found (in the FPGA, to be kept or undone)
#define CAPCAL_SAME        2      //the result equals the power-on stage 3 / 3: nothing to store
#define CAPCAL_FAILED      3      //a channel without a clean stage
uint32 fpga_adc_capture_calibrate(uint32 *ch1counts, uint32 *ch2counts, uint16 *value);   //v1.00y4
uint64 fpga_square_set(uint64 f_mhz, uint32 duty);  //v1.00x3 (FPGA 0x2050)
void   fpga_square_off(void);                       //v1.00x3 (FPGA 0x2050)

void   fpga_check_ready(void);

void   fpga_enable_system(void);

void   fpga_on_off_generator(void);
void   fpga_set_generator_freq(uint32 freq_hz);
void   fpga_set_generator_duty(uint8 duty);

void   fpga_set_channel_enable(PCHANNELSETTINGS settings);
void   fpga_set_channel_coupling(PCHANNELSETTINGS settings);
void   fpga_set_channel_voltperdiv(PCHANNELSETTINGS settings);
void   fpga_set_channel_offset(PCHANNELSETTINGS settings);

void   fpga_set_sample_rate(uint32 samplerate);
void   fpga_set_time_base(uint32 timebase);     //void   fpga_set_short_timebase(void);

void   fpga_set_long_timebase(uint32 timebase);            //For long time base

void   fpga_set_trigger_channel(void);
void   fpga_set_trigger_edge(void);
void   fpga_swap_trigger_channel(void);
void   fpga_set_trigger_level(void);
void   fpga_set_trigger_mode(void);

void   fpga_do_conversion(void);
uint8  fpga_done_conversion(void);

uint16 fpga_prepare_for_transfer(void);

void   fpga_read_sample_data(PCHANNELSETTINGS settings, uint32 triggerpoint);
void   fpga_read_adc_data(PCHANNELSETTINGS settings);

uint16 fpga_average_trace_data(PCHANNELSETTINGS settings);  //For long time base
uint16 fpga_average_trace_data_long(PCHANNELSETTINGS settings);

//void   fpga_set_battery_level(void);

void   fpga_delay(uint32 usec);

//----------------------------------------------------------------------------------------------------------------------------------

#endif /* FPGA_CONTROL_H */

