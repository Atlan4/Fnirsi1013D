/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   ref_and_math.h
 * Author: dk
 *
 * Created on April 29, 2025, 10:52 AM
 */


void display_REFx_data(void);
void copy_ch_to_ref(CHANNELSETTINGS *dest, const CHANNELSETTINGS *src, uint32 *tracebuffer);

void display_MATHx_data(void);

uint8* get_channel_data(int channel);
void compute_all_math_ops(int channelA, int channelB);

//for save and load file
void scope_load_ALLREF_file(void);
void scope_load_REFx_item_file(uint8 number);
void scope_save_REFx_item_file(uint8 number);
void scope_restore_setup_from_REFx_file(uint8 number);
void scope_prepare_setup_for_REFx_file(uint8 number);



//v1.00y3: reference curves of the frequency response and the spectrum views: 4 slots, a panel like the scope's REF
//menu (REF n show / Copy / Save / Load, and a row for all), files in \ref_bode\ and \ref_spec\ (folders)
#define VIEW_REF_SLOTS   4

typedef struct
{
  const char *folder;                       //"\\ref_bode" (no end backslash)
  const char *ext;                          //".bod"
  uint32 (*valid)(int i);                   //slot holds a curve
  uint32 (*shown)(int i);
  void   (*toggle)(int i);                  //show / hide
  uint32 (*copy)(int i);                    //the live curve to the slot; 1 when done
  uint32 (*write)(FIL *fp, int i);          //slot to an open file; FR_OK when done
  uint32 (*read)(FIL *fp, int i);           //open file to the slot; FR_OK when done
  void   (*clear)(int i);
} VIEWREFOPS;

extern const uint32 view_ref_colors[VIEW_REF_SLOTS];

void   view_ref_panel(uint32 xpos, const VIEWREFOPS *ops);
void   view_ref_file_name(char *name, const VIEWREFOPS *ops, int i);
void   scope_ref_folder_fix(void);
