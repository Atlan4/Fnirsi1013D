# FNIRSI 1013D – súhrn práce (stav 27. 11. 2026, firmvér v1.01b2)

Pokračovanie súboru `HANDOFF.md` (stav v1.00v9). Tento súbor opisuje všetko od v1.00z4 po v1.01b2.
Nič z toho nie je odskúšané na prístroji, pokiaľ nie je uvedené inak.

## 1. Pravidlá (platia ďalej)

- Komunikácia po slovensky, komentáre v kóde po anglicky. Dusan nechce nič z vlastnej iniciatívy mimo zadania.
- Verzia = jeden riadok `#define VERSION_STRING "v1.01xN" // popis` v `variables.h` (riadok 19). Po `z9` prišlo
  `v1.01a0` (Dusan to potvrdil), ďalej `a1 … a9`, `b0 … b2`. Ďalšia verzia je **v1.01c2**.
- Záloha po každej verzii: `rsync -a --exclude build --exclude dist fnirsi_1013d_scope/ "zaloha moje scope/fnirsi_1013d_scope vX/"`.
  **Žiadne `scope vX.bin`** v `zaloha moje scope` (Dusanov pokyn od v1.00z5).
- Build na kontrolu v dočasnom priečinku (nie v projekte, `.build-post` kopíruje na SD a do firmware_Atlan_Peco):
  `rsync -a --exclude build --exclude dist --exclude i2c_chips ./ $B/; cd $B; make -f nbproject/Makefile-Debug.mk CONF=Debug SUBPROJECTS= .build-conf`,
  potom `arm-none-eabi-objcopy -O binary dist/Debug/*/fnirsi_1013d_scope.elf fw.bin` a `./mksunxi fw.bin`.
  Staré varovania (test.c 1158/1301, menu.c 2635/4167/5713, statemachine.c unused a..k, cdc/usb lcd_y) nie sú nové.
- Nový `.c` súbor treba pridať do `nbproject/Makefile-Debug.mk`, `Makefile-Release.mk` a `configurations.xml`
  (NetBeans zatvorený). Preto je **celý dekodér v `test.c`** (presun do `i2c.c`/`decoder.c` je otvorený bod).
- Starý kód sa nemaže, ale dáva do `#if 0 … #endif` s poznámkou verzie.
- Pozor: komentár `//` končiaci spätným lomítkom (`\ref_roll\`) predĺži komentár na ďalší riadok. Cesty v komentároch
  písať bez koncového `\`.

## 2. Verzie od v1.00z5

| Verzia | Čo |
|---|---|
| z5 | Roll (FPGA streaming logger 0x2050/0x3050): MEASURES zo zobrazených stĺpcov (Vmax/Vmin z min/max vzoriek, Vavg/Vrms z priemerov, frekvencia len pri ≥ 2 periódach po ≥ 4 stĺpcoch), Peak/Pro pásmo min–max (kruhový buffer `rollf_pmin/pmax`), Trace v ACQ menu odblokovaný v roll, REF v roll (zobrazené stĺpce, značka v `sample1`) |
| z6 | Roll REF vo vlastnom priečinku `\ref_roll\`, posun REF hore/dole v roll prekreslí roll |
| z7 | Skutočný EXT trigger (0x15 = 2, kalibračný pin, generátor sa vypne), samostatná sada REF pre roll a normál (`scope_refset_sync`, uloženie oboch) |
| z8 | Oranžová pevná šípka „E“ pri EXT so stavom pinu (0x28 bit 0: plná = 1, obrys = 0), napätie triggera pri šípke „T“ (zmizne 1,5 s po zmene) |
| z9 | EXT šípka: obrys z bitmapy (symetrický), E vycentrované |
| a0 | Roll s HW spracovaním FPGA: Peak/Pro/Auto/Sin x → peak detect (0x56 bit 1), Linear/Dots/Hi-Res → boxcar (0x53 = 1, 0x54 shift); 2 × wpc slov na stĺpec |
| a1 | HW Hi-Res v normálnom režime (boxcar pri Trace Hi-Res, ≥ 2 vzorky/pixel, < 200 MSa/s), T v šípke o riadok vyššie, čítanie REF súboru len 16380 B |
| a2 | I2C dekodér etapa 1 (popisky, prepínač v menu kanála na mieste po „Open FFT“, List) |
| a3 | Okno dekodéra (prah Auto/Manual po 50 mV, 7/10 bit, HEX/DEC), Settings > Measure > Decoder, spoľahlivejší START/STOP (SCL nad prahom ±2 vzorky) |
| a4 | List ako tabuľka (#, Time, Event, Value, Ack, Info), ACK/NACK slovom farebne, posúvanie prstom, DS3231M v Info |
| a5–a6 | Formát Addr / Data zvlášť (HEX/DEC/BIN), tlačidlá vpravo pod Close vo farbách, HEX s 0x |
| a7 | Výber obvodu (Chip), 24Cxx EEPROM |
| a8 | Obvody zo SD `\i2c_chips\*.txt` (parser, vstavané DS3231M a 24C32/64 ako záloha) |
| a9 | Čísla riadkov v okne Chip |
| b0 | Záložky kategórií v okne Chip (CAT), ADDR2, 35 obvodov |
| b1 | Dekodéry UART a SPI |
| b2 | Dekodéry 1-Wire a LIN, Swap kanálov, okno pre 5 protokolov (farby, ON/OFF, centrované texty, List modrý / Close červený), „Decode“ v rámčeku, okno sa otvorí po zapnutí, stránka dekodéra v CTRL, Settings > Decoder len štartové položky |
| b3 | CTRL: V+/V- 46 px, pásik kanála 20 px (CH1 y 152, CH2 y 292), tlačidlá Decoder/List na stránke V/div pod CTRL (y 59/105, výška 42), samostatná stránka dekodéra vypnutá; okno: protokoly v stĺpci vpravo pod ON/OFF, Swap vľavo od ON/OFF, popisky bližšie (tlačidlá od x 100), šípky Left/Right_icon namiesto -/+, HEX/DEC aj pre UART a SPI, List/Close nižšie (y 368); v Liste texty tlačidiel Close/Addr/Data/Chip vycentrované |
| b4 | Okno: čiara pod horným riadkom, protokoly v rámčeku, OFF biele na červenom, Auto 50 % zelené, HEX/DEC vlastné farby, baud v oválnom rámčeku (ťuk = posuvný zoznam `dec_pick`), LIN Version Auto/1.x/2.x (117 bity 15..14, `lin_sum_want`); CTRL tlačidlo „Decode“ + „I2C on“ vo farbe protokolu (`scope_dec_color`); Chip podľa mena (`i2cd_chosen`, slová 232–245, `DEC_CHIPNAME_OFFSET`); 1-Wire CRC8 (ROM, Read scratchpad; flags 2 zlé / 4 dobré, `chk`); LIN „should be“; List: Next NACK/error (žltý rámik), Save do `\decoder\PROTO[_CHIP]_NNN.txt` (hlavička + CSV), Load (výber súboru, zobrazenie v stĺpcoch) |
| b5 | Baud rámček s rohmi 3 px, šírka 76 (UART) / 60 (LIN); okno Chip: 8 záložiek + Close v jednom riadku (krok 82, texty na stred, Close červené); List: pravý stĺpec na tmavom paneli s čiarou (x 718), tlačidlá 70 × 44 tmavé s farebným okrajom (`i2ct_pbutton`, Close `i2ct_close_button`), horný riadok v rámčeku (`i2ct_frame`); CTRL: Decode/List 40 px (y 62/109), CH1 y 156, CH2 y 294, 50% TRIG 46 px (y 427) |
| b6 | Popisky nad stopou vo formáte Listu (`dec_label_text`, HEX s 0x/DEC/BIN; okno Values = HEX/DEC/BIN nastaví Addr aj Data), pri hustých popiskoch každý druhý (aj S/P) o 18 px vyššie; Settings > Measure > Decoder „CTRL Decode button switches on“ (`scope_dec_btn_on`, slovo 119 bit 5, OS_I2CDEC); Show grid / Next page / END cal 46 px; Decode a vypínač z menu kanálov odstránené (riadok prázdny); List: ťuk na riadok posunie stopu na čas udalosti (`i2ct_jump`, List aj okno sa zavrú), Filter (All / NACK-chyby / TX / RX / adresa I2C, `i2ct_filter_pick`), Load: Delete s druhým ťukom |
| b7 | Popisky: rámček široký podľa textu (centrovaný na bajt), keď by prekryl predchádzajúci v riadku, ostane úzky bez textu; pri hustých popiskoch celý paket (I2C S..P, SPI rámec, 1-Wire od RESET, LIN od BREAK, UART bajt) v jednom riadku, ďalší paket v druhom (`dec_ev_packet_start`) |
| b8 | Save: `PROTO[_CHIP]_RRRRMMDD_HHMMSS.txt` pri zapnutých hodinách (`onoffRTC`, čas z DS3231), inak `_NNN`; obvod aj pri Chip Auto, ak adresy patria jednému obvodu (`dec_file_chip`); I2C trigger v okne (Off / NACK / adresa, `scope_dec_trig`, slovo 246) – pri nájdení v RUN prepne na STOP (`scope_dec_trigger_after` na konci `scope_display_trace_data`); List: štatistika NACK/chyby + odmeraný baud (`dec_measure_baud`), ťuk = označí riadok, druhý ťuk na iný riadok = dt, ťuk na označený = posun stopy; okno: Auto baud (UART/LIN, najbližšia hodnota zo zoznamu) |
| b9 | Bez červenej: chyby nad stopou ako žltý rožok v rámčeku (text biely, o 1 px nižšie = vycentrovaný), P svetlo oranžové, RESET bez presence žltý; v Liste chyby žlté (`DEC_ERR_COLOR`); normálny NACK po poslednom čítanom bajte pred P/Sr (`dec_i2c_nack_normal`, v Liste flags 0x40/0x80) nie je chyba (sivý v Liste, nepočíta sa do štatistiky, Next, filtra ani triggera); husté popisky: keď sa zvolený formát nevojde, HEX s 0x, potom bez 0x; filter Listu ostáva medzi otvoreniami |
| c0 | NACK znova vo filtri, Next NACK a počte (`dec_ev_error` = každý NACK); normálny NACK na konci čítania žltý (List aj rožok nad stopou), skutočné chyby červené (rožok, List, RESET bez presence), text nad stopou biely; P/STOP oranžové; BIN vždy ako BIN: rámček široký podľa textu, keď prekryje predchádzajúci, ide do ďalšieho voľného riadku (spolu 4 riadky, `DEC_ROWS`); trigger NACK ignoruje normálny NACK |
| c1 | Značka chyby/NACK nad stopou ako blok 6 × 10 px (veľkosť číslice) vpravo v rámčeku, rámček o 8 px širší, text centrovaný vľavo od nej |

## 3. Stav dekodéra (v1.01b2)

**Ovládanie**
- Menu kanála: riadok „Decode“ + názov protokolu v rámčeku (`scope_channel_i2c_select`, menu.c). Prepínač vpravo = ON/OFF
  (po zapnutí sa otvorí okno), ťuk na text = okno (`scope_i2c_settings_window`). V roll/spektre/Bode stlmené (`chmenu_blocked(CHI_FFT)`).
- CTRL v pravom paneli: hlavné → V/div → **stránka dekodéra** (`RIGHT_MENU_DECODER` = 5, menu.h) → hlavné. Tlačidlá
  Decoder (y 63, otvorí okno) a List (y 121). V spektre/Bode sa stránka preskočí.
- Okno (x 160, y 30, 480 × 420): ON/OFF, protokoly I2C/UART/SPI/1-Wire/LIN (farby `dec_colors`), Swap, Threshold
  Auto 50 % / Manual (CH1/CH2 v mV, ±50 mV), dva riadky podľa protokolu, List, Close.
- Popisky nad stopou (`scope_i2c_display`, volané v `scope_display_trace_data` po REF/MATH). Krátky ťuk na pásik popisiek
  otvorí List (`scope_i2c_tap`, pred `scope_adjust_timebase_and_voltdiv`).
- List (`scope_i2c_list`, `i2ct_draw`): tabuľka, ťahanie prstom, posuvník, vpravo Close, Addr (len I2C), Data, Chip (len I2C).
- Settings > Measure > Decoder: „Decoder on at start“, „Protocol at start“ (Last/…), „Threshold Auto 50 % at start“.

**Protokoly** (všetky v `test.c`, dekódujú zobrazený záznam `tracebuffer`, aj uložený wave)
- I2C (`i2c_decode`): SDA CH1, SCL CH2 (Swap prehodí). 7/10 bit, Info podľa obvodov (`i2ct_annotate`).
- UART (`uart_decode`): TX CH1, RX CH2, baud `uart_bauds` (300 … 2 000 000), 7/8 bit, parita N/E/O, 1/2 stop, Norm/Inv; ≥ 3 vzorky/bit.
- SPI (`spi_decode`): SCLK CH1, dáta CH2, bez CS (rámec končí pri medzere > 4 bežné periódy), mód 0–3, MSB/LSB, 8/16 bit.
- 1-Wire (`ow_decode`): linka CH1, RESET ≥ 480 µs (+ presence), bit 1 < 15 µs, Standard/Overdrive, Info `ow_annotate` (ROM/DS18B20).
- LIN (`lin_decode`): linka CH1, BREAK ≥ 11 bitov, SYNC/PID (parita)/DATA/CHECK (classic/enhanced), baud `lin_bauds`.
- Spoločné: `dec_decode()` vyberie protokol; udalosti `I2CEVENT i2c_ev[600]` (typy I2C 0–3, UART 4, SPI 5–6,
  1-Wire 7–8, LIN 9–10; polia line, flags, v16, a10, addr); digitalizácia `dec_digital` (hysteréza ±1/6 alebo manuálny prah).
- Overené na PC (umelé signály): UART, SPI, 1-Wire, LIN; I2C Dusan overil na prístroji s DS3231M (v1.01a2 ukazoval len
  adresy; v1.01a3 opravené falošné STOP, Dusan potom písal „zdá sa, že to funguje“).

**Obvody na SD `\i2c_chips\`** (zdroj v projekte `fnirsi_1013d_scope/i2c_chips/`, 35 súborov + README.txt; Dusan ich kopíruje sám)
- Kľúče: NAME, SHORT (≤ 7), CAT (RTC, Memory, Sensors, Converters, I/O, Power, Display), ADDR (napr. 50-57), ADDR2,
  AUTO, REGADDR (0/1/2), BLOCKBITS, MEMORY, REGSIZE (1/2), AUTOINC, LAST, DATA=meno,typ, REG=reg,meno,typ,extra.
- Typy: HEX (maska), DEC, SDEC (jednotka), BCD (maska), BIN, BITS (mená bitov 7..0), FRAC2.
- Parser `i2cd_parse`, načítanie `scope_i2c_load_chips` pri každom otvorení Listu, max 48 obvodov, 64 registrov,
  zoradené podľa NAME. Auto: z AUTO=1 vyhrá najužší rozsah. Bez priečinka vstavané DS3231M a 24C32/64.

**Uložené nastavenia** (`settingsworkbuffer`, OTHER_SETTING_OFFSET = 80)
- 110 roll Memory, 111 Start in last view, 112 last view, 113 maska roll REF sady
- 114 `scope_i2c_settings_word`: bit 0 on, 1 manuálny prah, 2 10-bit, 3 DEC, 5..4 formát Addr, 7..6 formát Data, 13..8 Chip
- 115 / 116 prahy CH1 / CH2 v mV (0 = 1650)
- 117 `scope_dec_settings_word`: 1..0 + 11 protokol, 2 UART 7 bit, 4..3 parita, 5 2 stop, 6 Inv, 8..7 SPI mód, 9 LSB, 10 16 bit, 12 Swap, 13 1-Wire overdrive
- 118 UART baud index + 1
- 119 `scope_dec_start_word`: 0 on pri štarte, 3..1 protokol pri štarte (0 Last), 4 Auto prah pri štarte, 11..8 LIN baud + 1
- Cursor sekcia: 134 bodehint_off, 135 tapvdiv_off; FPGA sekcia: 206 adc_capsel.
- Pozor: OTHER sekcia má 40 slov (80–119), **je plná**. Ďalšie nastavenia treba dať inam (232–245 meno obvodu od b4, 246 trigger dekodéra od b8, voľné od 247).

## 4. Roll, REF, trigger (z5–a1) – dôležité miesta

- `test.c`: `scope_roll_logger_pass` (nová s HW oknom; stará v `#if 0`), `roll_draw_record`, `scope_roll_measurements`,
  `scope_roll_trace_mode`, `scope_roll_ref_copy`, `scope_refset_*`, `scope_roll_ref_moved`.
- `fpga_control.c`: `fpga_logger_start(divider, hw)` (FLOG_SKIP/PEAK/BOXCAR), `fpga_logger_window/shift`, HW Hi-Res
  (`fpga_hw_hires_*`, `fpga_read_hires_data`), EXT (`fpga_set_trigger_channel`, `fpga_ext_trigger_on`).
- `scope_functions.c`: `scope_draw_pointers` (EXT šípka, napätie triggera, `scope_trigger_text_tick`), `view_path_info`
  (`\ref_roll\`), HW Hi-Res tagy.

## 5. Otvorené / neoverené

- Na prístroji neoverené: takmer všetko od z5 (roll merania/Peak/REF, EXT trigger, HW peak/boxcar v roll, HW Hi-Res,
  UART/SPI/1-Wire/LIN, okno v1.01b2, stránka CTRL, Settings štart).
- **Predpoklad dĺžky slova pri FPGA okne** (roll a0, HW Hi-Res a1): slovo s oknom = čas 2 vzoriek → 2 × wpc slov na
  stĺpec. Ak sa roll/Hi-Res na prístroji časovo natiahne alebo stlačí 2×, je to tento predpoklad (jeden riadok).
- FPGA AL3 0x3050: Dusanov test ADC check 0xF7 (sticky bit 0, piny OK), timing CH1 0 0 0 0, CH2 13 39 38 38. Návrh testov
  poslaný (kalibrácia bez sond 2×, ADC check po štarte, CH2 pri 200 MSa/s, porovnanie s EF2). Možné riešenie v FPGA
  (skorší stupeň pre CH2 alebo fáza enkódu). Čaká na Dusanove výsledky.
- Popisky nad stopou bez „0x“ (Dusan nerozhodol).
- Voľba Chip sa ukladá ako poradové číslo (zmení sa pri pridaní súborov na SD).
- REF súbor pri načítaní prepíše v REF aj ukazovatele tracebuffer/tracepoints (staré správanie, nemenené).
- Ďalšie možné dekodéry / nápady: CAN, I2S, Manchester, dekódovanie Search ROM pri 1-Wire, 1-Wire CRC kontrola,
  SPI s CS na druhom kanáli nie je možné (2 kanály).
- Presun kódu dekodéra z `test.c` do vlastného `.c` (len so zatvoreným NetBeans).
