//----------------------------------------------------------------------------------------------------------------------------------
#include "types.h"
#include "menu.h"
#include "test.h"
#include "scope_functions.h"
#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "spi_control.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "DS3231.h"

#include "usb_interface.h"
#include "variables.h"

#include "sin_cos_math.h"
#include "ref_and_math.h"     //v1.00z7

//sinx
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//endsinx

  #include <stdint.h>
#include <stddef.h>  // Pre definíciu size_t

#include <string.h>
//----------------------------------------------------------------------------------------------------------------------------------
/*
  //Check if in waveform view
  if(scopesettings.waveviewmode)
  {
    //Display the file name
    //Use white text and font_0
    display_set_fg_color(WHITE_COLOR);
    display_set_font(&font_0);
    
    if(onoffRTC) //if RTCon view rtc info
      {
      thumbnaildata = &viewthumbnaildata[viewcurrentindex];
      decodethumbnailfilename(thumbnaildata->filename);
      display_text(488, 70, filenameRTC);   //500 48 , 490 58
      }   else display_text(555, 70, viewfilename); //550 48
  }
  */

//----------------------------------------------------------------------------------------------------------------------------------
 
#include "ff.h"
#include "stdint.h"

// --- Constants defining file structure ---
#define SETTINGS_SIZE   0x320   // 800 bytes for settings
#define CH1_START       0x320
#define CH2_START       0xED8
#define CH_SAMPLES      3000

// --- Read 32-bit little-endian value ---
static uint32_t read_le32(const uint8_t *p)
{
    return (uint32_t)p[0]
         | ((uint32_t)p[1] << 8)
         | ((uint32_t)p[2] << 16)
         | ((uint32_t)p[3] << 24);
}

// --- Write text to file (no stdlib) ---
static void write_text(FIL *fp, const char *txt)
{
    UINT bw;
    uint32_t len = 0;
    const char *p = txt;
    while (*p++) len++;
    f_write(fp, txt, len, &bw);
}

// --- Write unsigned integer as ASCII ---
static void write_uint(FIL *fp, uint32_t value)
{
    char buf[12];
    char *p = buf + 11;
    *p = 0;
    if (value == 0)
    {
        *(--p) = '0';
    }
    else
    {
        while (value && p > buf)
        {
            *(--p) = '0' + (value % 10);
            value /= 10;
        }
    }
    write_text(fp, p);
}

/*
 * Convert all waveform files (*.wav) from folder "waveforms"
 * into CSV files stored in folder "cvs_format".
 * No standard C library functions are used.
 */
FRESULT convert_waveforms_to_csv_excel(void)
{
    DIR dir;
    FIL file_in, file_out;
    FILINFO fno;
    FRESULT fr;
    UINT br, bw;
    BYTE header[SETTINGS_SIZE];
    BYTE ch1[CH_SAMPLES];
    BYTE ch2[CH_SAMPLES];

    const char *path_in  = "waveforms";
    const char *path_out = "cvs_format";

    // Create output folder if not present
    f_mkdir(path_out);

    fr = f_opendir(&dir, path_in);
    if (fr != FR_OK)
        return fr;

    // Read all files from "waveforms"
    while (1)
    {
        fr = f_readdir(&dir, &fno);
        if (fr != FR_OK || fno.fname[0] == 0)
            break;
        if (fno.fattrib & AM_DIR)
            continue;

        // Check for ".wav" extension
        char *name = fno.fname;
        int len = 0;
        while (name[len])
            len++;
        if (len < 4)
            continue;
        if (!(name[len - 4] == '.' && name[len - 3] == 'w' &&
              name[len - 2] == 'a' && name[len - 1] == 'v'))
            continue;

        // Build full paths
        char in_path[64];
        char out_path[64];
        int i = 0, j = 0;

        // in_path = "waveforms/" + filename
        while (path_in[i])
        {
            in_path[i] = path_in[i];
            i++;
        }
        in_path[i++] = '/';
        while (name[j] && i < 63)
            in_path[i++] = name[j++];
        in_path[i] = 0;

        // out_path = "cvs_format/" + filename with ".csv"
        i = 0;
        while (path_out[i])
        {
            out_path[i] = path_out[i];
            i++;
        }
        out_path[i++] = '/';
        j = 0;
        while (name[j] && i < 59)
        {
            if (name[j] == '.')
            {
                out_path[i++] = 'c';
                out_path[i++] = 's';
                out_path[i++] = 'v';
                out_path[i] = 0;
                break;
            }
            out_path[i++] = name[j++];
        }

        // --- Read waveform file ---
        fr = f_open(&file_in, in_path, FA_READ);
        if (fr != FR_OK)
            continue;

        f_read(&file_in, header, SETTINGS_SIZE, &br);
        f_lseek(&file_in, CH1_START);
        f_read(&file_in, ch1, CH_SAMPLES, &br);
        f_read(&file_in, ch2, CH_SAMPLES, &br);
        f_close(&file_in);

        // Extract some settings
        uint32_t volt_div_ch1 = read_le32(&header[36]);
        uint32_t volt_div_ch2 = read_le32(&header[132]);
        uint32_t sample_rate  = read_le32(&header[228]);
        uint32_t time_div     = read_le32(&header[224]);
        uint32_t trig_ch      = read_le32(&header[240]);
        uint32_t trig_level   = read_le32(&header[244]);
        uint32_t trig_mode    = read_le32(&header[232]);
        uint32_t trig_edge    = read_le32(&header[236]);

        // --- Create CSV file ---
        fr = f_open(&file_out, out_path, FA_WRITE | FA_CREATE_ALWAYS);
        if (fr != FR_OK)
            continue;

        // UTF-8 BOM
        const BYTE bom[3] = {0xEF, 0xBB, 0xBF};
        f_write(&file_out, bom, 3, &bw);

        // Metadata
        write_text(&file_out, "# FNIRSI 1013D waveform export\n");
        write_text(&file_out, "# File name; ");
        write_text(&file_out, name);
        write_text(&file_out, "\n# Sample rate; ");
        write_uint(&file_out, sample_rate);
        write_text(&file_out, " Hz\n# Time per division; ");
        write_uint(&file_out, time_div);
        write_text(&file_out, "\n# Volt/div CH1; ");
        write_uint(&file_out, volt_div_ch1);
        write_text(&file_out, "\n# Volt/div CH2; ");
        write_uint(&file_out, volt_div_ch2);
        write_text(&file_out, "\n# Trigger channel; ");
        write_uint(&file_out, trig_ch);
        write_text(&file_out, "\n# Trigger level; ");
        write_uint(&file_out, trig_level);
        write_text(&file_out, "\n# Trigger mode; ");
        write_uint(&file_out, trig_mode);
        write_text(&file_out, "\n# Trigger edge; ");
        write_uint(&file_out, trig_edge);
        write_text(&file_out, "\n#---------------------------------------------\n");
        write_text(&file_out, "Index;CH1;CH2\n");

        // Write channel data
        for (int k = 0; k < CH_SAMPLES; k++)
        {
            write_uint(&file_out, k);
            write_text(&file_out, ";");
            write_uint(&file_out, ch1[k]);
            write_text(&file_out, ";");
            write_uint(&file_out, ch2[k]);
            write_text(&file_out, "\n");
        }

        f_close(&file_out);
    }

    f_closedir(&dir);
    return FR_OK;
}

//----------------------------------------------------------------------------------------------------------------------------------
//skusit vyuzit aj na long base, pri stopnuti priebehu
int32 scope_load_REFx_trace_dataxxx(void)
{
  //Point to the file numbers
  uint16 *fnptr = (uint16 *)viewfilenumberdata;
  uint32 result;

  //Setup the file name for this view item
  scope_print_file_name(fnptr[viewcurrentindex]);

  //Try to open the file for reading
  result = f_open(&viewfp, viewfilename, FA_READ);

  //Check if file opened ok
  if(result == FR_OK)
  {
    //Checks on correct number of bytes read might be needed
    //Load the setup data to the file setup data buffer
    if((result = f_read(&viewfp, (uint8 *)viewfilesetupdata, sizeof(viewfilesetupdata), 0)) == FR_OK)
    {
      //Copy the loaded data to the settings
      scope_restore_setup_from_file();

      //Check if the version of the file is wrong
      if(viewfilesetupdata[1] != WAVEFORM_FILE_VERSION)
      {
        //No need to load the rest of the data
        result = WAVEFORM_FILE_ERROR;

        //Show the user the file is not correct
        scope_display_file_status_message(MESSAGE_WAV_VERSION_MISMATCH, 0);
      }
      else
      {
        //Load the channel 1 sample data      
        if((result = f_read(&viewfp, (uint8 *)channel1tracebuffer, 3000, 0)) == FR_OK)
        {
          //Load the channel 2 sample data
          if((result = f_read(&viewfp, (uint8 *)channel2tracebuffer, 3000, 0)) == FR_OK)
          {
            //Do a check on file validity
            if((result = scope_check_waveform_file()) == 0)
            {
              //Switch to stopped and waveform viewing mode
              scopesettings.runstate = 0;//ok
              scopesettings.waveviewmode = 1;

              //Show the normal scope screen
              scope_setup_main_screen();

              //display the trace data
              scope_display_trace_data();
            }
            else
            {
              //Checksum error so signal that to the user
              result = WAVEFORM_FILE_ERROR;

              //Show the user the file is not correct
              scope_display_file_status_message(MESSAGE_WAV_CHECKSUM_ERROR, 0);
            }
          }
        }
      }
    }

    //Done with the file so close it
    f_close(&viewfp);

    //Check if one of the reads failed
    if((result != FR_OK) && (result != WAVEFORM_FILE_ERROR))
    {
      //Signal unable to write to the file
      scope_display_file_status_message(MESSAGE_FILE_READ_FAILED, 0);
    }
  }
  else
  {
    //Signal unable to open the file
    scope_display_file_status_message(MESSAGE_FILE_OPEN_FAILED, 0);
  }

  //Check if all went well
  if(result == FR_OK)
  {
    //Tell it to the caller
    return(VIEW_TRACE_LOAD_OK);
  }

  //Remove the current item from the thumbnails and delete the item from disk
  scope_remove_item_from_thumbnails(1);

  //Save the thumbnail file
  scope_save_thumbnail_file();

  return(VIEW_TRACE_LOAD_ERROR);
}

//----------------------------------------------------------------------------------------------------------------------------------


  //if (method == 'Sinc') { y = sincInterpolate(waveArray, tGlobal);}
                    
                
		// Sinc Interpolation with Lanczos window
/*          void sincInterpolate(points, t, a = 6) {
            int32 sum = 0;
            const start = math.max(0, Math.floor(t - a));
            const end = Math.min(points.length - 1, Math.ceil(t + a));
            
            for (int32 i = start; i <= end; i++) {
                const x = i - t;
                // Apply Sinc kernel with Lanczos window
                const sincValue = sincKernel(x);
                const windowValue = lanczosWindow(x, a);
                sum += points[i] * sincValue * windowValue;
            }
            
            return sum;
        }

        function sincKernel(x) {
            if (x == 0) return 1;
            return Math.sin(Math.PI * x) / (Math.PI * x);
        }

        function lanczosWindow(x, a) {
            if (Math.abs(x) >= a) return 0;
            return sincKernel(x / a); // Sinc function scaled by the window size
        }
*/

void display_text_message(char* message, uint8 value) {
    display_set_fg_color(BLACK_COLOR);
    display_fill_rect(488, 420, 250, 50); // Vyčistí priestor na zobrazenie textu

    // Nastavenie farby textu a fontu
    display_set_fg_color(WHITE_COLOR);
    display_set_font(&font_0);

    // Zobrazenie textu
    display_text(488, 440, message);
    display_decimal(600, 440, value);
    display_text(495, 455, viewfilename);

    timer0_delay(3000); // Počká 3 sekundy
}



/*

// Function to compute the value of sin(x)/x for sinc interpolation
double sinc(double x) {
    if (x == 0) {
        return 1.0;
    } else {
        return sin(PI * x) / (PI * x);
    }
}

// Function to perform sinc interpolation
void sinc_interpolation(double* t_interp, double* t_sampled, int* sampled_signal, int* sincpole, int size) {
    for (int i = 0; i < size; i++) {
        sincpole[i] = 0;  // Initialize the interpolated signal
        for (int j = 0; j < size; j++) {
            double sinc_value = sinc((t_interp[i] - t_sampled[j]) / (t_sampled[1] - t_sampled[0]));
            sincpole[i] += sampled_signal[j] * sinc_value;
        }
        // Clip the interpolated value to the range [0, 400] and convert to integer
        if (sincpole[i] < 0) {
            sincpole[i] = 0;
        } else if (sincpole[i] > 400) {
            sincpole[i] = 400;
        }
    }
}
*/
// Funkcia na výpočet pohyblivého priemeru (SMA) s oknom window_size
void moving_average(uint8* input, size_t size, size_t window_size) {
    uint32 sum = 0;  // Použijeme väčší dátový typ pre súčet
    size_t half_window = window_size / 2;
    uint8_t temp[size];  // Dočasné pole pre uloženie výsledkov

    // Vypočítanie priemeru pre každú vzorku signálu
    for (size_t i = 0; i < size; i++) {
        sum = 0;
        size_t count = 0;

        // Vypočíta priemer v okne okolo aktuálneho bodu
        for (int j = -half_window; j <= (int)half_window; j++) {
            if ((i + j) >= 0 && (i + j) < size) {
                sum += input[i + j];
                count++;
            }
        }

        // Uloženie výsledku priemeru do dočasného poľa
        temp[i] = sum / count;
    }

    // Skopírovanie výsledku späť do pôvodného input poľa
    for (size_t i = 0; i < size; i++) {
        input[i] = temp[i];
    }
}

//-------------------------------------------------------------------------------
// Funkcia na výpočet exponenciálneho kĺzavého priemeru (EMA)
void exponential_moving_average(uint8_t* input, size_t size, double alpha) {
    double ema = input[0];  // Inicializácia s prvou vzorkou

    // Iterácia cez všetky vzorky
    for (size_t i = 1; i < size; i++) {
        ema = alpha * input[i] + (1 - alpha) * ema;
        input[i] = (uint8_t)ema;  // Uloženie výsledku priamo späť do input poľa
    }
}

//-------------------------------------------------------------------------------
// Funkcia na filtrovanie signálu pomocou FIR filtra
void fir_filter(uint8_t* input, size_t size) {
    // FIR koeficienty pre dolnopriepustný filter (koeficienty je potrebné vypočítať pre cutoff 49 MHz)
double fir_coeffs[] = {
    -0.001288, -0.000300, 0.001836, 0.000676, -0.003386, -0.001576, 0.006156, 0.003345, -0.010409, -0.006472, 0.016563, 0.011743, -0.025481, -0.020732, 0.039401, 0.037612, -0.066018, -0.079762, 0.155080, 0.443010, 0.443010, 0.155080, -0.079762, -0.066018, 0.037612, 0.039401, -0.020732, -0.025481, 0.011743, 0.016563, -0.006472, -0.010409, 0.003345, 0.006156, -0.001576, -0.003386, 0.000676, 0.001836, -0.000300, -0.001288 // Odraz koeficientov
};

    uint8_t output[MAX_SAMPLE_BUFFER_SIZE]; // Poľe pre filtrovaný signál

    for (size_t n = 0; n < size; n++) {
        double sum = 0.0;
        // Vypočítajte hodnotu pre aktuálny výstup
        for (size_t k = 0; k < FIR_ORDER; k++) {
            if (n >= k) {  // Zabezpečte, že index nie je mimo rozsah
                sum += fir_coeffs[k] * input[n - k];
            }
        }
        output[n] = (uint8_t)sum; // Uložte hodnotu do output poľa
    }

    // Uloženie filtrovaného signálu späť do input poľa (scopesettings.channel1.tracebuffer)
    for (size_t i = 0; i < size; i++) {
        input[i] = output[i]; // Uloženie filtrovaných hodnôt do pôvodného poľa
    }
}

//--------------------------------------------------------------------------------
// Funkcia na filtrovanie zmien v rozsahu 1 až 2 bity
void filter_bit_changes(uint8_t* input, size_t size) {
    for (size_t i = 1; i < size; i++) {
        // Zistíme rozdiel medzi aktuálnou a predchádzajúcou hodnotou
        int16_t difference = (int16_t)input[i] - (int16_t)input[i - 1];

        // Ak je zmena v rozsahu 1 až 2 bity, nastavíme aktuálnu hodnotu na predchádzajúcu
        if (difference >= 1 && difference <= 2) {
            input[i] = input[i - 1];
        } else if (difference <= -1 && difference >= -2) {
            input[i] = input[i - 1];
        }
    }
}
//-----------------------------------------------------------------------------

// Funkcia na pridanie 1 bitu k hodnotám signálu
void add_one_bit(uint8_t* input, size_t size) {
    for (size_t i = 0; i < size; i++) {
        input[i] += 0x01; // Pridajte 1 bit k hodnote
    }
}

//-----------------------------------------------------------------------
// Funkcia na výpočet priemeru v okne
void average_filter(uint8_t* input, size_t size, size_t window_size) {
    if (window_size % 2 == 0) {
        window_size++; // Zabezpečte, že okno je nepárne
    }

    uint32_t sum = 0;  // Používame väčší dátový typ pre súčet
    size_t half_window = window_size / 2;
    uint8_t temp[MAX_SAMPLE_BUFFER_SIZE];  // Dočasné pole pre uloženie výsledkov

    // Pre každý vzor
    for (size_t i = 0; i < size; i++) {
        sum = 0;
        size_t count = 0;

        // Vypočítanie priemeru v okne okolo aktuálneho bodu
        for (int j = -half_window; j <= (int)half_window; j++) {
            size_t index = i + j;

            // Zabezpečte, že index je v rámci povoleného rozsahu
            if (index < size && index >= 0) {
                sum += input[index];
                count++;
            }
        }

        // Uloženie výsledku priemeru do dočasného poľa
        temp[i] = sum / count; // Uložte ako uint8_t
    }

    // Skopírovanie výsledku späť do pôvodného input poľa
    for (size_t i = 0; i < size; i++) {
        input[i] = temp[i];
    }
}

/*
void scope_preset_long_mode(void)
{
 * 
 
display_fill_rect(740,  83, 50, 15);//99
display_fill_rect(740, 248, 50, 15);//264
//Black color for inactive button
display_set_fg_color(BLACK_COLOR);

display_set_font(&font_2);
display_decimal(740, 83, sampleAVG);

}
*/

//----------------------------------------------------------------------------------------------------------------------------------
//ROLL MODE
void scope_get_long_timebase_data1(void)
{
  //Default timeout for 50S/div
  uint32    timeout = 1000;
  uint32    curticks;

  
  if((scopesettings.runstate)&&(!triggerlong)&&(scopesettings.triggermode))
        {scope_check_long_trigger();}
  
  //Check if run or stop mode - 1-Run mode
  if((scopesettings.runstate)&&(triggerlong))
  {
      
    //Get the delay setting based on the time base
    switch(scopesettings.timeperdiv)
    {
    //50S/div
    case 0:
      timeout = 1000;
      break;
    //20S/div
    case 1:
      timeout = 400;
      break;

    //10S/div
    case 2:
      timeout = 200;
      break;

    //5S/div
    case 3:
      timeout = 100;
      break;

    //2S/div
    case 4:
      timeout = 40;
      break;

    //1S/div
    case 5:
      timeout = 20;
      break;

    //500mS/div
    case 6:
      timeout = 10;
      break;

    //200mS/div
    case 7:
      timeout = 4;
      break;

    //100mS/div
    case 8:
      timeout = 2;
      break;
      
    default:
        break;      
    }
  
    //Make the timeout timer tick related by adding it to the previous capture
    //timeout += scopesettings.previoustimerticks;
    timeout += previoustimerticks;
  
    //For smaller timeouts (500mS/div, 200mS/div and 100mS/div) stay in the wait loop even if there is touch
    //while((scopesettings.timeperdiv > 5) || (havetouch == 0))
    while((havetouch == 0))
    {
        //Get the current ticks
        curticks = timer0_get_ticks();
  
        //Check if there is a timeout
        //While technically prone to error on timer ticks overflow the scope has to be running for >49 days before it occurs
        if(curticks >= timeout)
        {
            //Save the current ticks for next timeout and bail out the loop
            //scopesettings.previoustimerticks = curticks;
            previoustimerticks = curticks;
            goto skip_delay;
        }
    
        //Scan the touch panel to see if there is user input
        tp_i2c_read_status();
    }
    
  //Wait an extra 40 milliseconds when there was touch
    timer0_delay(30);
  
    skip_delay:
/*
      //flag signal is triggered=1 for auto mode
    if ( scopesettings.count >2998) //2998
    {   
        //single mode trigger
        if(scopesettings.triggermode == 1) 
        {   //stop scope
            scopesettings.runstate = 0;//ok
            //Show this on the screen
            scope_run_stop_text();
  
            //Check in which state the right menu is in, Button back to inactive state
            if(scopesettings.rightmenustate == 0) scope_run_stop_button(0);
        
            triggerlong = 0;
        }
        //auto mode trigger
        if(scopesettings.triggermode == 2) scope_preset_values();
    }
    
    if ( scopesettings.count > 2999)   //2999 
    {   scopesettings.count = 0;      //reset buffer pointer 
    
        //Draw the grid lines and dots based on the grid brightness setting
        scope_draw_grid();
    
        //Draw the signal center, trigger level and trigger position pointers
        scope_draw_pointers();
        //disp_first_sample = 0;
    }
*/
        //Use a separate buffer to clear the screen
        display_set_screen_buffer(displaybuffertmp);//1

        //Clear the trace portion of the screen
        display_set_fg_color(BLACK_COLOR);
        display_fill_rect(0, 48, 730, 403); //432  403
        /*
        
            //Check channel 1 is enabled
    if(scopesettings.channel1.enable) 
    {    
        //Set CH1 display trace color 
        //display_set_fg_color(CHANNEL1_COLOR);
        //Clear the trace portion of the screen
        display_set_fg_color(BLACK_COLOR);
        
        for (scopesettings.xpos=scopesettings.lastx; scopesettings.xpos<727; scopesettings.xpos++)
        {
          //Get the sample CH1
          scopesettings.channel1.sample1 = scope_get_y_sample(&scopesettings.channel1,  (scopesettings.xpos)); 

          //Draw the pixel 
          display_draw_pixel(scopesettings.xpos, scopesettings.channel1.sample1);
        }
        
    }
        
       */
    //Check channel 1 is enabled
    if(scopesettings.channel1.enable) 
    {
        for (uint32 i=0; i<726; i++)
          {
          scopesettings.channel1.tracebuffer[i]=scopesettings.channel1.tracebuffer[i+1];
          }
        //Read, accumulate and average 10 bytes of channel 1 trace data
        //scopesettings.count = 725;
        scopesettings.channel1.tracebuffer[726] = fpga_average_trace_data(&scopesettings.channel1);
    }
 /*   
    //Check channel 2 is enabled
    if(scopesettings.channel2.enable)   
        //Read, accumulate and average 10 bytes of channel 2 trace data
        scopesettings.channel2.tracebuffer[scopesettings.count] = fpga_average_trace_data(&scopesettings.channel2);
*/
     
    //Check channel 1 is enabled
    if(scopesettings.channel1.enable) 
    {    
        //Set CH1 display trace color 
        display_set_fg_color(CHANNEL1_COLOR);
        
        for (scopesettings.xpos=scopesettings.lastx; scopesettings.xpos<727; scopesettings.xpos++)
        {
          //Get the sample CH1
          scopesettings.channel1.sample1 = scope_get_y_sample(&scopesettings.channel1,  (scopesettings.xpos)); 

          //Draw the pixel 
          display_draw_pixel(scopesettings.xpos, scopesettings.channel1.sample1);
        }
        
    }
    /*    
    //Check channel 2 is enabled
    if(scopesettings.channel2.enable) 
    {
        //Get the sample CH2
        scopesettings.channel2.sample2 = scope_get_y_sample(&scopesettings.channel2,  scopesettings.count);
        
            //Set CH2 display trace color 
        display_set_fg_color(CHANNEL2_COLOR);
        //Draw the last line
        display_draw_line(scopesettings.lastx, scopesettings.channel2.sample1, scopesettings.xpos, scopesettings.channel2.sample2);
        scopesettings.channel2.sample1 =  scopesettings.channel2.sample2;
    }
    //------------------------------------------------------------------
 
    */

        //Check if not in waveform view mode (Scope mode) with grid disabled // treba ?
        if((!scopesettings.waveviewmode) || (scopesettings.gridenable))
        {
            //Draw the grid lines and dots based on the grid brightness setting
            scope_draw_grid();
        }
    
        //Draw the signal center, trigger level and trigger position pointers
        scope_draw_pointers();
    
        //Draw the cursors with their measurement displays
        scope_draw_time_cursors();
        scope_draw_volt_cursors();
        scope_display_cursor_measurements();
    
        //scopesettings.xpos = 4;
       
        if(scopesettings.lastx > 3) scopesettings.lastx--; //else scopesettings.lastx
    
    
        //Copy it to the actual screen buffer
        display_set_source_buffer(displaybuffertmp);//1
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        display_copy_rect_to_screen(0, 48, 730, 403); //432 403
      
        //-------------------------------------------------------
    
    //scopesettings.lastx =  scopesettings.xpos;  
    //scopesettings.xpos++;
    //scopesettings.count++;
    //disp_first_sample = scopesettings.count;
  
  } //end runstate
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_get_long_timebase_data(void)
{
  //Default timeout for 50S/div
  uint32    timeout = 1000;
  uint32    curticks;

  
  if((scopesettings.runstate)&&(!triggerlong)&&(scopesettings.triggermode))
        {scope_check_long_trigger();}
  
  //Check if run or stop mode - 1-Run mode
  if((scopesettings.runstate)&&(triggerlong))
  {
      
    //Get the delay setting based on the time base
    switch(scopesettings.timeperdiv)
    {
    //50S/div
    case 0:
      timeout = 1000;
      break;
    //20S/div
    case 1:
      timeout = 400;
      break;

    //10S/div
    case 2:
      timeout = 200;
      break;

    //5S/div
    case 3:
      timeout = 100;
      break;

    //2S/div
    case 4:
      timeout = 40;
      break;

    //1S/div
    case 5:
      timeout = 20;
      break;

    //500mS/div
    case 6:
      timeout = 10;
      break;

    //200mS/div
    case 7:
      timeout = 4;
      break;

    //100mS/div
    case 8:
      timeout = 2;
      break;
      
    default:
        break;      
    }
  
    //Make the timeout timer tick related by adding it to the previous capture
    //timeout += scopesettings.previoustimerticks;
    timeout += previoustimerticks;
  
    //For smaller timeouts (500mS/div, 200mS/div and 100mS/div) stay in the wait loop even if there is touch
    //while((scopesettings.timeperdiv > 5) || (havetouch == 0))
    while((havetouch == 0))
    {
        //Get the current ticks
        curticks = timer0_get_ticks();
  
        //Check if there is a timeout
        //While technically prone to error on timer ticks overflow the scope has to be running for >49 days before it occurs
        if(curticks >= timeout)
        {
            //Save the current ticks for next timeout and bail out the loop
            //scopesettings.previoustimerticks = curticks;
            previoustimerticks = curticks;
            goto skip_delay;
        }
    
        //Scan the touch panel to see if there is user input
        tp_i2c_read_status();
    }
    
  //Wait an extra 40 milliseconds when there was touch
    timer0_delay(30);
  
    skip_delay:

      //flag signal is triggered=1 for auto mode
    if ( scopesettings.count > (scopesettings.samplecount-2)) //2998
    {   
        //single mode trigger
        if(scopesettings.triggermode == 1) 
        {   //stop scope
            scopesettings.runstate = 0;//ok
            //Show this on the screen
            scope_run_stop_text();
  
            //Check in which state the right menu is in, Button back to inactive state
            if(scopesettings.rightmenustate == 0) scope_run_stop_button(0);
        
            triggerlong = 0;
        }
        //auto mode trigger
        if(scopesettings.triggermode == 2) scope_preset_values();
    }
    
    if ( scopesettings.count > (scopesettings.samplecount-1))   //2999 
    {   scopesettings.count = 0;      //reset buffer pointer 
    
        //Draw the grid lines and dots based on the grid brightness setting
        scope_draw_grid();
    
        //Draw the signal center, trigger level and trigger position pointers
        scope_draw_pointers();
        //disp_first_sample = 0;
    }

    //Check channel 1 is enabled
    if(scopesettings.channel1.enable) 
        //Read, accumulate and average 10 bytes of channel 1 trace data
        scopesettings.channel1.tracebuffer[scopesettings.count] = fpga_average_trace_data(&scopesettings.channel1);

    //Check channel 2 is enabled
    if(scopesettings.channel2.enable)   
        //Read, accumulate and average 10 bytes of channel 2 trace data
        scopesettings.channel2.tracebuffer[scopesettings.count] = fpga_average_trace_data(&scopesettings.channel2);


    if ( scopesettings.xpos >726) //725
    {
        //Use a separate buffer to clear the screen
        display_set_screen_buffer(displaybuffertmp);//1

        //Clear the trace portion of the screen
        display_set_fg_color(BLACK_COLOR);
        display_fill_rect(0, 48, 730, 432); //403
    

        //Check if not in waveform view mode (Scope mode) with grid disabled
        if((!scopesettings.waveviewmode) || (scopesettings.gridenable))
        {
            //Draw the grid lines and dots based on the grid brightness setting
            scope_draw_grid();
        }
    
        //Draw the signal center, trigger level and trigger position pointers
        scope_draw_pointers();
    
        //Draw the cursors with their measurement displays
        scope_draw_time_cursors();
        scope_draw_volt_cursors();
        scope_display_cursor_measurements();
    
        scopesettings.xpos = 4;
        scopesettings.lastx = 3;
    
    
        //Copy it to the actual screen buffer
        display_set_source_buffer(displaybuffertmp);//1
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        display_copy_rect_to_screen(0, 48, 730, 432); //403
        //display_copy_rect_to_screen(2, 44, 728, 434);       //opravit rozmery
    }
  
      
    //Check channel 1 is enabled
    if(scopesettings.channel1.enable) 
    {     
        //Get the sample CH1
        scopesettings.channel1.sample2 = scope_get_y_sample(&scopesettings.channel1,  scopesettings.count); 

        //Set CH1 display trace color 
        display_set_fg_color(CHANNEL1_COLOR);
        //Draw the line 
        display_draw_line(scopesettings.lastx, scopesettings.channel1.sample1, scopesettings.xpos, scopesettings.channel1.sample2);
        scopesettings.channel1.sample1 =  scopesettings.channel1.sample2;
    }
        
    //Check channel 2 is enabled
    if(scopesettings.channel2.enable) 
    {
        //Get the sample CH2
        scopesettings.channel2.sample2 = scope_get_y_sample(&scopesettings.channel2,  scopesettings.count);
        
            //Set CH2 display trace color 
        display_set_fg_color(CHANNEL2_COLOR);
        //Draw the last line
        display_draw_line(scopesettings.lastx, scopesettings.channel2.sample1, scopesettings.xpos, scopesettings.channel2.sample2);
        scopesettings.channel2.sample1 =  scopesettings.channel2.sample2;
    }
    
    scopesettings.lastx =  scopesettings.xpos;  
    scopesettings.xpos++;
    scopesettings.count++;
    disp_first_sample = scopesettings.count;
    
    //disp_xstart = 3; disp_xend = 727; 
    //scopesettings.triggerhorizontalposition = 375;
    //scopesettings.triggerhorizontalposition = scopesettings.count;
    disp_have_trigger=1;  //musi byt 1 aby nevlozilo sample/2 tj 1500
    
      //Calculate the start and end x coordinates
    
    if (scopesettings.count < 750) { disp_xstart = 0; disp_xend = 750; scopesettings.triggerhorizontalposition = 375;}
    else if (scopesettings.count < 1500) { disp_xstart = 750; disp_xend = 1500; scopesettings.triggerhorizontalposition = 1125;}
    else if (scopesettings.count < 2250) { disp_xstart = 1500; disp_xend = 2250;scopesettings.triggerhorizontalposition = 1875;}
    else if (scopesettings.count < 3000) { disp_xstart = 2250; disp_xend = 3000;scopesettings.triggerhorizontalposition = 2625;}
  //disp_xend = triggerposition + xrange;
    
    
    
    //scope_test_trigerposition_value();
  
  } //end runstate
}

//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------

void scope_check_long_trigger(void)
{
    uint32 sample1AVG = 0;
    uint32 sample2AVG = 0;
    uint32 sample1 = 0;
    uint32 sample2 = 0;
    uint32 level = 0;
    
    level = scopesettings.triggerverticalposition+25;   //+25 compensation
    
    //triggerlong = 1; 
    //scope_run_stop_text();
    
 
      //Check trigger channel 1 or channel 2
    if((scopesettings.triggerchannel == 0)) //channel1
    {
    //Read, accumulate and average 10 bytes of channel 1 trace data multiply
    sample1AVG = fpga_average_trace_data(&scopesettings.channel1);
    timer0_delay(5);
    sample2AVG = fpga_average_trace_data(&scopesettings.channel1);
    //scopesettings.channel1.sample1 = sampleAVG;
    //Get the sample and adjust the data for the correct voltage per div setting
    //sample1 = ((sample1AVG) * scopesettings.channel1.input_calibration[scopesettings.channel1.samplevoltperdiv]) >> VOLTAGE_SHIFTER;
    //sample2 = ((sample2AVG) * scopesettings.channel1.input_calibration[scopesettings.channel1.samplevoltperdiv]) >> VOLTAGE_SHIFTER;
    
    sample1 = ((sample1AVG) * multiply) >> VOLTAGE_SHIFTER;
    sample2 = ((sample2AVG) * multiply) >> VOLTAGE_SHIFTER;
    scopesettings.channel1.sample1 = sample2;
    
    }else
    {                                       //channel2
    //Read, accumulate and average 10 bytes of channel 2 trace data
    sample1AVG = fpga_average_trace_data(&scopesettings.channel2);
    timer0_delay(5);
    sample2AVG = fpga_average_trace_data(&scopesettings.channel2);
    //scopesettings.channel2.sample1 = sampleAVG;
    //Get the sample and adjust the data for the correct voltage per div setting
    //sample = ((sampleAVG) * scopesettings.channel2.input_calibration[scopesettings.channel2.samplevoltperdiv]) >> VOLTAGE_SHIFTER;
    
    //sample1 = ((sample1AVG) * scopesettings.channel2.input_calibration[scopesettings.channel2.samplevoltperdiv]) >> VOLTAGE_SHIFTER;
    //sample2 = ((sample2AVG) * scopesettings.channel2.input_calibration[scopesettings.channel2.samplevoltperdiv]) >> VOLTAGE_SHIFTER;
    
    sample1 = ((sample1AVG) * multiply) >> VOLTAGE_SHIFTER;
    sample2 = ((sample2AVG) * multiply) >> VOLTAGE_SHIFTER;  
    scopesettings.channel2.sample1 = sample2;
    
    }
   
    //if((scopesettings.triggerverticalposition == sample)||(scopesettings.triggerverticalposition == sample+1)) 
    //{triggerlong = 1; scope_run_stop_text();}//scopesettings.triggerhorizontalposition = 3000; }
    
    
    
    if(((scopesettings.triggeredge == 0) && (sample1 < level) && (sample2 >= level)) ||
       ((scopesettings.triggeredge == 1) && (sample1 >= level) && (sample2 < level)))
         {triggerlong = 1; scope_run_stop_text();}
     
     
    /*
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 220);  //x , y , sirka, vyska
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);
 
      display_decimal(600, 10, sampleAVG);
      display_decimal(600, 20, sample);
      display_decimal(600, 30, scopesettings.triggerverticalposition);
*/
    
     
}

//----------------------------------------------------------------------------------------------------------------------------------
/*
void scope_check_long_trigger(void)
{
  
}
*/

//----------------------------------------------------------------------------------------------------------------------------------
//**********************************************************************************************************************************
//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_ADoffset_value(void)
{
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 220);  //x , y , sirka, vyska
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);
      //uint32 center = (scopesettings.channel1.center * signal_adjusters[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;   
      
       
 // uint32 offset;
  uint32    max1;
  uint32    min1;    
  uint32    p2p1; 
  uint32    center1x; 
  uint32    dcoffset;
  uint32    dcoffsetm;
  
  register uint32 multiply;
  
  PCHANNELSETTINGS settings;
     /* 
    max1 = (scopesettings.channel1.max * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    center1x = (scopesettings.channel1.center * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
      //  center1x = (((scopesettings.channel1.center) * multiply ) >> VOLTAGE_SHIFTER);//3289650
    min1= (center1x*scopesettings.channel1.dc_shift_center)/100; 
    
    //min1 = (scopesettings.channel1.min * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    p2p1 = (scopesettings.channel1.peakpeak * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    dcoffset = (scopesettings.channel1.dcoffset * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    dcoffsetm = (scopesettings.channel1.dcoffset * multiply ) >> VOLTAGE_SHIFTER;//3289650
       */
    
    settings = &scopesettings.channel1;
    
    multiply=(settings->input_calibration[settings->samplevoltperdiv]);//*(settings->dc_shift_center)/100; ;
    
    //Get the sample and adjust the data  
    max1 = ((settings->maxDC * multiply ) >> VOLTAGE_SHIFTER);//3289650
    center1x = ((settings->centerDC * multiply ) >> VOLTAGE_SHIFTER);//3289650
    //center1x = settings->center;
    min1 = ((settings->minDC * multiply ) >> VOLTAGE_SHIFTER);//3289650
    p2p1 = ((settings->peakpeakDC * multiply ) >> VOLTAGE_SHIFTER);//3289650
    
    /*
        //Get the sample and adjust the data  
    max1 = settings->maxAS;//3289650
    //center = ((settings->center * multiply ) >> VOLTAGE_SHIFTER);//3289650
    center1x = settings->centerAS;
    min1 = settings->minAS;//3289650
    p2p1 = settings->peakpeakAS;//3289650
    */
    //scopesettings.channel1.dcoffset
      
      display_decimal(550, 0, max1 );
      display_decimal(550, 10, center1x);
      display_decimal(550, 20, min1);
      display_decimal(550, 30, p2p1);
      //display_decimal(550, 40, dcoffset);
      //display_decimal(550, 50, dcoffsetm);
    
      display_decimal(600, 0, scopesettings.channel1.max );
      display_decimal(600, 10, scopesettings.channel1.center );
      display_decimal(600, 20, scopesettings.channel1.min );
      display_decimal(600, 30, scopesettings.channel1.peakpeak );
      display_decimal(600, 40, scopesettings.channel1.dcoffset );
      display_decimal(600, 50, scopesettings.channel1.traceposition);
      
      //display_decimal(630, 20, scopesettings.voltcursor1position );
      //display_decimal(630, 30, scopesettings.voltcursor2position );
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_TP(void)
{
  
  #define   positionX  80//450
  #define   positionY  2  //250
  //Draw the background
  //display_fill_rect(159, 116, 226, 36);
  
  display_set_fg_color(BLACK_COLOR);
  //Fill the settings background
  display_fill_rect(positionX, positionY, 80, 95);  //x , y , sirka, vyska
  //display_fill_rect(600, 0, 100, 45);  //x , y , sirka, vyska
  //display_fill_rect(600, 0, 100, 100);  //x , y , sirka, vyska
  //Display the text with the green color
  //display_set_fg_color(GREEN_COLOR);
  /*
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_2);
  display_text(550, 0, "Xtouch");
  display_decimal(550, 10, xtouch_tmp);
  display_text(550, 20, "Ytouch");
  display_decimal(550, 30, ytouch_tmp);//450 320
  display_decimal(550, 40, scopesettings.runstate);//450 320
   */
  
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_2);
  display_text(positionX, positionY, "Xtouch");
  display_decimal(positionX, positionY+10, xtouch);
  display_text(positionX, positionY+20, "Ytouch");
  display_decimal(positionX, positionY+30, ytouch);//450 320
   
  display_text(positionX, positionY+50, "Xtouch tmp");
  display_decimal(positionX, positionY+60, xtouch_tmp);
  display_text(positionX, positionY+70, "Ytouch tmp");
  display_decimal(positionX, positionY+80, ytouch_tmp);//450 320
 /* 
  display_text(positionX, positionY+90, "mathmenuopen");
  display_decimal(positionX, positionY+100, mathmenuopen);//450 320
  
  display_text(positionX, positionY+110, "math mode");
  display_decimal(positionX, positionY+120, mathmode);//450 320
  */ 
  /*
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_2);
  display_text(600, 0, "Xtouch");
  display_decimal(600, 10, xtouch);
  display_text(600, 20, "Ytouch");
  display_decimal(600, 30, ytouch);//450 320
  */
  /*
  display_text(600, 50, "Xtouch");
  display_decimal(600, 60, xtouch_tmp);
  display_text(600, 70, "Ytouch");
  display_decimal(600, 80, ytouch_tmp);//450 320
  */
  
}


void scope_test_longbase_value(void)
{
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 220);  //x , y , sirka, vyska
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);

      display_text(550, 10, "sara"); 
      display_decimal(600, 10, scopesettings.samplerate);
      display_text(550, 20, "tpd");
      display_decimal(600, 20, scopesettings.timeperdiv);
   
      display_decimal(600, 30, frequency_per_div[scopesettings.timeperdiv]);
      display_decimal(600, 40, sample_rate[scopesettings.samplerate]);
      
      display_decimal(600, 50, timebase_settings[scopesettings.timeperdiv]);      
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_trigerposition_value(void)
{
  #define   positionX  600
  #define   positionY  100  //250

      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(positionX, positionY, 100, 220);  //x , y , sirka, vyska
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);

      //display_decimal(600, 0, triggerposition);
      display_decimal(positionX, positionY+10, disp_xstart);
      display_decimal(positionX, positionY+20, disp_xend);
      display_decimal(positionX, positionY+30, disp_first_sample);
      
      display_decimal(positionX, positionY+50, (disp_xstart * 10000) / 42899);
      display_decimal(positionX, positionY+60, (disp_xend * 10000) / 42899);
      
      display_decimal(positionX, positionY+70, scopesettings.triggerhorizontalposition);
      
      
       // thumbnaildata->disp_xstart = (disp_xstart * 10000) / 42899;
       // thumbnaildata->disp_xend   = (disp_xend * 10000) / 42899;
      
      
      //display_decimal(600, 50,  ((disp_trigger_index - disp_first_sample + 1) * 727.0) / (disp_trigger_index - disp_first_sample >= 0 ? (727.0 / disp_xpos_per_sample) : 1));
      //display_decimal(600, 60,  int32 ((disp_trigger_index - disp_first_sample + 1) * 727.0) / (727.0 / disp_xpos_per_sample));
      //display_decimal(600, 50,  (((1500          ) * 727.0) / (727.0 / disp_xpos_per_sample)+15));
      //display_decimal(600, 60,  (((1500 - 3000 ) * 727.0) / (727.0 / disp_xpos_per_sample)));
      
     // (disp_trigger_index - disp_first_sample + 1) / (727.0 / disp_xpos_per_sample)
      
      //display_decimal(600, 70, disp_trigger_index);
      //display_decimal(600, 80, disp_xpos_per_sample);  

      display_decimal(positionX, positionY+210, scopesettings.samplerate);
         
      display_decimal(positionX, positionY+220, scopesettings.timeperdiv);
            
      //display_decimal(600, 230, frequency_per_div[scopesettings.timeperdiv]);
      
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_calibration_value(void)
{
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 250);  //x , y , sirka, vyska 220
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);
  
      display_decimal(600, 40, scopesettings.channel1.dc_calibration_offset[0]);
      display_decimal(600, 50, scopesettings.channel1.dc_calibration_offset[1]);
      display_decimal(600, 60, scopesettings.channel1.dc_calibration_offset[2]);
      display_decimal(600, 70, scopesettings.channel1.dc_calibration_offset[3]);
      display_decimal(600, 80, scopesettings.channel1.dc_calibration_offset[4]);
      display_decimal(600, 90, scopesettings.channel1.dc_calibration_offset[5]);
      display_decimal(600, 100, scopesettings.channel1.dc_calibration_offset[6]);
      
      display_decimal(600, 120, scopesettings.channel2.dc_calibration_offset[0]);
      display_decimal(600, 130, scopesettings.channel2.dc_calibration_offset[1]);
      display_decimal(600, 140, scopesettings.channel2.dc_calibration_offset[2]);
      display_decimal(600, 150, scopesettings.channel2.dc_calibration_offset[3]);
      display_decimal(600, 160, scopesettings.channel2.dc_calibration_offset[4]);
      display_decimal(600, 170, scopesettings.channel2.dc_calibration_offset[5]);
      display_decimal(600, 180, scopesettings.channel2.dc_calibration_offset[6]);
      
      display_decimal(600, 210, scopesettings.channel1.adc1compensation);
      display_decimal(600, 220, scopesettings.channel1.adc2compensation);
      display_decimal(600, 230, scopesettings.channel2.adc1compensation);
      display_decimal(600, 240, scopesettings.channel2.adc2compensation);
      
      display_decimal(650, 40, scopesettings.channel1.input_calibration[0]);
      display_decimal(650, 50, scopesettings.channel1.input_calibration[1]);
      display_decimal(650, 60, scopesettings.channel1.input_calibration[2]);
      display_decimal(650, 70, scopesettings.channel1.input_calibration[3]);
      display_decimal(650, 80, scopesettings.channel1.input_calibration[4]);
      display_decimal(650, 90, scopesettings.channel1.input_calibration[5]);
      display_decimal(650, 100, scopesettings.channel1.input_calibration[6]);
      
      display_decimal(650, 120, scopesettings.channel2.input_calibration[0]);
      display_decimal(650, 130, scopesettings.channel2.input_calibration[1]);
      display_decimal(650, 140, scopesettings.channel2.input_calibration[2]);
      display_decimal(650, 150, scopesettings.channel2.input_calibration[3]);
      display_decimal(650, 160, scopesettings.channel2.input_calibration[4]);
      display_decimal(650, 170, scopesettings.channel2.input_calibration[5]);
      display_decimal(650, 180, scopesettings.channel2.input_calibration[6]);
      
    int32   volts;
    int32   value;
    PVOLTCALCDATA vcd;
    
    //Calculate the voltage based on the channel settings
    vcd = (PVOLTCALCDATA)&volt_calc_data[scopesettings.channel2.magnification][scopesettings.channel2.displayvoltperdiv];
    
    //value=scopesettings.channel1.peakpeak;
    value=scopesettings.channel2.max-128;
    
    volts = (value * scopesettings.channel2.input_calibration[5]) >> VOLTAGE_SHIFTER;
    
    volts *= vcd->mul_factor;
      
    display_decimal(650, 190, value);
    display_decimal(650, 200, volts);
    
    display_decimal(600, 190, scopesettings.channel2.displayvoltperdiv);
    display_decimal(600, 200, scopesettings.channel2.magnification);
    
}
//----------------------------------------------------------------------------------------------------------------------------------
//v1.00z0: the first version of the logger roll (v1.00y9, fixed 3000 columns moved down by one per column) kept for
//reference; the new one follows it
#if 0
//----------------------------------------------------------------------------------------------------------------------------------
//v1.00y9: roll mode on the FPGA streaming logger (0x153F port: 0x2050 / 0x3050), as MCP's roll.c / roll_view.c. The
//legacy roll (scope_get_long_timebase_data) reads 0x24 / 0x26, which the port does not have any more, so it showed
//nothing there; older FPGAs keep it.
//Per pass of the main loop: the stream is started for the time base when it does not run, the words written since the
//last pass are read and turned into columns (one column = one pixel = the mean of 2 x wpc samples per channel, both
//cores corrected as the normal readout), and when columns came in the trace area is drawn once: the newest column at
//the right edge, older ones to the left. No waiting: at 100 ms/div a column comes every 2 ms and the picture moves by
//all the columns of the pass. The trigger as the old roll and MCP, on the columns: Auto adds columns for ever (the
//oldest dropped after ROLL_LEN), Single / Normal wait until the trigger channel's column crosses the trigger level in
//the edge's direction, then fill ROLL_LEN columns; Single stops then, Normal waits again. EXT runs as Auto.

#define ROLLF_LEN       3000                  //columns held per channel
#define ROLLF_TBS       9                     //time bases 0 (50 s/div) .. 8 (100 ms/div)
#define ROLLF_X_LAST    726
#define ROLLF_X_FIRST   4
#define ROLLF_COLS      (ROLLF_X_LAST - ROLLF_X_FIRST + 1)

#define ROLLF_WAIT      0
#define ROLLF_RUN       1
#define ROLLF_DONE      2

//Column period = time/div / 50 = wpc x 2 (divider + 1) x 5 ns (MCP roll_plan)
static const uint32 rollf_div[ROLLF_TBS] = { 999999, 999999, 999999, 999999, 999999, 499999, 249999, 99999, 49999 };
static const uint16 rollf_wpc[ROLLF_TBS] = { 100,    40,     20,     10,     4,      4,      4,      4,     4 };

static struct
{
  uint32 count;           //columns held
  uint8  state;
  uint8  cfg[4];          //trigger mode, channel, edge, time base the record was started for
  int32  prev;            //the trigger channel's previous column on screen (-1 none)
  uint32 nw;              //words in the column being summed
  uint32 sum[4];          //CH1 B, CH1 A, CH2 B, CH2 A
} rollf;

static uint8 rollf_words[2048 * 4];

static void rollf_reset(void)
{
  rollf.count = 0;
  rollf.nw    = 0;
  rollf.prev  = -1;
  rollf.sum[0] = rollf.sum[1] = rollf.sum[2] = rollf.sum[3] = 0;

  rollf.cfg[0] = scopesettings.triggermode;
  rollf.cfg[1] = scopesettings.triggerchannel;
  rollf.cfg[2] = scopesettings.triggeredge;
  rollf.cfg[3] = scopesettings.timeperdiv;

  //Auto, or the EXT channel (not in the stream): runs at once
  rollf.state = ((scopesettings.triggermode == 0) || (scopesettings.triggerchannel > 1)) ? ROLLF_RUN : ROLLF_WAIT;
  triggerlong = (rollf.state == ROLLF_RUN);
}

//One channel's column code from the sums of its cores (corrected and inverted as fpga_read_adc_data does)
static uint8 rollf_code(PCHANNELSETTINGS s, uint32 sumb, uint32 suma, uint32 n)
{
  int32 v = (int32)((suma + sumb) + ((int32)n * (s->adc1compensation + s->adc2compensation)));

  v = (v + (int32)n) / (int32)(2 * n);

  if(v < 0)   v = 0;
  if(v > 255) v = 255;

  if(s->invert)
    v = 255 - v;

  return((uint8)v);
}

//A new column at the end of the record (the oldest dropped when full); 1 when it was kept
static uint32 rollf_add(uint8 c1, uint8 c2)
{
  PCHANNELSETTINGS tc = (scopesettings.triggerchannel == 1) ? &scopesettings.channel2 : &scopesettings.channel1;
  int32 level = scopesettings.triggerverticalposition;
  int32 cur;

  if(rollf.state == ROLLF_DONE)
    return(0);

  //The trigger channel's column as a screen height (as the trigger pointer)
  tc->tracebuffer[ROLLF_LEN] = (tc == &scopesettings.channel1) ? c1 : c2;
  cur = 448 - scope_get_y_sample(tc, ROLLF_LEN);

  if(rollf.state == ROLLF_WAIT)
  {
    int crossed = (rollf.prev >= 0) &&
                  (scopesettings.triggeredge ? ((rollf.prev >= level) && (cur < level)) : ((rollf.prev < level) && (cur >= level)));

    rollf.prev = cur;

    if(!crossed)
      return(0);

    rollf.state = ROLLF_RUN;
    triggerlong = 1;
    scope_run_stop_text();
  }

  rollf.prev = cur;

  if(rollf.count == ROLLF_LEN)
  {
    memmove(scopesettings.channel1.tracebuffer, scopesettings.channel1.tracebuffer + 1, ROLLF_LEN - 1);
    memmove(scopesettings.channel2.tracebuffer, scopesettings.channel2.tracebuffer + 1, ROLLF_LEN - 1);
    rollf.count--;
  }

  scopesettings.channel1.tracebuffer[rollf.count] = c1;
  scopesettings.channel2.tracebuffer[rollf.count] = c2;
  rollf.count++;

  //A full Single / Normal record
  if((scopesettings.triggermode != 0) && (scopesettings.triggerchannel <= 1) && (rollf.count == ROLLF_LEN))
  {
    if(scopesettings.triggermode == 1)
    {
      rollf.state = ROLLF_DONE;
      scopesettings.runstate = 0;
      triggerlong = 0;
      scope_run_stop_text();

      if(scopesettings.rightmenustate == 0)
        scope_run_stop_button(0);
    }
    else
    {
      rollf.count = 0;
      rollf.prev  = -1;
      rollf.state = ROLLF_WAIT;
      triggerlong = 0;
      scope_run_stop_text();
    }
  }

  return(1);
}

static void rollf_draw(void)
{
  PCHANNELSETTINGS ch[2] = { &scopesettings.channel1, &scopesettings.channel2 };
  uint32 vis   = (rollf.count < ROLLF_COLS) ? rollf.count : ROLLF_COLS;
  uint32 first = rollf.count - vis, i, c;
  int32  x0 = ROLLF_X_LAST - (int32)vis + 1, y, ly = 0;

  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 48, 730, 432);

  if((!scopesettings.waveviewmode) || (scopesettings.gridenable))
    scope_draw_grid();

  for(c = 0; c < 2; c++)
  {
    if(!ch[c]->enable)
      continue;

    display_set_fg_color((c == 0) ? CHANNEL1_COLOR : CHANNEL2_COLOR);

    for(i = 0; i < vis; i++)
    {
      y = scope_get_y_sample(ch[c], first + i);

      if(i)
        display_draw_line(x0 + i - 1, ly, x0 + i, y);
      else
        display_draw_pixel(x0, y);

      ly = y;
    }
  }

  scope_draw_pointers();
  scope_draw_time_cursors();
  scope_draw_volt_cursors();
  scope_display_cursor_measurements();

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(0, 48, 730, 432);

  //As the old roll: the record holds its columns from index 0 (saved roll pictures / waveforms)
  disp_have_trigger = 1;
  disp_first_sample = rollf.count;
}

void scope_roll_logger_pass(void)
{
  uint32 tpd = scopesettings.timeperdiv, gap, k, added = 0;
  int32  n;
  uint8 *w;

  if(!scopesettings.runstate || (tpd >= ROLLF_TBS))
  {
    fpga_logger_stop(1);
    return;
  }

  //Trigger settings or time base changed, or RUN after a Single record: a new record
  if((rollf.state == ROLLF_DONE) || (rollf.cfg[0] != scopesettings.triggermode) || (rollf.cfg[1] != scopesettings.triggerchannel) ||
     (rollf.cfg[2] != scopesettings.triggeredge) || (rollf.cfg[3] != tpd))
  {
    rollf_reset();
    added = 1;
  }

  if(!fpga_logger_running())
  {
    if(fpga_logger_start(rollf_div[tpd]))
    {
      //The stream does not start: stop, so the screen does not stand still without a word
      scopesettings.runstate = 0;
      scope_run_stop_text();

      if(scopesettings.rightmenustate == 0)
        scope_run_stop_button(0);

      return;
    }

    //The time between is not on the trace
    rollf.nw   = 0;
    rollf.prev = -1;
    rollf.sum[0] = rollf.sum[1] = rollf.sum[2] = rollf.sum[3] = 0;
  }

  for(k = 0; k < 4; k++)
  {
    n = fpga_logger_read(rollf_words, 2048, &gap);

    if(n < 0)
      break;

    if(gap)
    {
      rollf.nw   = 0;
      rollf.prev = -1;
      rollf.sum[0] = rollf.sum[1] = rollf.sum[2] = rollf.sum[3] = 0;
      continue;
    }

    if(n == 0)
      break;

    for(w = rollf_words; n > 0; n--, w += 4)
    {
      rollf.sum[0] += w[0];
      rollf.sum[1] += w[1];
      rollf.sum[2] += w[2];
      rollf.sum[3] += w[3];

      if(++rollf.nw == rollf_wpc[tpd])
      {
        added |= rollf_add(rollf_code(&scopesettings.channel1, rollf.sum[0], rollf.sum[1], rollf.nw),
                           rollf_code(&scopesettings.channel2, rollf.sum[2], rollf.sum[3], rollf.nw));
        rollf.nw = 0;
        rollf.sum[0] = rollf.sum[1] = rollf.sum[2] = rollf.sum[3] = 0;
      }
    }
  }

  if(added)
    rollf_draw();
}

#endif

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00z0: roll mode on the FPGA streaming logger (0x153F port: 0x2050 / 0x3050), as MCP's roll.c / roll_view.c, with a
//record as long as the ACQ Memory setting (3000 .. 16000 columns) in a ring (no moving of the record per column).
//The legacy roll (scope_get_long_timebase_data) reads 0x24 / 0x26, which the port does not have, so it showed nothing
//there; older FPGAs keep it.
//Per pass of the main loop: the stream is started for the time base when it does not run, the words written since the
//last pass are read and turned into columns (one column = one pixel = the mean of 2 x wpc samples per channel, both
//cores corrected as the normal readout), and when columns came in the trace area is drawn once: the newest column at
//the right edge. The trigger as the old roll and MCP, on the columns: Auto adds columns for ever (the oldest overwritten
//when the ring is full), Single / Normal wait until the trigger channel's column crosses the trigger level in the
//edge's direction, then fill the record; Single stops then, Normal waits again. EXT runs as Auto.
//The record scroll box under the grid shows the whole record (min / max per pixel, the shown part bright) and, after
//STOP or in a saved roll file, moves the shown part (scope_roll_slider_touch). RUN shows the newest columns again.

#define ROLLF_MINLEN    3000
#define ROLLF_MAXLEN    16000                 //the trace buffers hold MAX_SAMPLE_BUFFER_SIZE (16382) bytes
#define ROLLF_SCRATCH   (ROLLF_MAXLEN + 1)    //a free place in the buffers for the trigger test
#define ROLLF_TBS       9                     //time bases 0 (50 s/div) .. 8 (100 ms/div)
#define ROLLF_X_LAST    726
#define ROLLF_X_FIRST   4
#define ROLLF_COLS      (ROLLF_X_LAST - ROLLF_X_FIRST + 1)

#define ROLLF_WAIT      0
#define ROLLF_RUN       1
#define ROLLF_DONE      2

//Column period = time/div / 50 = wpc x 2 (divider + 1) x 5 ns (MCP roll_plan)
static const uint32 rollf_div[ROLLF_TBS] = { 999999, 999999, 999999, 999999, 999999, 499999, 249999, 99999, 49999 };
static const uint16 rollf_wpc[ROLLF_TBS] = { 100,    40,     20,     10,     4,      4,      4,      4,     4 };

static struct
{
  uint32 len;             //ring length (Memory setting)
  uint32 head;            //where the next column goes
  uint32 count;           //columns held
  uint32 view;            //columns between the newest one and the newest shown (0: the newest at the right edge)
  uint8  state;
  uint8  cfg[4];          //trigger mode, channel, edge, time base the record was started for
  uint16 cfglen;          //record length it was started for
  int32  prev;            //the trigger channel's previous column on screen (-1 none)
  uint8  armed;           //v1.00z1: the trigger is armed (the column went past the level by the hysteresis)
  uint32 nw;              //words in the column being summed
  uint32 sum[4];          //CH1 B, CH1 A, CH2 B, CH2 A
  int32  cmin[2];         //v1.00z5: the lowest / highest corrected sample of the column being summed (CH1, CH2)
  int32  cmax[2];
} rollf;

//v1.00z5: the lowest and highest sample of every column (CH1, CH2) in the same ring as the column means in the trace
//buffers: the Peak / Pro band and Vmax / Vmin of the live record. A saved roll file only has the means.
static uint8 rollf_pmin[2][ROLLF_MAXLEN];
static uint8 rollf_pmax[2][ROLLF_MAXLEN];

//v1.00z5: the part of the record drawn last (roll_draw_record): measurements and CHx -> REF use it
static struct
{
  uint32 len, start, first, vis;
  uint8  peak;            //the min / max ring belongs to it (live record)
} rolld;

uint8 scope_roll_meas = 0;

extern uint32 isqrt(uint32 n);              //fpga_control.c
extern DISPLAYDATA displaydata;             //display_lib.c (current foreground colour)

//v1.00z5: a new column starts
static void rollf_col_clear(void)
{
  rollf.nw = 0;
  rollf.sum[0] = rollf.sum[1] = rollf.sum[2] = rollf.sum[3] = 0;
  rollf.cmin[0] = rollf.cmin[1] = 0x7FFFFFFF;
  rollf.cmax[0] = rollf.cmax[1] = -0x7FFFFFFF;
}

//A saved roll file in the viewer (scope_restore_setup_from_file): its columns from index 0, oldest first
uint32 rollview_count = 0;
static uint32 rollview_view = 0;

static uint8 rollf_words[2048 * 4];

static uint32 rollf_length(void)
{
  //uint32 n = scopesettings.samplecount;
  uint32 n = scopesettings.rollmemory;     //v1.00z4: own setting, the normal record length stays with the FPGA

  if(n < ROLLF_MINLEN) n = ROLLF_MINLEN;
  if(n > ROLLF_MAXLEN) n = ROLLF_MAXLEN;

  return(n);
}

static void rollf_reset(void)
{
  rollf.len   = rollf_length();
  rollf.head  = 0;
  rollf.count = 0;
  rollf.view  = 0;
  rollf.prev  = -1;
  rollf_col_clear();     //v1.00z5

  rollf.cfg[0] = scopesettings.triggermode;
  rollf.cfg[1] = scopesettings.triggerchannel;
  rollf.cfg[2] = scopesettings.triggeredge;
  rollf.cfg[3] = scopesettings.timeperdiv;
  rollf.cfglen = (uint16)rollf.len;

  //Auto, or the EXT channel (not in the stream): runs at once
  rollf.state = ((scopesettings.triggermode == 0) || (scopesettings.triggerchannel > 1)) ? ROLLF_RUN : ROLLF_WAIT;
  triggerlong = (rollf.state == ROLLF_RUN);
  rollf.armed = 0;

  //v1.00z1: the trigger level code for the column test, and RUN / WAIT shown at once
  fpga_set_trigger_level();
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_run_stop_text();
}

//One channel's column code from the sums of its cores (corrected and inverted as fpga_read_adc_data does)
static uint8 rollf_code(PCHANNELSETTINGS s, uint32 sumb, uint32 suma, uint32 n)
{
  int32 v = (int32)((suma + sumb) + ((int32)n * (s->adc1compensation + s->adc2compensation)));

  v = (v + (int32)n) / (int32)(2 * n);

  if(v < 0)   v = 0;
  if(v > 255) v = 255;

  if(s->invert)
    v = 255 - v;

  return((uint8)v);
}

//v1.00z5: the extremes of the finished column as codes (clipped and inverted as the means), for rollf_add
static uint8 rollf_cpk[2][2];

static void rollf_peak(PCHANNELSETTINGS s, uint32 c)
{
  int32 mn = rollf.cmin[c], mx = rollf.cmax[c];

  if(mn < 0) mn = 0;
  if(mn > 255) mn = 255;
  if(mx < 0) mx = 0;
  if(mx > 255) mx = 255;

  if(s->invert)
  {
    int32 t = 255 - mn;
    mn = 255 - mx;
    mx = t;
  }

  rollf_cpk[c][0] = (uint8)mn;
  rollf_cpk[c][1] = (uint8)mx;
}

//A new column at the end of the record (the oldest overwritten when the ring is full); 1 when it was kept
static uint32 rollf_add(uint8 c1, uint8 c2)
{
  //v1.00z1: the test on the column codes against the trigger level code (scopesettings.triggerlevel, as the FPGA
  //compares in the normal time base) with the hysteresis of Settings > Display > Trigger position: rising arms on a
  //column below level - H and fires on the first column at or above the level, falling the other way round (H = 0:
  //a plain crossing). The screen height test of v1.00z0 kept below.
#if 0
  PCHANNELSETTINGS tc = (scopesettings.triggerchannel == 1) ? &scopesettings.channel2 : &scopesettings.channel1;
  int32 level = scopesettings.triggerverticalposition;
  int32 cur;

  if(rollf.state == ROLLF_DONE)
    return(0);

  //The trigger channel's column as a screen height (as the trigger pointer)
  tc->tracebuffer[ROLLF_SCRATCH] = (tc == &scopesettings.channel1) ? c1 : c2;
  cur = 448 - scope_get_y_sample(tc, ROLLF_SCRATCH);

  if(rollf.state == ROLLF_WAIT)
  {
    int crossed = (rollf.prev >= 0) &&
                  (scopesettings.triggeredge ? ((rollf.prev >= level) && (cur < level)) : ((rollf.prev < level) && (cur >= level)));

    rollf.prev = cur;

    if(!crossed)
      return(0);

    rollf.state = ROLLF_RUN;
    triggerlong = 1;
    scope_run_stop_text();
  }

  rollf.prev = cur;
#endif
  int32 level = scopesettings.triggerlevel;
  int32 h     = scopesettings.trighyst;
  int32 cur   = (scopesettings.triggerchannel == 1) ? c2 : c1;

  if(rollf.state == ROLLF_DONE)
    return(0);

  if(rollf.state == ROLLF_WAIT)
  {
    int fired = 0;

    if(scopesettings.triggeredge == 0)
    {
      if(cur < (level - h))
        rollf.armed = 1;
      else if(rollf.armed && (cur >= level))
        fired = 1;
    }
    else
    {
      if(cur >= (level + h))
        rollf.armed = 1;
      else if(rollf.armed && (cur < level))
        fired = 1;
    }

    if(!fired)
      return(0);

    rollf.state = ROLLF_RUN;
    triggerlong = 1;
    display_set_screen_buffer((uint16 *)maindisplaybuffer);
    scope_run_stop_text();
  }

  scopesettings.channel1.tracebuffer[rollf.head] = c1;
  scopesettings.channel2.tracebuffer[rollf.head] = c2;

  //v1.00z5: the column's extremes (rollf_peak)
  rollf_pmin[0][rollf.head] = rollf_cpk[0][0];
  rollf_pmax[0][rollf.head] = rollf_cpk[0][1];
  rollf_pmin[1][rollf.head] = rollf_cpk[1][0];
  rollf_pmax[1][rollf.head] = rollf_cpk[1][1];

  if(++rollf.head >= rollf.len)
    rollf.head = 0;

  if(rollf.count < rollf.len)
    rollf.count++;

  //A full Single / Normal record
  if((scopesettings.triggermode != 0) && (scopesettings.triggerchannel <= 1) && (rollf.count == rollf.len))
  {
    if(scopesettings.triggermode == 1)
    {
      rollf.state = ROLLF_DONE;
      scopesettings.runstate = 0;
      triggerlong = 0;
      scope_run_stop_text();

      if(scopesettings.rightmenustate == 0)
        scope_run_stop_button(0);
    }
    else
    {
      rollf.head  = 0;
      rollf.count = 0;
      rollf.prev  = -1;
      rollf.armed = 0;
      rollf.state = ROLLF_WAIT;
      triggerlong = 0;
      display_set_screen_buffer((uint16 *)maindisplaybuffer);
      scope_run_stop_text();
    }
  }

  return(1);
}

//Draw a roll record: len the ring length, start the place of the oldest column, count the columns, view the columns
//right of the shown part. The trace area with grid, both channels, pointers and cursors, and the record scroll box
//with the whole record.
//v1.00z5: peak 1 when the min / max ring belongs to the record (live), for the Peak / Pro band. Then the REFs taken in
//the roll and the measurements of the shown part.
static int32 roll_y(PCHANNELSETTINGS s, uint8 code)
{
  s->tracebuffer[ROLLF_SCRATCH] = code;
  return(scope_get_y_sample(s, ROLLF_SCRATCH));
}

static void roll_draw_refs(void);

static void roll_draw_record(uint32 len, uint32 start, uint32 count, uint32 view, uint32 peak)
{
  PCHANNELSETTINGS ch[2] = { &scopesettings.channel1, &scopesettings.channel2 };
  uint32 vis, first, i, c, k, k0, k1, p, mode;
  int32  x0, y, ly = 0, wx = 4, ww = 723, mn, mx, yt, yb, pt = 0, pb = 0;
  uint16 color;

  if(view > count)
    view = count;

  vis   = ((count - view) < ROLLF_COLS) ? (count - view) : ROLLF_COLS;
  first = count - view - vis;
  x0    = ROLLF_X_LAST - (int32)vis + 1;

  //v1.00z7: the roll REF set in the slots (also in the viewer of a saved roll file)
  scope_refset_sync();

  rolld.len   = len;
  rolld.start = start;
  rolld.first = first;
  rolld.vis   = vis;
  rolld.peak  = (uint8)peak;

  mode = scope_roll_trace_mode();

  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 48, 730, 432);

  if((!scopesettings.waveviewmode) || (scopesettings.gridenable))
    scope_draw_grid();

  for(c = 0; c < 2; c++)
  {
    if(!ch[c]->enable)
      continue;

    display_set_fg_color((c == 0) ? CHANNEL1_COLOR : CHANNEL2_COLOR);

    //v1.00z5: Peak / Pro: every column a vertical line from its lowest to its highest sample, joined to the previous
    //column (no gaps on steep edges) as Peak in the normal time base; Pro in 3/8 of the colour with the means over it
    if((mode == 2) || (mode == 3))
    {
      color = displaydata.fg_color;

      if(mode == 3)
        displaydata.fg_color = ((color >> 2) & 0x39E7) + ((color >> 3) & 0x18E3);

      for(i = 0; i < vis; i++)
      {
        p  = (start + first + i) % len;
        mn = roll_y(ch[c], rollf_pmax[c][p]);     //screen y of the highest sample (top)
        mx = roll_y(ch[c], rollf_pmin[c][p]);     //and of the lowest (bottom)
        yt = mn;
        yb = mx;

        if(i)
        {
          if(yt > pb) yt = pb;
          if(yb < pt) yb = pt;
        }

        if(mode == 3)
          display_draw_vert_line(x0 + i, yt, yb);
        else
          scope_trace_line(x0 + i, yt, x0 + i, yb);

        pt = mn;
        pb = mx;
      }

      displaydata.fg_color = color;

      if(mode == 2)
        continue;
    }

    for(i = 0; i < vis; i++)
    {
      p = (start + first + i) % len;
      y = scope_get_y_sample(ch[c], p);

      //v1.00z1: with the Line width (1 / 2 px) of the ACQ menu
      //v1.00z5: Dots: only the column means
      if(i && (mode != 1))
        scope_trace_line(x0 + i - 1, ly, x0 + i, y);
      else
        scope_trace_pixel(x0 + i, y);

      ly = y;
    }
  }

  //v1.00z5: the REFs taken in the roll
  roll_draw_refs();

  //The scroll box (its frame is drawn by scope_draw_grid): the whole record, the shown part bright
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(3, 453, 724, 18);

  if(count)
  {
    wx = 4 + (int32)(((uint64)first * 723) / count);
    ww = (int32)(((uint64)vis * 723) / count);

    if(ww < 5)
      ww = 5;

    for(c = 2; c-- > 0; )
    {
      if(!ch[c]->enable)
        continue;

      for(i = 0; i < 723; i++)
      {
        k0 = (uint32)(((uint64)i * count) / 723);
        k1 = (uint32)(((uint64)(i + 1) * count) / 723);

        if(k1 <= k0)
          k1 = k0 + 1;

        if(k1 > count)
          k1 = count;

        mn = 255;
        mx = 0;

        for(k = k0; k < k1; k++)
        {
          int32 v = ch[c]->tracebuffer[(start + k) % len];

          if(v < mn) mn = v;
          if(v > mx) mx = v;
        }

        if(mx < mn)
          continue;

        display_set_fg_color((((int32)(4 + i) >= wx) && ((int32)(4 + i) < (wx + ww))) ? ((c == 0) ? CHANNEL1_COLOR : CHANNEL2_COLOR) : ((c == 0) ? 0x007F7F00 : 0x00007F7F));
        display_draw_vert_line(4 + i, 469 - ((mx * 14) / 255), 469 - ((mn * 14) / 255));
      }
    }

    display_set_fg_color(WHITE_COLOR);
    display_draw_rect(wx, 455, ww, 14);
  }

  scope_draw_pointers();
  scope_draw_time_cursors();
  scope_draw_volt_cursors();
  scope_display_cursor_measurements();

  //v1.00z5: the measurement tiles of the shown part
  scope_roll_measurements();

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(0, 48, 730, 432);

  //As the old roll: a saved roll picture / waveform
  disp_have_trigger = 1;
  disp_first_sample = count;
}

static uint32 rollf_start(void)
{
  return((rollf.head + rollf.len - rollf.count) % rollf.len);
}

static void rollf_draw(void)
{
  if(rollf.len)
    roll_draw_record(rollf.len, rollf_start(), rollf.count, rollf.view, 1);
}

//v1.00z0: a saved roll file in the viewer: columns 0 .. rollview_count - 1, oldest first
void scope_roll_view_draw(void)
{
  roll_draw_record(MAX_SAMPLE_BUFFER_SIZE, 0, rollview_count, rollview_view, 0);
}

void scope_roll_view_set(uint32 count, uint32 view)
{
  rollview_count = (count > ROLLF_MAXLEN) ? ROLLF_MAXLEN : count;
  rollview_view  = (view > rollview_count) ? 0 : view;
}

//v1.00z0: the live record of the port roll is held (STOP) or in use: 1 when the roll draws the trace area itself
uint32 scope_roll_live(void)
{
  return(FPGA_IS_153F_PORT() && scopesettings.long_mode && !scopesettings.waveviewmode);
}

//v1.00z0: from scope_preset_values in the long time base mode on the port: RUN starts a new record (as the old roll
//cleared its sweep), STOP keeps the record and draws it again (a moved trace or pointer)
//v1.00z1: no new record here any more (a moved trace or trigger pointer during RUN wiped up to 16000 columns): the record
//is only drawn again; a new one comes with RUN (scope_roll_restart), a changed time base, Memory or trigger setting
void scope_roll_preset(void)
{
  //if(scopesettings.runstate)
  //  rollf_reset();

  rollf_draw();
}

//v1.00z1: RUN pressed: a new record at the next pass
void scope_roll_restart(void)
{
  rollf.len = 0;
}

//v1.00z1: the roll's own screen: the live logger roll of the port or a saved logger roll record in the viewer (things
//of the normal time base without meaning there are dimmed / hidden)
uint32 scope_roll_ui(void)
{
  return((FPGA_IS_153F_PORT() && scopesettings.long_mode && !scopesettings.waveviewmode) ||
         (scopesettings.waveviewmode && scopesettings.long_mode && rollview_count));
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00z5: the drawing mode in the roll. A column holds 2 x wpc (8 .. 200) samples, so Auto and Sin x are Peak as in the
//normal time base with more than one sample per pixel. Peak / Pro need the min / max ring, which only the live record
//has (a saved roll file holds the means): Linear there. Hi-Res is the line of the means (a column is their mean).
uint32 scope_roll_trace_mode(void)
{
  uint32 m = scopesettings.ACQ_trace;
  uint32 peak = !(scopesettings.waveviewmode && rollview_count);

  if((m == TRACE_MODE_AUTO) || (m == TRACE_MODE_SINX))
    m = 2;

  if(((m == 2) || (m == 3)) && !peak)
    m = 0;

  return(m);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00z5: REF in the roll. CHx -> REF in the roll takes the shown columns (oldest first from index 0, at most 723) and
//marks the REF in its sample1 (not used by REFs otherwise, saved with the REF file): ROLL_REF_MAGIC | time base << 16 |
//columns. Such a REF is drawn in the roll one column per pixel with its newest column at the right edge (as it was
//shown when taken, whatever the time base now) and is not drawn in the normal time base; a REF of the normal time base
//is not drawn in the roll (other time axis).
#define ROLL_REF_MAGIC  0x52000000
#define ROLL_REF_MASK   0xFF000000

uint32 scope_ref_is_roll(PCHANNELSETTINGS ref)
{
  return((ref->sample1 & ROLL_REF_MASK) == ROLL_REF_MAGIC);
}

static uint32 roll_ref_cols(PCHANNELSETTINGS ref)
{
  uint32 n;

  if(!scope_ref_is_roll(ref))
    return(0);

  n = ref->sample1 & 0xFFFF;

  return((n > ROLLF_COLS) ? ROLLF_COLS : n);
}

void scope_roll_ref_copy(PCHANNELSETTINGS dest, PCHANNELSETTINGS src)
{
  uint32 i;

  dest->sample1 = 0;

  if(!scope_roll_ui() || ((src != &scopesettings.channel1) && (src != &scopesettings.channel2)) || !rolld.len)
    return;

  for(i = 0; i < rolld.vis; i++)
    dest->tracebuffer[i] = src->tracebuffer[(rolld.start + rolld.first + i) % rolld.len];

  dest->sample1 = ROLL_REF_MAGIC | ((scopesettings.timeperdiv & 0xFF) << 16) | rolld.vis;
}

static PCHANNELSETTINGS roll_ref(uint32 r, uint32 *on)
{
  switch(r)
  {
    case 0:  *on = scopesettings.ref1; return(&scopesettings.ch_ref1);
    case 1:  *on = scopesettings.ref2; return(&scopesettings.ch_ref2);
    case 2:  *on = scopesettings.ref3; return(&scopesettings.ch_ref3);
    case 3:  *on = scopesettings.ref4; return(&scopesettings.ch_ref4);
    case 4:  *on = scopesettings.ref5; return(&scopesettings.ch_ref5);
    case 5:  *on = scopesettings.ref6; return(&scopesettings.ch_ref6);
    case 6:  *on = scopesettings.ref7; return(&scopesettings.ch_ref7);
    default: *on = scopesettings.ref8; return(&scopesettings.ch_ref8);
  }
}

static void roll_draw_refs(void)
{
  PCHANNELSETTINGS ref;
  uint32 r, on, n, i;
  int32  x0, y, ly = 0;

  for(r = 0; r < 8; r++)
  {
    ref = roll_ref(r, &on);
    n   = roll_ref_cols(ref);

    if(!on || !n)
      continue;

    display_set_fg_color(ref->color);
    x0 = ROLLF_X_LAST - (int32)n + 1;

    for(i = 0; i < n; i++)
    {
      y = scope_get_y_sample(ref, i);

      if(i)
        scope_trace_line(x0 + i - 1, ly, x0 + i, y);
      else
        scope_trace_pixel(x0, y);

      ly = y;
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00z5: MEASURES in the roll, from the shown columns (or the columns of a roll REF chosen as the source). Vmax / Vmin
//(and Vpp, Vp) from the lowest / highest single sample of the columns in the live record, from the column means in a
//saved roll file; Vavg and Vrms from the column means. Frequency, period, time + / - and duty from the crossings of the
//column means (hysteresis as the normal readout), only when the shown part holds at least two whole periods of at least
//4 columns each and the signal is more than a few codes high; "xxx" otherwise. Time in 10 us units for
//scope_print_value (scale m), frequency in 10 uHz units (scale m).
static void roll_measure(PCHANNELSETTINGS s, const uint8 *buf, uint32 len, uint32 start, uint32 n, const uint8 *pmn, const uint8 *pmx, uint32 tpd)
{
  uint32 i, p, v, sum = 0, sq = 0, state, zc = 0, hs = 0, hd = 0, ls = 0, ld = 0, prev = 0, colus;
  int32  mmn = 255, mmx = 0, pkmn = 255, pkmx = 0, c, thr, hi, lo, d;
  uint64 htq, ltq, pq;

  s->frequencyvalid = 0;

  for(i = 0; i < n; i++)
  {
    p = (start + i) % len;
    v = buf[p];
    sum += v;
    d = (int32)v - 128;
    sq += (uint32)(d * d);

    if((int32)v < mmn) mmn = v;
    if((int32)v > mmx) mmx = v;

    if(pmn)
    {
      if(pmn[p] < pkmn) pkmn = pmn[p];
      if(pmx[p] > pkmx) pkmx = pmx[p];
    }
  }

  if(!pmn)
  {
    pkmn = mmn;
    pkmx = mmx;
  }

  s->min      = pkmn;
  s->max      = pkmx;
  s->average  = sum / n;
  s->rms      = isqrt(sq / n);
  s->peakpeak = pkmx - pkmn;
  s->center   = (pkmx + pkmn) / 2;

  //Frequency from the means
  if((tpd >= ROLLF_TBS) || ((mmx - mmn) < 6))
    return;

  c   = (mmx + mmn) / 2;
  thr = ((mmx - mmn) / 10) + 2;
  hi  = c + thr;
  lo  = c - thr;
  state = (buf[start % len] > hi) ? 1 : 0;

  for(i = 0; i < n; i++)
  {
    v = buf[(start + i) % len];

    if(((int32)v > hi) && (state == 0))
    {
      state = 1;

      if(zc) { ls += i - prev; ld++; }

      prev = i;
      zc++;
    }
    else if(((int32)v < lo) && (state == 1))
    {
      state = 0;

      if(zc) { hs += i - prev; hd++; }

      prev = i;
      zc++;
    }
  }

  //Two whole periods: 5 crossings (2 high and 2 low times)
  if((zc < 5) || !hd || !ld)
    return;

  htq = ((uint64)hs << 16) / hd;
  ltq = ((uint64)ls << 16) / ld;
  pq  = htq + ltq;

  if(pq < (4 << 16))
    return;

  //Column period in us = wpc x 2 (divider + 1) x 5 ns
  colus = (rollf_wpc[tpd] * (rollf_div[tpd] + 1)) / 100;

  s->hightime   = (uint32)((htq * colus) / (10 << 16));
  s->lowtime    = (uint32)((ltq * colus) / (10 << 16));
  s->periodtime = s->hightime + s->lowtime;
  s->frequency  = (uint32)((100000000000ULL << 16) / (pq * colus));

  if(s->periodtime)
    s->frequencyvalid = 1;
}

static void roll_measure_side(uint32 side)
{
  PCHANNELSETTINGS ch = side ? &scopesettings.channel2 : &scopesettings.channel1;
  PCHANNELSETTINGS ref;
  uint32 src  = side ? scopesettings.source2_measures : scopesettings.source1_measures;
  uint32 hide = side ? scopesettings.hide_values_CH2 : scopesettings.hide_values_CH1;
  uint32 on, n, r, any = ch->enable;
  uint32 x = side ? 366 : 5;

  for(r = side * 4; r < (side * 4) + 4; r++)
  {
    roll_ref(r, &on);
    any |= on;
  }

  if(!any || hide)
    return;

  if((src >= 1) && (src <= 4))
  {
    ref = roll_ref((side * 4) + src - 1, &on);
    n   = roll_ref_cols(ref);

    if(!n)
      return;

    roll_measure(ref, ref->tracebuffer, MAX_SAMPLE_BUFFER_SIZE, 0, n, 0, 0, (ref->sample1 >> 16) & 0xFF);
    scope_roll_meas = 1;
    scope_display_channel_measurements(ref, scopesettings.measuresstate[side], x, ref->color);
    scope_roll_meas = 0;
    return;
  }

  if(!rolld.vis)
    return;

  roll_measure(ch, ch->tracebuffer, rolld.len, rolld.start + rolld.first, rolld.vis,
               rolld.peak ? rollf_pmin[side] : 0, rolld.peak ? rollf_pmax[side] : 0, scopesettings.timeperdiv);
  scope_roll_meas = 1;
  scope_display_channel_measurements(ch, scopesettings.measuresstate[side], x, side ? CHANNEL2_COLOR : CHANNEL1_COLOR);
  scope_roll_meas = 0;
}

void scope_roll_measurements(void)
{
  if(scopesettings.xymodedisplay)
    return;

  roll_measure_side(0);
  roll_measure_side(1);
}

//v1.00z0: the record in the order of the file: the ring turned so that the oldest column is at index 0 (three reversals,
//no extra memory), for SAVE WAVE; *count / *view for the file
static void roll_reverse(uint8 *b, uint32 from, uint32 to)
{
  uint8 t;

  while((from + 1) < to)
  {
    to--;
    t = b[from];
    b[from] = b[to];
    b[to] = t;
    from++;
  }
}

void scope_roll_linearize(uint32 *count, uint32 *view)
{
  uint32 s;
  uint8 *b[2] = { scopesettings.channel1.tracebuffer, scopesettings.channel2.tracebuffer };
  int    c;

  *count = 0;
  *view  = 0;

  if(!scope_roll_live() || !rollf.len || !rollf.count)
    return;

  s = rollf_start();

  if(s)
  {
    for(c = 0; c < 2; c++)
    {
      roll_reverse(b[c], 0, s);
      roll_reverse(b[c], s, rollf.len);
      roll_reverse(b[c], 0, rollf.len);

      //v1.00z5: the min / max ring stays in step with the means
      roll_reverse(rollf_pmin[c], 0, s);
      roll_reverse(rollf_pmin[c], s, rollf.len);
      roll_reverse(rollf_pmin[c], 0, rollf.len);
      roll_reverse(rollf_pmax[c], 0, s);
      roll_reverse(rollf_pmax[c], s, rollf.len);
      roll_reverse(rollf_pmax[c], 0, rollf.len);
    }

    //The oldest column is at 0 now; when full the next column overwrites it
    rollf.head = rollf.count % rollf.len;
  }

  *count = rollf.count;
  *view  = rollf.view;
}

//v1.00z0: the thumbnail of a roll save: the shown part (newest shown column at the right) in thumbnail columns 3 .. 169
//(as screen x 4 .. 726); returns 0 when there is no logger roll record
uint32 scope_roll_thumbnail(PTHUMBNAILDATA td)
{
  uint32 len, start, count, view, t;
  int32  x, idx, y, newest;

  if(scopesettings.waveviewmode && rollview_count)
  {
    len = MAX_SAMPLE_BUFFER_SIZE; start = 0; count = rollview_count; view = rollview_view;
  }
  else if(scope_roll_live() && rollf.len && rollf.count)
  {
    len = rollf.len; start = rollf_start(); count = rollf.count; view = rollf.view;
  }
  else
    return(0);

  newest = (int32)count - 1 - (int32)view;
  td->disp_xstart = 0;
  td->disp_xend   = 0;

  for(t = 3; t <= 169; t++)
  {
    x = (t * 42899) / 10000;

    if(x < ROLLF_X_FIRST) x = ROLLF_X_FIRST;
    if(x > ROLLF_X_LAST)  x = ROLLF_X_LAST;

    idx = newest - (ROLLF_X_LAST - x);

    if(idx < 0)
      continue;

    if(!td->disp_xstart)
      td->disp_xstart = t;

    td->disp_xend = t;

    if(scopesettings.channel1.enable)
    {
      y = scope_get_y_sample(&scopesettings.channel1, (start + idx) % len);
      if(y < 47) y = 47;
      td->channel1data[t - 3] = (uint8)(((y - 47) * 10000) / 42210);
    }

    if(scopesettings.channel2.enable)
    {
      y = scope_get_y_sample(&scopesettings.channel2, (start + idx) % len);
      if(y < 47) y = 47;
      td->channel2data[t - 3] = (uint8)(((y - 47) * 10000) / 42210);
    }
  }

  return(1);
}

//v1.00z0: a touch in the record scroll box with a roll record: after STOP (live) or in a saved roll file the shown part
//follows the finger (the window centred on it); 0 when it is not a roll record to scroll
uint32 scope_roll_slider_touch(void)
{
  uint32 viewer = scopesettings.waveviewmode && rollview_count;
  uint32 live   = scope_roll_live() && !scopesettings.runstate && rollf.len && rollf.count;
  uint32 count, vis;
  int32  centre, first;

  if(!viewer && !live)
    return(0);

  count = viewer ? rollview_count : rollf.count;
  vis   = (count < ROLLF_COLS) ? count : ROLLF_COLS;

  while(havetouch)
  {
    centre = (int32)((((int32)xtouch - 4) * (int64)count) / 723);
    first  = centre - (int32)(vis / 2);

    if(first < 0)
      first = 0;

    if(first > (int32)(count - vis))
      first = (int32)(count - vis);

    if(viewer)
    {
      rollview_view = count - vis - (uint32)first;
      scope_roll_view_draw();
    }
    else
    {
      rollf.view = count - vis - (uint32)first;
      rollf_draw();
    }

    tp_i2c_read_status();
  }

  return(1);
}

#if 0     //v1.01a0: replaced by the pass with the FPGA's window processing below
void scope_roll_logger_pass(void)
{
  uint32 tpd = scopesettings.timeperdiv, gap, k, added = 0;
  int32  n, v;
  uint8 *w;
  int32  c1a = scopesettings.channel1.adc1compensation, c1b = scopesettings.channel1.adc2compensation;
  int32  c2a = scopesettings.channel2.adc1compensation, c2b = scopesettings.channel2.adc2compensation;

  if(!scopesettings.runstate || (tpd >= ROLLF_TBS))
  {
    fpga_logger_stop(1);
    return;
  }

  //Trigger settings, time base or record length changed, or RUN after a Single record: a new record
  if((rollf.state == ROLLF_DONE) || !rollf.len || (rollf.cfg[0] != scopesettings.triggermode) || (rollf.cfg[1] != scopesettings.triggerchannel) ||
     (rollf.cfg[2] != scopesettings.triggeredge) || (rollf.cfg[3] != tpd) || (rollf.cfglen != rollf_length()))
  {
    rollf_reset();
    added = 1;
  }

  //Running: the newest columns are shown
  rollf.view = 0;

  if(!fpga_logger_running())
  {
    if(fpga_logger_start(rollf_div[tpd]))
    {
      //The stream does not start: stop, so the screen does not stand still without a word
      scopesettings.runstate = 0;
      scope_run_stop_text();

      if(scopesettings.rightmenustate == 0)
        scope_run_stop_button(0);

      return;
    }

    //The time between is not on the trace
    rollf.prev = -1;
    rollf_col_clear();     //v1.00z5
  }

  for(k = 0; k < 4; k++)
  {
    n = fpga_logger_read(rollf_words, 2048, &gap);

    if(n < 0)
      break;

    if(gap)
    {
      rollf.prev = -1;
      rollf_col_clear();     //v1.00z5
      continue;
    }

    if(n == 0)
      break;

    for(w = rollf_words; n > 0; n--, w += 4)
    {
      rollf.sum[0] += w[0];
      rollf.sum[1] += w[1];
      rollf.sum[2] += w[2];
      rollf.sum[3] += w[3];

      //v1.00z5: the extremes of the single samples (each core corrected as the normal readout: core A = adc1, B = adc2)
      v = w[0] + c1b; if(v < rollf.cmin[0]) rollf.cmin[0] = v; if(v > rollf.cmax[0]) rollf.cmax[0] = v;
      v = w[1] + c1a; if(v < rollf.cmin[0]) rollf.cmin[0] = v; if(v > rollf.cmax[0]) rollf.cmax[0] = v;
      v = w[2] + c2b; if(v < rollf.cmin[1]) rollf.cmin[1] = v; if(v > rollf.cmax[1]) rollf.cmax[1] = v;
      v = w[3] + c2a; if(v < rollf.cmin[1]) rollf.cmin[1] = v; if(v > rollf.cmax[1]) rollf.cmax[1] = v;

      if(++rollf.nw == rollf_wpc[tpd])
      {
        rollf_peak(&scopesettings.channel1, 0);
        rollf_peak(&scopesettings.channel2, 1);

        added |= rollf_add(rollf_code(&scopesettings.channel1, rollf.sum[0], rollf.sum[1], rollf.nw),
                           rollf_code(&scopesettings.channel2, rollf.sum[2], rollf.sum[3], rollf.nw));
        rollf_col_clear();
      }
    }
  }

  if(added)
    rollf_draw();
}

#endif

//v1.01a0: the logger roll with the FPGA's own window processing (0x2050 / 0x3050, 0x56 / 0x53): every logger word
//covers a window of N = divider + 1 raw samples at 200 MSa/s (both cores; twice the words of the sample skipping, so
//2 x wpc words per column, the column period stays). Peak / Pro (and Auto, Sin x): peak detect, a word holds { max, min }
//of its window, so a column has the lowest / highest of ALL samples of its time (no glitch lost); the column mean is
//the mean of the words' (min + max) / 2. Linear / Dots / Hi-Res: boxcar (K = 1), a word holds the sum of its window
//>> shift, so the column mean is the mean of all samples (no aliasing, less noise) and min / max are those of the
//word means. A change of the mode during RUN starts a new record. The sample skipping pass of v1.00z5 is kept below.
static uint8 rollf_hw = 0;          //what the running stream delivers: FLOG_SKIP / FLOG_PEAK / FLOG_BOXCAR
static uint8 rollf_hw_shift = 0;    //boxcar output shift
static uint32 rollf_hw_n = 1;       //raw samples per word

static uint32 rollf_hw_wanted(void)
{
  uint32 m = scope_roll_trace_mode();

  return(((m == 2) || (m == 3)) ? FLOG_PEAK : FLOG_BOXCAR);
}

//The column mean as a code: corrected with the mean of the two cores' compensations (a window has samples of both),
//clipped and inverted as rollf_code
static uint8 rollf_code_hw(PCHANNELSETTINGS s, uint32 sum, uint32 n)
{
  int32 v;

  if(rollf_hw == FLOG_PEAK)
    v = (int32)((sum + n) / (2 * n));
  else
    v = (int32)((((uint64)sum << rollf_hw_shift) + (((uint64)rollf_hw_n * n) / 2)) / ((uint64)rollf_hw_n * n));

  v += (s->adc1compensation + s->adc2compensation) / 2;

  if(v < 0)   v = 0;
  if(v > 255) v = 255;

  if(s->invert)
    v = 255 - v;

  return((uint8)v);
}

void scope_roll_logger_pass(void)
{
  uint32 tpd = scopesettings.timeperdiv, gap, k, added = 0, hw, wpc, c, lo, hi, x;
  int32  n, v, comp[2];
  uint8 *w;
  int32  c1a = scopesettings.channel1.adc1compensation, c1b = scopesettings.channel1.adc2compensation;
  int32  c2a = scopesettings.channel2.adc1compensation, c2b = scopesettings.channel2.adc2compensation;

  if(!scopesettings.runstate || (tpd >= ROLLF_TBS))
  {
    fpga_logger_stop(1);
    return;
  }

  hw = rollf_hw_wanted();

  //Trigger settings, time base or record length changed, RUN after a Single record, or the other window processing: a
  //new record (and the stream started again for it)
  if((rollf.state == ROLLF_DONE) || !rollf.len || (rollf.cfg[0] != scopesettings.triggermode) || (rollf.cfg[1] != scopesettings.triggerchannel) ||
     (rollf.cfg[2] != scopesettings.triggeredge) || (rollf.cfg[3] != tpd) || (rollf.cfglen != rollf_length()) ||
     (fpga_logger_running() && (rollf_hw != hw)))
  {
    if(fpga_logger_running() && (rollf_hw != hw))
      fpga_logger_stop(0);

    rollf_reset();
    added = 1;
  }

  //Running: the newest columns are shown
  rollf.view = 0;

  if(!fpga_logger_running())
  {
    if(fpga_logger_start(rollf_div[tpd], hw))
    {
      //The stream does not start: stop, so the screen does not stand still without a word
      scopesettings.runstate = 0;
      scope_run_stop_text();

      if(scopesettings.rightmenustate == 0)
        scope_run_stop_button(0);

      return;
    }

    rollf_hw       = (uint8)hw;
    rollf_hw_n     = fpga_logger_window(rollf_div[tpd]);
    rollf_hw_shift = (uint8)fpga_logger_shift(rollf_hw_n);

    //The time between is not on the trace
    rollf.prev = -1;
    rollf_col_clear();     //v1.00z5
  }

  wpc     = (rollf_hw == FLOG_SKIP) ? rollf_wpc[tpd] : (2 * rollf_wpc[tpd]);
  comp[0] = (c1a + c1b) / 2;
  comp[1] = (c2a + c2b) / 2;

  for(k = 0; k < 4; k++)
  {
    n = fpga_logger_read(rollf_words, 2048, &gap);

    if(n < 0)
      break;

    if(gap)
    {
      rollf.prev = -1;
      rollf_col_clear();     //v1.00z5
      continue;
    }

    if(n == 0)
      break;

    for(w = rollf_words; n > 0; n--, w += 4)
    {
      if(rollf_hw == FLOG_SKIP)
      {
        rollf.sum[0] += w[0];
        rollf.sum[1] += w[1];
        rollf.sum[2] += w[2];
        rollf.sum[3] += w[3];

        //v1.00z5: the extremes of the single samples (each core corrected as the normal readout: core A = adc1, B = adc2)
        v = w[0] + c1b; if(v < rollf.cmin[0]) rollf.cmin[0] = v; if(v > rollf.cmax[0]) rollf.cmax[0] = v;
        v = w[1] + c1a; if(v < rollf.cmin[0]) rollf.cmin[0] = v; if(v > rollf.cmax[0]) rollf.cmax[0] = v;
        v = w[2] + c2b; if(v < rollf.cmin[1]) rollf.cmin[1] = v; if(v > rollf.cmax[1]) rollf.cmax[1] = v;
        v = w[3] + c2a; if(v < rollf.cmin[1]) rollf.cmin[1] = v; if(v > rollf.cmax[1]) rollf.cmax[1] = v;
      }
      else
      {
        //Lanes per channel: w[0] / w[2] the high byte (0x21 / 0x23), w[1] / w[3] the low byte (0x20 / 0x22)
        for(c = 0; c < 2; c++)
        {
          hi = w[c * 2];
          lo = w[(c * 2) + 1];

          if(rollf_hw == FLOG_PEAK)
          {
            //{ max, min } of the window's raw codes
            rollf.sum[c * 2] += hi + lo;

            v = (int32)lo + comp[c]; if(v < rollf.cmin[c]) rollf.cmin[c] = v;
            v = (int32)hi + comp[c]; if(v > rollf.cmax[c]) rollf.cmax[c] = v;
          }
          else
          {
            //Boxcar: the window sum >> shift; the word's mean code for min / max
            x = (hi << 8) | lo;
            rollf.sum[c * 2] += x;

            v = (int32)(((x << rollf_hw_shift) + (rollf_hw_n / 2)) / rollf_hw_n) + comp[c];
            if(v < rollf.cmin[c]) rollf.cmin[c] = v;
            if(v > rollf.cmax[c]) rollf.cmax[c] = v;
          }
        }
      }

      if(++rollf.nw == wpc)
      {
        rollf_peak(&scopesettings.channel1, 0);
        rollf_peak(&scopesettings.channel2, 1);

        if(rollf_hw == FLOG_SKIP)
          added |= rollf_add(rollf_code(&scopesettings.channel1, rollf.sum[0], rollf.sum[1], rollf.nw),
                             rollf_code(&scopesettings.channel2, rollf.sum[2], rollf.sum[3], rollf.nw));
        else
          added |= rollf_add(rollf_code_hw(&scopesettings.channel1, rollf.sum[0], rollf.nw),
                             rollf_code_hw(&scopesettings.channel2, rollf.sum[2], rollf.nw));

        rollf_col_clear();
      }
    }
  }

  if(added)
    rollf_draw();
}

//v1.00z6: a REF moved up / down in the logger roll (move_refN_position): the record is drawn again with it (live: also
//after STOP, a saved roll file in the viewer as well); outside the roll the normal display loop draws it
void scope_roll_ref_moved(void)
{
  if(!scope_roll_ui())
    return;

  if(scopesettings.waveviewmode)
    scope_roll_view_draw();
  else
    rollf_draw();
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00z7: two REF sets, one of the normal time base and one of the logger roll (live roll or a saved roll file in the
//viewer, scope_roll_ui). The slots ch_ref1..8 / ref1..8_tracebuffer / ref1..8 always hold the set of the mode in use;
//the other set waits here. scope_refset_sync (main loop) swaps them when the mode changes, so each mode gets back its
//own REFs and their on / off states. The normal set keeps its whole buffers (16382 bytes), the roll set only its
//columns (ROLLF_COLS). The on / off states of both sets are saved with the settings (normal set in the old places,
//roll set as a bit mask at OTHER_REFROLL_OFFSET); with REF on startup the roll set's files come from \ref_roll\.
static struct
{
  CHANNELSETTINGS s;
  uint8 on;
} refset_bak[8];

#define REFSET_BYTES    (UINT32_SAMPLE_BUFFER_SIZE * 4)     //the size of ref1..8_tracebuffer

static uint8 refset_norm_data[8][REFSET_BYTES];
static uint8 refset_roll_data[8][ROLLF_COLS];
static uint8 refset_roll  = 0;      //1: the roll set is in the slots
static uint8 refset_ready = 0;      //refset_bak[].s set up from the slots

static uint8 *refset_flag(uint32 r)
{
  switch(r)
  {
    case 0:  return(&scopesettings.ref1);
    case 1:  return(&scopesettings.ref2);
    case 2:  return(&scopesettings.ref3);
    case 3:  return(&scopesettings.ref4);
    case 4:  return(&scopesettings.ref5);
    case 5:  return(&scopesettings.ref6);
    case 6:  return(&scopesettings.ref7);
    default: return(&scopesettings.ref8);
  }
}

static uint8 *refset_buf(uint32 r)
{
  switch(r)
  {
    case 0:  return((uint8 *)ref1_tracebuffer);
    case 1:  return((uint8 *)ref2_tracebuffer);
    case 2:  return((uint8 *)ref3_tracebuffer);
    case 3:  return((uint8 *)ref4_tracebuffer);
    case 4:  return((uint8 *)ref5_tracebuffer);
    case 5:  return((uint8 *)ref6_tracebuffer);
    case 6:  return((uint8 *)ref7_tracebuffer);
    default: return((uint8 *)ref8_tracebuffer);
  }
}

//The waiting set starts as an empty copy of the slots (colours, calibration), no REF data, its on states kept
static void refset_setup(void)
{
  uint32 r, on;

  if(refset_ready)
    return;

  for(r = 0; r < 8; r++)
  {
    memcpy(&refset_bak[r].s, roll_ref(r, &on), sizeof(CHANNELSETTINGS));
    refset_bak[r].s.sample1 = 0;
    memset(refset_norm_data[r], 128, REFSET_BYTES);
    memset(refset_roll_data[r], 128, ROLLF_COLS);
  }

  refset_ready = 1;
}

static void refset_swap(void)
{
  CHANNELSETTINGS t;
  PCHANNELSETTINGS s;
  uint8  *tb, *b, *f, on;
  PDISPLAYPOINTS tp;
  uint32 r, dummy;

  refset_setup();

  for(r = 0; r < 8; r++)
  {
    s  = roll_ref(r, &dummy);
    b  = refset_buf(r);
    f  = refset_flag(r);
    tb = s->tracebuffer;
    tp = s->tracepoints;

    //Settings and on state (the slot keeps its own buffer pointers)
    memcpy(&t, s, sizeof(CHANNELSETTINGS));
    memcpy(s, &refset_bak[r].s, sizeof(CHANNELSETTINGS));
    memcpy(&refset_bak[r].s, &t, sizeof(CHANNELSETTINGS));
    s->tracebuffer = tb;
    s->tracepoints = tp;

    on = *f;
    *f = refset_bak[r].on;
    refset_bak[r].on = on;

    //Data
    if(!refset_roll)
    {
      //normal -> roll
      memcpy(refset_norm_data[r], b, REFSET_BYTES);
      memcpy(b, refset_roll_data[r], ROLLF_COLS);
    }
    else
    {
      //roll -> normal
      memcpy(refset_roll_data[r], b, ROLLF_COLS);
      memcpy(b, refset_norm_data[r], REFSET_BYTES);
    }
  }

  refset_roll ^= 1;
}

void scope_refset_sync(void)
{
  if((scope_roll_ui() ? 1 : 0) != refset_roll)
    refset_swap();
}

//On / off state of REF r (0..7) of the normal (roll = 0) or the roll set, for saving the settings
uint8 scope_refset_get(uint32 roll, uint32 r)
{
  if(roll == refset_roll)
    return(*refset_flag(r));

  return(refset_bak[r].on);
}

//After the settings were loaded: the slots' on states are those of the normal set, mask the roll set's
void scope_refset_loaded(uint32 mask)
{
  uint32 r;
  uint8  on;

  for(r = 0; r < 8; r++)
  {
    on = (mask >> r) & 1;

    if(refset_roll)
    {
      //The roll set is in the slots: the loaded normal states go to the waiting set
      refset_bak[r].on = *refset_flag(r);
      *refset_flag(r) = on;
    }
    else
      refset_bak[r].on = on;
  }
}

//REF on startup: the roll set's files (\ref_roll\N.ref, only those there) into the roll set
void scope_refset_load_roll_files(void)
{
  char   name[16] = "\\ref_roll\\0.ref";
  uint32 r, was = refset_roll;

  if(!was)
    refset_swap();

  for(r = 0; r < 8; r++)
  {
    name[10] = '1' + r;

    if(f_stat(name, 0) == FR_OK)
    {
      view_ref_roll_force = 1;
      scope_load_REFx_item_file(r + 1);
      view_ref_roll_force = 0;
    }
  }

  if(!was)
    refset_swap();
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01a2: I2C decoder, stage 1. A layer of the scope view (normal time base, not X-Y, not roll / spectrum / Bode): SDA
//on CH1, SCL on CH2, both enabled. The record (the trace buffers as shown, also a saved waveform) is made digital per
//channel with a hysteresis around the middle of its min / max (50 %, more than 20 codes peak to peak needed), then:
//START / repeated START = SDA falls while SCL is high, STOP = SDA rises while SCL is high, a bit = SDA at the rising edge
//of SCL, 8 bits MSB first and the ACK bit (low = ACK) make a byte; the first byte after a START is the address (7 bit
//and R/W). Bytes before the first START in the record are skipped. Labels above the SDA trace: S (green), P (red),
//a box per byte with its value in hex (address orange with W / R, data blue, a NAK in red). A short tap on the labels
//opens the list of transactions (scope_i2c_list). Switched by "Decode I2C" in the channel menu (saved with the
//settings). Thresholds, 10 bit addresses, HEX / DEC follow in the next stage.

#define I2C_MAX_EV      600
#define I2C_EV_START    0
#define I2C_EV_RESTART  1
#define I2C_EV_STOP     2
#define I2C_EV_BYTE     3

typedef struct
{
  uint8 type;
  uint8 value;
  uint8 ack;          //1 ACK, 0 NAK
  uint8 addr;         //1: the address byte of a transaction, 2 (v1.01a3): the second byte of a 10 bit address
  uint16 a10;         //v1.01a3: the 10 bit address (addr = 2, or addr = 1 of a 10 bit read)
  int32 i0, i1;       //sample index: the event (S / P) or the first bit and the ACK bit (byte)
  uint8  line;        //v1.01b1: UART: 0 TX (CH1), 1 RX (CH2)
  uint8  flags;       //v1.01b1: UART bit 0 parity error, bit 1 framing error; SPI word bit 0 incomplete
  uint16 v16;         //v1.01b1: SPI word value (8 / 16 bit), UART value; bits of an incomplete SPI word in a10
  uint16 chk;         //v1.01b4: the right check value: LIN checksum (low byte classic, high byte enhanced), 1-Wire CRC
} I2CEVENT;

//v1.01b1: UART and SPI decoders next to I2C (the same layer, list and window). UART: TX on CH1, RX on CH2, both
//decoded (a channel switched off is skipped), baud rate from a list, 7 / 8 data bits, parity N / E / O, 1 / 2 stop
//bits, normal or inverted idle, LSB first; at least 3 samples per bit. SPI: SCLK on CH1, one data line on CH2 (MOSI,
//MISO or SDIO of 3 wire SPI), no CS: a frame ends where the clock pauses for more than 4 typical clock periods; mode
//0..3 (CPOL / CPHA: the data taken at the rising edge in modes 0 and 3, at the falling one in 1 and 2), MSB or LSB
//first, 8 or 16 bit words.
#define DEC_I2C         0
#define DEC_UART        1
#define DEC_SPI         2
#define DEC_EV_UART     4
#define DEC_EV_SPIFRAME 5
#define DEC_EV_SPIWORD  6
//v1.01b2: 1-Wire and LIN, on CH1 (CH2 with Swap)
#define DEC_1WIRE       3
#define DEC_LIN         4
#define DEC_PROTOS      5
#define DEC_EV_OWRESET  7
#define DEC_EV_OWBYTE   8
#define DEC_EV_LINBREAK 9
#define DEC_EV_LINBYTE  10

uint8  scope_dec_swap       = 0;     //v1.01b2: the two channels' roles swapped (SDA / SCL, TX / RX, SCLK / data, line CH2)
uint8  scope_ow_overdrive   = 0;     //v1.01b2: 1-Wire overdrive timing
uint8  scope_lin_baud       = 5;     //v1.01b2: index into lin_bauds
uint8  scope_lin_ver        = 0;     //v1.01b4: LIN version of the checksum: 0 Auto (classic or enhanced), 1 LIN 1.x (classic), 2 LIN 2.x (enhanced, classic for the IDs 3C / 3D)
uint8  scope_dec_start_on   = 0;     //v1.01b2: start settings (Settings > Measure > Decoder)
uint8  scope_dec_start_proto = 0;    //0 the last one, 1.. I2C, UART, SPI, 1-Wire, LIN
uint8  scope_dec_start_auto = 0;
uint8  scope_dec_btn_on     = 0;     //v1.01b6: the Decode button of CTRL switches the decoder on (Settings > Measure > Decoder)
uint8  scope_dec_trig       = 0;     //v1.01b8: decoder trigger (I2C): 0 off, 1 a NACK, 2 the address scope_dec_trig_addr; RUN stops when found
uint8  scope_dec_trig_addr  = 0x68;
static uint8 dec_trig_hit   = 0;

#define LIN_BAUDS       7
static const uint32 lin_bauds[LIN_BAUDS] = { 1200, 2400, 4800, 9600, 10417, 19200, 20000 };

static const char *const dec_names[DEC_PROTOS] = { "I2C", "UART", "SPI", "1-Wire", "LIN" };

uint8  scope_dec_proto   = DEC_I2C;
uint8  scope_uart_baud   = 5;        //index into uart_bauds
uint8  scope_uart_7bit   = 0;
uint8  scope_uart_parity = 0;        //0 none, 1 even, 2 odd
uint8  scope_uart_stop2  = 0;
uint8  scope_uart_inv    = 0;
uint8  scope_spi_mode    = 0;
uint8  scope_spi_lsb     = 0;
uint8  scope_spi_16      = 0;

#define UART_BAUDS      18
static const uint32 uart_bauds[UART_BAUDS] =
{
  300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 38400, 57600, 115200, 230400, 250000, 460800, 500000, 921600,
  1000000, 2000000
};

static uint8  dec_err = 0;           //1: too few samples per UART bit
static int32  dec_band2_y = -1;      //UART RX / SPI data band (above CH2)

uint8 scope_i2c_enabled = 0;

//v1.01a3: decoder settings (saved with the settings): threshold automatic (50 % of each channel's swing) or manual in
//mV per channel (SDA, SCL), 10 bit addresses, values in decimal
uint8  scope_i2c_thr_auto = 1;
int32  scope_i2c_thr_mv[2] = { 1650, 1650 };
uint8  scope_i2c_addr10 = 0;
uint8  scope_i2c_dec = 0;

static I2CEVENT i2c_ev[I2C_MAX_EV];
static uint32   i2c_nev    = 0;
static int32    i2c_band_y = -1;      //screen y of the label band, -1 none drawn

static const char i2c_hexd[] = "0123456789ABCDEF";

static void i2c_hex2(char *p, uint8 v)
{
  p[0] = i2c_hexd[v >> 4];
  p[1] = i2c_hexd[v & 15];
}

//Min, max and the index of the max of a trace buffer
static void i2c_minmax(const uint8 *b, uint32 n, int32 *mn, int32 *mx, uint32 *imax)
{
  uint32 i;

  *mn = 255;
  *mx = 0;
  *imax = 0;

  for(i = 0; i < n; i++)
  {
    if(b[i] < *mn) *mn = b[i];
    if(b[i] > *mx) { *mx = b[i]; *imax = i; }
  }
}

static void i2c_add(uint8 type, int32 i0, int32 i1, uint8 value, uint8 ack, uint8 addr)
{
  if(i2c_nev >= I2C_MAX_EV)
    return;

  i2c_ev[i2c_nev].type  = type;
  i2c_ev[i2c_nev].i0    = i0;
  i2c_ev[i2c_nev].i1    = i1;
  i2c_ev[i2c_nev].value = value;
  i2c_ev[i2c_nev].ack   = ack;
  i2c_ev[i2c_nev].addr  = addr;
  i2c_ev[i2c_nev].a10   = 0;
  i2c_ev[i2c_nev].line  = 0;
  i2c_ev[i2c_nev].flags = 0;
  i2c_ev[i2c_nev].v16   = value;
  i2c_ev[i2c_nev].chk   = 0;     //v1.01b4
  i2c_nev++;
}

//v1.01a3: SCL above its upper threshold from 2 samples before to 2 samples after i
static uint32 i2c_scl_high(const uint8 *scl, uint32 n, uint32 i, int32 h)
{
  uint32 a = (i >= 2) ? (i - 2) : 0, b = ((i + 2) < n) ? (i + 2) : (n - 1), k;

  for(k = a; k <= b; k++)
    if(scl[k] <= h)
      return(0);

  return(1);
}

//v1.01a3: the voltage of a sample code in mV, as the measurements show it (scope_display_voltage, DC shift included)
static int32 i2c_code_mv(PCHANNELSETTINGS s, int32 code)
{
  PVOLTCALCDATA vcd = (PVOLTCALCDATA)&volt_calc_data[s->magnification][s->displayvoltperdiv];
  int32  v;
  double mv;
  int32  sc;

  if(s->dc_shift_value)
    code += (s->dcoffset * 100) / s->dc_shift_value;

  v = ((code - 128) * s->input_calibration[s->samplevoltperdiv]) >> VOLTAGE_SHIFTER;

  if(s->displayvoltperdiv != s->samplevoltperdiv)
    v = (v * vertical_scaling_factors[s->displayvoltperdiv][s->samplevoltperdiv]) / 10000;

  //scope_print_value: 2 decimals at the magnitude volt_scale (3 = m, 4 = unit)
  mv = (double)v * (double)vcd->mul_factor / 100.0;

  for(sc = vcd->volt_scale; sc > 3; sc--) mv *= 1000.0;
  for(; sc < 3; sc++) mv /= 1000.0;

  return((int32)mv);
}

//The sample code nearest to a voltage in mV
static int32 i2c_mv_code(PCHANNELSETTINGS s, int32 mv)
{
  int32 c, best = 128, d, bd = 0x7FFFFFFF;

  for(c = 0; c < 256; c++)
  {
    d = i2c_code_mv(s, c) - mv;

    if(d < 0)
      d = -d;

    if(d < bd)
    {
      bd = d;
      best = c;
    }
  }

  return(best);
}

#if 0     //v1.01b6: the labels use i2ct_num (the List formats)
//v1.01a3: a value as text, hex (2 digits) or decimal; returns the end
static char *i2c_val(char *p, uint32 v, uint32 hexdigits)
{
  if(scope_i2c_dec)
    return(scope_print_decimal(p, (int32)v, 0, 0));

  if(hexdigits > 2)
    *p++ = i2c_hexd[(v >> 8) & 15];

  i2c_hex2(p, (uint8)v);
  p[2] = 0;
  return(p + 2);
}
#endif

//Decode the record; returns 0 when there is nothing to decode (channels off, too small signals)
static uint32 i2c_decode(void)
{
  //v1.01b2: Swap: SDA on CH2, SCL on CH1
  PCHANNELSETTINGS csda = scope_dec_swap ? &scopesettings.channel2 : &scopesettings.channel1;
  PCHANNELSETTINGS cscl = scope_dec_swap ? &scopesettings.channel1 : &scopesettings.channel2;
  const uint8 *sda = csda->tracebuffer;
  const uint8 *scl = cscl->tracebuffer;
  uint32 n = fpgasettings.totalsamples, i, imax, dummy;
  int32  mn1, mx1, mn2, mx2, h1, l1, h2, l2, bits = 0, bstart = 0;
  uint8  d, c, pd, pc, inframe = 0, first = 0, byte = 0, a10hi = 0, a10next = 0;

  i2c_nev = 0;

  if(!scopesettings.channel1.enable || !scopesettings.channel2.enable || (n < 16) || (n > MAX_SAMPLE_BUFFER_SIZE))
    return(0);

  i2c_minmax(sda, n, &mn1, &mx1, &imax);
  i2c_minmax(scl, n, &mn2, &mx2, &dummy);

  if(((mx1 - mn1) < 20) || ((mx2 - mn2) < 20))
    return(0);

  //Hysteresis +-1/6 of the swing around the middle
  h1 = ((mx1 + mn1) / 2) + ((mx1 - mn1) / 6);
  l1 = ((mx1 + mn1) / 2) - ((mx1 - mn1) / 6);
  h2 = ((mx2 + mn2) / 2) + ((mx2 - mn2) / 6);
  l2 = ((mx2 + mn2) / 2) - ((mx2 - mn2) / 6);

  //v1.01a3: manual threshold: the code of the voltage, hysteresis +-1/12 of the swing (at least 2 codes)
  if(!scope_i2c_thr_auto)
  {
    int32 t1 = i2c_mv_code(csda, scope_i2c_thr_mv[scope_dec_swap ? 1 : 0]);     //v1.01b2: the thresholds stay with the channels
    int32 t2 = i2c_mv_code(cscl, scope_i2c_thr_mv[scope_dec_swap ? 0 : 1]);
    int32 y1 = ((mx1 - mn1) / 12 < 2) ? 2 : ((mx1 - mn1) / 12);
    int32 y2 = ((mx2 - mn2) / 12 < 2) ? 2 : ((mx2 - mn2) / 12);

    h1 = t1 + y1; l1 = t1 - y1;
    h2 = t2 + y2; l2 = t2 - y2;
  }

  pd = (sda[0] > ((h1 + l1) / 2));
  pc = (scl[0] > ((h2 + l2) / 2));

  for(i = 1; i < n; i++)
  {
    d = (sda[i] > h1) ? 1 : (sda[i] < l1) ? 0 : pd;
    c = (scl[i] > h2) ? 1 : (scl[i] < l2) ? 0 : pc;

    //v1.01a3: a START / STOP only with SCL really high (above its upper threshold) 2 samples before and after the SDA
    //change: SDA released right after the falling SCL of the ACK made false STOPs before
    if(pc && c && (d != pd) && i2c_scl_high(scl, n, i, h2))
    {
      //SDA changes while SCL is high: START / repeated START or STOP
      if(!d)
      {
        i2c_add(inframe ? I2C_EV_RESTART : I2C_EV_START, i, i, 0, 0, 0);
        inframe = 1;
        first   = 1;
        bits    = 0;
        byte    = 0;
      }
      else if(inframe)
      {
        i2c_add(I2C_EV_STOP, i, i, 0, 0, 0);
        inframe = 0;
      }
    }
    else if(!pc && c && inframe)
    {
      //SCL rising: a bit
      if(bits == 0)
        bstart = i;

      if(bits < 8)
      {
        byte = (uint8)((byte << 1) | d);
        bits++;
      }
      else
      {
        i2c_add(I2C_EV_BYTE, bstart, i, byte, d ? 0 : 1, first);

        //v1.01a3: 10 bit address: 11110 a9 a8 R/W, then (write) the low 8 bits as the next byte
        if(scope_i2c_addr10 && i2c_nev)
        {
          I2CEVENT *ev = &i2c_ev[i2c_nev - 1];

          if(first && ((byte & 0xF8) == 0xF0))
          {
            a10hi = (byte >> 1) & 3;
            ev->a10 = (uint16)(a10hi << 8);
            a10next = !(byte & 1);
          }
          else if(a10next)
          {
            ev->addr = 2;
            ev->a10  = (uint16)((a10hi << 8) | byte);
            a10next  = 0;
          }
        }

        first = 0;
        bits  = 0;
        byte  = 0;
      }
    }

    pd = d;
    pc = c;
  }

  //The label band: above the highest SDA sample
  i2c_band_y = scope_get_y_sample(csda, imax) - 20;     //v1.01b2: the SDA channel

  if(i2c_band_y < 50)  i2c_band_y = 50;
  if(i2c_band_y > 420) i2c_band_y = 420;

  return(1);
}

//v1.01b1: the levels of a channel for UART / SPI as I2C makes them (auto 50 % or the manual mV, hysteresis); the
//digital record into dig; 0 when the swing is below 20 codes. *imax the index of the highest sample (label band).
static uint8 dec_dig[2][MAX_SAMPLE_BUFFER_SIZE];

static uint32 dec_digital(uint32 c, uint32 n, uint32 *imax)
{
  PCHANNELSETTINGS ch = c ? &scopesettings.channel2 : &scopesettings.channel1;
  const uint8 *b = ch->tracebuffer;
  uint8 *d = dec_dig[c];
  int32 mn, mx, h, l, t, y;
  uint32 i;
  uint8 pv;

  i2c_minmax(b, n, &mn, &mx, imax);

  if((mx - mn) < 20)
    return(0);

  h = ((mx + mn) / 2) + ((mx - mn) / 6);
  l = ((mx + mn) / 2) - ((mx - mn) / 6);

  if(!scope_i2c_thr_auto)
  {
    t = i2c_mv_code(ch, scope_i2c_thr_mv[c]);
    y = ((mx - mn) / 12 < 2) ? 2 : ((mx - mn) / 12);
    h = t + y;
    l = t - y;
  }

  pv = (b[0] > ((h + l) / 2));

  for(i = 0; i < n; i++)
  {
    pv = (b[i] > h) ? 1 : (b[i] < l) ? 0 : pv;
    d[i] = pv;
  }

  return(1);
}

//v1.01b8: the baud rate measured from the record (UART: both lines when on, LIN / others: CH1, CH2 with Swap): the
//shortest pulse is about one bit; the pulses up to 12 bits long, each divided by its number of bits, give the bit time
//on average. 0 when there are too few edges.
static uint32 dec_measure_baud(void)
{
  uint32 n = fpgasettings.totalsamples, sr = scopesettings.samplerate, c, i, last, run, m = 0xFFFFFFFF, imax, runs = 0;
  uint32 cmin, cmax;
  double total = 0.0, bits = 0.0, k;

  if((n < 16) || (n > MAX_SAMPLE_BUFFER_SIZE))
    return(0);

  if(sr >= (sizeof(sample_rate) / sizeof(sample_rate[0])))
    sr = 0;

  if(scope_dec_proto == DEC_UART)
  {
    cmin = 0;
    cmax = 1;
  }
  else
    cmin = cmax = scope_dec_swap ? 1 : 0;

  //The shortest pulse (2 samples at least), not the first and last ones (cut by the record)
  for(c = cmin; c <= cmax; c++)
  {
    if(!(c ? scopesettings.channel2.enable : scopesettings.channel1.enable) || !dec_digital(c, n, &imax))
      continue;

    for(i = 1, last = 0; i < n; i++)
    {
      if(dec_dig[c][i] == dec_dig[c][i - 1])
        continue;

      run = i - last;

      if(last && (run >= 2) && (run < m))
        m = run;

      if(last)
        runs++;

      last = i;
    }
  }

  if((runs < 4) || (m == 0xFFFFFFFF))
    return(0);

  for(c = cmin; c <= cmax; c++)
  {
    if(!(c ? scopesettings.channel2.enable : scopesettings.channel1.enable) || !dec_digital(c, n, &imax))
      continue;

    for(i = 1, last = 0; i < n; i++)
    {
      if(dec_dig[c][i] == dec_dig[c][i - 1])
        continue;

      run = i - last;

      if(last && (run >= 2) && (run <= (12 * m)))
      {
        k = (double)(uint32)(((double)run / (double)m) + 0.5);

        if(k < 1.0)
          k = 1.0;

        total += (double)run;
        bits  += k;
      }

      last = i;
    }
  }

  if(bits < 1.0)
    return(0);

  return((uint32)(((double)sample_rate[sr] * bits / total) + 0.5));
}

//v1.01b8: the nearest rate of a table to the measured one (by ratio); -1 when nothing was measured
static int32 dec_nearest_baud(const uint32 *tab, uint32 n)
{
  uint32 b = dec_measure_baud(), i;
  int32  best = -1;
  double d, bd = 1e9;

  if(!b)
    return(-1);

  for(i = 0; i < n; i++)
  {
    d = ((double)tab[i] > (double)b) ? ((double)tab[i] / (double)b) : ((double)b / (double)tab[i]);

    if(d < bd)
    {
      bd   = d;
      best = (int32)i;
    }
  }

  return(best);
}

static int32 dec_band(PCHANNELSETTINGS ch, uint32 imax)
{
  int32 y = scope_get_y_sample(ch, imax) - 20;

  if(y < 50)  y = 50;
  if(y > 420) y = 420;

  return(y);
}

static uint32 uart_decode(void)
{
  uint32 n = fpgasettings.totalsamples, sr = scopesettings.samplerate, c, imax, nb = scope_uart_7bit ? 7 : 8;
  uint32 i, k, v, bit, ones, flags, idle = scope_uart_inv ? 0 : 1, any = 0;
  double spb, pos;
  int32  pi;
  PCHANNELSETTINGS ch;

  i2c_nev  = 0;
  dec_err  = 0;

  if((n < 16) || (n > MAX_SAMPLE_BUFFER_SIZE))
    return(0);

  if(sr >= (sizeof(sample_rate) / sizeof(sample_rate[0])))
    sr = 0;

  spb = (double)sample_rate[sr] / (double)uart_bauds[scope_uart_baud % UART_BAUDS];

  if(spb < 3.0)
  {
    dec_err = 1;
    return(0);
  }

  for(c = 0; c < 2; c++)
  {
    ch = c ? &scopesettings.channel2 : &scopesettings.channel1;

    if(!ch->enable || !dec_digital(c, n, &imax))
      continue;

    if(c) dec_band2_y = dec_band(ch, imax);
    else  i2c_band_y  = dec_band(ch, imax);

    //v1.01b2: the band of CH1 is i2c_band_y, of CH2 dec_band2_y; line = TX / RX (CH1 / CH2, swapped with Swap)

    any = 1;

    for(i = 1; i < n; i++)
    {
      //A start bit: the line leaves idle
      if(!((dec_dig[c][i - 1] == idle) && (dec_dig[c][i] != idle)))
        continue;

      pos = (double)i + (spb * 0.5);

      if(((uint32)pos >= n) || (dec_dig[c][(uint32)pos] == idle))
        continue;

      //Data bits, LSB first, at their middles
      for(k = 0, v = 0, ones = 0; k < nb; k++)
      {
        pi = (int32)((double)i + (spb * (1.5 + k)));

        if(pi >= (int32)n)
          break;

        bit = (dec_dig[c][pi] == idle) ? 1 : 0;
        v |= bit << k;
        ones += bit;
      }

      if(k < nb)
        break;

      flags = 0;
      k = 1 + nb;

      if(scope_uart_parity)
      {
        pi = (int32)((double)i + (spb * (k + 0.5)));

        if(pi >= (int32)n)
          break;

        bit = (dec_dig[c][pi] == idle) ? 1 : 0;
        ones += bit;

        //Even: the ones with the parity bit even; odd: odd
        if((ones & 1) != ((scope_uart_parity == 2) ? 1 : 0))
          flags |= 1;

        k++;
      }

      pi = (int32)((double)i + (spb * (k + 0.5)));

      if(pi >= (int32)n)
        break;

      if(dec_dig[c][pi] != idle)
        flags |= 2;

      i2c_add(DEC_EV_UART, (int32)i, (int32)((double)i + (spb * (k + (scope_uart_stop2 ? 2 : 1)))), (uint8)v, 0, 0);
      i2c_ev[i2c_nev - 1].line  = (uint8)(c ^ scope_dec_swap);     //v1.01b2
      i2c_ev[i2c_nev - 1].flags = (uint8)flags;
      i2c_ev[i2c_nev - 1].v16   = (uint16)v;

      //On after the middle of the stop bit
      i = (uint32)pi;
    }
  }

  //TX and RX in time order (insertion, the lists are short)
  for(i = 1; i < i2c_nev; i++)
  {
    I2CEVENT t = i2c_ev[i];

    for(k = i; (k > 0) && (i2c_ev[k - 1].i0 > t.i0); k--)
      i2c_ev[k] = i2c_ev[k - 1];

    i2c_ev[k] = t;
  }

  return(any);
}

static int32 spi_edges[8192];

static uint32 spi_decode(void)
{
  uint32 n = fpgasettings.totalsamples, imax, dummy, i, ne = 0, k, m, bits = 0, wbits = scope_spi_16 ? 16 : 8;
  uint32 rising = !(((scope_spi_mode >> 1) ^ scope_spi_mode) & 1), word = 0;
  int32  iv[64], gap, prev = -0x7FFFFFFF, wstart = 0, t;

  i2c_nev = 0;
  dec_err = 0;

  if(!scopesettings.channel1.enable || !scopesettings.channel2.enable || (n < 16) || (n > MAX_SAMPLE_BUFFER_SIZE))
    return(0);

  //v1.01b2: Swap: SCLK on CH2, data on CH1
  {
    uint32 ck = scope_dec_swap ? 1 : 0;

    if(!dec_digital(ck, n, &dummy) || !dec_digital(ck ^ 1, n, &imax))
      return(0);

    if(ck) i2c_band_y  = dec_band(&scopesettings.channel1, imax);
    else   dec_band2_y = dec_band(&scopesettings.channel2, imax);

    //The data edges of the clock
    for(i = 1; (i < n) && (ne < 8192); i++)
      if((dec_dig[ck][i] != dec_dig[ck][i - 1]) && (dec_dig[ck][i] == (rising ? 1 : 0)))
        spi_edges[ne++] = (int32)i;
  }

  if(ne < 2)
    return(1);

  //The typical clock period: the median of the first intervals; a frame gap is more than 4 of them
  for(m = 0; (m < 64) && ((m + 1) < ne); m++)
    iv[m] = spi_edges[m + 1] - spi_edges[m];

  for(i = 1; i < m; i++)
  {
    t = iv[i];

    for(k = i; (k > 0) && (iv[k - 1] > t); k--)
      iv[k] = iv[k - 1];

    iv[k] = t;
  }

  gap = 4 * iv[m / 2];

  if(gap < 3)
    gap = 3;

  for(i = 0; i < ne; i++)
  {
    int32 e = spi_edges[i];

    if((i == 0) || ((e - prev) > gap))
    {
      //A new frame: a word not finished is shown with its bits
      if(bits)
      {
        i2c_add(DEC_EV_SPIWORD, wstart, prev, (uint8)word, 0, 0);
        i2c_ev[i2c_nev - 1].v16   = (uint16)word;
        i2c_ev[i2c_nev - 1].flags = 1;
        i2c_ev[i2c_nev - 1].a10   = (uint16)bits;
      }

      i2c_add(DEC_EV_SPIFRAME, e, e, 0, 0, 0);
      bits = 0;
      word = 0;
    }

    if(bits == 0)
      wstart = e;

    //The data line at the edge
    if(scope_spi_lsb)
      word |= (uint32)dec_dig[scope_dec_swap ? 0 : 1][e] << bits;
    else
      word = (word << 1) | dec_dig[scope_dec_swap ? 0 : 1][e];

    if(++bits == wbits)
    {
      i2c_add(DEC_EV_SPIWORD, wstart, e, (uint8)word, 0, 0);
      i2c_ev[i2c_nev - 1].v16 = (uint16)word;
      bits = 0;
      word = 0;
    }

    prev = e;
  }

  if(bits)
  {
    i2c_add(DEC_EV_SPIWORD, wstart, prev, (uint8)word, 0, 0);
    i2c_ev[i2c_nev - 1].v16   = (uint16)word;
    i2c_ev[i2c_nev - 1].flags = 1;
    i2c_ev[i2c_nev - 1].a10   = (uint16)bits;
  }

  return(1);
}

//v1.01b2: the line of 1-Wire / LIN: CH1, CH2 with Swap; its band
static uint32 dec_line(uint32 n, uint32 *c)
{
  PCHANNELSETTINGS ch;
  uint32 imax;

  *c = scope_dec_swap ? 1 : 0;
  ch = *c ? &scopesettings.channel2 : &scopesettings.channel1;

  if(!ch->enable || (n < 16) || (n > MAX_SAMPLE_BUFFER_SIZE) || !dec_digital(*c, n, &imax))
    return(0);

  if(*c) dec_band2_y = dec_band(ch, imax);
  else   i2c_band_y  = dec_band(ch, imax);

  return(1);
}

//v1.01b2: 1-Wire: the low pulses of the line (idle high). A low of 480 us and more (overdrive 48 us) is a RESET; a low
//of 60..300 us (overdrive 6..30) starting within 80 us (8) after the reset ends is the slaves' presence (flags bit 0
//of the reset); a low shorter than 15 us (2) is a 1 bit, longer (up to 120 us, overdrive 16) a 0 bit; 8 bits LSB first
//make a byte. Read slots look the same (the slave holds the line low for a 0). At least 1 sample per 2 us (0.25 us).
static uint32 ow_decode(void)
{
  uint32 n = fpgasettings.totalsamples, sr = scopesettings.samplerate, c, i, a, bits = 0, v = 0, bstart = 0;
  double us;
  int32  lastreset = -1, resetend = 0;
  uint32 od = scope_ow_overdrive;

  i2c_nev = 0;
  dec_err = 0;

  if(sr >= (sizeof(sample_rate) / sizeof(sample_rate[0])))
    sr = 0;

  us = 1000000.0 / (double)sample_rate[sr];     //us per sample

  if(us > (od ? 0.25 : 2.0))
  {
    dec_err = 1;
    return(0);
  }

  if(!dec_line(n, &c))
    return(0);

  for(i = 1; i < n; i++)
  {
    double dur, after;

    if(!(dec_dig[c][i - 1] && !dec_dig[c][i]))
      continue;

    //A low pulse from i to a
    for(a = i; (a < n) && !dec_dig[c][a]; a++);

    if(a >= n)
      break;

    dur = (double)(a - i) * us;

    if(dur >= (od ? 48.0 : 480.0))
    {
      i2c_add(DEC_EV_OWRESET, (int32)i, (int32)a, 0, 0, 0);
      lastreset = (int32)(i2c_nev - 1);
      resetend  = (int32)a;
      bits = 0;
      v    = 0;
    }
    else if((lastreset >= 0) && ((after = (double)((int32)i - resetend) * us) <= (od ? 8.0 : 80.0)) &&
            (dur >= (od ? 6.0 : 60.0)) && (dur <= (od ? 30.0 : 300.0)) && !(i2c_ev[lastreset].flags & 1))
    {
      //The presence pulse
      i2c_ev[lastreset].flags |= 1;
      i2c_ev[lastreset].i1 = (int32)a;
      (void)after;
    }
    else if(dur <= (od ? 16.0 : 120.0))
    {
      if(bits == 0)
        bstart = i;

      if(dur < (od ? 2.0 : 15.0))
        v |= 1 << bits;

      if(++bits == 8)
      {
        i2c_add(DEC_EV_OWBYTE, (int32)bstart, (int32)a, (uint8)v, 0, 0);
        bits = 0;
        v    = 0;
      }
    }

    i = a;
  }

  return(1);
}

//v1.01b4: the checksum type the LIN version wants for a PID: 1 classic, 2 enhanced (LIN 2.x: classic for the
//diagnostic frames 3C / 3D), 0 Auto (either)
static uint32 lin_sum_want(uint32 pid)
{
  if(scope_lin_ver == 1)
    return(1);

  if(scope_lin_ver == 2)
    return((((pid & 0x3F) == 0x3C) || ((pid & 0x3F) == 0x3D)) ? 1 : 2);

  return(0);
}

static uint32 lin_sum_ok(uint32 got, uint32 pid)
{
  uint32 w = lin_sum_want(pid);

  return(w ? (got == w) : (got != 0));
}

//v1.01b2: LIN: a BREAK is the line low for 11 bit times and more; then the bytes as UART 8N1 at the LIN baud rate:
//SYNC (0x55), PID (6 bit ID + 2 parity bits), data, and the last byte before the next BREAK (or the end) is the
//checksum (classic: the data, enhanced: PID + data, sum with carry, inverted). addr = 0 SYNC, 1 PID, 2 data,
//3 checksum; flags bit 1 framing, 2 SYNC not 0x55, 3 PID parity, 4 checksum; a10 of the checksum 1 classic, 2 enhanced.
static uint32 lin_decode(void)
{
  uint32 n = fpgasettings.totalsamples, sr = scopesettings.samplerate, c, i, a, k, v, bit, role = 2, fstart = 0, e;
  double sb;
  int32  pi;

  i2c_nev = 0;
  dec_err = 0;

  if(sr >= (sizeof(sample_rate) / sizeof(sample_rate[0])))
    sr = 0;

  sb = (double)sample_rate[sr] / (double)lin_bauds[scope_lin_baud % LIN_BAUDS];

  if(sb < 3.0)
  {
    dec_err = 1;
    return(0);
  }

  if(!dec_line(n, &c))
    return(0);

  for(i = 1; i < n; i++)
  {
    if(!(dec_dig[c][i - 1] && !dec_dig[c][i]))
      continue;

    for(a = i; (a < n) && !dec_dig[c][a]; a++);

    //BREAK
    if((double)(a - i) >= (11.0 * sb))
    {
      i2c_add(DEC_EV_LINBREAK, (int32)i, (int32)a, 0, 0, 0);
      role = 0;
      i = a;
      continue;
    }

    //A byte 8N1 from the start bit at i
    for(k = 0, v = 0; k < 8; k++)
    {
      pi = (int32)((double)i + (sb * (1.5 + k)));

      if(pi >= (int32)n)
        break;

      bit = dec_dig[c][pi];
      v |= bit << k;
    }

    if(k < 8)
      break;

    pi = (int32)((double)i + (sb * 9.5));

    if(pi >= (int32)n)
      break;

    i2c_add(DEC_EV_LINBYTE, (int32)i, (int32)((double)i + (sb * 10.0)), (uint8)v, 0, (uint8)((role > 2) ? 2 : role));
    i2c_ev[i2c_nev - 1].flags = dec_dig[c][pi] ? 0 : 2;

    if(role == 0)
    {
      if(v != 0x55)
        i2c_ev[i2c_nev - 1].flags |= 4;
    }
    else if(role == 1)
    {
      //PID parity: P0 = ID0 ^ ID1 ^ ID2 ^ ID4, P1 = !(ID1 ^ ID3 ^ ID4 ^ ID5)
      uint32 id = v & 0x3F, p0, p1;

      p0 = ((id >> 0) ^ (id >> 1) ^ (id >> 2) ^ (id >> 4)) & 1;
      p1 = (~((id >> 1) ^ (id >> 3) ^ (id >> 4) ^ (id >> 5))) & 1;

      if((v >> 6) != (p0 | (p1 << 1)))
        i2c_ev[i2c_nev - 1].flags |= 8;
    }

    role++;
    i = (uint32)pi;
  }

  //The checksums: the last byte of every frame (after SYNC, PID and at least one data byte)
  for(e = 0; e <= i2c_nev; e++)
  {
    if((e == i2c_nev) || (i2c_ev[e].type == DEC_EV_LINBREAK))
    {
      //The frame from fstart to e - 1: SYNC, PID, data ..., checksum
      if((e >= (fstart + 4)) && (i2c_ev[fstart].type == DEC_EV_LINBYTE) && (i2c_ev[fstart].addr == 0))
      {
        uint32 sum = 0, f, pid = i2c_ev[fstart + 1].value, ck = i2c_ev[e - 1].value, cls, enh;

        for(f = fstart + 2; f < (e - 1); f++)
        {
          sum += i2c_ev[f].value;
          if(sum > 255) sum -= 255;
        }

        cls = (~sum) & 0xFF;
        sum += pid;
        if(sum > 255) sum -= 255;
        enh = (~sum) & 0xFF;

        i2c_ev[e - 1].addr = 3;
        i2c_ev[e - 1].a10  = (ck == enh) ? 2 : (ck == cls) ? 1 : 0;
        //v1.01b4: both right sums kept for the List (low byte classic, high byte enhanced), checked by the LIN version
        i2c_ev[e - 1].chk  = (uint16)(cls | (enh << 8));

        //if(!i2c_ev[e - 1].a10)
        if(!lin_sum_ok(i2c_ev[e - 1].a10, pid))
          i2c_ev[e - 1].flags |= 16;
      }

      fstart = e + 1;
    }
  }

  return(1);
}

//v1.01b1: the decoder of the chosen protocol
static uint32 dec_decode(void)
{
  i2c_band_y  = -1;
  dec_band2_y = -1;

  if(scope_dec_proto == DEC_UART)
    return(uart_decode());

  if(scope_dec_proto == DEC_SPI)
    return(spi_decode());

  //v1.01b2
  if(scope_dec_proto == DEC_1WIRE)
    return(ow_decode());

  if(scope_dec_proto == DEC_LIN)
    return(lin_decode());

  return(i2c_decode());
}

static int32 i2c_x(int32 idx)
{
  return(disp_xstart + (int32)(((double)idx - (double)disp_first_sample) / disp_sample_step));
}

#if 0     //v1.01b6: the labels of v1.01b2 (HEX / DEC of the window, one row)
//The layer, from scope_display_trace_data (after REF / MATH)
void scope_i2c_display(void)
{
  uint32 e;
  int32  x0, x1, hb, w, tw;
  char   t[12];
  I2CEVENT *ev;

  i2c_band_y  = -1;
  dec_band2_y = -1;

  if(!scope_i2c_enabled || scopesettings.long_mode || scopesettings.xymodedisplay || (disp_sample_step <= 0.0))
    return;

  //if(!i2c_decode())
  if(!dec_decode())     //v1.01b1
    return;

  display_set_font(&font_0);

  for(e = 0; e < i2c_nev; e++)
  {
    ev = &i2c_ev[e];

    //v1.01b1: UART bytes (TX band above CH1, RX above CH2), SPI frames and words (above CH2)
    //v1.01b2: 1-Wire and LIN (above their line), the bands follow Swap
    if((ev->type == DEC_EV_UART) || (ev->type == DEC_EV_SPIWORD) || (ev->type == DEC_EV_SPIFRAME) ||
       (ev->type >= DEC_EV_OWRESET))
    {
      int32 by;
      char *q;

      if(ev->type == DEC_EV_UART)
        by = (ev->line ^ scope_dec_swap) ? dec_band2_y : i2c_band_y;
      else
        by = (dec_band2_y >= 0) ? dec_band2_y : i2c_band_y;

      if(by < 0)
        continue;

      //v1.01b2: RESET (presence: green "R", none: red) and BREAK markers
      if((ev->type == DEC_EV_OWRESET) || (ev->type == DEC_EV_LINBREAK))
      {
        x0 = i2c_x(ev->i0);

        if((x0 >= disp_xstart) && (x0 <= (disp_xend - 10)))
        {
          display_set_fg_color(((ev->type == DEC_EV_LINBREAK) || (ev->flags & 1)) ? GREEN_COLOR : RED_COLOR);
          display_draw_vert_line(x0, by - 4, by + 19);
          display_text(x0 + 2, by, (ev->type == DEC_EV_LINBREAK) ? "B" : "R");
        }

        continue;
      }

      if(ev->type == DEC_EV_SPIFRAME)
      {
        x0 = i2c_x(ev->i0);

        if((x0 >= disp_xstart) && (x0 <= disp_xend))
        {
          display_set_fg_color(GREEN_COLOR);
          display_draw_vert_line(x0, by - 4, by + 19);
        }

        continue;
      }

      x0 = i2c_x(ev->i0);
      x1 = i2c_x(ev->i1);

      if((x1 < disp_xstart) || (x0 > disp_xend))
        continue;

      if(x0 < disp_xstart) x0 = disp_xstart;
      if(x1 > disp_xend)   x1 = disp_xend;

      w = x1 - x0;

      if(w < 2)
        continue;

      display_set_fg_color((ev->type == DEC_EV_UART) ? ((ev->line ^ scope_dec_swap) ? CHANNEL2_COLOR : CHANNEL1_COLOR) :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 1)) ? ORANGE_COLOR :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 3)) ? 0x00C080FF :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 0)) ? LIGHTGREY_COLOR : 0x0040A0FF);
      display_draw_rect(x0, by, w, 16);

      q = i2c_val(t, ev->v16 & 0xFF, 2);

      if((ev->type == DEC_EV_SPIWORD) && scope_spi_16)
      {
        q = t;

        if(scope_i2c_dec)
          q = scope_print_decimal(t, ev->v16, 0, 0);
        else
        {
          *q++ = i2c_hexd[(ev->v16 >> 12) & 15];
          *q++ = i2c_hexd[(ev->v16 >> 8) & 15];
          *q++ = i2c_hexd[(ev->v16 >> 4) & 15];
          *q++ = i2c_hexd[ev->v16 & 15];
          *q = 0;
        }
      }

      tw = (int32)(q - t) * 8;

      if(w >= (tw + 4))
      {
        display_set_fg_color(ev->flags ? RED_COLOR : WHITE_COLOR);
        display_text(x0 + ((w - tw) / 2), by, t);
      }

      continue;
    }

    if(ev->type != I2C_EV_BYTE)
    {
      x0 = i2c_x(ev->i0);

      if((x0 < disp_xstart) || (x0 > (disp_xend - 8)))
        continue;

      display_set_fg_color((ev->type == I2C_EV_STOP) ? RED_COLOR : GREEN_COLOR);
      display_draw_vert_line(x0, i2c_band_y, i2c_band_y + 15);
      display_text(x0 + 2, i2c_band_y, (ev->type == I2C_EV_STOP) ? "P" : (ev->type == I2C_EV_RESTART) ? "Sr" : "S");
      continue;
    }

    //A byte: from half a bit before its first bit to half a bit after the ACK
    hb = (ev->i1 - ev->i0) / 16;
    x0 = i2c_x(ev->i0 - hb);
    x1 = i2c_x(ev->i1 + hb);

    if((x1 < disp_xstart) || (x0 > disp_xend))
      continue;

    if(x0 < disp_xstart) x0 = disp_xstart;
    if(x1 > disp_xend)   x1 = disp_xend;

    w = x1 - x0;

    if(w < 2)
      continue;

    display_set_fg_color(ev->addr ? ORANGE_COLOR : 0x0040A0FF);
    display_draw_rect(x0, i2c_band_y, w, 16);

    //v1.01a3: hex or decimal, 10 bit addresses on their second byte (the first shows "10b")
    {
      char *q;

      if(ev->addr == 2)
      {
        q = i2c_val(t, ev->a10, 3);
        *q++ = 'W';
        *q = 0;
      }
      else if(ev->addr && ev->a10 && scope_i2c_addr10)
      {
        q = t;
        *q++ = '1'; *q++ = '0'; *q++ = 'b';
        *q++ = (ev->value & 1) ? 'R' : 'W';
        *q = 0;
      }
      else if(ev->addr)
      {
        q = i2c_val(t, ev->value >> 1, 2);
        *q++ = (ev->value & 1) ? 'R' : 'W';
        *q = 0;
      }
      else
        q = i2c_val(t, ev->value, 2);

      tw = (int32)(q - t) * 8;
    }

    if(w >= (tw + 4))
    {
      display_set_fg_color(ev->ack ? WHITE_COLOR : RED_COLOR);
      display_text(x0 + ((w - tw) / 2), i2c_band_y, t);
    }
  }
}
#endif

//v1.01b6: the labels in the formats of the List (Addr / Data: HEX with 0x, DEC, BIN; the window's Values sets both),
//and when they are too dense to fit their boxes every second label (S / P too) one row higher, so they do not overlap
extern uint8 scope_i2c_fmt_addr;
extern uint8 scope_i2c_fmt_data;
static char *i2ct_num(char *p, uint32 v, uint32 bits, uint32 fmt);

#define DEC_LEVEL_H   18
#define DEC_ROWS      4      //v1.01c0: label rows above a band (2 for the packets, 2 more for dense wide labels)

static char *dec_label_text(const I2CEVENT *ev, char *t);
static uint32 dec_ev_error(uint32 e);

//v1.01b9: the NACK of the master after the last byte it reads (the next event is P or Sr): normal, not an error
static uint32 dec_i2c_nack_normal(uint32 e)
{
  int32 k;

  if((e >= i2c_nev) || (i2c_ev[e].type != I2C_EV_BYTE) || i2c_ev[e].ack || i2c_ev[e].addr)
    return(0);

  //Marked by the List before its filter took rows away (flags bit 6 marked, bit 7 normal)
  if(i2c_ev[e].flags & 0x40)
    return((i2c_ev[e].flags & 0x80) ? 1 : 0);

  if(((e + 1) < i2c_nev) && (i2c_ev[e + 1].type != I2C_EV_STOP) && (i2c_ev[e + 1].type != I2C_EV_RESTART))
    return(0);

  //A read: the address byte of the transaction has the R bit
  for(k = (int32)e - 1; k >= 0; k--)
  {
    if(i2c_ev[k].type != I2C_EV_BYTE)
      return(0);

    if(i2c_ev[k].addr == 1)
      return(i2c_ev[k].value & 1);
  }

  return(0);
}

#if 0     //v1.01c0: BIN stays BIN (more rows instead)
//v1.01b9: a byte label in HEX (with 0x, or nox: without) when the chosen format does not fit
static char *dec_label_text_fmt(const I2CEVENT *ev, char *t, uint32 nox)
{
  uint8 fa = scope_i2c_fmt_addr, fd = scope_i2c_fmt_data;
  char *q;

  scope_i2c_fmt_addr = 0;
  scope_i2c_fmt_data = 0;
  q = dec_label_text(ev, t);
  scope_i2c_fmt_addr = fa;
  scope_i2c_fmt_data = fd;

  //Without "0x": the text moved two places to the left
  if(nox && (t[0] == '0') && (t[1] == 'x'))
  {
    char *p = t;

    while(p[2])
    {
      p[0] = p[2];
      p++;
    }

    *p = 0;
    q = p;
  }

  return(q);
}
#endif

//The text of a byte label into t (24 characters), returns its end
static char *dec_label_text(const I2CEVENT *ev, char *t)
{
  char *q;

  if(ev->type == I2C_EV_BYTE)
  {
    //10 bit addresses on their second byte (the first shows "10b")
    if(ev->addr == 2)
    {
      q = i2ct_num(t, ev->a10, 10, scope_i2c_fmt_addr);
      *q++ = 'W';
    }
    else if(ev->addr && ev->a10 && scope_i2c_addr10)
    {
      q = t;
      *q++ = '1'; *q++ = '0'; *q++ = 'b';
      *q++ = (ev->value & 1) ? 'R' : 'W';
    }
    else if(ev->addr)
    {
      q = i2ct_num(t, ev->value >> 1, 7, scope_i2c_fmt_addr);
      *q++ = (ev->value & 1) ? 'R' : 'W';
    }
    else
      return(i2ct_num(t, ev->value, 8, scope_i2c_fmt_data));

    *q = 0;
    return(q);
  }

  if((ev->type == DEC_EV_SPIWORD) && scope_spi_16)
    return(i2ct_num(t, ev->v16, 16, scope_i2c_fmt_data));

  if(ev->type == DEC_EV_UART)
    return(i2ct_num(t, ev->v16 & 0xFF, scope_uart_7bit ? 7 : 8, scope_i2c_fmt_data));

  return(i2ct_num(t, ev->v16 & 0xFF, 8, scope_i2c_fmt_data));
}

//The band of an event (screen y), -1 none; *b 0 the first band, 1 the second
static int32 dec_ev_band(const I2CEVENT *ev, uint32 *b)
{
  int32 by;

  if((ev->type <= I2C_EV_BYTE))
    by = i2c_band_y;
  else if(ev->type == DEC_EV_UART)
    by = (ev->line ^ scope_dec_swap) ? dec_band2_y : i2c_band_y;
  else
    by = (dec_band2_y >= 0) ? dec_band2_y : i2c_band_y;

  *b = ((by >= 0) && (by == dec_band2_y) && (by != i2c_band_y)) ? 1 : 0;
  return(by);
}

//The box of a byte event on the screen: 0 when not in view
static uint32 dec_ev_box(const I2CEVENT *ev, int32 *px0, int32 *pw)
{
  int32 x0, x1, hb;

  if(ev->type == I2C_EV_BYTE)
  {
    //From half a bit before its first bit to half a bit after the ACK
    hb = (ev->i1 - ev->i0) / 16;
    x0 = i2c_x(ev->i0 - hb);
    x1 = i2c_x(ev->i1 + hb);
  }
  else
  {
    x0 = i2c_x(ev->i0);
    x1 = i2c_x(ev->i1);
  }

  if((x1 < disp_xstart) || (x0 > disp_xend))
    return(0);

  if(x0 < disp_xstart) x0 = disp_xstart;
  if(x1 > disp_xend)   x1 = disp_xend;

  if((x1 - x0) < 2)
    return(0);

  *px0 = x0;
  *pw  = x1 - x0;
  return(1);
}

static uint32 dec_ev_is_box(const I2CEVENT *ev)
{
  return((ev->type == I2C_EV_BYTE) || (ev->type == DEC_EV_UART) || (ev->type == DEC_EV_SPIWORD) ||
         (ev->type == DEC_EV_OWBYTE) || (ev->type == DEC_EV_LINBYTE));
}

#if 0     //v1.01b7: v1.01b6 (every second label a row higher, the box of the byte)
//The layer, from scope_display_trace_data (after REF / MATH)
void scope_i2c_display(void)
{
  uint32 e, b, dense = 0, level[2] = { 0, 0 }, lv;
  int32  x0, w, tw, by, y;
  char   t[24], *q;
  I2CEVENT *ev;

  i2c_band_y  = -1;
  dec_band2_y = -1;

  if(!scope_i2c_enabled || scopesettings.long_mode || scopesettings.xymodedisplay || (disp_sample_step <= 0.0))
    return;

  if(!dec_decode())
    return;

  display_set_font(&font_0);

  //Dense: a label in view does not fit its box
  for(e = 0; (e < i2c_nev) && !dense; e++)
  {
    ev = &i2c_ev[e];

    if(dec_ev_is_box(ev) && dec_ev_box(ev, &x0, &w))
    {
      q  = dec_label_text(ev, t);
      tw = (int32)(q - t) * 8;

      if(w < (tw + 4))
        dense = 1;
    }
  }

  for(e = 0; e < i2c_nev; e++)
  {
    ev = &i2c_ev[e];
    by = dec_ev_band(ev, &b);

    if(by < 0)
      continue;

    //SPI frame start: a green line, no label
    if(ev->type == DEC_EV_SPIFRAME)
    {
      x0 = i2c_x(ev->i0);

      if((x0 >= disp_xstart) && (x0 <= disp_xend))
      {
        display_set_fg_color(GREEN_COLOR);
        display_draw_vert_line(x0, by - 4, by + 19);
      }

      continue;
    }

    //Markers: I2C S / Sr / P, 1-Wire RESET, LIN BREAK
    if(!dec_ev_is_box(ev))
    {
      x0 = i2c_x(ev->i0);

      if((x0 < disp_xstart) || (x0 > (disp_xend - 10)))
        continue;

      lv = dense ? (level[b]++ & 1) : 0;
      y  = by - (int32)(lv * DEC_LEVEL_H);
      if(y < 46) y = 46;

      if((ev->type == DEC_EV_OWRESET) || (ev->type == DEC_EV_LINBREAK))
      {
        display_set_fg_color(((ev->type == DEC_EV_LINBREAK) || (ev->flags & 1)) ? GREEN_COLOR : RED_COLOR);
        display_draw_vert_line(x0, y - 4, by + 19);
        display_text(x0 + 2, y, (ev->type == DEC_EV_LINBREAK) ? "B" : "R");
      }
      else
      {
        display_set_fg_color((ev->type == I2C_EV_STOP) ? RED_COLOR : GREEN_COLOR);
        display_draw_vert_line(x0, y, by + 15);
        display_text(x0 + 2, y, (ev->type == I2C_EV_STOP) ? "P" : (ev->type == I2C_EV_RESTART) ? "Sr" : "S");
      }

      continue;
    }

    if(!dec_ev_box(ev, &x0, &w))
      continue;

    lv = dense ? (level[b]++ & 1) : 0;
    y  = by - (int32)(lv * DEC_LEVEL_H);
    if(y < 46) y = 46;

    if(ev->type == I2C_EV_BYTE)
      display_set_fg_color(ev->addr ? ORANGE_COLOR : 0x0040A0FF);
    else
      display_set_fg_color((ev->type == DEC_EV_UART) ? ((ev->line ^ scope_dec_swap) ? CHANNEL2_COLOR : CHANNEL1_COLOR) :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 1)) ? ORANGE_COLOR :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 3)) ? 0x00C080FF :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 0)) ? LIGHTGREY_COLOR : 0x0040A0FF);

    display_draw_rect(x0, y, w, 16);

    q  = dec_label_text(ev, t);
    tw = (int32)(q - t) * 8;

    //Dense: the text may be up to twice the box (the next label is a row higher or lower)
    if((w >= (tw + 4)) || (dense && ((2 * w) >= (tw + 4))))
    {
      int32 tx = x0 + ((w - tw) / 2);

      if(tx < disp_xstart)           tx = disp_xstart;
      if((tx + tw) > disp_xend)      tx = disp_xend - tw;

      display_set_fg_color(((ev->type == I2C_EV_BYTE) ? !ev->ack : ev->flags) ? RED_COLOR : WHITE_COLOR);
      display_text(tx, y, t);
    }
  }
}
#endif

//v1.01b7: the boxes as wide as their text needs (BIN did not fit), and when dense a whole packet (I2C S .. P, an SPI
//frame, 1-Wire from a RESET, LIN from a BREAK, a UART byte) on one row, the next packet on the other row. A box that
//would cover the one before it on its row keeps its own width and shows no text.
static uint32 dec_ev_packet_start(const I2CEVENT *ev)
{
  return((ev->type == I2C_EV_START) || (ev->type == DEC_EV_SPIFRAME) || (ev->type == DEC_EV_OWRESET) ||
         (ev->type == DEC_EV_LINBREAK) || (ev->type == DEC_EV_UART));
}

//The layer, from scope_display_trace_data (after REF / MATH)
void scope_i2c_display(void)
{
  uint32 e, b, dense = 0, packet[2] = { 0, 0 }, lv;
  int32  mark = 0;
  int32  x0, w, tw, by, y, bx, bw, lastend[2][DEC_ROWS] = { { -1000, -1000, -1000, -1000 }, { -1000, -1000, -1000, -1000 } };
  char   t[24], *q;
  I2CEVENT *ev;

  i2c_band_y  = -1;
  dec_band2_y = -1;

  if(!scope_i2c_enabled || scopesettings.long_mode || scopesettings.xymodedisplay || (disp_sample_step <= 0.0))
    return;

  if(!dec_decode())
    return;

  //v1.01b8: the decoder trigger (I2C NACK / address): found while running -> RUN stops after this display
  if(scope_dec_trig && (scope_dec_proto == DEC_I2C) && scopesettings.runstate && !scopesettings.waveviewmode)
  {
    for(e = 0; e < i2c_nev; e++)
    {
      ev = &i2c_ev[e];

      if((ev->type == I2C_EV_BYTE) &&
         (((scope_dec_trig == 1) && !ev->ack && !dec_i2c_nack_normal(e)) ||     //v1.01b9: not the normal NACK
 ((scope_dec_trig == 2) && (ev->addr == 1) && ((ev->value >> 1) == scope_dec_trig_addr))))
      {
        dec_trig_hit = 1;
        break;
      }
    }
  }

  display_set_font(&font_0);

  //Dense: a label in view does not fit its box
  for(e = 0; (e < i2c_nev) && !dense; e++)
  {
    ev = &i2c_ev[e];

    if(dec_ev_is_box(ev) && dec_ev_box(ev, &x0, &w))
    {
      q  = dec_label_text(ev, t);
      tw = (int32)(q - t) * 8;

      if(w < (tw + 4))
        dense = 1;
    }
  }

  for(e = 0; e < i2c_nev; e++)
  {
    ev = &i2c_ev[e];
    by = dec_ev_band(ev, &b);

    if(by < 0)
      continue;

    //The row of the packet (a new packet takes the other row)
    if(dense && dec_ev_packet_start(ev))
      packet[b]++;

    lv = dense ? (packet[b] & 1) : 0;
    y  = by - (int32)(lv * DEC_LEVEL_H);
    if(y < 46) y = 46;

    //SPI frame start: a green line, no label
    if(ev->type == DEC_EV_SPIFRAME)
    {
      x0 = i2c_x(ev->i0);

      if((x0 >= disp_xstart) && (x0 <= disp_xend))
      {
        display_set_fg_color(GREEN_COLOR);
        display_draw_vert_line(x0, y - 4, by + 19);
      }

      continue;
    }

    //Markers: I2C S / Sr / P, 1-Wire RESET, LIN BREAK
    if(!dec_ev_is_box(ev))
    {
      x0 = i2c_x(ev->i0);

      if((x0 < disp_xstart) || (x0 > (disp_xend - 10)))
        continue;

      if((ev->type == DEC_EV_OWRESET) || (ev->type == DEC_EV_LINBREAK))
      {
        //v1.01b9: no red: a reset without presence in yellow (v1.01c0: red again, it is an error)
        display_set_fg_color(((ev->type == DEC_EV_LINBREAK) || (ev->flags & 1)) ? GREEN_COLOR : RED_COLOR);
        display_draw_vert_line(x0, y - 4, by + 19);
        display_text(x0 + 2, y + 1, (ev->type == DEC_EV_LINBREAK) ? "B" : "R");
      }
      else
      {
        //v1.01b9: P in light orange instead of red
        display_set_fg_color((ev->type == I2C_EV_STOP) ? ORANGE_COLOR : GREEN_COLOR);     //v1.01c0: P orange
        display_draw_vert_line(x0, y, by + 15);
        display_text(x0 + 2, y + 1, (ev->type == I2C_EV_STOP) ? "P" : (ev->type == I2C_EV_RESTART) ? "Sr" : "S");
      }

      continue;
    }

    if(!dec_ev_box(ev, &x0, &w))
      continue;

    //v1.01c0: always the chosen format (BIN stays BIN). The box as wide as the text needs, centred on the byte; when
    //it would cover the box before it on the packet's row, the next row that is free (the other packet row, then
    //two more above), so every value is shown
    {
      uint32 k, row;
      static const uint8 order[2][DEC_ROWS] = { { 0, 1, 2, 3 }, { 1, 0, 2, 3 } };

      q  = dec_label_text(ev, t);
      tw = (int32)(q - t) * 8;
      bw = w;
      bx = x0;

      //v1.01c1: room for the mark (a block of a character's size) right of the text
      mark = dec_ev_error(e) ? 8 : 0;

      if(w < (tw + 4 + mark))
      {
        bw = tw + 4 + mark;
        bx = x0 + (w / 2) - (bw / 2);

        if(bx < disp_xstart)          bx = disp_xstart;
        if((bx + bw) > disp_xend)     bx = disp_xend - bw;
      }

      for(k = 0; k < DEC_ROWS; k++)
      {
        row = order[lv & 1][k];

        if(bx > lastend[b][row])
          break;
      }

      if(k < DEC_ROWS)
        lv = row;
      else
      {
        //No row free: its own width, no text
        bw = w;
        bx = x0;
        tw = -1;
      }

      y = by - (int32)(lv * DEC_LEVEL_H);
      if(y < 46) y = 46;
    }

    if(ev->type == I2C_EV_BYTE)
      display_set_fg_color(ev->addr ? ORANGE_COLOR : 0x0040A0FF);
    else
      display_set_fg_color((ev->type == DEC_EV_UART) ? ((ev->line ^ scope_dec_swap) ? CHANNEL2_COLOR : CHANNEL1_COLOR) :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 1)) ? ORANGE_COLOR :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 3)) ? 0x00C080FF :
                           ((ev->type == DEC_EV_LINBYTE) && (ev->addr == 0)) ? LIGHTGREY_COLOR : 0x0040A0FF);

    display_draw_rect(bx, y, bw, 16);
    lastend[b][lv] = bx + bw;

    if(tw >= 0)
    {
      //display_set_fg_color(((ev->type == I2C_EV_BYTE) ? !ev->ack : ev->flags) ? RED_COLOR : WHITE_COLOR);
      //display_text(bx + ((bw - tw) / 2), y, t);
      //v1.01b9: always white, one pixel lower (the digits are centred in the box)
      //v1.01c1: centred in the box without the mark
      display_set_fg_color(WHITE_COLOR);
      display_text(bx + ((bw - mark - tw) / 2), y + 1, t);
    }

    //v1.01b9: an error as a small corner instead of coloured text
    //v1.01c0: red for an error, yellow for the normal NACK after the last byte read
    //v1.01c1: a block as big as a digit (6 x 10) at the right inside the box
    if(mark && (bw >= 10))
    {
      display_set_fg_color(dec_i2c_nack_normal(e) ? YELLOW_COLOR : RED_COLOR);
      display_fill_rect(bx + bw - 8, y + 3, 6, 10);
    }
  }
}

//v1.01b8: called at the end of scope_display_trace_data: the decoder trigger found -> STOP (as the STOP button)
void scope_dec_trigger_after(void)
{
  if(!dec_trig_hit)
    return;

  dec_trig_hit = 0;

  if(!scopesettings.runstate)
    return;

  scopesettings.runstate = 0;
  scope_run_stop_text();

  if(scopesettings.rightmenustate == 0)
    scope_run_stop_button(0);
}

//v1.01b8: the decoder trigger in a settings word: bits 1..0 the mode, 14..8 the address
uint16 scope_dec_trig_word(void)
{
  return((uint16)((scope_dec_trig % 3) | ((scope_dec_trig_addr & 0x7F) << 8)));
}

void scope_dec_trig_set(uint16 w)
{
  scope_dec_trig      = (uint8)((w & 3) % 3);
  scope_dec_trig_addr = (uint8)((w >> 8) & 0x7F);

  if(!w)
    scope_dec_trig_addr = 0x68;
}

//A short tap in the trace area (statemachine): on the label band it opens the list; 1 when it did
uint32 scope_i2c_tap(int32 x, int32 y)
{
  (void)x;

  //v1.01b1: either band (UART RX / SPI above CH2)
  if(!scope_i2c_enabled ||
     (((i2c_band_y < 0) || (y < (i2c_band_y - 6 - DEC_LEVEL_H)) || (y > (i2c_band_y + 22))) &&     //v1.01b6: the upper row too
      ((dec_band2_y < 0) || (y < (dec_band2_y - 6 - DEC_LEVEL_H)) || (y > (dec_band2_y + 22)))))
    return(0);

  scope_i2c_list();
  return(1);
}

//The time of a sample index from the start of the record, as text (scope_print_value units)
static void i2c_time_text(char *buf, int32 idx)
{
  uint32 sr = scopesettings.samplerate;
  double t;

  if(sr >= (sizeof(sample_rate) / sizeof(sample_rate[0])))
    sr = 0;

  t = (double)idx / (double)sample_rate[sr];

  if(t < 0.02)
    scope_print_value(buf, (int32)(t * 1e11), 1, "", "s");     //0.01 ns units
  else
    scope_print_value(buf, (int32)(t * 1e5), 3, "", "s");      //0.01 ms units
}

#if 0     //v1.01a4: the text list of v1.01a2 / a3, replaced by the table below
//One transaction (from event e, a START) as a text line; returns the index after it
#define I2C_LINE_MAX    100

static uint32 i2c_line(uint32 e, char *s, uint32 number)
{
  char  *p = s, *end = s + I2C_LINE_MAX - 6;
  char   t[24];
  uint32 k, started = 0;
  I2CEVENT *ev;

  //Number and time
  p = scope_print_decimal(p, number, 0, 0);
  *p++ = ' ';
  i2c_time_text(t, i2c_ev[e].i0);
  for(k = 0; t[k] && (p < end); k++) *p++ = t[k];
  while((p - s) < 14) *p++ = ' ';

  for(; e < i2c_nev; e++)
  {
    ev = &i2c_ev[e];

    if(p >= end)
    {
      //Too long for the line: the rest is skipped up to the end of the transaction
      if(ev->type == I2C_EV_STOP)
      {
        e++;
        break;
      }

      continue;
    }

    //The next transaction
    if((ev->type == I2C_EV_START) && started)
      break;

    started = 1;

    switch(ev->type)
    {
      case I2C_EV_START:   *p++ = 'S'; *p++ = ' '; break;
      case I2C_EV_RESTART: *p++ = 'S'; *p++ = 'r'; *p++ = ' '; break;
      case I2C_EV_STOP:    *p++ = 'P'; e++; *p = 0; return(e);
      default:
        //v1.01a3: hex / decimal, a 10 bit address once (on its second byte)
        if(ev->addr == 2)
        {
          p = i2c_val(p, ev->a10, 3);
          *p++ = 'W';
        }
        else if(ev->addr && ev->a10 && scope_i2c_addr10)
        {
          if(ev->value & 1)
          {
            *p++ = '1'; *p++ = '0'; *p++ = 'b'; *p++ = 'R';
          }
          else
          {
            //the address follows with the next byte
            continue;
          }
        }
        else if(ev->addr)
        {
          p = i2c_val(p, ev->value >> 1, 2);
          *p++ = (ev->value & 1) ? 'R' : 'W';
        }
        else
          p = i2c_val(p, ev->value, 2);

        *p++ = ev->ack ? '+' : '-';
        *p++ = ' ';
        break;
    }
  }

  *p = 0;
  return(e);
}

//The list screen: one transaction per row (number, time from the record start, S / Sr, address with W / R, the data
//bytes, P; '+' ACK, '-' NAK), Up / Down to scroll, Close. The record decoded once when it opens.
#define I2C_LIST_ROWS   21
#define I2C_LIST_Y0     46

static uint32 i2c_tr_start[I2C_MAX_EV];
static uint32 i2c_ntr = 0;

static void i2c_list_button(int32 x, int32 y, const char *text)
{
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(x, y, 66, 40, 3);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(x, y, 66, 40, 3);
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(x + 8, y + 12, (int8 *)text);
}

static void i2c_list_draw(uint32 top)
{
  char   s[I2C_LINE_MAX + 8];
  uint32 r, k;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);

  display_set_font(&font_3);
  display_set_fg_color(ORANGE_COLOR);
  display_text(10, 10, "I2C transactions");
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_0);
  scope_print_decimal(s, i2c_ntr, 0, 0);
  display_text(180, 12, s);
  display_text(230, 12, scope_i2c_dec ? "SDA = CH1, SCL = CH2, + ACK, - NAK, time from the record start, DEC" : "SDA = CH1, SCL = CH2, + ACK, - NAK, time from the record start, HEX");

  i2c_list_button(724, 4,   "Close");
  i2c_list_button(724, 150, " Up");
  i2c_list_button(724, 300, "Down");

  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_horz_line(I2C_LIST_Y0 - 4, 4, 712);

  display_set_font(&font_0);

  if(!i2c_ntr)
  {
    display_set_fg_color(LIGHTGREY_COLOR);
    display_text(10, I2C_LIST_Y0 + 10, "No transaction in the record (SDA on CH1 and SCL on CH2, both on, STOP and look again)");
    return;
  }

  for(r = 0; (r < I2C_LIST_ROWS) && ((top + r) < i2c_ntr); r++)
  {
    i2c_line(i2c_tr_start[top + r], s, top + r + 1);

    //Lines with a NAK in red
    display_set_fg_color(WHITE_COLOR);

    for(k = 0; s[k]; k++)
      if(s[k] == '-')
        display_set_fg_color(0x00FF8080);

    s[88] = 0;
    display_text(6, I2C_LIST_Y0 + (r * 20), s);
  }
}

void scope_i2c_list(void)
{
  uint32 e, top = 0;
  int32  x, y;

  tp_i2c_wait_for_touch_release();

  //The screen is kept to come back to
  display_set_destination_buffer(displaybuffer2);
  display_copy_rect_from_screen(0, 0, 800, 480);

  i2c_decode();

  //Transactions: every START (repeated STARTs stay in their transaction)
  for(e = 0, i2c_ntr = 0; e < i2c_nev; e++)
    if(i2c_ev[e].type == I2C_EV_START)
      i2c_tr_start[i2c_ntr++] = e;

  i2c_list_draw(top);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x = xtouch;
    y = ytouch;
    tp_i2c_wait_for_touch_release();

    if(x < 720)
      continue;

    if((y >= 4) && (y <= 44))
      break;

    if((y >= 150) && (y <= 190))
    {
      top = (top >= I2C_LIST_ROWS) ? (top - I2C_LIST_ROWS) : 0;
      i2c_list_draw(top);
    }
    else if((y >= 300) && (y <= 340))
    {
      if((top + I2C_LIST_ROWS) < i2c_ntr)
        top += I2C_LIST_ROWS;

      i2c_list_draw(top);
    }
  }

  display_set_source_buffer(displaybuffer2);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(0, 0, 800, 480);
}
#endif     //v1.01a4: the list as a table below

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01a4: the list as a table, one row per event: # (the transaction's number on its START row), Time (from the record
//start), Event (START, ADDR, DATA, Sr, STOP), Value (address with W / R, data; HEX or DEC), Ack (ACK green, NACK red).
//The rows of a transaction share a shade, every other transaction a little lighter. Moved with the finger (drag up /
//down), a scroll bar right shows the part in view, Close top right. The text one transaction per row (v1.01a2) above.
#define I2CT_ROWS       20
#define I2CT_ROW_H      20
#define I2CT_Y0         52
#define I2CT_X_NUM      8
#define I2CT_X_TIME     56
#define I2CT_X_EVENT    190
#define I2CT_X_VALUE    290
#define I2CT_X_ACK      410
#define I2CT_W          700

static uint16 i2ct_trn[I2C_MAX_EV];     //transaction number of each row (1 ..), 0 before the first START

//v1.01a5: the number format of the table's Value column, own for addresses and for data (0 HEX, 1 DEC, 2 BIN), switched
//by the two buttons in the head of the list, saved with the settings
uint8 scope_i2c_fmt_addr = 0;
uint8 scope_i2c_fmt_data = 0;

static const char *const i2ct_fmt_names[3] = { "HEX", "DEC", "BIN" };

static char *i2ct_num(char *p, uint32 v, uint32 bits, uint32 fmt)
{
  int32 b;

  if(fmt == 1)
    return(scope_print_decimal(p, (int32)v, 0, 0));

  if(fmt == 2)
  {
    for(b = (int32)bits - 1; b >= 0; b--)
      *p++ = ((v >> b) & 1) ? '1' : '0';

    *p = 0;
    return(p);
  }

  //v1.01a6: hex with 0x
  *p++ = '0';
  *p++ = 'x';

  //v1.01b1: 16 bit SPI words with 4 digits
  if(bits > 12)
    *p++ = i2c_hexd[(v >> 12) & 15];

  if(bits > 8)
    *p++ = i2c_hexd[(v >> 8) & 15];

  i2c_hex2(p, (uint8)v);
  p[2] = 0;
  return(p + 2);
}

//v1.01a6: the format buttons right under Close, in the colours of the addresses / the data: the name and the format
#if 0     //v1.01b4: the full coloured buttons
static void i2ct_fmt_button(int32 y, const char *name, uint32 fmt, uint32 color)
{
  display_set_fg_color(color);
  display_fill_rounded_rect(720, y, 76, 48, 3);
  display_set_fg_color(BLACK_COLOR);
  display_set_font(&font_3);
  //v1.01b3: centred (were from x 730)
  display_text(758 - ((int32)scope_text_width(name) / 2), y + 5, (int8 *)name);
  display_text(758 - ((int32)scope_text_width(i2ct_fmt_names[fmt % 3]) / 2), y + 25, (int8 *)i2ct_fmt_names[fmt % 3]);
}
#endif

//v1.01b5: the buttons of the List's right column lighter: dark with an edge and the first line in the button's colour,
//70 x 44 (were 76 x 48 filled with the colour); orange when touched
#define I2CT_PB_X   724
#define I2CT_PB_W   70
#define I2CT_PB_H   44
#define I2CT_PB_FILL  0x00242C34

static void i2ct_pbutton(int32 y, const char *l1, const char *l2, uint32 color, uint32 active)
{
  display_set_fg_color(active ? ORANGE_COLOR : I2CT_PB_FILL);
  display_fill_rounded_rect(I2CT_PB_X, y, I2CT_PB_W, I2CT_PB_H, 3);
  display_set_fg_color(active ? ORANGE_COLOR : color);
  display_draw_rounded_rect(I2CT_PB_X, y, I2CT_PB_W, I2CT_PB_H, 3);
  display_set_font(&font_3);
  display_set_fg_color(active ? BLACK_COLOR : color);
  display_text(I2CT_PB_X + (I2CT_PB_W / 2) - ((int32)scope_text_width(l1) / 2), y + 4, (int8 *)l1);
  display_set_fg_color(active ? BLACK_COLOR : WHITE_COLOR);
  display_text(I2CT_PB_X + (I2CT_PB_W / 2) - ((int32)scope_text_width(l2) / 2), y + 23, (int8 *)l2);
}

static void i2ct_fmt_button(int32 y, const char *name, uint32 fmt, uint32 color)
{
  i2ct_pbutton(y, name, i2ct_fmt_names[fmt % 3], color, 0);
}

//v1.01b5: the right column on its own darker panel with a line to the table, the title row in a frame (information
//and messages)
static void i2ct_frame(void)
{
  display_set_fg_color(0x00101010);
  display_fill_rect(718, 0, 82, 480);
  display_set_fg_color(0x00505860);
  display_draw_vert_line(718, 0, 479);

  display_set_fg_color(0x00182028);
  display_fill_rounded_rect(4, 2, 704, 26, 3);
  display_set_fg_color(0x00505860);
  display_draw_rounded_rect(4, 2, 704, 26, 3);
}

//v1.01b5: Close at the top of the column in red with a light edge
static void i2ct_close_button(void)
{
  display_set_fg_color(0x00A03030);
  display_fill_rounded_rect(I2CT_PB_X, 4, I2CT_PB_W, 36, 3);
  display_set_fg_color(0x00E08080);
  display_draw_rounded_rect(I2CT_PB_X, 4, I2CT_PB_W, 36, 3);
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(I2CT_PB_X + (I2CT_PB_W / 2) - ((int32)scope_text_width("Close") / 2), 14, "Close");
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01a4: the Info column of the table (chip on the address row, register / meaning on the data bytes)
#define I2C_INFO_LEN    30
#define I2CT_X_INFO     466

static char i2ct_info[I2C_MAX_EV][I2C_INFO_LEN];

static char *i2c_str(char *p, const char *s, char *end)
{
  while(*s && (p < end))
    *p++ = *s++;

  *p = 0;
  return(p);
}

#if 0     //v1.01a8: the built-in chips of v1.01a4 .. a7, replaced by the files of \i2c_chips\ below
//----------------------------------------------------------------------------------------------------------------------------------
//v1.01a4: known chips (the first one: DS3231M, address 0x68), built in; the Info column of the table names the chip on
//its address row and the register and its meaning on each data byte. Register pointer as the chip keeps it: the first
//byte written after the address sets it, every further byte (written or read) is the next register (wraps after the
//last). At the start of the record the pointer is unknown ("?") until a write sets it.

static const char *const ds3231_regs[19] =
{
  "Seconds", "Minutes", "Hours", "Day", "Date", "Month", "Year",
  "A1 Seconds", "A1 Minutes", "A1 Hours", "A1 Day/Date", "A2 Minutes", "A2 Hours", "A2 Day/Date",
  "Control", "Status", "Aging", "Temp MSB", "Temp LSB"
};


static char *i2c_bcd(char *p, uint8 v)
{
  *p++ = '0' + ((v >> 4) & 15);
  *p++ = '0' + (v & 15);
  *p = 0;
  return(p);
}

//"Name = meaning" of a DS3231M register value
static void ds3231_info(char *buf, uint32 reg, uint8 v)
{
  char *p = buf, *end = buf + I2C_INFO_LEN - 1;

  if(reg > 18)
  {
    i2c_str(p, "?", end);
    return;
  }

  p = i2c_str(p, ds3231_regs[reg], end);
  p = i2c_str(p, " = ", end);

  switch(reg)
  {
    case 0: case 1: case 7: case 8: case 11:
      p = i2c_bcd(p, v & 0x7F);
      if((reg >= 7) && (v & 0x80)) p = i2c_str(p, " M", end);
      break;

    case 2: case 9: case 12:
      if(v & 0x40)
      {
        p = i2c_bcd(p, v & 0x1F);
        p = i2c_str(p, (v & 0x20) ? " PM" : " AM", end);
      }
      else
        p = i2c_bcd(p, v & 0x3F);

      if((reg != 2) && (v & 0x80)) p = i2c_str(p, " M", end);
      break;

    case 3:
      *p++ = '0' + (v & 7);
      *p = 0;
      break;

    case 4:
      p = i2c_bcd(p, v & 0x3F);
      break;

    case 5:
      p = i2c_bcd(p, v & 0x1F);
      if(v & 0x80) p = i2c_str(p, " C", end);
      break;

    case 6:
      p = i2c_bcd(p, v);
      break;

    case 10: case 13:
      //Day (DY/DT = 1) or date
      if(v & 0x40) { p = i2c_str(p, "day ", end); *p++ = '0' + (v & 7); *p = 0; }
      else         { p = i2c_str(p, "date ", end); p = i2c_bcd(p, v & 0x3F); }
      if(v & 0x80) p = i2c_str(p, " M", end);
      break;

    case 15:
      //Status flags that are set
      if(!(v & 0x8F)) p = i2c_str(p, "-", end);
      if(v & 0x80) p = i2c_str(p, "OSF ", end);
      if(v & 0x08) p = i2c_str(p, "EN32k ", end);
      if(v & 0x04) p = i2c_str(p, "BSY ", end);
      if(v & 0x02) p = i2c_str(p, "A2F ", end);
      if(v & 0x01) p = i2c_str(p, "A1F", end);
      break;

    case 16:
    case 17:
      {
        int32 sv = (int32)(signed char)v;

        p = scope_print_decimal(p, (sv < 0) ? -sv : sv, 0, (sv < 0) ? 1 : 0);
        *p = 0;

        if(reg == 17)
          p = i2c_str(p, " C", end);
      }
      break;

    case 18:
      //The fraction of the temperature: bits 7..6 in 0.25 C
      p = i2c_str(p, (const char *[]){ ".00 C", ".25 C", ".50 C", ".75 C" }[(v >> 6) & 3], end);
      break;

    default:
      //Control: hex
      *p++ = '0'; *p++ = 'x';
      i2c_hex2(p, v);
      p[2] = 0;
      break;
  }
}

//v1.01a7: the chip the Info column decodes (Chip button in the list, saved with the settings). Auto: 0x68 = DS3231M,
//0x50..0x57 = 24C32/64 (the EEPROM of the usual DS3231 modules); otherwise only the chosen chip at its addresses.
//24Cxx: the device address 0x50..0x57; 1 byte word address (24C01/02), 1 byte + block bits A2..A0 of the device
//address (24C04/08/16), 2 byte word address (24C32 .. 24C512). The first bytes written after the address set the
//memory address, every further byte written or read is the next address ("Write / Read [0x0123] = 0x55").
#define I2C_CHIP_AUTO     0
#define I2C_CHIP_OFF      1
#define I2C_CHIP_DS3231   2
#define I2C_CHIP_24C02    3
#define I2C_CHIP_24C16    4
#define I2C_CHIP_24C64    5
#define I2C_CHIP_24C512   6
#define I2C_CHIPS         7

uint8 scope_i2c_chip = I2C_CHIP_AUTO;

static const char *const i2c_chip_names[I2C_CHIPS] =
{
  "Auto (by address)", "Off", "DS3231M RTC (0x68)", "24C01 / 24C02 (0x50..57)", "24C04 / 08 / 16 (0x50..57)",
  "24C32 / 24C64 (0x50..57)", "24C128 / 256 / 512 (0x50..57)"
};

static const char *const i2c_chip_short[I2C_CHIPS] = { "Auto", "Off", "DS3231", "24C02", "24C16", "24C64", "24C512" };

//The chip type for a device address: I2C_CHIP_DS3231 / _24Cxx, 0 none
static uint32 i2c_chip_for(uint32 dev)
{
  uint32 c = scope_i2c_chip;

  if(c == I2C_CHIP_OFF)
    return(0);

  if(c == I2C_CHIP_AUTO)
    return((dev == 0x68) ? I2C_CHIP_DS3231 : ((dev & 0x78) == 0x50) ? I2C_CHIP_24C64 : 0);

  if(c == I2C_CHIP_DS3231)
    return((dev == 0x68) ? c : 0);

  return(((dev & 0x78) == 0x50) ? c : 0);
}

static char *i2c_hex4(char *p, uint32 v)
{
  *p++ = '0'; *p++ = 'x';
  *p++ = i2c_hexd[(v >> 12) & 15];
  *p++ = i2c_hexd[(v >> 8) & 15];
  *p++ = i2c_hexd[(v >> 4) & 15];
  *p++ = i2c_hexd[v & 15];
  *p = 0;
  return(p);
}

//The Info column for all rows
static void i2ct_annotate(void)
{
  uint32 e, bytes = 0, dev = 0, rw = 0, chip = 0;
  int32  ptr = -1, eptr = -1;
  char  *p, *end;
  I2CEVENT *ev;

  for(e = 0; e < i2c_nev; e++)
  {
    ev  = &i2c_ev[e];
    p   = i2ct_info[e];
    end = &i2ct_info[e][I2C_INFO_LEN - 1];
    *p  = 0;

    if(ev->type != I2C_EV_BYTE)
      continue;

    if(ev->addr == 1)
    {
      dev   = ev->value >> 1;
      rw    = ev->value & 1;
      bytes = 0;
      chip  = i2c_chip_for(dev);

      if(chip == I2C_CHIP_DS3231)
        i2c_str(p, "DS3231M RTC", end);
      else if(chip)
      {
        p = i2c_str(p, i2c_chip_short[chip], end);
        i2c_str(p, " EEPROM", end);
      }

      continue;
    }

    if(!chip || (ev->addr == 2))
      continue;

    if(chip == I2C_CHIP_DS3231)
    {
      if(!rw && (bytes == 0))
      {
        //The register pointer
        p = i2c_str(p, "Pointer -> ", end);

        ptr = ev->value;

        if(ptr <= 18)
          i2c_str(p, ds3231_regs[ptr], end);
      }
      else if(ptr < 0)
        i2c_str(p, "? (pointer unknown)", end);
      else
      {
        ds3231_info(p, (uint32)ptr, ev->value);
        ptr = (ptr >= 18) ? 0 : (ptr + 1);
      }
    }
    else
    {
      //24Cxx: the memory address phase of a write, then the bytes
      uint32 two = (chip == I2C_CHIP_24C64) || (chip == I2C_CHIP_24C512);

      if(!rw && (bytes == 0))
      {
        if(two)
        {
          eptr = ev->value << 8;
          p = i2c_str(p, "Addr high ", end);
          i2ct_num(p, ev->value, 8, 0);
        }
        else
        {
          eptr = ev->value;

          //24C04 / 08 / 16: the block bits A2..A0 of the device address are address bits 10..8
          if(chip == I2C_CHIP_24C16)
            eptr |= (dev & 7) << 8;

          p = i2c_str(p, "Address -> ", end);
          i2c_hex4(p, (uint32)eptr);
        }
      }
      else if(!rw && two && (bytes == 1))
      {
        eptr |= ev->value;
        p = i2c_str(p, "Addr low -> ", end);
        i2c_hex4(p, (uint32)eptr);
      }
      else
      {
        //A read of a 24C04/08/16 takes the block from the device address only when the pointer is unknown
        p = i2c_str(p, rw ? "Read [" : "Write [", end);

        if(eptr < 0)
          p = i2c_str(p, "?", end);
        else
          p = i2c_hex4(p, (uint32)eptr);

        p = i2c_str(p, "] = ", end);
        i2ct_num(p, ev->value, 8, 0);

        if(eptr >= 0)
          eptr = (eptr + 1) & 0xFFFF;
      }
    }

    bytes++;
  }
}

#endif

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01a8: the chips come from files on the SD card, \i2c_chips\*.txt (one chip per file, the format in README.txt of
//that folder); without the folder (or no valid file) the built-in DS3231M and 24C32/64 descriptions below are used,
//in the same format. The files are read again every time the List opens. Chip = Auto: the chips with AUTO=1 whose
//address range holds the device address, the narrowest range wins; Off: no Info; otherwise the chosen chip only.
//The built-in chips of v1.01a4 .. a7 are kept above (#if 0).
//#define I2CD_MAXCHIPS   24
#define I2CD_MAXCHIPS   48     //v1.01b0
#define I2CD_MAXREGS    64
#define I2CD_NAME       27
#define I2CD_RNAME      18
//#define I2CD_EXTRA      64
#define I2CD_EXTRA      96     //v1.01b0: long bit name lists

#define I2CD_HEX        0
#define I2CD_DEC        1
#define I2CD_SDEC       2
#define I2CD_BCD        3
#define I2CD_BIN        4
#define I2CD_BITS       5
#define I2CD_FRAC2      6

//v1.01b0: the tabs of the Chip window (CAT= of the files; tab 0 All)
#define I2C_CAT_TABS    8

static const char *const i2c_cat_names[I2C_CAT_TABS] = { "All", "RTC", "Memory", "Sensors", "Converters", "I/O", "Power", "Display" };

typedef struct
{
  uint16 reg;
  uint8  type;
  uint8  mask;
  char   name[I2CD_RNAME];
  char   extra[I2CD_EXTRA];
} I2CDREG;

typedef struct
{
  char    name[I2CD_NAME];
  char    shortn[8];
  uint8   lo, hi, autoon, regaddr, blockbits, memory, regsize, autoinc;
  uint8   lo2, hi2, have2;        //v1.01b0: a second address / range (ADDR2)
  uint8   cat;                    //v1.01b0: tab of the Chip window (CAT), 0 = only under All
  uint16  last;
  uint8   nregs;
  I2CDREG data;                   //REGADDR=0: every data byte
  I2CDREG regs[I2CD_MAXREGS];
} I2CDCHIP;

uint8 scope_i2c_chip = 0;         //0 Auto, 1 Off, 2.. the chips in name order

static I2CDCHIP i2cd[I2CD_MAXCHIPS];
static I2CDCHIP i2cd_tmp;
static uint32   i2cd_n = 0;

//v1.01b4: the chosen chip kept by its NAME too (saved in the settings), so it stays the same chip when files are added
//to \i2c_chips\ (the number alone would point to another one); empty: Auto / Off or older settings (the number used)
static char     i2cd_chosen[DEC_CHIPNAME_WORDS * 2];     //at least I2CD_NAME

static void i2c_chip_name_keep(void)
{
  uint32 i;

  for(i = 0; i < sizeof(i2cd_chosen); i++)
    i2cd_chosen[i] = 0;

  if((scope_i2c_chip >= 2) && ((uint32)(scope_i2c_chip - 2) < i2cd_n))
    for(i = 0; (i < (I2CD_NAME - 1)) && i2cd[scope_i2c_chip - 2].name[i]; i++)
      i2cd_chosen[i] = i2cd[scope_i2c_chip - 2].name[i];
}

//The chip of the kept name after the chips are loaded (Auto when it is not there any more)
static void i2c_chip_name_find(void)
{
  uint32 c, i;

  if((scope_i2c_chip < 2) || !i2cd_chosen[0])
    return;

  for(c = 0; c < i2cd_n; c++)
  {
    for(i = 0; (i < (I2CD_NAME - 1)) && i2cd_chosen[i] && (i2cd_chosen[i] == i2cd[c].name[i]); i++);

    if((i2cd_chosen[i] == 0) && (i2cd[c].name[i] == 0))
    {
      scope_i2c_chip = (uint8)(c + 2);
      return;
    }
  }

  scope_i2c_chip = 0;
  i2c_chip_name_keep();
}

//Saved in DEC_CHIPNAME_WORDS settings words, two characters in each
void scope_i2c_chip_name_save(uint16 *p)
{
  uint32 i;

  for(i = 0; i < DEC_CHIPNAME_WORDS; i++)
    p[i] = (uint16)((uint8)i2cd_chosen[i * 2] | ((uint8)i2cd_chosen[(i * 2) + 1] << 8));
}

void scope_i2c_chip_name_load(const uint16 *p)
{
  uint32 i;

  for(i = 0; i < DEC_CHIPNAME_WORDS; i++)
  {
    i2cd_chosen[i * 2]       = (char)(p[i] & 0xFF);
    i2cd_chosen[(i * 2) + 1] = (char)(p[i] >> 8);
  }

  i2cd_chosen[I2CD_NAME - 1] = 0;
}
static char     i2cd_file[4096];

static const char i2cd_builtin_ds3231[] =
  "NAME=DS3231M RTC\nSHORT=DS3231\nADDR=68\nAUTO=1\nREGADDR=1\nLAST=12\n"
  "REG=00,Seconds,BCD,7F\nREG=01,Minutes,BCD,7F\nREG=02,Hours,BCD,3F\nREG=03,Day,BCD,07\nREG=04,Date,BCD,3F\n"
  "REG=05,Month,BCD,1F\nREG=06,Year,BCD\nREG=07,A1 Seconds,BCD,7F\nREG=08,A1 Minutes,BCD,7F\nREG=09,A1 Hours,BCD,3F\n"
  "REG=0A,A1 Day/Date,BCD,3F\nREG=0B,A2 Minutes,BCD,7F\nREG=0C,A2 Hours,BCD,3F\nREG=0D,A2 Day/Date,BCD,3F\n"
  "REG=0E,Control,BITS,EOSC,BBSQW,CONV,RS2,RS1,INTCN,A2IE,A1IE\nREG=0F,Status,BITS,OSF,-,-,-,EN32k,BSY,A2F,A1F\n"
  "REG=10,Aging,SDEC\nREG=11,Temp MSB,SDEC,C\nREG=12,Temp LSB,FRAC2\n";

static const char i2cd_builtin_24c64[] =
  "NAME=24C32/64 EEPROM\nSHORT=24C64\nADDR=50-57\nAUTO=1\nMEMORY=1\nREGADDR=2\n";

static uint32 i2cd_hexval(const char *s, uint32 *v)
{
  uint32 n = 0, d = 0, c;

  while(*s == ' ')
    s++;

  for(; *s; s++, d++)
  {
    c = (uint8)*s;

    if((c >= '0') && (c <= '9'))      n = (n << 4) | (c - '0');
    else if((c >= 'a') && (c <= 'f')) n = (n << 4) | (c - 'a' + 10);
    else if((c >= 'A') && (c <= 'F')) n = (n << 4) | (c - 'A' + 10);
    else break;
  }

  *v = n;
  return(d);
}

static void i2cd_copy(char *dst, const char *src, uint32 size)
{
  uint32 i = 0;

  while(*src == ' ')
    src++;

  while(src[i] && (i < (size - 1)))
  {
    dst[i] = src[i];
    i++;
  }

  //No trailing blanks
  while(i && (dst[i - 1] == ' '))
    i--;

  dst[i] = 0;
}

static uint32 i2cd_streq(const char *a, const char *b)
{
  while(*a && *b)
  {
    uint8 x = (uint8)*a++, y = (uint8)*b++;

    if((x >= 'a') && (x <= 'z')) x -= 32;
    if((y >= 'a') && (y <= 'z')) y -= 32;

    if(x != y)
      return(0);
  }

  return(*a == *b);
}

static uint8 i2cd_type(const char *t)
{
  if(i2cd_streq(t, "DEC"))   return(I2CD_DEC);
  if(i2cd_streq(t, "SDEC"))  return(I2CD_SDEC);
  if(i2cd_streq(t, "BCD"))   return(I2CD_BCD);
  if(i2cd_streq(t, "BIN"))   return(I2CD_BIN);
  if(i2cd_streq(t, "BITS"))  return(I2CD_BITS);
  if(i2cd_streq(t, "FRAC2")) return(I2CD_FRAC2);
  return(I2CD_HEX);
}

//"name,type,extra..." (the register number already taken off) into a register entry
static void i2cd_regfields(I2CDREG *r, char *v)
{
  char *f[3] = { v, 0, 0 };
  uint32 k = 1, m;

  //The first two commas split name, type and the rest (the extra keeps its commas: bit names)
  for(; *v && (k < 3); v++)
  {
    if(*v == ',')
    {
      *v = 0;
      f[k++] = v + 1;
    }
  }

  i2cd_copy(r->name, f[0], I2CD_RNAME);
  r->type     = f[1] ? i2cd_type(f[1]) : I2CD_HEX;
  r->mask     = 0;
  r->extra[0] = 0;

  if(f[2])
  {
    if((r->type == I2CD_HEX) || (r->type == I2CD_BCD))
    {
      if(i2cd_hexval(f[2], &m))
        r->mask = (uint8)m;
    }
    else
      i2cd_copy(r->extra, f[2], I2CD_EXTRA);
  }
}

//Parse a description (text, \r \n line ends) into i2cd_tmp; 1 when it has a NAME and an address
static uint32 i2cd_parse(char *t)
{
  I2CDCHIP *c = &i2cd_tmp;
  char *line, *eq, *v;
  uint32 x, haveaddr = 0;

  memset(c, 0, sizeof(I2CDCHIP));
  c->regaddr = 1;
  c->regsize = 1;
  c->autoinc = 1;
  c->autoon  = 1;
  c->last    = 0xFF;

  while(*t)
  {
    line = t;

    while(*t && (*t != '\n') && (*t != '\r'))
      t++;

    while((*t == '\n') || (*t == '\r'))
      *t++ = 0;

    while(*line == ' ')
      line++;

    if((*line == '#') || (*line == 0))
      continue;

    for(eq = line; *eq && (*eq != '='); eq++);

    if(!*eq)
      continue;

    *eq = 0;
    v = eq + 1;

    if(i2cd_streq(line, "NAME"))           i2cd_copy(c->name, v, I2CD_NAME);
    else if(i2cd_streq(line, "SHORT"))     i2cd_copy(c->shortn, v, sizeof(c->shortn));
    else if(i2cd_streq(line, "ADDR"))
    {
      uint32 n = i2cd_hexval(v, &x);

      c->lo = c->hi = (uint8)(x & 0x7F);
      haveaddr = (n > 0);

      while(*v && (*v != '-'))
        v++;

      if((*v == '-') && i2cd_hexval(v + 1, &x))
        c->hi = (uint8)(x & 0x7F);
    }
    else if(i2cd_streq(line, "ADDR2"))
    {
      //v1.01b0: a second address or range
      if(i2cd_hexval(v, &x))
      {
        c->lo2 = c->hi2 = (uint8)(x & 0x7F);
        c->have2 = 1;

        while(*v && (*v != '-'))
          v++;

        if((*v == '-') && i2cd_hexval(v + 1, &x))
          c->hi2 = (uint8)(x & 0x7F);
      }
    }
    else if(i2cd_streq(line, "CAT"))
    {
      //v1.01b0: RTC, Memory, Sensors, Converters, I/O, Power, Display
      uint32 k;

      for(k = 1; k < I2C_CAT_TABS; k++)
        if(i2cd_streq(v, i2c_cat_names[k]))
          c->cat = (uint8)k;
    }
    else if(i2cd_streq(line, "AUTO"))      { i2cd_hexval(v, &x); c->autoon = (x != 0); }
    else if(i2cd_streq(line, "REGADDR"))   { i2cd_hexval(v, &x); c->regaddr = (uint8)((x > 2) ? 2 : x); }
    else if(i2cd_streq(line, "BLOCKBITS")) { i2cd_hexval(v, &x); c->blockbits = (uint8)((x > 3) ? 3 : x); }
    else if(i2cd_streq(line, "MEMORY"))    { i2cd_hexval(v, &x); c->memory = (x != 0); }
    else if(i2cd_streq(line, "REGSIZE"))   { i2cd_hexval(v, &x); c->regsize = (x == 2) ? 2 : 1; }
    else if(i2cd_streq(line, "AUTOINC"))   { i2cd_hexval(v, &x); c->autoinc = (x != 0); }
    else if(i2cd_streq(line, "LAST"))      { i2cd_hexval(v, &x); c->last = (uint16)x; }
    else if(i2cd_streq(line, "DATA"))      i2cd_regfields(&c->data, v);
    else if(i2cd_streq(line, "REG") && (c->nregs < I2CD_MAXREGS))
    {
      char *q = v;

      if(!i2cd_hexval(v, &x))
        continue;

      while(*q && (*q != ','))
        q++;

      if(!*q)
        continue;

      c->regs[c->nregs].reg = (uint16)x;
      i2cd_regfields(&c->regs[c->nregs], q + 1);
      c->nregs++;
    }
  }

  if(!c->shortn[0])
    i2cd_copy(c->shortn, c->name, sizeof(c->shortn));

  if(c->hi < c->lo)
    c->hi = c->lo;

  if(c->hi2 < c->lo2)
    c->hi2 = c->lo2;

  return(c->name[0] && haveaddr);
}

//i2cd_tmp into the list, kept in name order
static void i2cd_insert(void)
{
  uint32 i, k;

  if(i2cd_n >= I2CD_MAXCHIPS)
    return;

  for(i = 0; i < i2cd_n; i++)
  {
    const char *a = i2cd_tmp.name, *b = i2cd[i].name;

    for(k = 0; a[k] && (a[k] == b[k]); k++);

    if((uint8)a[k] < (uint8)b[k])
      break;
  }

  for(k = i2cd_n; k > i; k--)
    memcpy(&i2cd[k], &i2cd[k - 1], sizeof(I2CDCHIP));

  memcpy(&i2cd[i], &i2cd_tmp, sizeof(I2CDCHIP));
  i2cd_n++;
}

static void i2cd_builtin(const char *t)
{
  uint32 i;

  for(i = 0; t[i] && (i < (sizeof(i2cd_file) - 1)); i++)
    i2cd_file[i] = t[i];

  i2cd_file[i] = 0;

  if(i2cd_parse(i2cd_file))
    i2cd_insert();
}

void scope_i2c_load_chips(void)
{
  DIR     dir;
  FILINFO fno;
  FIL     fp;
  UINT    br;
  char    path[48];
  uint32  i, k, len;

  i2cd_n = 0;

  if(f_opendir(&dir, "\\i2c_chips") == FR_OK)
  {
    while((f_readdir(&dir, &fno) == FR_OK) && fno.fname[0])
    {
      if(fno.fattrib & AM_DIR)
        continue;

      for(len = 0; fno.fname[len]; len++);

      //*.txt
      if((len < 5) || !i2cd_streq(&fno.fname[len - 4], ".txt") || (len > 30))
        continue;

      k = 0;
      for(i = 0; "\\i2c_chips\\"[i]; i++) path[k++] = "\\i2c_chips\\"[i];
      for(i = 0; i < len; i++) path[k++] = fno.fname[i];
      path[k] = 0;

      if(f_open(&fp, path, FA_READ) != FR_OK)
        continue;

      br = 0;

      if(f_read(&fp, i2cd_file, sizeof(i2cd_file) - 1, &br) != FR_OK)
        br = 0;

      f_close(&fp);
      i2cd_file[br] = 0;

      if(br && i2cd_parse(i2cd_file))
        i2cd_insert();
    }

    f_closedir(&dir);
  }

  if(!i2cd_n)
  {
    i2cd_builtin(i2cd_builtin_ds3231);
    i2cd_builtin(i2cd_builtin_24c64);
  }

  i2c_chip_name_find();     //v1.01b4

  if(scope_i2c_chip >= (i2cd_n + 2))
    scope_i2c_chip = 0;
}

//v1.01b0: the chip answers to dev (ADDR or ADDR2); *w the width of the range that holds it
static uint32 i2cd_has(const I2CDCHIP *c, uint32 dev, uint32 *w)
{
  if((dev >= c->lo) && (dev <= c->hi))
  {
    *w = c->hi - c->lo;
    return(1);
  }

  if(c->have2 && (dev >= c->lo2) && (dev <= c->hi2))
  {
    *w = c->hi2 - c->lo2;
    return(1);
  }

  return(0);
}

//The chip of a device address: its index, -1 none
static int32 i2cd_for(uint32 dev)
{
  int32  best = -1;
  uint32 i, w, bw = 0x100;

  if(scope_i2c_chip == 1)
    return(-1);

  if(scope_i2c_chip >= 2)
  {
    i = scope_i2c_chip - 2;
    return(((i < i2cd_n) && i2cd_has(&i2cd[i], dev, &w)) ? (int32)i : -1);
  }

  for(i = 0; i < i2cd_n; i++)
  {
    if(!i2cd[i].autoon || !i2cd_has(&i2cd[i], dev, &w))
      continue;

    if(w < bw)
    {
      bw = w;
      best = (int32)i;
    }
  }

  return(best);
}

#if 0     //v1.01b0: the window with tabs counts its own rows (i2cc_filter)
//Choices of the Chip button: 0 Auto, 1 Off, then the chips
static uint32 i2c_nchoices(void)
{
  return(i2cd_n + 2);
}
#endif

static void i2c_choice_name(uint32 r, char *buf, uint32 size)
{
  char *p = buf, *end = buf + size - 1;

  if(r == 0)      { i2c_str(p, "Auto (by address)", end); return; }
  if(r == 1)      { i2c_str(p, "Off", end); return; }
  if((r - 2) >= i2cd_n) { *p = 0; return; }

  p = i2c_str(p, i2cd[r - 2].name, end);
  p = i2c_str(p, "  (0x", end);
  if(p < (end - 2)) { i2c_hex2(p, i2cd[r - 2].lo); p += 2; *p = 0; }

  if(i2cd[r - 2].hi != i2cd[r - 2].lo)
  {
    p = i2c_str(p, "..", end);
    if(p < (end - 2)) { i2c_hex2(p, i2cd[r - 2].hi); p += 2; *p = 0; }
  }

  //v1.01b0: the second address / range
  if(i2cd[r - 2].have2)
  {
    p = i2c_str(p, ", 0x", end);
    if(p < (end - 2)) { i2c_hex2(p, i2cd[r - 2].lo2); p += 2; *p = 0; }

    if(i2cd[r - 2].hi2 != i2cd[r - 2].lo2)
    {
      p = i2c_str(p, "..", end);
      if(p < (end - 2)) { i2c_hex2(p, i2cd[r - 2].hi2); p += 2; *p = 0; }
    }
  }

  i2c_str(p, ")", end);
}

static const char *i2c_choice_short(void)
{
  if(scope_i2c_chip == 0) return("Auto");
  if(scope_i2c_chip == 1) return("Off");
  if((uint32)(scope_i2c_chip - 2) < i2cd_n) return(i2cd[scope_i2c_chip - 2].shortn);
  return("Auto");
}

static char *i2c_hex4(char *p, uint32 v)
{
  *p++ = '0'; *p++ = 'x';
  *p++ = i2c_hexd[(v >> 12) & 15];
  *p++ = i2c_hexd[(v >> 8) & 15];
  *p++ = i2c_hexd[(v >> 4) & 15];
  *p++ = i2c_hexd[v & 15];
  *p = 0;
  return(p);
}

//A value as its register type says (bits = 8 or 16)
static char *i2cd_value(char *p, char *end, const I2CDREG *r, uint32 v, uint32 bits)
{
  char  t[24];
  int32 sv;
  uint32 b, k;

  switch(r ? r->type : I2CD_HEX)
  {
    case I2CD_DEC:
      scope_print_decimal(t, (int32)v, 0, 0);
      p = i2c_str(p, t, end);
      break;

    case I2CD_SDEC:
      sv = (bits > 8) ? (int32)(int16)v : (int32)(signed char)v;
      scope_print_decimal(t, (sv < 0) ? -sv : sv, 0, (sv < 0) ? 1 : 0);
      p = i2c_str(p, t, end);
      break;

    case I2CD_BCD:
      if(r->mask) v &= r->mask;
      t[0] = '0' + ((v >> 4) & 15);
      t[1] = '0' + (v & 15);
      t[2] = 0;
      p = i2c_str(p, t, end);
      break;

    case I2CD_BIN:
      for(b = bits, k = 0; b-- > 0; )
        t[k++] = ((v >> b) & 1) ? '1' : '0';
      t[k] = 0;
      p = i2c_str(p, t, end);
      break;

    case I2CD_BITS:
    {
      //Names of bit 7 .. bit 0 in the extra, comma separated; the set bits listed
      const char *e = r->extra;
      uint32 any = 0;

      for(b = 8; b-- > 0; )
      {
        char nm[16];

        for(k = 0; *e && (*e != ',') && (k < 15); e++)
          nm[k++] = *e;

        nm[k] = 0;

        while(*e && (*e != ','))
          e++;

        if(*e == ',')
          e++;

        if(((v >> b) & 1) && nm[0] && !((nm[0] == '-') && !nm[1]))
        {
          if(any) p = i2c_str(p, " ", end);
          p = i2c_str(p, nm, end);
          any = 1;
        }
      }

      if(!any)
        p = i2c_str(p, "-", end);

      return(p);
    }

    case I2CD_FRAC2:
      p = i2c_str(p, (const char *[]){ ".00", ".25", ".50", ".75" }[(v >> 6) & 3], end);
      break;

    default:
      if(r && r->mask) v &= r->mask;
      if(bits > 8) i2c_hex4(t, v);
      else { t[0] = '0'; t[1] = 'x'; i2c_hex2(&t[2], (uint8)v); t[4] = 0; }
      p = i2c_str(p, t, end);
      break;
  }

  //A unit after DEC / SDEC
  if(r && ((r->type == I2CD_DEC) || (r->type == I2CD_SDEC)) && r->extra[0])
  {
    p = i2c_str(p, " ", end);
    p = i2c_str(p, r->extra, end);
  }

  return(p);
}

static const I2CDREG *i2cd_reg(const I2CDCHIP *c, uint32 reg)
{
  uint32 i;

  for(i = 0; i < c->nregs; i++)
    if(c->regs[i].reg == reg)
      return(&c->regs[i]);

  return(0);
}

//"name" of a register, or "Reg 0x3F"
static char *i2cd_regname(char *p, char *end, const I2CDCHIP *c, uint32 reg)
{
  const I2CDREG *r = i2cd_reg(c, reg);
  char t[8];

  if(r && r->name[0])
    return(i2c_str(p, r->name, end));

  p = i2c_str(p, "Reg ", end);
  t[0] = '0'; t[1] = 'x';
  i2c_hex2(&t[2], (uint8)reg);
  t[4] = 0;
  return(i2c_str(p, t, end));
}

//The Info column for all rows
static void i2ct_annotate(void)
{
  static int32 ptr[I2CD_MAXCHIPS];
  static uint8 hib[I2CD_MAXCHIPS], half[I2CD_MAXCHIPS];
  uint32 e, bytes = 0, dev = 0, rw = 0;
  int32  c = -1;
  char  *p, *end;
  I2CDCHIP *ch;
  I2CEVENT *ev;

  for(e = 0; e < I2CD_MAXCHIPS; e++)
  {
    ptr[e]  = -1;
    half[e] = 0;
  }

  for(e = 0; e < i2c_nev; e++)
  {
    ev  = &i2c_ev[e];
    p   = i2ct_info[e];
    end = &i2ct_info[e][I2C_INFO_LEN - 1];
    *p  = 0;

    if(ev->type != I2C_EV_BYTE)
      continue;

    if(ev->addr == 1)
    {
      dev   = ev->value >> 1;
      rw    = ev->value & 1;
      bytes = 0;
      c     = i2cd_for(dev);

      if(c >= 0)
      {
        i2c_str(p, i2cd[c].name, end);
        half[c] = 0;
      }

      continue;
    }

    if((c < 0) || (ev->addr == 2))
      continue;

    ch = &i2cd[c];

    if(ch->regaddr == 0)
    {
      //No registers: every byte is the chip's data
      p = i2c_str(p, ch->data.name[0] ? ch->data.name : "Data", end);
      p = i2c_str(p, " = ", end);
      i2cd_value(p, end, &ch->data, ev->value, 8);
    }
    else if(!rw && (bytes < ch->regaddr))
    {
      //The register / memory address the master writes first
      if((ch->regaddr == 2) && (bytes == 0))
      {
        ptr[c] = ev->value << 8;
        p = i2c_str(p, "Addr high ", end);
        i2cd_value(p, end, 0, ev->value, 8);
      }
      else
      {
        ptr[c] = (ch->regaddr == 2) ? ((ptr[c] & 0xFF00) | ev->value) : ev->value;

        if(ch->blockbits)
          ptr[c] |= (dev & ((1 << ch->blockbits) - 1)) << 8;

        half[c] = 0;

        if(ch->memory)
        {
          p = i2c_str(p, "Address -> ", end);
          i2c_hex4(p, (uint32)ptr[c]);
        }
        else
        {
          p = i2c_str(p, "Reg -> ", end);
          i2cd_regname(p, end, ch, (uint32)ptr[c]);
        }
      }
    }
    else if(ptr[c] < 0)
      i2c_str(p, ch->memory ? (rw ? "Read [?]" : "Write [?]") : "? (register unknown)", end);
    else if(ch->memory)
    {
      p = i2c_str(p, rw ? "Read [" : "Write [", end);
      p = i2c_hex4(p, (uint32)ptr[c]);
      p = i2c_str(p, "] = ", end);
      i2cd_value(p, end, 0, ev->value, 8);
      ptr[c] = (ptr[c] + 1) & 0xFFFF;
    }
    else
    {
      const I2CDREG *r = i2cd_reg(ch, (uint32)ptr[c]);
      uint32 next = 1;

      if(ch->regsize == 2)
      {
        if(!half[c])
        {
          //The high byte; the value comes with the low one
          hib[c]  = ev->value;
          half[c] = 1;
          next    = 0;
          p = i2cd_regname(p, end, ch, (uint32)ptr[c]);
          p = i2c_str(p, " hi", end);
        }
        else
        {
          half[c] = 0;
          p = i2cd_regname(p, end, ch, (uint32)ptr[c]);
          p = i2c_str(p, " = ", end);
          i2cd_value(p, end, r, ((uint32)hib[c] << 8) | ev->value, 16);
        }
      }
      else
      {
        p = i2cd_regname(p, end, ch, (uint32)ptr[c]);
        p = i2c_str(p, " = ", end);
        i2cd_value(p, end, r, ev->value, 8);
      }

      if(next && ch->autoinc)
        ptr[c] = (ptr[c] >= ch->last) ? 0 : (ptr[c] + 1);
    }

    bytes++;
  }
}

#if 0     //v1.01b0: replaced by the window with tabs below
//v1.01a7: the chip choice: a window with one row per chip, moved with the finger, a tap on a row takes it, Close
//(or a tap outside) leaves the choice as it is
#define I2CC_X        150
#define I2CC_Y        50
#define I2CC_W        500
#define I2CC_H        410
#define I2CC_ROW_H    44
#define I2CC_ROWS     7
#define I2CC_Y0       (I2CC_Y + 50)

static void i2cc_draw(int32 top)
{
  int32 r, y;

  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(I2CC_X, I2CC_Y, I2CC_W, I2CC_H);
  display_set_fg_color(0x0040C040);
  display_draw_rect(I2CC_X, I2CC_Y, I2CC_W, I2CC_H);

  display_set_font(&font_3);
  display_set_fg_color(0x0060E060);
  display_text(I2CC_X + 12, I2CC_Y + 14, "Chip for the Info column");

  display_set_fg_color(MIDLEGREY_COLOR);
  display_fill_rounded_rect(I2CC_X + I2CC_W - 90, I2CC_Y + 6, 80, 36, 3);
  display_set_fg_color(WHITE_COLOR);
  display_text(I2CC_X + I2CC_W - 78, I2CC_Y + 15, "Close");

  for(r = 0; (r < I2CC_ROWS) && ((uint32)(top + r) < i2c_nchoices()); r++)
  {
    char nm[48];

    y = I2CC_Y0 + (r * I2CC_ROW_H);

    display_set_fg_color(((top + r) == scope_i2c_chip) ? 0x0040C040 : (((top + r) & 1) ? 0x00303030 : 0x00262626));
    display_fill_rounded_rect(I2CC_X + 8, y, I2CC_W - 16, I2CC_ROW_H - 4, 3);
    display_set_fg_color(((top + r) == scope_i2c_chip) ? BLACK_COLOR : WHITE_COLOR);
    i2c_choice_name((uint32)(top + r), nm, sizeof(nm));
    //display_text(I2CC_X + 20, y + 12, (int8 *)nm);
    //v1.01a9: the chips numbered (1 ..) in front of the name, Auto / Off without a number
    if((top + r) >= 2)
    {
      char num[8];

      i2c_str(scope_print_decimal(num, top + r - 1, 0, 0), ".", num + 7);
      display_text(I2CC_X + 20, y + 12, (int8 *)num);
    }

    display_text(I2CC_X + 56, y + 12, (int8 *)nm);
  }

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(I2CC_X, I2CC_Y, I2CC_W + 1, I2CC_H + 1);
}

static void i2c_chip_pick(void)
{
  int32 n = (int32)i2c_nchoices(), top = 0, maxtop = (n > I2CC_ROWS) ? (n - I2CC_ROWS) : 0, x0, y0, top0, nt, moved, r;

  tp_i2c_wait_for_touch_release();
  i2cc_draw(top);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x0 = xtouch;
    y0 = ytouch;

    //Outside or Close
    if((x0 < I2CC_X) || (x0 > (I2CC_X + I2CC_W)) || (y0 < I2CC_Y) || (y0 > (I2CC_Y + I2CC_H)) ||
       ((x0 >= (I2CC_X + I2CC_W - 90)) && (y0 <= (I2CC_Y + 44))))
    {
      tp_i2c_wait_for_touch_release();
      return;
    }

    //Drag moves the rows, a tap without moving takes a row
    top0  = top;
    moved = 0;

    while(havetouch)
    {
      if((((int32)ytouch - y0) > 8) || ((y0 - (int32)ytouch) > 8))
        moved = 1;

      nt = top0 + ((y0 - (int32)ytouch) / I2CC_ROW_H);

      if(nt < 0)      nt = 0;
      if(nt > maxtop) nt = maxtop;

      if(nt != top)
      {
        top = nt;
        i2cc_draw(top);
      }

      tp_i2c_read_status();
    }

    if(!moved && (y0 >= I2CC_Y0))
    {
      r = top + ((y0 - I2CC_Y0) / I2CC_ROW_H);

      if((r >= 0) && (r < n) && ((y0 - I2CC_Y0) < (I2CC_ROWS * I2CC_ROW_H)))
      {
        scope_i2c_chip = (uint8)r;
        i2c_chip_name_keep();     //v1.01b4
        i2cc_draw(top);
        return;
      }
    }
  }
}
#endif

//v1.01b0: the chip choice with tabs on top (All, RTC, Memory, Sensors, Converters, I/O, Power, Display: CAT= of the
//files) that show only the chips of that kind; Auto and Off are always the first two rows. The rows move with the
//finger, a tap on a row takes it, Close (or a tap outside) leaves the choice. Numbers as in All. The window of v1.01a7
//(no tabs) above.
#define I2CC2_X       20
#define I2CC2_Y       40
#define I2CC2_W       760
#define I2CC2_H       432
#define I2CC2_TAB_Y   (I2CC2_Y + 46)
#define I2CC2_TAB_W   92
#define I2CC3_TAB_W   82      //v1.01b5: 8 tabs and Close in one row
#define I2CC2_ROW_H   44
#define I2CC2_Y0      (I2CC2_Y + 92)
#define I2CC2_ROWS    7

static uint8  i2cc_tab = 0;
static uint8  i2cc_list[I2CD_MAXCHIPS + 2];
static uint32 i2cc_n = 0;

//The choices of the tab: Auto, Off, then the chips of that kind
static void i2cc_filter(void)
{
  uint32 i;

  i2cc_n = 0;
  i2cc_list[i2cc_n++] = 0;
  i2cc_list[i2cc_n++] = 1;

  for(i = 0; i < i2cd_n; i++)
    if((i2cc_tab == 0) || (i2cd[i].cat == i2cc_tab))
      i2cc_list[i2cc_n++] = (uint8)(i + 2);
}

static void i2cc2_draw(int32 top)
{
  int32 r, y, t;
  uint32 c;
  char  nm[56], num[8];

  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(I2CC2_X, I2CC2_Y, I2CC2_W, I2CC2_H);
  display_set_fg_color(0x0040C040);
  display_draw_rect(I2CC2_X, I2CC2_Y, I2CC2_W, I2CC2_H);

  display_set_font(&font_3);
  display_set_fg_color(0x0060E060);
  display_text(I2CC2_X + 12, I2CC2_Y + 12, "Chip for the Info column");

  //display_set_fg_color(MIDLEGREY_COLOR);
  //display_fill_rounded_rect(I2CC2_X + I2CC2_W - 90, I2CC2_Y + 4, 80, 36, 3);
  //display_set_fg_color(WHITE_COLOR);
  //display_text(I2CC2_X + I2CC2_W - 78, I2CC2_Y + 13, "Close");

  //Tabs
  //v1.01b5: narrower (82 apart), the texts centred, Close as the last one of the row in red with a light edge
  for(t = 0; t < I2C_CAT_TABS; t++)
  {
    int32 x = I2CC2_X + 8 + (t * I2CC3_TAB_W);

    display_set_fg_color((t == i2cc_tab) ? ORANGE_COLOR : MIDLEGREY_COLOR);
    display_fill_rounded_rect(x, I2CC2_TAB_Y, I2CC3_TAB_W - 4, 36, 3);
    display_set_fg_color((t == i2cc_tab) ? BLACK_COLOR : WHITE_COLOR);
    display_text(x + ((I2CC3_TAB_W - 4 - (int32)scope_text_width(i2c_cat_names[t])) / 2), I2CC2_TAB_Y + 10, (int8 *)i2c_cat_names[t]);
  }

  {
    int32 x = I2CC2_X + 8 + (I2C_CAT_TABS * I2CC3_TAB_W);

    display_set_fg_color(0x00A03030);
    display_fill_rounded_rect(x, I2CC2_TAB_Y, I2CC3_TAB_W - 4, 36, 3);
    display_set_fg_color(0x00E08080);
    display_draw_rounded_rect(x, I2CC2_TAB_Y, I2CC3_TAB_W - 4, 36, 3);
    display_set_fg_color(WHITE_COLOR);
    display_text(x + ((I2CC3_TAB_W - 4 - (int32)scope_text_width("Close")) / 2), I2CC2_TAB_Y + 10, "Close");
  }

  for(r = 0; (r < I2CC2_ROWS) && ((uint32)(top + r) < i2cc_n); r++)
  {
    c = i2cc_list[top + r];
    y = I2CC2_Y0 + (r * I2CC2_ROW_H);

    display_set_fg_color((c == scope_i2c_chip) ? 0x0040C040 : ((r & 1) ? 0x00303030 : 0x00262626));
    display_fill_rounded_rect(I2CC2_X + 8, y, I2CC2_W - 16, I2CC2_ROW_H - 4, 3);
    display_set_fg_color((c == scope_i2c_chip) ? BLACK_COLOR : WHITE_COLOR);

    //The number of the chip (as in All), Auto / Off without
    if(c >= 2)
    {
      i2c_str(scope_print_decimal(num, c - 1, 0, 0), ".", num + 7);
      display_text(I2CC2_X + 20, y + 12, (int8 *)num);
    }

    i2c_choice_name(c, nm, sizeof(nm));
    display_text(I2CC2_X + 60, y + 12, (int8 *)nm);
  }

  if(i2cc_n <= 2)
  {
    display_set_fg_color(LIGHTGREY1_COLOR);
    display_text(I2CC2_X + 20, I2CC2_Y0 + (2 * I2CC2_ROW_H) + 12, "No chip of this kind in \\i2c_chips\\");
  }

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(I2CC2_X, I2CC2_Y, I2CC2_W + 1, I2CC2_H + 1);
}

static void i2c_chip_pick(void)
{
  int32 top = 0, maxtop, x0, y0, top0, nt, moved, r;

  tp_i2c_wait_for_touch_release();

  i2cc_filter();
  maxtop = ((int32)i2cc_n > I2CC2_ROWS) ? ((int32)i2cc_n - I2CC2_ROWS) : 0;
  i2cc2_draw(top);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x0 = xtouch;
    y0 = ytouch;

    //Outside or Close
    //v1.01b5: Close in the row of the tabs
    if((x0 < I2CC2_X) || (x0 > (I2CC2_X + I2CC2_W)) || (y0 < I2CC2_Y) || (y0 > (I2CC2_Y + I2CC2_H)) ||
       ((y0 >= I2CC2_TAB_Y) && (y0 < (I2CC2_TAB_Y + 36)) && (x0 >= (I2CC2_X + 8 + (I2C_CAT_TABS * I2CC3_TAB_W)))))
    {
      tp_i2c_wait_for_touch_release();
      return;
    }

    //A tab
    if((y0 >= I2CC2_TAB_Y) && (y0 < (I2CC2_TAB_Y + 36)) && (x0 >= (I2CC2_X + 8)))
    {
      r = (x0 - (I2CC2_X + 8)) / I2CC3_TAB_W;

      if((r >= 0) && (r < I2C_CAT_TABS))
      {
        i2cc_tab = (uint8)r;
        i2cc_filter();
        top    = 0;
        maxtop = ((int32)i2cc_n > I2CC2_ROWS) ? ((int32)i2cc_n - I2CC2_ROWS) : 0;
        i2cc2_draw(top);
      }

      tp_i2c_wait_for_touch_release();
      continue;
    }

    //Drag moves the rows, a tap without moving takes a row
    top0  = top;
    moved = 0;

    while(havetouch)
    {
      if((((int32)ytouch - y0) > 8) || ((y0 - (int32)ytouch) > 8))
        moved = 1;

      nt = top0 + ((y0 - (int32)ytouch) / I2CC2_ROW_H);

      if(nt < 0)      nt = 0;
      if(nt > maxtop) nt = maxtop;

      if(nt != top)
      {
        top = nt;
        i2cc2_draw(top);
      }

      tp_i2c_read_status();
    }

    if(!moved && (y0 >= I2CC2_Y0) && ((y0 - I2CC2_Y0) < (I2CC2_ROWS * I2CC2_ROW_H)))
    {
      r = top + ((y0 - I2CC2_Y0) / I2CC2_ROW_H);

      if((r >= 0) && ((uint32)r < i2cc_n))
      {
        scope_i2c_chip = i2cc_list[r];
        i2c_chip_name_keep();     //v1.01b4
        i2cc2_draw(top);
        return;
      }
    }
  }
}

//v1.01b2: the Info column of 1-Wire: the ROM command after a RESET, the 8 bytes of a ROM code (Read / Match ROM:
//family, serial, CRC), the function command after it (DS18B20 names) and its bytes; Search ROM bits are not decoded
//v1.01b4: the Dallas / Maxim CRC8 (x^8 + x^5 + x^4 + 1, LSB first) of n bytes of the events from e
static uint32 ow_crc8(uint32 e, uint32 n)
{
  uint32 crc = 0, b, k;

  for(; n; n--, e++)
  {
    b = i2c_ev[e].value;

    for(k = 0; k < 8; k++)
    {
      uint32 mix = (crc ^ b) & 1;

      crc >>= 1;
      if(mix) crc ^= 0x8C;
      b >>= 1;
    }
  }

  return(crc);
}

//v1.01b4: the CRC byte at e checked against the n bytes before it: flags bit 1 wrong, bit 2 right; chk the right one
static void ow_crc_check(uint32 e, uint32 n)
{
  uint32 k;

  if(e < n)
    return;

  for(k = e - n; k < e; k++)
    if(i2c_ev[k].type != DEC_EV_OWBYTE)
      return;

  i2c_ev[e].chk    = (uint16)ow_crc8(e - n, n);
  i2c_ev[e].flags |= (i2c_ev[e].chk == i2c_ev[e].value) ? 4 : 2;
}

static void ow_annotate(void)
{
  static const uint8 romcode[8] = { 0x33, 0x55, 0xCC, 0xF0, 0xEC, 0x3C, 0x69, 0xA5 };
  static const char *const romname[8] =
  {
    "Read ROM", "Match ROM", "Skip ROM", "Search ROM", "Alarm search", "Overdrive skip", "Overdrive match", "Resume"
  };
  uint32 e, k, n = 0, state = 0, rom = 0, x;
  char  *p, *end;

  if(scope_dec_proto != DEC_1WIRE)
    return;

  for(e = 0; e < i2c_nev; e++)
  {
    p   = i2ct_info[e];
    end = &i2ct_info[e][I2C_INFO_LEN - 1];
    *p  = 0;

    if(i2c_ev[e].type == DEC_EV_OWRESET)
    {
      state = 1;
      n = 0;
      continue;
    }

    if(i2c_ev[e].type != DEC_EV_OWBYTE)
      continue;

    x = i2c_ev[e].value;

    if(state == 1)
    {
      //The ROM command
      const char *nm = "?";

      for(k = 0; k < 8; k++)
        if(x == romcode[k])
          nm = romname[k];

      i2c_str(p, nm, end);
      rom   = x;
      state = ((x == 0x33) || (x == 0x55) || (x == 0x69)) ? 2 : ((x == 0xF0) || (x == 0xEC)) ? 4 : 3;
      n = 0;
    }
    else if(state == 2)
    {
      //The ROM code
      p = i2c_str(p, (n == 0) ? " Family" : (n == 7) ? " ROM CRC" : " Serial ", end);

      if((n > 0) && (n < 7))
      {
        *p++ = '1' + (n - 1);
        *p = 0;
      }

      if(n == 7)
        ow_crc_check(e, 7);     //v1.01b4

      if(++n == 8)
        state = (rom == 0x33) ? 5 : 3;
    }
    else if(state == 3)
    {
      //The function command (DS18B20 / DS1820 names)
      const char *nm = (x == 0x44) ? "Convert T" : (x == 0xBE) ? "Read scratchpad" : (x == 0x4E) ? "Write scratchpad" :
                       (x == 0x48) ? "Copy scratchpad" : (x == 0xB8) ? "Recall E2" : (x == 0xB4) ? "Read power" : "Function";

      i2c_str(p, nm, end);
      state = (x == 0xBE) ? 6 : 5;     //v1.01b4: Read scratchpad: 8 bytes and their CRC
      n = 0;
    }
    else if(state == 6)
    {
      i2c_str(p, (n == 8) ? " Scratchpad CRC" : " Data", end);

      if(n == 8)
      {
        ow_crc_check(e, 8);
        state = 5;
      }

      n++;
    }
    else if(state == 4)
      i2c_str(p, " (search bits)", end);
    else
      i2c_str(p, " Data", end);
  }
}

#if 0     //v1.01b5: Close is i2ct_close_button
static void i2ct_button(int32 x, int32 y, int32 w, const char *text)
{
  display_set_fg_color(MIDLEGREY_COLOR);
  display_fill_rounded_rect(x, y, w, 40, 3);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(x, y, w, 40, 3);
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  //display_text(x + 10, y + 12, (int8 *)text);
  //v1.01b3: centred
  display_text(x + ((w - (int32)scope_text_width(text)) / 2), y + 12, (int8 *)text);
}
#endif

#define DEC_FILT_ALL    0     //v1.01b6: the List's filter
#define DEC_FILT_ERR    1
#define DEC_FILT_TX     2
#define DEC_FILT_RX     3
#define DEC_FILT_ADDR   4

static uint8  i2ct_filter = DEC_FILT_ALL;
static uint8  i2ct_filter_addr = 0;
static const char *i2ct_filter_name(char *t);

//#define DEC_ERR_COLOR  YELLOW_COLOR     //v1.01b9: errors / NACK in the List (red disturbed)
#define DEC_ERR_COLOR  RED_COLOR        //v1.01c0: real errors may be red; the normal NACK is yellow

static int32  i2ct_mark = -1;               //v1.01b4: the row found by Next, -1 none
static int32  i2ct_mark2 = -1;              //v1.01b8: the second row tapped (time from i2ct_mark), -1 none
static uint32 dec_stat_err = 0;             //v1.01b8: NACK / errors in the record
static uint32 dec_stat_real = 0;            //v1.01c0: of them not the normal NACK at the end of a read
static uint32 dec_stat_baud = 0;            //v1.01b8: UART / LIN rate measured from the record, 0 none
static char   i2ct_status[48];              //v1.01b4: Saved ... / Save failed, in the title row

//v1.01b4: the PID of the LIN frame of the event ev (the PID byte before it), 0 none
static uint32 lin_frame_pid(const I2CEVENT *ev)
{
  int32 e = (int32)(ev - i2c_ev);

  for(e--; e >= 0; e--)
  {
    if(i2c_ev[e].type != DEC_EV_LINBYTE)
      break;

    if(i2c_ev[e].addr == 1)
      return(i2c_ev[e].value);
  }

  return(0);
}

//v1.01b4: the Info text of a LIN checksum, t of 48 characters: right: which sum (LIN 1.x classic, 2.x enhanced);
//wrong: the right one for the chosen version (Auto: both)
static void lin_check_text(char *t, const I2CEVENT *ev)
{
  char  *q, *end = t + 47;
  uint32 w;

  if(!(ev->flags & 16))
  {
    i2c_str(t, (ev->a10 == 2) ? "enhanced (LIN 2.x)" : "classic (LIN 1.x)", end);
    return;
  }

  w = lin_sum_want(lin_frame_pid(ev));

  if(w)
  {
    q = i2c_str(t, "should be ", end);
    i2ct_num(q, (w == 1) ? (ev->chk & 0xFF) : (ev->chk >> 8), 8, scope_i2c_fmt_data);
    return;
  }

  q = i2c_str(t, "1.x: ", end);
  q = i2ct_num(q, ev->chk & 0xFF, 8, scope_i2c_fmt_data);
  q = i2c_str(q, ", 2.x: ", end);
  i2ct_num(q, ev->chk >> 8, 8, scope_i2c_fmt_data);
}

static void i2ct_draw(uint32 top)
{
  char   t[24], *q;
  uint32 r, e, ntr = 0;
  int32  y, bh, by;
  I2CEVENT *ev;

  //Drawn off screen, then copied (no flicker while dragging)
  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);
  i2ct_frame();     //v1.01b5

  for(e = 0; e < i2c_nev; e++)
    if((i2c_ev[e].type == I2C_EV_START) || (i2c_ev[e].type == DEC_EV_SPIFRAME) || (i2c_ev[e].type == DEC_EV_UART) ||
       (i2c_ev[e].type == DEC_EV_OWRESET) || (i2c_ev[e].type == DEC_EV_LINBREAK))     //v1.01b2
      ntr++;

  //Title
  display_set_font(&font_3);
  display_set_fg_color(ORANGE_COLOR);
  //display_text(10, 10, "I2C transactions");
  //v1.01b1: per protocol
  //display_text(10, 10, (scope_dec_proto == DEC_UART) ? "UART bytes" : (scope_dec_proto == DEC_SPI) ? "SPI frames" : "I2C transactions");
  {
    static const char *const title[DEC_PROTOS] = { "I2C transactions", "UART bytes", "SPI frames", "1-Wire resets", "LIN frames" };
    display_text(10, 7, (int8 *)title[scope_dec_proto % DEC_PROTOS]);
  }
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_0);
  q = scope_print_decimal(t, ntr, 0, 0);
  *q = 0;
  display_text(170, 9, t);
  //v1.01b2: the channels as Swap sets them
  {
    static const char *const ch[DEC_PROTOS][2] =
    {
      { "SDA = CH1, SCL = CH2", "SDA = CH2, SCL = CH1" }, { "TX = CH1, RX = CH2", "TX = CH2, RX = CH1" },
      { "SCLK = CH1, data = CH2", "SCLK = CH2, data = CH1" }, { "1-Wire on CH1", "1-Wire on CH2" }, { "LIN on CH1", "LIN on CH2" }
    };
    display_text(220, 9, (int8 *)ch[scope_dec_proto % DEC_PROTOS][scope_dec_swap ? 1 : 0]);
  }

  //v1.01a5: the formats of addresses and data
  //v1.01a6: right under Close, orange (addresses) and blue (data) as in the table
  //v1.01b1: UART / SPI have data only (no addresses, no chips)
  if(scope_dec_proto == DEC_I2C)
    i2ct_fmt_button(54,  "Addr", scope_i2c_fmt_addr, ORANGE_COLOR);     //v1.01b5: 54 / 104 (were 56 / 112)

  i2ct_fmt_button(104, "Data", scope_i2c_fmt_data, 0x0060B0FF);

  //v1.01a7: the chip of the Info column
  if(scope_dec_proto == DEC_I2C)
  {
  //display_set_fg_color(0x0040C040);
  //display_fill_rounded_rect(720, 168, 76, 48, 3);
  //display_set_fg_color(BLACK_COLOR);
  //display_set_font(&font_3);
  //v1.01b3: centred (were from x 730)
  //display_text(758 - ((int32)scope_text_width("Chip") / 2), 173, "Chip");
  //display_text(758 - ((int32)scope_text_width(i2c_choice_short()) / 2), 193, (int8 *)i2c_choice_short());
  i2ct_pbutton(154, "Chip", i2c_choice_short(), 0x0040C040, 0);     //v1.01b5
  }

  //i2ct_button(714, 4, 80, "Close");
  //i2ct_button(720, 4, 76, "Close");
  i2ct_close_button();     //v1.01b5

  //v1.01b4: Next NACK / error, Save and Load; what Save / Load did (v1.01b5: lighter buttons, 210 / 378 / 428)
  i2ct_pbutton(210, "Next", (scope_dec_proto == DEC_I2C) ? "NACK" : "error", YELLOW_COLOR, 0);
  {
    char ft[24];

    i2ct_pbutton(260, "Filter", i2ct_filter_name(ft), 0x00C0C0C0, 0);     //v1.01b6
  }
  i2ct_pbutton(378, "Save", "List", 0x0060A0FF, 0);
  i2ct_pbutton(428, "Load", "List", 0x0060D060, 0);

  if(i2ct_status[0])
  {
    display_set_font(&font_3);
    display_set_fg_color(YELLOW_COLOR);
    display_text(440, 7, (int8 *)i2ct_status);
  }
  else
  {
    //v1.01b8: the statistics of the record: NACK / errors, the measured rate (UART / LIN)
    q = i2c_str(t, (scope_dec_proto == DEC_I2C) ? "NACK " : "Errors ", t + 23);
    q = scope_print_decimal(q, dec_stat_err, 0, 0);

    if(dec_stat_baud && ((scope_dec_proto == DEC_UART) || (scope_dec_proto == DEC_LIN)))
    {
      q = i2c_str(q, "  ~", t + 23);
      q = scope_print_decimal(q, dec_stat_baud, 0, 0);
      i2c_str(q, " Bd", t + 23);
    }
    else
      *q = 0;

    display_set_font(&font_3);
    display_set_fg_color(dec_stat_real ? DEC_ERR_COLOR : dec_stat_err ? YELLOW_COLOR : LIGHTGREY_COLOR);     //v1.01c0: only normal NACKs: yellow
    display_text(440, 7, (int8 *)t);
  }

  //Column heads
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(4, I2CT_Y0 - 22, I2CT_W, 20);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_text(I2CT_X_NUM,   I2CT_Y0 - 20, "#");
  display_text(I2CT_X_TIME,  I2CT_Y0 - 20, "Time");
  display_text(I2CT_X_EVENT, I2CT_Y0 - 20, (scope_dec_proto == DEC_UART) ? "Line" : "Event");
  display_text(I2CT_X_VALUE, I2CT_Y0 - 20, "Value");
  display_text(I2CT_X_ACK,   I2CT_Y0 - 20, (scope_dec_proto == DEC_I2C) ? "Ack" : "Status");
  display_text(I2CT_X_INFO,  I2CT_Y0 - 20, (scope_dec_proto == DEC_UART) ? "Char" : (scope_dec_proto == DEC_SPI) ? "" : "Info");
  (void)dec_names;

  if(!i2c_nev)
  {
    display_set_fg_color(LIGHTGREY_COLOR);
    //display_text(10, I2CT_Y0 + 10, "No I2C data in the record (SDA on CH1, SCL on CH2, both on; STOP and look again)");
    if(scope_dec_proto == DEC_UART)
      display_text(10, I2CT_Y0 + 10, dec_err ? "Too few samples per bit for the baud rate: use a shorter time/div" :
                                               "No UART data in the record (TX on CH1, RX on CH2, baud rate?; STOP and look again)");
    else if(scope_dec_proto == DEC_SPI)
      display_text(10, I2CT_Y0 + 10, "No SPI data in the record (SCLK on CH1, data on CH2, both on; STOP and look again)");
    else if(scope_dec_proto == DEC_1WIRE)
      display_text(10, I2CT_Y0 + 10, dec_err ? "Too few samples for 1-Wire: at least 0.5 MSa/s (overdrive 4 MSa/s)" :
                                               "No 1-Wire data in the record (line on CH1; STOP and look again)");
    else if(scope_dec_proto == DEC_LIN)
      display_text(10, I2CT_Y0 + 10, dec_err ? "Too few samples per bit for the baud rate: use a shorter time/div" :
                                               "No LIN data in the record (line on CH1, baud rate?; STOP and look again)");
    else
      display_text(10, I2CT_Y0 + 10, "No I2C data in the record (SDA on CH1, SCL on CH2, both on; STOP and look again)");
  }

  for(r = 0; (r < I2CT_ROWS) && ((top + r) < i2c_nev); r++)
  {
    ev = &i2c_ev[top + r];
    y  = I2CT_Y0 + (r * I2CT_ROW_H);

    //Shade of the transaction
    display_set_fg_color((i2ct_trn[top + r] & 1) ? 0x00202830 : 0x00101418);
    display_fill_rect(4, y, I2CT_W, I2CT_ROW_H);

    //v1.01b2: the rows of 1-Wire and LIN
    if(ev->type >= DEC_EV_OWRESET)
    {
      if((ev->type == DEC_EV_OWRESET) || (ev->type == DEC_EV_LINBREAK))
      {
        display_set_fg_color(LIGHTGREY_COLOR);
        display_draw_horz_line(y, 4, 4 + I2CT_W - 1);
        display_set_fg_color(WHITE_COLOR);
        scope_print_decimal(t, i2ct_trn[top + r], 0, 0);
        display_text(I2CT_X_NUM, y + 2, t);
      }

      display_set_fg_color(LIGHTGREY_COLOR);
      i2c_time_text(t, ev->i0);
      display_text(I2CT_X_TIME, y + 2, t);

      if(ev->type == DEC_EV_OWRESET)
      {
        display_set_fg_color(GREEN_COLOR);
        display_text(I2CT_X_EVENT, y + 2, "RESET");
        display_set_fg_color((ev->flags & 1) ? GREEN_COLOR : DEC_ERR_COLOR);     //v1.01b9: errors in yellow, not red
        display_text(I2CT_X_ACK, y + 2, (ev->flags & 1) ? "Presence" : "No presence");
        continue;
      }

      if(ev->type == DEC_EV_LINBREAK)
      {
        display_set_fg_color(GREEN_COLOR);
        display_text(I2CT_X_EVENT, y + 2, "BREAK");
        continue;
      }

      if(ev->type == DEC_EV_OWBYTE)
      {
        display_set_fg_color(i2ct_info[top + r][0] && (i2ct_info[top + r][0] != ' ') ? ORANGE_COLOR : 0x0060B0FF);
        display_text(I2CT_X_EVENT, y + 2, "BYTE");
        i2ct_num(t, ev->value, 8, scope_i2c_fmt_data);
        display_text(I2CT_X_VALUE, y + 2, t);
        //display_set_fg_color(GREEN_COLOR);
        //display_text(I2CT_X_ACK, y + 2, "OK");
        //v1.01b4: a CRC byte checked: right or wrong and the right value
        display_set_fg_color((ev->flags & 2) ? DEC_ERR_COLOR : GREEN_COLOR);     //v1.01b9: errors in yellow, not red
        display_text(I2CT_X_ACK, y + 2, (ev->flags & 2) ? "Bad CRC" : (ev->flags & 4) ? "CRC OK" : "OK");

        if(ev->flags & 2)
        {
          q = i2c_str(t, "should be ", t + 23);
          i2ct_num(q, ev->chk & 0xFF, 8, scope_i2c_fmt_data);
          display_set_fg_color(DEC_ERR_COLOR);     //v1.01b9: errors in yellow, not red
          display_text(I2CT_X_INFO + 120, y + 2, t);
        }
      }
      else
      {
        //LIN byte: SYNC, PID (the ID shown), DATA, CHECKSUM
        static const char *const role[4] = { "SYNC", "PID", "DATA", "CHECK" };
        uint32 err = ev->flags & 0x1E;

        display_set_fg_color((ev->addr == 1) ? ORANGE_COLOR : (ev->addr == 3) ? 0x00C080FF : (ev->addr == 0) ? LIGHTGREY_COLOR : 0x0060B0FF);
        display_text(I2CT_X_EVENT, y + 2, (int8 *)role[ev->addr & 3]);

        if(ev->addr == 1)
        {
          q = i2c_str(t, "ID ", t + 23);
          i2ct_num(q, ev->value & 0x3F, 6, scope_i2c_fmt_data);
        }
        else
          i2ct_num(t, ev->value, 8, scope_i2c_fmt_data);

        display_text(I2CT_X_VALUE, y + 2, t);

        display_set_fg_color(err ? DEC_ERR_COLOR : GREEN_COLOR);     //v1.01b9: errors in yellow, not red
        display_text(I2CT_X_ACK, y + 2, (ev->flags & 2) ? "Frame" : (ev->flags & 4) ? "Not 55" : (ev->flags & 8) ? "Parity" :
                                       (ev->flags & 16) ? "Bad sum" : "OK");

        if(ev->addr == 3)
        {
          //display_set_fg_color(WHITE_COLOR);
          //display_text(I2CT_X_INFO, y + 2, (ev->a10 == 2) ? "enhanced" : (ev->a10 == 1) ? "classic" : "");
          //v1.01b4: right: which sum (LIN 1.x classic, 2.x enhanced); wrong: the right one(s) for the chosen version
          char lt[48];

          lin_check_text(lt, ev);
          display_set_fg_color((ev->flags & 16) ? DEC_ERR_COLOR : WHITE_COLOR);     //v1.01b9: errors in yellow, not red
          display_text(I2CT_X_INFO, y + 2, lt);
        }

        continue;
      }

      if(i2ct_info[top + r][0])
      {
        display_set_fg_color(WHITE_COLOR);
        display_text(I2CT_X_INFO, y + 2, i2ct_info[top + r]);
      }

      continue;
    }

    //v1.01b1: the rows of UART and SPI
    if((ev->type == DEC_EV_UART) || (ev->type == DEC_EV_SPIFRAME) || (ev->type == DEC_EV_SPIWORD))
    {
      if(ev->type != DEC_EV_SPIWORD)
      {
        if(ev->type == DEC_EV_SPIFRAME)
        {
          display_set_fg_color(LIGHTGREY_COLOR);
          display_draw_horz_line(y, 4, 4 + I2CT_W - 1);
        }

        display_set_fg_color(WHITE_COLOR);
        scope_print_decimal(t, i2ct_trn[top + r], 0, 0);
        display_text(I2CT_X_NUM, y + 2, t);
      }

      display_set_fg_color(LIGHTGREY_COLOR);
      i2c_time_text(t, ev->i0);
      display_text(I2CT_X_TIME, y + 2, t);

      if(ev->type == DEC_EV_SPIFRAME)
      {
        display_set_fg_color(GREEN_COLOR);
        display_text(I2CT_X_EVENT, y + 2, "FRAME");
        continue;
      }

      if(ev->type == DEC_EV_UART)
      {
        display_set_fg_color((ev->line ^ scope_dec_swap) ? CHANNEL2_COLOR : CHANNEL1_COLOR);
        display_text(I2CT_X_EVENT, y + 2, ev->line ? "RX" : "TX");
        i2ct_num(t, ev->v16, scope_uart_7bit ? 7 : 8, scope_i2c_fmt_data);
        display_set_fg_color(0x0060B0FF);
        display_text(I2CT_X_VALUE, y + 2, t);

        display_set_fg_color(ev->flags ? DEC_ERR_COLOR : GREEN_COLOR);     //v1.01b9: errors in yellow, not red
        display_text(I2CT_X_ACK, y + 2, (ev->flags & 2) ? "Frame" : (ev->flags & 1) ? "Parity" : "OK");

        //The character (printable ASCII)
        t[0] = ((ev->v16 >= 32) && (ev->v16 < 127)) ? (char)ev->v16 : '.';
        t[1] = 0;
        display_set_fg_color(WHITE_COLOR);
        display_text(I2CT_X_INFO, y + 2, t);
        continue;
      }

      //SPI word
      display_set_fg_color(0x0060B0FF);
      display_text(I2CT_X_EVENT, y + 2, "WORD");
      i2ct_num(t, ev->v16, scope_spi_16 ? 16 : 8, scope_i2c_fmt_data);
      display_text(I2CT_X_VALUE, y + 2, t);

      if(ev->flags & 1)
      {
        q = scope_print_decimal(t, ev->a10, 0, 0);
        i2c_str(q, " bits", t + 23);
        display_set_fg_color(DEC_ERR_COLOR);     //v1.01b9: errors in yellow, not red
        display_text(I2CT_X_ACK, y + 2, t);
      }
      else
      {
        display_set_fg_color(GREEN_COLOR);
        display_text(I2CT_X_ACK, y + 2, "OK");
      }

      continue;
    }

    if(ev->type == I2C_EV_START)
    {
      display_set_fg_color(LIGHTGREY_COLOR);
      display_draw_horz_line(y, 4, 4 + I2CT_W - 1);
      display_set_fg_color(WHITE_COLOR);
      q = scope_print_decimal(t, i2ct_trn[top + r], 0, 0);
      *q = 0;
      display_text(I2CT_X_NUM, y + 2, t);
    }

    display_set_fg_color(LIGHTGREY_COLOR);
    i2c_time_text(t, ev->i0);
    display_text(I2CT_X_TIME, y + 2, t);

    switch(ev->type)
    {
      case I2C_EV_START:
        display_set_fg_color(GREEN_COLOR);
        display_text(I2CT_X_EVENT, y + 2, "START");
        break;

      case I2C_EV_RESTART:
        display_set_fg_color(YELLOW_COLOR);
        display_text(I2CT_X_EVENT, y + 2, "Sr");
        break;

      case I2C_EV_STOP:
        display_set_fg_color(ORANGE_COLOR);     //v1.01c0: STOP orange
        display_text(I2CT_X_EVENT, y + 2, "STOP");
        break;

      default:
        //Value as in the labels: a 10 bit address on its second byte, "10b" on the first
        //v1.01a5: addresses and data each in their own format (HEX / DEC / BIN)
        if(ev->addr == 2)
        {
          q = i2ct_num(t, ev->a10, 10, scope_i2c_fmt_addr);
          *q++ = ' '; *q++ = 'W'; *q = 0;
        }
        else if(ev->addr && ev->a10 && scope_i2c_addr10)
        {
          q = t;
          *q++ = '1'; *q++ = '0'; *q++ = 'b'; *q++ = ' ';
          *q++ = (ev->value & 1) ? 'R' : 'W';
          *q = 0;
        }
        else if(ev->addr)
        {
          q = i2ct_num(t, ev->value >> 1, 7, scope_i2c_fmt_addr);
          *q++ = ' ';
          *q++ = (ev->value & 1) ? 'R' : 'W';
          *q = 0;
        }
        else
          i2ct_num(t, ev->value, 8, scope_i2c_fmt_data);

        display_set_fg_color(ev->addr ? ORANGE_COLOR : 0x0060B0FF);
        display_text(I2CT_X_EVENT, y + 2, ev->addr ? "ADDR" : "DATA");
        display_text(I2CT_X_VALUE, y + 2, t);

        display_set_fg_color(ev->ack ? GREEN_COLOR : dec_i2c_nack_normal(top + r) ? YELLOW_COLOR : DEC_ERR_COLOR);     //v1.01c0: the normal NACK yellow
        display_text(I2CT_X_ACK, y + 2, ev->ack ? "ACK" : "NACK");

        //v1.01a4: the chip / register
        if(i2ct_info[top + r][0])
        {
          display_set_fg_color(WHITE_COLOR);
          display_text(I2CT_X_INFO, y + 2, i2ct_info[top + r]);
        }
        break;
    }
  }

  //v1.01b4: the row found by Next framed in yellow
  if((i2ct_mark >= (int32)top) && (i2ct_mark < (int32)(top + I2CT_ROWS)))
  {
    display_set_fg_color(YELLOW_COLOR);
    display_draw_rect(4, I2CT_Y0 + ((i2ct_mark - (int32)top) * I2CT_ROW_H), I2CT_W - 1, I2CT_ROW_H - 1);
  }

  //v1.01b8: the second tapped row in light blue
  if((i2ct_mark2 >= (int32)top) && (i2ct_mark2 < (int32)(top + I2CT_ROWS)))
  {
    display_set_fg_color(0x0040E0FF);
    display_draw_rect(4, I2CT_Y0 + ((i2ct_mark2 - (int32)top) * I2CT_ROW_H), I2CT_W - 1, I2CT_ROW_H - 1);
  }

  //Scroll bar: the part in view
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(708, I2CT_Y0, 8, I2CT_ROWS * I2CT_ROW_H);

  if(i2c_nev > I2CT_ROWS)
  {
    bh = (I2CT_ROWS * I2CT_ROWS * I2CT_ROW_H) / i2c_nev;
    if(bh < 12) bh = 12;
    by = I2CT_Y0 + (int32)((top * ((I2CT_ROWS * I2CT_ROW_H) - bh)) / (i2c_nev - I2CT_ROWS));
    display_set_fg_color(LIGHTGREY_COLOR);
    display_fill_rect(708, by, 8, bh);
  }

  display_set_fg_color(LIGHTGREY1_COLOR);
  display_text(10, 460, "Drag up / down to scroll");

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(0, 0, 800, 480);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01b4: in the List: Next (jump to the next NACK / error, the row framed in yellow), Save (the List as a text file in
//\decoder\ on the SD card: a header and a comma separated table, opens in a spreadsheet too) and Load (a saved List
//chosen from \decoder\ and shown on the scope). And a list to pick from (dragged with the finger, a tap takes a row),
//used for the baud rates of the decoder window too.
#define DEC_FOLDER      "\\decoder"
#define DEC_MAX_FILES   100
#define DEC_FNAME       36
#define DEC_TXT_SIZE    65536
#define DEC_TXT_LINES   2048

static void i2cw_cbutton(int32 x, int32 y, int32 w, const char *text, uint32 fill, uint32 color);

static FIL    dec_fp;
static char   dec_files[DEC_MAX_FILES][DEC_FNAME];
static uint32 dec_nfiles;
static char   dec_txt[DEC_TXT_SIZE];
static uint32 dec_txt_line[DEC_TXT_LINES];
static uint32 dec_txt_n;

//A NACK or an error on the row (event) e
static uint32 dec_ev_error(uint32 e)
{
  const I2CEVENT *ev = &i2c_ev[e];

  switch(ev->type)
  {
    //case I2C_EV_BYTE:     return(!ev->ack && !dec_i2c_nack_normal(e));     //v1.01b9: not the NACK after the last byte read
    case I2C_EV_BYTE:     return(!ev->ack);     //v1.01c0: every NACK again (filter, Next NACK, count); the normal one in yellow
    case DEC_EV_UART:     return(ev->flags & 3);
    case DEC_EV_SPIWORD:  return(ev->flags & 1);
    case DEC_EV_OWRESET:  return(!(ev->flags & 1));
    case DEC_EV_OWBYTE:   return(ev->flags & 2);
    case DEC_EV_LINBYTE:  return(ev->flags & 0x1E);
  }

  return(0);
}

//The next row with an error after the row from (wraps round), -1 none
static int32 dec_next_error(int32 from)
{
  uint32 k, e;

  for(k = 1; k <= i2c_nev; k++)
  {
    e = (uint32)(from + (int32)k + (int32)i2c_nev) % i2c_nev;

    if(dec_ev_error(e))
      return((int32)e);
  }

  return(-1);
}

#if 0     //v1.01b4: replaced by i2ct_pbutton in v1.01b5
//A button of the List's right column (76 x 48), two lines centred
static void i2ct_rbutton(int32 y, const char *l1, const char *l2, uint32 fill, uint32 text)
{
  display_set_fg_color(fill);
  display_fill_rounded_rect(720, y, 76, 48, 3);
  display_set_fg_color(text);
  display_set_font(&font_3);
  display_text(758 - ((int32)scope_text_width(l1) / 2), y + 5, (int8 *)l1);
  display_text(758 - ((int32)scope_text_width(l2) / 2), y + 25, (int8 *)l2);
}
#endif

//The six columns of a row as text (#, Time, Event, Value, Ack, Info), as the table shows them
static void dec_row_fields(uint32 e, char f[6][48])
{
  static const char *const linrole[4] = { "SYNC", "PID", "DATA", "CHECK" };
  const I2CEVENT *ev = &i2c_ev[e];
  char  *q;
  uint32 k;

  for(k = 0; k < 6; k++)
    f[k][0] = 0;

  if((ev->type == I2C_EV_START) || (ev->type == DEC_EV_SPIFRAME) || (ev->type == DEC_EV_UART) ||
     (ev->type == DEC_EV_OWRESET) || (ev->type == DEC_EV_LINBREAK))
    scope_print_decimal(f[0], i2ct_trn[e], 0, 0);

  i2c_time_text(f[1], ev->i0);

  switch(ev->type)
  {
    case I2C_EV_START:    i2c_str(f[2], "START", f[2] + 47); break;
    case I2C_EV_RESTART:  i2c_str(f[2], "Sr", f[2] + 47);    break;
    case I2C_EV_STOP:     i2c_str(f[2], "STOP", f[2] + 47);  break;

    case I2C_EV_BYTE:
      if(ev->addr == 2)
      {
        q = i2ct_num(f[3], ev->a10, 10, scope_i2c_fmt_addr);
        i2c_str(q, " W", f[3] + 47);
      }
      else if(ev->addr && ev->a10 && scope_i2c_addr10)
        i2c_str(f[3], (ev->value & 1) ? "10b R" : "10b W", f[3] + 47);
      else if(ev->addr)
      {
        q = i2ct_num(f[3], ev->value >> 1, 7, scope_i2c_fmt_addr);
        i2c_str(q, (ev->value & 1) ? " R" : " W", f[3] + 47);
      }
      else
        i2ct_num(f[3], ev->value, 8, scope_i2c_fmt_data);

      i2c_str(f[2], ev->addr ? "ADDR" : "DATA", f[2] + 47);
      i2c_str(f[4], ev->ack ? "ACK" : "NACK", f[4] + 47);
      i2c_str(f[5], i2ct_info[e], f[5] + 47);
      break;

    case DEC_EV_UART:
      i2c_str(f[2], ev->line ? "RX" : "TX", f[2] + 47);
      i2ct_num(f[3], ev->v16, scope_uart_7bit ? 7 : 8, scope_i2c_fmt_data);
      i2c_str(f[4], (ev->flags & 2) ? "Frame" : (ev->flags & 1) ? "Parity" : "OK", f[4] + 47);
      f[5][0] = ((ev->v16 >= 32) && (ev->v16 < 127)) ? (char)ev->v16 : '.';
      f[5][1] = 0;
      break;

    case DEC_EV_SPIFRAME: i2c_str(f[2], "FRAME", f[2] + 47); break;

    case DEC_EV_SPIWORD:
      i2c_str(f[2], "WORD", f[2] + 47);
      i2ct_num(f[3], ev->v16, scope_spi_16 ? 16 : 8, scope_i2c_fmt_data);

      if(ev->flags & 1)
      {
        q = scope_print_decimal(f[4], ev->a10, 0, 0);
        i2c_str(q, " bits", f[4] + 47);
      }
      else
        i2c_str(f[4], "OK", f[4] + 47);
      break;

    case DEC_EV_OWRESET:
      i2c_str(f[2], "RESET", f[2] + 47);
      i2c_str(f[4], (ev->flags & 1) ? "Presence" : "No presence", f[4] + 47);
      break;

    case DEC_EV_OWBYTE:
      i2c_str(f[2], "BYTE", f[2] + 47);
      i2ct_num(f[3], ev->value, 8, scope_i2c_fmt_data);
      i2c_str(f[4], (ev->flags & 2) ? "Bad CRC" : (ev->flags & 4) ? "CRC OK" : "OK", f[4] + 47);
      q = i2c_str(f[5], i2ct_info[e], f[5] + 47);

      if(ev->flags & 2)
      {
        q = i2c_str(q, " should be ", f[5] + 40);
        i2ct_num(q, ev->chk & 0xFF, 8, scope_i2c_fmt_data);
      }
      break;

    case DEC_EV_LINBREAK: i2c_str(f[2], "BREAK", f[2] + 47); break;

    case DEC_EV_LINBYTE:
      i2c_str(f[2], linrole[ev->addr & 3], f[2] + 47);

      if(ev->addr == 1)
      {
        q = i2c_str(f[3], "ID ", f[3] + 47);
        i2ct_num(q, ev->value & 0x3F, 6, scope_i2c_fmt_data);
      }
      else
        i2ct_num(f[3], ev->value, 8, scope_i2c_fmt_data);

      i2c_str(f[4], (ev->flags & 2) ? "Frame" : (ev->flags & 4) ? "Not 55" : (ev->flags & 8) ? "Parity" : (ev->flags & 16) ? "Bad sum" : "OK", f[4] + 47);

      if(ev->addr == 3)
        lin_check_text(f[5], ev);
      break;
  }
}

static void dec_put(const char *s)
{
  UINT   bw;
  uint32 n = 0;

  while(s[n])
    n++;

  if(n)
    f_write(&dec_fp, s, n, &bw);
}

//A header line "name: value"
static void dec_put2(const char *name, const char *value)
{
  dec_put(name);
  dec_put(": ");
  dec_put(value);
  dec_put("\r\n");
}

//A CSV field: in quotes when it holds a comma or a quote (a quote doubled)
static void dec_put_field(const char *s, uint32 last)
{
  char   b[100], *p = b;
  uint32 q = 0, i;

  for(i = 0; s[i]; i++)
    if((s[i] == ',') || (s[i] == '"'))
      q = 1;

  if(q) *p++ = '"';

  for(i = 0; s[i] && (p < (b + 94)); i++)
  {
    if(s[i] == '"')
      *p++ = '"';

    *p++ = s[i];
  }

  if(q) *p++ = '"';

  if(last) { *p++ = '\r'; *p++ = '\n'; }
  else     *p++ = ',';

  *p = 0;
  dec_put(b);
}

//v1.01b8: the date and time of the clock chip as YYYYMMDD_HHMMSS (read once per save), returns the end
static uint8 dec_rtc[7];

static char *dec_rtc_stamp(char *p)
{
  static const uint8 order[6] = { 6, 5, 4, 2, 1, 0 };     //year, month, date, hours, minutes, seconds
  uint32 k;

  *p++ = '2';
  *p++ = '0';

  for(k = 0; k < 6; k++)
  {
    uint8 v = dec_rtc[order[k]] & ((order[k] == 2) ? 0x3F : (order[k] == 5) ? 0x1F : (order[k] == 4) ? 0x3F : 0x7F);

    if(k == 3)
      *p++ = '_';

    *p++ = '0' + ((v >> 4) & 15);
    *p++ = '0' + (v & 15);
  }

  *p = 0;
  return(p);
}

//v1.01b8: the short name of the chip for the file name: the chosen one, or with Auto the only chip the addresses of
//the record belong to; 0 none
static const char *dec_file_chip(void)
{
  uint32 e;
  int32  c, one = -1;

  if(scope_i2c_chip >= 2)
    return(i2c_choice_short());

  if(scope_i2c_chip != 0)
    return(0);

  for(e = 0; e < i2c_nev; e++)
  {
    if((i2c_ev[e].type != I2C_EV_BYTE) || (i2c_ev[e].addr != 1))
      continue;

    c = i2cd_for(i2c_ev[e].value >> 1);

    if(c < 0)
      continue;

    if((one >= 0) && (c != one))
      return(0);

    one = c;
  }

  return((one >= 0) ? i2cd[one].shortn : 0);
}

//The List into \decoder\<protocol>[_<chip>]_<YYYYMMDD_HHMMSS or nnn>.txt; the status text says how it went
static void dec_list_save(void)
{
  static const char *const chname[DEC_PROTOS][2] =
  {
    { "SDA = CH1  SCL = CH2", "SDA = CH2  SCL = CH1" }, { "TX = CH1  RX = CH2", "TX = CH2  RX = CH1" },
    { "SCLK = CH1  data = CH2", "SCLK = CH2  data = CH1" }, { "line on CH1", "line on CH2" }, { "line on CH1", "line on CH2" }
  };
  static const char *const parname[3] = { "N", "E", "O" };
  static const char *const linver[3] = { "Auto", "LIN 1.x (classic)", "LIN 2.x (enhanced)" };
  char   path[64], t[96], *p, f[6][48];
  uint32 pr = scope_dec_proto % DEC_PROTOS, num, i, e, sr = scopesettings.samplerate;
  FRESULT res = FR_OK;

  f_mkdir(DEC_FOLDER);

  //v1.01b8: the time for the name
  if(onoffRTC)
    tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, dec_rtc, 7);

  for(num = 1; num < 1000; num++)
  {
    p = i2c_str(path, DEC_FOLDER "\\", path + 63);
    p = i2c_str(p, dec_names[pr], path + 63);

    //if((pr == DEC_I2C) && (scope_i2c_chip >= 2))
    //v1.01b8: the chosen chip, or with Auto the one chip found for the addresses of the record
    if((pr == DEC_I2C) && dec_file_chip())
    {
      const char *c = dec_file_chip();

      *p++ = '_';

      //Only letters and digits in the name of the file
      for(i = 0; c[i] && (i < 7); i++)
        *p++ = (((c[i] >= '0') && (c[i] <= '9')) || ((c[i] >= 'A') && (c[i] <= 'Z')) || ((c[i] >= 'a') && (c[i] <= 'z'))) ? c[i] : '-';
    }

    *p++ = '_';

    //v1.01b8: with the clock on (Settings > Clock, time stamp in files) the date and time instead of the number
    if(onoffRTC && (num == 1))
      p = dec_rtc_stamp(p);
    else
    {
      if(onoffRTC)
      {
        //The same second twice: _002 ...
        p = dec_rtc_stamp(p);
        *p++ = '_';
      }

      *p++ = '0' + ((num / 100) % 10);
      *p++ = '0' + ((num / 10) % 10);
      *p++ = '0' + (num % 10);
    }

    i2c_str(p, ".txt", path + 63);

    res = f_open(&dec_fp, path, FA_CREATE_NEW | FA_WRITE);

    if(res != FR_EXIST)
      break;
  }

  if(res != FR_OK)
  {
    i2c_str(i2ct_status, "Save failed", i2ct_status + 47);
    return;
  }

  if(sr >= (sizeof(sample_rate) / sizeof(sample_rate[0])))
    sr = 0;

  //The header
  dec_put2("Decoder list", VERSION_STRING);
  dec_put2("Protocol", dec_names[pr]);
  dec_put2("Channels", chname[pr][scope_dec_swap ? 1 : 0]);

  if(pr == DEC_I2C)
  {
    dec_put2("Addresses", scope_i2c_addr10 ? "10 bit" : "7 bit");
    dec_put2("Chip", (scope_i2c_chip >= 2) ? i2cd_chosen : i2c_choice_short());
  }
  else if(pr == DEC_UART)
  {
    p = scope_print_decimal(t, uart_bauds[scope_uart_baud % UART_BAUDS], 0, 0);
    p = i2c_str(p, " baud ", t + 95);
    *p++ = scope_uart_7bit ? '7' : '8';
    p = i2c_str(p, parname[scope_uart_parity % 3], t + 95);
    *p++ = scope_uart_stop2 ? '2' : '1';
    i2c_str(p, scope_uart_inv ? " inverted" : " normal", t + 95);
    dec_put2("UART", t);
  }
  else if(pr == DEC_SPI)
  {
    p = i2c_str(t, "mode ", t + 95);
    *p++ = '0' + (scope_spi_mode & 3);
    p = i2c_str(p, scope_spi_lsb ? " LSB first " : " MSB first ", t + 95);
    i2c_str(p, scope_spi_16 ? "16 bit" : "8 bit", t + 95);
    dec_put2("SPI", t);
  }
  else if(pr == DEC_1WIRE)
    dec_put2("Speed", scope_ow_overdrive ? "Overdrive" : "Standard");
  else
  {
    p = scope_print_decimal(t, lin_bauds[scope_lin_baud % LIN_BAUDS], 0, 0);
    i2c_str(p, " baud", t + 95);
    dec_put2("LIN", t);
    dec_put2("Version", linver[scope_lin_ver % 3]);
  }

  if(scope_i2c_thr_auto)
    dec_put2("Threshold", "Auto 50 %");
  else
  {
    p = i2c_str(t, "CH1 ", t + 95);
    p = scope_print_decimal(p, scope_i2c_thr_mv[0], 0, 0);
    p = i2c_str(p, " mV  CH2 ", t + 95);
    p = scope_print_decimal(p, scope_i2c_thr_mv[1], 0, 0);
    i2c_str(p, " mV", t + 95);
    dec_put2("Threshold", t);
  }

  p = scope_print_decimal(t, sample_rate[sr], 0, 0);
  i2c_str(p, " Sa/s", t + 95);
  dec_put2("Sample rate", t);

  if(scopesettings.waveviewmode)
    dec_put2("Wave", viewfilename);

  scope_print_decimal(t, i2c_nev, 0, 0);
  dec_put2("Rows", t);
  dec_put("\r\n");

  //The table
  dec_put("#,Time,Event,Value,Ack,Info\r\n");

  for(e = 0; e < i2c_nev; e++)
  {
    dec_row_fields(e, f);

    for(i = 0; i < 6; i++)
      dec_put_field(f[i], i == 5);
  }

  f_close(&dec_fp);

  p = i2c_str(i2ct_status, "Saved ", i2ct_status + 47);
  i2c_str(p, path + sizeof(DEC_FOLDER), i2ct_status + 47);
}

//----------------------------------------------------------------------------------------------------------------------------------
//The list to pick from: a window at x, y, w wide, rows of 36, a title with Close; the row cur in green. Drag moves the
//rows, a tap on a row takes it; Close or a tap outside: -1. The screen under it is not kept (the caller draws again).
typedef const char *(*DECPICKNAME)(uint32 i, char *buf);

#define DECP_ROW_H   36
#define DECP_TITLE_H 40

static void dec_pick_draw(int32 x, int32 y, int32 w, uint32 rows, const char *title, uint32 n, DECPICKNAME name, int32 cur, int32 top)
{
  char   buf[48];
  uint32 r;
  int32  ry, h = DECP_TITLE_H + (int32)(rows * DECP_ROW_H) + 4;

  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(x, y, w, h);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rect(x, y, w, h);

  display_set_font(&font_3);
  display_set_fg_color(ORANGE_COLOR);
  display_text(x + 10, y + 12, (int8 *)title);
  i2cw_cbutton(x + w - 78, y + 3, 72, "Close", 0x00A03030, WHITE_COLOR);

  for(r = 0; (r < rows) && ((top + (int32)r) < (int32)n); r++)
  {
    ry = y + DECP_TITLE_H + (int32)(r * DECP_ROW_H);
    display_set_fg_color(((top + (int32)r) == cur) ? 0x0040C040 : (((top + r) & 1) ? 0x00303030 : 0x00262626));
    display_fill_rect(x + 2, ry, w - 14, DECP_ROW_H - 2);
    display_set_fg_color(((top + (int32)r) == cur) ? BLACK_COLOR : WHITE_COLOR);
    display_set_font(&font_3);
    display_text(x + 12, ry + 9, (int8 *)name((uint32)(top + (int32)r), buf));
  }

  //Scroll bar
  if(n > rows)
  {
    int32 bh = (int32)((rows * rows * DECP_ROW_H) / n), by;

    if(bh < 12) bh = 12;
    by = y + DECP_TITLE_H + (int32)(((uint32)top * ((rows * DECP_ROW_H) - (uint32)bh)) / (n - rows));
    display_set_fg_color(LIGHTGREY_COLOR);
    display_fill_rect(x + w - 10, by, 6, bh);
  }

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(x, y, w + 1, h + 1);
}

static int32 dec_pick(int32 x, int32 y, int32 w, uint32 rows, const char *title, uint32 n, DECPICKNAME name, int32 cur)
{
  int32 h = DECP_TITLE_H + (int32)(rows * DECP_ROW_H) + 4, maxtop = (n > rows) ? (int32)(n - rows) : 0;
  int32 top = 0, top0, y0, nt, moved, r;

  //The current row in view
  if(cur >= 0)
  {
    top = cur - (int32)(rows / 2);
    if(top > maxtop) top = maxtop;
    if(top < 0)      top = 0;
  }

  tp_i2c_wait_for_touch_release();
  dec_pick_draw(x, y, w, rows, title, n, name, cur, top);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    //Outside or Close
    if(((int32)xtouch < x) || ((int32)xtouch > (x + w)) || ((int32)ytouch < y) || ((int32)ytouch > (y + h)) ||
       (((int32)ytouch < (y + DECP_TITLE_H)) && ((int32)xtouch >= (x + w - 80))))
    {
      tp_i2c_wait_for_touch_release();
      return(-1);
    }

    y0    = ytouch;
    top0  = top;
    moved = 0;

    while(havetouch)
    {
      if((((int32)ytouch - y0) > 8) || ((y0 - (int32)ytouch) > 8))
        moved = 1;

      nt = top0 + ((y0 - (int32)ytouch) / DECP_ROW_H);

      if(nt < 0)      nt = 0;
      if(nt > maxtop) nt = maxtop;

      if(nt != top)
      {
        top = nt;
        dec_pick_draw(x, y, w, rows, title, n, name, cur, top);
      }

      tp_i2c_read_status();
    }

    if(!moved && (y0 >= (y + DECP_TITLE_H)))
    {
      r = top + ((y0 - (y + DECP_TITLE_H)) / DECP_ROW_H);

      if((r >= 0) && (r < (int32)n))
        return(r);
    }
  }
}

//The names for the pick list: the saved files, the baud rates
static const char *dec_file_name(uint32 i, char *buf)
{
  (void)buf;
  return(dec_files[i]);
}

static const char *dec_uart_baud_name(uint32 i, char *buf)
{
  scope_print_decimal(buf, uart_bauds[i % UART_BAUDS], 0, 0);
  return(buf);
}

static const char *dec_lin_baud_name(uint32 i, char *buf)
{
  scope_print_decimal(buf, lin_bauds[i % LIN_BAUDS], 0, 0);
  return(buf);
}

//The *.txt files of \decoder\, sorted by name
static void dec_read_files(void)
{
  DIR     dir;
  FILINFO fno;
  uint32  len, i, k;

  dec_nfiles = 0;

  if(f_opendir(&dir, DEC_FOLDER) != FR_OK)
    return;

  while((dec_nfiles < DEC_MAX_FILES) && (f_readdir(&dir, &fno) == FR_OK) && fno.fname[0])
  {
    if(fno.fattrib & AM_DIR)
      continue;

    for(len = 0; fno.fname[len]; len++);

    if((len < 5) || (len >= DEC_FNAME) || !i2cd_streq(&fno.fname[len - 4], ".txt"))
      continue;

    //Insert in name order
    for(k = dec_nfiles; k > 0; k--)
    {
      for(i = 0; dec_files[k - 1][i] && (dec_files[k - 1][i] == fno.fname[i]); i++);

      if((uint8)dec_files[k - 1][i] <= (uint8)fno.fname[i])
        break;

      for(i = 0; i < DEC_FNAME; i++)
        dec_files[k][i] = dec_files[k - 1][i];
    }

    for(i = 0; i <= len; i++)
      dec_files[k][i] = fno.fname[i];

    dec_nfiles++;
  }

  f_closedir(&dir);
}

//One line of a saved file on the screen: a table row in the columns of the List (fields split at commas outside
//quotes), any other line as it is
static void dec_view_line(int32 y, const char *s, uint32 len)
{
  static const int16 colx[6] = { I2CT_X_NUM, I2CT_X_TIME, I2CT_X_EVENT, I2CT_X_VALUE, I2CT_X_ACK, I2CT_X_INFO };
  static const uint32 colc[6] = { WHITE_COLOR, LIGHTGREY_COLOR, 0x0060B0FF, 0x0060B0FF, GREEN_COLOR, WHITE_COLOR };
  char   b[100];
  uint32 i, k = 0, c = 0, q = 0, comma = 0, bad;

  for(i = 0; i < len; i++)
    if(s[i] == ',')
      comma = 1;

  if(!comma)
  {
    for(i = 0; (i < len) && (i < 98); i++)
      b[i] = s[i];

    b[i] = 0;
    display_set_fg_color(YELLOW_COLOR);
    display_text(8, y, (int8 *)b);
    return;
  }

  for(i = 0; i <= len; i++)
  {
    if((i == len) || ((s[i] == ',') && !q))
    {
      b[k] = 0;

      if(c < 6)
      {
        //The errors in red as in the List
        bad = (c == 4) && b[0] && !((b[0] == 'O') && (b[1] == 'K')) && !((b[0] == 'A') && (b[1] == 'C')) &&
              !((b[0] == 'P') && (b[1] == 'r')) && !((b[0] == 'C') && (b[1] == 'R'));
        display_set_fg_color((y < (I2CT_Y0 - 10)) ? ORANGE_COLOR : bad ? RED_COLOR : colc[c]);
        display_text(colx[c], y, (int8 *)b);
      }

      c++;
      k = 0;
      continue;
    }

    if(s[i] == '"')
    {
      //A doubled quote in quotes is one quote
      if(q && ((i + 1) < len) && (s[i + 1] == '"'))
      {
        if(k < 98) b[k++] = '"';
        i++;
      }
      else
        q ^= 1;

      continue;
    }

    if(k < 98)
      b[k++] = s[i];
  }
}

#define DECV_ROWS    21
#define DECV_ROW_H   20
#define DECV_Y0      48

static uint8 dec_view_del = 0;     //v1.01b6: Delete tapped once, waiting for the second tap

static void dec_view_draw(const char *fname, uint32 top)
{
  uint32 r, l, a, b;
  int32  bh, by;

  display_set_screen_buffer(displaybuffertmp);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);

  display_set_font(&font_3);
  display_set_fg_color(ORANGE_COLOR);
  i2ct_frame();     //v1.01b5
  display_set_fg_color(ORANGE_COLOR);
  display_text(10, 8, (int8 *)fname);
  i2ct_close_button();

  //v1.01b6: Delete with a second tap as the confirmation
  i2ct_pbutton(428, "Delete", dec_view_del ? "Sure?" : "file", RED_COLOR, dec_view_del);

  if(dec_view_del)
  {
    display_set_font(&font_3);
    display_set_fg_color(RED_COLOR);
    display_text(330, 8, "Tap Delete again to delete the file");
  }

  display_set_font(&font_0);

  for(r = 0; (r < DECV_ROWS) && ((top + r) < dec_txt_n); r++)
  {
    l = top + r;
    a = dec_txt_line[l];

    //The line without its end
    for(b = a; dec_txt[b] && (dec_txt[b] != '\r') && (dec_txt[b] != '\n'); b++);

    display_set_fg_color((r & 1) ? 0x00202830 : 0x00101418);
    display_fill_rect(4, DECV_Y0 + (int32)(r * DECV_ROW_H), 700, DECV_ROW_H);
    dec_view_line(DECV_Y0 + (int32)(r * DECV_ROW_H) + 2, &dec_txt[a], b - a);
  }

  //Scroll bar
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(708, DECV_Y0, 8, DECV_ROWS * DECV_ROW_H);

  if(dec_txt_n > DECV_ROWS)
  {
    bh = (DECV_ROWS * DECV_ROWS * DECV_ROW_H) / (int32)dec_txt_n;
    if(bh < 12) bh = 12;
    by = DECV_Y0 + (int32)((top * (uint32)((DECV_ROWS * DECV_ROW_H) - bh)) / (dec_txt_n - DECV_ROWS));
    display_set_fg_color(LIGHTGREY_COLOR);
    display_fill_rect(708, by, 8, bh);
  }

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(0, 0, 800, 480);
}

//Load: pick a file of \decoder\ and show it (dragged with the finger) until Close
static void dec_list_load(void)
{
  char   path[64], *p;
  UINT   br = 0;
  int32  f, top = 0, maxtop, top0, y0, nt;
  uint32 i;

  dec_read_files();

  if(!dec_nfiles)
  {
    i2c_str(i2ct_status, "No files in \\decoder", i2ct_status + 47);
    return;
  }

  f = dec_pick(200, 40, 400, 11, "Load a saved List", dec_nfiles, dec_file_name, -1);

  if(f < 0)
    return;

  p = i2c_str(path, DEC_FOLDER "\\", path + 63);
  i2c_str(p, dec_files[f], path + 63);

  if(f_open(&dec_fp, path, FA_READ) != FR_OK)
  {
    i2c_str(i2ct_status, "Load failed", i2ct_status + 47);
    return;
  }

  if(f_read(&dec_fp, dec_txt, DEC_TXT_SIZE - 1, &br) != FR_OK)
    br = 0;

  f_close(&dec_fp);
  dec_txt[br] = 0;

  //The starts of the lines
  dec_txt_n = 0;

  for(i = 0; (i < br) && (dec_txt_n < DEC_TXT_LINES); )
  {
    dec_txt_line[dec_txt_n++] = i;

    while((i < br) && (dec_txt[i] != '\n'))
      i++;

    i++;
  }

  maxtop = (dec_txt_n > DECV_ROWS) ? (int32)(dec_txt_n - DECV_ROWS) : 0;
  dec_view_del = 0;
  dec_view_draw(dec_files[f], 0);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    if((xtouch >= 718) && (ytouch <= 44))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }

    //v1.01b6: Delete: the first tap asks, the second deletes; any other touch cancels
    if((xtouch >= 718) && (ytouch >= 424))
    {
      tp_i2c_wait_for_touch_release();

      if(!dec_view_del)
      {
        dec_view_del = 1;
        dec_view_draw(dec_files[f], (uint32)top);
        continue;
      }

      dec_view_del = 0;
      p = i2c_str(i2ct_status, (f_unlink(path) == FR_OK) ? "Deleted " : "Delete failed ", i2ct_status + 47);
      i2c_str(p, dec_files[f], i2ct_status + 47);
      break;
    }

    if(dec_view_del)
    {
      dec_view_del = 0;
      tp_i2c_wait_for_touch_release();
      dec_view_draw(dec_files[f], (uint32)top);
      continue;
    }

    y0   = ytouch;
    top0 = top;

    while(havetouch)
    {
      nt = top0 + ((y0 - (int32)ytouch) / DECV_ROW_H);

      if(nt < 0)      nt = 0;
      if(nt > maxtop) nt = maxtop;

      if(nt != top)
      {
        top = nt;
        dec_view_draw(dec_files[f], (uint32)top);
      }

      tp_i2c_read_status();
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01b6: the List's rows: decoded, numbered and annotated (chips loaded from the SD card when load), then the filter
//(All, NACK / errors only, UART TX / RX only, one I2C address: its whole transactions) keeps only its rows
#define DEC_FILT_MAX    20
static uint8  dec_filt_code[DEC_FILT_MAX];
static uint8  dec_filt_addr[DEC_FILT_MAX];
static char   dec_filt_name[DEC_FILT_MAX][24];
static uint32 dec_filt_n;
uint8         dec_list_jumped = 0;     //the List moved the trace (the decoder window closes then)

static void i2ct_prepare(uint32 load)
{
  uint32 e, n;

  dec_decode();

  for(e = 0, n = 0; e < i2c_nev; e++)
  {
    if((i2c_ev[e].type == I2C_EV_START) || (i2c_ev[e].type == DEC_EV_SPIFRAME) || (i2c_ev[e].type == DEC_EV_UART) ||
       (i2c_ev[e].type == DEC_EV_OWRESET) || (i2c_ev[e].type == DEC_EV_LINBREAK))
      n++;

    i2ct_trn[e] = (uint16)n;
  }

  if(load)
    scope_i2c_load_chips();

  i2ct_annotate();
  ow_annotate();

  //v1.01b9: the normal NACKs marked while all rows are there (the filter may take the STOP away)
  if(scope_dec_proto == DEC_I2C)
  {
    for(e = 0; e < i2c_nev; e++)
      if(i2c_ev[e].type == I2C_EV_BYTE)
        i2c_ev[e].flags = (uint8)(0x40 | (dec_i2c_nack_normal(e) ? 0x80 : 0));
  }

  //v1.01b8: the statistics of the whole record (before the filter)
  for(e = 0, dec_stat_err = 0, dec_stat_real = 0; e < i2c_nev; e++)
    if(dec_ev_error(e))
    {
      dec_stat_err++;

      if(!dec_i2c_nack_normal(e))
        dec_stat_real++;
    }

  dec_stat_baud = ((scope_dec_proto == DEC_UART) || (scope_dec_proto == DEC_LIN)) ? dec_measure_baud() : 0;
}

//The 7 bit address of the I2C transaction the event e is in, 0x100 none
static uint32 i2ct_trn_addr(uint32 e)
{
  uint32 k = e;

  //Back to its START / Sr
  while((k > 0) && (i2c_ev[k].type != I2C_EV_START) && (i2c_ev[k].type != I2C_EV_RESTART))
    k--;

  for(; k < i2c_nev; k++)
  {
    if((i2c_ev[k].type == I2C_EV_BYTE) && (i2c_ev[k].addr == 1))
      return((uint32)(i2c_ev[k].value >> 1));

    if((k > e) && (i2c_ev[k].type != I2C_EV_BYTE))
      break;
  }

  return(0x100);
}

static uint32 i2ct_keep(uint32 e)
{
  switch(i2ct_filter)
  {
    case DEC_FILT_ERR:  return(dec_ev_error(e));
    case DEC_FILT_TX:   return((i2c_ev[e].type == DEC_EV_UART) && !i2c_ev[e].line);
    case DEC_FILT_RX:   return((i2c_ev[e].type == DEC_EV_UART) && i2c_ev[e].line);
    case DEC_FILT_ADDR: return((i2c_ev[e].type <= I2C_EV_BYTE) && (i2ct_trn_addr(e) == i2ct_filter_addr));
  }

  return(1);
}

static void i2ct_filter_apply(void)
{
  static uint8 keep[I2C_MAX_EV];
  uint32 e, k, i;

  if(i2ct_filter == DEC_FILT_ALL)
    return;

  //Decided on the whole record first (the transaction address looks at other rows)
  for(e = 0; e < i2c_nev; e++)
    keep[e] = (uint8)(i2ct_keep(e) ? 1 : 0);

  for(e = 0, k = 0; e < i2c_nev; e++)
  {
    if(!keep[e])
      continue;

    if(k != e)
    {
      i2c_ev[k]   = i2c_ev[e];
      i2ct_trn[k] = i2ct_trn[e];

      for(i = 0; i < I2C_INFO_LEN; i++)
        i2ct_info[k][i] = i2ct_info[e][i];
    }

    k++;
  }

  i2c_nev = k;
}

//The short name of the filter for its button
static const char *i2ct_filter_name(char *t)
{
  switch(i2ct_filter)
  {
    case DEC_FILT_ERR:  return((scope_dec_proto == DEC_I2C) ? "NACK" : "Errors");
    case DEC_FILT_TX:   return("TX");
    case DEC_FILT_RX:   return("RX");
    case DEC_FILT_ADDR: i2ct_num(t, i2ct_filter_addr, 7, scope_i2c_fmt_addr); return(t);
  }

  return("All");
}

static const char *dec_filt_list_name(uint32 i, char *buf)
{
  (void)buf;
  return(dec_filt_name[i]);
}

static void dec_filt_add(uint32 code, uint32 addr, const char *name)
{
  char *p;

  if(dec_filt_n >= DEC_FILT_MAX)
    return;

  dec_filt_code[dec_filt_n] = (uint8)code;
  dec_filt_addr[dec_filt_n] = (uint8)addr;
  p = i2c_str(dec_filt_name[dec_filt_n], name, dec_filt_name[dec_filt_n] + 23);

  if(code == DEC_FILT_ADDR)
    i2ct_num(p, addr, 7, scope_i2c_fmt_addr);

  dec_filt_n++;
}

//The filter chosen from a list (the addresses of the whole record); the rows made again. 1 when it changed
static uint32 i2ct_filter_pick(void)
{
  uint32 e, k, a, cur = 0, seen;
  int32  r;

  i2ct_prepare(0);

  dec_filt_n = 0;
  dec_filt_add(DEC_FILT_ALL, 0, "All rows");
  dec_filt_add(DEC_FILT_ERR, 0, (scope_dec_proto == DEC_I2C) ? "NACK only" : "Errors only");

  if(scope_dec_proto == DEC_UART)
  {
    dec_filt_add(DEC_FILT_TX, 0, "TX only");
    dec_filt_add(DEC_FILT_RX, 0, "RX only");
  }

  if(scope_dec_proto == DEC_I2C)
  {
    for(e = 0; e < i2c_nev; e++)
    {
      if((i2c_ev[e].type != I2C_EV_BYTE) || (i2c_ev[e].addr != 1))
        continue;

      a = i2c_ev[e].value >> 1;

      for(k = 0, seen = 0; k < dec_filt_n; k++)
        if((dec_filt_code[k] == DEC_FILT_ADDR) && (dec_filt_addr[k] == a))
          seen = 1;

      if(!seen)
        dec_filt_add(DEC_FILT_ADDR, a, "Address ");
    }
  }

  for(k = 0; k < dec_filt_n; k++)
    if((dec_filt_code[k] == i2ct_filter) && ((i2ct_filter != DEC_FILT_ADDR) || (dec_filt_addr[k] == i2ct_filter_addr)))
      cur = k;

  r = dec_pick(200, 40, 400, 9, "Show in the List", dec_filt_n, dec_filt_list_name, (int32)cur);

  if(r >= 0)
  {
    i2ct_filter      = dec_filt_code[r];
    i2ct_filter_addr = dec_filt_addr[r];
  }

  i2ct_filter_apply();
  return(r >= 0);
}

//A row tapped: the trace moved so its time is in the middle of the screen (not in the long time base / roll)
static uint32 i2ct_jump(uint32 e)
{
  int32 first, shown, max_first;

  if(scopesettings.long_mode || scope_roll_ui() || (disp_xpos_per_sample <= 0.0) || (e >= i2c_nev))
    return(0);

  shown = (int32)(725.0 / disp_xpos_per_sample);
  first = i2c_ev[e].i0 - (shown / 2);
  max_first = (int32)fpgasettings.totalsamples - shown;

  if(max_first < 0)     max_first = 0;
  if(first > max_first) first = max_first;
  if(first < 0)         first = 0;

  scopesettings.triggerhorizontalposition = (int32)(((int32)disp_trigger_index - first) * disp_xpos_per_sample);
  previous_trigger_point_position = scopesettings.triggerhorizontalposition;
  return(1);
}

void scope_i2c_list(void)
{
  int32  top = 0, maxtop, top0, y0, nt, moved;
  uint32 jumped = 0;

  tp_i2c_wait_for_touch_release();

  //The screen is kept to come back to
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_destination_buffer(displaybuffer2);
  display_copy_rect_from_screen(0, 0, 800, 480);

  //v1.01b6: decoded, numbered and annotated in i2ct_prepare (as v1.01b1 .. b2 did here), then the filter
  //i2ct_filter = DEC_FILT_ALL;
  //v1.01b9: the filter stays until it is changed (only when it does not belong to the protocol it is reset)
  if(((i2ct_filter == DEC_FILT_TX) || (i2ct_filter == DEC_FILT_RX)) && (scope_dec_proto != DEC_UART))
    i2ct_filter = DEC_FILT_ALL;

  if((i2ct_filter == DEC_FILT_ADDR) && (scope_dec_proto != DEC_I2C))
    i2ct_filter = DEC_FILT_ALL;

  dec_list_jumped = 0;
  i2ct_prepare(1);
  i2ct_filter_apply();

  maxtop = ((int32)i2c_nev > I2CT_ROWS) ? ((int32)i2c_nev - I2CT_ROWS) : 0;

  i2ct_mark      = -1;     //v1.01b4
  i2ct_mark2     = -1;     //v1.01b8
  i2ct_status[0] = 0;

  i2ct_draw(top);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    //Close
    if((xtouch >= 718) && (ytouch <= 44))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }

    //v1.01a5: format of the addresses / of the data: HEX -> DEC -> BIN (v1.01a6: the buttons under Close)
    if((xtouch >= 718) && (ytouch >= 52) && (ytouch <= 150))     //v1.01b5: 54 / 104, 44 high
    {
      if(ytouch < 101)
      {
        if(scope_dec_proto == DEC_I2C)     //v1.01b1
          scope_i2c_fmt_addr = (scope_i2c_fmt_addr + 1) % 3;
      }
      else
        scope_i2c_fmt_data = (scope_i2c_fmt_data + 1) % 3;

      i2ct_draw(top);
      tp_i2c_wait_for_touch_release();
      continue;
    }

    //v1.01a7: the chip choice (v1.01b1: I2C only)
    if((xtouch >= 718) && (ytouch >= 152) && (ytouch <= 202) && (scope_dec_proto == DEC_I2C))
    {
      i2c_chip_pick();
      i2ct_annotate();
      i2ct_draw(top);
      continue;
    }

    //v1.01b4: Next NACK / error: the row framed and brought into view (wraps round)
    if((xtouch >= 718) && (ytouch >= 206) && (ytouch < 257))
    {
      i2ct_pbutton(210, "Next", (scope_dec_proto == DEC_I2C) ? "NACK" : "error", YELLOW_COLOR, 1);
      tp_i2c_wait_for_touch_release();

      nt = dec_next_error((i2ct_mark >= 0) ? i2ct_mark : (top - 1));
      i2ct_status[0] = 0;

      if(nt < 0)
        i2c_str(i2ct_status, (scope_dec_proto == DEC_I2C) ? "No NACK" : "No error", i2ct_status + 47);
      else
      {
        i2ct_mark = nt;
        i2ct_mark2 = -1;     //v1.01b8

        if((nt < top) || (nt >= (top + I2CT_ROWS)))
        {
          top = nt - 2;
          if(top > maxtop) top = maxtop;
          if(top < 0)      top = 0;
        }
      }

      i2ct_draw(top);
      continue;
    }

    //v1.01b6: the filter (a list to choose from), the rows made again
    if((xtouch >= 718) && (ytouch >= 257) && (ytouch <= 308))
    {
      char ft[24];

      i2ct_pbutton(260, "Filter", i2ct_filter_name(ft), 0x00C0C0C0, 1);
      tp_i2c_wait_for_touch_release();
      i2ct_filter_pick();
      i2ct_mark = -1;
      i2ct_mark2 = -1;     //v1.01b8
      top       = 0;
      maxtop    = ((int32)i2c_nev > I2CT_ROWS) ? ((int32)i2c_nev - I2CT_ROWS) : 0;
      i2ct_draw(top);
      continue;
    }

    //v1.01b4: Save / Load
    if((xtouch >= 718) && (ytouch >= 374))
    {
      if(ytouch < 425)
      {
        i2ct_pbutton(378, "Save", "List", 0x0060A0FF, 1);
        tp_i2c_wait_for_touch_release();
        dec_list_save();
      }
      else
      {
        i2ct_pbutton(428, "Load", "List", 0x0060D060, 1);
        tp_i2c_wait_for_touch_release();
        i2ct_status[0] = 0;
        dec_list_load();
      }

      i2ct_draw(top);
      continue;
    }

    //v1.01a6: nothing else in the right column
    if(xtouch >= 718)
    {
      tp_i2c_wait_for_touch_release();
      continue;
    }

    //Drag: the rows follow the finger
    y0   = ytouch;
    top0 = top;
    moved = 0;     //v1.01b6

    while(havetouch)
    {
      if((((int32)ytouch - y0) > 8) || ((y0 - (int32)ytouch) > 8))
        moved = 1;

      nt = top0 + ((y0 - (int32)ytouch) / I2CT_ROW_H);

      if(nt < 0)      nt = 0;
      if(nt > maxtop) nt = maxtop;

      if(nt != top)
      {
        top = nt;
        i2ct_draw(top);
      }

      tp_i2c_read_status();
    }

    //v1.01b6: a tap on a row: the List closes and the trace shows that time in the middle
    //v1.01b8: the first tap marks the row (yellow), a tap on another row marks it too (light blue) and shows the time
    //between them; a tap on a marked row shows it on the trace (as the tap in v1.01b6)
    if(!moved && (y0 >= I2CT_Y0) && (y0 < (I2CT_Y0 + (I2CT_ROWS * I2CT_ROW_H))))
    {
      nt = top + ((y0 - I2CT_Y0) / I2CT_ROW_H);

      if(nt < (int32)i2c_nev)
      {
        if((nt == i2ct_mark) || (nt == i2ct_mark2))
        {
          if(i2ct_jump((uint32)nt))
          {
            jumped = 1;
            break;
          }
        }
        else if(i2ct_mark < 0)
        {
          i2ct_mark  = nt;
          i2ct_mark2 = -1;
          i2c_str(i2ct_status, "Tap a 2nd row: time", i2ct_status + 47);
        }
        else
        {
          char  tt[24], *pp;
          int32 d = i2c_ev[nt].i0 - i2c_ev[i2ct_mark].i0;

          i2ct_mark2 = nt;
          i2c_time_text(tt, (d < 0) ? -d : d);
          pp = i2c_str(i2ct_status, (d < 0) ? "dt = -" : "dt = ", i2ct_status + 47);
          i2c_str(pp, tt, i2ct_status + 47);
        }

        i2ct_draw(top);
      }
    }
  }

  display_set_source_buffer(displaybuffer2);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(0, 0, 800, 480);

  //v1.01b6: the trace drawn again at the new place
  if(jumped)
  {
    dec_list_jumped = 1;
    scope_display_trace_data();
  }
}


//----------------------------------------------------------------------------------------------------------------------------------
//v1.01a3: the decoder's window, opened by a tap on the text "Decode I2C" in the channel menu: threshold Auto (50 % of
//each channel's swing) or Manual (SDA / SCL in V, - / + by 50 mV), address 7 / 10 bit, values HEX / DEC, List, Close.
//A touch outside the window closes it too. The screen under it is kept in displaybuffer3.
#define I2CW_X      180
#define I2CW_Y      70
#define I2CW_W      400
#define I2CW_H      350

static void i2cw_button(int32 x, int32 y, int32 w, const char *text, uint32 on, uint32 dim)
{
  display_set_fg_color(on ? ORANGE_COLOR : MIDLEGREY_COLOR);
  display_fill_rounded_rect(x, y, w, 34, 3);
  display_set_fg_color(dim ? LIGHTGREY1_COLOR : on ? BLACK_COLOR : WHITE_COLOR);
  display_set_font(&font_3);
  //display_text(x + 8, y + 9, (int8 *)text);
  //v1.01b2: centred in the button
  display_text(x + ((w - (int32)scope_text_width(text)) / 2), y + 9, (int8 *)text);
}

//v1.01b2: a button with its own fill and text colour
static void i2cw_cbutton(int32 x, int32 y, int32 w, const char *text, uint32 fill, uint32 color)
{
  display_set_fg_color(fill);
  display_fill_rounded_rect(x, y, w, 34, 3);
  display_set_fg_color(color);
  display_set_font(&font_3);
  display_text(x + ((w - (int32)scope_text_width(text)) / 2), y + 9, (int8 *)text);
}

static void i2cw_volts(char *buf, int32 mv)
{
  char *p = buf;

  if(mv < 0)
  {
    *p++ = '-';
    mv = -mv;
  }

  p = scope_print_decimal(p, mv / 1000, 0, 0);
  *p++ = '.';
  *p++ = '0' + ((mv / 100) % 10);
  *p++ = '0' + ((mv / 10) % 10);
  *p++ = ' ';
  *p++ = 'V';
  *p = 0;
}

#if 0     //v1.01b1: the I2C only window, replaced by the one for all protocols below
static void i2cw_draw(void)
{
  char   t[16];
  uint32 c, dim = scope_i2c_thr_auto;
  int32  y;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);
  display_set_fg_color(ORANGE_COLOR);
  display_draw_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);

  display_set_font(&font_3);
  display_text(I2CW_X + 12, I2CW_Y + 10, "I2C decoder   SDA = CH1, SCL = CH2");

  display_set_fg_color(WHITE_COLOR);
  display_text(I2CW_X + 12, I2CW_Y + 54, "Threshold");
  i2cw_button(I2CW_X + 150, I2CW_Y + 46, 100, "Auto 50%", scope_i2c_thr_auto, 0);
  i2cw_button(I2CW_X + 270, I2CW_Y + 46, 100, "Manual", !scope_i2c_thr_auto, 0);

  for(c = 0; c < 2; c++)
  {
    y = I2CW_Y + 96 + (c * 46);
    display_set_font(&font_3);
    display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
    display_text(I2CW_X + 12, y + 8, c ? "SCL (CH2)" : "SDA (CH1)");
    i2cw_button(I2CW_X + 150, y, 44, " -", 0, dim);
    i2cw_volts(t, scope_i2c_thr_mv[c]);
    display_set_font(&font_3);
    display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
    display_text(I2CW_X + 206, y + 9, t);
    i2cw_button(I2CW_X + 326, y, 44, " +", 0, dim);
  }

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(I2CW_X + 12, I2CW_Y + 196, "Address");
  i2cw_button(I2CW_X + 150, I2CW_Y + 188, 100, "7 bit", !scope_i2c_addr10, 0);
  i2cw_button(I2CW_X + 270, I2CW_Y + 188, 100, "10 bit", scope_i2c_addr10, 0);

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(I2CW_X + 12, I2CW_Y + 242, "Values");
  i2cw_button(I2CW_X + 150, I2CW_Y + 234, 100, "HEX", !scope_i2c_dec, 0);
  i2cw_button(I2CW_X + 270, I2CW_Y + 234, 100, "DEC", scope_i2c_dec, 0);

  i2cw_button(I2CW_X + 150, I2CW_Y + 296, 100, "List", 0, 0);
  i2cw_button(I2CW_X + 270, I2CW_Y + 296, 100, "Close", 0, 0);
}

static uint32 i2cw_in(int32 x, int32 y, int32 bx, int32 by, int32 bw)
{
  return((x >= (I2CW_X + bx)) && (x < (I2CW_X + bx + bw)) && (y >= (I2CW_Y + by)) && (y < (I2CW_Y + by + 34)));
}

void scope_i2c_settings_window(void)
{
  int32  x, y, c, list;

  tp_i2c_wait_for_touch_release();

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);

  i2cw_draw();

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x = xtouch;
    y = ytouch;
    list = 0;

    //Outside: close
    if((x < I2CW_X) || (x > (I2CW_X + I2CW_W)) || (y < I2CW_Y) || (y > (I2CW_Y + I2CW_H)))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }

    if(i2cw_in(x, y, 150, 46, 100))       scope_i2c_thr_auto = 1;
    else if(i2cw_in(x, y, 270, 46, 100))  scope_i2c_thr_auto = 0;
    else if(i2cw_in(x, y, 150, 188, 100)) scope_i2c_addr10 = 0;
    else if(i2cw_in(x, y, 270, 188, 100)) scope_i2c_addr10 = 1;
    else if(i2cw_in(x, y, 150, 234, 100)) scope_i2c_dec = 0;
    else if(i2cw_in(x, y, 270, 234, 100)) scope_i2c_dec = 1;
    else if(i2cw_in(x, y, 150, 296, 100)) list = 1;
    else if(i2cw_in(x, y, 270, 296, 100))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }
    else if(!scope_i2c_thr_auto)
    {
      for(c = 0; c < 2; c++)
      {
        if(i2cw_in(x, y, 150, 96 + (c * 46), 44) && (scope_i2c_thr_mv[c] > -20000))
          scope_i2c_thr_mv[c] -= 50;
        else if(i2cw_in(x, y, 326, 96 + (c * 46), 44) && (scope_i2c_thr_mv[c] < 30000))
          scope_i2c_thr_mv[c] += 50;
      }
    }

    if(list)
    {
      scope_i2c_list();
      i2cw_draw();
      continue;
    }

    i2cw_draw();
    tp_i2c_wait_for_touch_release();
  }

  display_set_source_buffer(displaybuffer3);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);
}

#endif

#if 0     //v1.01b2: the three protocol window, replaced by the five protocol one below
//v1.01b1: the window for all three protocols: Protocol I2C / UART / SPI on top, the thresholds (CH1 / CH2 named by
//the protocol), then two rows of the protocol: I2C address 7 / 10 bit and values HEX / DEC; UART baud rate (- / +) and
//data bits, parity, stop bits, idle level; SPI mode 0..3, MSB / LSB first, 8 / 16 bit words. List and Close.
#undef  I2CW_Y
#undef  I2CW_H
#define I2CW_Y      40
#define I2CW_H      400

static void i2cw_draw(void)
{
  static const char *const chname[3][2] = { { "SDA (CH1)", "SCL (CH2)" }, { "TX (CH1)", "RX (CH2)" }, { "SCLK (CH1)", "Data (CH2)" } };
  static const char *const parname[3] = { "None", "Even", "Odd" };
  char   t[16];
  uint32 c, dim = scope_i2c_thr_auto, pr = scope_dec_proto % 3;
  int32  y;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);
  display_set_fg_color(ORANGE_COLOR);
  display_draw_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);

  display_set_font(&font_3);
  display_text(I2CW_X + 12, I2CW_Y + 10, "Decoder");

  display_set_fg_color(WHITE_COLOR);
  display_text(I2CW_X + 12, I2CW_Y + 52, "Protocol");
  i2cw_button(I2CW_X + 150, I2CW_Y + 44, 74, "I2C",  pr == DEC_I2C, 0);
  i2cw_button(I2CW_X + 232, I2CW_Y + 44, 74, "UART", pr == DEC_UART, 0);
  i2cw_button(I2CW_X + 314, I2CW_Y + 44, 74, "SPI",  pr == DEC_SPI, 0);

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(I2CW_X + 12, I2CW_Y + 96, "Threshold");
  i2cw_button(I2CW_X + 150, I2CW_Y + 88, 100, "Auto 50%", scope_i2c_thr_auto, 0);
  i2cw_button(I2CW_X + 270, I2CW_Y + 88, 100, "Manual", !scope_i2c_thr_auto, 0);

  for(c = 0; c < 2; c++)
  {
    y = I2CW_Y + 132 + (c * 44);
    display_set_font(&font_3);
    display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
    display_text(I2CW_X + 12, y + 8, (int8 *)chname[pr][c]);
    i2cw_button(I2CW_X + 150, y, 44, " -", 0, dim);
    i2cw_volts(t, scope_i2c_thr_mv[c]);
    display_set_font(&font_3);
    display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
    display_text(I2CW_X + 206, y + 9, t);
    i2cw_button(I2CW_X + 326, y, 44, " +", 0, dim);
  }

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);

  if(pr == DEC_UART)
  {
    display_text(I2CW_X + 12, I2CW_Y + 230, "Baud rate");
    i2cw_button(I2CW_X + 150, I2CW_Y + 222, 44, " -", 0, 0);
    scope_print_decimal(t, uart_bauds[scope_uart_baud % UART_BAUDS], 0, 0);
    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 206, I2CW_Y + 231, t);
    i2cw_button(I2CW_X + 326, I2CW_Y + 222, 44, " +", 0, 0);

    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 12, I2CW_Y + 276, "Format");
    i2cw_button(I2CW_X + 150, I2CW_Y + 268, 58, scope_uart_7bit ? "7 bit" : "8 bit", 1, 0);
    i2cw_button(I2CW_X + 212, I2CW_Y + 268, 58, parname[scope_uart_parity % 3], scope_uart_parity != 0, 0);
    i2cw_button(I2CW_X + 274, I2CW_Y + 268, 58, scope_uart_stop2 ? "2 stp" : "1 stp", 1, 0);
    i2cw_button(I2CW_X + 336, I2CW_Y + 268, 58, scope_uart_inv ? "Inv" : "Norm", scope_uart_inv, 0);
  }
  else if(pr == DEC_SPI)
  {
    display_text(I2CW_X + 12, I2CW_Y + 230, "Mode");

    for(c = 0; c < 4; c++)
    {
      t[0] = '0' + c;
      t[1] = 0;
      i2cw_button(I2CW_X + 150 + (c * 62), I2CW_Y + 222, 58, t, scope_spi_mode == c, 0);
    }

    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 12, I2CW_Y + 276, "Bits");
    i2cw_button(I2CW_X + 150, I2CW_Y + 268, 58, "MSB", !scope_spi_lsb, 0);
    i2cw_button(I2CW_X + 212, I2CW_Y + 268, 58, "LSB", scope_spi_lsb, 0);
    i2cw_button(I2CW_X + 274, I2CW_Y + 268, 58, "8 bit", !scope_spi_16, 0);
    i2cw_button(I2CW_X + 336, I2CW_Y + 268, 58, "16bit", scope_spi_16, 0);
  }
  else
  {
    display_text(I2CW_X + 12, I2CW_Y + 230, "Address");
    i2cw_button(I2CW_X + 150, I2CW_Y + 222, 100, "7 bit", !scope_i2c_addr10, 0);
    i2cw_button(I2CW_X + 270, I2CW_Y + 222, 100, "10 bit", scope_i2c_addr10, 0);

    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 12, I2CW_Y + 276, "Values");
    i2cw_button(I2CW_X + 150, I2CW_Y + 268, 100, "HEX", !scope_i2c_dec, 0);
    i2cw_button(I2CW_X + 270, I2CW_Y + 268, 100, "DEC", scope_i2c_dec, 0);
  }

  i2cw_button(I2CW_X + 150, I2CW_Y + 340, 100, "List", 0, 0);
  i2cw_button(I2CW_X + 270, I2CW_Y + 340, 100, "Close", 0, 0);
}

static uint32 i2cw_in(int32 x, int32 y, int32 bx, int32 by, int32 bw)
{
  return((x >= (I2CW_X + bx)) && (x < (I2CW_X + bx + bw)) && (y >= (I2CW_Y + by)) && (y < (I2CW_Y + by + 34)));
}

void scope_i2c_settings_window(void)
{
  int32  x, y, c, list;

  tp_i2c_wait_for_touch_release();

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);

  i2cw_draw();

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x = xtouch;
    y = ytouch;
    list = 0;

    //Outside: close
    if((x < I2CW_X) || (x > (I2CW_X + I2CW_W)) || (y < I2CW_Y) || (y > (I2CW_Y + I2CW_H)))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }

    if(i2cw_in(x, y, 150, 44, 74))        scope_dec_proto = DEC_I2C;
    else if(i2cw_in(x, y, 232, 44, 74))   scope_dec_proto = DEC_UART;
    else if(i2cw_in(x, y, 314, 44, 74))   scope_dec_proto = DEC_SPI;
    else if(i2cw_in(x, y, 150, 88, 100))  scope_i2c_thr_auto = 1;
    else if(i2cw_in(x, y, 270, 88, 100))  scope_i2c_thr_auto = 0;
    else if(i2cw_in(x, y, 150, 340, 100)) list = 1;
    else if(i2cw_in(x, y, 270, 340, 100))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }
    else if((y >= (I2CW_Y + 132)) && (y < (I2CW_Y + 210)))
    {
      if(!scope_i2c_thr_auto)
      {
        for(c = 0; c < 2; c++)
        {
          if(i2cw_in(x, y, 150, 132 + (c * 44), 44) && (scope_i2c_thr_mv[c] > -20000))
            scope_i2c_thr_mv[c] -= 50;
          else if(i2cw_in(x, y, 326, 132 + (c * 44), 44) && (scope_i2c_thr_mv[c] < 30000))
            scope_i2c_thr_mv[c] += 50;
        }
      }
    }
    else if(scope_dec_proto == DEC_UART)
    {
      if(i2cw_in(x, y, 150, 222, 44) && (scope_uart_baud > 0))                     scope_uart_baud--;
      else if(i2cw_in(x, y, 326, 222, 44) && (scope_uart_baud < (UART_BAUDS - 1)))  scope_uart_baud++;
      else if(i2cw_in(x, y, 150, 268, 58)) scope_uart_7bit ^= 1;
      else if(i2cw_in(x, y, 212, 268, 58)) scope_uart_parity = (scope_uart_parity + 1) % 3;
      else if(i2cw_in(x, y, 274, 268, 58)) scope_uart_stop2 ^= 1;
      else if(i2cw_in(x, y, 336, 268, 58)) scope_uart_inv ^= 1;
    }
    else if(scope_dec_proto == DEC_SPI)
    {
      for(c = 0; c < 4; c++)
        if(i2cw_in(x, y, 150 + (c * 62), 222, 58))
          scope_spi_mode = (uint8)c;

      if(i2cw_in(x, y, 150, 268, 58))      scope_spi_lsb = 0;
      else if(i2cw_in(x, y, 212, 268, 58)) scope_spi_lsb = 1;
      else if(i2cw_in(x, y, 274, 268, 58)) scope_spi_16 = 0;
      else if(i2cw_in(x, y, 336, 268, 58)) scope_spi_16 = 1;
    }
    else
    {
      if(i2cw_in(x, y, 150, 222, 100))      scope_i2c_addr10 = 0;
      else if(i2cw_in(x, y, 270, 222, 100)) scope_i2c_addr10 = 1;
      else if(i2cw_in(x, y, 150, 268, 100)) scope_i2c_dec = 0;
      else if(i2cw_in(x, y, 270, 268, 100)) scope_i2c_dec = 1;
    }

    if(list)
    {
      scope_i2c_list();
      i2cw_draw();
      continue;
    }

    i2cw_draw();
    tp_i2c_wait_for_touch_release();
  }

  display_set_source_buffer(displaybuffer3);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);
}

#endif

//v1.01b2: the window for all five protocols, 480 wide: On / Off at the top, Protocol I2C / UART / SPI / 1-Wire / LIN
//(the chosen one in its own colour) with Swap (the roles of CH1 / CH2: SDA / SCL, TX / RX, SCLK / data, the line on
//CH2), the thresholds, two rows of the protocol, List (blue) and Close (red). Texts centred in the buttons.
#undef  I2CW_X
#undef  I2CW_Y
#undef  I2CW_W
#undef  I2CW_H
#define I2CW_X      160
#define I2CW_Y      30
#define I2CW_W      480
#define I2CW_H      420

static const uint32 dec_colors[DEC_PROTOS] = { ORANGE_COLOR, 0x0060B0FF, 0x0040C040, 0x00C080FF, 0x0000C0C0 };

#if 0     //v1.01b3: the v1.01b2 layout (protocols in a row, - / +), replaced by the one below
static void i2cw_draw(void)
{
  static const char *const chname[DEC_PROTOS][2] =
  {
    { "SDA", "SCL" }, { "TX", "RX" }, { "SCLK", "Data" }, { "Line", "-" }, { "Line", "-" }
  };
  static const char *const parname[3] = { "None", "Even", "Odd" };
  char   t[24], *q;
  uint32 c, dim = scope_i2c_thr_auto, pr = scope_dec_proto % DEC_PROTOS, role;
  int32  y;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);
  display_set_fg_color(dec_colors[pr]);
  display_draw_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);

  display_set_font(&font_3);
  display_text(I2CW_X + 12, I2CW_Y + 14, "Decoder");
  i2cw_cbutton(I2CW_X + I2CW_W - 100, I2CW_Y + 6, 90, scope_i2c_enabled ? "ON" : "OFF", scope_i2c_enabled ? GREEN_COLOR : MIDLEGREY_COLOR,
               scope_i2c_enabled ? BLACK_COLOR : WHITE_COLOR);

  //Protocols, each in its own colour when chosen
  for(c = 0; c < DEC_PROTOS; c++)
    i2cw_cbutton(I2CW_X + 12 + (c * 76), I2CW_Y + 50, 72, dec_names[c], (c == pr) ? dec_colors[c] : MIDLEGREY_COLOR, (c == pr) ? BLACK_COLOR : WHITE_COLOR);

  i2cw_cbutton(I2CW_X + 396, I2CW_Y + 50, 72, "Swap", scope_dec_swap ? YELLOW_COLOR : MIDLEGREY_COLOR, scope_dec_swap ? BLACK_COLOR : WHITE_COLOR);

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(I2CW_X + 12, I2CW_Y + 104, "Threshold");
  i2cw_button(I2CW_X + 160, I2CW_Y + 96, 120, "Auto 50%", scope_i2c_thr_auto, 0);
  i2cw_button(I2CW_X + 300, I2CW_Y + 96, 120, "Manual", !scope_i2c_thr_auto, 0);

  for(c = 0; c < 2; c++)
  {
    //The channel and its role (Swap)
    role = c ^ scope_dec_swap;
    y = I2CW_Y + 140 + (c * 44);
    q = i2c_str(t, c ? "CH2 " : "CH1 ", t + 23);
    i2c_str(q, chname[pr][role], t + 23);
    display_set_font(&font_3);
    display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
    display_text(I2CW_X + 12, y + 8, (int8 *)t);
    i2cw_button(I2CW_X + 160, y, 44, "-", 0, dim);
    i2cw_volts(t, scope_i2c_thr_mv[c]);
    display_set_font(&font_3);
    display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
    display_text(I2CW_X + 290 - ((int32)scope_text_width(t) / 2), y + 9, t);
    i2cw_button(I2CW_X + 376, y, 44, "+", 0, dim);
  }

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);

  if((pr == DEC_UART) || (pr == DEC_LIN))
  {
    display_text(I2CW_X + 12, I2CW_Y + 240, "Baud rate");
    i2cw_button(I2CW_X + 160, I2CW_Y + 232, 44, "-", 0, 0);
    scope_print_decimal(t, (pr == DEC_LIN) ? lin_bauds[scope_lin_baud % LIN_BAUDS] : uart_bauds[scope_uart_baud % UART_BAUDS], 0, 0);
    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 290 - ((int32)scope_text_width(t) / 2), I2CW_Y + 241, t);
    i2cw_button(I2CW_X + 376, I2CW_Y + 232, 44, "+", 0, 0);
  }

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);

  if(pr == DEC_UART)
  {
    display_text(I2CW_X + 12, I2CW_Y + 286, "Format");
    i2cw_button(I2CW_X + 160, I2CW_Y + 278, 62, scope_uart_7bit ? "7 bit" : "8 bit", 1, 0);
    i2cw_button(I2CW_X + 226, I2CW_Y + 278, 62, parname[scope_uart_parity % 3], scope_uart_parity != 0, 0);
    i2cw_button(I2CW_X + 292, I2CW_Y + 278, 62, scope_uart_stop2 ? "2 stop" : "1 stop", 1, 0);
    i2cw_button(I2CW_X + 358, I2CW_Y + 278, 62, scope_uart_inv ? "Inv" : "Norm", scope_uart_inv, 0);
  }
  else if(pr == DEC_LIN)
  {
    display_text(I2CW_X + 12, I2CW_Y + 286, "Values");
    i2cw_button(I2CW_X + 160, I2CW_Y + 278, 120, "HEX", !scope_i2c_dec, 0);
    i2cw_button(I2CW_X + 300, I2CW_Y + 278, 120, "DEC", scope_i2c_dec, 0);
  }
  else if(pr == DEC_SPI)
  {
    display_text(I2CW_X + 12, I2CW_Y + 240, "Mode");

    for(c = 0; c < 4; c++)
    {
      t[0] = '0' + c;
      t[1] = 0;
      i2cw_button(I2CW_X + 160 + (c * 66), I2CW_Y + 232, 62, t, scope_spi_mode == c, 0);
    }

    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 12, I2CW_Y + 286, "Bits");
    i2cw_button(I2CW_X + 160, I2CW_Y + 278, 62, "MSB", !scope_spi_lsb, 0);
    i2cw_button(I2CW_X + 226, I2CW_Y + 278, 62, "LSB", scope_spi_lsb, 0);
    i2cw_button(I2CW_X + 292, I2CW_Y + 278, 62, "8 bit", !scope_spi_16, 0);
    i2cw_button(I2CW_X + 358, I2CW_Y + 278, 62, "16 bit", scope_spi_16, 0);
  }
  else if(pr == DEC_1WIRE)
  {
    display_text(I2CW_X + 12, I2CW_Y + 240, "Speed");
    i2cw_button(I2CW_X + 160, I2CW_Y + 232, 120, "Standard", !scope_ow_overdrive, 0);
    i2cw_button(I2CW_X + 300, I2CW_Y + 232, 120, "Overdrive", scope_ow_overdrive, 0);

    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 12, I2CW_Y + 286, "Values");
    i2cw_button(I2CW_X + 160, I2CW_Y + 278, 120, "HEX", !scope_i2c_dec, 0);
    i2cw_button(I2CW_X + 300, I2CW_Y + 278, 120, "DEC", scope_i2c_dec, 0);
  }
  else
  {
    display_text(I2CW_X + 12, I2CW_Y + 240, "Address");
    i2cw_button(I2CW_X + 160, I2CW_Y + 232, 120, "7 bit", !scope_i2c_addr10, 0);
    i2cw_button(I2CW_X + 300, I2CW_Y + 232, 120, "10 bit", scope_i2c_addr10, 0);

    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(I2CW_X + 12, I2CW_Y + 286, "Values");
    i2cw_button(I2CW_X + 160, I2CW_Y + 278, 120, "HEX", !scope_i2c_dec, 0);
    i2cw_button(I2CW_X + 300, I2CW_Y + 278, 120, "DEC", scope_i2c_dec, 0);
  }

  //List and Close set apart: List blue, Close red
  display_set_fg_color(0x00505050);
  display_draw_horz_line(I2CW_Y + 330, I2CW_X + 8, I2CW_X + I2CW_W - 8);
  i2cw_cbutton(I2CW_X + 160, I2CW_Y + 350, 120, "List", 0x002070D0, WHITE_COLOR);
  i2cw_cbutton(I2CW_X + 300, I2CW_Y + 350, 120, "Close", 0x00A03030, WHITE_COLOR);
}

static uint32 i2cw_in(int32 x, int32 y, int32 bx, int32 by, int32 bw)
{
  return((x >= (I2CW_X + bx)) && (x < (I2CW_X + bx + bw)) && (y >= (I2CW_Y + by)) && (y < (I2CW_Y + by + 34)));
}

void scope_i2c_settings_window(void)
{
  int32  x, y, c, list;

  tp_i2c_wait_for_touch_release();

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);

  i2cw_draw();

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x = xtouch;
    y = ytouch;
    list = 0;

    //Outside: close
    if((x < I2CW_X) || (x > (I2CW_X + I2CW_W)) || (y < I2CW_Y) || (y > (I2CW_Y + I2CW_H)))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }

    if(i2cw_in(x, y, I2CW_W - 100, 6, 90))
      scope_i2c_enabled ^= 1;
    else if((y >= (I2CW_Y + 50)) && (y < (I2CW_Y + 84)) && (x >= (I2CW_X + 12)) && (x < (I2CW_X + 12 + (DEC_PROTOS * 76))))
      scope_dec_proto = (uint8)((x - (I2CW_X + 12)) / 76);
    else if(i2cw_in(x, y, 396, 50, 72))   scope_dec_swap ^= 1;
    else if(i2cw_in(x, y, 160, 96, 120))  scope_i2c_thr_auto = 1;
    else if(i2cw_in(x, y, 300, 96, 120))  scope_i2c_thr_auto = 0;
    else if(i2cw_in(x, y, 160, 350, 120)) list = 1;
    else if(i2cw_in(x, y, 300, 350, 120))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }
    else if((y >= (I2CW_Y + 140)) && (y < (I2CW_Y + 218)))
    {
      if(!scope_i2c_thr_auto)
      {
        for(c = 0; c < 2; c++)
        {
          if(i2cw_in(x, y, 160, 140 + (c * 44), 44) && (scope_i2c_thr_mv[c] > -20000))
            scope_i2c_thr_mv[c] -= 50;
          else if(i2cw_in(x, y, 376, 140 + (c * 44), 44) && (scope_i2c_thr_mv[c] < 30000))
            scope_i2c_thr_mv[c] += 50;
        }
      }
    }
    else if(scope_dec_proto == DEC_UART)
    {
      if(i2cw_in(x, y, 160, 232, 44) && (scope_uart_baud > 0))                     scope_uart_baud--;
      else if(i2cw_in(x, y, 376, 232, 44) && (scope_uart_baud < (UART_BAUDS - 1)))  scope_uart_baud++;
      else if(i2cw_in(x, y, 160, 278, 62)) scope_uart_7bit ^= 1;
      else if(i2cw_in(x, y, 226, 278, 62)) scope_uart_parity = (scope_uart_parity + 1) % 3;
      else if(i2cw_in(x, y, 292, 278, 62)) scope_uart_stop2 ^= 1;
      else if(i2cw_in(x, y, 358, 278, 62)) scope_uart_inv ^= 1;
    }
    else if(scope_dec_proto == DEC_LIN)
    {
      if(i2cw_in(x, y, 160, 232, 44) && (scope_lin_baud > 0))                    scope_lin_baud--;
      else if(i2cw_in(x, y, 376, 232, 44) && (scope_lin_baud < (LIN_BAUDS - 1)))  scope_lin_baud++;
      else if(i2cw_in(x, y, 160, 278, 120)) scope_i2c_dec = 0;
      else if(i2cw_in(x, y, 300, 278, 120)) scope_i2c_dec = 1;
    }
    else if(scope_dec_proto == DEC_SPI)
    {
      for(c = 0; c < 4; c++)
        if(i2cw_in(x, y, 160 + (c * 66), 232, 62))
          scope_spi_mode = (uint8)c;

      if(i2cw_in(x, y, 160, 278, 62))      scope_spi_lsb = 0;
      else if(i2cw_in(x, y, 226, 278, 62)) scope_spi_lsb = 1;
      else if(i2cw_in(x, y, 292, 278, 62)) scope_spi_16 = 0;
      else if(i2cw_in(x, y, 358, 278, 62)) scope_spi_16 = 1;
    }
    else if(scope_dec_proto == DEC_1WIRE)
    {
      if(i2cw_in(x, y, 160, 232, 120))      scope_ow_overdrive = 0;
      else if(i2cw_in(x, y, 300, 232, 120)) scope_ow_overdrive = 1;
      else if(i2cw_in(x, y, 160, 278, 120)) scope_i2c_dec = 0;
      else if(i2cw_in(x, y, 300, 278, 120)) scope_i2c_dec = 1;
    }
    else
    {
      if(i2cw_in(x, y, 160, 232, 120))      scope_i2c_addr10 = 0;
      else if(i2cw_in(x, y, 300, 232, 120)) scope_i2c_addr10 = 1;
      else if(i2cw_in(x, y, 160, 278, 120)) scope_i2c_dec = 0;
      else if(i2cw_in(x, y, 300, 278, 120)) scope_i2c_dec = 1;
    }

    if(list)
    {
      scope_i2c_list();
      i2cw_draw();
      continue;
    }

    i2cw_draw();
    tp_i2c_wait_for_touch_release();
  }

  display_set_source_buffer(displaybuffer3);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);
}
#endif

//v1.01b3: the window laid out again: the protocols in a column on the right under ON / OFF, Swap left of ON / OFF,
//the labels nearer to their buttons, < and > (the arrows of the old clock panel) instead of - and +, HEX / DEC for UART
//and SPI too (third row), List and Close lower
#define DECW_LX       12      //labels
#define DECW_BX       100     //buttons from here ...
#define DECW_BE       360     //... to here
#define DECW_PX       380     //the protocol column (and ON / OFF)
#define DECW_PW       90
#define DECW_SWX      270     //Swap
//#define DECW_THR_Y    50
//#define DECW_CH_Y     96      //CH1, CH2 at +44
//#define DECW_A_Y      188
//#define DECW_B_Y      234
//#define DECW_C_Y      280
//v1.01b4: the top row set apart by a line (y 46), the rows 6 lower
#define DECW_TOP_LINE 46
#define DECW_THR_Y    56
#define DECW_CH_Y     100     //CH1, CH2 at +44
#define DECW_A_Y      192
#define DECW_B_Y      238
#define DECW_C_Y      284
#define DECW_LINE_Y   330
#define DECW_LIST_Y   368
#define DECW_LIST_X   110
#define DECW_CLOSE_X  250
#define DECW_HALF     125     //two buttons in a row: DECW_BX and DECW_BE - DECW_HALF
#define DECW_Q        62      //four buttons in a row, 66 apart

//static const int16 decw_proto_y[DEC_PROTOS] = { DECW_THR_Y, DECW_CH_Y, DECW_CH_Y + 44, DECW_A_Y, DECW_B_Y };
//v1.01b4: the protocols evenly in their own frame
#define DECW_PROTO_STEP 44
static const int16 decw_proto_y[DEC_PROTOS] = { DECW_THR_Y, DECW_THR_Y + 44, DECW_THR_Y + 88, DECW_THR_Y + 132, DECW_THR_Y + 176 };

//v1.01b4: colours: HEX and DEC each its own when chosen, the baud rate frame
#define DECW_HEX_COLOR    0x0040A0FF
#define DECW_DEC_COLOR    0x00C080FF
#define DECW_BAUD_FILL    0x00103848
#define DECW_BAUD_EDGE    0x0000C0C0

//v1.01b4: the LIN version names
static const char *const decw_linver[3] = { "Auto", "1.x", "2.x" };

//A button with the left or right arrow icon
static void i2cw_arrow(int32 x, int32 y, uint32 right, uint32 dim)
{
  display_set_fg_color(MIDLEGREY_COLOR);
  display_fill_rounded_rect(x, y, 44, 34, 3);
  display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
  display_set_bg_color(MIDLEGREY_COLOR);
  display_copy_icon_use_colors(right ? Right_icon : Left_icon, x + 10, y + 5, 24, 24);
}

//A row label
static void i2cw_label(int32 y, const char *text, uint32 dim)
{
  display_set_font(&font_3);
  display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
  display_text(I2CW_X + DECW_LX, I2CW_Y + y + 9, (int8 *)text);
}

//A value between the arrows, centred
static void i2cw_value(int32 y, const char *text, uint32 dim)
{
  display_set_font(&font_3);
  display_set_fg_color(dim ? LIGHTGREY1_COLOR : WHITE_COLOR);
  display_text(I2CW_X + ((DECW_BX + DECW_BE) / 2) - ((int32)scope_text_width(text) / 2), I2CW_Y + y + 9, (int8 *)text);
}

//The HEX / DEC row
static void i2cw_hexdec(int32 y)
{
  i2cw_label(y, "Values", 0);
  //i2cw_button(I2CW_X + DECW_BX, I2CW_Y + y, DECW_HALF, "HEX", !scope_i2c_dec, 0);
  //i2cw_button(I2CW_X + DECW_BE - DECW_HALF, I2CW_Y + y, DECW_HALF, "DEC", scope_i2c_dec, 0);
  //v1.01b4: each in its own colour when chosen
  //i2cw_cbutton(I2CW_X + DECW_BX, I2CW_Y + y, DECW_HALF, "HEX", !scope_i2c_dec ? DECW_HEX_COLOR : MIDLEGREY_COLOR, !scope_i2c_dec ? BLACK_COLOR : WHITE_COLOR);
  //i2cw_cbutton(I2CW_X + DECW_BE - DECW_HALF, I2CW_Y + y, DECW_HALF, "DEC", scope_i2c_dec ? DECW_DEC_COLOR : MIDLEGREY_COLOR, scope_i2c_dec ? BLACK_COLOR : WHITE_COLOR);
  //v1.01b6: HEX / DEC / BIN, the format of the data in the labels and the List (the List's Addr / Data set too)
  {
    static const char *const nm[3] = { "HEX", "DEC", "BIN" };
    static const uint32 col[3] = { DECW_HEX_COLOR, DECW_DEC_COLOR, 0x0060D060 };
    uint32 c, f = scope_i2c_fmt_data % 3;

    for(c = 0; c < 3; c++)
      i2cw_cbutton(I2CW_X + DECW_BX + (c * 88), I2CW_Y + y, 84, nm[c], (c == f) ? col[c] : MIDLEGREY_COLOR, (c == f) ? BLACK_COLOR : WHITE_COLOR);
  }
}

//v1.01b4: the baud rate in a rounded frame between the arrows (a tap on it opens the list of the rates)
//v1.01b5: the corners as the buttons', as wide as the longest rate of the protocol needs (2000000 / 20000) and centred
#define DECW_BAUD_UART_W  76
#define DECW_BAUD_LIN_W   60
#define DECW_BAUD_W(lin)  ((lin) ? DECW_BAUD_LIN_W : DECW_BAUD_UART_W)
//#define DECW_BAUD_X(lin)  (((DECW_BX + DECW_BE) / 2) - (DECW_BAUD_W(lin) / 2))
//v1.01b8: < frame > from the left, Auto on the right
#define DECW_BAUD_X(lin)  (DECW_BX + 50)
#define DECW_BAUD_RX(lin) (DECW_BAUD_X(lin) + DECW_BAUD_W(lin) + 6)
#define DECW_AUTO_W       76
#define DECW_AUTO_X       (DECW_BE - DECW_AUTO_W)

static void i2cw_baud(int32 y, uint32 baud)
{
  char   t[16];
  uint32 lin = (scope_dec_proto == DEC_LIN);

  display_set_fg_color(DECW_BAUD_FILL);
  display_fill_rounded_rect(I2CW_X + DECW_BAUD_X(lin), I2CW_Y + y, DECW_BAUD_W(lin), 34, 3);
  display_set_fg_color(DECW_BAUD_EDGE);
  display_draw_rounded_rect(I2CW_X + DECW_BAUD_X(lin), I2CW_Y + y, DECW_BAUD_W(lin), 34, 3);
  scope_print_decimal(t, baud, 0, 0);
  display_set_font(&font_3);
  display_set_fg_color(YELLOW_COLOR);
  display_text(I2CW_X + DECW_BAUD_X(lin) + (DECW_BAUD_W(lin) / 2) - ((int32)scope_text_width(t) / 2), I2CW_Y + y + 9, (int8 *)t);     //v1.01b8
}

//v1.01b8: the I2C trigger row: Off, NACK, the address (a tap opens the list of the addresses)
static const char *dec_addr_name(uint32 i, char *buf)
{
  i2ct_num(buf, i, 7, scope_i2c_fmt_addr);
  return(buf);
}

static void i2cw_trigger_row(int32 y)
{
  char t[24];

  i2cw_label(y, "Trigger", 0);
  i2cw_button(I2CW_X + DECW_BX, I2CW_Y + y, 84, "Off", scope_dec_trig == 0, 0);
  i2cw_button(I2CW_X + DECW_BX + 88, I2CW_Y + y, 84, "NACK", scope_dec_trig == 1, 0);
  dec_addr_name(scope_dec_trig_addr, t);
  i2cw_button(I2CW_X + DECW_BX + 176, I2CW_Y + y, 84, t, scope_dec_trig == 2, 0);
}

static void i2cw_draw(void)
{
  static const char *const chname[DEC_PROTOS][2] =
  {
    { "SDA", "SCL" }, { "TX", "RX" }, { "SCLK", "Data" }, { "Line", "-" }, { "Line", "-" }
  };
  static const char *const parname[3] = { "None", "Even", "Odd" };
  char   t[24], *q;
  uint32 c, dim = scope_i2c_thr_auto, pr = scope_dec_proto % DEC_PROTOS, role;
  int32  y;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);
  display_set_fg_color(dec_colors[pr]);
  display_draw_rect(I2CW_X, I2CW_Y, I2CW_W, I2CW_H);

  display_set_font(&font_3);
  display_text(I2CW_X + DECW_LX, I2CW_Y + 14, "Decoder");
  i2cw_cbutton(I2CW_X + DECW_SWX, I2CW_Y + 6, DECW_PW, "Swap", scope_dec_swap ? YELLOW_COLOR : MIDLEGREY_COLOR, scope_dec_swap ? BLACK_COLOR : WHITE_COLOR);
  //v1.01b4: OFF in white on red
  i2cw_cbutton(I2CW_X + DECW_PX, I2CW_Y + 6, DECW_PW, scope_i2c_enabled ? "ON" : "OFF", scope_i2c_enabled ? GREEN_COLOR : 0x00C02020,
               scope_i2c_enabled ? BLACK_COLOR : WHITE_COLOR);

  //v1.01b4: the top row set apart as the bottom one
  display_set_fg_color(0x00505050);
  display_draw_horz_line(I2CW_Y + DECW_TOP_LINE, I2CW_X + 8, I2CW_X + I2CW_W - 8);

  //v1.01b4: the protocols in one frame
  display_set_fg_color(0x00707070);
  display_draw_rounded_rect(I2CW_X + DECW_PX - 5, I2CW_Y + DECW_THR_Y - 5, DECW_PW + 10, (DEC_PROTOS * DECW_PROTO_STEP) + 2, 3);

  //Protocols in a column under ON / OFF, each in its own colour when chosen
  for(c = 0; c < DEC_PROTOS; c++)
    i2cw_cbutton(I2CW_X + DECW_PX, I2CW_Y + decw_proto_y[c], DECW_PW, dec_names[c], (c == pr) ? dec_colors[c] : MIDLEGREY_COLOR, (c == pr) ? BLACK_COLOR : WHITE_COLOR);

  i2cw_label(DECW_THR_Y, "Threshold", 0);
  //i2cw_button(I2CW_X + DECW_BX, I2CW_Y + DECW_THR_Y, DECW_HALF, "Auto 50%", scope_i2c_thr_auto, 0);
  //v1.01b4: Auto in green
  i2cw_cbutton(I2CW_X + DECW_BX, I2CW_Y + DECW_THR_Y, DECW_HALF, "Auto 50%", scope_i2c_thr_auto ? GREEN_COLOR : MIDLEGREY_COLOR, scope_i2c_thr_auto ? BLACK_COLOR : WHITE_COLOR);
  i2cw_button(I2CW_X + DECW_BE - DECW_HALF, I2CW_Y + DECW_THR_Y, DECW_HALF, "Manual", !scope_i2c_thr_auto, 0);

  for(c = 0; c < 2; c++)
  {
    //The channel and its role (Swap)
    role = c ^ scope_dec_swap;
    y = DECW_CH_Y + (c * 44);
    q = i2c_str(t, c ? "CH2 " : "CH1 ", t + 23);
    i2c_str(q, chname[pr][role], t + 23);
    i2cw_label(y, t, dim);
    i2cw_arrow(I2CW_X + DECW_BX, I2CW_Y + y, 0, dim);
    i2cw_volts(t, scope_i2c_thr_mv[c]);
    i2cw_value(y, t, dim);
    i2cw_arrow(I2CW_X + DECW_BE - 44, I2CW_Y + y, 1, dim);
  }

  if((pr == DEC_UART) || (pr == DEC_LIN))
  {
    i2cw_label(DECW_A_Y, "Baud rate", 0);
    i2cw_arrow(I2CW_X + DECW_BX, I2CW_Y + DECW_A_Y, 0, 0);
    //scope_print_decimal(t, (pr == DEC_LIN) ? lin_bauds[scope_lin_baud % LIN_BAUDS] : uart_bauds[scope_uart_baud % UART_BAUDS], 0, 0);
    //i2cw_value(DECW_A_Y, t, 0);
    i2cw_baud(DECW_A_Y, (pr == DEC_LIN) ? lin_bauds[scope_lin_baud % LIN_BAUDS] : uart_bauds[scope_uart_baud % UART_BAUDS]);     //v1.01b4
    //i2cw_arrow(I2CW_X + DECW_BE - 44, I2CW_Y + DECW_A_Y, 1, 0);
    i2cw_arrow(I2CW_X + DECW_BAUD_RX(pr == DEC_LIN), I2CW_Y + DECW_A_Y, 1, 0);     //v1.01b8: right after the frame
    i2cw_cbutton(I2CW_X + DECW_AUTO_X, I2CW_Y + DECW_A_Y, DECW_AUTO_W, "Auto", GREEN_COLOR, BLACK_COLOR);     //v1.01b8: measured
  }

  if(pr == DEC_UART)
  {
    i2cw_label(DECW_B_Y, "Format", 0);
    i2cw_button(I2CW_X + DECW_BX,       I2CW_Y + DECW_B_Y, DECW_Q, scope_uart_7bit ? "7 bit" : "8 bit", 1, 0);
    i2cw_button(I2CW_X + DECW_BX + 66,  I2CW_Y + DECW_B_Y, DECW_Q, parname[scope_uart_parity % 3], scope_uart_parity != 0, 0);
    i2cw_button(I2CW_X + DECW_BX + 132, I2CW_Y + DECW_B_Y, DECW_Q, scope_uart_stop2 ? "2 stop" : "1 stop", 1, 0);
    i2cw_button(I2CW_X + DECW_BX + 198, I2CW_Y + DECW_B_Y, DECW_Q, scope_uart_inv ? "Inv" : "Norm", scope_uart_inv, 0);
    i2cw_hexdec(DECW_C_Y);
  }
  else if(pr == DEC_LIN)
  {
    //v1.01b4: the version (which checksum is right)
    i2cw_label(DECW_B_Y, "Version", 0);

    for(c = 0; c < 3; c++)
      i2cw_button(I2CW_X + DECW_BX + (c * 88), I2CW_Y + DECW_B_Y, 84, decw_linver[c], scope_lin_ver == c, 0);

    i2cw_hexdec(DECW_C_Y);
  }
  else if(pr == DEC_SPI)
  {
    i2cw_label(DECW_A_Y, "Mode", 0);

    for(c = 0; c < 4; c++)
    {
      t[0] = '0' + c;
      t[1] = 0;
      i2cw_button(I2CW_X + DECW_BX + (c * 66), I2CW_Y + DECW_A_Y, DECW_Q, t, scope_spi_mode == c, 0);
    }

    i2cw_label(DECW_B_Y, "Bits", 0);
    i2cw_button(I2CW_X + DECW_BX,       I2CW_Y + DECW_B_Y, DECW_Q, "MSB", !scope_spi_lsb, 0);
    i2cw_button(I2CW_X + DECW_BX + 66,  I2CW_Y + DECW_B_Y, DECW_Q, "LSB", scope_spi_lsb, 0);
    i2cw_button(I2CW_X + DECW_BX + 132, I2CW_Y + DECW_B_Y, DECW_Q, "8 bit", !scope_spi_16, 0);
    i2cw_button(I2CW_X + DECW_BX + 198, I2CW_Y + DECW_B_Y, DECW_Q, "16 bit", scope_spi_16, 0);
    i2cw_hexdec(DECW_C_Y);
  }
  else if(pr == DEC_1WIRE)
  {
    i2cw_label(DECW_A_Y, "Speed", 0);
    i2cw_button(I2CW_X + DECW_BX, I2CW_Y + DECW_A_Y, DECW_HALF, "Standard", !scope_ow_overdrive, 0);
    i2cw_button(I2CW_X + DECW_BE - DECW_HALF, I2CW_Y + DECW_A_Y, DECW_HALF, "Overdrive", scope_ow_overdrive, 0);
    i2cw_hexdec(DECW_B_Y);
  }
  else
  {
    i2cw_label(DECW_A_Y, "Address", 0);
    i2cw_button(I2CW_X + DECW_BX, I2CW_Y + DECW_A_Y, DECW_HALF, "7 bit", !scope_i2c_addr10, 0);
    i2cw_button(I2CW_X + DECW_BE - DECW_HALF, I2CW_Y + DECW_A_Y, DECW_HALF, "10 bit", scope_i2c_addr10, 0);
    i2cw_hexdec(DECW_B_Y);
    i2cw_trigger_row(DECW_C_Y);     //v1.01b8
  }

  //List and Close set apart: List blue, Close red
  display_set_fg_color(0x00505050);
  display_draw_horz_line(I2CW_Y + DECW_LINE_Y, I2CW_X + 8, I2CW_X + I2CW_W - 8);
  i2cw_cbutton(I2CW_X + DECW_LIST_X, I2CW_Y + DECW_LIST_Y, 120, "List", 0x002070D0, WHITE_COLOR);
  i2cw_cbutton(I2CW_X + DECW_CLOSE_X, I2CW_Y + DECW_LIST_Y, 120, "Close", 0x00A03030, WHITE_COLOR);
}

static uint32 i2cw_in(int32 x, int32 y, int32 bx, int32 by, int32 bw)
{
  return((x >= (I2CW_X + bx)) && (x < (I2CW_X + bx + bw)) && (y >= (I2CW_Y + by)) && (y < (I2CW_Y + by + 34)));
}

//The HEX / DEC row touched: 1 when handled
static uint32 i2cw_hexdec_touch(int32 x, int32 y, int32 ry)
{
  //v1.01b6: HEX / DEC / BIN, 88 apart; the addresses take the same format
  if((y >= (I2CW_Y + ry)) && (y < (I2CW_Y + ry + 34)) && (x >= (I2CW_X + DECW_BX)) && (x < (I2CW_X + DECW_BX + 264)))
  {
    scope_i2c_fmt_data = (uint8)(((x - (I2CW_X + DECW_BX)) / 88) % 3);
    scope_i2c_fmt_addr = scope_i2c_fmt_data;
    scope_i2c_dec      = (scope_i2c_fmt_data == 1);
    return(1);
  }

  return(0);
}

void scope_i2c_settings_window(void)
{
  int32  x, y, c, list;

  tp_i2c_wait_for_touch_release();

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);

  i2cw_draw();

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    x = xtouch;
    y = ytouch;
    list = 0;

    //Outside: close
    if((x < I2CW_X) || (x > (I2CW_X + I2CW_W)) || (y < I2CW_Y) || (y > (I2CW_Y + I2CW_H)))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }

    if(i2cw_in(x, y, DECW_PX, 6, DECW_PW))
      scope_i2c_enabled ^= 1;
    else if(i2cw_in(x, y, DECW_SWX, 6, DECW_PW))
      scope_dec_swap ^= 1;
    else if(x >= (I2CW_X + DECW_PX))
    {
      //The protocol column
      for(c = 0; c < DEC_PROTOS; c++)
        if(i2cw_in(x, y, DECW_PX, decw_proto_y[c], DECW_PW))
          scope_dec_proto = (uint8)c;
    }
    else if(i2cw_in(x, y, DECW_BX, DECW_THR_Y, DECW_HALF))              scope_i2c_thr_auto = 1;
    else if(i2cw_in(x, y, DECW_BE - DECW_HALF, DECW_THR_Y, DECW_HALF))  scope_i2c_thr_auto = 0;
    else if(i2cw_in(x, y, DECW_LIST_X, DECW_LIST_Y, 120))               list = 1;
    else if(i2cw_in(x, y, DECW_CLOSE_X, DECW_LIST_Y, 120))
    {
      tp_i2c_wait_for_touch_release();
      break;
    }
    else if((y >= (I2CW_Y + DECW_CH_Y)) && (y < (I2CW_Y + DECW_CH_Y + 78)))
    {
      if(!scope_i2c_thr_auto)
      {
        for(c = 0; c < 2; c++)
        {
          if(i2cw_in(x, y, DECW_BX, DECW_CH_Y + (c * 44), 44) && (scope_i2c_thr_mv[c] > -20000))
            scope_i2c_thr_mv[c] -= 50;
          else if(i2cw_in(x, y, DECW_BE - 44, DECW_CH_Y + (c * 44), 44) && (scope_i2c_thr_mv[c] < 30000))
            scope_i2c_thr_mv[c] += 50;
        }
      }
    }
    else if(scope_dec_proto == DEC_UART)
    {
      if(i2cw_in(x, y, DECW_BX, DECW_A_Y, 44) && (scope_uart_baud > 0))                          scope_uart_baud--;
      else if(i2cw_in(x, y, DECW_BAUD_RX(0), DECW_A_Y, 44) && (scope_uart_baud < (UART_BAUDS - 1)))  scope_uart_baud++;     //v1.01b8
      else if(i2cw_in(x, y, DECW_AUTO_X, DECW_A_Y, DECW_AUTO_W))
      {
        //v1.01b8: the rate measured from the record, the nearest of the list
        c = dec_nearest_baud(uart_bauds, UART_BAUDS);
        if(c >= 0) scope_uart_baud = (uint8)c;
      }
      else if(i2cw_in(x, y, DECW_BAUD_X(0), DECW_A_Y, DECW_BAUD_W(0)))     //v1.01b5: the frame of the rate
      {
        //v1.01b4: the list of the rates
        c = dec_pick(I2CW_X + DECW_BX, I2CW_Y + 50, 200, 9, "Baud rate", UART_BAUDS, dec_uart_baud_name, scope_uart_baud);
        if(c >= 0) scope_uart_baud = (uint8)c;
      }
      else if(i2cw_in(x, y, DECW_BX, DECW_B_Y, DECW_Q))       scope_uart_7bit ^= 1;
      else if(i2cw_in(x, y, DECW_BX + 66, DECW_B_Y, DECW_Q))  scope_uart_parity = (scope_uart_parity + 1) % 3;
      else if(i2cw_in(x, y, DECW_BX + 132, DECW_B_Y, DECW_Q)) scope_uart_stop2 ^= 1;
      else if(i2cw_in(x, y, DECW_BX + 198, DECW_B_Y, DECW_Q)) scope_uart_inv ^= 1;
      else i2cw_hexdec_touch(x, y, DECW_C_Y);
    }
    else if(scope_dec_proto == DEC_LIN)
    {
      if(i2cw_in(x, y, DECW_BX, DECW_A_Y, 44) && (scope_lin_baud > 0))                          scope_lin_baud--;
      else if(i2cw_in(x, y, DECW_BAUD_RX(1), DECW_A_Y, 44) && (scope_lin_baud < (LIN_BAUDS - 1)))  scope_lin_baud++;     //v1.01b8
      else if(i2cw_in(x, y, DECW_AUTO_X, DECW_A_Y, DECW_AUTO_W))
      {
        //v1.01b8: the rate measured from the record, the nearest of the list
        c = dec_nearest_baud(lin_bauds, LIN_BAUDS);
        if(c >= 0) scope_lin_baud = (uint8)c;
      }
      else if(i2cw_in(x, y, DECW_BAUD_X(1), DECW_A_Y, DECW_BAUD_W(1)))     //v1.01b5: the frame of the rate
      {
        //v1.01b4: the list of the rates
        c = dec_pick(I2CW_X + DECW_BX, I2CW_Y + 50, 200, 7, "Baud rate", LIN_BAUDS, dec_lin_baud_name, scope_lin_baud);
        if(c >= 0) scope_lin_baud = (uint8)c;
      }
      else if((y >= (I2CW_Y + DECW_B_Y)) && (y < (I2CW_Y + DECW_B_Y + 34)) && (x >= (I2CW_X + DECW_BX)) && (x < (I2CW_X + DECW_BX + 264)))
        scope_lin_ver = (uint8)(((x - (I2CW_X + DECW_BX)) / 88) % 3);     //v1.01b4
      else i2cw_hexdec_touch(x, y, DECW_C_Y);
    }
    else if(scope_dec_proto == DEC_SPI)
    {
      for(c = 0; c < 4; c++)
        if(i2cw_in(x, y, DECW_BX + (c * 66), DECW_A_Y, DECW_Q))
          scope_spi_mode = (uint8)c;

      if(i2cw_in(x, y, DECW_BX, DECW_B_Y, DECW_Q))            scope_spi_lsb = 0;
      else if(i2cw_in(x, y, DECW_BX + 66, DECW_B_Y, DECW_Q))  scope_spi_lsb = 1;
      else if(i2cw_in(x, y, DECW_BX + 132, DECW_B_Y, DECW_Q)) scope_spi_16 = 0;
      else if(i2cw_in(x, y, DECW_BX + 198, DECW_B_Y, DECW_Q)) scope_spi_16 = 1;
      else i2cw_hexdec_touch(x, y, DECW_C_Y);
    }
    else if(scope_dec_proto == DEC_1WIRE)
    {
      if(i2cw_in(x, y, DECW_BX, DECW_A_Y, DECW_HALF))                   scope_ow_overdrive = 0;
      else if(i2cw_in(x, y, DECW_BE - DECW_HALF, DECW_A_Y, DECW_HALF))  scope_ow_overdrive = 1;
      else i2cw_hexdec_touch(x, y, DECW_B_Y);
    }
    else
    {
      if(i2cw_in(x, y, DECW_BX, DECW_A_Y, DECW_HALF))                   scope_i2c_addr10 = 0;
      else if(i2cw_in(x, y, DECW_BE - DECW_HALF, DECW_A_Y, DECW_HALF))  scope_i2c_addr10 = 1;
      else if(i2cw_in(x, y, DECW_BX, DECW_C_Y, 84))                     scope_dec_trig = 0;     //v1.01b8: the trigger
      else if(i2cw_in(x, y, DECW_BX + 88, DECW_C_Y, 84))                scope_dec_trig = 1;
      else if(i2cw_in(x, y, DECW_BX + 176, DECW_C_Y, 84))
      {
        //The address from the list (0x00 .. 0x7F)
        c = dec_pick(I2CW_X + DECW_BX, I2CW_Y + 50, 200, 9, "Trigger address", 128, dec_addr_name, scope_dec_trig_addr);

        if(c >= 0)
          scope_dec_trig_addr = (uint8)c;

        if((c >= 0) || (scope_dec_trig == 2))
          scope_dec_trig = 2;
      }
      else i2cw_hexdec_touch(x, y, DECW_B_Y);
    }

    if(list)
    {
      scope_i2c_list();

      //v1.01b6: a row of the List moved the trace: the window closes, the trace is drawn again
      if(dec_list_jumped)
        break;

      i2cw_draw();
      continue;
    }

    i2cw_draw();
    tp_i2c_wait_for_touch_release();
  }

  display_set_source_buffer(displaybuffer3);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(I2CW_X, I2CW_Y, I2CW_W + 1, I2CW_H + 1);

  if(dec_list_jumped)
  {
    dec_list_jumped = 0;
    scope_display_trace_data();
  }
}

//v1.01b1: UART / SPI settings in one word: bits 1..0 protocol, 2 UART 7 bit, 4..3 parity, 5 2 stop bits, 6 inverted,
//8..7 SPI mode, 9 LSB first, 10 16 bit; and the baud rate index
uint16 scope_dec_settings_word(void)
{
  //v1.01b2: bit 11 the third bit of the protocol, 12 Swap, 13 1-Wire overdrive
  return((uint16)((scope_dec_proto & 3) | (scope_uart_7bit ? 4 : 0) | ((scope_uart_parity % 3) << 3) | (scope_uart_stop2 ? 0x20 : 0) |
                  (scope_uart_inv ? 0x40 : 0) | ((scope_spi_mode & 3) << 7) | (scope_spi_lsb ? 0x200 : 0) | (scope_spi_16 ? 0x400 : 0) |
                  ((scope_dec_proto & 4) ? 0x800 : 0) | (scope_dec_swap ? 0x1000 : 0) | (scope_ow_overdrive ? 0x2000 : 0) |
                  ((scope_lin_ver % 3) << 14)));     //v1.01b4: bits 15..14 the LIN version
}

uint16 scope_dec_baud_index(void)
{
  return(scope_uart_baud);
}

void scope_dec_settings_set(uint16 w, uint16 baud)
{
  //scope_dec_proto   = (uint8)((w & 3) % 3);
  scope_dec_proto    = (uint8)(((w & 3) | ((w & 0x800) ? 4 : 0)) % DEC_PROTOS);     //v1.01b2
  scope_dec_swap     = (w & 0x1000) ? 1 : 0;
  scope_ow_overdrive = (w & 0x2000) ? 1 : 0;
  scope_lin_ver      = (uint8)(((w >> 14) & 3) % 3);     //v1.01b4
  scope_uart_7bit   = (w & 4) ? 1 : 0;
  scope_uart_parity = (uint8)(((w >> 3) & 3) % 3);
  scope_uart_stop2  = (w & 0x20) ? 1 : 0;
  scope_uart_inv    = (w & 0x40) ? 1 : 0;
  scope_spi_mode    = (uint8)((w >> 7) & 3);
  scope_spi_lsb     = (w & 0x200) ? 1 : 0;
  scope_spi_16      = (w & 0x400) ? 1 : 0;
  scope_uart_baud   = (baud < UART_BAUDS) ? (uint8)baud : 5;
}

//v1.01b4: the colour of the chosen protocol (the Decoder button of CTRL)
uint32 scope_dec_color(void)
{
  return(dec_colors[scope_dec_proto % DEC_PROTOS]);
}

//v1.01b1: the protocol's name for the channel menu
const char *scope_dec_name(void)
{
  //return((scope_dec_proto == DEC_UART) ? "UART" : (scope_dec_proto == DEC_SPI) ? "SPI" : "I2C");
  return(dec_names[scope_dec_proto % DEC_PROTOS]);     //v1.01b2
}

//v1.01b2: the protocol at start for Settings: "Last" or its name; the next one on a tap
const char *scope_dec_start_name(void)
{
  return(scope_dec_start_proto ? dec_names[(scope_dec_start_proto - 1) % DEC_PROTOS] : "Last");
}

void scope_dec_start_next(void)
{
  scope_dec_start_proto = (scope_dec_start_proto + 1) % (DEC_PROTOS + 1);
}

//v1.01b2: the start settings and the LIN baud rate in one word: bit 0 on at start, 3..1 protocol at start, 4 Auto
//threshold at start, 11..8 LIN baud index + 1 (0 in older settings: 19200)
uint16 scope_dec_start_word(void)
{
  return((uint16)((scope_dec_start_on ? 1 : 0) | ((scope_dec_start_proto & 7) << 1) | (scope_dec_start_auto ? 0x10 : 0) |
                  (scope_dec_btn_on ? 0x20 : 0) |     //v1.01b6: bit 5
                  (((scope_lin_baud % LIN_BAUDS) + 1) << 8)));
}

//After the decoder settings are loaded: the start settings applied
void scope_dec_start_set(uint16 w)
{
  uint32 lb = (w >> 8) & 15;

  scope_dec_start_on    = (w & 1) ? 1 : 0;
  scope_dec_start_proto = (uint8)(((w >> 1) & 7) % (DEC_PROTOS + 1));
  scope_dec_start_auto  = (w & 0x10) ? 1 : 0;
  scope_dec_btn_on      = (w & 0x20) ? 1 : 0;     //v1.01b6
  scope_lin_baud        = (lb && (lb <= LIN_BAUDS)) ? (uint8)(lb - 1) : 5;

  scope_i2c_enabled = scope_dec_start_on;

  if(scope_dec_start_proto)
    scope_dec_proto = scope_dec_start_proto - 1;

  if(scope_dec_start_auto)
    scope_i2c_thr_auto = 1;
}

//v1.01a3: the decoder settings in one settings word (bit 0 on, 1 manual threshold, 2 10 bit, 3 decimal) and the two
//thresholds in mV (0 = default 1650 mV)
uint16 scope_i2c_settings_word(void)
{
  //v1.01a5: bits 5..4 the list's address format, 7..6 its data format
  return((uint16)((scope_i2c_enabled ? 1 : 0) | (scope_i2c_thr_auto ? 0 : 2) | (scope_i2c_addr10 ? 4 : 0) | (scope_i2c_dec ? 8 : 0) |
                  ((scope_i2c_fmt_addr % 3) << 4) | ((scope_i2c_fmt_data % 3) << 6) | ((scope_i2c_chip & 63) << 8)));     //v1.01b0: 6 bits     //v1.01a7: bits 10..8 the chip (v1.01a8: 12..8, 0 Auto, 1 Off, 2.. the chips in name order)
}

void scope_i2c_settings_set(uint16 w, uint16 sda, uint16 scl)
{
  scope_i2c_enabled  = (w & 1) ? 1 : 0;
  scope_i2c_thr_auto = (w & 2) ? 0 : 1;
  scope_i2c_addr10   = (w & 4) ? 1 : 0;
  scope_i2c_dec      = (w & 8) ? 1 : 0;
  scope_i2c_fmt_addr = ((w >> 4) & 3) % 3;     //v1.01a5
  scope_i2c_fmt_data = ((w >> 6) & 3) % 3;
  scope_i2c_chip     = (uint8)((w >> 8) & 63);     //v1.01b0: 6 bits     //v1.01a7 (v1.01a8: checked against the chips when they are loaded)
  scope_i2c_thr_mv[0] = sda ? (int32)(int16)sda : 1650;
  scope_i2c_thr_mv[1] = scl ? (int32)(int16)scl : 1650;
}
