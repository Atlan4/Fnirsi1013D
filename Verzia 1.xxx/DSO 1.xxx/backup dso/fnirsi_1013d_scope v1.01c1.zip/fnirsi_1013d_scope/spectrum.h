//----------------------------------------------------------------------------------------------------------------------------------
// spectrum.h - spectrum analyser view (v1.00q6). The FFT core is fx_fft.c from the MCP firmware (fnirsi-1013d-mcp), the
// view itself is written for this firmware: it replaces the trace display while it is active and uses the captured
// trace buffers, so no FPGA change is needed.
//----------------------------------------------------------------------------------------------------------------------------------

#ifndef SPECTRUM_H
#define SPECTRUM_H

#include "types.h"

//Switch the view on (1) or off (0), and ask whether it is on
void   spectrum_set_active(int on);
void   spectrum_settings_for_save(void);     //v1.00z4
int    spectrum_is_active(void);

//Draw the spectrum of the current trace buffers in the trace area (called instead of the trace display)
void   spectrum_display(void);

//Shown instead of the spectrum when the long time base mode is selected (no trace buffer to analyse)
void   spectrum_long_mode_note(void);

//Touch in the trace area while the view is active: the settings buttons under the plot and their lists (v1.00q8)
void   spectrum_handle_touch(void);

//v1.00q7: a new record was captured (called by scope_acquire_trace_data), the averaging adds it
void   spectrum_new_record(void);

//v1.00r2: AUTO SET in the spectrum view (fundamental, sample rate for its harmonics, Ref level and Scale; the volts
//per division are left alone), and its end
void   spectrum_autoset(void);
void   spectrum_autoset_cancel(void);

//v1.00r4: MEASURES in the spectrum view: which readouts the text lines above the plot show
void   spectrum_open_measures_menu(void);

//v1.00r8: the spectrum view's own frequency (0) and level (1) cursor, switched by the F / L CURSOR buttons
void   spectrum_toggle_cursor(int level);

//v1.00t1: 20 log10 of the volts per ADC code of a channel in centi-dB (the frequency response view uses it)
#include "variables.h"
int32  spectrum_channel_volts_cdb(PCHANNELSETTINGS s);

//v1.00v3: SAVE SPEC (the file in \spectrum\, its thumbnail, the CSV) and showing a saved file
uint32 spectrum_file_write(FIL *fp);
uint32 spectrum_csv_write(void);
void   spectrum_fill_thumbnail(PTHUMBNAILDATA td);
void   spectrum_view_file(void);

//v1.00v4: the view's settings in the settings sector (10 words)
void   spectrum_settings_save(uint16 *ptr);
void   spectrum_settings_load(const uint16 *ptr);

//v1.00y3: reference spectra panel from the menu of channel ch (0 CH1, 1 CH2), only for a shown channel
int  spectrum_ref_channel_ok(int ch);
void spectrum_ref_panel(uint32 xpos, int ch);

#endif
