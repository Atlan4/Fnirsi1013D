//----------------------------------------------------------------------------------------------------------------------------------

#include "fnirsi_1013d_scope.h"
#include "variables.h"

// Definovanie konštánt
#define PI 3.14159265358979323846
#define N 100  // Počet vzoriek v pôvodnom poli
//#define INTERPOLATED_SIZE 720  // Počet vzoriek po interpolácii

// FIR koeficienty pre dolnopriepustný filter (toto sú hypotetické hodnoty)

#define FIR_ORDER (sizeof(fir_coeffs) / sizeof(fir_coeffs[0]))


//----------------------------------------------------------------------------------------------------------------------------------

FRESULT convert_waveforms_to_csv_excel(void);

void display_text_message(char* message, uint8 value);



double sinc(double x);
//void sinc_interpolation(double* t_interp, double* t_sampled, int* sampled_signal, int* sincpole, int interp_size, int sampled_size);
void sinc_interpolation(double* t_interp, double* t_sampled, int* sampled_signal, int* sincpole, int size);

void moving_average(uint8* input, size_t size, size_t window_size);

void exponential_moving_average(uint8_t* input, size_t size, double alpha);

void fir_filter(uint8_t* input, size_t size);

void filter_bit_changes(uint8_t* input, size_t size);

void modify_signal(uint8_t* input, size_t size);
void add_one_bit(uint8_t* input, size_t size);

void average_filter(uint8* input, size_t size, size_t window_size);
 
//void scope_update_cursor_possition(void);
 
//void scope_preset_long_mode(void);

void scope_get_long_timebase_data(void);
void scope_roll_logger_pass(void);     //v1.00y9: roll on the FPGA streaming logger (0x2050 / 0x3050)
//v1.00z0: roll record (length = Memory), scroll box, save / thumbnail / viewer
extern uint32 rollview_count;
void   scope_roll_view_draw(void);
void   scope_roll_view_set(uint32 count, uint32 view);
uint32 scope_roll_live(void);
void   scope_roll_preset(void);
void   scope_roll_linearize(uint32 *count, uint32 *view);
uint32 scope_roll_thumbnail(PTHUMBNAILDATA td);
uint32 scope_roll_slider_touch(void);
void   scope_roll_restart(void);     //v1.00z1
uint32 scope_roll_ui(void);          //v1.00z1
//v1.00z5: measurements, Peak / Pro trace and REF in the logger roll
extern uint8 scope_roll_meas;        //1 while the measurement tiles of the roll are formatted (time / frequency units)
extern uint8 view_ref_roll;          //v1.00z6: REF files in the ref_roll folder (scope_functions.c)
uint32 scope_roll_trace_mode(void);
void   scope_roll_measurements(void);
uint32 scope_ref_is_roll(PCHANNELSETTINGS ref);
void   scope_roll_ref_copy(PCHANNELSETTINGS dest, PCHANNELSETTINGS src);
void   scope_roll_ref_moved(void);      //v1.00z6
extern uint8 view_ref_roll_force;    //v1.00z7: REF files in the ref_roll folder outside the roll too (startup load)
void   scope_refset_sync(void);         //v1.00z7: REF sets of the normal time base and of the roll
uint8  scope_refset_get(uint32 roll, uint32 r);
void   scope_refset_loaded(uint32 mask);
void   scope_refset_load_roll_files(void);
//v1.01a2: I2C decoder (SDA = CH1, SCL = CH2)
extern uint8 scope_i2c_enabled;
void   scope_i2c_display(void);
uint32 scope_i2c_tap(int32 x, int32 y);
void   scope_i2c_list(void);
//v1.01a3: decoder settings
extern uint8  scope_i2c_thr_auto;
extern int32  scope_i2c_thr_mv[2];
extern uint8  scope_i2c_addr10;
extern uint8  scope_i2c_dec;
void   scope_i2c_settings_window(void);
uint16 scope_i2c_settings_word(void);
void   scope_i2c_settings_set(uint16 w, uint16 sda, uint16 scl);
void   scope_i2c_chip_name_save(uint16 *p);          //v1.01b4: the chosen chip by its name
void   scope_i2c_chip_name_load(const uint16 *p);
uint32 scope_dec_color(void);                        //v1.01b4: the colour of the chosen protocol
extern uint8 scope_dec_btn_on;                       //v1.01b6: the Decode button of CTRL switches the decoder on
void   scope_dec_trigger_after(void);                //v1.01b8: the decoder trigger (I2C NACK / address) stops RUN
uint16 scope_dec_trig_word(void);
void   scope_dec_trig_set(uint16 w);
//v1.01b1: UART / SPI decoders
uint16 scope_dec_settings_word(void);
uint16 scope_dec_baud_index(void);
void   scope_dec_settings_set(uint16 w, uint16 baud);
const char *scope_dec_name(void);
//v1.01b2: start settings of the decoder (Settings > Measure > Decoder)
extern uint8 scope_dec_start_on;
extern uint8 scope_dec_start_auto;
const char *scope_dec_start_name(void);
void   scope_dec_start_next(void);
uint16 scope_dec_start_word(void);
void   scope_dec_start_set(uint16 w);

void scope_check_long_trigger(void);



//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_ADoffset_value(void);

void scope_test_TP(void);

void scope_test_sunlight(void);

void scope_test_longbase_value(void);

void scope_test_trigerposition_value(void);
void scope_test_calibration_value(void);

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------
