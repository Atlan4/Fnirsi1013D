//----------------------------------------------------------------------------------------------------------------------------------
// spectrum.c - spectrum analyser view (v1.00q6, settings buttons and THD v1.00q8), see spectrum.h.
//
// The FFT, the windows and the dB conversion are fx_fft.c from the MCP firmware (integer only, no FPU). The dBV scaling
// follows the MCP spectrum.c (spec_gain_cdb): the volts per ADC code come from the same input_calibration and
// volt_calc_data tables this firmware uses for its voltage measurements.
//
// Layout of the trace area (x 2..729, y 48..479):
//   y  50..84   v1.00r4: text lines above the plot (peak readout per channel left, N / RBW and the cursor readout right)
//   y  86..406  plot, 8 vertical divisions of 40 px, x 54..724, frequency grid in 1-2-5 steps (0 .. fs/2)
//               v1.00r4: one frequency cursor (T CURSOR) and one level cursor (V CURSOR), dragged in the plot
//   y 410       frequency labels under the vertical grid lines, dB labels left of the plot
//   y 434..474  v1.00q8: seven buttons (Channel, FFT points, Window, Average, Scale, Ref level, Reset). A touch on a
//               button opens the list of its values above it, a touch on a value chooses it and closes the list (a
//               touch outside closes it without a change); Reset acts at once.
// Peak readout per channel at the top left: frequency, level and THD (harmonics 2..10, as MCP ui_ms_thd).
// Averaging is done on the dB values of new records (as MCP: Off, 4, 16, 64, max hold; default 4), which gives the
// smoother trace.
// The right side menu (time/div, V/div, run/stop) keeps working: the time base sets the sample rate and so the span.
//----------------------------------------------------------------------------------------------------------------------------------

#include "types.h"
#include "spectrum.h"
#include "fx_fft.h"
#include "fnirsi_1013d_scope.h"
#include "variables.h"
#include "display_lib.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "menu.h"
#include "scope_functions.h"
#include "statemachine.h"
#include "ref_and_math.h"     //v1.00y3: reference spectra panel

//----------------------------------------------------------------------------------------------------------------------------------

#define SP_X0             54          //v1.00r0: room for the top dB label with its unit
#define SP_X1             724
#define SP_Y0             sp_y0       //v1.00r8: top of the plot follows the number of text lines above it
#define SP_Y0_MAX         (SP_TXT_Y + (4 * SP_TXT_LINE) + 2)
#define SP_TXT_Y          50          //first text line above the plot
#define SP_TXT_LINE       18          //v1.00r5: line pitch of the boxed readouts
#define SP_CH_COL_X       322         //v1.00s0: fixed x of the CH1 / CH2 readout column
#define SP_FCUR_COLOR     ORANGE_COLOR    //v1.00r5: frequency cursor and its readout
#define SP_LCUR_COLOR     MAGENTA_COLOR   //v1.00r5: level cursor and its readout
#define SP_BOX_FILL       0x00101010
#define SP_Y1             406
#define SP_W              (SP_X1 - SP_X0)
#define SP_H              (SP_Y1 - SP_Y0)
#define SP_DIVS_X         10
#define SP_DIVS_Y         8

//Button row under the plot (v1.00q8)
#define SP_BTN_Y          434
#define SP_BTN_H          40
#define SP_BTN_X0         4
#define SP_BTN_W          100
#define SP_BTN_PITCH      104
#define SP_BTN_COUNT      7

#define SP_BTN_CHANNEL    0
#define SP_BTN_FFT        1
#define SP_BTN_WINDOW     2
#define SP_BTN_AVERAGE    3
#define SP_BTN_SCALE      4
#define SP_BTN_REF        5
#define SP_BTN_RESET      6

//List of values that opens above a button
//#define SP_LIST_W         120
#define SP_LIST_W         SP_BTN_W    //v1.00q9: the list is as wide as the button it opens from
#define SP_LIST_ROW_H     30

#define SP_TEXT_COLOR     0x00C0C0C0

#define SP_LOG2_MIN       8           //256 points
#define SP_LOG2_MAX       12          //4096 points
#define SP_N_MAX          (1 << SP_LOG2_MAX)

#define SP_CH_1           0
#define SP_CH_2           1
#define SP_CH_BOTH        2

//----------------------------------------------------------------------------------------------------------------------------------

static const int8  *sp_window_names[FX_WIN_COUNT] = { "Rect", "Hann", "Flat-top" };
static const int16  sp_ref_levels[] = { 20, 10, 0, -10, -20, -30, -40 };     //dBV at the top of the plot
static const uint8  sp_db_per_div[] = { 5, 10, 20 };
static const int8  *sp_avg_names[]  = { "Off", "4", "16", "64", "Max hold" };
static const uint8  sp_avg_n[]      = { 1, 4, 16, 64, 0 };                    //0 = max hold
static const int8  *sp_btn_names[SP_BTN_COUNT] = { "Channel", "FFT points", "Window", "Average", "Scale", "Ref level", "Reset" };
static const int8  *sp_channel_names[3] = { "CH1", "CH2", "CH1 + CH2" };

#define SP_AVG_COUNT      (sizeof(sp_avg_n) / sizeof(sp_avg_n[0]))

#define SP_REF_COUNT      (sizeof(sp_ref_levels) / sizeof(sp_ref_levels[0]))
#define SP_DBDIV_COUNT    (sizeof(sp_db_per_div) / sizeof(sp_db_per_div[0]))

typedef struct
{
  uint8 active;
  uint8 channel;          //SP_CH_1, SP_CH_2 or SP_CH_BOTH
  uint8 window;           //FX_WIN_*
  uint8 ref;              //index in sp_ref_levels
  uint8 dbdiv;            //index in sp_db_per_div
  uint8 note_shown;       //long time base note drawn
  uint8 log2n;            //chosen FFT points (limited by the record length)
  uint8 avg;              //index in sp_avg_n
  uint8 fresh;            //bit per channel: a new record was captured since its last FFT
  uint8 meas;             //v1.00r4: readouts shown in the text lines (SP_MS_*), chosen in MEASURES
  uint16 fcur;            //v1.00r4: frequency cursor, x offset in the plot 0..SP_W
  uint16 lcur;            //v1.00r4: level cursor, y offset in the plot 0..SP_H
  uint8 fcur_on;          //v1.00r8: frequency cursor on, independent of the scope's time cursors
  uint8 lcur_on;          //v1.00r8: level cursor on, independent of the scope's volt cursors
} SPECTRUMSTATE;

//Readouts of the text lines (v1.00r4)
#define SP_MS_FREQ        0x01        //peak frequency
#define SP_MS_LEVEL       0x02        //peak level
#define SP_MS_THD         0x04        //THD of the peak as the fundamental
#define SP_MS_NOISE       0x08        //noise floor (median of the bins)
#define SP_MS_COUNT       4           //v1.00r8: N / RBW is always shown, no longer a choice
#define SP_MS_DEFAULT     (SP_MS_FREQ | SP_MS_LEVEL | SP_MS_THD)
#define SP_MS_CHANNEL     (SP_MS_FREQ | SP_MS_LEVEL | SP_MS_THD | SP_MS_NOISE)

//Defaults as the MCP view (Reset): CH1, 2048 points, Hann, average 4, 10 dB/div, ref 0 dBV
#define SP_DEFAULTS       { 0, SP_CH_1, FX_WIN_HANN, 2, 1, 0, 11, 1, 3, SP_MS_DEFAULT, SP_W / 4, 160, 0, 0 }

static SPECTRUMSTATE sp = SP_DEFAULTS;

//v1.00r8: top of the plot, set per display from the text lines above it (row 0 N / RBW, then cursors, CH1, CH2)
static int32 sp_y0 = 86;

//Averaging state per channel: accumulator x16 in centi-dBV, records in it, and a key of the parameters it belongs to
static int32  sp_acc[2][(1 << SP_LOG2_MAX) / 2 + 1];
static uint32 sp_navg[2];
static uint32 sp_key[2];

//FFT plan and work memory (int32, 8-byte aligned as fx_fft requires)
static int32  sp_win[FX_FFT_WIN_WORDS(SP_LOG2_MAX)] __attribute__((aligned(8)));
static int32  sp_buf[FX_FFT_BUF_WORDS(SP_LOG2_MAX)] __attribute__((aligned(8)));
static int16  sp_cdb[2][(SP_N_MAX / 2) + 1];      //centi-dBV per bin and channel as shown (averaged)
static int16  sp_raw[2][(SP_N_MAX / 2) + 1];      //centi-dBV per bin of the latest record
static FX_FFT sp_fft;
static int    sp_plan_log2   = 0;
static int    sp_plan_window = -1;

//----------------------------------------------------------------------------------------------------------------------------------
//Small text helpers (no sprintf in this firmware)

static char *sp_str(char *p, const char *s)
{
  while(*s)
    *p++ = *s++;

  *p = 0;
  return(p);
}

static char *sp_uint(char *p, uint32 v)
{
  char   t[11];
  uint32 i = 0;

  do
  {
    t[i++] = '0' + (v % 10);
    v /= 10;
  } while(v);

  while(i)
    *p++ = t[--i];

  *p = 0;
  return(p);
}

//Integer part and a fixed number of decimals, trailing zeros of the decimals removed when trim is set
static char *sp_fixed(char *p, uint32 ip, uint32 frac, uint32 decimals, int trim)
{
  char   t[8];
  uint32 i;

  p = sp_uint(p, ip);

  if(decimals == 0)
    return(p);

  for(i = decimals; i > 0; i--)
  {
    t[i - 1] = '0' + (frac % 10);
    frac /= 10;
  }

  if(trim)
  {
    while((decimals > 0) && (t[decimals - 1] == '0'))
      decimals--;
  }

  if(decimals)
  {
    *p++ = '.';

    for(i = 0; i < decimals; i++)
      *p++ = t[i];
  }

  *p = 0;
  return(p);
}

//Frequency in mHz as Hz / kHz / MHz with three decimals
static char *sp_freq(char *p, uint64 f_mhz, int trim)
{
  uint64 hz = f_mhz / 1000;

  if(hz >= 1000000)
    p = sp_fixed(p, (uint32)(hz / 1000000), (uint32)((hz % 1000000) / 1000), 3, trim), p = sp_str(p, " MHz");
  else if(hz >= 1000)
    p = sp_fixed(p, (uint32)(hz / 1000), (uint32)(hz % 1000), 3, trim), p = sp_str(p, " kHz");
  else
    p = sp_fixed(p, (uint32)hz, (uint32)((f_mhz % 1000) / 10), 2, trim), p = sp_str(p, " Hz");

  return(p);
}

//Centi-dB with one decimal
static char *sp_db(char *p, int32 cdb)
{
  if(cdb < 0)
  {
    *p++ = '-';
    cdb = -cdb;
  }

  return(sp_fixed(p, cdb / 100, (cdb % 100) / 10, 1, 0));
}

//Width in pixels of a text in the current variable width font
static uint32 sp_text_width(const char *text)
{
  extern DISPLAYDATA displaydata;
  PFONTDATA        font = displaydata.font;
  PFONTINFORMATION info;
  uint32           width = 0;

  if(font->type != VARIABLE_WIDTH_FONT)
    return(0);

  while(*text)
  {
    info = check_char_in_vw_font(font->fontinformation, (uint16)(uint8)*text);

    if(info)
      width += info->fontmetrics[(uint8)*text - info->first_char].width;

    text++;
  }

  return(width);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Scaling

static PCHANNELSETTINGS sp_channel(int ch)
{
  return((ch == SP_CH_2) ? &scopesettings.channel2 : &scopesettings.channel1);
}

//Centi-dB from "dB re 1 ADC code RMS" (fx_fft) to dBV (or dBA), as the MCP spec_gain_cdb
static int32 sp_gain_cdb(PCHANNELSETTINGS s)
{
  uint32 r  = (s->samplevoltperdiv < 7) ? s->samplevoltperdiv : 6;
  uint32 m  = (s->magnification < 7) ? s->magnification : 1;
  int64  ic = s->input_calibration[r];
  uint64 uv_q8;
  const VOLTCALCDATA *v = &volt_calc_data[m][r];

  if(ic <= 0)
    ic = 1;

  //uV per code x 256 = ic * mul * 10 / 2^13 (VOLTAGE_SHIFTER 21 minus the 8 fraction bits); volt_scale 4 counts in
  //units 1000x larger than volt_scale 3
  uv_q8 = ((uint64)ic * v->mul_factor * 10 * ((v->volt_scale > 3) ? 1000 : 1) + 4096) >> 13;

  if(uv_q8 == 0)
    uv_q8 = 1;

  //20 log10(uv_q8 / 256 * 1e-6) in centi-dB
  return((2 * fx_cdb_from_q16(fx_log2_q16(uv_q8))) - (2 * fx_cdb_from_q16(8 << 16)) - 12000);
}

//Number of FFT points: the chosen one, limited to the largest power of two in the record (256 .. 4096)
//v1.00v3: a saved spectrum is shown (Saved waveforms in this view): its own rate, points and channels, no FFT
static uint8  sp_viewing = 0;
static uint32 sp_view_fs;
static uint8  sp_view_log2n, sp_view_en1, sp_view_en2;

static int sp_log2n(void)
{
  uint32 n = fpgasettings.totalsamples;
  int    l = SP_LOG2_MIN;

  if(sp_viewing)
    return(sp_view_log2n);

  while((l < SP_LOG2_MAX) && (l < sp.log2n) && ((1u << (l + 1)) <= n))
    l++;

  return(l);
}

static uint32 sp_sample_rate(void)
{
  if(sp_viewing)
    return(sp_view_fs);

  return(sample_rate[scopesettings.samplerate]);
}

//Frequency of bin k in mHz
static uint64 sp_bin_mhz(uint32 k, int log2n)
{
  return(((uint64)k * sp_sample_rate() * 1000) >> log2n);
}

//The channels to show, following what is enabled; -1 when the chosen channel is off
static int sp_fix_channel(void)
{
  int on1 = sp_viewing ? sp_view_en1 : scopesettings.channel1.enable;
  int on2 = sp_viewing ? sp_view_en2 : scopesettings.channel2.enable;

  if((sp.channel == SP_CH_BOTH) && !(on1 && on2))
    return(on1 ? SP_CH_1 : (on2 ? SP_CH_2 : -1));

  if((sp.channel == SP_CH_1) && !on1)
    return(-1);

  if((sp.channel == SP_CH_2) && !on2)
    return(-1);

  return(sp.channel);
}

//FFT of one channel into sp_raw[ch] when there is a new record (or the parameters changed), then the averaging
//(as MCP spectrum.c: on the dB values, x16 accumulator, or max hold) into sp_cdb[ch], bins 0 .. N/2
static void sp_compute(int ch, int log2n)
{
  PCHANNELSETTINGS s = sp_channel(ch);
  uint32 half = 1u << (log2n - 1);
  int32  gain = sp_gain_cdb(s);
  uint32 key, k, n;
  int    fresh = (sp.fresh >> ch) & 1;

  //v1.00v3: a saved spectrum is shown as it was saved
  if(sp_viewing)
    return;

  //Parameters the accumulated spectrum belongs to: a change starts the averaging again
  key = 2166136261u;
  key = (key ^ (uint32)log2n) * 16777619u;
  key = (key ^ (uint32)sp.window) * 16777619u;
  key = (key ^ sp_sample_rate()) * 16777619u;
  key = (key ^ (uint32)gain) * 16777619u;
  key = (key ^ (uint32)sp.avg) * 16777619u;

  if(key != sp_key[ch])
  {
    sp_key[ch]  = key;
    sp_navg[ch] = 0;
  }

  //Nothing new to add: show what is accumulated
  if(sp_navg[ch] && !fresh)
    return;

  if((sp_plan_log2 != log2n) || (sp_plan_window != sp.window))
  {
    fx_fft_init(&sp_fft, log2n, sp.window, sp_win, sp_buf);
    sp_plan_log2   = log2n;
    sp_plan_window = sp.window;
  }

  //The record from its start; the ADC zero is code 128, the DC bin shows the rest
  fx_fft_run_u8(&sp_fft, s->tracebuffer, 128);
  fx_fft_cdb(&sp_fft, 0, half + 1, gain, sp_raw[ch]);

  sp.fresh &= ~(1 << ch);

  n = sp_avg_n[sp.avg];

  if(sp_navg[ch] < 0xFFFF)
    sp_navg[ch]++;

  for(k = 0; k <= half; k++)
  {
    int32 x = (int32)sp_raw[ch][k] * 16;

    if(sp_navg[ch] == 1)
      sp_acc[ch][k] = x;
    else if(n == 0)
    {
      //Max hold
      if(x > sp_acc[ch][k])
        sp_acc[ch][k] = x;
    }
    else
      sp_acc[ch][k] += (x - sp_acc[ch][k]) / (int32)((sp_navg[ch] < n) ? sp_navg[ch] : n);

    sp_cdb[ch][k] = (int16)((sp_acc[ch][k] + ((sp_acc[ch][k] < 0) ? -8 : 8)) / 16);
  }
}

//y of a level in centi-dBV, clamped to the plot
static int32 sp_level_y(int32 cdb)
{
  int32 top  = sp_ref_levels[sp.ref] * 100;
  int32 span = sp_db_per_div[sp.dbdiv] * 100 * SP_DIVS_Y;
  int32 y    = SP_Y0 + (((top - cdb) * SP_H) / span);

  if(y < SP_Y0)
    y = SP_Y0;
  else if(y > SP_Y1)
    y = SP_Y1;

  return(y);
}

//Peak bin above the DC region (bins 0..2 skipped)
static uint32 sp_peak(int ch, int log2n)
{
  uint32 n2 = 1u << (log2n - 1);
  uint32 k, best = 3;

  for(k = 3; k <= n2; k++)
  {
    if(sp_cdb[ch][k] > sp_cdb[ch][best])
      best = k;
  }

  return(best);
}

//----------------------------------------------------------------------------------------------------------------------------------
//THD (v1.00q8), taken from the MCP firmware ui_meas.c (ui_ms_thd, ui_ms_pow_q24, ui_ms_isqrt64)

#define SP_THD_K_MIN      5           //fundamental at least at bin 5 (clear of DC)
#define SP_THD_HARMONICS  10          //harmonics 2..10
#define SP_THD_F0_LOW     (-1)
#define SP_THD_F0_HIGH    (-2)

//10^(i / 100) in Q24, i = 0..100: power ratio of i / 10 dB
static const uint32 sp_pow10_q24[101] =
{
  16777216, 17168008, 17567902, 17977111, 18395852, 18824346, 19262821, 19711510,
  20170650, 20640485, 21121264, 21613241, 22116678, 22631842, 23159005, 23698447,
  24250455, 24815321, 25393344, 25984831, 26590095, 27209458, 27843248, 28491801,
  29155460, 29834578, 30529514, 31240638, 31968326, 32712964, 33474947, 34254679,
  35052572, 35869052, 36704549, 37559508, 38434381, 39329633, 40245738, 41183182,
  42142461, 43124085, 44128574, 45156461, 46208290, 47284619, 48386019, 49513075,
  50666382, 51846554, 53054215, 54290007, 55554583, 56848616, 58172790, 59527809,
  60914389, 62333268, 63785196, 65270944, 66791300, 68347069, 69939077, 71568167,
  73235204, 74941071, 76686673, 78472935, 80300804, 82171250, 84085265, 86043862,
  88048081, 90098984, 92197659, 94345219, 96542801, 98791572, 101092723, 103447475,
  105857077, 108322805, 110845967, 113427901, 116069976, 118773593, 121540186, 124371220,
  127268198, 130232655, 133266164, 136370331, 139546804, 142797267, 146123443, 149527095,
  153010028, 156574090, 160221169, 163953199, 167772160
};

//Power ratio of a level in centi-dB (-120 .. +20 dB) in Q24
static uint64 sp_pow_q24(int32 cdb)
{
  int32  q, r, j, f;
  uint64 v;

  if(cdb < -12000) cdb = -12000;
  if(cdb > 2000)   cdb = 2000;

  //cdb = 1000 q + r, 0 <= r < 1000 (floor division)
  q = (cdb >= 0) ? cdb / 1000 : -((-cdb + 999) / 1000);
  r = cdb - 1000 * q;
  j = r / 10;
  f = r % 10;

  v = sp_pow10_q24[j] + (((uint64)(sp_pow10_q24[j + 1] - sp_pow10_q24[j]) * (uint32)f) / 10);

  for(; q > 0; q--)
    v *= 10;

  for(; q < 0; q++)
    v /= 10;

  return(v);
}

static uint64 sp_isqrt64(uint64 v)
{
  uint64 r = 0, b = (uint64)1 << 62;

  while(b > v)
    b >>= 2;

  while(b)
  {
    if(v >= r + b)
    {
      v -= r + b;
      r = (r >> 1) + b;
    }
    else
      r >>= 1;

    b >>= 2;
  }

  return(r);
}

//THD in hundredths of a percent of the fundamental at bin k: three bins around it against three bins around each of
//harmonics 2..10 below bin last; SP_THD_F0_LOW / SP_THD_F0_HIGH when it cannot be measured
static int32 sp_thd(const int16 *cdb, uint32 last, uint32 k)
{
  uint64 p1 = 0, ph = 0, ratio;
  int32  ref;
  uint32 n, w, c, lo, hi, m, j;

  if(k < SP_THD_K_MIN)
    return(SP_THD_F0_LOW);

  //The three bins around the second harmonic must be on the axis
  if(2 * k + 1 > last)
    return(SP_THD_F0_HIGH);

  ref = cdb[k];

  for(j = k - 1; j <= k + 1; j++)
    p1 += sp_pow_q24(cdb[j] - ref);

  for(n = 2; n <= SP_THD_HARMONICS; n++)
  {
    c = n * k;

    if(c + 1 > last)
      break;

    //Search window: the peak bin may be off by half a bin, so harmonic n by n / 2; kept narrow enough that the summed
    //bins of neighbouring harmonics never overlap
    w = n / 2 + 1;

    if(w > (k - 3) / 2)
      w = (k - 3) / 2;

    lo = c - w;
    hi = c + w;

    if(hi + 1 > last)
      hi = last - 1;

    for(m = lo, j = lo; j <= hi; j++)
      if(cdb[j] > cdb[m])
        m = j;

    for(j = m - 1; j <= m + 1; j++)
      ph += sp_pow_q24(cdb[j] - ref);
  }

  ratio = (ph << 24) / p1;

  //sqrt of the Q24 ratio taken in Q40 -> Q20; percent in hundredths
  return((int32)((sp_isqrt64(ratio << 16) * 10000) >> 20));
}

//----------------------------------------------------------------------------------------------------------------------------------
//Drawing

//Grid step of the frequency axis in mHz: the smallest 1-2-5 step that gives at most 10 divisions over the span
static uint64 sp_freq_step(uint64 span_mhz)
{
  static const uint8 mult[3] = { 1, 2, 5 };
  uint64 base = 1;
  int    m;

  while(1)
  {
    for(m = 0; m < 3; m++)
    {
      if((mult[m] * base * 10) >= span_mhz)
        return(mult[m] * base);
    }

    base *= 10;
  }
}

//v1.00r0: dB labels as whole numbers on every division with the unit at the top one, frequency grid in 1-2-5 steps
static void sp_draw_grid(int log2n)
{
  char   t[24], *p;
  uint32 i;
  int32  x, y, db;
  uint64 span = ((uint64)sp_sample_rate() * 1000) / 2;     //0 .. fs/2 in mHz
  uint64 step = sp_freq_step(span);
  uint64 f;

  //v1.00r4: dotted grid as MCP (spec_draw_grid): the color follows the grid brightness setting (at least 0x30), dots
  //every 4 px on the horizontal lines and every 3 px on the vertical lines
  {
    uint32 c = (scopesettings.gridbrightness * 255) / 100;

    if(c < 0x30)
      c = 0x30;

    display_set_fg_color((c << 16) | (c << 8) | c);
  }

  for(i = 0; i <= SP_DIVS_Y; i++)
    display_draw_horz_dots(SP_Y0 + ((i * SP_H) / SP_DIVS_Y), SP_X0, SP_X1, 4);

  //Vertical lines at the multiples of the step, and the frame at the right end
  for(f = 0; f <= span; f += step)
    display_draw_vert_dots(SP_X0 + (uint32)((f * SP_W) / span), SP_Y0, SP_Y1, 3);

  display_draw_vert_dots(SP_X1, SP_Y0, SP_Y1, 3);

  display_set_fg_color(SP_TEXT_COLOR);
  display_set_font(&font_2);

  //dB labels left of every horizontal line, the top one with the unit
  for(i = 0; i <= SP_DIVS_Y; i++)
  {
    y  = SP_Y0 + ((i * SP_H) / SP_DIVS_Y) - 6;
    db = sp_ref_levels[sp.ref] - (int32)(i * sp_db_per_div[sp.dbdiv]);
    p  = t;

    if(db < 0)
    {
      *p++ = '-';
      db = -db;
    }
    else if((db > 0) && (i == 0))
    {
      *p++ = '+';
    }

    p = sp_uint(p, (uint32)db);

    if(i == 0)
      sp_str(p, " dBV");

    x = SP_X0 - 4 - sp_text_width(t);
    display_text((x < 4) ? 4 : x, (y < 49) ? 49 : y, (int8 *)t);
  }

  //Frequency labels under the vertical lines
  for(f = 0; f <= span; f += step)
  {
    sp_freq(t, f, 1);
    x = SP_X0 + (int32)((f * SP_W) / span) - (sp_text_width(t) / 2);

    if(x < 4)
      x = 4;
    else if((x + (int32)sp_text_width(t)) > 727)
      x = 727 - sp_text_width(t);

    display_text(x, SP_Y1 + 4, (int8 *)t);
  }

  (void)log2n;
}

//One channel's spectrum: per plot column the highest bin that falls in it, joined by lines
static void sp_draw_trace(int ch, int log2n, uint32 color)
{
  uint32 n2 = 1u << (log2n - 1);
  uint32 c, k, k0, k1;
  int32  v, y, prev_y = 0;

  display_set_fg_color(color);

  for(c = 0; c <= SP_W; c++)
  {
    k0 = (c * n2) / SP_W;
    k1 = ((c + 1) * n2) / SP_W;

    if(k1 <= k0)
      k1 = k0 + 1;

    if(k1 > (n2 + 1))
      k1 = n2 + 1;

    v = sp_cdb[ch][k0];

    for(k = k0 + 1; k < k1; k++)
    {
      if(sp_cdb[ch][k] > v)
        v = sp_cdb[ch][k];
    }

    y = sp_level_y(v);

    if(c)
      display_draw_line(SP_X0 + c - 1, prev_y, SP_X0 + c, y);

    prev_y = y;
  }
}

static int32 sp_noise_cdb(const int16 *cdb, uint32 first, uint32 last);

//v1.00r5: one readout in a rounded frame on text line 'line', x is its left edge; returns the x after it (with a gap)
static int32 sp_box_width(const char *t)
{
  return(sp_text_width(t) + 10);
}

static int32 sp_box(int32 x, int line, const char *t, uint32 color)
{
  int32 y = SP_TXT_Y + (line * SP_TXT_LINE);
  int32 w = sp_box_width(t);

  display_set_fg_color(SP_BOX_FILL);
  display_fill_rounded_rect(x, y - 1, w, 16, 3);
  display_set_fg_color(color);
  display_draw_rounded_rect(x, y - 1, w, 16, 3);
  display_set_font(&font_2);
  display_text(x + 5, y + 1, (int8 *)t);

  return(x + w + 4);
}

//Readouts of one channel on text line 'line' above the plot, from x bx (the ones chosen in MEASURES), each in a rounded frame in
//the channel color, and a marker at the peak
static int32 sp_draw_peak(int ch, int log2n, uint32 color, int line, int32 bx)
{
  char   t[32], *p;
  uint32 k = sp_peak(ch, log2n);
  uint32 n2 = 1u << (log2n - 1);
  int32  x = SP_X0 + ((k * SP_W) / n2);
  int32  y = sp_level_y(sp_cdb[ch][k]);
  PCHANNELSETTINGS s = sp_channel(ch);
  const char *unit = s->V_A ? " dBA" : " dBV";

  display_set_font(&font_2);

  if(sp.meas & (SP_MS_FREQ | SP_MS_LEVEL | SP_MS_THD | SP_MS_NOISE))
  {
    bx = sp_box(bx, line, (ch == SP_CH_2) ? "CH2" : "CH1", color);

    if(sp.meas & SP_MS_FREQ)
    {
      p = sp_str(t, "Peak ");
      sp_freq(p, sp_bin_mhz(k, log2n), 0);
      bx = sp_box(bx, line, t, color);
    }

    if(sp.meas & SP_MS_LEVEL)
    {
      p = sp_db(t, sp_cdb[ch][k]);
      sp_str(p, unit);
      bx = sp_box(bx, line, t, color);
    }

    //v1.00q8: THD of the peak as the fundamental
    if(sp.meas & SP_MS_THD)
    {
      int32 thd = sp_thd(sp_cdb[ch], n2, k);

      p = sp_str(t, "THD ");

      if(thd == SP_THD_F0_LOW)
        sp_str(p, "f0 too low");
      else if(thd == SP_THD_F0_HIGH)
        sp_str(p, "f0 too high");
      else
      {
        p = sp_fixed(p, thd / 100, thd % 100, 2, 0);
        sp_str(p, " %");
      }

      bx = sp_box(bx, line, t, color);
    }

    //v1.00r4: noise floor, the median of the bins above DC
    if(sp.meas & SP_MS_NOISE)
    {
      p = sp_str(t, "Noise ");
      p = sp_db(p, sp_noise_cdb(sp_cdb[ch], 3, n2));
      sp_str(p, unit);
      bx = sp_box(bx, line, t, color);
    }
  }

  //v1.00r3: a filled red triangle above the peak (was a small outline in the channel color), kept inside the plot
  {
    int32 i, tip = y - 2;

    if(tip < (SP_Y0 + 8))
      tip = SP_Y0 + 8;

    display_set_fg_color(RED_COLOR);

    for(i = 0; i <= 6; i++)
      display_draw_horz_line(tip - i, x - i, x + i);
  }

  //Where the next readout on this line can go
  return(bx);
}

//Points and resolution bandwidth in a grey frame, always shown; v1.00r9: first text line from the plot's left edge,
//returns the x after it
static int32 sp_draw_info(int log2n)
{
  char   t[64], *p;
  uint32 fs = sp_sample_rate();
  uint64 rbw_mhz = (((uint64)fs * fx_enbw_milli(sp.window)) >> log2n);   //fs / N * ENBW (milli-bins) in mHz

  p = sp_str(t, "N ");
  p = sp_uint(p, 1u << log2n);
  p = sp_str(p, "  RBW ");
  sp_freq(p, rbw_mhz, 1);

  display_set_font(&font_2);
  return(sp_box(SP_X0, 0, t, SP_TEXT_COLOR));
}

//v1.00r4: the frequency cursor (T CURSOR) and the level cursor (V CURSOR), one each. v1.00r5: each in its own color,
//with its readout in a frame of the same color on the second text line at the right: the cursor frequency with the
//level of the shown spectrum there, and the cursor level
static int32 sp_draw_cursors(int ch, int log2n, int line)
{
  char   tf[48], tl[24], *p;
  uint32 n2 = 1u << (log2n - 1);
  uint32 k;
  int32  top  = sp_ref_levels[sp.ref] * 100;
  int32  span = sp_db_per_div[sp.dbdiv] * 100 * SP_DIVS_Y;
  int32  x = SP_X0;             //v1.00r9: from the plot's left edge

  if(!sp.fcur_on && !sp.lcur_on)
    return(x);

  if(sp.fcur_on)
  {
    display_set_fg_color(SP_FCUR_COLOR);
    display_draw_vert_dashes(SP_X0 + sp.fcur, SP_Y0, SP_Y1, 3, 3);
  }

  if(sp.lcur_on)
  {
    display_set_fg_color(SP_LCUR_COLOR);
    display_draw_horz_dashes(SP_Y0 + sp.lcur, SP_X0, SP_X1, 3, 3);
  }

  display_set_font(&font_2);

  //v1.00r6: left aligned; v1.00r8: on its own text line under N / RBW
  if(sp.fcur_on)
  {
    k = ((uint32)sp.fcur * n2 + (SP_W / 2)) / SP_W;

    if(k > n2)
      k = n2;

    p = sp_str(tf, "F ");
    p = sp_freq(p, sp_bin_mhz(k, log2n), 0);

    if(ch >= 0)
    {
      p = sp_str(p, "  ");
      p = sp_db(p, sp_cdb[(ch == SP_CH_BOTH) ? SP_CH_1 : ch][k]);
      sp_str(p, " dBV");
    }

    x = sp_box(x, line, tf, SP_FCUR_COLOR);
  }

  if(sp.lcur_on)
  {
    p = sp_str(tl, "L ");
    p = sp_db(p, top - (((int32)sp.lcur * span) / SP_H));
    sp_str(p, " dBV");

    x = sp_box(x, line, tl, SP_LCUR_COLOR);
  }

  //Room between the cursor readouts and what follows on the line
  return(x + 8);
}

//----------------------------------------------------------------------------------------------------------------------------------

static void sp_draw_buttons(int active);

//v1.00s6: the scope and the spectrum view each keep their own time base and trigger settings. The spectrum's AUTO SET
//changes them (2 us/div probe, a rate for the harmonics, trigger at 50 %), which made the scope trace look compressed
//after switching back. Entering the view saves the scope's settings and puts back the view's last ones, leaving it does
//the opposite.
typedef struct
{
  uint8 valid;
  __typeof__(scopesettings.timeperdiv)                        timeperdiv;
  __typeof__(scopesettings.triggerchannel)                    triggerchannel;
  __typeof__(scopesettings.triggerverticalposition)           triggerverticalposition;
  __typeof__(scopesettings.channel1.triggerverticalposition)  ch1triggerverticalposition;
  __typeof__(scopesettings.channel2.triggerverticalposition)  ch2triggerverticalposition;
  __typeof__(scopesettings.triggerhorizontalposition)         triggerhorizontalposition;
} SP_MODESETTINGS;

static SP_MODESETTINGS sp_scope_settings;
static SP_MODESETTINGS sp_view_settings;

static void sp_mode_save(SP_MODESETTINGS *m)
{
  m->valid                      = 1;
  m->timeperdiv                 = scopesettings.timeperdiv;
  m->triggerchannel             = scopesettings.triggerchannel;
  m->triggerverticalposition    = scopesettings.triggerverticalposition;
  m->ch1triggerverticalposition = scopesettings.channel1.triggerverticalposition;
  m->ch2triggerverticalposition = scopesettings.channel2.triggerverticalposition;
  m->triggerhorizontalposition  = scopesettings.triggerhorizontalposition;
}

static void sp_mode_restore(const SP_MODESETTINGS *m)
{
  if(!m->valid)
    return;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Time base first (it also sets the sample rate and the long time base mode). v1.00u5: with the scope "running" for
  //the call, so the sample rate reaches the FPGA also when stopped (scope_set_timebase writes it in RUN only)
  {
    __typeof__(scopesettings.runstate) run = scopesettings.runstate;

    scopesettings.timeperdiv = m->timeperdiv;
    scopesettings.runstate   = 1;
    scope_set_timebase();
    scopesettings.runstate   = run;
  }

  //Trigger channel and level
  scopesettings.triggerchannel                    = m->triggerchannel;
  scopesettings.triggerverticalposition           = m->triggerverticalposition;
  scopesettings.channel1.triggerverticalposition  = m->ch1triggerverticalposition;
  scopesettings.channel2.triggerverticalposition  = m->ch2triggerverticalposition;
  scopesettings.triggerhorizontalposition         = m->triggerhorizontalposition;

  fpga_set_trigger_channel();
  fpga_set_trigger_level();

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_trigger_settings(0);
}

void spectrum_set_active(int on)
{
  spectrum_autoset_cancel();

  //v1.00s6: swap the time base and trigger settings between the scope and the view
  if(on && !sp.active)
  {
    sp_mode_save(&sp_scope_settings);
    sp_mode_restore(&sp_view_settings);

    //v1.00v5: no roll mode (long time base) in this view. Coming from the scope in roll mode the view starts at 1 ms/div
    if(scopesettings.long_mode)
    {
      __typeof__(scopesettings.runstate) run = scopesettings.runstate;

      display_set_screen_buffer((uint16 *)maindisplaybuffer);
      scopesettings.timeperdiv = 18;
      scopesettings.runstate   = 1;
      scope_set_timebase();
      scopesettings.runstate   = run;
    }
  }
  else if(!on && sp.active)
  {
    sp_mode_save(&sp_view_settings);

    //v1.00v5: off before the scope's time base is put back, scope_set_timebase keeps this view out of the long time base
    sp.active = 0;
    sp_mode_restore(&sp_scope_settings);
  }

  sp.active     = on ? 1 : 0;
  sp.note_shown = 0;

  //Start the averaging again when the view opens
  sp_navg[0] = sp_navg[1] = 0;

  //v1.00y5: Move grey while the view is active, normal again after it
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_move_speed(0);
}

//v1.00z4: power off in this view: the scope's time base and trigger saved on the view's entry back in scopesettings
//(RAM only, no FPGA, no screen) for the settings sector
void spectrum_settings_for_save(void)
{
  if(!sp.active || !sp_scope_settings.valid)
    return;

  scopesettings.timeperdiv = sp_scope_settings.timeperdiv;
  scopesettings.samplerate = time_per_div_sample_rate[scopesettings.timeperdiv];
  scopesettings.long_mode  = (scopesettings.timeperdiv < 11) ? 1 : 0;

  scopesettings.triggerchannel                   = sp_scope_settings.triggerchannel;
  scopesettings.triggerverticalposition          = sp_scope_settings.triggerverticalposition;
  scopesettings.channel1.triggerverticalposition = sp_scope_settings.ch1triggerverticalposition;
  scopesettings.channel2.triggerverticalposition = sp_scope_settings.ch2triggerverticalposition;
  scopesettings.triggerhorizontalposition        = sp_scope_settings.triggerhorizontalposition;
}

int spectrum_is_active(void)
{
  return(sp.active);
}

static void sp_auto_step(void);

static void sp_draw_refs(int log2n);     //v1.00y3

void spectrum_display(void)
{
  int log2n = sp_log2n();
  int ch    = sp_fix_channel();
  int cursors = sp.fcur_on || sp.lcur_on;
  int chrows  = ((ch < 0) || !(sp.meas & SP_MS_CHANNEL)) ? 0 : (ch == SP_CH_BOTH) ? 2 : 1;
  int rows    = 1 + (cursors ? 1 : 0);

  //v1.00r9: two columns of text lines above the plot: left N / RBW and the cursors (when on), right CH1 and CH2
  if(chrows > rows)
    rows = chrows;

  sp_y0 = SP_TXT_Y + (rows * SP_TXT_LINE) + 2;

  if(sp.lcur > SP_H)
    sp.lcur = SP_H;

  sp.note_shown = 0;

  //Draw in a separate buffer to avoid flicker
  display_set_screen_buffer(displaybuffertmp);

  //Clear the trace portion of the screen
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(2, 48, 728, 432);

  sp_draw_grid(log2n);

  //v1.00y3: shown reference spectra under the live traces
  sp_draw_refs(log2n);

  if(ch < 0)
  {
    display_set_fg_color(WHITE_COLOR);
    display_set_font(&font_3);
    display_text(SP_X0 + 200, SP_Y0 + 160, (int8 *)((sp.channel == SP_CH_2) ? "CH2 is off" : (sp.channel == SP_CH_1) ? "CH1 is off" : "Both channels are off"));
  }
  else
  {
    //Channel 2 first so channel 1 is on top when both are shown
    if((ch == SP_CH_2) || (ch == SP_CH_BOTH))
    {
      sp_compute(SP_CH_2, log2n);
      sp_draw_trace(SP_CH_2, log2n, CHANNEL2_COLOR);
    }

    if((ch == SP_CH_1) || (ch == SP_CH_BOTH))
    {
      sp_compute(SP_CH_1, log2n);
      sp_draw_trace(SP_CH_1, log2n, CHANNEL1_COLOR);
    }
  }

  //v1.00r9: left column from the plot's left edge: N / RBW on the first line, the cursors on the second. Right column:
  //CH1 on the first line, CH2 on the second (CH2 alone on the first). v1.00s0: the right column at a fixed x (where it
  //was with the 10 kHz grid line at 50 kSa/s), no longer following the grid; only moved right when the left column is
  //wider
  {
    int32 lx = SP_X0, cx, rx;

    if(ch >= 0)
      lx = sp_draw_info(log2n);

    cx = sp_draw_cursors(ch, log2n, 1);

    if(cx > lx)
      lx = cx;

    rx = ((lx + 8) > SP_CH_COL_X) ? (lx + 8) : SP_CH_COL_X;

    if((ch == SP_CH_1) || (ch == SP_CH_BOTH))
      sp_draw_peak(SP_CH_1, log2n, CHANNEL1_COLOR, 0, rx);

    if(ch == SP_CH_2)
      sp_draw_peak(SP_CH_2, log2n, CHANNEL2_COLOR, 0, rx);
    else if(ch == SP_CH_BOTH)
      sp_draw_peak(SP_CH_2, log2n, CHANNEL2_COLOR, 1, rx);
  }

  //v1.00q8: the settings buttons under the plot
  sp_draw_buttons(-1);

  //Copy it to the actual screen buffer
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(2, 48, 728, 432);

  //v1.00r1: a running auto set takes its next step on each new record
  sp_auto_step();
}

void spectrum_long_mode_note(void)
{
  //Drawn once, the long time base mode itself draws nothing while the view is active
  if(sp.note_shown)
    return;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(2, 48, 728, 432);

  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(160, 220, (int8 *)"Spectrum analyser: select a shorter time base");
  display_text(160, 244, (int8 *)"(the long time base mode has no record to analyse)");

  sp.note_shown = 1;
}

//----------------------------------------------------------------------------------------------------------------------------------
//Settings buttons under the plot and their lists (v1.00q8)

//Number of values in a button's list (0: an action without a list)
static int sp_option_count(int b)
{
  switch(b)
  {
    case SP_BTN_CHANNEL: return(3);
    case SP_BTN_FFT:     return(SP_LOG2_MAX - SP_LOG2_MIN + 1);
    case SP_BTN_WINDOW:  return(FX_WIN_COUNT);
    case SP_BTN_AVERAGE: return(SP_AVG_COUNT);
    case SP_BTN_SCALE:   return(SP_DBDIV_COUNT);
    case SP_BTN_REF:     return(SP_REF_COUNT);
    default:             return(0);
  }
}

//The chosen value's index in a button's list
static int sp_option_current(int b)
{
  switch(b)
  {
    case SP_BTN_CHANNEL: return(sp.channel);
    case SP_BTN_FFT:     return(sp.log2n - SP_LOG2_MIN);
    case SP_BTN_WINDOW:  return(sp.window);
    case SP_BTN_AVERAGE: return(sp.avg);
    case SP_BTN_SCALE:   return(sp.dbdiv);
    case SP_BTN_REF:     return(sp.ref);
    default:             return(-1);
  }
}

static void sp_ref_text(char *t, int i)
{
  char *p = t;

  if(sp_ref_levels[i] > 0)
    p = sp_str(p, "+");

  p = sp_db(p, sp_ref_levels[i] * 100);
  sp_str(p, " dBV");
}

//Text of value i of a button's list
static void sp_option_text(int b, int i, char *t)
{
  char *p;

  switch(b)
  {
    case SP_BTN_CHANNEL: sp_str(t, (const char *)sp_channel_names[i]); break;
    case SP_BTN_FFT:     sp_uint(t, 1u << (SP_LOG2_MIN + i)); break;
    case SP_BTN_WINDOW:  sp_str(t, (const char *)sp_window_names[i]); break;
    case SP_BTN_AVERAGE: sp_str(t, (const char *)sp_avg_names[i]); break;
    case SP_BTN_SCALE:   p = sp_uint(t, sp_db_per_div[i]); sp_str(p, " dB/div"); break;
    case SP_BTN_REF:     sp_ref_text(t, i); break;
    default:             t[0] = 0; break;
  }
}

//Value shown on a button: the chosen one (FFT points: the ones used when the record is shorter)
static void sp_button_value(int b, char *t)
{
  if(b == SP_BTN_FFT)
    sp_uint(t, 1u << sp_log2n());
  else if(b == SP_BTN_RESET)
    sp_str(t, "Defaults");
  else
    sp_option_text(b, sp_option_current(b), t);
}

//Restart the averaging with the current record after a change
static void sp_settings_changed(void)
{
  sp_navg[0] = sp_navg[1] = 0;
  sp.fresh = 3;
}

static void sp_option_set(int b, int i)
{
  switch(b)
  {
    case SP_BTN_CHANNEL: sp.channel = i; break;
    case SP_BTN_FFT:     sp.log2n   = SP_LOG2_MIN + i; break;
    case SP_BTN_WINDOW:  sp.window  = i; break;
    case SP_BTN_AVERAGE: sp.avg     = i; break;
    case SP_BTN_SCALE:   sp.dbdiv   = i; break;
    case SP_BTN_REF:     sp.ref     = i; break;
  }

  sp_settings_changed();
}

static void sp_reset(void)
{
  SPECTRUMSTATE d = SP_DEFAULTS;

  d.active     = sp.active;
  d.note_shown = sp.note_shown;
  d.meas       = sp.meas;
  d.fcur       = sp.fcur;
  d.lcur       = sp.lcur;
  d.fcur_on    = sp.fcur_on;
  d.lcur_on    = sp.lcur_on;
  sp = d;

  sp_settings_changed();
}

//One button: its name small on top, its value below (active: highlighted while its list is open)
static void sp_draw_button(int b, int active)
{
  char   t[24];
  uint32 x = SP_BTN_X0 + (b * SP_BTN_PITCH);

  display_set_fg_color(active ? ITEM_ACTIVE_COLOR : DARKGREY_COLOR);
  display_fill_rounded_rect(x, SP_BTN_Y, SP_BTN_W, SP_BTN_H, 3);
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(x, SP_BTN_Y, SP_BTN_W, SP_BTN_H, 3);

  //v1.00v7: grey text on the buttons that do nothing while a saved spectrum is shown (only Channel, Scale, Ref level)
  int off = sp_viewing && (b != SP_BTN_CHANNEL) && (b != SP_BTN_SCALE) && (b != SP_BTN_REF);

  display_set_font(&font_2);
  display_set_fg_color(active ? BLACK_COLOR : off ? 0x00606060 : SP_TEXT_COLOR);
  display_text(x + ((SP_BTN_W - sp_text_width((const char *)sp_btn_names[b])) / 2), SP_BTN_Y + 3, (int8 *)sp_btn_names[b]);

  sp_button_value(b, t);
  display_set_font(&font_3);
  display_set_fg_color(active ? BLACK_COLOR : off ? 0x00707070 : WHITE_COLOR);
  display_text(x + ((SP_BTN_W - sp_text_width(t)) / 2), SP_BTN_Y + 19, (int8 *)t);
}

//All buttons, one of them active (-1 none), in the current screen buffer
static void sp_draw_buttons(int active)
{
  int b;

  for(b = 0; b < SP_BTN_COUNT; b++)
    sp_draw_button(b, b == active);
}

//Geometry of a button's list: above the button, kept on the trace area
static void sp_list_rect(int b, uint32 *x, uint32 *y, uint32 *h)
{
  uint32 bx = SP_BTN_X0 + (b * SP_BTN_PITCH);

  *h = sp_option_count(b) * SP_LIST_ROW_H;
  *y = SP_BTN_Y - 4 - *h;
  *x = ((bx + SP_LIST_W) > 728) ? (728 - SP_LIST_W) : bx;
}

static void sp_draw_list(int b, int touched)
{
  char   t[24];
  uint32 x, y, h;
  int    i, n = sp_option_count(b), cur = sp_option_current(b);

  sp_list_rect(b, &x, &y, &h);

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(x, y, SP_LIST_W, h);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rect(x, y, SP_LIST_W, h);

  display_set_font(&font_3);

  for(i = 0; i < n; i++)
  {
    uint32 ry = y + (i * SP_LIST_ROW_H);

    if(i == touched)
    {
      display_set_fg_color(ITEM_ACTIVE_COLOR);
      display_fill_rect(x + 1, ry + 1, SP_LIST_W - 2, SP_LIST_ROW_H - 2);
    }

    //Separator between the values
    if(i)
    {
      display_set_fg_color(BLACK_COLOR);
      display_draw_horz_line(ry, x + 6, x + SP_LIST_W - 6);
    }

    sp_option_text(b, i, t);
    display_set_fg_color((i == touched) ? BLACK_COLOR : (i == cur) ? CHANNEL1_COLOR : WHITE_COLOR);
    //Centred in the row (v1.00q9, the list is only a button wide)
    display_text(x + ((SP_LIST_W - sp_text_width(t)) / 2), ry + 7, (int8 *)t);
  }
}

static void sp_auto_record(void);

void spectrum_new_record(void)
{
  sp.fresh = 3;

  //v1.00r1: the auto set counts the records
  sp_auto_record();
}

void spectrum_handle_touch(void)
{
  int    b = -1, i;
  uint32 x, y, h;

  //v1.00r1: any touch in the view ends a running auto set
  spectrum_autoset_cancel();

  //Only the buttons under the plot react
  if((ytouch >= SP_BTN_Y) && (ytouch <= (SP_BTN_Y + SP_BTN_H)) && (xtouch >= SP_BTN_X0))
  {
    b = (xtouch - SP_BTN_X0) / SP_BTN_PITCH;

    if((b >= SP_BTN_COUNT) || (((xtouch - SP_BTN_X0) % SP_BTN_PITCH) > SP_BTN_W))
      b = -1;

    //v1.00v3: a saved spectrum: only Channel, Scale and Ref level (the others need a new FFT)
    if(sp_viewing && (b != SP_BTN_CHANNEL) && (b != SP_BTN_SCALE) && (b != SP_BTN_REF))
      b = -1;
  }

  //v1.00r4: a touch in the plot with a cursor on drags the nearer cursor (the frequency cursor left / right, the level
  //cursor up / down) until the touch ends
  if((b < 0) && (sp.fcur_on || sp.lcur_on) &&
     (xtouch >= SP_X0) && (xtouch <= SP_X1) && (ytouch >= SP_Y0) && (ytouch <= SP_Y1))
  {
    int32 dx = (int32)xtouch - (SP_X0 + sp.fcur);
    int32 dy = (int32)ytouch - (SP_Y0 + sp.lcur);
    int   freq;

    if(dx < 0) dx = -dx;
    if(dy < 0) dy = -dy;

    freq = sp.fcur_on && (!sp.lcur_on || (dx <= dy));

    while(havetouch)
    {
      int32 v;

      if(freq)
      {
        v = (int32)xtouch - SP_X0;
        sp.fcur = (v < 0) ? 0 : (v > SP_W) ? SP_W : v;
      }
      else
      {
        v = (int32)ytouch - SP_Y0;
        sp.lcur = (v < 0) ? 0 : (v > SP_H) ? SP_H : v;
      }

      if(!scopesettings.long_mode)
        spectrum_display();

      tp_i2c_read_status();
    }

    return;
  }

  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  if(b >= 0)
    sp_draw_button(b, 1);

  //Wait until touch is released
  tp_i2c_wait_for_touch_release();

  if(b < 0)
    return;

  //Reset acts at once
  if(b == SP_BTN_RESET)
  {
    sp_reset();
  }
  else
  {
    //First touch: the list of values above the button; second touch: a value is chosen and the list closes, a touch
    //outside the list closes it without a change
    sp_draw_list(b, -1);
    sp_list_rect(b, &x, &y, &h);

    while(1)
    {
      tp_i2c_read_status();

      if(havetouch)
      {
        if((xtouch >= x) && (xtouch < (x + SP_LIST_W)) && (ytouch >= y) && (ytouch < (y + h)))
        {
          i = (ytouch - y) / SP_LIST_ROW_H;

          sp_draw_list(b, i);
          tp_i2c_wait_for_touch_release();
          sp_option_set(b, i);
        }
        else
        {
          tp_i2c_wait_for_touch_release();
        }

        break;
      }
    }
  }

  //Redraw the view with the new setting (also when stopped); covers the list
  if(!scopesettings.long_mode)
    spectrum_display();
  else
  {
    sp.note_shown = 0;
    spectrum_long_mode_note();
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//Auto set in the spectrum view (v1.00r2), after the MCP firmware's spectrum Auto (spec_auto_*). It sets only spectrum
//things and never the volts per division (no relay clicks, as MCP):
//  1. FFT points to the maximum, Hann window, average 4, trigger on the analysed channel.
//  2. Probe at 50 MSa/s (2 us/div); the first record sets the trigger level to 50 %. The fundamental f0 is measured on
//     the record (rising crossings with hysteresis, as MCP spec_f0_mhz); without three periods in the record the time
//     base goes 10x slower (three settings) and the next record is tried, down to the first short time base.
//  3. The slowest sample rate with fs >= 25 x f0, so 0 .. fs/2 shows the fundamental and about 12 harmonics.
//  4. After four records at that rate (the average settled): Ref level and Scale from the peak and the noise floor (as
//     MCP spec_auto_finish: Ref just above the peak, dB/div from the peak to floor range).
//It is not started when stopped or in single mode, any touch in the view ends it, and after 4 s (MCP AUTO_TIMEOUT_MS)
//the search goes on with what it has (v1.00r3: the levels still come from records at the final rate).

#define SP_AUTO_OFF         0
#define SP_AUTO_PROBE       1           //looking for f0, 10x slower per try
#define SP_AUTO_LEVELS      2           //records at the chosen sample rate
#define SP_AUTO_LEVEL_REC   4
#define SP_AUTO_FS_PER_F0   25
#define SP_AUTO_TIMEOUT_MS  4000
#define SP_AUTO_TB_PROBE    26          //2 us/div, 50 MSa/s (MCP TB_FULL_AXIS)
#define SP_SHORT_TB_FIRST   11          //first short time base setting (time_per_div_sample_rate)
#define SP_SHORT_TB_LAST    34
#define SP_SHORT_RATE_LAST  17          //slowest short time base sample rate (sample_rate index)

static uint8  sp_auto_stage = SP_AUTO_OFF;
static uint8  sp_auto_count;
static uint8  sp_auto_new;
static uint8  sp_auto_ch;
static uint8  sp_auto_trig_done;
static uint32 sp_auto_t0;
static uint64 sp_auto_f0;

void spectrum_autoset_cancel(void)
{
  sp_auto_stage = SP_AUTO_OFF;
}

//Fundamental of the record in mHz, 0 when there are fewer than three periods or too little signal
static uint64 sp_auto_f0_mhz(int ch)
{
  PCHANNELSETTINGS s = sp_channel(ch);
  uint32 n = fpgasettings.totalsamples, i, first = 0, last = 0, rises = 0, min = 255, max = 0, hi, lo, v;
  int    state;

  for(i = 0; i < n; i++)
  {
    v = s->tracebuffer[i];

    if(v < min) min = v;
    if(v > max) max = v;
  }

  //Less than 10 codes peak to peak: no usable signal
  if((max - min) < 10)
    return(0);

  //Hysteresis between one and two thirds of the range
  lo = min + ((max - min) / 3);
  hi = min + ((2 * (max - min)) / 3);
  state = (s->tracebuffer[0] > hi) ? 1 : 0;

  for(i = 1; i < n; i++)
  {
    v = s->tracebuffer[i];

    if(!state && (v > hi))
    {
      state = 1;

      if(!rises)
        first = i;

      last = i;
      rises++;
    }
    else if(state && (v < lo))
      state = 0;
  }

  if((rises < 3) || (last <= first))
    return(0);

  return(((uint64)sp_sample_rate() * 1000 * (rises - 1)) / (last - first));
}

//Switch to a short time base setting (only the time base, the volts per division stay)
static void sp_auto_set_timebase(int t)
{
  if((t < SP_SHORT_TB_FIRST) || (t > SP_SHORT_TB_LAST) || (t == scopesettings.timeperdiv))
    return;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scopesettings.timeperdiv = t;
  scope_set_timebase();
}

//Switch to the short time base setting whose sample rate fits f0 (fs >= 25 x f0, the slowest that does)
static void sp_auto_set_rate(uint64 f0_mhz)
{
  int    rate = 0, t;
  uint64 need = f0_mhz * SP_AUTO_FS_PER_F0;

  for(t = SP_SHORT_RATE_LAST; t >= 0; t--)
  {
    if(((uint64)sample_rate[t] * 1000) >= need)
    {
      rate = t;
      break;
    }
  }

  //The first short time base setting that uses this sample rate
  for(t = SP_SHORT_TB_FIRST; t <= SP_SHORT_TB_LAST; t++)
  {
    if(time_per_div_sample_rate[t] == rate)
      break;
  }

  sp_auto_set_timebase(t);
}

//Median level of bins first..last in centi-dBV (0.1 dB histogram from -200 to +60 dB), as MCP ui_ms_noise_cdb
static int32 sp_noise_cdb(const int16 *cdb, uint32 first, uint32 last)
{
  static uint16 hist[2601];
  uint32 k, n = 0, cum = 0, i;
  int32  v;

  for(i = 0; i < 2601; i++)
    hist[i] = 0;

  for(k = first; k <= last; k++)
  {
    v = cdb[k];

    if(v < -20000) v = -20000;
    if(v > 6000)   v = 6000;

    hist[(v + 20000) / 10]++;
    n++;
  }

  if(!n)
    return(-20000);

  for(i = 0; i < 2600; i++)
  {
    cum += hist[i];

    if((2 * cum) >= (n + 1))
      break;
  }

  return(((int32)i * 10) - 20000);
}

//Ref level and Scale from the peak P and the noise floor F of the analysed channel
static void sp_auto_levels(int ch)
{
  int    log2n = sp_log2n();
  uint32 n2 = 1u << (log2n - 1);
  uint32 k = sp_peak(ch, log2n);
  int32  P = sp_cdb[ch][k];
  int32  F = sp_noise_cdb(sp_cdb[ch], 3, n2);
  int32  range = P - F + 1000;
  int32  top = P + 300;
  int    i;

  //dB per division: the range from just above the peak to below the floor fits the 8 divisions
  sp.dbdiv = (range <= (8 * 500)) ? 0 : (range <= (8 * 1000)) ? 1 : 2;

  //Ref: the lowest level in the list that is still above the peak (+20 dBV when the peak is higher)
  sp.ref = 0;

  for(i = SP_REF_COUNT - 1; i >= 0; i--)
  {
    if((sp_ref_levels[i] * 100) >= top)
    {
      sp.ref = i;
      break;
    }
  }
}

void spectrum_autoset(void)
{
  int ch;

  sp_auto_stage = SP_AUTO_OFF;

  //Not when stopped or in single mode (as MCP), and not in the long time base mode (no record)
  if(!scopesettings.runstate || (scopesettings.triggermode == 1) || scopesettings.long_mode)
    return;

  //The analysed channel: CH2 when chosen or when CH1 is off
  ch = ((sp.channel == SP_CH_2) || !scopesettings.channel1.enable) ? SP_CH_2 : SP_CH_1;

  if(!sp_channel(ch)->enable)
    return;

  sp.log2n  = SP_LOG2_MAX;
  sp.window = FX_WIN_HANN;
  sp.avg    = 1;
  sp_settings_changed();

  //Trigger on the analysed channel
  scopesettings.triggerchannel = (ch == SP_CH_2) ? 1 : 0;
  fpga_set_trigger_channel();
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_trigger_settings(0);

  //Probe at 50 MSa/s
  sp_auto_set_timebase(SP_AUTO_TB_PROBE);

  sp_auto_ch        = ch;
  sp_auto_count     = 0;
  sp_auto_new       = 0;
  sp_auto_trig_done = 0;
  sp_auto_f0        = 0;
  sp_auto_t0        = timer0_get_ticks();
  sp_auto_stage     = SP_AUTO_PROBE;
}

//Mark a new record for the auto set (called from spectrum_new_record)
static void sp_auto_record(void)
{
  if(sp_auto_stage != SP_AUTO_OFF)
    sp_auto_new = 1;
}

//The rate from f0 (when found) and then the levels after the average settled
static void sp_auto_go(void)
{
  if(sp_auto_f0)
    sp_auto_set_rate(sp_auto_f0);

  sp_settings_changed();
  sp_auto_count = 0;
  sp_auto_stage = SP_AUTO_LEVELS;
}

static void sp_auto_step(void)
{
  if((sp_auto_stage == SP_AUTO_OFF) || !sp_auto_new)
    return;

  sp_auto_new = 0;
  sp_auto_count++;

  //Time-out of the search (v1.00r3): go on with what is there (the rate of a found f0, else the current one). The levels
  //are always taken from records at the final rate (stage SP_AUTO_LEVELS), never from a probe record: a probe at a fast
  //rate does not show a low frequency signal and gave a much too low Ref level (-40 dBV with the peak off the plot).
  if((sp_auto_stage == SP_AUTO_PROBE) && ((timer0_get_ticks() - sp_auto_t0) > SP_AUTO_TIMEOUT_MS))
  {
    sp_auto_go();
    return;
  }

  switch(sp_auto_stage)
  {
    case SP_AUTO_PROBE:
      //First record of the probe: the trigger level to the middle of the signal (no relays involved)
      if(!sp_auto_trig_done)
      {
        sp_auto_trig_done = 1;
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        scope_do_50_percent_trigger_setup();
        scope_trigger_settings(0);
        sp_auto_count = 0;
        return;
      }

      //The first record after a time base change may still be at the previous rate
      if(sp_auto_count < 2)
        return;

      sp_auto_f0 = sp_auto_f0_mhz(sp_auto_ch);

      //No three periods in the record: 10x slower, as long as there is a short time base for it
      if(!sp_auto_f0 && ((scopesettings.timeperdiv - 3) >= SP_SHORT_TB_FIRST))
      {
        sp_auto_set_timebase(scopesettings.timeperdiv - 3);
        sp_auto_count = 0;
        return;
      }

      sp_auto_go();
      break;

    case SP_AUTO_LEVELS:
      //The first record after the rate change may still be at the previous rate: start the average again without it
      if(sp_auto_count == 1)
      {
        sp_settings_changed();
        return;
      }

      if(sp_auto_count < (1 + SP_AUTO_LEVEL_REC))
        return;

      sp_auto_levels(sp_auto_ch);
      sp_auto_stage = SP_AUTO_OFF;
      break;
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//MEASURES in the spectrum view (v1.00r4): which readouts the text lines above the plot show. A tap on a row switches it,
//a tap outside the menu closes it.

#define SP_MSM_X          528
#define SP_MSM_Y          236
#define SP_MSM_W          200
#define SP_MSM_TITLE_H    32
#define SP_MSM_ROW_H      40
#define SP_MSM_H          (SP_MSM_TITLE_H + (SP_MS_COUNT * SP_MSM_ROW_H))

static const int8 *sp_ms_names[SP_MS_COUNT] = { "Peak frequency", "Peak level", "THD", "Noise floor" };

static void sp_msm_row(int row)
{
  uint32 y = SP_MSM_Y + SP_MSM_TITLE_H + (row * SP_MSM_ROW_H);
  int    on = (sp.meas >> row) & 1;

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(SP_MSM_X + 1, y, SP_MSM_W - 2, SP_MSM_ROW_H - 1);

  //Check box
  display_set_fg_color(on ? CHANNEL1_COLOR : GREY_COLOR);
  display_draw_rect(SP_MSM_X + 12, y + 11, 18, 18);

  if(on)
    display_fill_rect(SP_MSM_X + 16, y + 15, 11, 11);

  display_set_fg_color(on ? WHITE_COLOR : SP_TEXT_COLOR);
  display_set_font(&font_3);
  display_text(SP_MSM_X + 42, y + 12, (int8 *)sp_ms_names[row]);

  if(row < (SP_MS_COUNT - 1))
  {
    display_set_fg_color(BLACK_COLOR);
    display_draw_horz_line(y + SP_MSM_ROW_H - 1, SP_MSM_X + 8, SP_MSM_X + SP_MSM_W - 8);
  }
}

void spectrum_open_measures_menu(void)
{
  int row;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(SP_MSM_X, SP_MSM_Y, SP_MSM_W, SP_MSM_H);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rect(SP_MSM_X, SP_MSM_Y, SP_MSM_W, SP_MSM_H);

  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(SP_MSM_X + 12, SP_MSM_Y + 8, (int8 *)"Spectrum measures");
  display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(SP_MSM_Y + SP_MSM_TITLE_H - 1, SP_MSM_X + 8, SP_MSM_X + SP_MSM_W - 8);

  for(row = 0; row < SP_MS_COUNT; row++)
    sp_msm_row(row);

  while(1)
  {
    tp_i2c_read_status();

    if(havetouch)
    {
      if((xtouch >= SP_MSM_X) && (xtouch < (SP_MSM_X + SP_MSM_W)) && (ytouch >= (SP_MSM_Y + SP_MSM_TITLE_H)) && (ytouch < (SP_MSM_Y + SP_MSM_H)))
      {
        row = (ytouch - SP_MSM_Y - SP_MSM_TITLE_H) / SP_MSM_ROW_H;
        sp.meas ^= (1 << row);
        sp_msm_row(row);
        tp_i2c_wait_for_touch_release();
      }
      else if((xtouch >= SP_MSM_X) && (xtouch < (SP_MSM_X + SP_MSM_W)) && (ytouch >= SP_MSM_Y) && (ytouch < (SP_MSM_Y + SP_MSM_H)))
      {
        //The title: nothing
        tp_i2c_wait_for_touch_release();
      }
      else
      {
        tp_i2c_wait_for_touch_release();
        break;
      }
    }
  }

  //Closed: the view covers the menu area again
  if(!scopesettings.long_mode)
    spectrum_display();
}

//v1.00r8: the F CURSOR (0) and L CURSOR (1) buttons in the spectrum view switch the view's own cursors
void spectrum_toggle_cursor(int level)
{
  if(level)
    sp.lcur_on ^= 1;
  else
    sp.fcur_on ^= 1;
}

//v1.00t1: 20 log10 of the volts per ADC code of a channel in centi-dB (used by the frequency response view)
int32 spectrum_channel_volts_cdb(PCHANNELSETTINGS s)
{
  return(sp_gain_cdb(s));
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00v3: SAVE SPEC: the shown spectra (after averaging) as a file in \spectrum\ (shown again in Saved waveforms while
//this view is active), a thumbnail for the list, and a CSV next to it when switched on

#define SP_FILE_MAGIC     0x31435053u     //"SPC1"

typedef struct
{
  uint32 magic;
  uint32 fs;
  uint8  log2n, channel, window, ref, dbdiv, avg, meas, en1, en2, va1, va2, nu;
} SPECTRUMFILEHEADER;

uint32 spectrum_file_write(FIL *fp)
{
  SPECTRUMFILEHEADER h;
  uint32 result;

  h.magic   = SP_FILE_MAGIC;
  h.fs      = sp_sample_rate();
  h.log2n   = sp_log2n();
  h.channel = sp.channel;
  h.window  = sp.window;
  h.ref     = sp.ref;
  h.dbdiv   = sp.dbdiv;
  h.avg     = sp.avg;
  h.meas    = sp.meas;
  h.en1     = scopesettings.channel1.enable;
  h.en2     = scopesettings.channel2.enable;
  h.va1     = scopesettings.channel1.V_A;
  h.va2     = scopesettings.channel2.V_A;
  h.nu      = 0;

  if((result = f_write(fp, &h, sizeof(h), 0)) != FR_OK)
    return(result);

  return(f_write(fp, sp_cdb, sizeof(sp_cdb), 0));
}

static uint32 spectrum_file_read(FIL *fp)
{
  SPECTRUMFILEHEADER h;
  uint32 result;

  if((result = f_read(fp, &h, sizeof(h), 0)) != FR_OK)
    return(result);

  if((h.magic != SP_FILE_MAGIC) || (h.log2n < SP_LOG2_MIN) || (h.log2n > SP_LOG2_MAX) || (h.fs == 0))
    return(FR_INT_ERR);

  if((result = f_read(fp, sp_cdb, sizeof(sp_cdb), 0)) != FR_OK)
    return(result);

  sp_view_fs    = h.fs;
  sp_view_log2n = h.log2n;
  sp_view_en1   = h.en1;
  sp_view_en2   = h.en2;
  sp.channel    = (h.channel <= SP_CH_BOTH) ? h.channel : SP_CH_1;
  sp.window     = (h.window < FX_WIN_COUNT) ? h.window : FX_WIN_HANN;
  sp.ref        = (h.ref < SP_REF_COUNT) ? h.ref : 2;
  sp.dbdiv      = (h.dbdiv < SP_DBDIV_COUNT) ? h.dbdiv : 1;
  sp.avg        = (h.avg < SP_AVG_COUNT) ? h.avg : 1;
  sp.meas       = h.meas;
  sp.log2n      = h.log2n;

  return(FR_OK);
}

//Frequency in Hz (three decimals) and the level of each shown channel in dBV (two decimals)
uint32 spectrum_csv_write(void)
{
  int    log2n = sp_log2n(), ch = sp_fix_channel();
  uint32 k, n2 = 1u << (log2n - 1);

  if(csv_open() != FR_OK)
    return(csv_close());

  csv_puts("Frequency_Hz");

  if((ch == SP_CH_1) || (ch == SP_CH_BOTH))
    csv_puts(scopesettings.channel1.V_A ? ",CH1_dBA" : ",CH1_dBV");

  if((ch == SP_CH_2) || (ch == SP_CH_BOTH))
    csv_puts(scopesettings.channel2.V_A ? ",CH2_dBA" : ",CH2_dBV");

  csv_puts("\r\n");

  for(k = 0; k <= n2; k++)
  {
    csv_putfixed((int64)sp_bin_mhz(k, log2n), 3);

    if((ch == SP_CH_1) || (ch == SP_CH_BOTH))
    {
      csv_puts(",");
      csv_putfixed(sp_cdb[SP_CH_1][k], 2);
    }

    if((ch == SP_CH_2) || (ch == SP_CH_BOTH))
    {
      csv_puts(",");
      csv_putfixed(sp_cdb[SP_CH_2][k], 2);
    }

    csv_puts("\r\n");
  }

  return(csv_close());
}

//The thumbnail: the shown spectra over the 166 columns (the highest bin of each column)
void spectrum_fill_thumbnail(PTHUMBNAILDATA td)
{
  int    log2n = sp_log2n(), ch = sp_fix_channel(), c;
  uint32 n2 = 1u << (log2n - 1), k, k0, k1;
  int32  v1, v2;

  td->channel1enable = (ch == SP_CH_1) || (ch == SP_CH_BOTH);
  td->channel2enable = (ch == SP_CH_2) || (ch == SP_CH_BOTH);
  td->xydisplaymode  = 3;
  td->long_mode      = 0;
  td->disp_xstart    = 3;
  td->disp_xend      = 169;
  td->channel1traceposition = td->channel2traceposition = td->triggerverticalposition = 0;
  td->triggerhorizontalposition = 3;
  td->triggerchannel = 0;

  for(c = 0; c <= 166; c++)
  {
    k0 = ((uint32)c * n2) / 167;
    k1 = ((uint32)(c + 1) * n2) / 167;

    if(k1 <= k0)
      k1 = k0 + 1;

    v1 = sp_cdb[SP_CH_1][k0];
    v2 = sp_cdb[SP_CH_2][k0];

    for(k = k0 + 1; (k < k1) && (k <= n2); k++)
    {
      if(sp_cdb[SP_CH_1][k] > v1) v1 = sp_cdb[SP_CH_1][k];
      if(sp_cdb[SP_CH_2][k] > v2) v2 = sp_cdb[SP_CH_2][k];
    }

    td->channel1data[c] = (uint8)(((sp_level_y(v1) - SP_Y0) * 92) / SP_H);
    td->channel2data[c] = (uint8)(((sp_level_y(v2) - SP_Y0) * 92) / SP_H);
  }
}

//Show the saved file viewcurrentindex points to, until the return button (top left) is touched
void spectrum_view_file(void)
{
  //The live settings and spectra are kept and put back after viewing
  static int16  cdb_save[2][(SP_N_MAX / 2) + 1];
  SPECTRUMSTATE st_save = sp;
  uint32        result;
  int32         action = SAVED_VIEW_LOAD;

  memcpy(cdb_save, sp_cdb, sizeof(sp_cdb));

  spectrum_autoset_cancel();

  //v1.00v7: one file after the other (Next / Prev / Delete on the right bar) until Return or no file is left
  while(action == SAVED_VIEW_LOAD)
  {
    scope_print_file_name(viewfilenumberdata[viewcurrentindex]);

    if(f_open(&viewfp, viewfilename, FA_READ) != FR_OK)
    {
      scope_display_file_status_message(MESSAGE_FILE_OPEN_FAILED, 0);
      break;
    }

    sp_viewing = 1;
    result = spectrum_file_read(&viewfp);
    f_close(&viewfp);

    if(result != FR_OK)
    {
      scope_display_file_status_message(MESSAGE_WAV_VERSION_MISMATCH, 0);
      break;
    }

    action = SAVED_VIEW_REDRAW;

    while(1)
    {
      //Screen: return button and the file name at the top, the right bar, the view below
      if(action == SAVED_VIEW_REDRAW)
      {
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        display_set_fg_color(BLACK_COLOR);
        display_fill_rect(0, 0, 800, 480);
        scope_main_return_button(0);

        display_set_font(&font_3);
        display_set_fg_color(WHITE_COLOR);
        display_text(130, 14, "Saved spectrum");
        display_set_fg_color(SP_TEXT_COLOR);
        scope_display_saved_file_name(300, 14);

        scope_saved_view_right_menu();
        action = SAVED_VIEW_NONE;
      }

      spectrum_display();
      tp_i2c_read_status();

      if(!havetouch)
        continue;

      //Return
      if((xtouch <= 80) && (ytouch <= 44))
      {
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        scope_main_return_button(1);
        tp_i2c_wait_for_touch_release();
        action = SAVED_VIEW_EXIT;
        break;
      }

      if(xtouch >= 730)
      {
        action = handle_saved_view_right_touch();

        if((action == SAVED_VIEW_LOAD) || (action == SAVED_VIEW_EXIT))
          break;

        if(action == SAVED_VIEW_TCURSOR)
          spectrum_toggle_cursor(0);
        else if(action == SAVED_VIEW_VCURSOR)
          spectrum_toggle_cursor(1);
        else if(action == SAVED_VIEW_MEASURES)
        {
          //The readouts of the saved spectrum (worked out from it again)
          spectrum_open_measures_menu();
          action = SAVED_VIEW_REDRAW;
        }
      }
      else if(ytouch >= 48)
        spectrum_handle_touch();
      else
        tp_i2c_wait_for_touch_release();
    }
  }

  //Back to the live view: settings, spectra, the averaging starts again
  sp_viewing = 0;
  sp = st_save;
  memcpy(sp_cdb, cdb_save, sizeof(sp_cdb));
  sp_navg[0] = sp_navg[1] = 0;
  sp.fresh = 3;
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00v4: the settings of the view in the settings sector (SPECTRUM_SETTING_OFFSET, 10 words), so they stay after power
//off: channel, window, Ref level, Scale, FFT points, Average, the readouts (MEASURES) and the two cursors' on / off

#define SP_SETTINGS_MAGIC   0x5EC7

void spectrum_settings_save(uint16 *ptr)
{
  ptr[0] = SP_SETTINGS_MAGIC;
  ptr[1] = sp.channel;
  ptr[2] = sp.window;
  ptr[3] = sp.ref;
  ptr[4] = sp.dbdiv;
  ptr[5] = sp.log2n;
  ptr[6] = sp.avg;
  ptr[7] = sp.meas;
  ptr[8] = sp.fcur_on;
  ptr[9] = sp.lcur_on;
}

void spectrum_settings_load(const uint16 *ptr)
{
  //Only words this firmware wrote, each within its range
  if(ptr[0] != SP_SETTINGS_MAGIC)
    return;

  if(ptr[1] <= SP_CH_BOTH)                                   sp.channel = ptr[1];
  if(ptr[2] < FX_WIN_COUNT)                                  sp.window  = ptr[2];
  if(ptr[3] < SP_REF_COUNT)                                  sp.ref     = ptr[3];
  if(ptr[4] < SP_DBDIV_COUNT)                                sp.dbdiv   = ptr[4];
  if((ptr[5] >= SP_LOG2_MIN) && (ptr[5] <= SP_LOG2_MAX))     sp.log2n   = ptr[5];
  if(ptr[6] < SP_AVG_COUNT)                                  sp.avg     = ptr[6];

  sp.meas    = ptr[7] & 0xFF;
  sp.fcur_on = ptr[8] ? 1 : 0;
  sp.lcur_on = ptr[9] ? 1 : 0;
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00y3: reference spectra (4 slots). REF in the menu of a shown channel opens the panel (ref_and_math.c
//view_ref_panel): Copy takes that channel's spectrum as shown (after averaging), Save / Load use \ref_spec\refN.spc in
//the .spc format of SAVE SPEC (the slot in the channel it came from; a saved .spc file copied there loads its shown
//channel). A shown reference is drawn under the live traces in its color, mapped to the current frequency axis (its
//own sample rate and points), so it stays right when the time base changes.

typedef struct
{
  uint8  valid;
  uint8  shown;
  uint8  ch;
  uint8  log2n;
  uint32 fs;
  int16  cdb[(SP_N_MAX / 2) + 1];
} SPECTRUMREF;

static SPECTRUMREF sp_ref[VIEW_REF_SLOTS];
static uint8       sp_ref_menu_ch = SP_CH_1;     //the channel whose menu opened the panel

static uint32 sp_ref_valid(int i)  { return(sp_ref[i].valid); }
static uint32 sp_ref_shown(int i)  { return(sp_ref[i].shown); }
static void   sp_ref_toggle(int i) { sp_ref[i].shown ^= 1; }
static void   sp_ref_clear(int i)  { sp_ref[i].valid = 0; sp_ref[i].shown = 0; }

static uint32 sp_ref_copy(int i)
{
  uint32 k;

  for(k = 0; k <= (SP_N_MAX / 2); k++)
    sp_ref[i].cdb[k] = sp_cdb[sp_ref_menu_ch][k];

  sp_ref[i].ch    = sp_ref_menu_ch;
  sp_ref[i].log2n = sp_log2n();
  sp_ref[i].fs    = sp_sample_rate();
  sp_ref[i].valid = 1;
  sp_ref[i].shown = 1;

  return(1);
}

//The .spc layout of spectrum_file_write: header, then the CH1 and the CH2 table; the slot in its channel, the other
//one filled with the bottom of the range
static uint32 sp_ref_write(FIL *fp, int i)
{
  static int16 floor_tab[(SP_N_MAX / 2) + 1];
  SPECTRUMFILEHEADER h;
  uint32 result, k;

  for(k = 0; k <= (SP_N_MAX / 2); k++)
    floor_tab[k] = -20000;

  h.magic   = SP_FILE_MAGIC;
  h.fs      = sp_ref[i].fs;
  h.log2n   = sp_ref[i].log2n;
  h.channel = sp_ref[i].ch;
  h.window  = sp.window;
  h.ref     = sp.ref;
  h.dbdiv   = sp.dbdiv;
  h.avg     = sp.avg;
  h.meas    = sp.meas;
  h.en1     = (sp_ref[i].ch == SP_CH_1);
  h.en2     = (sp_ref[i].ch == SP_CH_2);
  h.va1     = scopesettings.channel1.V_A;
  h.va2     = scopesettings.channel2.V_A;
  h.nu      = 0;

  if((result = f_write(fp, &h, sizeof(h), 0)) != FR_OK)
    return(result);

  if((result = f_write(fp, (sp_ref[i].ch == SP_CH_1) ? sp_ref[i].cdb : floor_tab, sizeof(floor_tab), 0)) != FR_OK)
    return(result);

  return(f_write(fp, (sp_ref[i].ch == SP_CH_2) ? sp_ref[i].cdb : floor_tab, sizeof(floor_tab), 0));
}

static uint32 sp_ref_read(FIL *fp, int i)
{
  SPECTRUMFILEHEADER h;
  uint32 result;
  uint8  ch;

  if((result = f_read(fp, &h, sizeof(h), 0)) != FR_OK)
    return(result);

  if((h.magic != SP_FILE_MAGIC) || (h.log2n < SP_LOG2_MIN) || (h.log2n > SP_LOG2_MAX) || (h.fs == 0))
    return(FR_INT_ERR);

  //The channel the file shows (both: CH1)
  ch = (h.channel == SP_CH_2) ? SP_CH_2 : SP_CH_1;

  if((result = f_read(fp, sp_ref[i].cdb, sizeof(sp_ref[i].cdb), 0)) != FR_OK)
    return(result);

  if((ch == SP_CH_2) && ((result = f_read(fp, sp_ref[i].cdb, sizeof(sp_ref[i].cdb), 0)) != FR_OK))
    return(result);

  sp_ref[i].ch    = ch;
  sp_ref[i].log2n = h.log2n;
  sp_ref[i].fs    = h.fs;
  sp_ref[i].valid = 1;
  sp_ref[i].shown = 1;

  return(FR_OK);
}

static const VIEWREFOPS sp_ref_ops =
{
  "\\ref_spec", ".spc", sp_ref_valid, sp_ref_shown, sp_ref_toggle, sp_ref_copy, sp_ref_write, sp_ref_read, sp_ref_clear
};

//The panel from the menu of channel ch (0 CH1, 1 CH2); only a shown channel has it
int spectrum_ref_channel_ok(int ch)
{
  return((sp.channel == SP_CH_BOTH) || (sp.channel == ch));
}

void spectrum_ref_panel(uint32 xpos, int ch)
{
  sp_ref_menu_ch = (ch == SP_CH_2) ? SP_CH_2 : SP_CH_1;
  view_ref_panel(xpos, &sp_ref_ops);
}

//One reference on the current axis: per plot column the highest reference bin inside the column's frequencies
static void sp_draw_ref(int r, int log2n)
{
  SPECTRUMREF *ref = &sp_ref[r];
  uint64 fs  = sp_sample_rate();
  uint32 n2  = 1u << (log2n - 1);
  uint32 rn2 = 1u << (ref->log2n - 1);
  uint32 c, k, k0, k1;
  int32  v, y, prev_y = 0, have = 0;

  if(!fs || !ref->fs)
    return;

  display_set_fg_color(view_ref_colors[r]);

  for(c = 0; c <= SP_W; c++)
  {
    //Bins of the current axis in this column, as frequencies in reference bins: k * fs / N * Nr / fsr
    k0 = (uint32)((((uint64)((c * n2) / SP_W)) * fs * (2 * rn2)) / ((uint64)(2 * n2) * ref->fs));
    k1 = (uint32)((((uint64)(((c + 1) * n2) / SP_W)) * fs * (2 * rn2)) / ((uint64)(2 * n2) * ref->fs));

    if(k0 > rn2)
      break;

    if(k1 <= k0)
      k1 = k0 + 1;

    if(k1 > (rn2 + 1))
      k1 = rn2 + 1;

    v = ref->cdb[k0];

    for(k = k0 + 1; k < k1; k++)
    {
      if(ref->cdb[k] > v)
        v = ref->cdb[k];
    }

    y = sp_level_y(v);

    if(have)
      display_draw_line(SP_X0 + c - 1, prev_y, SP_X0 + c, y);
    else
    {
      //v1.00z0: "R1" .. "R4" in the reference's color at the left, at the scale (above the curve's start)
      static const char *names[VIEW_REF_SLOTS] = { "R1", "R2", "R3", "R4" };
      int32 ly = y - 16;

      if(ly < sp_y0)
        ly = sp_y0;
      else if(ly > (SP_Y1 - 14))
        ly = SP_Y1 - 14;

      display_set_font(&font_2);
      display_text(SP_X0 + 3, ly, (int8 *)names[r]);
    }

    prev_y = y;
    have = 1;
  }
}

static void sp_draw_refs(int log2n)
{
  int r;

  for(r = 0; r < VIEW_REF_SLOTS; r++)
  {
    if(sp_ref[r].valid && sp_ref[r].shown)
      sp_draw_ref(r, log2n);
  }
}
