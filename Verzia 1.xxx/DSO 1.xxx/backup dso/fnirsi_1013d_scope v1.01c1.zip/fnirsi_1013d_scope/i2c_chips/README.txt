# I2C chips for the decoder of the FNIRSI 1013D firmware (v1.01b0)
# Copy this folder to the SD card as \i2c_chips\ . One file per chip, name up to 8 characters + .txt.
# The List (Chip button) offers Auto, Off and every chip found here. Without the folder the firmware
# uses its built-in DS3231M and 24C32/64.
#
# Lines KEY=value, # starts a comment. Hex numbers without 0x.
# NAME=      name on the address row and in the Chip list (up to 26 characters)
# SHORT=     name on the Chip button (up to 7 characters)
# CAT=       tab of the Chip window: RTC, Memory, Sensors, Converters, I/O, Power, Display (others: only under All)
# ADDR=      7 bit device address, or a range: 50-57
# ADDR2=     a second address or range (e.g. BH1750: ADDR=23, ADDR2=5C)
# AUTO=      1: used by Chip = Auto (when several chips fit, the narrowest address range wins), 0: only when chosen
# REGADDR=   bytes of register / memory address the master writes first (0, 1 or 2)
# BLOCKBITS= 24C04/08/16: low bits of the device address that are memory address bits 8.. (0..3)
# MEMORY=    1: memory, the bytes are shown as Write / Read [address] = value
# REGSIZE=   bytes per register (1 or 2, 2 = high byte first)
# AUTOINC=   1: the register address goes up after every register (0: it stays)
# LAST=      the last register (hex); after it the address goes back to 0
# DATA=      name,type of every data byte of a chip without registers (REGADDR=0)
# REG=       register,name,type,extra
#
# Types: HEX (extra: mask), DEC, SDEC (signed, extra: unit), BCD (extra: mask), BIN,
#        BITS (extra: names of bit 7 .. bit 0, comma separated, - for none), FRAC2 (bits 7..6 = .00 .25 .50 .75)
