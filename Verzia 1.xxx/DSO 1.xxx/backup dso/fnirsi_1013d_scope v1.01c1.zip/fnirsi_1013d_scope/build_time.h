#ifndef BUILD_TIME_H
#define BUILD_TIME_H
#define COMPILE_YEAR 26
#define COMPILE_MONTH 11
#define COMPILE_DAY 28
#define COMPILE_HOUR 8
#define COMPILE_MIN 30
#define COMPILE_SEC 22
#endif
