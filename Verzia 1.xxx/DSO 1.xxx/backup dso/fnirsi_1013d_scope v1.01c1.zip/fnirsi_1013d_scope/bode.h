//----------------------------------------------------------------------------------------------------------------------------------
// bode.h - frequency response (Bode) view (v1.00t1). The calibration pin's DDS generator (FPGA 0x2000, commands 0x50 /
// 0x51 / 0x52) drives the device under test, CH1 reads its input and CH2 its output. For every point of a log spaced
// sweep the gain CH2 / CH1 in dB and the phase are taken from a Hann windowed single frequency DFT of both records at
// the generator's exact frequency. The view replaces the trace display like the spectrum analyser view.
//----------------------------------------------------------------------------------------------------------------------------------

#ifndef BODE_H
#define BODE_H

#include "types.h"
#include "variables.h"

void bode_set_active(int on);
void bode_settings_for_save(void);     //v1.00z4
int  bode_is_active(void);

//Called instead of the trace display, and by the acquisition for every new record
void bode_display(void);
void bode_new_record(void);

//Touch in the trace area, AUTO SET, T CURSOR
void bode_handle_touch(void);
void bode_autoset(void);
void bode_toggle_cursor(void);

//v1.00u2: the MEASURES button of the right bar clears the chart in this view
void bode_clear_chart(void);

//v1.00v2: the view's settings in the settings sector (7 words)
void bode_settings_save(uint16 *ptr);
void bode_settings_load(const uint16 *ptr);

//v1.00v3: SAVE BODE (the file in \bode\, its thumbnail, the CSV) and showing a saved file
uint32 bode_file_write(FIL *fp);
uint32 bode_csv_write(void);
void   bode_fill_thumbnail(PTHUMBNAILDATA td);
void   bode_view_file(void);
int    bode_is_viewing(void);     //v1.00v7

//v1.00y3: reference curves panel (REF in the CH2 menu), CH range Manual
void   bode_ref_panel(uint32 xpos);
int    bode_range_manual(void);

#endif
