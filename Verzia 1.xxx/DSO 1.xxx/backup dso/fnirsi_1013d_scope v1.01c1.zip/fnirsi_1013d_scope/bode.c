//----------------------------------------------------------------------------------------------------------------------------------
// bode.c - frequency response (Bode) view (v1.00t1), see bode.h.
//
// Wiring: calibration pin (generator, 0..3.3 V square) -> DUT input and CH1, DUT output -> CH2, probe grounds on the DUT.
//
// Sweep: Points log spaced frequencies from Start to Stop. For each point the generator is set to the frequency (the DDS
// step gives its exact value, which the DFT uses), the sample rate is the slowest of the short time base rates with
// at least 20 samples per period, the records captured right after a change are dropped (the generator, the DUT and
// the relays settle), then one record is measured. With CH range Auto a clipped or too small channel gets another
// V/div and the point is measured again after the relays settled (dropped records); with Constant the V/div stay.
// The scope keeps acquiring as usual (auto trigger), RUN repeats the sweep, STOP pauses it, AUTO SET finds the corner.
//
// Layout of the trace area (as the spectrum analyser view): two text lines at the top, the plot x 54..688 by y 86..406
// with the gain axis on the left (dB) and the phase axis on the right (degrees), the frequency axis log with decades,
// seven buttons under the plot with value lists (first touch opens, second chooses).
//----------------------------------------------------------------------------------------------------------------------------------

#include "types.h"
#include "bode.h"
#include "spectrum.h"
#include "fx_fft.h"
#include "fnirsi_1013d_scope.h"
#include "variables.h"
#include "display_lib.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "menu.h"
#include "statemachine.h"
#include "scope_functions.h"
#include "ref_and_math.h"     //v1.00y3: reference curves panel

//----------------------------------------------------------------------------------------------------------------------------------

#define BD_X0             54
#define BD_X1             688
#define BD_Y0             86          //v1.00u2: two text lines again (Thru status in the left margin, all readouts on one line)
#define BD_Y1             406
#define BD_W              (BD_X1 - BD_X0)
#define BD_H              (BD_Y1 - BD_Y0)
#define BD_DIVS_Y         8
#define BD_TXT_Y          50
#define BD_TXT_LINE       18
#define BD_COL2_X         322

#define BD_GAIN_TOP       1000        //centi-dB at the top of the plot
#define BD_GAIN_DIV       1000        //centi-dB per division
#define BD_PHASE_TOP      180000      //milli-degrees at the top
#define BD_PHASE_DIV      45000       //milli-degrees per division

#define BD_GAIN_COLOR     0x0000FFFF  //cyan, as MCP
#define BD_PHASE_COLOR    0x00FF60C0  //pink, as MCP
#define BD_CURSOR_COLOR   ORANGE_COLOR
#define BD_TEXT_COLOR     0x00C0C0C0
#define BD_BOX_FILL       0x00101010

#define BD_BTN_Y          434
#define BD_BTN_H          40
#define BD_BTN_X0         4
#define BD_BTN_W          100
#define BD_BTN_PITCH      104
#define BD_BTN_COUNT      7
#define BD_LIST_ROW_H     30

#define BD_MAX_POINTS     100
#define BD_GEN_CLOCK_MHZ  50000000000ull   //DDS clock 50 MHz in mHz
#define BD_SAMPLES_PER_PERIOD  20
#define BD_MIN_PERIODS    8           //v1.00t3: periods in a record (v1.00t8: 8 as MCP, was 16)
#define BD_SETTLE_DELAY_MAX_MS  400   //v1.00t8: settle by a delay up to this, longer by dropped records
#define BD_SHORT_TB_FIRST 11
#define BD_SHORT_TB_LAST  34
#define BD_SHORT_RATE_LAST 17
#define BD_RANGE_SKIP     3           //records dropped after a V/div change (the relays and the input settle)

//Buttons
#define BD_BTN_START      0
#define BD_BTN_STOP       1
#define BD_BTN_POINTS     2
#define BD_BTN_SETTLE     3
#define BD_BTN_RANGE      4
#define BD_BTN_DISPLAY    5
#define BD_BTN_THRU       6           //v1.00u1: Thru (was Clear; Clear chart is in its list)

//----------------------------------------------------------------------------------------------------------------------------------

//static const uint32 bd_start_hz[] = { 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000 };
//static const uint32 bd_stop_hz[]  = { 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000, 2000000, 5000000 };
//v1.00w7: span 1 Hz .. 10 MHz (+ 1, 2, 5 Hz at the start, + 10 MHz at the end). Below 10 Hz the slowest short time
//base (500 Sa/s) holds fewer than 8 periods (1 Hz: 6 s record, 6 periods with 3000 samples), still enough for the
//Hann window, only slow. Settings and files of older versions have the start index 3 lower (BD_START_OLD_SHIFT).
static const uint32 bd_start_hz[] = { 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000 };
static const uint32 bd_stop_hz[]  = { 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000, 2000000, 5000000, 10000000 };
#define BD_START_OLD_SHIFT  3
static const uint8  bd_points[]   = { 10, 20, 30, 50, 100 };
static const uint8  bd_settle_periods[] = { 3, 10, 50, 200 };
static const char  *bd_settle_names[]   = { "Fast", "Normal", "Resonant", "High Q" };
//static const char  *bd_range_names[]    = { "Auto", "Constant" };
static const char  *bd_range_names[]    = { "Auto", "Manual" };      //v1.00y3: Manual = V/div by hand (channel menu)
static const char  *bd_display_names[]  = { "Both", "Gain", "Phase" };
static const char  *bd_btn_names[BD_BTN_COUNT] = { "Start", "Stop", "Points", "Settle", "CH range", "Display", "Thru" };
static const char  *bd_thru_names[]   = { "Measure", "On", "Off" };      //v1.00u2: Clear chart is the right bar button

#define BD_COUNT(a)       ((int)(sizeof(a) / sizeof(a[0])))

typedef struct
{
  uint8  active;
  uint8  start;           //index in bd_start_hz
  uint8  stop;            //index in bd_stop_hz
  uint8  points;          //index in bd_points
  uint8  settle;          //index in bd_settle_periods
  uint8  range;           //0 Auto, 1 Constant
  uint8  display;         //0 both, 1 gain, 2 phase
  uint8  cursor_on;
  uint8  cursor;          //point index of cursor C1
  uint8  cursor2;         //v1.00u7: point index of cursor C2
  uint8  newrecord;       //a record came in since the last step
  uint8  sweeping;        //a point is being measured
  uint8  skip;            //records still to drop before measuring
  uint8  autostage;       //0 off, 1 overview sweep, 2 final sweep
  uint8  warn;            //BD_WARN_* of the last point
  uint16 idx;             //point in measurement
  uint16 n;               //points of the sweep
  uint16 measured;        //points measured in the current table
  uint8  rangechanges;    //v1.00t2: V/div changes for the current point
  uint8  nofiner;         //v1.00t2: bit per channel: no finer V/div for this point (it clipped there)
  uint32 sweep_t0;        //v1.00t9: start of the sweep (ms ticks)
  uint32 sweep_ms;        //v1.00t9: duration of the last full sweep
  uint8  thru_measuring;  //v1.00u1: the current sweep measures the thru
  uint8  thru_valid;      //v1.00u1: a thru is stored
  uint8  thru_on;         //v1.00u1: the thru is divided out of the sweeps
  uint8  thru_start, thru_stop, thru_points;   //v1.00u1: the table the thru belongs to
  uint8  user_points;     //v1.00u4: the Points chosen before AUTO SET (its overview uses 20, the final sweep these)
  uint8  single;          //v1.00w8: 0 RUN repeats the sweep, 1 one sweep then STOP (rows under Points)
  uint8  checks;          //v1.00w9: settle check: measurements of the current point so far
  int32  prev_gain;       //v1.00w9: the previous measurement of the current point
  int32  prev_phase;
} BODESTATE;

#define BD_CURSOR2_COLOR  MAGENTA_COLOR   //v1.00u7: cursor C2 (C1 orange)

#define BD_WARN_CH1_LOW   0x01
#define BD_WARN_CH2_SMALL 0x02
#define BD_WARN_CLIPPED   0x04
#define BD_WARN_UNSETTLED 0x08        //v1.00w9: two measurements of the point did not agree
#define BD_WARN_NOISE     0x10        //v1.00x0: CH2 signal less than BD_SNR_MIN_CDB above its noise
#define BD_SNR_MIN_CDB    1200        //v1.00x0: 12 dB
#define BD_SNR_UNKNOWN    0x7FFFFFFF  //v1.00x0: no noise value (points of a saved file)

//v1.00w9: settle check (all Settle settings but Fast): a point is measured on two records in a row and taken when both
//agree within these limits, otherwise once more (the newer against the one before), at most BD_SETTLE_CHECK_MAX
//measurements, then it is kept grey with "not settled"
#define BD_SETTLE_CHECK_CDB    50     //0.5 dB
#define BD_SETTLE_CHECK_MDEG   3000   //3 degrees
#define BD_SETTLE_CHECK_MAX    5

//static BODESTATE bd = { 0, 3, 9, 2, 1, 0, 0, 0, 0xFF, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 };
static BODESTATE bd = { 0, 6, 9, 2, 1, 0, 0, 0, 0xFF, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 };   //v1.00w7: start 100 Hz is index 6 now

static uint64 bd_f[BD_MAX_POINTS];       //exact generator frequency of each point, mHz
static int32  bd_gain[BD_MAX_POINTS];    //centi-dB
static int32  bd_phase[BD_MAX_POINTS];   //milli-degrees
static uint8  bd_ok[BD_MAX_POINTS];      //measured and passed the checks
static int32  bd_thru_gain[BD_MAX_POINTS];    //v1.00u1: the thru (both probes on the DUT input), centi-dB
static int32  bd_thru_phase[BD_MAX_POINTS];   //v1.00u1: milli-degrees
static int32  bd_snr[BD_MAX_POINTS];          //v1.00x0: CH2 signal to noise, centi-dB (BD_SNR_UNKNOWN when not measured)

//v1.00u1: the thru belongs to this sweep's table (Start, Stop, Points); else it is stale
static int bd_thru_matches(void)
{
  return(bd.thru_valid && (bd.thru_start == bd.start) && (bd.thru_stop == bd.stop) && (bd.thru_points == bd.points));
}

//Settings of the scope saved on entry and put back on exit
typedef struct
{
  __typeof__(scopesettings.timeperdiv)               timeperdiv;
  __typeof__(scopesettings.runstate)                 runstate;
  __typeof__(scopesettings.triggermode)              triggermode;
  __typeof__(scopesettings.triggerchannel)           triggerchannel;
  __typeof__(scopesettings.channel1.displayvoltperdiv) ch1vpd;
  __typeof__(scopesettings.channel2.displayvoltperdiv) ch2vpd;
  __typeof__(scopesettings.channel1.enable)          ch1enable;
  __typeof__(scopesettings.channel2.enable)          ch2enable;
  __typeof__(fpgasettings.gen_enable)                gen_enable;
  __typeof__(fpgasettings.gen_freq)                  gen_freq;
  __typeof__(fpgasettings.gen_duty)                  gen_duty;
  //v1.00t6: the trigger level and the horizontal position too
  __typeof__(scopesettings.triggerverticalposition)          tvp;
  __typeof__(scopesettings.channel1.triggerverticalposition) ch1tvp;
  __typeof__(scopesettings.channel2.triggerverticalposition) ch2tvp;
  __typeof__(scopesettings.triggerhorizontalposition)        thp;
} BODESAVED;

static BODESAVED bd_saved;

//v1.00v3: a saved frequency response is shown (Saved waveforms in this view): no sweep, only Display and the cursors
static uint8 bd_viewing = 0;
static uint8 bd_markers_hidden = 0;

//v1.00y6: the hint is shown after entering the view only, until the first touch in the view or the first sweep
static uint8 bd_hint_pending = 0;
   //v1.00v7: MARKERS off in the saved file viewer

//----------------------------------------------------------------------------------------------------------------------------------
//Text helpers (as spectrum.c)

static char *bd_str(char *p, const char *s)
{
  while(*s)
    *p++ = *s++;

  *p = 0;
  return(p);
}

static char *bd_uint(char *p, uint32 v)
{
  char   t[11];
  uint32 i = 0;

  do
  {
    t[i++] = '0' + (v % 10);
    v /= 10;
  } while(v);

  while(i)
    *p++ = t[--i];

  *p = 0;
  return(p);
}

static char *bd_fixed(char *p, uint32 ip, uint32 frac, uint32 decimals, int trim)
{
  char   t[8];
  uint32 i;

  p = bd_uint(p, ip);

  if(decimals == 0)
    return(p);

  for(i = decimals; i > 0; i--)
  {
    t[i - 1] = '0' + (frac % 10);
    frac /= 10;
  }

  if(trim)
  {
    while((decimals > 0) && (t[decimals - 1] == '0'))
      decimals--;
  }

  if(decimals)
  {
    *p++ = '.';

    for(i = 0; i < decimals; i++)
      *p++ = t[i];
  }

  *p = 0;
  return(p);
}

static char *bd_freq(char *p, uint64 f_mhz, int trim)
{
  uint64 hz = f_mhz / 1000;

  if(hz >= 1000000)
  {
    p = bd_fixed(p, (uint32)(hz / 1000000), (uint32)((hz % 1000000) / 1000), 3, trim);
    p = bd_str(p, " MHz");
  }
  else if(hz >= 1000)
  {
    p = bd_fixed(p, (uint32)(hz / 1000), (uint32)(hz % 1000), 3, trim);
    p = bd_str(p, " kHz");
  }
  else
  {
    p = bd_fixed(p, (uint32)hz, (uint32)((f_mhz % 1000) / 10), 2, trim);
    p = bd_str(p, " Hz");
  }

  return(p);
}

//Signed value with 'decimals' of 'scale' (centi = 100, milli = 1000)
static char *bd_signed(char *p, int32 v, int32 scale, int decimals)
{
  int32 div = scale;
  int   i;

  if(v < 0)
  {
    *p++ = '-';
    v = -v;
  }
  else if(v > 0)
    *p++ = '+';

  for(i = 0; i < decimals; i++)
    div /= 10;

  return(bd_fixed(p, v / scale, (v % scale) / div, decimals, 0));
}

static uint32 bd_text_width(const char *text)
{
  extern DISPLAYDATA displaydata;
  PFONTINFORMATION info;
  uint32 width = 0;

  while(*text)
  {
    info = check_char_in_vw_font(displaydata.font->fontinformation, (uint16)(uint8)*text);

    if(info)
      width += info->fontmetrics[(uint8)*text - info->first_char].width;

    text++;
  }

  return(width);
}

//One readout in a rounded frame on text line 'line'; returns the x after it
static int32 bd_box(int32 x, int line, const char *t, uint32 color)
{
  int32 y = BD_TXT_Y + (line * BD_TXT_LINE);
  int32 w = bd_text_width(t) + 10;

  display_set_fg_color(BD_BOX_FILL);
  display_fill_rounded_rect(x, y - 1, w, 16, 3);
  display_set_fg_color(color);
  display_draw_rounded_rect(x, y - 1, w, 16, 3);
  display_text(x + 5, y + 1, (int8 *)t);

  return(x + w + 4);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Maths

//2^(y / 65536) as a double (y >= 0), for the frequency plan
static double bd_exp2_q16(int32 y)
{
  int32  k = y >> 16;
  double f = (double)(y & 0xFFFF) / 65536.0;
  double p = 1.0 + f * (0.6931471806 + f * (0.2402265070 + f * (0.0555041087 + f * (0.0096181291 + f * 0.0013333558))));

  while(k > 0)
  {
    p *= 2.0;
    k--;
  }

  return(p);
}

//cos and sin in Q30 of a phase (2^32 = one turn)
static int32 bd_cos(uint32 phase)
{
  return(fx_cos_q30(phase >> (32 - FX_FFT_LOG2_MAX), FX_FFT_LOG2_MAX));
}

static int32 bd_sin(uint32 phase)
{
  return(fx_cos_q30((phase - 0x40000000u) >> (32 - FX_FFT_LOG2_MAX), FX_FFT_LOG2_MAX));
}

//Angle of x + j y in milli-degrees, (-180000, 180000], 16 CORDIC steps
static int32 bd_atan2_mdeg(int64 y, int64 x)
{
  static const int32 atantab[16] = { 45000, 26565, 14036, 7125, 3576, 1790, 895, 448, 224, 112, 56, 28, 14, 7, 3, 2 };
  int32 base = 0, z = 0, i;
  int64 xn;

  if((x == 0) && (y == 0))
    return(0);

  //Left half plane: turn by 180 degrees first
  if(x < 0)
  {
    x = -x;
    y = -y;
    base = 180000;
  }

  //Keep the values within 2^29 for the shifts, and large enough for the precision of the steps
  while((x > (1LL << 29)) || (y > (1LL << 29)) || (y < -(1LL << 29)))
  {
    x >>= 1;
    y >>= 1;
  }

  while((x < (1LL << 27)) && (y < (1LL << 27)) && (y > -(1LL << 27)))
  {
    x <<= 1;
    y <<= 1;
  }

  for(i = 0; i < 16; i++)
  {
    if(y > 0)
    {
      xn = x + (y >> i);
      y  = y - (x >> i);
      z += atantab[i];
    }
    else
    {
      xn = x - (y >> i);
      y  = y + (x >> i);
      z -= atantab[i];
    }

    x = xn;
  }

  z += base;

  while(z > 180000)
    z -= 360000;

  while(z <= -180000)
    z += 360000;

  return(z);
}

//Power of a complex value in log2 Q16 (re, im any size)
static int32 bd_log2_power(int64 re, int64 im)
{
  int32 s = 0;

  while((re > (1LL << 30)) || (re < -(1LL << 30)) || (im > (1LL << 30)) || (im < -(1LL << 30)))
  {
    re >>= 1;
    im >>= 1;
    s++;
  }

  return(fx_log2_q16((uint64)(re * re) + (uint64)(im * im) + 1) + ((2 * s) << 16));
}

//----------------------------------------------------------------------------------------------------------------------------------
//Hardware

//Set the generator to f (mHz); returns the frequency the DDS really makes (mHz)
static uint64 bd_generator_set(uint64 f_mhz)
{
  //phase_inc = f * 2^32 / 50 MHz, done as (f << 26) / (5e10 / 64) to stay in 64 bits
  uint64 inc = (f_mhz << 26) / (BD_GEN_CLOCK_MHZ >> 6);

  //v1.00x3: FPGA 0x2050 has no DDS: its square generator (period in 1/65536 of 5 ns) gives the exact frequency
  if(FPGA_IS_153F_PORT())
    return(fpga_square_set(f_mhz, 50));

  if(inc < 1)
    inc = 1;

  fpga_write_cmd(0x51);
  fpga_write_int((uint32)inc);

  return((inc * (BD_GEN_CLOCK_MHZ >> 6)) >> 26);
}

static void bd_generator_on(void)
{
  //v1.00x3: on 0x2050 the duty comes with every frequency (bd_generator_set), only the pin is switched on here
  if(!FPGA_IS_153F_PORT())
    fpga_set_generator_duty(50);
  fpga_write_cmd(0x50);
  fpga_write_int(1);
}

//v1.00t3: the short time base setting with the fastest sample rate whose record still holds BD_MIN_PERIODS periods of
//f (was: the slowest rate with 20 samples per period, which made records of 150 periods and more, up to 2.5 s at
//100 Hz). The next faster rate is at most 2.5x, so there are always more than 70 samples per period.
static void bd_set_rate_for(uint64 f_mhz)
{
  int    rate = BD_SHORT_RATE_LAST, t;
  uint64 limit = ((uint64)fpgasettings.totalsamples * f_mhz) / BD_MIN_PERIODS;   //fs * 1000 may be at most this

  for(t = 0; t <= BD_SHORT_RATE_LAST; t++)
  {
    if(((uint64)sample_rate[t] * 1000) <= limit)
    {
      rate = t;
      break;
    }
  }

  for(t = BD_SHORT_TB_FIRST; t <= BD_SHORT_TB_LAST; t++)
  {
    if(time_per_div_sample_rate[t] == rate)
      break;
  }

  if((t <= BD_SHORT_TB_LAST) && (t != scopesettings.timeperdiv))
  {
    display_set_screen_buffer((uint16 *)maindisplaybuffer);
    scopesettings.timeperdiv = t;
    scope_set_timebase();
  }
}

//Another V/div for a channel (dir +1 finer, -1 coarser); returns 1 when it changed
static int bd_change_range(PCHANNELSETTINGS s, int dir)
{
  int v = (int)s->displayvoltperdiv + dir;

  if((v < 0) || (v > 6))
    return(0);

  s->displayvoltperdiv = v;
  match_volt_per_div_settings(s);

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_channel_settings(s, 0);

  return(1);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Sweep

static uint64 bd_point_freq(int i)
{
  uint64 f0 = (uint64)bd_start_hz[bd.start] * 1000;
  uint64 f1 = (uint64)bd_stop_hz[bd.stop] * 1000;
  int32  l0, l1;

  if(f1 <= f0)
    f1 = f0 * 10;

  if(bd.n < 2)
    return(f0);

  l0 = fx_log2_q16(f0);
  l1 = fx_log2_q16(f1);

  return((uint64)bd_exp2_q16(l0 + (int32)(((int64)(l1 - l0) * i) / (bd.n - 1))));
}

//Number of records to drop after setting a point: one for the change, more when the settle time is longer than a record
static uint8 bd_settle_records(uint64 f_mhz)
{
  uint64 fs = sample_rate[scopesettings.samplerate];
  uint64 n  = fpgasettings.totalsamples;
  uint64 settle_us, record_us, k;

  if((fs == 0) || (f_mhz == 0))
    return(1);

  settle_us = ((uint64)bd_settle_periods[bd.settle] * 1000000000ull) / f_mhz;
  record_us = (n * 1000000ull) / fs;

  if(record_us == 0)
    record_us = 1;

  k = 1 + (settle_us / record_us);

  return((k > 20) ? 20 : (uint8)k);
}

static void bd_point_setup(void)
{
  uint64 f = bd_point_freq(bd.idx);

  uint32 settle_ms;

  //v1.00u0: sweeping before the time base change: that change redraws the view (scope_preset_values), which showed the
  //start hint for a moment when AUTO SET or RUN started a sweep
  bd.sweeping = 1;

  bd_f[bd.idx] = bd_generator_set(f);
  bd_set_rate_for(bd_f[bd.idx]);

  //v1.00t8: faster, as MCP: the next record starts only after this step (the acquisition is sequential), so instead
  //of dropping a whole record the settle time (Settle periods of f) is waited here and the next record is measured.
  //The first point of a sweep still drops one record (a capture may already run), long settle times drop records.
  settle_ms = (uint32)(((uint64)bd_settle_periods[bd.settle] * 1000000ull) / (bd_f[bd.idx] ? bd_f[bd.idx] : 1)) + 1;

  if((bd.idx > 0) && (settle_ms <= BD_SETTLE_DELAY_MAX_MS))
  {
    timer0_delay(settle_ms);
    bd.skip = 0;
  }
  else
    bd.skip = bd_settle_records(bd_f[bd.idx]);

  bd.sweeping  = 1;
  bd.newrecord = 0;

  //v1.00t2: a new point may try finer ranges again
  bd.rangechanges = 0;
  bd.nofiner      = 0;
  bd.checks       = 0;    //v1.00w9
}

//v1.00t3: keep = 1 for a repeated sweep with the same table: the old points stay and are overwritten one by one (the
//chart no longer disappears when RUN starts the next sweep)
static void bd_sweep_begin(int keep)
{
  int i;

  if(!keep || (bd.n != bd_points[bd.points]))
  {
    for(i = 0; i < BD_MAX_POINTS; i++)
      bd_ok[i] = 0;
  }

  bd_hint_pending = 0;     //v1.00y6

  bd.n        = bd_points[bd.points];
  bd.idx      = 0;
  bd.measured = 0;
  bd.warn     = 0;
  bd.sweep_t0 = timer0_get_ticks();

  //v1.00u8: C1 starts at a quarter of the table (at point 0 it lay on the plot's left edge, where a touch did not reach
  //it, so it could not be moved)
  if(bd.cursor >= bd.n)
    bd.cursor = bd.n / 4;

  //v1.00u7: C2 starts at three quarters of the table
  if(bd.cursor2 >= bd.n)
    bd.cursor2 = (bd.n * 3) / 4;

  bd_generator_on();
  bd_point_setup();
}

static void bd_sweep_start(void)
{
  bd_sweep_begin(0);
}

//v1.00t2: a finer V/div (up to 2.5x the codes around the centre 128) keeps the record within 10..245 and the signal is
//small enough to gain from it (less than 100 codes peak to peak)
static int bd_fits_finer(uint32 min, uint32 max)
{
  int32 lo = 128 + ((((int32)min - 128) * 5) / 2);
  int32 hi = 128 + ((((int32)max - 128) * 5) / 2);

  return(((max - min) < 100) && (lo >= 10) && (hi <= 245));
}

//Measure the current record at the point's frequency. Returns 0 when the point has to be measured again (V/div changed)
static int bd_measure(void)
{
  uint8 *b1 = scopesettings.channel1.tracebuffer;
  uint8 *b2 = scopesettings.channel2.tracebuffer;
  uint32 n  = fpgasettings.totalsamples;
  uint64 fs = sample_rate[scopesettings.samplerate];
  uint32 i, min1 = 255, max1 = 0, min2 = 255, max2 = 0;
  int32  sum1 = 0, sum2 = 0, m1, m2;
  uint32 ph = 0, dph, wph = 0, dwph;
  int64  re1 = 0, im1 = 0, re2 = 0, im2 = 0;
  uint32 phn = 0, dphn;                 //v1.00x0: noise bin of CH2
  int64  ren = 0, imn = 0;
  int32  ln;
  int32  c, s, w, x1, x2, l1, l2;

  if((n < 64) || (fs == 0))
    return(1);

  if(n > 8192)
    n = 8192;

  for(i = 0; i < n; i++)
  {
    sum1 += b1[i];
    sum2 += b2[i];

    if(b1[i] < min1) min1 = b1[i];
    if(b1[i] > max1) max1 = b1[i];
    if(b2[i] < min2) min2 = b2[i];
    if(b2[i] > max2) max2 = b2[i];
  }

  bd.warn = 0;

  //CH range Auto: a clipped channel gets a coarser V/div, a small one a finer V/div, then the point is measured again.
  //v1.00t2: no back and forth between two ranges (the relays clicked 100 / 200 mV and the sweep stood still):
  // - finer only when the signal, scaled by 2.5 around the screen centre (code 128, so a DC level counts too), still
  //   fits with a margin,
  // - after a channel clipped no finer range for it on this point,
  // - at most 6 changes per point, then the point is measured as it is.
  if((bd.range == 0) && (bd.rangechanges < 6))
  {
    int changed = 0;

    if((min1 == 0) || (max1 == 255))
    {
      changed |= bd_change_range(&scopesettings.channel1, -1);
      bd.nofiner |= 1;
    }
    else if(!(bd.nofiner & 1) && bd_fits_finer(min1, max1))
      changed |= bd_change_range(&scopesettings.channel1, 1);

    if((min2 == 0) || (max2 == 255))
    {
      changed |= bd_change_range(&scopesettings.channel2, -1);
      bd.nofiner |= 2;
    }
    else if(!(bd.nofiner & 2) && bd_fits_finer(min2, max2))
      changed |= bd_change_range(&scopesettings.channel2, 1);

    if(changed)
    {
      //v1.00t8: the relays and the input settle for 150 ms, then one record is dropped (was 3 records)
      bd.rangechanges++;
      timer0_delay(150);
      bd.skip = 1;
      return(0);
    }
  }

  if((max1 - min1) < 20)
    bd.warn |= BD_WARN_CH1_LOW;

  if((max2 - min2) < 4)
    bd.warn |= BD_WARN_CH2_SMALL;

  if((min1 == 0) || (max1 == 255) || (min2 == 0) || (max2 == 255))
    bd.warn |= BD_WARN_CLIPPED;

  m1 = sum1 / (int32)n;
  m2 = sum2 / (int32)n;

  //Phase steps: the point's frequency and the Hann window over the record (2^32 = one turn)
  dph  = (uint32)(((bd_f[bd.idx] << 24) / (fs * 1000)) << 8);
  dwph = (uint32)(0x100000000ull / n);

  //v1.00x0: noise of CH2 measured at 1.375 f (between the fundamental and its 3rd harmonic, so neither the signal nor
  //the harmonics of the square wave generator count as noise)
  dphn = dph + ((dph >> 3) * 3);

  for(i = 0; i < n; i++)
  {
    //Hann window in Q15
    w = (int32)((0x40000000 - bd_cos(wph)) >> 16);

    c = bd_cos(ph) >> 15;
    s = bd_sin(ph) >> 15;

    x1 = ((int32)b1[i] - m1) * w;
    x2 = ((int32)b2[i] - m2) * w;

    re1 += (int64)x1 * c;
    im1 -= (int64)x1 * s;
    re2 += (int64)x2 * c;
    im2 -= (int64)x2 * s;

    //v1.00x0: noise bin
    ren += (int64)x2 * (bd_cos(phn) >> 15);
    imn -= (int64)x2 * (bd_sin(phn) >> 15);
    phn += dphn;

    ph  += dph;
    wph += dwph;
  }

  //Gain: power ratio in dB (= 20 log10 of the amplitude ratio), with the volts per code of each channel
  l1 = bd_log2_power(re1, im1);
  l2 = bd_log2_power(re2, im2);

  //v1.00x0: signal to noise of CH2 (the DUT output) in centi-dB, below BD_SNR_MIN_CDB the point is grey
  ln = bd_log2_power(ren, imn);
  bd_snr[bd.idx] = fx_cdb_from_q16(l2) - fx_cdb_from_q16(ln);

  if(bd_snr[bd.idx] < BD_SNR_MIN_CDB)
    bd.warn |= BD_WARN_NOISE;

  bd_gain[bd.idx] = fx_cdb_from_q16(l2) - fx_cdb_from_q16(l1) + spectrum_channel_volts_cdb(&scopesettings.channel2) - spectrum_channel_volts_cdb(&scopesettings.channel1);

  //Phase: angle of X2 times the conjugate of X1 (both vectors scaled down first)
  while((re1 > (1LL << 29)) || (re1 < -(1LL << 29)) || (im1 > (1LL << 29)) || (im1 < -(1LL << 29)))
  {
    re1 >>= 1;
    im1 >>= 1;
  }

  while((re2 > (1LL << 29)) || (re2 < -(1LL << 29)) || (im2 > (1LL << 29)) || (im2 < -(1LL << 29)))
  {
    re2 >>= 1;
    im2 >>= 1;
  }

  bd_phase[bd.idx] = bd_atan2_mdeg((im2 * re1) - (re2 * im1), (re2 * re1) + (im2 * im1));

  //v1.00u1: Thru, as MCP: the thru sweep stores the difference of the two channels with both probes on the DUT input;
  //Thru On divides it out of the later sweeps of the same table
  if(bd.thru_measuring)
  {
    bd_thru_gain[bd.idx]  = bd_gain[bd.idx];
    bd_thru_phase[bd.idx] = bd_phase[bd.idx];
  }
  else if(bd.thru_on && bd_thru_matches())
  {
    int32 ph = bd_phase[bd.idx] - bd_thru_phase[bd.idx];

    while(ph > 180000)   ph -= 360000;
    while(ph <= -180000) ph += 360000;

    bd_gain[bd.idx] -= bd_thru_gain[bd.idx];
    bd_phase[bd.idx] = ph;
  }

  bd_ok[bd.idx] = (bd.warn == 0) ? 1 : 2;   //2: measured, shown grey

  return(1);
}

static void bd_autoset_step(void);

//One step on every new record
static void bd_sweep_step(void)
{
  if(!bd.sweeping || !bd.newrecord)
    return;

  bd.newrecord = 0;

  if(bd.skip)
  {
    bd.skip--;
    return;
  }

  if(!bd_measure())
  {
    bd.checks = 0;    //v1.00w9: V/div changed, an earlier measurement does not count
    return;
  }

  //v1.00w9: settle check (not with Settle Fast, not on points that already have a warning)
  if((bd.settle != 0) && (bd.warn == 0))
  {
    int32 dg = bd_gain[bd.idx] - bd.prev_gain;
    int32 dp = bd_phase[bd.idx] - bd.prev_phase;

    while(dp > 180000)   dp -= 360000;
    while(dp <= -180000) dp += 360000;

    if(dg < 0) dg = -dg;
    if(dp < 0) dp = -dp;

    if((bd.checks == 0) || (((dg > BD_SETTLE_CHECK_CDB) || (dp > BD_SETTLE_CHECK_MDEG)) && (bd.checks < (BD_SETTLE_CHECK_MAX - 1))))
    {
      //Measure once more on the next record
      bd.prev_gain  = bd_gain[bd.idx];
      bd.prev_phase = bd_phase[bd.idx];
      bd.checks++;
      return;
    }

    if((dg > BD_SETTLE_CHECK_CDB) || (dp > BD_SETTLE_CHECK_MDEG))
    {
      bd.warn |= BD_WARN_UNSETTLED;
      bd_ok[bd.idx] = 2;
    }
  }

  bd.measured = bd.idx + 1;
  bd.idx++;

  if(bd.idx < bd.n)
  {
    bd_point_setup();
    return;
  }

  //Sweep done
  bd.sweeping = 0;
  bd.sweep_ms = timer0_get_ticks() - bd.sweep_t0;

  //v1.00u1: the thru sweep is done: store it for this table, switch it on, STOP; the next sweep is corrected
  if(bd.thru_measuring)
  {
    int i;

    bd.thru_measuring = 0;
    bd.thru_valid     = 1;
    bd.thru_on        = 1;
    bd.thru_start     = bd.start;
    bd.thru_stop      = bd.stop;
    bd.thru_points    = bd.points;

    for(i = 0; i < BD_MAX_POINTS; i++)
      bd_ok[i] = 0;

    bd.measured = 0;
    scopesettings.runstate = 0;
    display_set_screen_buffer((uint16 *)maindisplaybuffer);
    scope_run_stop_text();

    if(scopesettings.rightmenustate == 0)
      scope_run_stop_button(0);

    return;
  }

  if(bd.autostage)
  {
    bd_autoset_step();
    return;
  }

  //v1.00w8: single sweep: STOP, the chart stays (RUN starts the next sweep)
  if(bd.single && scopesettings.runstate)
  {
    scopesettings.runstate = 0;
    display_set_screen_buffer((uint16 *)maindisplaybuffer);
    scope_run_stop_text();

    if(scopesettings.rightmenustate == 0)
      scope_run_stop_button(0);

    return;
  }

  //RUN repeats the sweep, the new one overwrites the chart point by point
  if(scopesettings.runstate)
    bd_sweep_begin(1);
}

//----------------------------------------------------------------------------------------------------------------------------------
//AUTO SET: an overview sweep 100 Hz .. 2 MHz with 20 points, then the span around the -3 dB corner (or a resonance), one
//sweep there with 50 points, then STOP

static int bd_index_le(const uint32 *tab, int count, uint64 hz)
{
  int i, r = 0;

  for(i = 0; i < count; i++)
    if(tab[i] <= hz)
      r = i;

  return(r);
}

static int bd_index_ge(const uint32 *tab, int count, uint64 hz)
{
  int i;

  for(i = 0; i < count; i++)
    if(tab[i] >= hz)
      return(i);

  return(count - 1);
}

static void bd_autoset_step(void)
{
  int    i, first = -1, peak = -1, corner = -1;
  int32  ref = 0, pk = -100000;
  uint64 fc = 0;

  if(bd.autostage == 1)
  {
    for(i = 0; i < bd.n; i++)
    {
      if(bd_ok[i] != 1)
        continue;

      if(first < 0)
      {
        first = i;
        ref   = bd_gain[i];
      }

      if(bd_gain[i] > pk)
      {
        pk   = bd_gain[i];
        peak = i;
      }

      if((corner < 0) && (bd_gain[i] < (ref - 300)))
        corner = i;
    }

    if((peak >= 0) && (pk > (ref + 300)))
    {
      //A resonance: a decade on each side, more points and a longer settle
      fc = bd_f[peak] / 1000;
      bd.start  = bd_index_le(bd_start_hz, BD_COUNT(bd_start_hz), fc / 10);
      bd.stop   = bd_index_ge(bd_stop_hz, BD_COUNT(bd_stop_hz), fc * 10);
      bd.settle = 2;
    }
    else if(corner >= 0)
    {
      //A corner: 20x on each side
      fc = bd_f[corner] / 1000;
      bd.start  = bd_index_le(bd_start_hz, BD_COUNT(bd_start_hz), fc / 20);
      bd.stop   = bd_index_ge(bd_stop_hz, BD_COUNT(bd_stop_hz), fc * 20);
      bd.settle = 1;
    }
    else
    {
      //Flat: keep the overview's span
      bd.settle = 1;
    }

    //v1.00u4: the final sweep with the Points the user chose (was always 50)
    bd.points    = bd.user_points;
    bd.autostage = 2;
    bd_sweep_start();
    return;
  }

  //Final sweep done: STOP, the chart stays
  bd.autostage = 0;
  scopesettings.runstate = 0;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_run_stop_text();

  if(scopesettings.rightmenustate == 0)
    scope_run_stop_button(0);
}

void bode_autoset(void)
{
  //v1.00u4: keep the user's Points for the final sweep (a second AUTO SET during the overview keeps the first one's)
  if(bd.autostage != 1)
    bd.user_points = bd.points;

  //bd.start     = 3;        //100 Hz
  //bd.stop      = 10;       //2 MHz
  //v1.00w7: by value (the start table got longer)
  bd.start     = bd_index_le(bd_start_hz, BD_COUNT(bd_start_hz), 100);       //100 Hz
  bd.stop      = bd_index_ge(bd_stop_hz, BD_COUNT(bd_stop_hz), 2000000);     //2 MHz
  bd.points    = 1;        //20 points
  bd.settle    = 0;        //Fast
  bd.autostage = 1;

  if(!scopesettings.runstate)
  {
    scopesettings.runstate = 1;
    display_set_screen_buffer((uint16 *)maindisplaybuffer);
    scope_run_stop_text();

    if(scopesettings.rightmenustate == 0)
      scope_run_stop_button(0);
  }

  bd_sweep_start();
}

//----------------------------------------------------------------------------------------------------------------------------------
//Drawing

static int32 bd_freq_x(uint64 f_mhz)
{
  uint64 f0 = (uint64)bd_start_hz[bd.start] * 1000;
  uint64 f1 = (uint64)bd_stop_hz[bd.stop] * 1000;
  int32  l0 = fx_log2_q16(f0), l1 = fx_log2_q16(f1), l = fx_log2_q16(f_mhz ? f_mhz : 1);

  if(l1 <= l0)
    return(BD_X0);

  if(l < l0) l = l0;
  if(l > l1) l = l1;

  return(BD_X0 + (int32)(((int64)(l - l0) * BD_W) / (l1 - l0)));
}

static int32 bd_gain_y(int32 cdb)
{
  int32 y = BD_Y0 + (((BD_GAIN_TOP - cdb) * BD_H) / (BD_GAIN_DIV * BD_DIVS_Y));

  return((y < BD_Y0) ? BD_Y0 : (y > BD_Y1) ? BD_Y1 : y);
}

static int32 bd_phase_y(int32 mdeg)
{
  int32 y = BD_Y0 + (int32)(((int64)(BD_PHASE_TOP - mdeg) * BD_H) / ((int64)BD_PHASE_DIV * BD_DIVS_Y));

  return((y < BD_Y0) ? BD_Y0 : (y > BD_Y1) ? BD_Y1 : y);
}

static void bd_draw_grid(void)
{
  char   t[24], *p;
  uint32 c = (scopesettings.gridbrightness * 255) / 100;
  uint64 f0 = (uint64)bd_start_hz[bd.start] * 1000;
  uint64 f1 = (uint64)bd_stop_hz[bd.stop] * 1000;
  uint64 dec, f;
  int32  i, x, y, m;

  if(c < 0x30)
    c = 0x30;

  display_set_fg_color((c << 16) | (c << 8) | c);

  for(i = 0; i <= BD_DIVS_Y; i++)
    display_draw_horz_dots(BD_Y0 + ((i * BD_H) / BD_DIVS_Y), BD_X0, BD_X1, 4);

  display_draw_vert_dots(BD_X0, BD_Y0, BD_Y1, 3);
  display_draw_vert_dots(BD_X1, BD_Y0, BD_Y1, 3);

  //Decades (dots every 3 px) and the 2 and 5 of each decade (every 8 px)
  for(dec = 1000; dec <= f1; dec *= 10)
  {
    for(m = 1; m <= 9; m++)
    {
      f = dec * m;

      if((f < f0) || (f > f1))
        continue;

      if((m == 1) || (m == 2) || (m == 5))
        display_draw_vert_dots(bd_freq_x(f), BD_Y0, BD_Y1, (m == 1) ? 3 : 8);
    }
  }

  //Labels: gain left, phase right, frequency under the decades
  display_set_font(&font_2);

  for(i = 0; i <= BD_DIVS_Y; i++)
  {
    y = BD_Y0 + ((i * BD_H) / BD_DIVS_Y) - 6;

    if(y < 49)
      y = 49;

    if(bd.display != 2)
    {
      p = bd_signed(t, (BD_GAIN_TOP - (i * BD_GAIN_DIV)) / 100, 1, 0);

      if(i == 0)
        bd_str(p, " dB");

      display_set_fg_color(BD_GAIN_COLOR);
      x = BD_X0 - 4 - bd_text_width(t);
      display_text((x < 4) ? 4 : x, y, (int8 *)t);
    }

    if(bd.display != 1)
    {
      bd_signed(t, (BD_PHASE_TOP - (i * BD_PHASE_DIV)) / 1000, 1, 0);
      display_set_fg_color(BD_PHASE_COLOR);
      display_text(BD_X1 + 4, y, (int8 *)t);
    }
  }

  display_set_fg_color(BD_TEXT_COLOR);

  for(dec = 1000; dec <= f1; dec *= 10)
  {
    if(dec < f0)
      continue;

    bd_freq(t, dec, 1);
    x = bd_freq_x(dec) - (bd_text_width(t) / 2);

    if(x < 4) x = 4;
    if((x + (int32)bd_text_width(t)) > 727) x = 727 - bd_text_width(t);

    display_text(x, BD_Y1 + 4, (int8 *)t);
  }
}

//The measured points joined by lines; points that failed a check are drawn as grey dots and not joined
static void bd_draw_curve(int32 *val, int phase, uint32 color)
{
  int    i, have = 0;
  int32  x, y, px = 0, py = 0;

  for(i = 0; i < bd.n; i++)
  {
    if(!bd_ok[i])
    {
      have = 0;
      continue;
    }

    x = bd_freq_x(bd_f[i]);
    y = phase ? bd_phase_y(val[i]) : bd_gain_y(val[i]);

    if(bd_ok[i] == 2)
    {
      display_set_fg_color(0x00707070);
      display_fill_rect(x - 1, y - 1, 3, 3);
      have = 0;
      continue;
    }

    display_set_fg_color(color);

    //Phase jumps of more than 180 degrees (the wrap) are not joined
    if(have && (!phase || (((val[i] - val[i - 1]) < 180000) && ((val[i - 1] - val[i]) < 180000))))
      display_draw_line(px, py, x, y);

    display_fill_rect(x - 1, y - 1, 3, 3);

    px = x;
    py = y;
    have = 1;
  }
}

//v1.00t8: markers as MCP (bode_markers_find): the -3 dB crossings (of the passband level: the first point for a low
//pass, the last for a high pass, the peak for a resonance), the peak, and the phase crossings of -45 / -90 (+45 / +90
//for a high pass). Crossings are interpolated in log f between the two points around them.
typedef struct
{
  uint8  n3db;
  uint8  have_peak;
  uint8  nph;
  int32  ref;              //centi-dB, the -3 dB reference
  uint64 f3db[2];
  int32  peak;
  uint64 fpeak;
  uint64 fph[3];
  int32  ph[3];            //the phase of each crossing (milli-degrees)
  uint8  shape;            //v1.00t9: 1 low pass, 2 high pass, 3 resonance
} BODEMARKERS;

static BODEMARKERS bd_mk;

//Frequency at fraction t (Q16) between fa and fb on the log axis
static uint64 bd_log_interp(uint64 fa, uint64 fb, int32 t_q16)
{
  int32 la = fx_log2_q16(fa), lb = fx_log2_q16(fb);

  return((uint64)bd_exp2_q16(la + (int32)(((int64)(lb - la) * t_q16) >> 16)));
}

//The crossing of 'level' between points a and b (values va, vb)
static uint64 bd_cross(int a, int b, int32 va, int32 vb, int32 level)
{
  int32 t = (va == vb) ? 0 : (int32)((((int64)(va - level)) << 16) / (va - vb));

  return(bd_log_interp(bd_f[a], bd_f[b], t));
}

static void bd_find_markers(void)
{
  int    i, prev, first = -1, last = -1, peak = -1;
  int32  pk = -10000000, level, target[3];

  bd_mk.n3db = bd_mk.have_peak = bd_mk.nph = bd_mk.shape = 0;

  for(i = 0; i < bd.n; i++)
  {
    if(bd_ok[i] != 1)
      continue;

    if(first < 0)
      first = i;

    last = i;

    if(bd_gain[i] > pk)
    {
      pk   = bd_gain[i];
      peak = i;
    }
  }

  if(first < 0)
    return;

  //The shape: a peak above both ends is a resonance, a low end below the high end a high pass, else a low pass
  if((pk > (bd_gain[first] + 100)) && (pk > (bd_gain[last] + 100)))
  {
    bd_mk.ref = pk;
    bd_mk.have_peak = 1;
    bd_mk.shape = 3;
  }
  else if(bd_gain[first] < (bd_gain[last] - 300))
  {
    bd_mk.ref = bd_gain[last];
    bd_mk.shape = 2;
  }
  else
  {
    bd_mk.ref = bd_gain[first];
    bd_mk.shape = 1;
  }

  bd_mk.peak  = pk;
  bd_mk.fpeak = bd_f[peak];

  //-3 dB crossings, at most two
  level = bd_mk.ref - 300;

  for(i = first + 1, prev = first; (i <= last) && (bd_mk.n3db < 2); i++)
  {
    if(bd_ok[i] != 1)
      continue;

    if(((bd_gain[prev] >= level) && (bd_gain[i] < level)) || ((bd_gain[prev] < level) && (bd_gain[i] >= level)))
      bd_mk.f3db[bd_mk.n3db++] = bd_cross(prev, i, bd_gain[prev], bd_gain[i], level);

    prev = i;
  }

  //Phase crossings: -45 / -90 / -180, or +45 / +90 / +180 when the phase starts positive (high pass). The phase is
  //unwrapped point by point (a step of more than 180 degrees is a wrap), so the 180 degree crossing is found too.
  target[0] = (bd_phase[first] > 0) ? 45000 : -45000;
  target[1] = (bd_phase[first] > 0) ? 90000 : -90000;
  target[2] = (bd_phase[first] > 0) ? 180000 : -180000;

  for(level = 0; level < 3; level++)
  {
    int32 pa, pb, unwrap = 0;

    for(i = first + 1, prev = first; i <= last; i++)
    {
      if(bd_ok[i] != 1)
        continue;

      pa = bd_phase[prev] + unwrap;
      pb = bd_phase[i] + unwrap;

      if((pb - pa) > 180000)
      {
        pb -= 360000;
        unwrap -= 360000;
      }
      else if((pa - pb) > 180000)
      {
        pb += 360000;
        unwrap += 360000;
      }

      if(((pa >= target[level]) && (pb < target[level])) || ((pa < target[level]) && (pb >= target[level])))
      {
        bd_mk.fph[bd_mk.nph] = bd_cross(prev, i, pa, pb, target[level]);
        bd_mk.ph[bd_mk.nph]  = target[level];
        bd_mk.nph++;
        break;
      }

      prev = i;
    }
  }
}

//A white triangle pointing down at (x, y) with a small label in 'color' right of it
static void bd_marker(int32 x, int32 y, const char *label, uint32 color)
{
  int32 i, w;

  if(x < (BD_X0 + 5)) x = BD_X0 + 5;
  if(x > (BD_X1 - 5)) x = BD_X1 - 5;
  if(y < (BD_Y0 + 8)) y = BD_Y0 + 8;

  display_set_fg_color(WHITE_COLOR);

  for(i = 0; i < 6; i++)
    display_draw_horz_line(y - 2 - i, x - i, x + i);

  display_set_font(&font_2);
  w = bd_text_width(label);

  //The label right of the triangle, left of it near the right edge
  display_set_fg_color(color);
  display_text(((x + 9 + w) < BD_X1) ? (x + 9) : (x - 9 - w), y - 16, (int8 *)label);
}

static void bd_draw_markers(void)
{
  char t[32], *p;
  int  i;

  if(bd.display != 2)
  {
    for(i = 0; i < bd_mk.n3db; i++)
    {
      p = bd_str(t, "-3dB ");
      bd_freq(p, bd_mk.f3db[i], 0);
      bd_marker(bd_freq_x(bd_mk.f3db[i]), bd_gain_y(bd_mk.ref - 300), t, BD_GAIN_COLOR);
    }

    if(bd_mk.have_peak)
    {
      p = bd_signed(t, bd_mk.peak, 100, 1);
      p = bd_str(p, " dB ");
      bd_freq(p, bd_mk.fpeak, 0);
      bd_marker(bd_freq_x(bd_mk.fpeak), bd_gain_y(bd_mk.peak), t, BD_GAIN_COLOR);
    }
  }

  if(bd.display != 1)
  {
    for(i = 0; i < bd_mk.nph; i++)
    {
      p = bd_signed(t, bd_mk.ph[i] / 1000, 1, 0);
      p = bd_str(p, " deg ");
      bd_freq(p, bd_mk.fph[i], 0);
      bd_marker(bd_freq_x(bd_mk.fph[i]), bd_phase_y(bd_mk.ph[i]), t, BD_PHASE_COLOR);
    }
  }
}

//v1.00t9: the readouts flow over the first two text lines (a box that does not fit goes to the next line), as MCP's
//Frequency response measurements: the sweep state, the cursor, Level, -3dB, BW, Peak, Q, Ph45, Ph90, Ph180, Sweep.
//The third line has the warning of the last point.
static int32 bd_fx;
static int   bd_fl;

static void bd_flow(const char *t, uint32 color)
{
  int32 w = bd_text_width(t) + 10;

  if(((bd_fx + w) > (BD_X1 + 36)) && (bd_fl < 1))
  {
    bd_fl++;
    bd_fx = BD_X0;
  }

  bd_fx = bd_box(bd_fx, bd_fl, t, color);
}

//v1.00u7: one cursor's values (frequency, gain, phase) in a box of its color
static void bd_cursor_value(int idx, const char *name, uint32 color)
{
  char t[64], *p;

  if(idx >= bd.n)
    return;

  p = bd_str(t, name);
  p = bd_freq(p, bd_f[idx] ? bd_f[idx] : bd_point_freq(idx), 0);

  if(bd_ok[idx])
  {
    p = bd_str(p, "  ");
    p = bd_signed(p, bd_gain[idx], 100, 1);
    p = bd_str(p, " dB  ");
    p = bd_signed(p, bd_phase[idx], 1000, 1);
    //bd_str(p, " deg");
    p = bd_str(p, " deg");

    //v1.00x0: signal to noise of CH2 at this point
    if(bd_snr[idx] != BD_SNR_UNKNOWN)
    {
      p = bd_str(p, "  SNR ");
      p = bd_signed(p, bd_snr[idx], 100, 0);
      bd_str(p, " dB");
    }
  }

  bd_flow(t, color);
}

static void bd_draw_readouts(void)
{
  char  t[64], *p;
  int   i;

  display_set_font(&font_2);

  bd_fx = BD_X0;
  bd_fl = 0;

  //v1.00u3: the Thru state as the first box of the line ("Thru on" green), at the plot's left edge like the others
  if(bd.thru_valid || bd.thru_measuring)
  {
    const char *th = bd.thru_measuring ? "Thru measuring" : !bd_thru_matches() ? "Thru stale" : bd.thru_on ? "Thru on" : "Thru off";

    bd_flow(th, (bd_thru_matches() && bd.thru_on && !bd.thru_measuring) ? GREEN_COLOR : BD_TEXT_COLOR);
  }

  //The sweep state
  p = t;

  if(bd_viewing)
    p = bd_str(p, "Saved ");

  if(bd.autostage)
    p = bd_str(p, "Auto set ");

  if(bd.thru_measuring)
    p = bd_str(p, "Thru ");

  if(bd.sweeping)
  {
    p = bd_str(p, "Sweep ");
    p = bd_uint(p, bd.idx + 1);
    p = bd_str(p, " / ");
    p = bd_uint(p, bd.n);
    p = bd_str(p, "  ");
    bd_freq(p, bd_f[bd.idx], 0);
  }
  else
  {
    p = bd_str(p, (bd.measured ? "Done " : "Ready"));

    if(bd.measured)
    {
      p = bd_uint(p, bd.measured);
      bd_str(p, " points");
    }
  }

  bd_flow(t, BD_TEXT_COLOR);

  //(v1.00u7: the cursors are on the second line, bd_draw_cursor_values)

  if(bd_mk.shape)
  {
    //Level: the passband level (or the peak of a resonance), the -3 dB reference
    p = bd_str(t, "Level ");
    p = bd_signed(p, bd_mk.ref, 100, 1);
    bd_str(p, " dB");
    bd_flow(t, BD_GAIN_COLOR);

    //-3dB crossings
    p = bd_str(t, "-3dB ");

    if(bd_mk.n3db)
    {
      p = bd_freq(p, bd_mk.f3db[0], 0);

      if(bd_mk.n3db > 1)
      {
        p = bd_str(p, " / ");
        bd_freq(p, bd_mk.f3db[1], 0);
      }
    }
    else
      bd_str(p, "--");

    bd_flow(t, BD_GAIN_COLOR);

    //BW: between the two crossings, or from DC to the corner of a low pass
    p = bd_str(t, "BW ");

    if(bd_mk.n3db == 2)
      bd_freq(p, bd_mk.f3db[1] - bd_mk.f3db[0], 0);
    else if((bd_mk.n3db == 1) && (bd_mk.shape == 1))
      bd_freq(p, bd_mk.f3db[0], 0);
    else
      bd_str(p, "--");

    bd_flow(t, BD_GAIN_COLOR);

    //Peak and Q (a resonance with both crossings)
    if(bd_mk.have_peak)
    {
      p = bd_str(t, "Peak ");
      p = bd_signed(p, bd_mk.peak, 100, 1);
      p = bd_str(p, " dB @ ");
      bd_freq(p, bd_mk.fpeak, 0);
      bd_flow(t, BD_GAIN_COLOR);

      p = bd_str(t, "Q ");

      if((bd_mk.n3db == 2) && (bd_mk.f3db[1] > bd_mk.f3db[0]))
      {
        uint64 q100 = (bd_mk.fpeak * 100) / (bd_mk.f3db[1] - bd_mk.f3db[0]);

        bd_fixed(p, (uint32)(q100 / 100), (uint32)(q100 % 100), 2, 0);
      }
      else
        bd_str(p, "--");

      bd_flow(t, BD_GAIN_COLOR);
    }

    //Phase crossings
    for(i = 0; i < bd_mk.nph; i++)
    {
      p = bd_str(t, "Ph");
      p = bd_signed(p, bd_mk.ph[i] / 1000, 1, 0);
      p = bd_str(p, " ");
      bd_freq(p, bd_mk.fph[i], 0);
      bd_flow(t, BD_PHASE_COLOR);
    }
  }

  //v1.00u2: the Thru state is in the left margin (bd_draw_readouts start)

  //Duration of the last full sweep
  if(bd.sweep_ms)
  {
    p = bd_str(t, "Sweep ");
    p = bd_fixed(p, bd.sweep_ms / 1000, (bd.sweep_ms % 1000) / 100, 1, 0);
    bd_str(p, " s");
    bd_flow(t, BD_TEXT_COLOR);
  }

  //v1.00u7: cursors C1 (orange), C2 (magenta) and C2 - C1 (white) on the second line
  if(bd.cursor_on)
  {
    if(bd_fl == 0)
    {
      bd_fl = 1;
      bd_fx = BD_X0;
    }

    bd_cursor_value(bd.cursor, "C1 ", BD_CURSOR_COLOR);
    bd_cursor_value(bd.cursor2, "C2 ", BD_CURSOR2_COLOR);

    if((bd.cursor < bd.n) && (bd.cursor2 < bd.n) && (bd_ok[bd.cursor] == 1) && (bd_ok[bd.cursor2] == 1))
    {
      uint64 f1 = bd_f[bd.cursor], f2 = bd_f[bd.cursor2];
      int32  dph = bd_phase[bd.cursor2] - bd_phase[bd.cursor];

      while(dph > 180000)   dph -= 360000;
      while(dph <= -180000) dph += 360000;

      p = bd_str(t, "C2-C1 ");

      if(f2 < f1)
        p = bd_str(p, "-");

      p = bd_freq(p, (f2 >= f1) ? (f2 - f1) : (f1 - f2), 0);
      p = bd_str(p, "  ");
      p = bd_signed(p, bd_gain[bd.cursor2] - bd_gain[bd.cursor], 100, 1);
      p = bd_str(p, " dB  ");
      p = bd_signed(p, dph, 1000, 1);
      p = bd_str(p, " deg");

      //v1.00v1: the slope between the cursors in dB per decade (-20 for a first order, -40 for a second order roll-off)
      if(f1 != f2)
      {
        int32 dl = fx_log2_q16(f2) - fx_log2_q16(f1);          //log2(f2 / f1) in Q16
        int32 slope = (int32)(((int64)(bd_gain[bd.cursor2] - bd_gain[bd.cursor]) * 217706) / dl);   //217706 = log2(10) Q16

        p = bd_str(p, "  ");
        p = bd_signed(p, slope, 100, 1);
        bd_str(p, " dB/dec");
      }

      bd_flow(t, WHITE_COLOR);
    }
  }

  //Warning of the last point on the second line after the readouts that went there
  if(bd.warn)
  {
    bd_box((bd_fl == 1) ? bd_fx : BD_X0, 1, (bd.warn & BD_WARN_CLIPPED) ? "Clipped: coarser V/div or CH range Auto" :
                     (bd.warn & BD_WARN_CH1_LOW) ? "CH1 level low: CH1 on the DUT input?" :
                     (bd.warn & BD_WARN_UNSETTLED) ? "Not settled: longer Settle" :     //v1.00w9
                     (bd.warn & BD_WARN_CH2_SMALL) ? "CH2 small: finer V/div or CH range Auto" :
                                                   "CH2 near noise (SNR < 12 dB)", RED_COLOR);   //v1.00x0
  }
}

//v1.00u7: two cursors, C1 orange and C2 magenta, each with its name at the top of the plot
static void bd_draw_one_cursor(int idx, const char *name, uint32 color)
{
  int32 x;

  if(idx >= bd.n)
    return;

  x = bd_freq_x(bd_f[idx] ? bd_f[idx] : bd_point_freq(idx));

  display_set_fg_color(color);
  display_draw_vert_dashes(x, BD_Y0, BD_Y1, 3, 3);

  //(v1.00u8: no C1 / C2 name on the plot, the color tells them apart)
  (void)name;
}

static void bd_draw_cursor(void)
{
  if(!bd.cursor_on)
    return;

  bd_draw_one_cursor(bd.cursor, "C1", BD_CURSOR_COLOR);
  bd_draw_one_cursor(bd.cursor2, "C2", BD_CURSOR2_COLOR);
}

//v1.00t7: the start hint in the middle of the grid
static void bd_hint_line(int32 y, const char *t, uint32 color)
{
  display_set_fg_color(color);
  display_text(BD_X0 + ((BD_W - (int32)bd_text_width(t)) / 2), y, (int8 *)t);
}

static void bd_draw_hint(void)
{
  int32 cy = BD_Y0 + (BD_H / 2);

  //A dark box behind the text, so the grid does not run through it
  display_set_fg_color(BD_BOX_FILL);
  display_fill_rounded_rect(BD_X0 + 90, cy - 70, BD_W - 180, 140, 6);
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(BD_X0 + 90, cy - 70, BD_W - 180, 140, 6);

  display_set_font(&font_5);
  bd_hint_line(cy - 58, "Press RUN or AUTO SET", WHITE_COLOR);

  display_set_font(&font_3);
  bd_hint_line(cy - 18, "Generator (calibration pin) -> circuit input and CH1", BD_TEXT_COLOR);
  bd_hint_line(cy + 4,  "CH2 -> circuit output", BD_GAIN_COLOR);
  bd_hint_line(cy + 26, "Probe grounds -> circuit ground, probes at 1X", BD_TEXT_COLOR);
  bd_hint_line(cy + 48, "Passive or buffered circuits only", ORANGE_COLOR);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Buttons under the plot and their value lists (as spectrum.c)

static int bd_option_count(int b)
{
  switch(b)
  {
    case BD_BTN_START:   return(BD_COUNT(bd_start_hz));
    case BD_BTN_STOP:    return(BD_COUNT(bd_stop_hz));
    case BD_BTN_POINTS:  return(BD_COUNT(bd_points) + 2);   //v1.00w8: + Repeat / Single
    case BD_BTN_SETTLE:  return(BD_COUNT(bd_settle_periods));
    case BD_BTN_RANGE:   return(2);
    case BD_BTN_DISPLAY: return(3);
    case BD_BTN_THRU:    return(3);
    default:             return(0);
  }
}

static int bd_option_current(int b)
{
  switch(b)
  {
    case BD_BTN_START:   return(bd.start);
    case BD_BTN_STOP:    return(bd.stop);
    case BD_BTN_POINTS:  return(bd.points);
    case BD_BTN_SETTLE:  return(bd.settle);
    case BD_BTN_RANGE:   return(bd.range);
    case BD_BTN_DISPLAY: return(bd.display);
    case BD_BTN_THRU:    return(!bd.thru_valid ? -1 : bd.thru_on ? 1 : 2);
    default:             return(-1);
  }
}

static void bd_option_text(int b, int i, char *t)
{
  switch(b)
  {
    case BD_BTN_START:   bd_freq(t, (uint64)bd_start_hz[i] * 1000, 1); break;
    case BD_BTN_STOP:    bd_freq(t, (uint64)bd_stop_hz[i] * 1000, 1);  break;
    //case BD_BTN_POINTS:  bd_uint(t, bd_points[i]);                     break;
    case BD_BTN_POINTS:  //v1.00w8: the point counts, then the sweep mode rows
      if(i < BD_COUNT(bd_points))
        bd_uint(t, bd_points[i]);
      else
        bd_str(t, (i == BD_COUNT(bd_points)) ? "Repeat" : "Single");
      break;
    case BD_BTN_SETTLE:  bd_str(t, bd_settle_names[i]);                break;
    case BD_BTN_RANGE:   bd_str(t, bd_range_names[i]);                 break;
    case BD_BTN_DISPLAY: bd_str(t, bd_display_names[i]);               break;
    case BD_BTN_THRU:    bd_str(t, bd_thru_names[i]);                  break;
    default:             bd_str(t, "Points");                          break;
  }
}

static void bd_option_set(int b, int i)
{
  //v1.00u1: Thru: Measure (both probes on the DUT input, one sweep), On, Off
  if(b == BD_BTN_THRU)
  {
    int k;

    switch(i)
    {
      case 0:
        bd.thru_measuring = 1;
        bd.autostage      = 0;

        if(!scopesettings.runstate)
        {
          scopesettings.runstate = 1;
          display_set_screen_buffer((uint16 *)maindisplaybuffer);
          scope_run_stop_text();

          if(scopesettings.rightmenustate == 0)
            scope_run_stop_button(0);
        }

        bd_sweep_start();
        return;

      case 1:
        bd.thru_on = bd.thru_valid;
        break;

      case 2:
        bd.thru_on = 0;
        break;

      default:
        break;
    }

    //On and Off: a new chart
    bd.autostage = 0;
    bd.measured  = 0;

    for(k = 0; k < BD_MAX_POINTS; k++)
      bd_ok[k] = 0;

    if(scopesettings.runstate)
      bd_sweep_start();
    else
      bd.sweeping = 0;

    return;
  }

  //v1.00w8: sweep mode rows under Points: only the mode changes, the chart and a running sweep stay
  if((b == BD_BTN_POINTS) && (i >= BD_COUNT(bd_points)))
  {
    bd.single = (i > BD_COUNT(bd_points)) ? 1 : 0;
    return;
  }

  switch(b)
  {
    case BD_BTN_START:   bd.start   = i; break;
    case BD_BTN_STOP:    bd.stop    = i; break;
    case BD_BTN_POINTS:  bd.points  = i; break;
    case BD_BTN_SETTLE:  bd.settle  = i; break;
    case BD_BTN_RANGE:   bd.range   = i; break;
    case BD_BTN_DISPLAY: bd.display = i; return;
  }

  //A new span or table: the sweep starts again (when running)
  bd.autostage = 0;

  if(scopesettings.runstate)
    bd_sweep_start();
  else
  {
    bd.sweeping = 0;
    bd.measured = 0;

    for(i = 0; i < BD_MAX_POINTS; i++)
      bd_ok[i] = 0;
  }
}

static void bd_draw_button(int b, int active)
{
  char   t[24];
  uint32 x = BD_BTN_X0 + (b * BD_BTN_PITCH);

  display_set_fg_color(active ? ITEM_ACTIVE_COLOR : DARKGREY_COLOR);
  display_fill_rounded_rect(x, BD_BTN_Y, BD_BTN_W, BD_BTN_H, 3);
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(x, BD_BTN_Y, BD_BTN_W, BD_BTN_H, 3);

  //v1.00v7: grey text on the buttons that do nothing while a saved file is shown (only Display does)
  int off = bd_viewing && (b != BD_BTN_DISPLAY);

  display_set_font(&font_2);
  display_set_fg_color(active ? BLACK_COLOR : off ? 0x00606060 : BD_TEXT_COLOR);
  display_text(x + ((BD_BTN_W - bd_text_width(bd_btn_names[b])) / 2), BD_BTN_Y + 3, (int8 *)bd_btn_names[b]);

  if(b == BD_BTN_THRU)
    bd_str(t, bd.thru_measuring ? "Meas." : !bd.thru_valid ? "None" : !bd_thru_matches() ? "Stale" : bd.thru_on ? "On" : "Off");
  else
    bd_option_text(b, bd_option_current(b), t);

  //v1.00w8: single sweep shown next to the point count
  if((b == BD_BTN_POINTS) && bd.single)
  {
    char *e = t;

    while(*e)
      e++;

    bd_str(e, " Single");
  }

  display_set_font(&font_3);
  display_set_fg_color(active ? BLACK_COLOR : off ? 0x00707070 : WHITE_COLOR);
  display_text(x + ((BD_BTN_W - bd_text_width(t)) / 2), BD_BTN_Y + 19, (int8 *)t);
}

static void bd_draw_buttons(void)
{
  int b;

  for(b = 0; b < BD_BTN_COUNT; b++)
    bd_draw_button(b, 0);
}

static void bd_list_rect(int b, uint32 *x, uint32 *y, uint32 *h)
{
  //v1.00x1: y worked out signed. With 16 Start entries (v1.00w7) BD_BTN_Y - 4 - h went below 0, the unsigned y wrapped
  //to a huge value, the clamp below did not catch it and the list was drawn (and touched) off the screen.
  int32 ys;

  *h = bd_option_count(b) * BD_LIST_ROW_H;
  //*y = BD_BTN_Y - 4 - *h;
  ys = (int32)BD_BTN_Y - 4 - (int32)*h;
  *x = BD_BTN_X0 + (b * BD_BTN_PITCH);

  //Long lists start lower than the text lines
  //if(*y < 48)
  //  *y = 48;
  if(ys < 48)
    ys = 48;

  *y = (uint32)ys;
}

static void bd_draw_list(int b, int touched)
{
  char   t[24];
  uint32 x, y, h;
  int    i, n = bd_option_count(b), cur = bd_option_current(b);
  int    rowh = BD_LIST_ROW_H;

  bd_list_rect(b, &x, &y, &h);

  if((y + h) > (BD_BTN_Y - 4))
    rowh = (BD_BTN_Y - 4 - y) / n;

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(x, y, BD_BTN_W, n * rowh);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rect(x, y, BD_BTN_W, n * rowh);

  display_set_font(&font_3);

  for(i = 0; i < n; i++)
  {
    uint32 ry = y + (i * rowh);

    if(i == touched)
    {
      display_set_fg_color(ITEM_ACTIVE_COLOR);
      display_fill_rect(x + 1, ry + 1, BD_BTN_W - 2, rowh - 2);
    }

    if(i)
    {
      display_set_fg_color(BLACK_COLOR);
      display_draw_horz_line(ry, x + 6, x + BD_BTN_W - 6);
    }

    bd_option_text(b, i, t);
    //v1.00w8: under Points also the selected sweep mode row is marked
    int sel = (i == cur) || ((b == BD_BTN_POINTS) && (i == (BD_COUNT(bd_points) + bd.single)));

    display_set_fg_color((i == touched) ? BLACK_COLOR : sel ? CHANNEL1_COLOR : WHITE_COLOR);
    display_text(x + ((BD_BTN_W - bd_text_width(t)) / 2), ry + ((rowh - 16) / 2), (int8 *)t);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void bode_set_active(int on)
{
  if(on && !bd.active)
  {
    //Save what the view changes
    bd_saved.timeperdiv     = scopesettings.timeperdiv;
    bd_saved.runstate       = scopesettings.runstate;
    bd_saved.triggermode    = scopesettings.triggermode;
    bd_saved.triggerchannel = scopesettings.triggerchannel;
    bd_saved.ch1vpd         = scopesettings.channel1.displayvoltperdiv;
    bd_saved.ch2vpd         = scopesettings.channel2.displayvoltperdiv;
    bd_saved.ch1enable      = scopesettings.channel1.enable;
    bd_saved.ch2enable      = scopesettings.channel2.enable;
    bd_saved.gen_enable     = fpgasettings.gen_enable;
    bd_saved.gen_freq       = fpgasettings.gen_freq;
    bd_saved.gen_duty       = fpgasettings.gen_duty;
    bd_saved.tvp            = scopesettings.triggerverticalposition;
    bd_saved.ch1tvp         = scopesettings.channel1.triggerverticalposition;
    bd_saved.ch2tvp         = scopesettings.channel2.triggerverticalposition;
    bd_saved.thp            = scopesettings.triggerhorizontalposition;

    bd.active = 1;

    //v1.00y6: the start hint once per entry (unless switched off in Settings)
    bd_hint_pending = !scopesettings.bodehint_off;

    //Both channels on, auto trigger on CH1, short time base, nothing driven before a sweep starts
    scopesettings.channel1.enable = 1;
    scopesettings.channel2.enable = 1;
    fpga_set_channel_enable(&scopesettings.channel1);
    fpga_set_channel_enable(&scopesettings.channel2);

    scopesettings.triggerchannel = 0;
    fpga_set_trigger_channel();

    display_set_screen_buffer((uint16 *)maindisplaybuffer);
    set_trigger_mode(0);
    scope_trigger_settings(0);

    if(scopesettings.long_mode)
    {
      scopesettings.timeperdiv = 23;      //20 us/div, 5 MSa/s
      scope_set_timebase();
    }

    bd.sweeping  = 0;
    bd.autostage = 0;

    //v1.00t5: the view opens in STOP (set_trigger_mode above set RUN): nothing is swept or driven before RUN or AUTO SET
    scopesettings.runstate = 0;
    scope_run_stop_text();

    if(scopesettings.rightmenustate == 0)
      scope_run_stop_button(0);
  }
  else if(!on && bd.active)
  {
    bd.active    = 0;
    bd.sweeping  = 0;
    bd.autostage = 0;

    //Put the scope back as it was
    display_set_screen_buffer((uint16 *)maindisplaybuffer);

    scopesettings.channel1.displayvoltperdiv = bd_saved.ch1vpd;
    scopesettings.channel2.displayvoltperdiv = bd_saved.ch2vpd;
    match_volt_per_div_settings(&scopesettings.channel1);
    match_volt_per_div_settings(&scopesettings.channel2);
    scopesettings.channel1.enable = bd_saved.ch1enable;
    scopesettings.channel2.enable = bd_saved.ch2enable;
    fpga_set_channel_enable(&scopesettings.channel1);
    fpga_set_channel_enable(&scopesettings.channel2);
    scope_channel_settings(&scopesettings.channel1, 0);
    scope_channel_settings(&scopesettings.channel2, 0);

    //v1.00u5: always set the time base with the scope "running": scope_set_timebase only writes the sample rate to the
    //FPGA in RUN, and the view often ends in STOP, so the scope kept the sweep's last sample rate (artifacts, no signal
    //until the time base was changed by hand). The saved RUN / STOP state is put back below.
    scopesettings.timeperdiv = bd_saved.timeperdiv;
    scopesettings.runstate   = 1;
    scope_set_timebase();

    scopesettings.triggerchannel = bd_saved.triggerchannel;
    fpga_set_trigger_channel();

    //v1.00t6: trigger level and horizontal position as they were
    scopesettings.triggerverticalposition          = bd_saved.tvp;
    scopesettings.channel1.triggerverticalposition = bd_saved.ch1tvp;
    scopesettings.channel2.triggerverticalposition = bd_saved.ch2tvp;
    scopesettings.triggerhorizontalposition        = bd_saved.thp;
    fpga_set_trigger_level();

    set_trigger_mode(bd_saved.triggermode);
    scopesettings.runstate = bd_saved.runstate;
    scope_run_stop_text();

    if(scopesettings.rightmenustate == 0)
      scope_run_stop_button(0);

    scope_trigger_settings(0);

    fpgasettings.gen_enable = bd_saved.gen_enable;
    fpgasettings.gen_freq   = bd_saved.gen_freq;
    fpgasettings.gen_duty   = bd_saved.gen_duty;
    fpga_on_off_generator();
  }

  //v1.00y3: ACQ, Move and T grey while the view is active, normal again after it
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  scope_acqusition_settings(0);
  scope_move_speed(0);
  scope_trigger_settings(0);

  //v1.00y5: V CURSOR grey too (when the right bar shows the basic buttons)
  if(scopesettings.rightmenustate == 0)
    scope_v_cursor_button(0);
}

//v1.00z4: power off in this view: the scope settings saved on the view's entry back in scopesettings (RAM only, no
//FPGA, no screen), so the settings sector gets the scope's own time base, V/div, trigger and generator
void bode_settings_for_save(void)
{
  if(!bd.active)
    return;

  scopesettings.channel1.displayvoltperdiv = bd_saved.ch1vpd;
  scopesettings.channel1.samplevoltperdiv  = bd_saved.ch1vpd;
  scopesettings.channel2.displayvoltperdiv = bd_saved.ch2vpd;
  scopesettings.channel2.samplevoltperdiv  = bd_saved.ch2vpd;
  scopesettings.channel1.enable = bd_saved.ch1enable;
  scopesettings.channel2.enable = bd_saved.ch2enable;

  scopesettings.timeperdiv = bd_saved.timeperdiv;
  scopesettings.samplerate = time_per_div_sample_rate[scopesettings.timeperdiv];
  scopesettings.long_mode  = (scopesettings.timeperdiv < 11) ? 1 : 0;

  scopesettings.triggermode    = bd_saved.triggermode;
  scopesettings.triggerchannel = bd_saved.triggerchannel;
  scopesettings.triggerverticalposition          = bd_saved.tvp;
  scopesettings.channel1.triggerverticalposition = bd_saved.ch1tvp;
  scopesettings.channel2.triggerverticalposition = bd_saved.ch2tvp;
  scopesettings.triggerhorizontalposition        = bd_saved.thp;
  scopesettings.runstate = bd_saved.runstate;

  fpgasettings.gen_enable = bd_saved.gen_enable;
  fpgasettings.gen_freq   = bd_saved.gen_freq;
  fpgasettings.gen_duty   = bd_saved.gen_duty;
}

int bode_is_active(void)
{
  return(bd.active);
}

void bode_new_record(void)
{
  bd.newrecord = 1;
}

void bode_toggle_cursor(void)
{
  bd.cursor_on ^= 1;
}

static void bd_draw_refs(void);     //v1.00y3

void bode_display(void)
{
  static uint8 busy = 0;

  //v1.00t4: a time base change inside a step redraws the screen through scope_preset_values, which calls this again:
  //that nested call does nothing
  if(busy)
    return;

  busy = 1;

  //The sweep takes its step first (a new record may finish a point); v1.00v3: not while a saved file is shown
  if(!bd_viewing)
  {
    if(bd.active && !bd.sweeping && !bd.autostage && scopesettings.runstate && !bd.measured)
      bd_sweep_start();

    bd_sweep_step();

    //A STOP / RUN in the middle: RUN goes on where the sweep stopped, after a finished sweep it starts a new one
    if(scopesettings.runstate && !bd.sweeping && !bd.autostage && (bd.measured >= bd.n) && bd.n)
      bd_sweep_begin(1);
  }

  display_set_screen_buffer(displaybuffertmp);

  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(2, 48, 728, 432);

  bd_draw_grid();

  //v1.00y3: shown reference curves under the live ones
  bd_draw_refs();

  if(bd.display != 2)
    bd_draw_curve(bd_gain, 0, BD_GAIN_COLOR);

  if(bd.display != 1)
    bd_draw_curve(bd_phase, 1, BD_PHASE_COLOR);

  //v1.00u6: no markers and no values during the AUTO SET overview (its wide span showed markers, e.g. a -90 degree
  //crossing at MHz, that the final sweep's narrower span does not contain); they come with the final sweep
  bd_find_markers();

  if(bd.autostage == 1)
    bd_mk.shape = bd_mk.n3db = bd_mk.have_peak = bd_mk.nph = 0;

  if(!bd_markers_hidden)
    bd_draw_markers();

  bd_draw_cursor();
  bd_draw_readouts();
  bd_draw_buttons();

  //v1.00t7: before the first sweep, how to start and how to connect, in the middle of the grid (gone with the sweep)
  //if(!bd.measured && !bd.sweeping && !bd.autostage && !bd_viewing)
  //v1.00y6: only once after entering the view, until the first touch or sweep (not again after a setting change), and
  //not at all when switched off in Settings
  if(bd_hint_pending && !bd.measured && !bd.sweeping && !bd.autostage && !bd_viewing)
    bd_draw_hint();

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(2, 48, 728, 432);

  busy = 0;
}

void bode_handle_touch(void)
{
  bd_hint_pending = 0;     //v1.00y6: the first touch ends the start hint
  int    b = -1, i;
  uint32 x, y, h;

  //Buttons under the plot
  if((ytouch >= BD_BTN_Y) && (ytouch <= (BD_BTN_Y + BD_BTN_H)) && (xtouch >= BD_BTN_X0))
  {
    b = (xtouch - BD_BTN_X0) / BD_BTN_PITCH;

    if((b >= BD_BTN_COUNT) || (((xtouch - BD_BTN_X0) % BD_BTN_PITCH) > BD_BTN_W))
      b = -1;
  }

  //Cursors (v1.00u7: two): a touch in the plot takes the nearer cursor, a drag moves it, snapping to the points
  //v1.00u8: also a touch up to 20 px left / right of the plot (a cursor on an edge point)
  if((b < 0) && bd.cursor_on && (xtouch >= (BD_X0 - 20)) && (xtouch <= (BD_X1 + 20)) && (ytouch >= BD_Y0) && (ytouch <= BD_Y1))
  {
    uint8 *cur;
    int32  d1 = (bd.cursor < bd.n) ? ((int32)xtouch - bd_freq_x(bd_f[bd.cursor] ? bd_f[bd.cursor] : bd_point_freq(bd.cursor))) : 100000;
    int32  d2 = (bd.cursor2 < bd.n) ? ((int32)xtouch - bd_freq_x(bd_f[bd.cursor2] ? bd_f[bd.cursor2] : bd_point_freq(bd.cursor2))) : 100000;

    if(d1 < 0) d1 = -d1;
    if(d2 < 0) d2 = -d2;

    cur = (d2 < d1) ? &bd.cursor2 : &bd.cursor;

    while(havetouch)
    {
      int32 best = 100000, d;
      int32 before = *cur;

      for(i = 0; i < bd.n; i++)
      {
        d = (int32)xtouch - bd_freq_x(bd_f[i] ? bd_f[i] : bd_point_freq(i));

        if(d < 0)
          d = -d;

        if(d < best)
        {
          best = d;
          *cur = i;
        }
      }

      //v1.00v1: the cursors always move alone here (owner's choice, as MCP): Lock move cursors is for the scope only
      (void)before;

      bode_display();
      tp_i2c_read_status();
    }

    return;
  }

  //v1.00v3: a saved file shown: only Display (the other settings belong to a sweep)
  if(bd_viewing && (b != BD_BTN_DISPLAY))
    b = -1;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  if(b >= 0)
    bd_draw_button(b, 1);

  tp_i2c_wait_for_touch_release();

  if(b < 0)
    return;

  //(v1.00u1: Clear chart is in the Thru list)
  {
    bd_draw_list(b, -1);
    bd_list_rect(b, &x, &y, &h);

    if((y + h) > (BD_BTN_Y - 4))
      h = ((BD_BTN_Y - 4 - y) / bd_option_count(b)) * bd_option_count(b);

    while(1)
    {
      tp_i2c_read_status();

      if(havetouch)
      {
        if((xtouch >= x) && (xtouch < (x + BD_BTN_W)) && (ytouch >= y) && (ytouch < (y + h)))
        {
          i = (ytouch - y) / (h / bd_option_count(b));

          bd_draw_list(b, i);
          tp_i2c_wait_for_touch_release();
          bd_option_set(b, i);
        }
        else
          tp_i2c_wait_for_touch_release();

        break;
      }
    }
  }

  bode_display();
}

//v1.00u2: the right bar's MEASURES button is Clear chart in this view
void bode_clear_chart(void)
{
  int i;

  bd.autostage = 0;
  bd.measured  = 0;

  for(i = 0; i < BD_MAX_POINTS; i++)
    bd_ok[i] = 0;

  if(scopesettings.runstate)
    bd_sweep_start();
  else
    bd.sweeping = 0;
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00v2: the settings of the view in the settings sector (BODE_SETTING_OFFSET, 7 words), so they stay after power off

//#define BD_SETTINGS_MAGIC   0xB0DE
#define BD_SETTINGS_MAGIC_OLD   0xB0DE      //v1.00w7: start index 3 lower
#define BD_SETTINGS_MAGIC       0xB0DF      //v1.00w7: 1 Hz .. 10 MHz tables

void bode_settings_save(uint16 *ptr)
{
  ptr[0] = BD_SETTINGS_MAGIC;
  ptr[1] = bd.start;
  ptr[2] = bd.stop;
  ptr[3] = bd.points;
  ptr[4] = bd.settle;
  ptr[5] = bd.range;
  ptr[6] = bd.display;
  ptr[7] = bd.single;     //v1.00w8 (8th and last word of the Bode settings)
}

void bode_settings_load(const uint16 *ptr)
{
  //Only words this firmware wrote, each within its list
  //if(ptr[0] != BD_SETTINGS_MAGIC)
  //  return;
  uint32 shift = 0;

  if(ptr[0] == BD_SETTINGS_MAGIC_OLD)
    shift = BD_START_OLD_SHIFT;
  else if(ptr[0] != BD_SETTINGS_MAGIC)
    return;

  if((ptr[1] + shift) < BD_COUNT(bd_start_hz)) bd.start = ptr[1] + shift;
  if(ptr[2] < BD_COUNT(bd_stop_hz))        bd.stop    = ptr[2];
  if(ptr[3] < BD_COUNT(bd_points))         bd.points  = ptr[3];
  if(ptr[4] < BD_COUNT(bd_settle_periods)) bd.settle  = ptr[4];
  if(ptr[5] < 2)                           bd.range   = ptr[5];
  if(ptr[6] < 3)                           bd.display = ptr[6];
  if((shift == 0) && (ptr[7] < 2))         bd.single  = ptr[7];   //v1.00w8 (not in the old settings)
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00v3: SAVE BODE: the sweep table as a file in \bode\ (shown again in Saved waveforms while this view is active), a
//thumbnail for the list, and a CSV next to it when switched on

//#define BD_FILE_MAGIC     0x31444F42u     //"BOD1"
#define BD_FILE_MAGIC_OLD 0x31444F42u     //"BOD1"  v1.00w7: start index 3 lower
#define BD_FILE_MAGIC     0x32444F42u     //"BOD2"  v1.00w7: 1 Hz .. 10 MHz tables

typedef struct
{
  uint32 magic;
  uint8  start, stop, points, settle, range, display, thru_on, thru_valid;
  uint16 n, measured;
} BODEFILEHEADER;

uint32 bode_file_write(FIL *fp)
{
  BODEFILEHEADER h;
  uint32 result;

  h.magic      = BD_FILE_MAGIC;
  h.start      = bd.start;
  h.stop       = bd.stop;
  h.points     = bd.points;
  h.settle     = bd.settle;
  h.range      = bd.range;
  h.display    = bd.display;
  h.thru_on    = bd.thru_on;
  h.thru_valid = bd.thru_valid;
  h.n          = bd.n;
  h.measured   = bd.measured;

  if((result = f_write(fp, &h, sizeof(h), 0)) != FR_OK) return(result);
  if((result = f_write(fp, bd_f, sizeof(bd_f), 0)) != FR_OK) return(result);
  if((result = f_write(fp, bd_gain, sizeof(bd_gain), 0)) != FR_OK) return(result);
  if((result = f_write(fp, bd_phase, sizeof(bd_phase), 0)) != FR_OK) return(result);

  return(f_write(fp, bd_ok, sizeof(bd_ok), 0));
}

static uint32 bode_file_read(FIL *fp)
{
  BODEFILEHEADER h;
  uint32 result;

  if((result = f_read(fp, &h, sizeof(h), 0)) != FR_OK) return(result);

  //v1.00w7: older files: start index of the old table
  if(h.magic == BD_FILE_MAGIC_OLD)
  {
    h.magic  = BD_FILE_MAGIC;
    h.start += BD_START_OLD_SHIFT;
  }

  if((h.magic != BD_FILE_MAGIC) || (h.n > BD_MAX_POINTS) || (h.start >= BD_COUNT(bd_start_hz)) || (h.stop >= BD_COUNT(bd_stop_hz)) ||
     (h.points >= BD_COUNT(bd_points)))
    return(FR_INT_ERR);

  if((result = f_read(fp, bd_f, sizeof(bd_f), 0)) != FR_OK) return(result);
  if((result = f_read(fp, bd_gain, sizeof(bd_gain), 0)) != FR_OK) return(result);
  if((result = f_read(fp, bd_phase, sizeof(bd_phase), 0)) != FR_OK) return(result);
  if((result = f_read(fp, bd_ok, sizeof(bd_ok), 0)) != FR_OK) return(result);

  bd.start      = h.start;
  bd.stop       = h.stop;
  bd.points     = h.points;
  bd.settle     = h.settle;
  bd.range      = h.range;
  bd.display    = (h.display < 3) ? h.display : 0;
  bd.thru_on    = h.thru_on;
  bd.thru_valid = h.thru_valid;
  bd.n          = h.n;
  bd.measured   = h.measured;

  //v1.00x0: the files hold no noise values
  {
    int k;

    for(k = 0; k < BD_MAX_POINTS; k++)
      bd_snr[k] = BD_SNR_UNKNOWN;
  }

  return(FR_OK);
}

//Frequency in Hz with three decimals (mHz), gain in dB and phase in degrees with two / three decimals
uint32 bode_csv_write(void)
{
  int i;

  if(csv_open() != FR_OK)
    return(csv_close());

  csv_puts("Frequency_Hz,Gain_dB,Phase_deg,Valid\r\n");

  for(i = 0; i < bd.n; i++)
  {
    if(!bd_ok[i])
      continue;

    csv_putfixed((int64)bd_f[i], 3);
    csv_puts(",");
    csv_putfixed(bd_gain[i], 2);
    csv_puts(",");
    csv_putfixed(bd_phase[i], 3);
    csv_puts((bd_ok[i] == 1) ? ",1\r\n" : ",0\r\n");
  }

  return(csv_close());
}

//The thumbnail: gain (cyan, channel 2 data) and phase (pink, channel 1 data) over the 166 columns
void bode_fill_thumbnail(PTHUMBNAILDATA td)
{
  int    c, i, best, last = -1;
  int32  x, d, bd_x;
  int32  yg = 46, yp = 46;

  td->channel1enable = (bd.display != 1);
  td->channel2enable = (bd.display != 2);
  td->xydisplaymode  = 2;
  td->long_mode      = 0;
  td->disp_xstart    = 3;
  td->disp_xend      = 169;
  td->channel1traceposition = td->channel2traceposition = td->triggerverticalposition = 0;
  td->triggerhorizontalposition = 3;
  td->triggerchannel = 0;

  for(c = 0; c <= 166; c++)
  {
    //The point nearest to this column (screen x of the column on the plot)
    x = BD_X0 + ((c * BD_W) / 166);
    best = -1;
    bd_x = 100000;

    for(i = 0; i < bd.n; i++)
    {
      if(bd_ok[i] != 1)
        continue;

      d = x - bd_freq_x(bd_f[i]);

      if(d < 0)
        d = -d;

      if(d < bd_x)
      {
        bd_x = d;
        best = i;
      }
    }

    if((best >= 0) && (best != last))
    {
      yg = ((bd_gain_y(bd_gain[best]) - BD_Y0) * 92) / BD_H;
      yp = ((bd_phase_y(bd_phase[best]) - BD_Y0) * 92) / BD_H;
      last = best;
    }

    td->channel2data[c] = (uint8)yg;
    td->channel1data[c] = (uint8)yp;
  }
}

//Show the saved file viewcurrentindex points to, until the return button (top left) is touched
void bode_view_file(void)
{
  //The live chart and settings are kept and put back after viewing
  static uint64 f_save[BD_MAX_POINTS];
  static int32  g_save[BD_MAX_POINTS], p_save[BD_MAX_POINTS];
  static uint8  ok_save[BD_MAX_POINTS];
  BODESTATE     st_save = bd;
  uint32        result;
  int32         action = SAVED_VIEW_LOAD;

  memcpy(f_save, bd_f, sizeof(bd_f));
  memcpy(g_save, bd_gain, sizeof(bd_gain));
  memcpy(p_save, bd_phase, sizeof(bd_phase));
  memcpy(ok_save, bd_ok, sizeof(bd_ok));

  //v1.00v7: markers shown at the start, the MARKERS button of the right bar hides them
  bd_markers_hidden = 0;

  //v1.00v7: one file after the other (Next / Prev / Delete on the right bar) until Return or no file is left
  while(action == SAVED_VIEW_LOAD)
  {
    scope_print_file_name(viewfilenumberdata[viewcurrentindex]);

    if(f_open(&viewfp, viewfilename, FA_READ) != FR_OK)
    {
      scope_display_file_status_message(MESSAGE_FILE_OPEN_FAILED, 0);
      break;
    }

    result = bode_file_read(&viewfp);
    f_close(&viewfp);

    if(result != FR_OK)
    {
      scope_display_file_status_message(MESSAGE_WAV_VERSION_MISMATCH, 0);
      break;
    }

    bd_viewing   = 1;
    bd.sweeping  = 0;
    bd.autostage = 0;
    bd.thru_measuring = 0;
    bd.warn      = 0;
    bd.cursor_on = 1;
    bd.cursor    = bd.n / 4;
    bd.cursor2   = (bd.n * 3) / 4;

    action = SAVED_VIEW_REDRAW;

    while(1)
    {
      //Screen: return button and the file name at the top, the right bar, the view below
      if(action == SAVED_VIEW_REDRAW)
      {
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        display_set_fg_color(BLACK_COLOR);
        display_fill_rect(0, 0, 800, 480);
        scope_main_return_button(0);

        display_set_font(&font_3);
        display_set_fg_color(WHITE_COLOR);
        display_text(130, 14, "Saved frequency response");
        display_set_fg_color(BD_TEXT_COLOR);
        scope_display_saved_file_name(360, 14);

        scope_saved_view_right_menu();
        action = SAVED_VIEW_NONE;
      }

      bode_display();
      tp_i2c_read_status();

      if(!havetouch)
        continue;

      //Return
      if((xtouch <= 80) && (ytouch <= 44))
      {
        display_set_screen_buffer((uint16 *)maindisplaybuffer);
        scope_main_return_button(1);
        tp_i2c_wait_for_touch_release();
        action = SAVED_VIEW_EXIT;
        break;
      }

      if(xtouch >= 730)
      {
        action = handle_saved_view_right_touch();

        if((action == SAVED_VIEW_LOAD) || (action == SAVED_VIEW_EXIT))
          break;

        if(action == SAVED_VIEW_TCURSOR)
          bode_toggle_cursor();
        else if(action == SAVED_VIEW_MEASURES)
          bd_markers_hidden ^= 1;
      }
      else if(ytouch >= 48)
        bode_handle_touch();
      else
        tp_i2c_wait_for_touch_release();
    }
  }

  //Back to the live view
  bd_viewing = 0;
  bd_markers_hidden = 0;
  bd = st_save;
  memcpy(bd_f, f_save, sizeof(bd_f));
  memcpy(bd_gain, g_save, sizeof(bd_gain));
  memcpy(bd_phase, p_save, sizeof(bd_phase));
  memcpy(bd_ok, ok_save, sizeof(bd_ok));
}

//v1.00v7: a saved frequency response is shown (the right bar's MEASURES button is MARKERS then)
int bode_is_viewing(void)
{
  return(bd_viewing);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00y3: reference curves (4 slots). REF in the CH2 menu of this view opens the panel (ref_and_math.c view_ref_panel):
//Copy takes the chart as it is, Save / Load use \ref_bode\refN.bod in the .bod format of SAVE BODE (a saved .bod file
//copied there loads as a reference too). Shown references are drawn under the live curves in their own color, gain
//and phase as the Display setting, only the points inside the current span.

typedef struct
{
  uint8  valid;
  uint8  shown;
  uint16 n;
  uint64 f[BD_MAX_POINTS];
  int32  gain[BD_MAX_POINTS];
  int32  phase[BD_MAX_POINTS];
  uint8  ok[BD_MAX_POINTS];
} BODEREF;

static BODEREF bd_ref[VIEW_REF_SLOTS];

static uint32 bd_ref_valid(int i)  { return(bd_ref[i].valid); }
static uint32 bd_ref_shown(int i)  { return(bd_ref[i].shown); }
static void   bd_ref_toggle(int i) { bd_ref[i].shown ^= 1; }
static void   bd_ref_clear(int i)  { bd_ref[i].valid = 0; bd_ref[i].shown = 0; }

static uint32 bd_ref_copy(int i)
{
  int k;

  if(!bd.n || !bd.measured)
    return(0);

  for(k = 0; k < BD_MAX_POINTS; k++)
  {
    bd_ref[i].f[k]     = bd_f[k];
    bd_ref[i].gain[k]  = bd_gain[k];
    bd_ref[i].phase[k] = bd_phase[k];
    bd_ref[i].ok[k]    = (k < bd.n) ? bd_ok[k] : 0;
  }

  bd_ref[i].n     = bd.n;
  bd_ref[i].valid = 1;
  bd_ref[i].shown = 1;

  return(1);
}

//The .bod layout of bode_file_write with the slot's table
static uint32 bd_ref_write(FIL *fp, int i)
{
  BODEFILEHEADER h;
  uint32 result;

  h.magic      = BD_FILE_MAGIC;
  h.start      = bd.start;
  h.stop       = bd.stop;
  h.points     = bd.points;
  h.settle     = bd.settle;
  h.range      = bd.range;
  h.display    = bd.display;
  h.thru_on    = 0;
  h.thru_valid = 0;
  h.n          = bd_ref[i].n;
  h.measured   = bd_ref[i].n;

  if((result = f_write(fp, &h, sizeof(h), 0)) != FR_OK) return(result);
  if((result = f_write(fp, bd_ref[i].f, sizeof(bd_ref[i].f), 0)) != FR_OK) return(result);
  if((result = f_write(fp, bd_ref[i].gain, sizeof(bd_ref[i].gain), 0)) != FR_OK) return(result);
  if((result = f_write(fp, bd_ref[i].phase, sizeof(bd_ref[i].phase), 0)) != FR_OK) return(result);

  return(f_write(fp, bd_ref[i].ok, sizeof(bd_ref[i].ok), 0));
}

static uint32 bd_ref_read(FIL *fp, int i)
{
  BODEFILEHEADER h;
  uint32 result;
  int    k;

  if((result = f_read(fp, &h, sizeof(h), 0)) != FR_OK) return(result);

  if(((h.magic != BD_FILE_MAGIC) && (h.magic != BD_FILE_MAGIC_OLD)) || (h.n > BD_MAX_POINTS))
    return(FR_INT_ERR);

  if((result = f_read(fp, bd_ref[i].f, sizeof(bd_ref[i].f), 0)) != FR_OK) return(result);
  if((result = f_read(fp, bd_ref[i].gain, sizeof(bd_ref[i].gain), 0)) != FR_OK) return(result);
  if((result = f_read(fp, bd_ref[i].phase, sizeof(bd_ref[i].phase), 0)) != FR_OK) return(result);
  if((result = f_read(fp, bd_ref[i].ok, sizeof(bd_ref[i].ok), 0)) != FR_OK) return(result);

  //Only the measured points of the file
  for(k = h.measured; k < BD_MAX_POINTS; k++)
    bd_ref[i].ok[k] = 0;

  bd_ref[i].n     = h.n;
  bd_ref[i].valid = 1;
  bd_ref[i].shown = 1;

  return(FR_OK);
}

static const VIEWREFOPS bd_ref_ops =
{
  "\\ref_bode", ".bod", bd_ref_valid, bd_ref_shown, bd_ref_toggle, bd_ref_copy, bd_ref_write, bd_ref_read, bd_ref_clear
};

void bode_ref_panel(uint32 xpos)
{
  view_ref_panel(xpos, &bd_ref_ops);
}

//v1.00z0: "R1" .. "R4" in the reference's color at the start of its curve (left, at the scale)
static void bd_ref_label(int r, int32 x, int32 y)
{
  static const char *names[VIEW_REF_SLOTS] = { "R1", "R2", "R3", "R4" };

  y -= 16;

  if(y < BD_Y0)
    y = BD_Y0;
  else if(y > (BD_Y1 - 14))
    y = BD_Y1 - 14;

  display_set_font(&font_2);
  display_set_fg_color(view_ref_colors[r]);
  display_text(x + 3, y, (int8 *)names[r]);
}

//One reference curve: the points inside the span joined (phase wraps not joined), as bd_draw_curve
//v1.00z0: label = 1 puts the R label at its first point
static void bd_draw_ref_curve(int r, int phase, int label)
{
  BODEREF *ref = &bd_ref[r];
  uint64 f0 = (uint64)bd_start_hz[bd.start] * 1000;
  uint64 f1 = (uint64)bd_stop_hz[bd.stop] * 1000;
  int32 *val = phase ? ref->phase : ref->gain;
  int32  x, y, px = 0, py = 0;
  int    i, have = 0;

  display_set_fg_color(view_ref_colors[r]);

  for(i = 0; i < ref->n; i++)
  {
    if(!ref->ok[i] || (ref->f[i] < f0) || (ref->f[i] > f1))
    {
      have = 0;
      continue;
    }

    x = bd_freq_x(ref->f[i]);
    y = phase ? bd_phase_y(val[i]) : bd_gain_y(val[i]);

    //v1.00z0: the label at the first point, then the curve's color again
    if(label)
    {
      bd_ref_label(r, x, y);
      display_set_fg_color(view_ref_colors[r]);
      label = 0;
    }

    if(have && (!phase || (((val[i] - val[i - 1]) < 180000) && ((val[i - 1] - val[i]) < 180000))))
      display_draw_line(px, py, x, y);

    px = x;
    py = y;
    have = 1;
  }
}

static void bd_draw_refs(void)
{
  int r;

  for(r = 0; r < VIEW_REF_SLOTS; r++)
  {
    if(!bd_ref[r].valid || !bd_ref[r].shown)
      continue;

    //v1.00z0: the R label at the gain curve, at the phase curve when only the phase is shown
    if(bd.display != 2)
      bd_draw_ref_curve(r, 0, 1);

    if(bd.display != 1)
      bd_draw_ref_curve(r, 1, (bd.display == 2));
  }
}

//v1.00y3: CH range Manual (V/div by hand) or Auto
int bode_range_manual(void)
{
  return(bd.range == 1);
}
