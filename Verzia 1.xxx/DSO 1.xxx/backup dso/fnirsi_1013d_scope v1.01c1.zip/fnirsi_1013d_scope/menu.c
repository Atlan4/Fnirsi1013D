//----------------------------------------------------------------------------------------------------------------------------------
#include "types.h"
#include "menu.h"
#include "test.h"
#include "scope_functions.h"
#include "spectrum.h"
#include "bode.h"
#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "spi_control.h"
#include "sd_card_interface.h"  //only diagnostic menu?
#include "display_lib.h"
#include "ff.h"
#include "DS3231.h"

#include "usb_interface.h"
#include "PC_interface.h"
#include "variables.h"
#include "generator.h"

#include "sin_cos_math.h"

#include <string.h>
//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_display_lib(void)
{
  display_set_bg_color(BLACK_COLOR);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_dimensions(SCREEN_WIDTH, SCREEN_HEIGHT);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_main_screen(void)
{
  //Prepare the screen in a working buffer
//  display_set_screen_buffer(displaybuffer1);

  //Setup for clearing top and right menu bars
  display_set_fg_color(BLACK_COLOR);

  //Top bar for the main, channel and trigger menu and information
  display_fill_rect(0, 0, 730, 48);

  //Right bar for control buttons
  display_fill_rect(730, 0, 70, 480);

  //Setup the menu bar on the right side
  scope_setup_right_control_menu();

  //Check if normal or wave view mode
  if(scopesettings.waveviewmode)
  {
    //Wave view mode so show return button
    scope_main_return_button(0);
  }    
  else
  {
    //Normal mode so show menu button
    scope_menu_button(0);
  }

  //Show the user if the acquisition is running or stopped
  scope_run_stop_text();

  //Display the channel menu select buttons and their settings
  scope_channel_settings(&scopesettings.channel1, 0);
  scope_channel_settings(&scopesettings.channel2, 0);

  //Display the current time per div setting
  scope_acqusition_settings(0);

  //Show the user selected move speed
  scope_move_speed(0);
  
  //Show the icon to white sun or yellow sun-max light
  scope_maxlight_item(scopesettings.maxlight);      

  //Display the trigger menu select button and the settings
  scope_trigger_settings(0);
  
  //Display the generator menu and the settings
  scope_generator_settings(0);

  //Show the battery charge level and charging indicator
  scope_battery_status();
  
  //Show version information
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_2);
  display_text(VERSION_STRING_XPOS, VERSION_STRING_YPOS, VERSION_STRING+1);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_restore_screen(void)
{
  //Clear the whole screen
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);
  
  //Fill in the screens with a blue color
  display_set_fg_color(DARKBLUE_COLOR);
  display_fill_rect(10, 10, 780, 460);
  
  //Display the text with font 5 and the white color
  display_set_font(&font_5);
  display_set_fg_color(WHITE_COLOR);
  display_text(370, 130, VERSION_STRING);    //Show version information 
  display_text(270, 190, "Load default settings value");    
  
  if (calibrationfail == 1)
    {
    //Display the text with red color
    display_set_fg_color(RED_COLOR);
    display_text(240, 240, "Need input calibration procedure !");  
    }
  else
    {
     //Display the text with green color
    display_set_fg_color(GREEN_COLOR);
    display_text(240, 240, "LOAD input calibration data OK !"); 
    display_set_fg_color(RED_COLOR);
    display_text(275, 280, "RUN baseline calibration !"); 
    }
  
  //Display the text with green color
  display_set_fg_color(GREEN_COLOR);
  display_text(320, 350, "Touch the screen");  
   
  //Scan the touch panel to see if there is user input
  while((havetouch == 0)) tp_i2c_read_status();
  
  //Clear the whole screen
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);
   
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_view_screen(void)
{
  //Switch to view mode so disallow saving of settings on power down
  viewactive = VIEW_ACTIVE;

  //v1.00v3: the frequency response and the spectrum lists keep the run state of their view
  __typeof__(scopesettings.runstate) runsave = scopesettings.runstate;

  //Set scope run state to running to have it sample fresh data on exit
  scopesettings.runstate = 1;//ok

  //Only needed for waveform view. Picture viewing does not change the scope settings
  if(viewtype == VIEW_TYPE_WAVEFORM)
  {
    //Save the current settings
    scope_save_setup(&savedscopesettings1);
  }
  
  //Initialize the view mode variables
  //Used for indicating if select all or select button is active
  viewselectmode = 0;

  //Start at first page
  viewpage = 0;

  //Clear the item selected flags
  memset(viewitemselected, VIEW_ITEM_NOT_SELECTED, VIEW_ITEMS_PER_PAGE);

  //Set storage buffer for screen capture under selected signs and messages
  display_set_destination_buffer(displaybuffer2);
  display_set_source_buffer(displaybuffer2);

  //Display the file actions menu on the right side of the screen
  scope_setup_right_file_menu();

  //Load the thumbnail file for the current view type
  if(scope_load_thumbnail_file() != 0)
  {
    //Restore the main screen
    scope_setup_main_screen();
    
    //Loading the thumbnail file failed so no sense in going on
    return;
  }

  //Display the available thumbnails for the current view type
  scope_initialize_and_display_thumbnails();

  //Handle touch for this part of the user interface
  handle_view_mode_touch();

  //This is only needed when an actual waveform has been viewed, but that needs an extra flag
  //Only needed for waveform view. Picture viewing does not change the scope settings
  if(viewtype == VIEW_TYPE_WAVEFORM)
  {
    //Restore the current settings
    scope_restore_setup(&savedscopesettings1);

    //Make sure view mode is normal
    scopesettings.waveviewmode = 0;

    //And resume with auto trigger mode
    //scopesettings.triggermode = 0;

    //Need to restore the original scope data and fpga settings

    //Is also part of startup, so could be done with a function
    //Set the volts per div for each channel based on the loaded scope settings
    fpga_set_channel_voltperdiv(&scopesettings.channel1);
    fpga_set_channel_voltperdiv(&scopesettings.channel2);

    //These are not done in the original code
    //Set the channels AC or DC coupling based on the loaded scope settings
    fpga_set_channel_coupling(&scopesettings.channel1);
    fpga_set_channel_coupling(&scopesettings.channel2);

    //Setup the trigger system in the FPGA based on the loaded scope settings
    fpga_set_sample_rate(scopesettings.samplerate);
    fpga_set_trigger_channel();
    fpga_set_trigger_edge();
    fpga_set_trigger_level();
    fpga_set_trigger_mode();

    //Set channel screen offsets
    fpga_set_channel_offset(&scopesettings.channel1);
    fpga_set_channel_offset(&scopesettings.channel2);
  }

  //v1.00v3: back to the frequency response or the spectrum view as it was
  if((viewtype == VIEW_TYPE_BODE) || (viewtype == VIEW_TYPE_SPECTRUM) || (viewtype == VIEW_TYPE_BODE_PICTURE) || (viewtype == VIEW_TYPE_SPECTRUM_PICTURE))
    scopesettings.runstate = runsave;

  //Reset the screen to the normal scope screen
  scope_setup_main_screen();
  
  //Display the trace data
  scope_display_trace_data();   //add for single mode screen mismas

  //Back to normal mode so allow saving of settings on power down
  viewactive = VIEW_NOT_ACTIVE;
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_usb_screen(void)
{
  //Clear the whole screen
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);

  //Set the light color for the equipment borders
  display_set_fg_color(0x00AAAAAA);

  //Draw the computer screen
  display_fill_rounded_rect(470, 115, 250, 190, 2);
  display_fill_rect(580, 305, 30, 20);
  display_fill_rounded_rect(550, 325, 90, 10, 2);
  display_fill_rect(550, 331, 89, 4);

  //Draw the scope
  display_fill_rounded_rect(80, 200, 180, 135, 2);

  //Draw the cable
  display_fill_rect(210, 188, 10, 12);
  display_fill_rect(213, 154, 4, 36);
  display_fill_rect(213, 150, 152, 4);
  display_fill_rect(361, 154, 4, 106);
  display_fill_rect(361, 260, 98, 4);
  display_fill_rect(458, 257, 12, 10);

  //Fill in the screens with a blue color
  display_set_fg_color(DARKBLUE_COLOR);
  display_fill_rect(477, 125, 235, 163);
  display_fill_rect(88, 210, 163, 112);

  //Draw a dark border around the blue screens
  display_set_fg_color(0x00111111);
  display_draw_rect(477, 125, 235, 163);
  display_draw_rect(88, 210, 163, 112);

  //Display the text with font 5 and the light color
  display_set_font(&font_5);
  display_set_fg_color(WHITE_COLOR);
  display_text(130, 254, "Off USB");    //130 bolo

  //Stop the USB interface
  usb_device_disable();
          
  USB_CH340 = 0;      //serial mode OFF, enable MSC
  usb_device_init();
  
  //Start the USB interface
  usb_device_enable();

  //Wait for the user to touch the scope Off USB section to quit
  while(1)
  {
    //Scan the touch panel for touch
    tp_i2c_read_status();

    //Check if there is touch
    if(havetouch)
    {
      //Check if touch within the text field  //Check if touch within the USB OFF button
      if((xtouch >= 90) && (xtouch <= 250) && (ytouch >= 210) && (ytouch <= 320))
      {
        if (mounted_to_PC)
        {
          scope_display_error();
          
          //Wait until touch is released 
          tp_i2c_wait_for_touch_release();
        }
        else 
        {  
          //Stop the USB interface
          usb_device_disable();
          
          USB_CH340 = 1;      //serial mode on
          usb_device_init();
          //Start the USB interface
          usb_device_enable();
          
          //Touched the text field so wait until touch is released and then quit
          tp_i2c_wait_for_touch_release();
          
          break;
        }
      }
    }
  }
  
  //Stop the USB interface
  //usb_device_disable();

  //Re-sync the system files
  scope_sync_thumbnail_files();
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_right_control_menu(void)
{
  //Setup for clearing right menu bar
  display_set_fg_color(BLACK_COLOR);

  //Clear the right bar for the control buttons
  display_fill_rect(730, 0, 70, 480);

  //Display the control button
  scope_control_button(0);

  //Check in which state the right menu is in
  if(scopesettings.rightmenustate == 0)
  {
    //Main control state so draw the always used buttons
    scope_t_cursor_button(0);
    scope_v_cursor_button(0);
    scope_measures_button(0);
    scope_save_picture_button(0);

    //Check if in wave view mode (Scope mode)
    if(scopesettings.waveviewmode)
    {
      //Wave view mode buttons
      scope_previous_wave_button(0);
      scope_next_wave_button(0);
      scope_delete_wave_button(0);
    }    
    else
    {
      //Main control mode buttons
      scope_run_stop_button(0);
      scope_auto_set_button(0);
      scope_save_wave_button(0);
    }
  }
  //else
  //v1.01b2: the decoder page
  if(scopesettings.rightmenustate == RIGHT_MENU_DECODER)
  {
    scope_right_decoder_button(0);
    scope_right_list_button(0);
  }

  //Check in which RIGHT sensitivity menu
  if(scopesettings.rightmenustate == 1)
  {
    //v1.01b3: the decoder buttons under CTRL (not in the spectrum / Bode views)
    if(!spectrum_is_active() && !bode_is_active())
    {
      scope_right_decoder_button(0);
      scope_right_list_button(0);
    }

    //Channel sensitivity state
    scope_channel_sensitivity_control(&scopesettings.channel1, 0, 0);
    scope_channel_sensitivity_control(&scopesettings.channel2, 0, 0);

    //Check if in wave view mode (Scope mode)
    if(scopesettings.waveviewmode)
    {
      //Wave view mode
      scope_show_grid_button(0);
    }    
    else
    {
      //Main control mode
      scope_50_percent_trigger_button(0);
    }
  }
   //Check in which DC shift calibration set menu - center position on signal
  if(scopesettings.rightmenustate == 2)
  {
    //Channel sensitivity state, this menu for - center position on signal
    scope_channel_sensitivity_control(&scopesettings.channel1, 0, 0);
    scope_channel_sensitivity_control(&scopesettings.channel2, 0, 0);
    
    //add visible value dc_shift_center
    scope_channel_dcshift_value();
      
    //Next calibration page
    scope_next_cal_button(0);
  } 
  //Check in which DC shift calibration set menu - size displayed signal
  if(scopesettings.rightmenustate == 3)
  {
    //Channel sensitivity state, this menu for - size displayed signal
    scope_channel_sensitivity_control(&scopesettings.channel1, 0, 0);
    scope_channel_sensitivity_control(&scopesettings.channel2, 0, 0);
    
    //add visible value dc_shift_size
    scope_channel_dcshift_value();
      
    //Next calibration page
    scope_next_cal_button(0);
  }  
  //Check in which DC shift calibration set menu - adjust measurement values
  if(scopesettings.rightmenustate == 4)
  {
    //Channel sensitivity state, this menu for - adjust measurement values
    scope_channel_sensitivity_control(&scopesettings.channel1, 0, 0);
    scope_channel_sensitivity_control(&scopesettings.channel2, 0, 0);
    
    //add visible value dc_shift_value
    scope_channel_dcshift_value();
      
    //Next calibration page
    scope_end_cal_button(0);
  }  
  //-----------------------------
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_right_file_menu(void)
{
  //Set black color for background
  display_set_fg_color(BLACK_COLOR);

  //Clear the right menu bar
  display_fill_rect(730, 0, 70, 480);

  //Add the buttons
  scope_return_button(0);
  scope_select_all_button(0);
  scope_select_button(0);
  scope_delete_button(0);
  scope_page_up_button(0);
  scope_page_down_button(0);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_setup_bottom_file_menu(int mode)
{
  PTHUMBNAILDATA thumbnaildata;   
    
  //Check if background needs to be saved
  if(mode == VIEW_BOTTON_MENU_INIT)
  {
    //Save the screen rectangle where the menu will be displayed
    display_copy_rect_from_screen(0, 390, 800, 90);
  }

  //Check if it needs to be drawn
  if(mode & VIEW_BOTTON_MENU_SHOW)
  {
    //Draw the background in grey
    display_set_fg_color(DARKGREY_COLOR);
    display_fill_rect(0, 390, 800, 90);

    //Draw the filename in white
    display_set_fg_color(WHITE_COLOR);
    display_set_font(&font_5);
    //display_text(20, 392, viewfilename);
    
      if(onoffRTC) //if RTCon view rtc info
        {
        thumbnaildata = &viewthumbnaildata[viewcurrentindex];
        decodethumbnailfilename(thumbnaildata->filename);
        display_text(20, 392, filenameRTC);
        }   else display_text(20, 392, viewfilename);
    
    //Setup the buttons
    scope_bmp_return_button(0);    
    scope_bmp_delete_button(0);
    scope_bmp_previous_button(0);
    scope_bmp_next_button(0);
    
    //Signal menu is visible
    viewbottommenustate = VIEW_BOTTON_MENU_SHOW | VIEW_BOTTOM_MENU_ACTIVE;
  }
  else
  {
    //Hide the menu bar
    display_copy_rect_to_screen(0, 390, 800, 90);

    //Signal menu is not visible
    viewbottommenustate = VIEW_BOTTON_MENU_HIDE | VIEW_BOTTOM_MENU_ACTIVE;
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
// Right side bar functions
//----------------------------------------------------------------------------------------------------------------------------------

void scope_control_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Grey color for inactive button
    display_set_fg_color(GREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 5, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(739, 5, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(748, 22, "CTRL");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_run_stop_button(int mode)
{ 
  //Check if inactive or active mode
  if(mode == 0)
  {
  //Check if run or stop mode  
  if(scopesettings.runstate) //ok
    {//Run mode:Green box
    display_set_fg_color(GREEN_COLOR);
    }    
    else 
    {//Stop mode:Red box 
    display_set_fg_color(RED_COLOR);
    }
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 65, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 65, 51, 50, 2);
        
  //Check if inactive or active mode
  if(mode == 0)
  {
      //Check if run or stop mode - Run mode: black text 
    if(scopesettings.runstate) display_set_fg_color(BLACK_COLOR);//ok
          //Stop mode: white text
          else display_set_fg_color(WHITE_COLOR);  
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 75, "RUN/");
  display_text(746, 90, "STOP");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_auto_set_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);  //black?0x00202020
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 125, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 125, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 135, "AUTO");
  display_text(753, 150, "SET");
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00v7: the second line of the Next / Prev / Delete buttons
static uint32 mm_text_width(const char *text);

static const char *mm_saved_kind(void)
{
  return(bode_is_active() ? "Bode" : spectrum_is_active() ? "spec" : "wave");
}

//v1.00v7: the right bar of a saved frequency response or spectrum being shown (as the saved waveform view: Next, Prev,
//the cursors, MEASURES / MARKERS, SAVE PICTURE and Delete)
void scope_saved_view_right_menu(void)
{
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(730, 0, 70, 480);

  scope_next_wave_button(0);
  scope_previous_wave_button(0);
  scope_t_cursor_button(0);
  scope_v_cursor_button(0);
  scope_measures_button(0);
  scope_save_picture_button(0);
  scope_delete_wave_button(0);
}

void scope_next_wave_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 65, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 65, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(749, 75, "Next");
  //v1.00v7: the saved frequency response / spectrum viewer uses these buttons too
  display_text(739 + ((51 - mm_text_width(mm_saved_kind())) / 2), 90, (int8 *)mm_saved_kind());
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_previous_wave_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 125, 51, 50, 2);
  
  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 125, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(749, 135, "Prev");
  display_text(739 + ((51 - mm_text_width(mm_saved_kind())) / 2), 150, (int8 *)mm_saved_kind());
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_t_cursor_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 185, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 185, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  //v1.00r8: "F" (frequency cursor) in the spectrum analyser view
  display_text(746, 195, spectrum_is_active() ? "F" : "T");
  display_text(765, 195, "CU");
  display_text(746, 210, "RSOR");

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_v_cursor_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 245, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 245, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);

  //v1.00z2: native grey text where it does nothing (frequency response view)
  if(bode_is_active() && !scopesettings.waveviewmode)
    display_set_fg_color(LIGHTGREY1_COLOR);
  //v1.00r8: "L" (level cursor) in the spectrum analyser view
  display_text(746, 255, spectrum_is_active() ? "L" : "V");
  display_text(765, 255, "CU");
  display_text(746, 270, "RSOR");
  

  //v1.00y5: grey (dimmed) in the frequency response view, where it does nothing
  //if(bode_is_active() && !scopesettings.waveviewmode)
  //  display_dim_rect(739, 245, 51, 50);
}

//----------------------------------------------------------------------------------------------------------------------------------

static uint32 mm_text_width(const char *text);

void scope_measures_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 305, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 305, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  //v1.00u2: Clear chart in the frequency response view; v1.00v7: Markers (on / off) when a saved one is shown
  if(bode_is_active() && bode_is_viewing())
  {
    display_text(739 + ((51 - mm_text_width("MAR")) / 2), 315, "MAR");
    display_text(739 + ((51 - mm_text_width("KERS")) / 2), 330, "KERS");
  }
  else if(bode_is_active())
  {
    //Centred in the 51 px button (v1.00u9)
    display_text(739 + ((51 - mm_text_width("CLEAR")) / 2), 315, "CLEAR");
    display_text(739 + ((51 - mm_text_width("CHART")) / 2), 330, "CHART");
  }
  else
  {
    display_text(746, 315, "MEAS");
    display_text(746, 330, "URES");
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_save_picture_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 365, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 365, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 375, "SAVE");
  display_text(753, 390, "PIC");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_save_wave_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 425, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 425, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  //v1.00v3: SAVE BODE / SAVE SPEC in the frequency response / spectrum view
  display_text(746, 435, "SAVE");
  display_text(739 + ((51 - mm_text_width(bode_is_active() ? "BODE" : spectrum_is_active() ? "SPEC" : "WAVE")) / 2), 450,
               bode_is_active() ? "BODE" : spectrum_is_active() ? "SPEC" : "WAVE");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_delete_wave_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 425, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 425, 51, 50, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(745, 436, "Delete");
  display_text(739 + ((51 - mm_text_width(mm_saved_kind())) / 2), 449, (int8 *)mm_saved_kind());
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_50_percent_trigger_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  //v1.01b5: 46 high as the V+ / V- buttons (was 425, 50 high)
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(739, 425, 52, 51);
  display_set_fg_color(mode ? ITEM_ACTIVE_COLOR : DARKGREY_COLOR);
  display_fill_rounded_rect(739, 427, 51, 46, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 427, 51, 46, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(753, 435, "50%");//752 436
  display_text(749, 450, "TRIG");//449
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_show_grid_button(int mode)      
{
  //v1.01b6: the slot cleared first (the button is lower than the one it may replace)
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(739, 425, 52, 51);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 427, 51, 46, 2);     //v1.01b6: 46 high as 50% TRIG and V+ / V- (was 425, 50 high)

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 427, 51, 46, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 436, "Show");
  display_text(752, 449, "grid");
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_next_cal_button(int mode)      
{
  //v1.01b6: the slot cleared first (the button is lower than the one it may replace)
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(739, 425, 52, 51);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //Darkgray color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 427, 51, 46, 2);     //v1.01b6: 46 high as 50% TRIG and V+ / V- (was 425, 50 high)

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 427, 51, 46, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(RED_COLOR);        //white
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(748, 436, "Next");
  display_text(752, 449, "page");
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_end_cal_button(int mode)      
{
  //v1.01b6: the slot cleared first (the button is lower than the one it may replace)
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(739, 425, 52, 51);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //Darkgray color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(739, 427, 51, 46, 2);     //v1.01b6: 46 high as 50% TRIG and V+ / V- (was 425, 50 high)

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, 427, 51, 46, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(GREEN_COLOR);        //white
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(751, 436, "END");    //748
  display_text(752, 449, "cal.");
}
//----------------------------------------------------------------------------------------------------------------------------------

#if 0 //v1.01b2: the buttons 50 high, the channel bar 24 high
void scope_channel_sensitivity_control(PCHANNELSETTINGS settings, int type, int mode)
{
  uint32 y;

  //Check if V+ is active or inactive
  if((type == 0) && (mode != 0))
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }
  else
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }

  //Top button
  display_fill_rounded_rect(739, settings->voltdivypos, 51, 50, 2);
  
  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, settings->voltdivypos, 51, 50, 2);

  //Check if V- is active or inactive
  if((type != 0) && (mode != 0))
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }
  else
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }

  //Y position o f bottom button
  y = settings->voltdivypos + 86;
  
  //Bottom button
  display_fill_rounded_rect(739, y, 51, 50, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, y, 51, 50, 2);
  
  //Display V+ and V- the text in larger font
  display_set_font(&font_0);
  
  //Check if V+ is active or inactive
  if((type == 0) && (mode != 0))
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Top button text
  display_text(757, settings->voltdivypos + 18, "V+");

  //Check if V- is active or inactive
  if((type != 0) && (mode != 0))
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Bottom button text
  display_text(757, settings->voltdivypos + 104, "V-");

  //Display the channel identifier bar with the channel color
  display_set_fg_color(settings->color);
  display_fill_rounded_rect(739, settings->voltdivypos + 56, 51, 24, 2);

  //Display the channel identifier in black
  display_set_fg_color(BLACK_COLOR);
  display_set_font(&font_2);
  display_text(754, settings->voltdivypos + 61, settings->buttontext);
}
#endif

void scope_channel_sensitivity_control(PCHANNELSETTINGS settings, int type, int mode)
{
  //v1.01b3: buttons 46 high (were 50), the channel bar 20 high (was 24), so the decoder buttons fit under CTRL
  uint32 y;

  //Check if V+ is active or inactive
  if((type == 0) && (mode != 0))
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }
  else
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }

  //Top button
  display_fill_rounded_rect(739, settings->voltdivypos, 51, 46, 2);
  
  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, settings->voltdivypos, 51, 46, 2);

  //Check if V- is active or inactive
  if((type != 0) && (mode != 0))
  {
    //Orange color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }
  else
  {
    //Black color for inactive button
    display_set_fg_color(DARKGREY_COLOR);
  }

  //Y position o f bottom button
  y = settings->voltdivypos + 74;
  
  //Bottom button
  display_fill_rounded_rect(739, y, 51, 46, 2);

  //Draw the edge
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, y, 51, 46, 2);
  
  //Display V+ and V- the text in larger font
  display_set_font(&font_0);
  
  //Check if V+ is active or inactive
  if((type == 0) && (mode != 0))
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Top button text
  display_text(757, settings->voltdivypos + 16, "V+");

  //Check if V- is active or inactive
  if((type != 0) && (mode != 0))
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Bottom button text
  display_text(757, y + 16, "V-");

  //Display the channel identifier bar with the channel color
  display_set_fg_color(settings->color);
  display_fill_rounded_rect(739, settings->voltdivypos + 50, 51, 20, 2);

  //Display the channel identifier in black
  display_set_fg_color(BLACK_COLOR);
  display_set_font(&font_2);
  display_text(754, settings->voltdivypos + 53, settings->buttontext);
}

//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_dcshift_value(void)
{

  //Black color for inactive button
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(755, CH1_VOLT_DIV_MENU_YPOS - 16, 50, 15);//99 v1.01b3: above the V+ buttons
  display_fill_rect(755, CH2_VOLT_DIV_MENU_YPOS - 16, 50, 15);//264

  display_set_font(&font_2);

  if(scopesettings.rightmenustate == 2)
  {
    //channel color for text
    display_set_fg_color(CHANNEL1_COLOR);
    display_decimal(755, CH1_VOLT_DIV_MENU_YPOS - 16, scopesettings.channel1.dc_shift_center);
    //channel color for text
    display_set_fg_color(CHANNEL2_COLOR);
    display_decimal(755, CH2_VOLT_DIV_MENU_YPOS - 16, scopesettings.channel2.dc_shift_center);
  }
  
    if(scopesettings.rightmenustate == 3)
  {
    //channel color for text
    display_set_fg_color(CHANNEL1_COLOR);
    display_decimal(755, CH1_VOLT_DIV_MENU_YPOS - 16, scopesettings.channel1.dc_shift_size);
    //channel color for text
    display_set_fg_color(CHANNEL2_COLOR);
    display_decimal(755, CH2_VOLT_DIV_MENU_YPOS - 16, scopesettings.channel2.dc_shift_size);
  }
  
    if(scopesettings.rightmenustate == 4)
  {
    //channel color for text
    display_set_fg_color(CHANNEL1_COLOR);
    display_decimal(755, CH1_VOLT_DIV_MENU_YPOS - 16, scopesettings.channel1.dc_shift_value);
    //channel color for text
    display_set_fg_color(CHANNEL2_COLOR);
    display_decimal(755, CH2_VOLT_DIV_MENU_YPOS - 16, scopesettings.channel2.dc_shift_value);
  }

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_return_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(734, 14, 63, 58, 2);

  //Outline the button
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(734, 14, 63, 58, 2);
  
  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(745, 34, "Return");//747
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_select_all_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }
  else
  {
    //White for enabled button
    display_set_fg_color(WHITE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(734, 93, 63, 58, 2);

  //Outline the button
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(734, 93, 63, 58, 2);
  
  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 106, "Select");
  display_text(758, 120, "all");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_select_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }
  else
  {
    //White for enabled button
    display_set_fg_color(WHITE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(734, 173, 63, 58, 2);

  //Outline the button
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(734, 173, 63, 58, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 193, "Select");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_delete_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(734, 253, 63, 58, 2);

  //Outline the button
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(734, 253, 63, 58, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(746, 273, "Delete");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_page_up_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(734, 333, 63, 58, 2);

  //Outline the button
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(734, 333, 63, 58, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(750, 345, "Page");
  display_text(758, 360, "up");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_page_down_button(int mode)
{
  //Check if inactive or active mode
  if(mode == 0)
  {
    //Black color for inactive button
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active color for activated button
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the body of the button
  display_fill_rounded_rect(734, 413, 63, 58, 2);

  //Outline the button
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(734, 413, 63, 58, 2);

  //Check if inactive or active mode
  if(mode == 0)
  {
    //White text color for inactive button
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Black text color for activated button
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(750, 425, "Page");
  display_text(748, 442, "down");
}

//----------------------------------------------------------------------------------------------------------------------------------
// Bitmap control bar functions
//----------------------------------------------------------------------------------------------------------------------------------

void scope_bmp_return_button(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so black background
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so active color background
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Fill in the body of the button
  display_fill_rounded_rect(40, 425, 120, 50, 3);

  //Draw rounded rectangle as button border in black
  display_set_fg_color(BLACK_COLOR);
  display_draw_rounded_rect(40, 425, 120, 50, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so black foreground and active color background
    display_set_fg_color(LIGHTGREY_COLOR);
    display_set_bg_color(ITEM_ACTIVE_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(return_arrow_icon, 79, 436, 41, 27);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_bmp_delete_button(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so black background
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so active color background
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Fill in the body of the button
  display_fill_rounded_rect(240, 425, 120, 50, 3);

  //Draw rounded rectangle as button border in black
  display_set_fg_color(BLACK_COLOR);
  display_draw_rounded_rect(240, 425, 120, 50, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so black foreground and active color background
    display_set_fg_color(LIGHTGREY_COLOR);
    display_set_bg_color(ITEM_ACTIVE_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(waste_bin_icon, 284, 433, 31, 33);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_bmp_previous_button(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so black background
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so active color background
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Fill in the body of the button
  display_fill_rounded_rect(440, 425, 120, 50, 3);

  //Draw rounded rectangle as button border in black
  display_set_fg_color(BLACK_COLOR);
  display_draw_rounded_rect(440, 425, 120, 50, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so black foreground and active color background
    display_set_fg_color(LIGHTGREY_COLOR);
    display_set_bg_color(ITEM_ACTIVE_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(previous_picture_icon, 483, 438, 33, 24);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_bmp_next_button(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so black background
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so active color background
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Fill in the body of the button
  display_fill_rounded_rect(640, 425, 120, 50, 3);

  //Draw rounded rectangle as button border in black
  display_set_fg_color(BLACK_COLOR);
  display_draw_rounded_rect(640, 425, 120, 50, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so black foreground and active color background
    display_set_fg_color(LIGHTGREY_COLOR);
    display_set_bg_color(ITEM_ACTIVE_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(next_picture_icon, 683, 438, 33, 24);
}

//----------------------------------------------------------------------------------------------------------------------------------
// Top bar function
//----------------------------------------------------------------------------------------------------------------------------------

void scope_menu_button(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark blue background
    display_set_fg_color(DARKBLUE_COLOR);//78
  }
  else
  {
    //Active so pale yellow background
    display_set_fg_color(PALEYELLOW_COLOR);
  }

  //Draw the background
  //display_fill_rounded_rect(0, 0, 80, 38, 3);
  display_fill_rounded_rect(MENU_BUTTON_XPOS, MENU_BUTTON_YPOS, MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active so black foreground
    display_set_fg_color(BLACK_COLOR);
  }

  //Draw the menu symbol
  display_fill_rect(MENU_BUTTON_XPOS+7,  MENU_BUTTON_YPOS+12, 15, 3);
  display_fill_rect(MENU_BUTTON_XPOS+7,  MENU_BUTTON_YPOS+17, 15, 3);
  display_fill_rect(MENU_BUTTON_XPOS+7,  MENU_BUTTON_YPOS+22, 15, 3); 
  /*
  display_fill_rect(MENU_BUTTON_XPOS+6,  MENU_BUTTON_YPOS+11, 7, 7);
  display_fill_rect(MENU_BUTTON_XPOS+15, MENU_BUTTON_YPOS+11, 7, 7);
  display_fill_rect(MENU_BUTTON_XPOS+6,  MENU_BUTTON_YPOS+20, 7, 7);
  display_fill_rect(MENU_BUTTON_XPOS+15, MENU_BUTTON_YPOS+20, 7, 7);
  */
  //Display the text
  display_set_font(&font_3);
  display_text(MENU_BUTTON_XPOS+28, MENU_BUTTON_YPOS+11, "MENU");//32 11
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_main_return_button(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so black background
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //Active so white background
    display_set_fg_color(WHITE_COLOR);
  }

  //Draw the background
  display_fill_rect(0, 0, 80, 38);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(BLACK_COLOR);
  }
  else
  {
    //Active so black foreground and white background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(WHITE_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(return_arrow_icon, 20, 5, 41, 27);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_maxlight_item(int mode)
{
   //Draw the black background
   display_set_fg_color(BLACK_COLOR);
   display_fill_rounded_rect(MAXLIGHT_BUTTON_XPOS, MAXLIGHT_BUTTON_YPOS, MAXLIGHT_BUTTON_WIDTH, MAXLIGHT_BUTTON_HEIGHT, 2); 

  if(mode == 0)
  {
    //Inactive so white foreground and black background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(BLACK_COLOR);
  }
  else if(mode == 2)
  {
    //Active, magenta rounded button
    display_set_fg_color(MAGENTA_COLOR);
    display_fill_rounded_rect(MAXLIGHT_BUTTON_XPOS, MAXLIGHT_BUTTON_YPOS, MAXLIGHT_BUTTON_WIDTH, MAXLIGHT_BUTTON_HEIGHT, 2);
    //Active so black foreground and magenta background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(MAGENTA_COLOR);
  }
  else if(mode == 1)
  {
    //Active so yellow foreground and black background
    display_set_fg_color(YELLOW_COLOR);
    //Active, magenta menu button
    display_set_bg_color(BLACK_COLOR); 
  }
    
  //Display the icon with the set colors
  display_copy_icon_use_colors(light_icon, MAXLIGHT_BUTTON_XPOS+10, MAXLIGHT_BUTTON_YPOS+7, 24, 24);    //light-sun icon 10 5 24 24
  
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(MAXLIGHT_BUTTON_XPOS, MAXLIGHT_BUTTON_YPOS, MAXLIGHT_BUTTON_WIDTH, MAXLIGHT_BUTTON_HEIGHT, 2);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_set_maxlight(int mode)
{
  if(mode == 0)
  {
    scopesettings.maxlight = 0;   //flag set to 0 - no max light
    //Update the actual screen brightness
    fpga_set_translated_brightness();
  }
  else if(mode == 1)
  {
    scopesettings.maxlight = 1;   //flag set to 1 - max light
    //Update the screen brightness to max
    fpga_set_backlight_brightness(60000);   //max brightness
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_run_stop_text(void)
{
  //Check if run or stop mode
  //v1.00z1: WAIT (orange) for Single and Normal while waiting for the trigger: in roll the roll's state (triggerlong),
  //at the normal time base a capture that is not done after 100 ms (trig_waiting, scope_acquire_trace_data)
  uint32 waiting = (scopesettings.triggermode != 0) && (scopesettings.long_mode ? !triggerlong : trig_waiting);

  if(scopesettings.runstate)//ok
  {
    //Run mode. Green box
    //if((scopesettings.triggermode == 1)&&(!triggerlong))
    if(waiting)
        display_set_fg_color(ORANGE_COLOR); 
        else display_set_fg_color(GREEN_COLOR);    
  }
  else
  {
    //Stop mode. Red box
    display_set_fg_color(RED_COLOR);
  }
  
  //Fill the box
  display_fill_rounded_rect(RUN_STOP_TEXT_XPOS, RUN_STOP_TEXT_YPOS, RUN_STOP_TEXT_WIDTH, RUN_STOP_TEXT_HEIGHT, 2);

  //Select the font for the text
  display_set_font(&font_3);

  //Check if run or stop mode
  if(scopesettings.runstate)//ok
  {
    //Run mode. Waiting mode. Black text, 
    display_set_fg_color(BLACK_COLOR);
    //if((scopesettings.triggermode==1)&&(!triggerlong))
    if(waiting)
        {display_text(RUN_STOP_TEXT_XPOS + 2, RUN_STOP_TEXT_YPOS + 1, "WAIT");}//3 1
        else {display_text(RUN_STOP_TEXT_XPOS + 5, RUN_STOP_TEXT_YPOS + 1, "RUN");} //5 1
  }
  else
  {
    //Stop mode. White text
    display_set_fg_color(WHITE_COLOR);
    display_text(RUN_STOP_TEXT_XPOS + 1, RUN_STOP_TEXT_YPOS + 1, "STOP");
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_settings(PCHANNELSETTINGS settings, int mode)
{
  int8 **vdtext = 0;

  //Clear the area first
  display_set_fg_color(BLACK_COLOR);
  display_fill_rounded_rect(settings->buttonxpos, CH_BUTTON_YPOS, CH_BUTTON_BG_WIDTH, CH_BUTTON_BG_HEIGHT, 2);

  //Check if channel is enabled or disabled
  if(settings->enable == 0)
  {
    //Disabled so off colors
    //Check if inactive or active
    if(mode == 0)
    {
      //Inactive, grey menu button
      display_set_fg_color(GREY_COLOR);
    }
    else
    {
      //Active, light grey menu button
      display_set_fg_color(LIGHTGREY2_COLOR);//0x00BBBBBB
    }
  }
  else
  {
    //Enabled so on colors
    //Check if inactive or active
    if(mode == 0)
    {
      //Inactive, channel 1 color menu button (inactive & invert channel = black button)
      if (settings->invert) { display_set_fg_color(BLACK_COLOR);}
        else { display_set_fg_color(settings->color);  }// ak invert black
    }
    else
    {
      //Active, blue menu button
      display_set_fg_color(settings->touchedcolor);
    }
  }

  //Fill the button
  display_fill_rounded_rect(settings->buttonxpos, CH_BUTTON_YPOS, CH_BUTTON_WIDTH, CH_BUTTON_HEIGHT, 2);

  //Select the font for the text
  display_set_font(&font_2);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, black text (inactive & invert channel = yellow text)
    if ((settings->invert)&&(settings->enable)) {display_set_fg_color(settings->color); display_draw_rounded_rect(settings->buttonxpos, CH_BUTTON_YPOS, CH_BUTTON_WIDTH, CH_BUTTON_HEIGHT, 2);}
        else display_set_fg_color(BLACK_COLOR);//zlty text ak inver kanal
  }
  else
  {
    //Active, white text
    display_set_fg_color(WHITE_COLOR);

    //Fill the settings background
    display_fill_rounded_rect(settings->buttonxpos + 30, CH_BUTTON_YPOS, CH_BUTTON_BG_WIDTH - 30, CH_BUTTON_BG_HEIGHT, 2);
  }

  //Display the channel identifier text
  display_text(settings->buttonxpos + 5, CH_BUTTON_YPOS + 11, settings->buttontext);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, white text
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active, black text
    display_set_fg_color(BLACK_COLOR);
  }

  //Check on which coupling is set
  if(settings->coupling == 0)
  {
    //DC coupling
    display_text(settings->buttonxpos + 38, CH_BUTTON_YPOS + 3, "DC");
  }
  else
  {
    //AC coupling
    display_text(settings->buttonxpos + 38, CH_BUTTON_YPOS + 3, "AC");
  }

  //Print the probe magnification factor
  switch(settings->magnification)
  {
    case 0:
      //Times 0.5 magnification
      display_text(settings->buttonxpos + 63, CH_BUTTON_YPOS + 3, "0.5X");

      //Set the (volts per div or ampere per div) text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[0]; else vdtext = (int8 **)volt_div_texts[0];
      break;

    case 1:
      //Times 1 magnification
      display_text(settings->buttonxpos + 61, CH_BUTTON_YPOS + 3, "1X");

      //Set the volts per div text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[1]; else vdtext = (int8 **)volt_div_texts[1];
      break;
      
    case 2:
      //Times 10 magnification
      display_text(settings->buttonxpos + 61, CH_BUTTON_YPOS + 3, "10X");

      //Set the volts per div text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[2]; else vdtext = (int8 **)volt_div_texts[2];
      break;
      
    case 3:
      //Times 20 magnification
      display_text(settings->buttonxpos + 61, CH_BUTTON_YPOS + 3, "20X");

      //Set the volts per div text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[3]; else vdtext = (int8 **)volt_div_texts[3];
      break;
      
    case 4:
      //Times 50 magnification
      display_text(settings->buttonxpos + 61, CH_BUTTON_YPOS + 3, "50X");

      //Set the volts per div text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[4]; else vdtext = (int8 **)volt_div_texts[4];
      break;
      
    case 5:
      //Times 100 magnification
      display_text(settings->buttonxpos + 61, CH_BUTTON_YPOS + 3, "100X");

      //Set the volts per div text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[5]; else vdtext = (int8 **)volt_div_texts[5];
      break;
      
    case 6:
      //Times 1000 magnification
      display_text(settings->buttonxpos + 61, CH_BUTTON_YPOS + 3, "1000X");

      //Set the volts per div text range to be used for this magnification
      if(settings->V_A) vdtext = (int8 **)ampere_div_texts[6]; else vdtext = (int8 **)volt_div_texts[6];
      break;
      
    default: break;
      //Times 100 magnification
      //display_text(settings->buttonxpos + 59, CH_BUTTON_YPOS + 3, "1000X");

      //Set the volts per div text range to be used for this magnification
      //if(settings->V_A) vdtext = (int8 **)ampere_div_texts[2]; else vdtext = (int8 **)volt_div_texts[2];
      
  }

  //Display the sensitivity when in range
  if(settings->displayvoltperdiv < 7)
  {
    display_text(settings->buttonxpos + 38, CH_BUTTON_YPOS + 19, vdtext[settings->displayvoltperdiv]);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00y3: a rectangle of the current screen buffer at 3/8 brightness (a button that does nothing in this view)
//v1.00z2: grey without color instead (owner: the 3/8 darkening looked bad): every pixel to a grey of its brightness,
//squeezed into 0x28 .. 0x80, so the shape, frame and text stay readable, only the color is gone. The black screen
//background stays black.
extern DISPLAYDATA displaydata;

void display_dim_rect(uint32 x, uint32 y, uint32 w, uint32 h)
{
  uint32 i, j, r, g, b, l, v, mx, mn;
  uint16 *p, c;
  uint16 bgc = *(displaydata.screenbuffer + (y * displaydata.pixelsperline) + x);     //v1.00z3: the background
  for(j = y; j < (y + h); j++)
  {
    p = displaydata.screenbuffer + (j * displaydata.pixelsperline) + x;

    for(i = 0; i < w; i++)
    {
      c = p[i];

      //p[i] = ((c >> 2) & 0x39E7) + ((c >> 3) & 0x18E3);
      //v1.00z3: as the V CURSOR button in the frequency response view (owner's pattern): the background (black screen,
      //the menu color at the rectangle's corner) and the neutral dark greys (button faces, frames) stay as they are, so
      //there is no grey bar; light neutral pixels (white / light text) become the grey text 0x606060, colored ones (a
      //selected button, a colored switch) a dark grey 0x484848. (v1.00z2 mapped every pixel to a grey 0x28..0x80.)
      if((c == 0) || (c == bgc))
        continue;

      r = ((c >> 11) & 0x1F) << 3;
      g = ((c >> 5) & 0x3F) << 2;
      b = (c & 0x1F) << 3;
      l = ((r * 77) + (g * 150) + (b * 29)) >> 8;

      mx = (r > g) ? ((r > b) ? r : b) : ((g > b) ? g : b);
      mn = (r < g) ? ((r < b) ? r : b) : ((g < b) ? g : b);

      if((mx - mn) < 24)
      {
        //Neutral: dark ones stay, light ones are the grey text
        if(l <= 0x58)
          continue;

        v = 0x60;
      }
      else
        v = 0x48;

      p[i] = (uint16)(((v >> 3) << 11) | ((v >> 2) << 5) | (v >> 3));
    }
  }
}

void scope_acqusition_settings(int mode)
{
  uint8 a = 0;
  //v1.00z2: native grey look where it does nothing (frequency response view): grey button, grey texts
  int dis = bode_is_active() && !scopesettings.waveviewmode;
  //Clear the area first
  display_set_fg_color(BLACK_COLOR);
  display_fill_rounded_rect(ACQ_BUTTON_XPOS, ACQ_BUTTON_YPOS, ACQ_BUTTON_BG_WIDTH, ACQ_BUTTON_BG_HEIGHT, 2);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, short time base green menu button, if long time base orange
    if (scopesettings.long_mode) display_set_fg_color(ORANGE_COLOR); else display_set_fg_color(GREEN_COLOR);
    if(dis) display_set_fg_color(0x00383838);     //v1.00z2
  }
  else
  {
    //Active, magenta menu button
    display_set_fg_color(MAGENTA_COLOR);
  }

  //Fill the button
  display_fill_rounded_rect(ACQ_BUTTON_XPOS, ACQ_BUTTON_YPOS, ACQ_BUTTON_WIDTH, ACQ_BUTTON_HEIGHT, 2);

  //Select the font for the text
  display_set_font(&font_2);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, black text
    display_set_fg_color(dis ? 0x00707070 : BLACK_COLOR);     //v1.00z2
  }
  else
  {
    //Active, white text
    display_set_fg_color(WHITE_COLOR);

    //Fill the settings background
    display_fill_rounded_rect(ACQ_BUTTON_XPOS + 30, ACQ_BUTTON_YPOS, ACQ_BUTTON_BG_WIDTH - 30, ACQ_BUTTON_BG_HEIGHT, 2);
  }

  //Display the acquisition identifier text
  if (scopesettings.long_mode)
  {
      display_text(ACQ_BUTTON_XPOS + 4, ACQ_BUTTON_YPOS + 3, "ACQ");        //long time base mode
      display_text(ACQ_BUTTON_XPOS + 2, ACQ_BUTTON_YPOS + 17, "Long"); 
  } 
  else 
  {
      if(scopesettings.average_mode) {display_text(ACQ_BUTTON_XPOS + 5, ACQ_BUTTON_YPOS + 17, "avg"); a=8;}    //Average mode 
      display_text(ACQ_BUTTON_XPOS + 4, ACQ_BUTTON_YPOS + 11-a, "ACQ");    //short time base mode
  } 
  
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, white text
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active, black text
    display_set_fg_color(BLACK_COLOR);
  }

  //v1.00z2: grey texts where the button does nothing
  if(dis)
    display_set_fg_color(0x00707070);

  //Only display the text when in range of the text array
  if(scopesettings.samplerate < (sizeof(acquisition_speed_texts) / sizeof(int8 *)))
  {
    //Display the text from the table
    display_text(ACQ_BUTTON_XPOS + 38, ACQ_BUTTON_YPOS + 3, (int8 *)acquisition_speed_texts[scopesettings.samplerate]);
  }

  //Only display the text when in range of the text array
  if(scopesettings.timeperdiv < (sizeof(time_div_texts) / sizeof(int8 *)))
  {
    //Display the text from the table
    display_text(ACQ_BUTTON_XPOS + 38, ACQ_BUTTON_YPOS + 19, (int8 *)time_div_texts[scopesettings.timeperdiv]);
  }

  //v1.00y3: grey (dimmed) in the frequency response view, where it does nothing
  //if(bode_is_active() && !scopesettings.waveviewmode)
  //  display_dim_rect(ACQ_BUTTON_XPOS, ACQ_BUTTON_YPOS, ACQ_BUTTON_BG_WIDTH, ACQ_BUTTON_BG_HEIGHT);
}

//----------------------------------------------------------------------------------------------------------------------------------
/*
#include <stdint.h>

#define REG32(addr) (*(volatile uint32 *)(addr))

//CCU registers (verify on your board) 
#define CCU_BASE              0x01C20000UL
#define CCU_BUS_CLK_GATING0   REG32(CCU_BASE + 0x60)
#define CCU_BUS_SOFT_RST0     REG32(CCU_BASE + 0x2D0)

// WDT registers (verify address on your board) 
#define WDT_BASE              0x01C20CA0UL
#define WDT_CTRL              REG32(WDT_BASE + 0x00)
#define WDT_CFG               REG32(WDT_BASE + 0x04)
#define WDT_MODE              REG32(WDT_BASE + 0x08)

//bits we expect (bit 12 per Allwinner family - verify) 
#define WDT_BUS_BIT           (1 << 12)

static void delay(volatile uint32 n)
{
    while (n--) { asm volatile("nop"); }
}

void dump_regs(void)
{
    volatile uint32_t a, b, c, d;
    a = CCU_BUS_CLK_GATING0;
    b = CCU_BUS_SOFT_RST0;
    c = WDT_CTRL;
    d = WDT_MODE;
    // Replace these with your logging / uart print function 
               usb_send_uint("CLK_GATING0 ", a);
               usb_send_uint("SOFT_RST0 ", b);
               usb_send_uint("WDT_CTRL ", c);
               usb_send_uint("WDT_MODE ", d);


            usb_CDC_in_ep_callback();
    // uart_printf("CLK_GATING0=0x%08x\n", a);
    // uart_printf("SOFT_RST0 =0x%08x\n", b);
    // uart_printf("WDT_CTRL  =0x%08x\n", c);
    // uart_printf("WDT_MODE  =0x%08x\n", d);
    (void)a;(void)b;(void)c;(void)d;
}

int try_enable_wdt_clock(void)
{
    // Try set-gating + set deassert reset (some platforms require set, others clear) 
    uint32 before, after;

    before = CCU_BUS_CLK_GATING0;
    CCU_BUS_CLK_GATING0 = before | WDT_BUS_BIT;
    delay(1000);
    after = CCU_BUS_CLK_GATING0;
    if ((after & WDT_BUS_BIT) == 0) return 0;
*/
//********************

#define WDT_BASE        0x01C20C90
#define WDT_CTRL        (*(volatile uint32 *)(WDT_BASE + 0x00))
#define WDT_CFG         (*(volatile uint32 *)(WDT_BASE + 0x04))
#define WDT_MODE        (*(volatile uint32 *)(WDT_BASE + 0x08))

#define CCM_BASE        0x01C20000
#define BUS_CLK_GATING0 (*(volatile uint32 *)(CCM_BASE + 0x60))
#define BUS_SOFT_RST0   (*(volatile uint32 *)(CCM_BASE + 0x2C))

void wdt_enable_clock(void)
{
    // BIT 31 = Watchdog clock gate
    BUS_CLK_GATING0 |= (1 << 31);
    BUS_SOFT_RST0   |= (1 << 31);
    
//    usb_send_uint("BUS_SOFT_RST0 =  ", BUS_SOFT_RST0); usb_send_uint("CLK_GATING0 =  ", BUS_CLK_GATING0); usb_CDC_in_ep_callback();


            
}
/*
printf("CLK_GATING0 = %08X\n", BUS_CLK_GATING0);
printf("SOFT_RST0   = %08X\n", BUS_SOFT_RST0);
printf("WDT_MODE    = %08X\n", WDT_MODE);
printf("WDT_CTRL    = %08X\n", WDT_CTRL);
*/
void system_reset(void)
{
    wdt_enable_clock();

    // Set shortest timeout (default is 0 -> ~0.5s)
    WDT_CFG = 0x00000000;

    // Enable WDT + enable reset output
    WDT_MODE = (1 << 0) | (1 << 1);
    
//    usb_send_uint("WDT_MODE =  ", WDT_MODE); usb_CDC_in_ep_callback();

    // Start the watchdog
    WDT_CTRL = 0x01;
    
//    usb_send_uint("WDT_CTRL =  ", WDT_CTRL); usb_CDC_in_ep_callback();

    while (1) {}  // do ~0.5 s príde HARD RESET
}

//****************


void scope_move_speed(int mode)
{
  //v1.00z2: native grey look where it does nothing (frequency response, spectrum)
  int dis = (bode_is_active() || spectrum_is_active()) && !scopesettings.waveviewmode;

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark blue background
    display_set_fg_color(DARKBLUE_COLOR);
  }
  else
  {
    //Active so pale yellow background
    display_set_fg_color(PALEYELLOW_COLOR);
  }

  //Draw the background
  if(dis) display_set_fg_color(0x00383838);     //v1.00z2
  display_fill_rounded_rect(MOVE_FAST_BUTTON_XPOS, MOVE_FAST_BUTTON_YPOS, MOVE_FAST_BUTTON_WIDTH, MOVE_FAST_BUTTON_HEIGHT, 2);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white text
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active so black text
    display_set_fg_color(BLACK_COLOR);
    
    //system_reset();
  }

  //Select the font for the text
  display_set_font(&font_3);

  if(dis) display_set_fg_color(0x00707070);     //v1.00z2

  //Display the common text
  display_text(MOVE_FAST_BUTTON_XPOS+6, MOVE_FAST_BUTTON_YPOS+1, "Move");//3 1 496 6
  
  //Check on which speed is set
  if(scopesettings.movespeed == 0)
  {
    display_text(MOVE_FAST_BUTTON_XPOS+12, MOVE_FAST_BUTTON_YPOS+16, "fast");//9 16 502
  }
  else
  {
    display_text(MOVE_FAST_BUTTON_XPOS+9, MOVE_FAST_BUTTON_YPOS+16, "slow");//6 16 499
  }
  
//convert_waveforms_to_csv_excel();  
  //((void (*)(void))0x00000000)();
  //system_reset();
  

  //v1.00y3: grey (dimmed) in the frequency response view, where it does nothing (v1.00y5: in the spectrum view too)
  //if((bode_is_active() || spectrum_is_active()) && !scopesettings.waveviewmode)
  //  display_dim_rect(MOVE_FAST_BUTTON_XPOS, MOVE_FAST_BUTTON_YPOS, MOVE_FAST_BUTTON_WIDTH, MOVE_FAST_BUTTON_HEIGHT);
}



//----------------------------------------------------------------------------------------------------------------------------------

void scope_trigger_settings(int mode)
{
  int8 *modetext = 0;
  //v1.00z2: native grey look where it does nothing (frequency response view)
  int dis = bode_is_active() && !scopesettings.waveviewmode;

  //Clear the area first light gray
  display_set_fg_color(BLACK_COLOR); //LIGHTGREY_COLOR       
  display_fill_rounded_rect(TRIGGER_BUTTON_XPOS, TRIGGER_BUTTON_YPOS, TRIGGER_BUTTON_BG_WIDTH, TRIGGER_BUTTON_BG_HEIGHT, 2);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, green menu button
    display_set_fg_color(TRIGGER_COLOR);
  }
  else
  {
    //Active, magenta menu button
    display_set_fg_color(MAGENTA_COLOR);
  }

  //Fill the button left side
  if(dis) display_set_fg_color(0x00383838);     //v1.00z2
  display_fill_rounded_rect(TRIGGER_BUTTON_XPOS, TRIGGER_BUTTON_YPOS, TRIGGER_BUTTON_WIDTH, TRIGGER_BUTTON_HEIGHT, 2);

  //Select the font for the text
  display_set_font(&font_4);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, black text
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active, white text
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Fill the settings background
  //display_fill_rounded_rect(TRIGGER_BUTTON_XPOS+31, TRIGGER_BUTTON_YPOS, 48, 35, 2);//591 5 48 35
  display_fill_rounded_rect(TRIGGER_BUTTON_XPOS+TRIGGER_BUTTON_WIDTH, TRIGGER_BUTTON_YPOS, 48, 35, 2);//31+48 79
  
  //Display the channel identifier text
  if(dis) display_set_fg_color(0x00707070);     //v1.00z2
  display_text(TRIGGER_BUTTON_XPOS+12, TRIGGER_BUTTON_YPOS+10, "T");

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, white text
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active, black text
    display_set_fg_color(BLACK_COLOR);
  }
  
  //Check on which trigger mode is set
  switch(scopesettings.triggermode)
  {
    case 0:
      modetext = "  Auto";
      break;

    case 1:
      modetext = " Single";
      break;

    case 2:
      modetext = "Normal";
      break;
  }

  //Select the font for the texts
  display_set_font(&font_2);

  //Check if valid setting
  if(dis) display_set_fg_color(0x00707070);     //v1.00z2

  if(modetext)
  {
    //Display the selected text if so
    display_text(TRIGGER_BUTTON_XPOS+36, TRIGGER_BUTTON_YPOS+1, modetext);
  }

  //Clear the area first light gray
  display_set_fg_color(LIGHTGREY_COLOR); 
  //Draw the trigger edge symbol
  trigger_symbol_grey = dis;     //v1.00z2
  scope_trigger_symbol(TRIGGER_BUTTON_XPOS, TRIGGER_BUTTON_YPOS); 
  trigger_symbol_grey = 0;
  
  //============================================================================
  //Check on which channel is used for triggering
  switch(scopesettings.triggerchannel)
  {
    //Channel 1
    case 0:
      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, dark channel 1 trigger color box
        display_set_fg_color(dis ? 0x00505050 : CHANNEL1_TRIG_COLOR);     //v1.00z2
      }
      else
      {
        //Active, some blue box
        display_set_fg_color(0x003333FF);
      }

      //Fill the channel background
      display_fill_rounded_rect(TRIGGER_BUTTON_XPOS+35, TRIGGER_BUTTON_YPOS+19, 28, 14, 2);

      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, black text
        display_set_fg_color(dis ? 0x00909090 : BLACK_COLOR);     //v1.00z2
      }
      else
      {
        //Active, white text
        display_set_fg_color(WHITE_COLOR);
      }

      //Display the text
      display_text(TRIGGER_BUTTON_XPOS+39, TRIGGER_BUTTON_YPOS+19, "CH1");//598
      break;
  //****************************************************************************
    //Channel 2
    case 1:
      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, dark cyan box
        display_set_fg_color(dis ? 0x00505050 : CHANNEL2_TRIG_COLOR);     //v1.00z2
      }
      else
      {
        //Active, some red box
        display_set_fg_color(0x00FF3333);
      }

      //Fill the channel background
      display_fill_rounded_rect(TRIGGER_BUTTON_XPOS+35, TRIGGER_BUTTON_YPOS+19, 28, 14, 2);

      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, black text
        display_set_fg_color(dis ? 0x00909090 : BLACK_COLOR);     //v1.00z2
      }
      else
      {
        //Active, white text
        display_set_fg_color(WHITE_COLOR);
      }

      //Display the text
      display_text(TRIGGER_BUTTON_XPOS+39, TRIGGER_BUTTON_YPOS+19, "CH2");
      break;
  //****************************************************************************    
    //Channel External
    case 2:
      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, dark cyan box
        display_set_fg_color(dis ? 0x00505050 : 0x00FF7000);     //v1.00z2
      }
      else
      {
        //Active, some red box
        display_set_fg_color(0x00FF3333);
      }

      //Fill the channel background
      display_fill_rounded_rect(TRIGGER_BUTTON_XPOS+35, TRIGGER_BUTTON_YPOS+19, 28, 14, 2);

      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, black text
        display_set_fg_color(dis ? 0x00909090 : BLACK_COLOR);     //v1.00z2
      }
      else
      {
        //Active, white text
        display_set_fg_color(WHITE_COLOR);
      }

      //Display the text
      display_text(TRIGGER_BUTTON_XPOS+40, TRIGGER_BUTTON_YPOS+19, "EXT");
      break;
  }

  //v1.00y3: grey (dimmed) in the frequency response view, where it does nothing
  //if(bode_is_active() && !scopesettings.waveviewmode)
  //  display_dim_rect(TRIGGER_BUTTON_XPOS, TRIGGER_BUTTON_YPOS, TRIGGER_BUTTON_BG_WIDTH, TRIGGER_BUTTON_BG_HEIGHT);
}

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------

void scope_generator_settings(int mode)
{
  int8 *modetext = 0;
  
  //buffer for text frequency
  char buffer[16];

  //Clear the area first light gray
  display_set_fg_color(BLACK_COLOR); //LIGHTGREY_COLOR  
 //display_set_fg_color(LIGHTGREY_COLOR); //LIGHTGREY_COLOR    
  display_fill_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_BG_WIDTH, GEN_BUTTON_BG_HEIGHT, 2); //BGW 62

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, green menu button
    display_set_fg_color(GREEN_COLOR);
    display_set_bg_color(BLACK_COLOR); //LIGHTGREY_COLOR 
  }
  else
  {
    //Active, magenta menu button
    display_set_fg_color(MAGENTA_COLOR);
  }

  //Fill the button (with wave)
  //display_draw_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_WIDTH, GEN_BUTTON_HEIGHT, 2);
  display_draw_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_WIDTH-3, 16, 2);
  //display_draw_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_BG_WIDTH, 10, 2);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, orange text
    display_set_fg_color(ORANGE_COLOR);
  }
  else
  {
    //Active, white text
    display_set_fg_color(WHITE_COLOR);
  }

  //Display the icon with the set colors
  //display_copy_icon_use_colors(Generator_menu_icon, GEN_BUTTON_XPOS+2, GEN_BUTTON_YPOS+6, 24, 24);//

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, white text
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active, black text
    display_set_fg_color(WHITE_COLOR);
  }
    
  //Fill the settings background
  display_fill_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_BG_WIDTH, 35, 2);//28+33=61/
  //display_fill_rounded_rect(GEN_BUTTON_XPOS+GEN_BUTTON_WIDTH, GEN_BUTTON_YPOS, 33, 35, 2);//28+33=61
  
    
      //Check if inactive or active
  if(mode == 0)
  {
    //Inactive, white text
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active, black text
    display_set_fg_color(BLACK_COLOR);
  }

  //Check on which trigger mode is set
  switch(fpgasettings.gen_wave_select)
  {
    case 0:
      modetext = "   Sine"; 
      break;

    case 1:
      //modetext = "  Single";
      modetext = "  Square";
      break;

    case 2:
      //modetext = " Normal";
      modetext = "Triangle";
      break;
  }

  //Select the font for the texts
  display_set_font(&font_2);

  //Check if valid setting
 // if(modetext)
 // {
    //Display the selected text if so
    //display_text(GEN_BUTTON_XPOS+30, TRIGGER_BUTTON_YPOS+1, modetext);
  //display_text(GEN_BUTTON_XPOS+31, GEN_BUTTON_YPOS+2, "100%");//+30 +1
  
//      extern uint32 a,b,c,d,e,f;
    
  //  fpgasettings.gen_duty = d;
  //  fpga_set_generator_duty(fpgasettings.gen_duty); 
    
//  fpgasettings.gen_freq = e;
//  fpga_set_generator_freq(fpgasettings.gen_freq);
  
  //convert duty number to text with %
  make_value_to_text(buffer, fpgasettings.gen_duty, '%');
  
  display_text(GEN_BUTTON_XPOS+25, GEN_BUTTON_YPOS+2, buffer);//+30 +1
  
  //display_text(GEN_BUTTON_XPOS+27, GEN_BUTTON_YPOS+2, "100%");//+30 +1
 //display_text(GEN_BUTTON_XPOS+27, GEN_BUTTON_YPOS+10, "100%");//+30 +1

  //Check which generator mode is selected
                               //SQUARE 
  if((fpgasettings.gen_wave_select==0)&&(!mode)) display_set_fg_color(ORANGE_COLOR);
                              //SINE
  else if((fpgasettings.gen_wave_select==1)&&(!mode)) display_set_fg_color(GREEN_COLOR);
                                //TRIANGLE
  else if((fpgasettings.gen_wave_select==2)&&(!mode)) display_set_fg_color(YELLOW_COLOR);
 
  //convert freq number to text with dot and Hz kHz MHz
  make_freq_to_text(buffer, fpgasettings.gen_freq);
  //display_text(GEN_MENU_XPOS + 68, GEN_MENU_YPOS + 132, buffer);
  display_text(GEN_BUTTON_XPOS+6, GEN_BUTTON_YPOS+19, buffer);//
  
  if((fpgasettings.gen_enable)&&(!mode))
  {
    display_set_fg_color(GREEN_COLOR);
    display_draw_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_BG_WIDTH, GEN_BUTTON_BG_HEIGHT, 2);
  }
  else if((!fpgasettings.gen_enable)&&(!mode))
  {
    display_set_fg_color(RED_COLOR);
    display_draw_rounded_rect(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS, GEN_BUTTON_BG_WIDTH, GEN_BUTTON_BG_HEIGHT, 2);
  }
  
  //display_text(GEN_BUTTON_XPOS+31, GEN_BUTTON_YPOS+19, "1kHz");//+30 +1
  //display_text(GEN_BUTTON_XPOS+31, GEN_BUTTON_YPOS+22, "1kHz");//+30 +1
  

  //Clear the area first light gray
  //display_set_fg_color(LIGHTGREY_COLOR); 
  //Draw the trigger edge symbol
  //scope_trigger_symbol(GEN_BUTTON_XPOS, GEN_BUTTON_YPOS);
//-------------
  /*
  //Check on which channel is used for triggering
  switch(scopesettings.triggerchannel)
  {
    //Channel 1
    case 0:
      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, dark channel 1 trigger color box
        display_set_fg_color(CHANNEL1_TRIG_COLOR);
      }
      else
      {
        //Active, some blue box
        display_set_fg_color(0x003333FF);
      }

      //Fill the channel background
      display_fill_rounded_rect(TRIGGER_BUTTON_XPOS+35, TRIGGER_BUTTON_YPOS+19, 28, 14, 2);

      //Check if inactive or active
      if(mode == 0)
      {
        //Inactive, black text
        display_set_fg_color(BLACK_COLOR);
      }
      else
      {
        //Active, white text
        display_set_fg_color(WHITE_COLOR);
      }

      //Display the text
      display_text(TRIGGER_BUTTON_XPOS+39, TRIGGER_BUTTON_YPOS+19, "CH1");//598
      break;

  }
  //---------------
  */
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_battery_status(void)
{   
  uint32    batterychargelevel;
  uint32    batterycharging; 
  //uint32    xpos = 703;   //position text xxx % battery
  
  batterychargelevel = scopesettings.batterychargelevel;
  batterycharging = scopesettings.batterycharging;
  
  //Prepare the battery symbol in a working buffer to avoid flicker
  display_set_screen_buffer(displaybuffertmp);//1

  //Clear the background
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(701, 5, 25, 13);//700 5 26 13

  //Draw an empty battery symbol in white
  display_set_fg_color(WHITE_COLOR);
  display_fill_rect(701, 9, 2, 4);//700
  display_fill_rect(703, 5, 22, 12);//702 5 23 12

  //Check if there is any charge
  if(batterychargelevel)
  {
    //Keep charge level on max if above
    if(batterychargelevel > 20)
    {
      //Max for displaying the level
      batterychargelevel = 20;
    }

    //Check if charge level is low
    if(batterychargelevel < 4)
    {
      //Draw the level indicator in red
      display_set_fg_color(RED_COLOR);
    }
    else
    {
      //Draw the level indicator in dark green
      display_set_fg_color(DARKGREEN_COLOR);
    }

    //Draw the indicator based on the level
    display_fill_rect(724 - batterychargelevel, 6, batterychargelevel, 10);//723
  }

  //Draw the battery charging indicator when plugged in
  if(batterycharging)
  {
#if 0
    //Some light blue color
    display_set_fg_color(0x002222FF);

    //Draw an arrow when charging
    display_draw_horz_line(10, 708, 718);
    display_draw_horz_line(11, 708, 718);
    display_draw_horz_line(12, 708, 718);
    display_draw_vert_line(719, 8, 14);
    display_draw_vert_line(720, 9, 13);
    display_draw_vert_line(721, 10, 12);
    display_draw_vert_line(722, 11, 11);
#else
    //Some orange color
    display_set_fg_color(0x00FF6A00);

    //Draw a lightning bolt when charging
    display_draw_horz_line( 7, 715, 716);
    display_draw_horz_line( 8, 713, 716);
    display_draw_horz_line( 9, 711, 715);
    display_draw_horz_line(10, 709, 715);
    display_draw_horz_line(11, 707, 711);
    display_draw_horz_line(12, 705, 709);
    display_draw_horz_line(11, 713, 715);
    display_draw_horz_line(10, 719, 723);
    display_draw_horz_line(11, 717, 721);
    display_draw_horz_line(12, 713, 719);
    display_draw_horz_line(13, 713, 717);
    display_draw_horz_line(14, 712, 715);
    display_draw_horz_line(15, 712, 713);
#endif
  } 
  ///*
  else
  {
      
    if (batterychargelevel < 20)
    {
        //Display the text xx capacity in %
        display_set_fg_color(DARKBLUE_COLOR);
        display_set_font(&font_2);
        display_decimal(708, 4, batterychargelevel*5 );//703 5
    //if (batterychargelevel < 20) xpos += 5;// move text right if <100%
    //display_decimal(xpos, 5, batterychargelevel*6 );//703 5
    }
  }
  //*/
  //Copy it to the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(701, 5, 25, 13);//700 5 26 13
}

//----------------------------------------------------------------------------------------------------------------------------------
// Menu functions
//----------------------------------------------------------------------------------------------------------------------------------

//v1.00q5: main menu with eight rows as in the MCP firmware (Scope, Spectrum analyser, Frequency response, Saved pictures,
//Saved waveforms, Settings, Diagnostics, USB drive). The original five-row menu is kept below under #if 0.

//Row labels: two lines, or one line centred vertically when the second is empty
static const char *const mm_line1[MM_ROWS] = { "Scope", "Spectrum", "Frequency", "Saved",    "Saved",     "Settings", "Diagnostics", "USB drive" };
static const char *const mm_line2[MM_ROWS] = { "",      "analyser", "response",  "pictures", "waveforms", "",         "",            ""          };

#define MM_AXIS_COLOR      0x00707070     //Axes of the drawn icons
#define MM_DISABLED_COLOR  0x00686868     //Icon and text of a row that is not available yet

extern DISPLAYDATA displaydata;     //display_lib.c (current font for mm_text_width)

//Width in pixels of a text in the current (variable width) font
static uint32 mm_text_width(const char *text)
{
  PFONTDATA        font = displaydata.font;
  PFONTINFORMATION info;
  uint32           width = 0;

  if(font->type != VARIABLE_WIDTH_FONT)
    return(0);

  while(*text)
  {
    info = check_char_in_vw_font(font->fontinformation, (uint16)(uint8)*text);

    if(info)
      width += info->fontmetrics[(uint8)*text - info->first_char].width;

    text++;
  }

  return(width);
}

//First y of the row's hit area
static uint32 mm_row_top(int row)
{
  return(MAIN_MENU_YPOS + (row * MM_PITCH));
}

//Scope: a sine over a cross of axes
static void scope_main_menu_wave_icon(uint32 y, uint32 fg)
{
  static const uint8 sine[25] = { 19, 16, 14, 12, 10, 9, 9, 9, 10, 12, 14, 16, 19, 21, 23, 25, 27, 28, 28, 28, 27, 25, 23, 21, 19 };
  uint32 x = MAIN_MENU_XPOS + 15;
  uint32 i;

  display_set_fg_color(MM_AXIS_COLOR);
  display_draw_horz_line(y + 19, x, x + 24);
  display_draw_vert_line(x + 12, y + 8, y + 29);
  display_set_fg_color(fg);

  for(i = 1; i < sizeof(sine); i++)
    display_draw_line(x + i - 1, y + sine[i - 1], x + i, y + sine[i]);
}

//Spectrum analyser: a base line with spectral lines, in the current foreground color
static void scope_main_menu_spectrum_icon(uint32 y)
{
  static const uint8 bars[] = { 4, 7, 22, 9, 5, 14, 4, 6, 10, 3, 5, 2 };
  uint32 i;

  display_draw_horz_line(y + 30, MAIN_MENU_XPOS + 15, MAIN_MENU_XPOS + 40);

  for(i = 0; i < sizeof(bars); i++)
    display_draw_vert_line(MAIN_MENU_XPOS + 16 + (2 * i), y + 29 - bars[i], y + 29);
}

//Frequency response: a low-pass magnitude response over an L frame
static void scope_main_menu_bode_icon(uint32 y, uint32 fg)
{
  uint32 x = MAIN_MENU_XPOS + 15;

  display_set_fg_color(MM_AXIS_COLOR);
  display_draw_vert_line(x, y + 8, y + 29);
  display_draw_horz_line(y + 29, x, x + 24);

  display_set_fg_color(fg);
  display_draw_horz_line(y + 12, x + 2, x + 10);
  display_draw_horz_line(y + 13, x + 11, x + 12);
  display_draw_line(x + 13, y + 14, x + 24, y + 25);
}

void scope_open_main_menu(void)
{
  int row;

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(MAIN_MENU_XPOS, MAIN_MENU_YPOS, MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(MAIN_MENU_XPOS, MAIN_MENU_YPOS, MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT);

  //Black lines between the rows, on the last line of every row but the last
  display_set_fg_color(BLACK_COLOR);

  for(row = 0; row < (MM_ROWS - 1); row++)
    display_draw_horz_line(mm_row_top(row) + MM_PITCH - 1, 9, 140);

  //Display the menu items
  for(row = 0; row < MM_ROWS; row++)
    scope_main_menu_item(row, 0);

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_top_rect_onto_screen(MAIN_MENU_XPOS, MAIN_MENU_YPOS, MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT, 63039);
}

//----------------------------------------------------------------------------------------------------------------------------------

//One row of the main menu: mode 0 inactive, 1 active (Settings stays yellow while its menu is open, others light grey)
void scope_main_menu_item(int row, int mode)
{
  uint32 y  = mm_row_top(row) + MM_BTN_DY;
  uint32 bg = (mode == 0) ? DARKGREY_COLOR : (row == MM_ROW_SETTINGS) ? YELLOW_COLOR : 0x00CCCCCC;
  uint32 xc = MAIN_MENU_XPOS + 93;
  uint32 fg;
  int    disabled = ((row == MM_ROW_SPECTRUM) && !MM_SPECTRUM_AVAILABLE) || ((row == MM_ROW_BODE) && !MM_BODE_AVAILABLE);

  if((row < 0) || (row >= MM_ROWS))
    return;

  //Draw the background
  display_set_fg_color(bg);
  display_fill_rounded_rect(MM_BTN_X, y, MM_BTN_W, MM_BTN_H, 3);

  //Foreground: black on an active row, grey on a row that is not available yet, else white
  fg = (mode != 0) ? BLACK_COLOR : disabled ? MM_DISABLED_COLOR : WHITE_COLOR;
  display_set_fg_color(fg);
  display_set_bg_color(bg);

  //Display the icon with the set colors
  switch(row)
  {
    case MM_ROW_SCOPE:       scope_main_menu_wave_icon(y, fg); break;
    case MM_ROW_SPECTRUM:    scope_main_menu_spectrum_icon(y); break;
    case MM_ROW_BODE:        scope_main_menu_bode_icon(y, fg); break;
    case MM_ROW_PICTURES:    display_copy_icon_use_colors(picture_view_icon, MAIN_MENU_XPOS + 15, y + 6, 24, 24); break;
    case MM_ROW_WAVEFORMS:   display_copy_icon_use_colors(waveform_view_icon, MAIN_MENU_XPOS + 15, y + 6, 24, 24); break;
    //v1.00s4: the Other settings icon here (as MCP)
    case MM_ROW_SETTINGS:    display_copy_icon_use_colors(Other_settings_icon, MAIN_MENU_XPOS + 15, y + 6, 24, 24); break;
    case MM_ROW_DIAGNOSTICS: display_copy_icon_use_colors(diagnostic_view_icon, MAIN_MENU_XPOS + 15, y + 4, 24, 24); break;
    default:                 display_copy_icon_use_colors(usb_icon, MAIN_MENU_XPOS + 18, y + 2, 18, 25); break;
  }

  //The label centred right of the icon: two lines, or one in the middle
  display_set_fg_color(fg);
  display_set_font(&font_3);

  //v1.00v5: the saved pictures and saved files rows name the files of the active view
  {
    const char *l1 = mm_line1[row];
    const char *l2 = mm_line2[row];

    if(bode_is_active() || spectrum_is_active())
    {
      if(row == MM_ROW_PICTURES)
      {
        l1 = bode_is_active() ? "Bode" : "Spectrum";
        l2 = "pictures";
      }
      else if(row == MM_ROW_WAVEFORMS)
        l2 = bode_is_active() ? "Bode" : "spectrum";
    }

    if(l2[0])
    {
      display_text(xc - (mm_text_width(l1) / 2), y + 1, (int8 *)l1);
      display_text(xc - (mm_text_width(l2) / 2), y + 17, (int8 *)l2);
    }
    else
    {
      display_text(xc - (mm_text_width(l1) / 2), y + 9, (int8 *)l1);
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//The functions of the original menu, kept for the existing callers

void scope_main_menu_system_settings(int mode)
{
  scope_main_menu_item(MM_ROW_SETTINGS, mode);
}

void scope_main_menu_picture_view(int mode)
{
  scope_main_menu_item(MM_ROW_PICTURES, mode);
}

void scope_main_menu_waveform_view(int mode)
{
  scope_main_menu_item(MM_ROW_WAVEFORMS, mode);
}

void scope_main_menu_diagnostic_view(int mode)
{
  scope_main_menu_item(MM_ROW_DIAGNOSTICS, mode);
}

void scope_main_menu_usb_connection(int mode)
{
  scope_main_menu_item(MM_ROW_USB, mode);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Original five-row main menu (up to v1.00q4), replaced by scope_main_menu_item in v1.00q5

#if 0
void scope_open_main_menu(void)
{
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(2, 46, 147, 292);//0  149 233

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(2, 46, 147, 292);//0  149 233

  //Three black lines between the settings
  display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(104, 9, 140);//59
  display_draw_horz_line(163, 9, 140);
  display_draw_horz_line(222, 9, 140);
  display_draw_horz_line(281, 9, 140);//222+59

  //Display the menu items
  scope_main_menu_system_settings(0);
  scope_main_menu_picture_view(0);
  scope_main_menu_waveform_view(0);
  scope_main_menu_diagnostic_view(0);
  scope_main_menu_usb_connection(0);

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_top_rect_onto_screen(2, 46, 147, 292, 63039);//3  149 233
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_main_menu_system_settings(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  display_fill_rounded_rect(9, 59, 131, 35, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(system_settings_icon, MAIN_MENU_XPOS+19, 64, 15, 25);//21
  //display_copy_icon_use_colors(Right_drop_menu_icon, MAIN_MENU_XPOS+110, 65, 24, 24);//211

  //Display the text
  display_set_font(&font_3);
  display_text(69, 60, "System");
  display_text(68, 76, "settings");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_main_menu_picture_view(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so white background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(9, 116, 131, 35, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and white background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(0x00CCCCCC);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(picture_view_icon, MAIN_MENU_XPOS+15, 122, 24, 24);

  //Display the text
  display_set_font(&font_3);
  display_text(73, 119, "Picture");
  display_text(79, 135, "view");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_main_menu_waveform_view(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so white background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(9, 175, 131, 35, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and white background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(0x00CCCCCC);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(waveform_view_icon, MAIN_MENU_XPOS+15, 181, 24, 24);

  //Display the text
  display_set_font(&font_3);
  display_text(62, 178, "Waveform");
  display_text(79, 194, "view");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_main_menu_diagnostic_view(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so white background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(9, 235, 131, 35, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and white background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(0x00CCCCCC);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(diagnostic_view_icon, MAIN_MENU_XPOS+15, 239, 24, 24);

  //diagnostic_view_icon
  //Display the text
  display_set_font(&font_3);
  display_text(60, 237, "Diagnostic");
  display_text(79, 253, "view");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_main_menu_usb_connection(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so white background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(9, 295, 131, 35, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and white background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(0x00CCCCCC);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(usb_icon, MAIN_MENU_XPOS+18, 297, 18, 25);//20

  //Display the text
  display_set_font(&font_3);
  display_text(80, 296, "USB");
  display_text(60, 312, "connection");
}

#endif

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_channel_menu(PCHANNELSETTINGS settings)
{
  uint32 xstart;
  uint32 xend;
  
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1
  //display_set_screen_buffer(displaybuffer1);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(settings->menuxpos, CH_MENU_YPOS, CH_MENU_WIDTH, CH_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  //display_set_fg_color(LIGHTGREY_COLOR);
  
    //Set channel color
  display_set_fg_color(settings->color);

  //Draw the edge
  display_draw_rect(settings->menuxpos, CH_MENU_YPOS, CH_MENU_WIDTH, CH_MENU_HEIGHT);

  //Line start and end x positions
  xstart = settings->menuxpos + 8;//14
  //xend   = settings->menuxpos + CH_MENU_WIDTH - 4;//-4
  xend   = settings->menuxpos + 164;//+168//-4

  //Three black lines between the settings
  //display_set_fg_color(BLACK_COLOR);
    //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_horz_line(CH_MENU_YPOS +  56, xstart, xend); //56
  display_draw_horz_line(CH_MENU_YPOS + 112, xstart, xend); //112
  display_draw_horz_line(CH_MENU_YPOS + 168, xstart, xend); //168
  display_draw_horz_line(CH_MENU_YPOS + 224, xstart, xend); //224
  
  //Set channel color
  display_set_fg_color(settings->color);
  //display_draw_horz_line(CH_MENU_YPOS + 280, xstart, xend); //280
  display_draw_horz_line(CH_MENU_YPOS + 280, settings->menuxpos, settings->menuxpos + 343); //280 330
  
  //One black lines between the sensitivity
  //display_set_fg_color(BLACK_COLOR);
    //Set channel color
  //display_set_fg_color(settings->color);
  
    
  //Set channel color
  display_set_fg_color(settings->color);
  //One channel_color lines the settings and sensitivity
  display_draw_vert_line(settings->menuxpos + 171,CH_MENU_YPOS, CH_MENU_YPOS+279);//171 4 239
    
  display_draw_vert_line(settings->menuxpos + 284, CH_MENU_YPOS + 280, CH_MENU_YPOS + CH_MENU_HEIGHT);
  
  //display_draw_vert_line(settings->menuxpos + 252,CH_MENU_YPOS+4, CH_MENU_YPOS+279);//252 4 239
  display_draw_vert_line(settings->menuxpos + 343, CH_MENU_YPOS, CH_MENU_YPOS + CH_MENU_HEIGHT);//343 +4 +279//334 4 279 //252 4 239

  //Main texts in white
  display_set_fg_color(WHITE_COLOR);

  //Select the font for the texts
  display_set_font(&font_3);
  
  //Display the texts
  display_text(settings->menuxpos + 15, CH_MENU_YPOS +  10, "Open");    //12
  display_text(settings->menuxpos + 23, CH_MENU_YPOS +  29, "CH");      //31
  
  //v1.00z3: "Open FFT" removed from the channel menu (owner: it will never be there); the row stays free
  //display_text(settings->menuxpos + 15, CH_MENU_YPOS +  66, "Open");    //72
  //display_text(settings->menuxpos + 20, CH_MENU_YPOS +  85, "FFT");     //19 91
  //v1.01a2: the row is the I2C decoder switch
  //display_text(settings->menuxpos +  9, CH_MENU_YPOS +  66, "Decode");
  //display_text(settings->menuxpos + 22, CH_MENU_YPOS +  85, "I2C");
  //v1.01b1: drawn by scope_channel_i2c_select with the protocol's name
  
  display_text(settings->menuxpos + 14, CH_MENU_YPOS +  122, "Invert"); //13 72
  display_text(settings->menuxpos + 23, CH_MENU_YPOS +  141, "CH");     //91
  
  
  display_text(settings->menuxpos + 15, CH_MENU_YPOS + 178, "Coup");    //132
  display_text(settings->menuxpos + 19, CH_MENU_YPOS + 197, "ling");    //18 151
  
  display_text(settings->menuxpos + 15, CH_MENU_YPOS + 234, "V / A");   //192
  display_text(settings->menuxpos + 12, CH_MENU_YPOS + 253, "mode");    //211
  
  display_text(settings->menuxpos + 14, CH_MENU_YPOS + 290, "Probe");   //15 252
  display_text(settings->menuxpos + 15, CH_MENU_YPOS + 309, "mode");    //271
  
  //****************************************************************
  //display_text(settings->menuxpos + 368, CH_MENU_YPOS + 10, "REF");   
  //display_text(settings->menuxpos + 363, CH_MENU_YPOS + 25, "mode"); 
  
  //display_text(settings->menuxpos + 363, CH_MENU_YPOS + 56, "MATH");   
  //display_text(settings->menuxpos + 363, CH_MENU_YPOS + 71, "mode");
  
  //Draw the edge in a lighter grey
 // display_set_fg_color(LIGHTGREY_COLOR);// netreba ?
  //display_set_fg_color(GREY_COLOR);//GREY_COLOR
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 6, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);//netreba ?

  
  //clear flag for touch 50% button in channel menu
  trigger50 = 0;

  //Display the actual settings
  scope_channel_enable_select(settings);
  //scope_channel_fft_show(settings);     //v1.00z3: removed
  //scope_channel_i2c_select(settings);     //v1.01a2   v1.01b6: removed from the channel menus
  scope_channel_invert_select(settings);
  scope_channel_coupling_select(settings);
  scope_channel_VA_select(settings);
  scope_channel_probe_magnification_select(settings);
  scope_channel_sensitivity_select(settings);
  scope_channel_ref_menu_item(settings, 0);
  scope_channel_math_menu_item(settings, 0);
  //scope_channel_ref_select(settings);

  //Set source and target for getting it on the actual screen 
  display_set_source_buffer(displaybuffertmp);//1
  //display_set_source_buffer(displaybuffer1);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_top_rect_onto_screen(settings->menuxpos, CH_MENU_YPOS, CH_MENU_WIDTH, CH_MENU_HEIGHT, 69906);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_enable_select(PCHANNELSETTINGS settings)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);
  
  //Show the state (if channel is disabled or enabled)
  scope_display_slide_button(settings->menuxpos + 98, CH_MENU_YPOS + 18, settings->enable, settings->color);//98 22
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_fft_show(PCHANNELSETTINGS settings)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);

 //Show the state (if FFT is disabled or enabled)
  //scope_display_slide_button(settings->menuxpos + 98, CH_MENU_YPOS + 74, settings->fftenable, GREEN_COLOR);//82
  //v1.01b6: the row of the former Decode stays empty (no switch)
}
//----------------------------------------------------------------------------------------------------------------------------------

//v1.01a2: the I2C decoder switch in the channel menu (the row of the former Open FFT)
void scope_channel_i2c_select(PCHANNELSETTINGS settings)
{
  //v1.01b1: "Decode" and the protocol (I2C / UART / SPI) left of the switch
  //v1.01b2: in a frame (it opens the decoder's window), both lines centred
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(settings->menuxpos + 6, CH_MENU_YPOS + 61, 74, 46);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(settings->menuxpos + 6, CH_MENU_YPOS + 61, 74, 46, 3);
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(settings->menuxpos + 43 - (mm_text_width("Decode") / 2), CH_MENU_YPOS +  66, "Decode");
  display_text(settings->menuxpos + 43 - (mm_text_width(scope_dec_name()) / 2), CH_MENU_YPOS +  85, (int8 *)scope_dec_name());

  display_set_font(&font_3);
  display_set_fg_color(DARKGREY_COLOR);
  scope_display_slide_button(settings->menuxpos + 98, CH_MENU_YPOS + 74, scope_i2c_enabled, ORANGE_COLOR);
}

void scope_channel_invert_select(PCHANNELSETTINGS settings)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);
 
 //Show the state (if invert is disabled or enabled)
  scope_display_slide_button(settings->menuxpos + 98, CH_MENU_YPOS + 130, settings->invert, GREEN_COLOR);//82
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_coupling_select(PCHANNELSETTINGS settings)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);

  //Check if coupling is dc or ac
  if(settings->coupling == 0)
  {
    //DC so dark grey box behind ac text
    display_fill_rect(settings->menuxpos + 130, CH_MENU_YPOS + 185, 32, 22);//139
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(settings->menuxpos + 130, CH_MENU_YPOS + 185, 32, 22, 2);
  }
  else
  {
    //AC so dark grey box behind dc text
    display_fill_rect(settings->menuxpos + 78, CH_MENU_YPOS + 185, 32, 22);//139
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(settings->menuxpos + 78, CH_MENU_YPOS + 185, 32, 22, 2);
  }

  //Set channel color for the box behind the selected text
  display_set_fg_color(settings->color);

  //Check if coupling is dc or ac
  if(settings->coupling == 0)
  {
    //DC so channel color box behind dc text
    display_fill_rounded_rect(settings->menuxpos + 78, CH_MENU_YPOS + 185, 32, 22, 2);
  }
  else
  {
    //AC so channel color box behind ac text
    display_fill_rounded_rect(settings->menuxpos + 130, CH_MENU_YPOS + 185, 32, 22, 2);
  }

  //Check if coupling is dc or ac
  if(settings->coupling == 0)
  {
    //DC so black DC text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //AC so white or grey DC text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the DC text
  display_text(settings->menuxpos + 85, CH_MENU_YPOS + 188, "DC");//145

  //Check if coupling is DC or AC
  if(settings->coupling == 0)
  {
    //DC so white or grey AC text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }
  else
  {
    //AC so black AC text
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the off text
  display_text(settings->menuxpos + 137, CH_MENU_YPOS + 188, "AC");//145
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_VA_select(PCHANNELSETTINGS settings)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);

  //Check if measures is V or A
  if(settings->V_A == 0)
  {
    //V so dark grey box behind A text
    display_fill_rect(settings->menuxpos + 130, CH_MENU_YPOS + 241, 32, 22);//199
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(settings->menuxpos + 130, CH_MENU_YPOS + 241, 32, 22, 2);
  }
  else
  {
    //A so dark grey box behind V text
    display_fill_rect(settings->menuxpos + 78, CH_MENU_YPOS + 241, 32, 22);
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(settings->menuxpos + 78, CH_MENU_YPOS + 241, 32, 22, 2);
  }

  //Set channel color for the box behind the selected text
  display_set_fg_color(settings->color);

  //Check if measures is V or A
  if(settings->V_A == 0)
  {
    //V so channel color box behind V text
    display_fill_rounded_rect(settings->menuxpos + 78, CH_MENU_YPOS + 241, 32, 22, 2);
  }
  else
  {
    //A so channel color box behind A text
    display_fill_rounded_rect(settings->menuxpos + 130, CH_MENU_YPOS + 241, 32, 22, 2);
  }

  //Check if measures is V or A
  if(settings->V_A == 0)
  {
    //V so black V text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //V so white or grey A text
    if(scopesettings.waveviewmode)
    {  
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the V text
  display_text(settings->menuxpos + 90, CH_MENU_YPOS + 244, "V");//85 202

  //Check if measures is V or A
  if(settings->V_A == 0)
  {
    //V so white or grey A text
    if(scopesettings.waveviewmode)
    {  
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }
  else
  {
    //A so black A text
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the off text
  display_text(settings->menuxpos + 142, CH_MENU_YPOS + 244, "A");//137 202
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_probe_magnification_select(PCHANNELSETTINGS settings)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);

  //dark grey 0.5-1-10-20-50-100-1000 magnification
  display_fill_rect(settings->menuxpos + 67,  CH_MENU_YPOS + 286, 213, 40);//72 250
  
  //Set channel color for the box behind the selected text
  display_set_fg_color(settings->color);

  //Check if which magnification to highlight
  switch(settings->magnification)
  {
    case 0:
      //Highlight times 0.5 magnification //0
      display_fill_rounded_rect(settings->menuxpos + 67, CH_MENU_YPOS + 286, 25, 40, 2);//72 250
      break;

    case 1:
      //Highlight times 1 magnification    //1
      display_fill_rounded_rect(settings->menuxpos + 97, CH_MENU_YPOS + 286, 25, 40, 2);//102
      break;
      
    case 2:
      //Highlight times 10 magnification     //0 77
      display_fill_rounded_rect(settings->menuxpos + 127, CH_MENU_YPOS + 286, 25, 40, 2);//132
      break;

    case 3:
      //Highlight times 10 magnification    //1 107
      display_fill_rounded_rect(settings->menuxpos + 157, CH_MENU_YPOS + 286, 25, 40, 2);//162
      break;  
   
    case 4:
      //Highlight times 100 magnification   //default   137
      display_fill_rounded_rect(settings->menuxpos + 187, CH_MENU_YPOS + 286, 25, 40, 2);//192
      break;
      
    case 5:
      //Highlight times 500 magnification   
      display_fill_rounded_rect(settings->menuxpos + 217, CH_MENU_YPOS + 286, 25, 40, 2);//222
      break;
      
    case 6:
      //Highlight times 1000 magnification  
      display_fill_rounded_rect(settings->menuxpos + 249, CH_MENU_YPOS + 286, 31, 40, 2);//252
      break;
      
      default: break;
  }
  
  //--------------------------------------------------------------------
   //Check if magnification is 0.5X
  if(settings->magnification == 0)
  {
    //Yes so black 0.5X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 0.5 text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 0.5X text
  display_text(settings->menuxpos + 71, CH_MENU_YPOS + 290, "0.5"); //71 252
  display_text(settings->menuxpos + 75, CH_MENU_YPOS + 307, "X");   //75 271
  //--------------------------------------------------------------------
 //Check if magnification is 1x
  if(settings->magnification == 1)
  {
    //Yes so black 1X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 1 text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 1X text
  display_text(settings->menuxpos + 106, CH_MENU_YPOS + 290, "1");//+27
  display_text(settings->menuxpos + 105, CH_MENU_YPOS + 307, "X");// +31
   
  //--------------------------------------------------------------------
  //Check if magnification is 10x
  if(settings->magnification == 2)  //0
  {
    //Yes so black 10X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 10X text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 10X text
  display_text(settings->menuxpos + 133, CH_MENU_YPOS + 290, "10");// +27 na 10x
  display_text(settings->menuxpos + 135, CH_MENU_YPOS + 307, "X");// +31 na x10
  //--------------------------------------------------------------------
  //Check if magnification is 20x
  if(settings->magnification == 3)  //1
  {
    //Yes so black 20X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 20X text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 20X text
  display_text(settings->menuxpos + 163, CH_MENU_YPOS + 290, "20");// +30 na x100
  display_text(settings->menuxpos + 165, CH_MENU_YPOS + 307, "X");//  +34 na x100
  //--------------------------------------------------------------------
  //Check if magnification is 50x
  if(settings->magnification == 4)  //1
  {
    //Yes so black 50X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 50X text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 50X text
  display_text(settings->menuxpos + 193, CH_MENU_YPOS + 290, "50");// +30 na x100
  display_text(settings->menuxpos + 195, CH_MENU_YPOS + 307, "X");//  +34 na x100
  //--------------------------------------------------------------------
  //Check if magnification is 100x
  if(settings->magnification == 5)
  {
    //Yes so black 100X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 100X text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 100X text
  display_text(settings->menuxpos + 219, CH_MENU_YPOS + 290, "100");//194
  display_text(settings->menuxpos + 225, CH_MENU_YPOS + 307, "X");//200
  //--------------------------------------------------------------------
  /*
  //Check if magnification is 500x
  if(settings->magnification == 5)
  {
    //Yes so black 500X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 500X text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 500X text
  display_text(settings->menuxpos + 224, CH_MENU_YPOS + 252, "500");
  display_text(settings->menuxpos + 230, CH_MENU_YPOS + 271, "X");
   */
  //--------------------------------------------------------------------
  //Check if magnification is 1000x
  if(settings->magnification == 6)  //1
  {
    //Yes so black 1000X text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //No so white or grey 1000X text
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the 1000X text
  display_text(settings->menuxpos + 250, CH_MENU_YPOS + 290, "1000");//257 1k
  display_text(settings->menuxpos + 260, CH_MENU_YPOS + 307, "X");
//******************************************************************************
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_sensitivity_select(PCHANNELSETTINGS settings)
{      
  uint32 i,j,x,y;
  
  //Clear the boxes for the not selected items
  for(i=0;i<7;i++)//12 //7
  {
    if (i<6) {x = 178;j=i;} else {x = 261;j=i-6;}//178 260 -6//<4 177*258
    //y = ((i & 7) * 46) + 3;    //3 *56+8
    y = (j * 46) + 6;    //3 *56+8
    
    if(i == (6 - settings->displayvoltperdiv))
        //Set channel color for the box behind the selected text
        display_set_fg_color(settings->color);
    else   
        //Set dark grey color for the boxes behind the not selected texts
        display_set_fg_color(DARKGREY_COLOR); 
    
    display_fill_rounded_rect(settings->menuxpos + x, CH_MENU_YPOS + y, 76, 40, 3);//70*40 70*48 70*22 48*22
    
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(settings->menuxpos + x, CH_MENU_YPOS + y, 76, 40, 3);
  }

  //Select the font for the texts
  display_set_font(&font_3);
  
  for(i=0;i<7;i++)//12//7
  {
    //y = ((i & 3) * 56) + 19; //*56 +19
    
    if(i == (6 - settings->displayvoltperdiv))
        //Set channel color for the box behind the selected text
        display_set_fg_color(BLACK_COLOR);
    else   
        //Set dark grey color for the boxes behind the not selected texts
        display_set_fg_color(WHITE_COLOR); 

    //Calculate the position of this text
    x = volt_div_texts_x_offsets[settings->magnification][6-i]+3;//11-i
    if (i<6) {j=i;} else {j=i-6;}
    y = (j * 46) + 17;//*56 +20

    //Check if measures is V or A
    //Display the text from the table
    if(settings->V_A == 0)
        display_text(settings->menuxpos + x, CH_MENU_YPOS + y,  (int8 *)volt_div_texts[settings->magnification][6-i]);//11-i //6-i
    else
        display_text(settings->menuxpos + x, CH_MENU_YPOS + y,  (int8 *)ampere_div_texts[settings->magnification][6-i]);
  }
  //********************************************************
  if(trigger50)
    {
      //Set channel color for the box behind the selected text
      display_set_fg_color(settings->color);
      display_fill_rounded_rect(settings->menuxpos + 291, CH_MENU_YPOS + 295, 45, 22, 2);//290 295 //270 185  //270 199 45 22
      //Texts in black
      display_set_fg_color(BLACK_COLOR);
      //display_text(settings->menuxpos + 283, CH_MENU_YPOS + 188, "50%");//283 188 //283 202
    }
    else      
    {
    //Set channel color rounded the box the selected active trigger channel 
      if((scopesettings.triggerchannel == 0)&&(settings->color == CHANNEL1_COLOR)) display_set_fg_color(CHANNEL1_COLOR);
      else if((scopesettings.triggerchannel == 1)&&(settings->color == CHANNEL2_COLOR)) display_set_fg_color(CHANNEL2_COLOR);
              else display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(settings->menuxpos + 291, CH_MENU_YPOS + 295, 45, 22, 2);//270 185 //270 199 45 22
      //Texts in white
      display_set_fg_color(WHITE_COLOR);  
    }
  
  display_text(settings->menuxpos + 303, CH_MENU_YPOS + 298, "50%");//283 188  //283 202
  
  //display_text(settings->menuxpos + 250, CH_MENU_YPOS + 290, "1000");//257 1k
  //display_text(settings->menuxpos + 260, CH_MENU_YPOS + 307, "X");
  
   // display_draw_vert_line(settings->menuxpos + 284, CH_MENU_YPOS + 280, CH_MENU_YPOS + CH_MENU_HEIGHT);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_ref_menu_item(PCHANNELSETTINGS settings, int mode)//set
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF1_1_COLOR); else display_set_fg_color(REF1_2_COLOR);
    display_set_fg_color(settings->color);
  }

  //Draw the background
  //display_fill_rounded_rect(159, 410, 226, 38, 3);//401 36
  
  display_fill_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 6, 60, 40, 3);
  
  //display_fill_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  //display_set_fg_color(GREY_COLOR);//GREY_COLOR
  display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 6, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(settings->color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(settings->menuxpos + 368, CH_MENU_YPOS + 10, "REF");   
  display_text(settings->menuxpos + 363, CH_MENU_YPOS + 25, "menu"); 
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_open_ref_menu(PCHANNELSETTINGS settings)
//void scope_channel_open_ref_menu(PCHANNELSETTINGS settings, PCHANNELSETTINGS REFsettings)
{
  uint32 xstart;
//  uint32 xend;
  
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 9;//6
  
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1
  //display_set_screen_buffer(displaybuffer2);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(settings->menuxpos + CH_REF_MENU_XPOS, CH_REF_MENU_YPOS, CH_REF_MENU_WIDTH, CH_REF_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(GREY_COLOR);
  
  //Set channel color
  //display_set_fg_color(settings->color);

  //Draw the edge
  display_draw_rect(settings->menuxpos + CH_REF_MENU_XPOS, CH_REF_MENU_YPOS, CH_REF_MENU_WIDTH, CH_REF_MENU_HEIGHT);
  
  //display_set_bg_color(DARKGREY_COLOR);
  //display_set_fg_color(YELLOW_COLOR);

  //display_copy_icon_use_colors(Right_drop_menu_icon, xstart, CH_REF_MENU_YPOS+186, 24, 24);
  //display_copy_icon_use_colors(Right_drop_menu_icon1, xstart, CH_REF_MENU_YPOS+216, 24, 24);
  //display_copy_icon_use_colors(Generator_menu_icon, xstart, CH_REF_MENU_YPOS+246, 24, 24);
  //display_copy_icon_use_colors(Generator_menu_icon1, xstart, CH_REF_MENU_YPOS+276, 24, 24);
  
    //**********************************************************
  
  //tu nakopirovat nastavenie z ref channel.enable do scopesettings.ref1 podla otvoreneho kanala 1alebo 2
  
 /*
   if(settings->color == CHANNEL1_COLOR)  
  {
    scopesettings.ref1 = scopesettings.ch1_ref1.enable;
    scopesettings.ref2 = scopesettings.ch1_ref2.enable;
    scopesettings.ref3 = scopesettings.ch1_ref3.enable;
    scopesettings.ref4 = scopesettings.ch1_ref4.enable;
  }
  else 
  {
    scopesettings.ref1 = scopesettings.ch2_ref1.enable;
    scopesettings.ref2 = scopesettings.ch2_ref2.enable;
    scopesettings.ref3 = scopesettings.ch2_ref3.enable;
    scopesettings.ref4 = scopesettings.ch2_ref4.enable;
  }
  */
  
  scope_channel_ref_select(settings);
  //scope_channel_ref_select(settings, REFsettings);
  
  scope_channel_COPYtoREF1_item(settings, 0);
  scope_channel_COPYtoREF2_item(settings, 0);
  scope_channel_COPYtoREF3_item(settings, 0);
  scope_channel_COPYtoREF4_item(settings, 0);
  scope_channel_CLEAR_REF_ALL_item(settings, 0);
  
  scope_channel_LOADtoREF1_item(settings, 0);
  scope_channel_LOADtoREF2_item(settings, 0);
  scope_channel_LOADtoREF3_item(settings, 0);
  scope_channel_LOADtoREF4_item(settings, 0);
  scope_channel_LOAD_REF_ALL_item(settings, 0);
  
  scope_channel_SAVE_REF1_item(settings, 0);
  scope_channel_SAVE_REF2_item(settings, 0);
  scope_channel_SAVE_REF3_item(settings, 0);
  scope_channel_SAVE_REF4_item(settings, 0);
  scope_channel_SAVE_REF_ALL_item(settings, 0);
  
  //**********************************************************
  
  //Set source and target for getting it on the actual screen 
  display_set_source_buffer(displaybuffertmp);//1
  //display_set_source_buffer(displaybuffer2);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(settings->menuxpos + CH_REF_MENU_XPOS, CH_REF_MENU_YPOS, CH_REF_MENU_WIDTH, CH_REF_MENU_HEIGHT, 61000);
    
}

void scope_channel_ref_select(PCHANNELSETTINGS settings)
//void scope_channel_ref_select(PCHANNELSETTINGS settings, PCHANNELSETTINGS REFsettings)
{  
//  PREFCHANNELSETTINGS REFsettings;
  uint32 xstart;
//  uint32 xend;
//  uint32 select;
  
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 6;
  //uint8 r=6;

 //-----------------------------------------------------------------------------
  
  if(((scopesettings.ref1)&&(settings->color == CHANNEL1_COLOR))||((scopesettings.ref5)&&(settings->color == CHANNEL2_COLOR))) //&scopesettings.channel2 if(scopesettings.triggerchannel == 0)
    { 
      //Set color based on channel color for the box behind the selected text
      if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref1.color); else display_set_fg_color(scopesettings.ch_ref5.color); 
      //display_set_fg_color(scopesettings.ch_ref1.color); 
      //display_set_fg_color(REF1_COLOR);
      
    
      //Draw the background in dark grey
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);   
      //Draw the edge in a lighter grey
      display_set_fg_color(LIGHTGREY_COLOR);
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
    }
    else      
    {
      display_set_fg_color(DARKGREY_COLOR);//GREY_COLOR
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
    }
  
    //Texts in white
    display_set_fg_color(WHITE_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_text(xstart+13, CH_REF_MENU_YPOS+18, "REF 1");
      else display_text(xstart+13, CH_REF_MENU_YPOS+18, "REF 5");
    
  if(((scopesettings.ref2)&&(settings->color == CHANNEL1_COLOR))||((scopesettings.ref6)&&(settings->color == CHANNEL2_COLOR)))//if(scopesettings.ch_ref2.enable)
    { 
      //Set color based on channel color for the box behind the selected text
      if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref2.color); else display_set_fg_color(scopesettings.ch_ref6.color); 
      //display_set_fg_color(scopesettings.ch_ref2.color); 
      //display_set_fg_color(REF2_COLOR);
      
      //Draw the background in dark grey
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);   
      //Draw the edge in a lighter grey
      display_set_fg_color(LIGHTGREY_COLOR);
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);
    }
    else      
    {
      display_set_fg_color(DARKGREY_COLOR);//GREY_COLOR
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);
    }
  
    //Texts in white
    display_set_fg_color(WHITE_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_text(xstart+13, CH_REF_MENU_YPOS+64, "REF 2");
      else display_text(xstart+13, CH_REF_MENU_YPOS+64, "REF 6");
    //display_text(xstart+13, CH_REF_MENU_YPOS+64, "REF 2");
    
  if(((scopesettings.ref3)&&(settings->color == CHANNEL1_COLOR))||((scopesettings.ref7)&&(settings->color == CHANNEL2_COLOR)))//if(scopesettings.ch_ref3.enable)
    { 
      //Set color based on channel color for the box behind the selected text
      //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF3_1_COLOR); else display_set_fg_color(REF3_2_COLOR); 
      if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref3.color); else display_set_fg_color(scopesettings.ch_ref7.color); 
      //display_set_fg_color(scopesettings.ch_ref3.color); 
      //display_set_fg_color(REF3_COLOR);
      
      //Draw the background in dark grey
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);   
      //Draw the edge in a lighter grey
      display_set_fg_color(LIGHTGREY_COLOR);
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);
    }
    else      
    {
      display_set_fg_color(DARKGREY_COLOR);//GREY_COLOR
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);
    }
  
    //Texts in white
    display_set_fg_color(WHITE_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_text(xstart+13, CH_REF_MENU_YPOS+110, "REF 3");
      else display_text(xstart+13, CH_REF_MENU_YPOS+110, "REF 7");
    //display_text(xstart+13, CH_REF_MENU_YPOS+110, "REF 3");
    
  if(((scopesettings.ref4)&&(settings->color == CHANNEL1_COLOR))||((scopesettings.ref8)&&(settings->color == CHANNEL2_COLOR)))//if(scopesettings.ch_ref4.enable)
    { 
      //Set color based on channel color for the box behind the selected text
      //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR); 
      if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref4.color); else display_set_fg_color(scopesettings.ch_ref8.color); 
      //display_set_fg_color(scopesettings.ch_ref4.color); 
      //display_set_fg_color(REF4_COLOR);
      
      //Draw the background in dark grey
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);   
      //Draw the edge in a lighter grey
      display_set_fg_color(LIGHTGREY_COLOR);
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);
    }
    else      
    {
      display_set_fg_color(DARKGREY_COLOR);//GREY_COLOR
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);
    }
  
    //Texts in white
    display_set_fg_color(WHITE_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_text(xstart+13, CH_REF_MENU_YPOS+156, "REF 4");
      else display_text(xstart+13, CH_REF_MENU_YPOS+156, "REF 8");
    //display_text(xstart+13, CH_REF_MENU_YPOS+156, "REF 4");
    
    if(((settings->color == CHANNEL1_COLOR)&&((scopesettings.ref1)||(scopesettings.ref2)||(scopesettings.ref3)||(scopesettings.ref4)))||
      ((settings->color == CHANNEL2_COLOR)&&((scopesettings.ref5)||(scopesettings.ref6)||(scopesettings.ref7)||(scopesettings.ref8))))
    { 
      display_set_fg_color(DARKGREY_COLOR);//GREY_COLOR
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);
      //Texts in white
      //display_set_fg_color(WHITE_COLOR);
    }
    else      
    {
      //Set red color for the box behind the selected text
      //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR); 
      display_set_fg_color(RED_COLOR);
      //Draw the background in red
      display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);   
      //Draw the edge in a lighter grey
      display_set_fg_color(LIGHTGREY_COLOR);
      display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);
      //Texts in black
      //display_set_fg_color(BLACK_COLOR);
    }
  
     
  //display_set_fg_color(BLACK_COLOR);
  //display_text(xstart + 18, CH_MATH_MENU_YPOS + 202, "OFF");
  
    //Texts in white
    display_set_fg_color(WHITE_COLOR);
    display_text(xstart+18, CH_REF_MENU_YPOS+194, "REF");//13 156
    display_text(xstart+21, CH_REF_MENU_YPOS+209, "Off");//13 156
    
    //-----------------------------------------------------------------------------
    
    
}//end

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_COPYtoREF1_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 74;//+6//6+68
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref1.color); else display_set_fg_color(scopesettings.ch_ref5.color);
    //display_set_fg_color(scopesettings.ch_ref1.color);
    //display_set_fg_color(REF1_COLOR);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
  //display_fill_rounded_rect(xstart+68, CH_REF_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  //display_set_fg_color(GREY_COLOR);
  display_set_fg_color(MAGENTA_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
  //display_draw_rounded_rect(xstart+68, CH_REF_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref1.color); else display_set_fg_color(scopesettings.ch_ref5.color);
    //display_set_fg_color(scopesettings.ch_ref1.color);
    //display_set_fg_color(REF1_COLOR);
  }
  
  //Display the text
  display_set_font(&font_3);
  if(settings->color == CHANNEL1_COLOR) { display_text(xstart + 10, CH_REF_MENU_YPOS + 10, "CH1 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 1");}
  else { display_text(xstart + 10, CH_REF_MENU_YPOS + 10, "CH2 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 5");}
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 10, "CH1 to");//+78
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 10, "CH2 to");
  //display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 1");//+81
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_COPYtoREF2_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 74;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF2_1_COLOR); else display_set_fg_color(REF2_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref2.color); 
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref2.color); else display_set_fg_color(scopesettings.ch_ref6.color);
    //display_set_fg_color(REF2_COLOR);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(MAGENTA_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF2_1_COLOR); else display_set_fg_color(REF2_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref2.color); 
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref2.color); else display_set_fg_color(scopesettings.ch_ref6.color);
    //display_set_fg_color(REF2_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  if(settings->color == CHANNEL1_COLOR) { display_text(xstart + 10, CH_REF_MENU_YPOS + 56, "CH1 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 2");}
  else { display_text(xstart + 10, CH_REF_MENU_YPOS + 56, "CH2 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 6");}
  
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 56, "CH1 to");
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 56, "CH2 to");
  //display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 2");//25
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_COPYtoREF3_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 74;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF3_1_COLOR); else display_set_fg_color(REF3_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref3.color); 
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref3.color); else display_set_fg_color(scopesettings.ch_ref7.color);
    //display_set_fg_color(REF3_COLOR);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(MAGENTA_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF3_1_COLOR); else display_set_fg_color(REF3_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref3.color); 
    //display_set_fg_color(REF3_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref3.color); else display_set_fg_color(scopesettings.ch_ref7.color);
  }
  
  //Display the text
  display_set_font(&font_3);
  if(settings->color == CHANNEL1_COLOR) { display_text(xstart + 10, CH_REF_MENU_YPOS + 102, "CH1 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 3");}
  else { display_text(xstart + 10, CH_REF_MENU_YPOS + 102, "CH2 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 7");}
  
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 102, "CH1 to");
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 102, "CH2 to");//56
  //display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 3");//25
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_COPYtoREF4_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 74;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref4.color); 
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref4.color); else display_set_fg_color(scopesettings.ch_ref8.color);
    //display_set_fg_color(REF4_COLOR);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(MAGENTA_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref4.color);
    //display_set_fg_color(REF4_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref4.color); else display_set_fg_color(scopesettings.ch_ref8.color);
  }

  //Display the text
  display_set_font(&font_3);
  if(settings->color == CHANNEL1_COLOR) { display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH1 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 4");}
  else { display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH2 to"); display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 8");}
  
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH1 to");
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH2 to");
  //display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 4");//25
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_CLEAR_REF_ALL_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 74;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    display_set_fg_color(ITEM_ACTIVE_COLOR);
    
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);
  
  //Draw the edge in a grey
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    display_set_fg_color(MAGENTA_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH1 to");
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH2 to");
  display_text(xstart + 13, CH_REF_MENU_YPOS + 194, "Clear");//+78
  display_text(xstart + 20, CH_REF_MENU_YPOS + 209, "ALL");//25
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_LOADtoREF1_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 142;//6+68+68
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF1_1_COLOR); else display_set_fg_color(REF1_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref1.color); 
    //display_set_fg_color(REF1_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref1.color); else display_set_fg_color(scopesettings.ch_ref5.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
  //display_fill_rounded_rect(xstart+68, CH_REF_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  //display_set_fg_color(GREY_COLOR);
  display_set_fg_color(GREEN_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
  //display_draw_rounded_rect(xstart+68, CH_REF_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref1.color); else display_set_fg_color(scopesettings.ch_ref5.color);
    //display_set_fg_color(scopesettings.ch_ref1.color); 
    //display_set_fg_color(REF1_COLOR);
  }
  
  //Display the text
  display_set_font(&font_3);
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 78, CH_REF_MENU_YPOS + 10, "CH1 to");//+78
  //else 
  display_text(xstart + 15, CH_REF_MENU_YPOS + 10, "Load");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 1"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 5");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_LOADtoREF2_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 142;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF2_1_COLOR); else display_set_fg_color(REF2_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref2.color);
    //display_set_fg_color(REF2_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref2.color); else display_set_fg_color(scopesettings.ch_ref6.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(GREEN_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF2_1_COLOR); else display_set_fg_color(REF2_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref2.color);
    //display_set_fg_color(REF2_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref2.color); else display_set_fg_color(scopesettings.ch_ref6.color);
  }
  
  //Display the text
  display_set_font(&font_3);
  display_text(xstart + 15, CH_REF_MENU_YPOS + 56, "Load");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 2"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 6");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_LOADtoREF3_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 142;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF3_1_COLOR); else display_set_fg_color(REF3_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref3.color);
    //display_set_fg_color(REF3_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref3.color); else display_set_fg_color(scopesettings.ch_ref7.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(GREEN_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF3_1_COLOR); else display_set_fg_color(REF3_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref3.color); 
    //display_set_fg_color(REF3_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref3.color); else display_set_fg_color(scopesettings.ch_ref7.color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xstart + 15, CH_REF_MENU_YPOS + 102,  "Load");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 3"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 7");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_LOADtoREF4_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 142;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref4.color); 
    //display_set_fg_color(REF4_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref4.color); else display_set_fg_color(scopesettings.ch_ref8.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(GREEN_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref4.color); 
    //display_set_fg_color(REF4_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref4.color); else display_set_fg_color(scopesettings.ch_ref8.color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xstart + 15, CH_REF_MENU_YPOS + 148,  "Load");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 4"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 8");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_LOAD_REF_ALL_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 142;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    display_set_fg_color(ITEM_ACTIVE_COLOR);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);
  
  //Draw the edge in a grey
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    display_set_fg_color(GREEN_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH1 to");
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH2 to");
  display_text(xstart + 15, CH_REF_MENU_YPOS + 194, "Load");//+78
  display_text(xstart + 20, CH_REF_MENU_YPOS + 209, "ALL");//25
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_SAVE_REF1_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 210;//6+68+68+68
  
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF1_1_COLOR); else display_set_fg_color(REF1_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref1.color); 
    //display_set_fg_color(REF1_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref1.color); else display_set_fg_color(scopesettings.ch_ref5.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
  //display_fill_rounded_rect(xstart+68, CH_REF_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  //display_set_fg_color(GREY_COLOR);
  display_set_fg_color(RED_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 6, 60, 40, 3);
  //display_draw_rounded_rect(xstart+68, CH_REF_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }

  //Display the text
  display_set_font(&font_3);
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 78, CH_REF_MENU_YPOS + 10, "CH1 to");//+78
  //else 
  display_text(xstart + 15, CH_REF_MENU_YPOS + 10, "Save");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 1"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 25, "REF 5");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_SAVE_REF2_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 210;
  
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF2_1_COLOR); else display_set_fg_color(REF2_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref2.color); 
    //display_set_fg_color(REF2_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref2.color); else display_set_fg_color(scopesettings.ch_ref6.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(RED_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xstart + 15, CH_REF_MENU_YPOS + 56, "Save");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 2"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 71, "REF 6");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_SAVE_REF3_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 210;
  
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF3_1_COLOR); else display_set_fg_color(REF3_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref3.color); 
    //display_set_fg_color(REF3_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref3.color); else display_set_fg_color(scopesettings.ch_ref7.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(RED_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 98, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xstart + 15, CH_REF_MENU_YPOS + 102,  "Save");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 3"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 117, "REF 7");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_SAVE_REF4_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 210;
  
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    //display_set_fg_color(scopesettings.ch_ref4.color); 
    //display_set_fg_color(REF4_COLOR);
    if(settings->color == CHANNEL1_COLOR) display_set_fg_color(scopesettings.ch_ref4.color); else display_set_fg_color(scopesettings.ch_ref8.color);
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(RED_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 144, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xstart + 15, CH_REF_MENU_YPOS + 148,  "Save");//+78
  if(settings->color == CHANNEL1_COLOR) display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 4"); else display_text(xstart + 13, CH_REF_MENU_YPOS + 163, "REF 8");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_SAVE_REF_ALL_item(PCHANNELSETTINGS settings, int mode)//set
{
  uint32 xstart;
  xstart = settings->menuxpos + CH_REF_MENU_XPOS + 210;
  
  //Check if inactive or active
  if((mode == 0)||(mode == 2))
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active - Set color based on channel color for the box behind the selected text
    //if(settings->color == CHANNEL1_COLOR) display_set_fg_color(REF4_1_COLOR); else display_set_fg_color(REF4_2_COLOR);
    display_set_fg_color(ITEM_ACTIVE_COLOR);
    
  }

  //Draw the background
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);
  
  //Draw the edge in a grey
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(xstart, CH_REF_MENU_YPOS + 190, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    //display_set_bg_color(DARKGREY_COLOR);
  }
  else if(mode == 1)
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    //display_set_bg_color(settings->color);
  }
  else if(mode == 2)
  {
    display_set_fg_color(RED_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  //if(settings->color == CHANNEL1_COLOR) display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH1 to");
  //else display_text(xstart + 10, CH_REF_MENU_YPOS + 148, "CH2 to");
  display_text(xstart + 15, CH_REF_MENU_YPOS + 194, "Save");//+78
  display_text(xstart + 20, CH_REF_MENU_YPOS + 209, "ALL");//25
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_math_menu_item(PCHANNELSETTINGS settings, int mode)//set
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so magenta background
    display_set_fg_color(MAGENTA_COLOR);
    //display_set_fg_color(settings->color);
  }

  //Draw the background
  display_fill_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  //display_set_fg_color(GREY_COLOR);//GREY_COLOR
  display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(settings->color);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(settings->menuxpos + 362, CH_MENU_YPOS + 56, "MATH");   
  display_text(settings->menuxpos + 362, CH_MENU_YPOS + 71, "menu");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_channel_open_math_menu(PCHANNELSETTINGS settings)
{
  //uint32 xstart;
  //uint32 xend;
  //uint32 select;
  
  //xstart = settings->menuxpos + CH_MATH_MENU_XPOS + 6;
  
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1
  //display_set_screen_buffer(displaybuffer2);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(settings->menuxpos + CH_MATH_MENU_XPOS, CH_MATH_MENU_YPOS, CH_MATH_MENU_WIDTH, CH_MATH_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  
  //Set channel color
  //display_set_fg_color(settings->color);

  //Draw the edge
  display_draw_rect(settings->menuxpos + CH_MATH_MENU_XPOS, CH_MATH_MENU_YPOS, CH_MATH_MENU_WIDTH, CH_MATH_MENU_HEIGHT);
  
  //**********************************************************
  
  scope_channel_math_select(settings);
  
  //**********************************************************
     
  //Set source and target for getting it on the actual screen 
  display_set_source_buffer(displaybuffertmp);//1
  //display_set_source_buffer(displaybuffer2);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(settings->menuxpos + CH_MATH_MENU_XPOS, CH_MATH_MENU_YPOS, CH_MATH_MENU_WIDTH, CH_MATH_MENU_HEIGHT, 61000);
    
}


void scope_channel_math_select(PCHANNELSETTINGS settings)
{  
  uint32 xstart;
//  uint32 xend;
  uint32 select;
  
  xstart = settings->menuxpos + CH_MATH_MENU_XPOS + 6;
  
  //Draw the background in dark grey
  //display_set_fg_color(DARKGREY_COLOR);
  
  for(uint8 r=6; r<CH_MATH_MENU_HEIGHT; r+=46)
  {
    //Draw the background in dark grey
    display_set_fg_color(DARKGREY_COLOR);
    display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + r, 60, 40, 3);
    
    
    //Draw the edge in a lighter grey
    display_set_fg_color(LIGHTGREY_COLOR);
    display_draw_rounded_rect(xstart, CH_MATH_MENU_YPOS + r, 60, 40, 3);    
  }
  
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(xstart+68, CH_MATH_MENU_YPOS + 6, 91, 40, 3);
  display_fill_rounded_rect(xstart+68, CH_MATH_MENU_YPOS + 52, 91, 40, 3);
  
  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(xstart+68, CH_MATH_MENU_YPOS + 6, 91, 40, 3);
  display_draw_rounded_rect(xstart+68, CH_MATH_MENU_YPOS + 52, 91, 40, 3);
  
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
 
  display_text(xstart + 14, CH_MATH_MENU_YPOS + 18,  "A + B"); //6+8
  display_text(xstart + 15, CH_MATH_MENU_YPOS + 64,  "A - B"); 
  display_text(xstart + 14, CH_MATH_MENU_YPOS + 110, "A * B"); 
  display_text(xstart + 14, CH_MATH_MENU_YPOS + 156, "A / B"); 
  
  //display_set_fg_color(BLACK_COLOR);
  display_text(xstart + 18, CH_MATH_MENU_YPOS + 202, "OFF");
  
  display_set_fg_color(WHITE_COLOR);
    
  switch (channelA)
  {
    case 0: display_set_fg_color(CHANNEL1_COLOR); display_text(xstart + 89, CH_MATH_MENU_YPOS + 18, "CH1=>A"); break;
    case 1: display_set_fg_color(CHANNEL2_COLOR); display_text(xstart + 89, CH_MATH_MENU_YPOS + 18, "CH2=>A"); break;
    case 2: display_set_fg_color(REF1_COLOR);   display_text(xstart + 84, CH_MATH_MENU_YPOS + 18, "REF1=>A"); break;
    case 3: display_set_fg_color(REF2_COLOR);   display_text(xstart + 84, CH_MATH_MENU_YPOS + 18, "REF2=>A"); break;
    //case 2: display_set_fg_color(REF1_COLOR);   display_text(xstart + 74, CH_MATH_MENU_YPOS + 18, "REF CH1=>A"); break;
    //case 3: display_set_fg_color(REF2_COLOR);   display_text(xstart + 74, CH_MATH_MENU_YPOS + 18, "REF CH2=>A"); break;
    //case 4: display_set_fg_color(MATH_COLOR);     display_text(xstart + 82, CH_MATH_MENU_YPOS + 18, "MATH=>A"); break;      
  }
  
  display_set_fg_color(WHITE_COLOR);
  
  switch (channelB)
  {
    case 0: display_set_fg_color(CHANNEL1_COLOR); display_text(xstart + 89, CH_MATH_MENU_YPOS + 64, "CH1=>B"); break;
    case 1: display_set_fg_color(CHANNEL2_COLOR); display_text(xstart + 89, CH_MATH_MENU_YPOS + 64, "CH2=>B"); break;
    case 2: display_set_fg_color(REF1_COLOR);   display_text(xstart + 84, CH_MATH_MENU_YPOS + 64, "REF1=>B"); break;
    case 3: display_set_fg_color(REF2_COLOR);   display_text(xstart + 84, CH_MATH_MENU_YPOS + 64, "REF2=>B"); break;
    //case 2: display_set_fg_color(REF1_COLOR);   display_text(xstart + 74, CH_MATH_MENU_YPOS + 64, "REF CH1=>B"); break;
    //case 3: display_set_fg_color(REF2_COLOR);   display_text(xstart + 74, CH_MATH_MENU_YPOS + 64, "REF CH2=>B"); break;
    //case 4: display_set_fg_color(MATH_COLOR);     display_text(xstart + 82, CH_MATH_MENU_YPOS + 64, "MATH=>B"); break;      
  }


  
  //Draw the background
  display_set_fg_color(GREEN_COLOR);
   
  
  switch (mathmode) //fill color select mode
  {
    case 1: select = 6;   display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + select, 60, 40, 3); display_set_fg_color(BLACK_COLOR);display_text(xstart+14, CH_MATH_MENU_YPOS + 18,  "A + B");  break;//6+8 break;
    case 2: select = 52;  display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + select, 60, 40, 3); display_set_fg_color(BLACK_COLOR);display_text(xstart+15, CH_MATH_MENU_YPOS + 64,  "A - B"); break;
    case 3: select = 98;  display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + select, 60, 40, 3); display_set_fg_color(BLACK_COLOR);display_text(xstart+14, CH_MATH_MENU_YPOS + 110, "A * B"); break;
    case 4: select = 144; display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + select, 60, 40, 3); display_set_fg_color(BLACK_COLOR);display_text(xstart+14, CH_MATH_MENU_YPOS + 156, "A / B");break;
      
    default: select = 190; display_set_fg_color(RED_COLOR);  display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + select, 60, 40, 3); display_set_fg_color(BLACK_COLOR); display_text(xstart + 18, CH_MATH_MENU_YPOS + 202, "OFF"); break;
  }
        
  //display_fill_rounded_rect(xstart, CH_MATH_MENU_YPOS + select, 60, 40, 3);
  //display_fill_rounded_rect(settings->menuxpos + CH_MATH_MENU_XPOS + 6, CH_MATH_MENU_YPOS + 6, 60, 40, 3);
  
  //display_fill_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  
  /*
  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  //display_set_fg_color(GREY_COLOR);//GREY_COLOR
  display_draw_rounded_rect(xstart, CH_MATH_MENU_YPOS + 6, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  
  display_draw_rounded_rect(xstart, CH_MATH_MENU_YPOS + 52, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
    
  display_draw_rounded_rect(xstart, CH_MATH_MENU_YPOS + 98, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  
  display_draw_rounded_rect(xstart, CH_MATH_MENU_YPOS + 144, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  
  display_draw_rounded_rect(xstart, CH_MATH_MENU_YPOS + 190, 60, 40, 3);
  //display_draw_rounded_rect(settings->menuxpos + 350, CH_MENU_YPOS + 52, 60, 40, 3);
  */
  

  //display_text(xstart, CH_MENU_YPOS + 71, "menu");
  
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_keyboard_menu(void)
{
  //extern char numbuf[12];
  //menuxpos = menuxpos + KEY_MENU_XPOS;
  
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(KEY_MENU_XPOS, KEY_MENU_YPOS, KEY_MENU_WIDTH, KEY_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(KEY_MENU_XPOS, KEY_MENU_YPOS, KEY_MENU_WIDTH, KEY_MENU_HEIGHT);

  //Draw the edge
  display_draw_rect(KEY_MENU_XPOS+5, KEY_MENU_YPOS+30, KEY_MENU_WIDTH-10, 31);
  
  //Main texts in white
  display_set_fg_color(WHITE_COLOR);
  
  //Select the font for the texts
  display_set_font(&font_3);//3

  if(holdoffmenuopen)     display_text(KEY_MENU_XPOS + 20, KEY_MENU_YPOS + 7, "TRIGGER                   Set hold off time");//117
  else if(freqmenuopen)   display_text(KEY_MENU_XPOS + 20, KEY_MENU_YPOS + 7, "GENERATOR                 Set frequency");//117
  else if(dutymenuopen)   display_text(KEY_MENU_XPOS + 20, KEY_MENU_YPOS + 7, "GENERATOR                 Set duty");//117
  else if(amplmenuopen)   display_text(KEY_MENU_XPOS + 20, KEY_MENU_YPOS + 7, "GENERATOR                 Set amplitude");//117
  else if(offsetmenuopen) display_text(KEY_MENU_XPOS + 20, KEY_MENU_YPOS + 7, "GENERATOR                 Set offset");//117
  else if(phasemenuopen)  display_text(KEY_MENU_XPOS + 20, KEY_MENU_YPOS + 7, "GENERATOR                 Set phase");//117
  
  //display_text(KEY_MENU_XPOS +  97, KEY_MENU_YPOS + 216, "Time per Division");//166
  
  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(LIGHTGREY_COLOR);
  
  //Clear the boxes for the not selected items 
  display_fill_rect(KEY_MENU_XPOS +   5, KEY_MENU_YPOS + 284, 90, 50);  //MIN
  display_fill_rect(KEY_MENU_XPOS + 101, KEY_MENU_YPOS + 284, 95, 50);
  display_fill_rect(KEY_MENU_XPOS + 202, KEY_MENU_YPOS + 284, 90, 50);
  
  display_fill_rect(KEY_MENU_XPOS +   5, KEY_MENU_YPOS + 338, 90, 50);
  display_fill_rect(KEY_MENU_XPOS + 101, KEY_MENU_YPOS + 338, 95, 50);
  display_fill_rect(KEY_MENU_XPOS + 202, KEY_MENU_YPOS + 338, 90, 50);
  
  //Select the font for the texts
  display_set_font(&font_3);
  
  //Set color for the text
  display_set_fg_color(BLUE_COLOR);
  display_text(KEY_MENU_XPOS + 38,  KEY_MENU_YPOS +  310, "MIN"); //38-300
  //Set color for the text
  display_set_fg_color(DARKGREEN_COLOR);
  display_text(KEY_MENU_XPOS + 126, KEY_MENU_YPOS +  310, "Default"); //126
  //Set color for the text
  display_set_fg_color(RED_COLOR);
  display_text(KEY_MENU_XPOS + 233, KEY_MENU_YPOS +  310, "MAX"); //233
  
  //Select the font for the texts
  display_set_font(&font_2);
  //Set color for the text
  display_set_fg_color(WHITE_COLOR);
  
  if(freqmenuopen)
  {
    display_text(KEY_MENU_XPOS + 38,  KEY_MENU_YPOS +  293, "1 Hz"); //38-300
    display_text(KEY_MENU_XPOS + 135, KEY_MENU_YPOS +  293, "1 kHz"); //126
    display_text(KEY_MENU_XPOS + 230, KEY_MENU_YPOS +  293, "5 Mhz"); //233
  }
  
  //v1.00x5: hold-off presets
  else if(holdoffmenuopen)
  {
    //display_text(KEY_MENU_XPOS + 33,  KEY_MENU_YPOS +  293, "100 ns");
    //display_text(KEY_MENU_XPOS + 137, KEY_MENU_YPOS +  293, "1 ms");
    //display_text(KEY_MENU_XPOS + 240, KEY_MENU_YPOS +  293, "1 s");
    //v1.00x6: the real limits of the FPGA hold-off
    display_text(KEY_MENU_XPOS + 40,  KEY_MENU_YPOS +  293, "5 ns");
    display_text(KEY_MENU_XPOS + 137, KEY_MENU_YPOS +  293, "1 ms");
    //display_text(KEY_MENU_XPOS + 224, KEY_MENU_YPOS +  293, "21,47 s");
    display_text(KEY_MENU_XPOS + 235, KEY_MENU_YPOS +  293, "21 s");     //v1.00x8
  }

  else if(dutymenuopen)
  {
    display_text(KEY_MENU_XPOS + 40,  KEY_MENU_YPOS +  293, "0 %"); //38-300
    display_text(KEY_MENU_XPOS + 137, KEY_MENU_YPOS +  293, "50 %"); //135
    display_text(KEY_MENU_XPOS + 230, KEY_MENU_YPOS +  293, "100 %"); //230
  }
  
  
  //Select the font for the texts
  display_set_font(&font_3);
  
  //Set color for the text
  display_set_fg_color(YELLOW_COLOR);
  display_text(KEY_MENU_XPOS + 34,  KEY_MENU_YPOS +  354, "Back");
  //Set color for the text
  display_set_fg_color(WHITE_COLOR);
  display_text(KEY_MENU_XPOS + 131, KEY_MENU_YPOS +  354, "Clear");
  //Set color for the text
  display_set_fg_color(GREEN_COLOR);
  display_text(KEY_MENU_XPOS + 238, KEY_MENU_YPOS +  354, "OK");


  
  //display_set_fg_color(WHITE_COLOR);
  //***************************************************************
    //Select the font for the texts
  display_set_font(&font_5);//3
    
  //Set color for the text
  display_set_fg_color(GREY_COLOR);
  //display_set_fg_color(YELLOW_COLOR);
  
  uint8 number_len = 0;
  extern char numbuffer[NUMBUF_MAX];
  extern uint8 numbuffer_len;

  
  if (numbuffer_len>0) number_len = numbuffer_len - 1; else number_len = 0;              
  display_text(KEY_MENU_XPOS + 269-(number_len*12), KEY_MENU_YPOS + 34, numbuffer); //200
  //buffer_clear(); 
  

  //Display the actual settings
  scope_keyboard_select();
 
  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  //display_slide_top_rect_onto_screen(KEY_MENU_XPOS, KEY_MENU_YPOS, KEY_MENU_WIDTH, KEY_MENU_HEIGHT, 61000);
  display_slide_right_rect_onto_screen(KEY_MENU_XPOS, KEY_MENU_YPOS, KEY_MENU_WIDTH, KEY_MENU_HEIGHT, 61000);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_keyboard_select(void)
{
  uint32 i,x = 0,y;

  //Select the font for the texts
  display_set_font(&font_5);

  //Clear the boxes for the not selected items
  for(i=0;i<((sizeof(keyboard_texts) / sizeof(int8 *)));i++)
  {
    if(((i%5) == 0)) x = 5; else x += 58;
    y=((i / 5) * 53); 
    
    //Set dark grey color for the boxes behind the not selected texts
    display_set_fg_color(MIDLEGREY_COLOR);
  
    display_fill_rect(KEY_MENU_XPOS + x, KEY_MENU_YPOS + y + 68, 55, 50);//35
    
    //Selected texts in white
    if(((i == 13)||(i == 14)||(i > 15))&&(genmenuopen==1)) display_set_fg_color(GREY_COLOR); else display_set_fg_color(WHITE_COLOR);

    //v1.00x6: hold-off: the 4th column is the unit ns / us / ms / s (the chosen one green), the 5th column and +/- do
    //nothing there (grey)
    if(holdoffmenuopen)
    {
      static const char *units[4] = { "ns", "us", "ms", "s" };
      static const uint8 unit_of_row[4] = { HOLDOFF_UNIT_NS, HOLDOFF_UNIT_US, HOLDOFF_UNIT_MS, HOLDOFF_UNIT_S };

      if((i % 5) == 3)
      {
        display_set_fg_color((unit_of_row[i / 5] == holdoff_unit) ? GREEN_COLOR : WHITE_COLOR);
        display_text(KEY_MENU_XPOS + x + ((55 - mm_text_width(units[i / 5])) / 2), KEY_MENU_YPOS + 82 + y, (int8 *)units[i / 5]);
        continue;
      }

      if(((i % 5) == 4) || (i == 17))
        display_set_fg_color(GREY_COLOR);
    }

    //o = x + keyboard_texts_x_offsets[i];
    //Display the text from the table
    display_text(KEY_MENU_XPOS + x + keyboard_texts_x_offsets[i], KEY_MENU_YPOS + 82 + y, (int8 *)keyboard_texts[i]);//49
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_acquisition_menu(void)
{
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(ACQ_MENU_XPOS, ACQ_MENU_YPOS, ACQ_MENU_WIDTH, ACQ_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(ACQ_MENU_XPOS, ACQ_MENU_YPOS, ACQ_MENU_WIDTH, ACQ_MENU_HEIGHT);

  //A two black line between the settings
  display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(ACQ_MENU_YPOS +  155, ACQ_MENU_XPOS + 8, ACQ_MENU_XPOS + 296);   //v1.00v8: fixed, the menu got wider
  
  //display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(ACQ_MENU_YPOS +  211, ACQ_MENU_XPOS + 8, ACQ_MENU_XPOS + ACQ_MENU_WIDTH - 8);//-84
  
  display_draw_vert_line(ACQ_MENU_XPOS +  304, ACQ_MENU_YPOS + 8, ACQ_MENU_YPOS + ACQ_MENU_HEIGHT - 8);

  //v1.00v8: the new column (more trace modes below, the upper part free for later settings)
  display_draw_vert_line(ACQ_MENU_XPOS + ACQ_MENU_COL3_X, ACQ_MENU_YPOS + 8, ACQ_MENU_YPOS + ACQ_MENU_HEIGHT - 8);

  //v1.00x2: 4th column (Persist above, Line below)
  display_draw_vert_line(ACQ_MENU_XPOS + ACQ_MENU_COL4_X, ACQ_MENU_YPOS + 8, ACQ_MENU_YPOS + ACQ_MENU_HEIGHT - 8);

  //Main texts in white
  display_set_fg_color(WHITE_COLOR);

  //Select the font for the texts
  display_set_font(&font_3);
  
  extern uint32 a,b,c,d,e,f;

  //Display the texts
  display_text(ACQ_MENU_XPOS + 111, ACQ_MENU_YPOS +   8, "Sample Rate");
  display_text(ACQ_MENU_XPOS +  97, ACQ_MENU_YPOS + 216, "Time per Division");//166
  
  display_text(ACQ_MENU_XPOS + 317, ACQ_MENU_YPOS +   8, "Memory"); //tab +6   
  //display_text(ACQ_MENU_XPOS + 324, ACQ_MENU_YPOS +   20, "deep"); //tab +6 

  display_text(ACQ_MENU_XPOS + 325, ACQ_MENU_YPOS +   216, "Trace"); //tab +6 //323   
  display_text(ACQ_MENU_XPOS + ACQ_MENU_COL3_X + ((76 - mm_text_width("More")) / 2), ACQ_MENU_YPOS + 216, "More");   //v1.00v8

  //v1.00x2: titles of the new columns
  display_text(ACQ_MENU_XPOS + ACQ_MENU_COL3_X + ((ACQ_MENU_COL_W - mm_text_width("Average")) / 2), ACQ_MENU_YPOS +   8, "Average");
  display_text(ACQ_MENU_XPOS + ACQ_MENU_COL4_X + ((ACQ_MENU_COL_W - mm_text_width("Persist")) / 2), ACQ_MENU_YPOS +   8, "Persist");
  display_text(ACQ_MENU_XPOS + ACQ_MENU_COL4_X + ((ACQ_MENU_COL_W - mm_text_width("Line")) / 2),    ACQ_MENU_YPOS + 216, "Line");

    //**********************************************************

  //v1.00x2: the ACQ button reads "ACQ Roll" (as MCP), the middle one is Clear (old texts below under #if 0)
  scope_acquisition_acq_button();
  scope_acquisition_clear_button(0);

#if 0
  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(LIGHTGREY_COLOR);

  //Clear the boxes for the not selected items (ACQ, Average, Long memory)
  display_fill_rounded_rect(ACQ_MENU_XPOS +   8, ACQ_MENU_YPOS + 163, 90, 40, 3);
  //display_fill_rect(ACQ_MENU_XPOS + 106, ACQ_MENU_YPOS + 163, 90, 40);
  //display_fill_rect(ACQ_MENU_XPOS + 204, ACQ_MENU_YPOS + 163, 90, 40);


  //Select the font for the texts
  display_set_font(&font_2);

  //Display Long/Short Mode text
  if (!scopesettings.long_mode)
  { //Set orange color for the text
    display_set_fg_color(ORANGE_COLOR);
    display_text(ACQ_MENU_XPOS + 43, ACQ_MENU_YPOS +  168, "ACQ");
    display_text(ACQ_MENU_XPOS + 24, ACQ_MENU_YPOS +  182, "Long mode");
  }
  else 
  { //Set green color for the text
    display_set_fg_color(GREEN_COLOR);
    display_text(ACQ_MENU_XPOS + 43, ACQ_MENU_YPOS +  168, "ACQ");
    display_text(ACQ_MENU_XPOS + 20, ACQ_MENU_YPOS +  182, "Short mode");
  }
#endif
  /*
  if (scopesettings.long_memory)
  //Set black color for the text
  display_set_fg_color(BLACK_COLOR); else display_set_fg_color(WHITE_COLOR);
  display_text(ACQ_MENU_XPOS + 235, ACQ_MENU_YPOS +  168, "Long");
  display_text(ACQ_MENU_XPOS + 225, ACQ_MENU_YPOS +  182, "memory");
   */
  
  //display_set_fg_color(WHITE_COLOR);
  //***************************************************************

  //Display the actual settings
  scope_acquisition_speed_select();
  scope_acquisition_timeperdiv_select();
  //scope_acquisition_ACQ_mode_select();
  scope_acquisition_Average_mode_select();
  //scope_acquisition_Long_memory_select();
  scope_acquisition_persist_select();      //v1.00x1: Persist in the place of the unused Long memory button

  scope_acquisition_memory_deep_select();
  scope_acquisition_trace_select();
  scope_acquisition_more_select();       //v1.00w5

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_top_rect_onto_screen(ACQ_MENU_XPOS, ACQ_MENU_YPOS, ACQ_MENU_WIDTH, ACQ_MENU_HEIGHT, 69906);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_acquisition_speed_select(void)
{
  uint32 i,x,y;

  //Select the font for the texts
  display_set_font(&font_2);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(MIDLEGREY_COLOR);

  //Clear the boxes for the not selected items
  for(i=0;i<((sizeof(acquisition_speed_texts) / sizeof(int8 *))-11);i++)//11 //9
  {
    if(i != scopesettings.samplerate)
    {
      x = ((i & 3) * 72) + 10;
      y = ((i >> 2) * 23) + 33;

      display_fill_rounded_rect(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, 68, 20, 2);
    }
  }

  //Set green color for the box behind the selected text
  display_set_fg_color(GREEN_COLOR);

  //Get the position of the selected item
  x = ((scopesettings.samplerate & 3) * 72) + 10;
  y = ((scopesettings.samplerate >> 2) * 23) + 33;

  //Highlight the selected item if short time mode
  if(scopesettings.timeperdiv>8) display_fill_rounded_rect(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, 68, 20, 2);

  for(i=0;i<((sizeof(acquisition_speed_texts) / sizeof(int8 *))-11);i++)
  {
    if(i != scopesettings.samplerate)
    {
      //Check if in stop mode
      if(((scopesettings.runstate)&&(!scopesettings.long_mode))||(scopesettings.triggermode == 1))
      {
        //When running available not selected texts shown in white
        display_set_fg_color(WHITE_COLOR);
        
      }
      else
      {
        //When stopped select option is disabled so texts shown in light grey
        display_set_fg_color(LIGHTGREY1_COLOR);     //
      }
    }
    else
    {
      //Selected texts in black
      display_set_fg_color(BLACK_COLOR);
    }

    //Calculate the position of this text
    x = ((i & 3) * 72) + acquisition_speed_text_x_offsets[i];
    y = ((i >> 2) * 23) + 36;

    //Display the text from the table
    display_text(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, (int8 *)acquisition_speed_texts[i]);
  }

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_acquisition_timeperdiv_select(void)
{
  uint32 c,i,x,y;
  #define ymp   241 //191   //position y for timeperdiv text and item

  //Select the font for the texts
  display_set_font(&font_2);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(MIDLEGREY_COLOR);

  //Clear the boxes for the not selected items
  for(i=0;i<((sizeof(time_div_texts) / sizeof(int8 *))-11);i++)
  {
    //Settings displayed from smallest to highest value
    c = ((sizeof(time_div_texts) / sizeof(int8 *)) - 1) - i;

    if(c != scopesettings.timeperdiv)
    {
      x = ((i & 3) * 72) + 10;
      y = ((i >> 2) * 23) + ymp;//191

      display_fill_rounded_rect(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, 68, 20, 2);
    }
  }

  //Set green color for the box behind the selected text
  display_set_fg_color(GREEN_COLOR);

  //Get the position of the selected item
  c = ((sizeof(time_div_texts) / sizeof(int8 *)) - 1) - scopesettings.timeperdiv;
  x = ((c & 3) * 72) + 10;
  y = ((c >> 2) * 23) + ymp;//191

  //Highlight the selected item if short time mode
  if(scopesettings.timeperdiv>8) display_fill_rounded_rect(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, 68, 20, 2);

  for(i=0;i<((sizeof(time_div_texts) / sizeof(int8 *))-11);i++)
  {
    //Settings displayed from smallest to highest value
      c = ((sizeof(time_div_texts) / sizeof(int8 *)) -1) - i;

    //Check if the current text is the selected on
    if(c != scopesettings.timeperdiv)
    {
      //When not check if the current on is a viable candidate for full screen trace display
      if(viable_time_per_div[scopesettings.samplerate][c])
      {
        //Available but viable not selected texts in white
        display_set_fg_color(WHITE_COLOR);
      }
      else
      {
        //Not viable but available not selected texts in grey
        display_set_fg_color(0x00686868);
      }
    }
    else
    {
      //Selected texts in black
      display_set_fg_color(BLACK_COLOR);
    }

    //Calculate the position of this text
    x = ((i & 3) * 72) + time_div_text_x_offsets[c];
    y = ((i >> 2) * 23) + ymp + 3;//194

    //Display the text from the table
    display_text(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, (int8 *)time_div_texts[c]);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_acquisition_ACQ_mode_select(void)
{
    //Set dark grey color for the boxes behind the not selected texts
    display_set_fg_color(LIGHTGREY_COLOR);
  
    //Clear the boxes for the not selected items (ACQ)
    display_fill_rounded_rect(ACQ_MENU_XPOS +   8, ACQ_MENU_YPOS + 163, 90, 40, 3);
                
    //Display Long/Short Mode text
    if (scopesettings.long_mode)
        {
        scopesettings.timeperdiv = 20;
        scopesettings.display_data_done = 1;
        //Send the time base command for the sort time base
        fpga_set_time_base(scopesettings.timeperdiv);
        //Set green color for the text
        //display_set_fg_color(ORANGE_COLOR);
        //display_text(ACQ_MENU_XPOS + 43, ACQ_MENU_YPOS +  168, "ACQ");
        //display_text(ACQ_MENU_XPOS + 24, ACQ_MENU_YPOS +  182, "Long mode");
        scopesettings.long_mode = 0;
        }
        else
        {
        scopesettings.timeperdiv = 8;
        //Send the time base command for the long time base
        fpga_set_long_timebase(scopesettings.timeperdiv);
        //display_set_fg_color(GREEN_COLOR);
        //display_text(ACQ_MENU_XPOS + 43, ACQ_MENU_YPOS +  168, "ACQ");
        //display_text(ACQ_MENU_XPOS + 20, ACQ_MENU_YPOS +  182, "Short mode");
        scopesettings.long_mode = 1;
        }

    //v1.00x2: "ACQ Roll", green when the roll (long time base) mode is on
    scope_acquisition_acq_button();
          
    //if((scopesettings.runstate))
    //{
        //Set the sample rate that belongs to the selected time per div setting
        scopesettings.samplerate = time_per_div_sample_rate[scopesettings.timeperdiv];  

        //Set the new setting in the FPGA
        fpga_set_sample_rate(scopesettings.samplerate);
    //}
     
    //scope_open_acquisition_menu();
    //Update the top menu bar display
    scope_acqusition_settings(0);
                
    //Display the actual settings
    scope_acquisition_speed_select();
    scope_acquisition_timeperdiv_select();
    scope_acquisition_Average_mode_select();
    //scope_acquisition_Long_memory_select();
    
    //scope_acquisition_memory_deep_select();
    //v1.00z4: the Memory column shows the roll's own length in roll, the normal one outside
    scope_acquisition_memory_deep_select();
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00x2: Average is a column with all counts (Off / 2x / 4x / 8x / 16x) above More, like Memory: the selected one
//orange. In roll mode (no averaging there) the texts are grey. The old button below under #if 0.
static const char *acq_avg_texts[AVERAGE_MODES] = { "Off", "2x", "4x", "8x", "16x" };

#define ACQ_COL_BTN_X(c)   (ACQ_MENU_XPOS + (c) + 11)
#define ACQ_COL_BTN_Y(i)   (ACQ_MENU_YPOS + 33 + ((i) * 28))
#define ACQ_COL_BTN_W      54
#define ACQ_COL_BTN_H      22

static void acq_column_button(uint32 col, uint32 i, const char *text, uint32 selected, uint32 enabled)
{
  uint32 x = ACQ_COL_BTN_X(col);
  uint32 y = ACQ_COL_BTN_Y(i);

  display_set_fg_color(selected ? ORANGE_COLOR : MIDLEGREY_COLOR);
  display_fill_rounded_rect(x, y, ACQ_COL_BTN_W, ACQ_COL_BTN_H, 2);

  display_set_fg_color(selected ? BLACK_COLOR : enabled ? WHITE_COLOR : LIGHTGREY1_COLOR);
  display_text(x + ((ACQ_COL_BTN_W - mm_text_width(text)) / 2), y + 4, (int8 *)text);
}

static int32 acq_column_hit(uint32 col, uint32 count, uint32 xt, uint32 yt)
{
  uint32 i;

  for(i = 0; i < count; i++)
  {
    if((xt >= ACQ_COL_BTN_X(col)) && (xt <= (ACQ_COL_BTN_X(col) + ACQ_COL_BTN_W)) && (yt >= ACQ_COL_BTN_Y(i)) && (yt <= (ACQ_COL_BTN_Y(i) + ACQ_COL_BTN_H)))
      return(i);
  }

  return(-1);
}

void scope_acquisition_Average_mode_select(void)
{
  uint32 i;

  display_set_font(&font_2);

  for(i = 0; i < AVERAGE_MODES; i++)
    acq_column_button(ACQ_MENU_COL3_X, i, acq_avg_texts[i], (i == scopesettings.average_mode), !scopesettings.long_mode);

  //v1.00y5: no effect in the spectrum view (it is drawn outside the trace path): dimmed
  if(spectrum_is_active() && !scopesettings.waveviewmode)
    display_dim_rect(ACQ_MENU_XPOS + ACQ_MENU_COL3_X + 2, ACQ_MENU_YPOS + 30, ACQ_MENU_COL_W - 4, 172);
}

//v1.00x2: touch in the upper part of the Average or Persist column; 1 when something changed
uint32 scope_acquisition_avg_persist_touch(uint32 xt, uint32 yt)
{
  int32 i;

  if((i = acq_column_hit(ACQ_MENU_COL3_X, AVERAGE_MODES, xt, yt)) >= 0)
  {
    //No averaging in roll mode (as the old button)
    if(scopesettings.long_mode)
      return(0);

    scopesettings.average_mode = i;
    scope_acquisition_Average_mode_select();
    scope_acqusition_settings(0);
    return(1);
  }

  if((i = acq_column_hit(ACQ_MENU_COL4_X, PERSIST_MODES, xt, yt)) >= 0)
  {
    //A touch on the selected one clears the persistence too
    scopesettings.persistence = i;
    persist_clear_request = 1;
    scope_acquisition_persist_select();
    return(1);
  }

  return(0);
}

//v1.00x2: ACQ button "ACQ Roll" (as MCP): green with black text when the roll (long time base) mode is on
void scope_acquisition_acq_button(void)
{
  display_set_fg_color(scopesettings.long_mode ? GREEN_COLOR : LIGHTGREY_COLOR);
  display_fill_rounded_rect(ACQ_MENU_XPOS + 8, ACQ_MENU_YPOS + 163, 90, 40, 3);

  display_set_font(&font_2);
  display_set_fg_color(scopesettings.long_mode ? BLACK_COLOR : WHITE_COLOR);
  display_text(ACQ_MENU_XPOS + 53 - (mm_text_width("ACQ") / 2),  ACQ_MENU_YPOS + 168, "ACQ");
  display_text(ACQ_MENU_XPOS + 53 - (mm_text_width("Roll") / 2), ACQ_MENU_YPOS + 182, "Roll");
}

//v1.00x2: Clear in the middle row (place of the old Average button): starts Average and Persist again from the
//current record (green while touched)
void scope_acquisition_clear_button(uint32 pressed)
{
  display_set_fg_color(pressed ? GREEN_COLOR : LIGHTGREY_COLOR);
  display_fill_rounded_rect(ACQ_MENU_XPOS + 106, ACQ_MENU_YPOS + 163, 90, 40, 3);

  display_set_font(&font_2);
  display_set_fg_color(pressed ? BLACK_COLOR : WHITE_COLOR);
  display_text(ACQ_MENU_XPOS + 151 - (mm_text_width("Clear") / 2),   ACQ_MENU_YPOS + 168, "Clear");
  display_text(ACQ_MENU_XPOS + 151 - (mm_text_width("Avg/Pers") / 2), ACQ_MENU_YPOS + 182, "Avg/Pers");

  //v1.00y5: no effect in the spectrum view: dimmed
  if((spectrum_is_active() && !scopesettings.waveviewmode) || scope_roll_ui())     //v1.00z1: and in the logger roll
    display_dim_rect(ACQ_MENU_XPOS + 106, ACQ_MENU_YPOS + 163, 90, 40);
}

void scope_acquisition_clear_touch(void)
{
  scope_average_reset();
  persist_clear_request = 1;
  scope_acquisition_clear_button(1);
}

void scope_acquisition_Average_mode_select_old(void)
{
    if ((scopesettings.average_mode)&&(!scopesettings.long_mode))
    {
        //Set dark grey color for the boxes behind the not selected texts
        display_set_fg_color(GREEN_COLOR);
        //Clear the boxes for the not selected items (Average)
        display_fill_rounded_rect(ACQ_MENU_XPOS + 106, ACQ_MENU_YPOS + 163, 90, 40, 3);
        //Texts in black
        display_set_fg_color(BLACK_COLOR);        
    }
    else
    {
        //Set dark grey color for the boxes behind the not selected texts
        display_set_fg_color(LIGHTGREY_COLOR);
        //Clear the boxes for the not selected items (Average)
        display_fill_rounded_rect(ACQ_MENU_XPOS + 106, ACQ_MENU_YPOS + 163, 90, 40, 3);
        //Texts in white
        display_set_fg_color(WHITE_COLOR); 
    }
    
    //Select the font for the texts
    display_set_font(&font_2);
  
    //Display average text
    display_text(ACQ_MENU_XPOS + 128, ACQ_MENU_YPOS +  168, "Average");
    //display_text(ACQ_MENU_XPOS + 136, ACQ_MENU_YPOS +  182, "mode");
    //v1.00w2: the selected count under the name (every touch steps Off / 2 / 4 / 8 / 16)
    {
      static const char *avg_texts[AVERAGE_MODES] = { "Off", "2x", "4x", "8x", "16x" };
      uint32 m = (scopesettings.average_mode < AVERAGE_MODES) ? scopesettings.average_mode : 0;

      display_text(ACQ_MENU_XPOS + 151 - (mm_text_width((char *)avg_texts[m]) / 2), ACQ_MENU_YPOS +  182, (int8 *)avg_texts[m]);
    }

}

//----------------------------------------------------------------------------------------------------------------------------------
void scope_acquisition_Long_memory_select(void)
{                  
    if ((scopesettings.long_memory)&&(!scopesettings.long_mode))
    {
        //Set dark grey color for the boxes behind the not selected texts
        display_set_fg_color(GREEN_COLOR);
        //Clear the boxes for the not selected items (Long_memory)
        display_fill_rounded_rect(ACQ_MENU_XPOS + 204, ACQ_MENU_YPOS + 163, 90, 40, 3);
        //Texts in black
        display_set_fg_color(BLACK_COLOR);        

    }
    else
    {
        //Set dark grey color for the boxes behind the not selected texts
        display_set_fg_color(LIGHTGREY_COLOR);
        //Clear the boxes for the not selected items (Average)
        display_fill_rounded_rect(ACQ_MENU_XPOS + 204, ACQ_MENU_YPOS + 163, 90, 40, 3);
        //Texts in white
        display_set_fg_color(WHITE_COLOR); 
    }
    
    /*
     * 
     *   //Clear the boxes for the not selected items (ACQ, Average, Long memory)
  display_fill_rect(ACQ_MENU_XPOS +   8, ACQ_MENU_YPOS + 163, 90, 40);
  //display_fill_rect(ACQ_MENU_XPOS + 106, ACQ_MENU_YPOS + 163, 90, 40);
  display_fill_rect(ACQ_MENU_XPOS + 204, ACQ_MENU_YPOS + 163, 90, 40);
     * 
     * 
       if (scopesettings.long_memory)
  //Set black color for the text
  display_set_fg_color(BLACK_COLOR); else display_set_fg_color(WHITE_COLOR);
  display_text(ACQ_MENU_XPOS + 235, ACQ_MENU_YPOS +  168, "Long");
  display_text(ACQ_MENU_XPOS + 225, ACQ_MENU_YPOS +  182, "memory");
     
     */
    
    //Select the font for the texts
    display_set_font(&font_2);
  
    //Display long memory text
    display_text(ACQ_MENU_XPOS + 235, ACQ_MENU_YPOS +  168, "Long");
    display_text(ACQ_MENU_XPOS + 225, ACQ_MENU_YPOS +  182, "memory");     

}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00z4: the Memory column edits the normal record length (FPGA) or, in the logger roll on the port, the roll's own
//length (MCU RAM, so all choices up to 16000 whatever the FPGA memory). It switches with the ACQ mode by itself.
uint32 acq_memory_choice(uint32 i)
{
  if(scope_roll_live())
    return((i < 4) ? ((i + 1) * 3000) : 16000);

  return(fpga_memory_choice(i));
}

uint32 acq_memory_max(void)
{
  if(scope_roll_live())
    return(16000);

  return(fpga_max_samples());
}

uint32 acq_memory_current(void)
{
  if(scope_roll_live())
    return(scopesettings.rollmemory);

  return(scopesettings.samplecount);
}

void scope_acquisition_memory_deep_select(void)
{                  
  //Select the font for the texts
  //display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  //display_set_fg_color(DARKGREY_COLOR);
  
  //*********************
  uint32 c,i,x,y;

  //Select the font for the texts
  display_set_font(&font_2);

  //Set middle grey color for the boxes behind the not selected texts & highlight the selected item
  display_set_fg_color(MIDLEGREY_COLOR);
      
  //Clear the boxes for the not selected items
  for(i=0;i<(sizeof(memory_deep_texts) / sizeof(int8 *));i++)
  { 
    //Get the position of the item
    x = 315 + ACQ_MENU_XPOS;
    y = (i * 36) + 33 + ACQ_MENU_YPOS;

    //Set yellow color for the box behind the selected text
    //if(i == (scopesettings.samplecount/3000) - 1) display_set_fg_color(YELLOW_COLOR); else display_set_fg_color(MIDLEGREY_COLOR);
    if(i == (acq_memory_current()/3000) - 1) display_set_fg_color(YELLOW_COLOR); else display_set_fg_color(MIDLEGREY_COLOR);     //v1.00z4
      
    display_fill_rounded_rect(x, y, 54, 25, 2);//53
  }

  for(i=0;i<(sizeof(memory_deep_texts) / sizeof(int8 *));i++)
  {
    //Settings displayed from smallest to highest value
    c = (i);

    //Check if the current text is the selected on
    //if(c != ((scopesettings.samplecount/3000) - 1))
    if(c != ((acq_memory_current()/3000) - 1))     //v1.00z4: the roll's own length in roll
    {
      //Available but viable not selected texts in white
      //display_set_fg_color(WHITE_COLOR);
      //v1.00x4: a length the FPGA memory does not hold in grey (not selectable)
      //display_set_fg_color((fpga_memory_choice(c) <= fpga_max_samples()) ? WHITE_COLOR : LIGHTGREY1_COLOR);
      display_set_fg_color((acq_memory_choice(c) <= acq_memory_max()) ? WHITE_COLOR : LIGHTGREY1_COLOR);     //v1.00z4
    }
    else
    {
      //Selected texts in black
      display_set_fg_color(BLACK_COLOR);
    }

    //Calculate the position of this text
    x = 315 + memory_deep_texts_x_offsets[c];
    y = (c * 36) +  38;

    //Display the text from the table
    //display_text(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, (int8 *)memory_deep_texts[c]);
    //v1.00x4: the last choice is 16000 when the memory holds it (0x2050, AL3, EP4)
    //display_text(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, (int8 *)(((c == 4) && (fpga_memory_choice(4) == 16000)) ? "16000" : memory_deep_texts[c]));
    display_text(ACQ_MENU_XPOS + x, ACQ_MENU_YPOS + y, (int8 *)(((c == 4) && (acq_memory_choice(4) == 16000)) ? "16000" : memory_deep_texts[c]));     //v1.00z4
  }

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_acquisition_trace_select(void)
{
  //v1.00v8: two columns of four, the first Linear / Dots / Peak / Pro, the second Auto / Sin x. With Auto or Sin x
  //selected, the mode it draws with at the current time base has green text
  uint32 i,x,y;
  uint32 used = scope_trace_mode_in_use();

  display_set_font(&font_2);

  for(i=0;i<TRACE_MODES;i++)
  {
    x = ACQ_MENU_XPOS + 315 + ((i >> 2) * 76);
    y = ACQ_MENU_YPOS + ((i & 3) * 36) + 241;

    //Orange box behind the selected mode
    display_set_fg_color((i == scopesettings.ACQ_trace) ? ORANGE_COLOR : MIDLEGREY_COLOR);
    display_fill_rounded_rect(x, y, 54, 25, 2);

    display_set_fg_color((i == scopesettings.ACQ_trace) ? BLACK_COLOR : (i == used) ? GREEN_COLOR : WHITE_COLOR);
    display_text(x + trace_texts_x_offsets[i], y + 5, (int8 *)trace_texts[i]);
  }

  //v1.00y5: no effect in the spectrum view: the Trace and More columns dimmed
  //if((spectrum_is_active() && !scopesettings.waveviewmode) || scope_roll_ui())     //v1.00z1: and in the logger roll
  //v1.00z5: the logger roll draws Linear / Dots / Peak / Pro itself (scope_roll_trace_mode): not dimmed there any more
  if(spectrum_is_active() && !scopesettings.waveviewmode)
    display_dim_rect(ACQ_MENU_XPOS + 306, ACQ_MENU_YPOS + 238, (ACQ_MENU_COL3_X + ACQ_MENU_COL_W) - 308, 145);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00w5: upper part of the More column: Line width (1 px / 2 px)
//v1.00w6: above it Persistence (Off / 1 s / 3 s / Inf), touch on the selected one clears the persistence

static const char *persist_texts[PERSIST_MODES] = { "Off", "1 s", "3 s", "Inf" };

void scope_acquisition_more_select(void)
{
  uint32 i, x, y;
  static const char *line_texts[2] = { "1px", "2px" };

  //v1.00x2: Line is in the lower part of the 4th column (title drawn with the menu), the upper part of the More
  //column is Average now: nothing cleared or drawn there any more
  //display_set_fg_color(DARKGREY_COLOR);
  //display_fill_rect(ACQ_MENU_XPOS + ACQ_MENU_COL3_X + 2, ACQ_MENU_YPOS + 4, 72, ACQ_MENU_MORE_LINE_Y + 28);

  //display_set_fg_color(WHITE_COLOR);
  //display_set_font(&font_3);
  //display_text(ACQ_MENU_XPOS + ACQ_MENU_COL3_X + ((76 - mm_text_width("Persist")) / 2), ACQ_MENU_YPOS + 8, "Persist");
  //display_text(ACQ_MENU_XPOS + ACQ_MENU_COL3_X + ((76 - mm_text_width("Line")) / 2), ACQ_MENU_YPOS + ACQ_MENU_MORE_LINE_Y - 26, "Line");

  display_set_font(&font_2);

  //v1.00x1: Persist moved to the button row (place of Long memory), the column top is free again
#if 0
  for(i = 0; i < PERSIST_MODES; i++)
  {
    x = ACQ_MENU_XPOS + ACQ_MENU_COL3_X + 11;
    y = ACQ_MENU_YPOS + 33 + (i * 28);

    display_set_fg_color((i == scopesettings.persistence) ? ORANGE_COLOR : MIDLEGREY_COLOR);
    display_fill_rounded_rect(x, y, 54, 22, 2);

    display_set_fg_color((i == scopesettings.persistence) ? BLACK_COLOR : WHITE_COLOR);
    display_text(x + ((54 - mm_text_width(persist_texts[i])) / 2), y + 4, (int8 *)persist_texts[i]);
  }
#endif

  for(i = 0; i < 2; i++)
  {
    //x = ACQ_MENU_XPOS + ACQ_MENU_COL3_X + 5 + (i * 34);
    //y = ACQ_MENU_YPOS + ACQ_MENU_MORE_LINE_Y;
    //v1.00x2: the same buttons as the trace modes, under each other in the 4th column
    x = ACQ_MENU_XPOS + ACQ_MENU_COL4_X + 11;
    y = ACQ_MENU_YPOS + (i * 36) + 241;

    display_set_fg_color((i == scopesettings.thicktrace) ? ORANGE_COLOR : MIDLEGREY_COLOR);
    //display_fill_rounded_rect(x, y, 32, 25, 2);
    display_fill_rounded_rect(x, y, 54, 25, 2);

    display_set_fg_color((i == scopesettings.thicktrace) ? BLACK_COLOR : WHITE_COLOR);
    //display_text(x + ((32 - mm_text_width(line_texts[i])) / 2), y + 5, (int8 *)line_texts[i]);
    display_text(x + ((54 - mm_text_width(line_texts[i])) / 2), y + 5, (int8 *)line_texts[i]);
  }

  //v1.00y5: no effect in the spectrum view: the Line column dimmed
  if(spectrum_is_active() && !scopesettings.waveviewmode)
    display_dim_rect(ACQ_MENU_XPOS + ACQ_MENU_COL4_X + 2, ACQ_MENU_YPOS + 238, ACQ_MENU_COL_W - 4, 145);
}

//v1.00w5: touch in the upper part of the More column, returns 1 when a setting changed
uint32 scope_acquisition_more_touch(uint32 xt, uint32 yt)
{
  uint32 i, x, y;

  //v1.00w6: persistence (v1.00x1: moved to the button row, scope_acquisition_persist_touch)
#if 0
  for(i = 0; i < PERSIST_MODES; i++)
  {
    x = ACQ_MENU_XPOS + ACQ_MENU_COL3_X + 11;
    y = ACQ_MENU_YPOS + 33 + (i * 28);

    if((xt >= x) && (xt <= (x + 54)) && (yt >= y) && (yt <= (y + 22)))
    {
      scopesettings.persistence = i;
      persist_clear_request = 1;
      scope_acquisition_more_select();
      return(1);
    }
  }
#endif

  for(i = 0; i < 2; i++)
  {
    //x = ACQ_MENU_XPOS + ACQ_MENU_COL3_X + 5 + (i * 34);
    //y = ACQ_MENU_YPOS + ACQ_MENU_MORE_LINE_Y;
    //v1.00x2: lower part of the 4th column
    x = ACQ_MENU_XPOS + ACQ_MENU_COL4_X + 11;
    y = ACQ_MENU_YPOS + (i * 36) + 241;

    //if((xt >= x) && (xt <= (x + 32)) && (yt >= y) && (yt <= (y + 25)))
    if((xt >= x) && (xt <= (x + 54)) && (yt >= y) && (yt <= (y + 25)))
    {
      scopesettings.thicktrace = i;
      scope_acquisition_more_select();
      return(1);
    }
  }

  return(0);
}

//v1.00x1: Persist button in the middle button row (where the unused Long memory button was), like Average: green
//when on, every touch steps Off / 1 s / 3 s / Inf and clears the persistence
//v1.00x2: Persist is a column with all settings (Off / 1 s / 3 s / Inf) in the 4th column, the button below unused
void scope_acquisition_persist_select(void)
{
  uint32 i;

  display_set_font(&font_2);

  for(i = 0; i < PERSIST_MODES; i++)
    acq_column_button(ACQ_MENU_COL4_X, i, persist_texts[i], (i == scopesettings.persistence), 1);

  //v1.00y5: no effect in the spectrum view: dimmed
  if((spectrum_is_active() && !scopesettings.waveviewmode) || scope_roll_ui())     //v1.00z1: and in the logger roll
    display_dim_rect(ACQ_MENU_XPOS + ACQ_MENU_COL4_X + 2, ACQ_MENU_YPOS + 30, ACQ_MENU_COL_W - 4, 172);
}

void scope_acquisition_persist_select_old(void)
{
  uint32 m = (scopesettings.persistence < PERSIST_MODES) ? scopesettings.persistence : 0;

  display_set_fg_color(m ? GREEN_COLOR : LIGHTGREY_COLOR);
  display_fill_rounded_rect(ACQ_MENU_XPOS + 204, ACQ_MENU_YPOS + 163, 90, 40, 3);

  display_set_fg_color(m ? BLACK_COLOR : WHITE_COLOR);
  display_set_font(&font_2);
  display_text(ACQ_MENU_XPOS + 249 - (mm_text_width("Persist") / 2), ACQ_MENU_YPOS + 168, "Persist");
  display_text(ACQ_MENU_XPOS + 249 - (mm_text_width(persist_texts[m]) / 2), ACQ_MENU_YPOS + 182, (int8 *)persist_texts[m]);
}

void scope_acquisition_persist_touch(void)
{
  scopesettings.persistence = (scopesettings.persistence + 1) % PERSIST_MODES;
  persist_clear_request = 1;
  scope_acquisition_persist_select();
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_trigger_menu(void)
{
  uint32 xstart;
  uint32 xend;
  
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  //display_fill_rect(560, 46, 166, 246);//186
  display_fill_rect(TRIGGER_MENU_XPOS, TRIGGER_MENU_YPOS, TRIGGER_MENU_WIDTH, TRIGGER_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  //display_draw_rect(560, 46, 166, 246);//186
  display_draw_rect(TRIGGER_MENU_XPOS, TRIGGER_MENU_YPOS, TRIGGER_MENU_WIDTH, TRIGGER_MENU_HEIGHT);
  
    //Line start and end x positions
  xstart = TRIGGER_MENU_XPOS + 10;//14
  xend   = TRIGGER_MENU_XPOS + TRIGGER_MENU_WIDTH - 10;//-4

  //Two black lines between the settings step 56
  display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(102, xstart, xend);//102//716//61
  display_draw_horz_line(158, xstart, xend);//158//716
  display_draw_horz_line(214, xstart, xend);////214 716
  display_draw_horz_line(270, xstart, xend);////270 716
  display_draw_horz_line(326, xstart, xend);////270 716

  //Main texts in white
  display_set_fg_color(WHITE_COLOR);

  //Select the font for the texts
  display_set_font(&font_3);

  //Display the texts
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+10,  "Trigger");//56
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+29,  "mode");//57
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+66,  "Trigger");//112
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+85,  "edge");//131
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+122, "Trigger");//168
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+141, "channel");//187
  
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+178, "Trigger");//224
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+197, "position");//243 position 
  
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+234, "Hold");//280
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+253, "off");//299
  
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+290, "Always");//224
  display_text(TRIGGER_MENU_XPOS+10, TRIGGER_MENU_YPOS+309, "50%");//243
  
  //Display the icon with the set colors
  display_copy_icon_use_colors(trigger_50_percent_icon, TRIGGER_MENU_XPOS+75, TRIGGER_MENU_YPOS+294, 24, 24);//296 //184

  //Display the actual settings
  scope_trigger_mode_select();
  scope_trigger_edge_select();
  scope_trigger_channel_select();
  scope_trigger_position_select();
  scope_hold_off_select();
  scope_always_trigger50_select();
  //scope_hold_off_select();

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  //display_slide_top_rect_onto_screen(560, 46, 166, 246, 56415);//186
  display_slide_top_rect_onto_screen(TRIGGER_MENU_XPOS, TRIGGER_MENU_YPOS, TRIGGER_MENU_WIDTH, TRIGGER_MENU_HEIGHT, 56415);
}

//==============================================================================

void scope_trigger_mode_select(void)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);

  //Check which trigger mode is selected
  switch(scopesettings.triggermode)
  {
    case 0:                                 //AUTO
      //dark grey single and normal
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+65, TRIGGER_MENU_YPOS+17, 47, 22, 2);//661 56
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+156, TRIGGER_MENU_YPOS+17, 54, 22, 2);//692 56
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(TRIGGER_MENU_XPOS+65, TRIGGER_MENU_YPOS+17, 47, 22, 2);//661 56
      display_draw_rounded_rect(TRIGGER_MENU_XPOS+156, TRIGGER_MENU_YPOS+17, 54, 22, 2);//692 56
      break;

    case 1:                                 //SINGLE
      //dark grey auto and normal
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+116, TRIGGER_MENU_YPOS+17, 36, 22, 2);//628 57 20 38
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+156, TRIGGER_MENU_YPOS+17, 54, 22, 2);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(TRIGGER_MENU_XPOS+116, TRIGGER_MENU_YPOS+17, 36, 22, 2);//628 57 20 38
      display_draw_rounded_rect(TRIGGER_MENU_XPOS+156, TRIGGER_MENU_YPOS+17, 54, 22, 2);//692 56
      break;

    default:                                //NORMAL
      //dark grey auto and single
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+65, TRIGGER_MENU_YPOS+17, 47, 22, 2);//629 57 20 38
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+116, TRIGGER_MENU_YPOS+17, 36, 22, 2);//661
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(TRIGGER_MENU_XPOS+65, TRIGGER_MENU_YPOS+17, 47, 22, 2);//661 56
      display_draw_rounded_rect(TRIGGER_MENU_XPOS+116, TRIGGER_MENU_YPOS+17, 36, 22, 2);//661
      break;
  }

  //Set trigger color for the box behind the selected text
  //display_set_fg_color(TRIGGER_COLOR);

  //Check if which trigger mode to highlight
  switch(scopesettings.triggermode)
  {
    case 0:
      //Highlight auto mode
      display_set_fg_color(TRIGGER_COLOR);  
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+116, TRIGGER_MENU_YPOS+17, 36, 22, 2);//629 57 20 38
      break;

    case 1:
      //Highlight single mode
      display_set_fg_color(ORANGE_COLOR); 
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+65, TRIGGER_MENU_YPOS+17, 47, 22, 2);//661 68 101 132
      break;

    default:
      //Highlight normal mode
      display_set_fg_color(DARKGREEN_COLOR);
      display_fill_rounded_rect(TRIGGER_MENU_XPOS+156, TRIGGER_MENU_YPOS+17, 54, 22, 2);//692
      break;
  }

  //Check if trigger mode is auto
  if(scopesettings.triggermode == 0)
  {
    //Yes so black auto text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //When not selected check if in normal view mode
    if(scopesettings.waveviewmode)
    {  
      //Grey auto text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White auto text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the auto text
  display_text(TRIGGER_MENU_XPOS+120, TRIGGER_MENU_YPOS+19, "Auto");//71 11 72 5
  //display_text(TRIGGER_MENU_XPOS+69, TRIGGER_MENU_YPOS+11, "Au");//71 11
  //display_text(TRIGGER_MENU_XPOS+71, TRIGGER_MENU_YPOS+28, "to");//73 28

  //Check if trigger mode is single
  if(scopesettings.triggermode == 1)
  {
    //Yes so black single text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //When not selected check if in normal view mode
    if(scopesettings.waveviewmode)
    {
      //Grey single text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
    else
    {
      //White single text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the single text
  display_text(TRIGGER_MENU_XPOS+68, TRIGGER_MENU_YPOS+19,  "Single");//666 110 19
  //display_text(TRIGGER_MENU_XPOS+104, TRIGGER_MENU_YPOS+9,  "Si");//666
  //display_text(TRIGGER_MENU_XPOS+103, TRIGGER_MENU_YPOS+19, "ng");
  //display_text(TRIGGER_MENU_XPOS+105, TRIGGER_MENU_YPOS+32, "le");

  //Check if trigger mode is normal
  if(scopesettings.triggermode > 1)
  {
    //Yes so black normal text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //When not selected check if in normal view mode
    if(scopesettings.waveviewmode)
    {
      //Grey normal text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);        
    }
    else
    {
      //White normal text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the normal text
  display_text(TRIGGER_MENU_XPOS+160, TRIGGER_MENU_YPOS+19,  "Normal");//695 155 33
  //display_text(TRIGGER_MENU_XPOS+134, TRIGGER_MENU_YPOS+9,  "No");//695
  //display_text(TRIGGER_MENU_XPOS+134, TRIGGER_MENU_YPOS+19, "rm");
  //display_text(TRIGGER_MENU_XPOS+136, TRIGGER_MENU_YPOS+32, "al");
}

//==============================================================================

void scope_trigger_edge_select(void)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);

  //Check which trigger edge is selected
  if(scopesettings.triggeredge == 0)
  {
    //Rising so dark grey box behind falling
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+150, TRIGGER_MENU_YPOS+74, 55, 22, 2);//110 74 47 22 2
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+150, TRIGGER_MENU_YPOS+74, 55, 22, 2);
  }
  else
  {
    //Falling so dark grey box behind rising
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+74, 55, 22, 2);//65 74 42 22 2
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+74, 55, 22, 2);
  }

  //Check which trigger edge is selected
  if(scopesettings.triggeredge == 0)
  {
    //Set trigger color for the box behind the selected text
    display_set_fg_color(LIGHTRED_COLOR);
    //Rising so trigger color box behind rising
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+74, 55, 22, 2);//626 125 40 22
  }
  else
  {   
    //Set trigger color for the box behind the selected text
    display_set_fg_color(LDARKBLUE_COLOR);
    //Falling so trigger color box behind falling
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+150, TRIGGER_MENU_YPOS+74, 55, 22, 2);//671 125 45 22
  }

  //Check which trigger edge is selected
  if(scopesettings.triggeredge == 0)
  {
    //Rising so black rising text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //For falling edge trigger check if in normal view mode
    if(scopesettings.waveviewmode)
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);        
    }
    else
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }

  //Display the rising text
  display_text(TRIGGER_MENU_XPOS+78, TRIGGER_MENU_YPOS+76, "Rising");//629 127

  //Check which trigger edge is selected
  if(scopesettings.triggeredge == 0)
  {
    //For rising edge trigger check if in normal view mode
    if(scopesettings.waveviewmode)
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);        
    }
    else
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
  }
  else
  {
    //Falling so black falling text
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the falling text
  display_text(TRIGGER_MENU_XPOS+156, TRIGGER_MENU_YPOS+76, "Falling");//160//112//672//674
  
  
  display_set_fg_color(DARKGREY_COLOR);
  scope_trigger_symbol(TRIGGER_MENU_XPOS+66, TRIGGER_MENU_YPOS+59);
}

//==============================================================================

void scope_trigger_channel_select(void)
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);

  //Check if channel is 1 or 2 or EXT
  if(scopesettings.triggerchannel == 0)//0-ch1
  {
    //1 so dark grey box behind CH2 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+129, 33, 22, 2);//118
    //2 so dark grey box behind EXT text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+129, 33, 22, 2);//166
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+129, 33, 22, 2);//118
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+129, 33, 22, 2);
  }
  else if(scopesettings.triggerchannel == 1)//1-ch2
  {
    //2 so dark grey box behind CH1 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+129, 33, 22, 2);
    //2 so dark grey box behind EXT text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+129, 33, 22, 2);
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+129, 33, 22, 2);
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+129, 33, 22, 2);
  }
  else if(scopesettings.triggerchannel == 2)//2-ext
  {
    //2 so dark grey box behind CH1 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+129, 33, 22, 2);
    //1 so dark grey box behind CH2 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+129, 33, 22, 2);//188
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+129, 33, 22, 2);
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+129, 33, 22, 2);
  }

  //Set trigger color for the box behind the selected text
  //display_set_fg_color(TRIGGER_COLOR);

  //Check if channel is 1 or 2 or EXT
  if(scopesettings.triggerchannel == 0)//0-ch1
  {
    //Set channel color for the box behind the selected text
    display_set_fg_color(CHANNEL1_COLOR);
    //1 so trigger color box behind CH1 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+129, 33, 22, 2);
  }
  else if(scopesettings.triggerchannel == 1)//1-ch2
  {
    display_set_fg_color(CHANNEL2_COLOR);
    //2 so trigger color box behind CH2 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+129, 33, 22, 2);//188
  }
  else if(scopesettings.triggerchannel == 2)
  {
    display_set_fg_color(EXTERN_TRIG_COLOR);
    //2 so trigger color box behind CH2 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+129, 33, 22, 2);//188
  }

  //Check if channel is 1 or 2
  if(scopesettings.triggerchannel == 0)
  {
    //1 so black CH1 text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //2 so white or grey CH1 text
    if((!scopesettings.waveviewmode) && scopesettings.channel1.enable)
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
    else
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
  }

  //Display the CH1 text
  display_text(TRIGGER_MENU_XPOS+74, TRIGGER_MENU_YPOS+132, "CH1");//191
  //-----------------------------------------------------

  //Check if channel is 1 or 2
  if(scopesettings.triggerchannel == 1)
  {
    //2 so black CH2 text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //1 so white or grey CH2 text
    if((!scopesettings.waveviewmode) && scopesettings.channel2.enable)
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
    else
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
  }

  //Display the CH2 text
  display_text(TRIGGER_MENU_XPOS+125, TRIGGER_MENU_YPOS+132, "CH2");
  
    //-----------------------------------------------------

  //Check if channel is 1 or 2
  if(scopesettings.triggerchannel == 2)
  {
    // so black EXT text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //so white or grey EXT text
    //if((!scopesettings.waveviewmode) && scopesettings.channel2.enable)
    if((!scopesettings.waveviewmode))
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
    else
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
  }

  //Display the CH2 text
  display_text(TRIGGER_MENU_XPOS+176, TRIGGER_MENU_YPOS+132, "EXT");

  //v1.00z1: no EXT in the logger roll: dimmed
  if(scope_roll_ui())
    display_dim_rect(TRIGGER_MENU_XPOS + 168, TRIGGER_MENU_YPOS + 126, 42, 28);
}

//==============================================================================

void scope_trigger_position_select(void)
{
//Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  display_set_fg_color(DARKGREY_COLOR);

  //Check if trigger point is 25 50 75%
  if(scopesettings.trigger_position_mem == 1)  //25%
  {
    //1 so dark grey box behind 50% text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+185, 33, 22, 2);//118
    //2 so dark grey box behind 75% text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+185, 33, 22, 2);//166
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+185, 33, 22, 2);//118
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+185, 33, 22, 2);
  }
  else if(scopesettings.trigger_position_mem == 2) //50%
  {
    //2 so dark grey box behind 25% text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+185, 33, 22, 2);
    //2 so dark grey box behind 75% text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+185, 33, 22, 2);
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+185, 33, 22, 2);
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+185, 33, 22, 2);
  }
  else if(scopesettings.trigger_position_mem == 3) //75%
  {
    //2 so dark grey box behind 25% text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+185, 33, 22, 2);
    //1 so dark grey box behind 50% text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+185, 33, 22, 2);//188
    display_set_fg_color(GREY_COLOR);//GREY_COLOR
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+185, 33, 22, 2);
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+185, 33, 22, 2);
  }

  //Set trigger color for the box behind the selected text
  //display_set_fg_color(TRIGGER_COLOR);

  //Check if trigger point is 25 50 75%
  if(scopesettings.trigger_position_mem == 1)  //25%
  {
    //Set channel color for the box behind the selected text
    display_set_fg_color(LDARKBLUE_COLOR);
    //1 so trigger color box behind CH1 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+70, TRIGGER_MENU_YPOS+185, 33, 22, 2);
  }
  else  if(scopesettings.trigger_position_mem == 2)  //50%
  {
    display_set_fg_color(DARKGREEN_COLOR);
    //2 so trigger color box behind CH2 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+121, TRIGGER_MENU_YPOS+185, 33, 22, 2);//188
  }
  else  if(scopesettings.trigger_position_mem == 3)  //75%
  {
    display_set_fg_color(LIGHTRED_COLOR);
    //2 so trigger color box behind CH2 text
    display_fill_rounded_rect(TRIGGER_MENU_XPOS+172, TRIGGER_MENU_YPOS+185, 33, 22, 2);//188
  }

   //Check if trigger point is 25%
  if(scopesettings.trigger_position_mem == 1)  //25%
  {
    //1 so black CH1 text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //2 so white or grey CH1 text
    if((!scopesettings.waveviewmode))
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
    else
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
  }

  //Display the 25% text
  //display_text(TRIGGER_MENU_XPOS+75, TRIGGER_MENU_YPOS+188, "25%");//191
  display_text(TRIGGER_MENU_XPOS+76, TRIGGER_MENU_YPOS+188, "Min");//191
  //-----------------------------------------------------

  //Check if trigger point is 50%
  if(scopesettings.trigger_position_mem == 2)  //50%
  {
    //2 so black CH2 text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //1 so white or grey CH2 text
    if((!scopesettings.waveviewmode))
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
    else
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
  }

  //Display the 50% text
  display_text(TRIGGER_MENU_XPOS+126, TRIGGER_MENU_YPOS+188, "50%");
  
    //-----------------------------------------------------

  //Check if trigger point is 75%
  if(scopesettings.trigger_position_mem == 3)  //75%
  {
    // so black EXT text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //so white or grey EXT text
    //if((!scopesettings.waveviewmode) && scopesettings.channel2.enable)
    if((!scopesettings.waveviewmode))
    {
      //White text if in normal mode
      display_set_fg_color(WHITE_COLOR);
    }
    else
    {
      //Grey text when in waveform view mode
      display_set_fg_color(LIGHTGREY1_COLOR);
    }
  }

  //Display the 75% text
  //display_text(TRIGGER_MENU_XPOS+177, TRIGGER_MENU_YPOS+188, "75%");
  display_text(TRIGGER_MENU_XPOS+175, TRIGGER_MENU_YPOS+188, "Max");

  //v1.00z1: no trigger position in the logger roll: dimmed
  if(scope_roll_ui())
    display_dim_rect(TRIGGER_MENU_XPOS + 66, TRIGGER_MENU_YPOS + 182, 144, 28);
}
  

//==============================================================================
  
void scope_hold_off_select(void)
{
  //v1.00x3: hold-off value box (touch opens the keyboard, value in ms) and an Off button. Only FPGA 0x2050 has the
  //hold-off; with other FPGAs the row shows "n/a" in grey and does nothing.
  char  t[16];
  char *p = t;
  //uint32 v = fpgasettings.en_holdoff_trigger ? fpgasettings.value_holdoff_trigger : 0;
  //v1.00x5: the value in 5 ns clocks, shown in s / ms / us / ns with up to 3 decimals
  //uint32 v = fpgasettings.en_holdoff_trigger ? fpgasettings.holdoff_ticks : 0;
  //v1.00x7: the value box always shows the last entered value; the button right of it is ON (green frame) / OFF (red
  //frame) and switches the hold-off without losing the value
  uint32 v  = fpgasettings.holdoff_ticks;
  uint32 on = fpgasettings.en_holdoff_trigger && fpgasettings.holdoff_ticks;
  uint32 ok = FPGA_IS_153F_PORT();

  display_set_font(&font_3);

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(TRIGGER_MENU_XPOS+70,  TRIGGER_MENU_YPOS+241, 92, 22, 2);
  //display_fill_rounded_rect(TRIGGER_MENU_XPOS+170, TRIGGER_MENU_YPOS+241, 35, 22, 2);
  //v1.00x8: ON green with black text, OFF red with white text (filled like the other buttons)
  display_set_fg_color(!ok ? DARKGREY_COLOR : on ? GREEN_COLOR : RED_COLOR);
  display_fill_rounded_rect(TRIGGER_MENU_XPOS+170, TRIGGER_MENU_YPOS+241, 35, 22, 2);

  //display_set_fg_color((ok && v) ? GREEN_COLOR : GREY_COLOR);
  //display_draw_rounded_rect(TRIGGER_MENU_XPOS+70,  TRIGGER_MENU_YPOS+241, 92, 22, 2);
  //display_set_fg_color((ok && !v) ? GREEN_COLOR : GREY_COLOR);
  //display_draw_rounded_rect(TRIGGER_MENU_XPOS+170, TRIGGER_MENU_YPOS+241, 35, 22, 2);
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(TRIGGER_MENU_XPOS+70,  TRIGGER_MENU_YPOS+241, 92, 22, 2);
  //display_set_fg_color(!ok ? GREY_COLOR : on ? GREEN_COLOR : RED_COLOR);
  //display_draw_rounded_rect(TRIGGER_MENU_XPOS+170, TRIGGER_MENU_YPOS+241, 35, 22, 2);
  if(!ok)
  {
    display_set_fg_color(GREY_COLOR);
    display_draw_rounded_rect(TRIGGER_MENU_XPOS+170, TRIGGER_MENU_YPOS+241, 35, 22, 2);
  }

  if(!ok)
  {
    p = (char *)"n/a";
  }
  else if(v == 0)
  {
    //p = (char *)"Off";
    p = (char *)"--";     //v1.00x7: no value entered yet
  }
  else
  {
    //v1.00x5: ns = clocks * 5; the unit where the whole part is at least 1, three decimals with trailing zeros cut
    uint64 ns = (uint64)v * 5;
    uint64 scale;
    const char *unit;
    uint32 ip, fp, i, digits[3];
    char  num[12];
    int32 n = 0;

    if(ns >= 1000000000ull)   { scale = 1000000000ull; unit = " s";  }
    else if(ns >= 1000000ull) { scale = 1000000ull;    unit = " ms"; }
    else if(ns >= 1000ull)    { scale = 1000ull;       unit = " us"; }
    else                      { scale = 1;             unit = " ns"; }

    ip = (uint32)(ns / scale);
    fp = (scale >= 1000) ? (uint32)((ns % scale) / (scale / 1000)) : 0;

    //Whole part
    do
    {
      num[n++] = '0' + (ip % 10);
      ip /= 10;
    } while(ip && (n < 11));

    while(n)
      *p++ = num[--n];

    //Decimals
    if(fp)
    {
      digits[0] = fp / 100;
      digits[1] = (fp / 10) % 10;
      digits[2] = fp % 10;

      *p++ = ',';

      for(i = 0; i < 3; i++)
      {
        *p++ = '0' + digits[i];

        if(((i == 0) && ((fp % 100) == 0)) || ((i == 1) && ((fp % 10) == 0)))
          break;
      }
    }

    while(*unit)
      *p++ = *unit++;

    *p = 0;
    p = t;
  }

  //display_set_fg_color(ok ? WHITE_COLOR : LIGHTGREY1_COLOR);
  //display_text(TRIGGER_MENU_XPOS+76, TRIGGER_MENU_YPOS+244, (int8 *)p);
  //display_text(TRIGGER_MENU_XPOS+176, TRIGGER_MENU_YPOS+244, "Off");
  //v1.00x7: the value white when ON, grey when OFF (kept for the next ON); the button text ON / OFF
  display_set_fg_color((ok && on) ? WHITE_COLOR : LIGHTGREY1_COLOR);
  display_text(TRIGGER_MENU_XPOS+76, TRIGGER_MENU_YPOS+244, (int8 *)p);
  //display_set_fg_color(ok ? WHITE_COLOR : LIGHTGREY1_COLOR);
  display_set_fg_color(!ok ? LIGHTGREY1_COLOR : on ? BLACK_COLOR : WHITE_COLOR);   //v1.00x8
  display_text(TRIGGER_MENU_XPOS+187 - (mm_text_width(on ? "ON" : "OFF") / 2), TRIGGER_MENU_YPOS+244, on ? "ON" : "OFF");

  //v1.00z1: no hold-off in the logger roll (the FPGA trigger is not used there): dimmed
  if(scope_roll_ui())
    display_dim_rect(TRIGGER_MENU_XPOS + 66, TRIGGER_MENU_YPOS + 238, 144, 28);
}

//==============================================================================

void scope_always_trigger50_select(void)
{
  //Select the font for the texts
  //display_set_font(&font_3); //treba? 21.11.2025

  //Set dark grey color for the box behind the not selected text
  //display_set_fg_color(DARKGREY_COLOR); //treba? 21.11.2025
  
  //Show the state (if always trige 50 on or off)
  scope_display_slide_button(TRIGGER_MENU_XPOS + 140, TRIGGER_MENU_YPOS + 296, scopesettings.alwaystrigger50, GREEN_COLOR);//140 186
}

//==============================================================================

//v1.00z2: 1 while the trigger button is drawn grey (no effect in the view)
uint8 trigger_symbol_grey = 0;

void scope_trigger_symbol(int x, int y)
{
  //Falling so black falling text
  //display_set_fg_color(DARKGREY_COLOR);
  //display_fill_rect(x+68, y+19, 8, 13);
  display_fill_rect(x+66, y+19, 11, 14);
  
  //White text if in normal mode
  //display_set_fg_color(WHITE_COLOR);
  display_set_fg_color(trigger_symbol_grey ? 0x00707070 : WHITE_COLOR);     //v1.00z2: grey on a button that does nothing
  
  //Draw the trigger edge symbol
  display_draw_vert_line(x+71, y+20, y+31);

  //Draw the arrow based on the selected edge
  if(scopesettings.triggeredge == 0)
  {
    //rising edge
    display_draw_horz_line(y+20, x+71, x+74);
    display_draw_horz_line(y+31, x+68, x+71);
    display_draw_horz_line(y+25, x+70, x+72);
    display_draw_horz_line(y+26, x+69, x+73);
  }
  else
  {
    //falling edge
    display_draw_horz_line(y+20, x+68, x+71);
    display_draw_horz_line(y+31, x+71, x+74);
    display_draw_horz_line(y+25, x+69, x+73);
    display_draw_horz_line(y+26, x+70, x+72);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_generator_menu(void)
{
  uint32 xstart;
  uint32 xend;
  
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1 //display_set_source_buffer(displaybuffer1);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(GEN_MENU_XPOS, GEN_MENU_YPOS, GEN_MENU_WIDTH, GEN_MENU_HEIGHT);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(GEN_MENU_XPOS, GEN_MENU_YPOS, GEN_MENU_WIDTH, GEN_MENU_HEIGHT);
  
    //Line start and end x positions
  xstart = GEN_MENU_XPOS + 10;
  xend   = GEN_MENU_XPOS + GEN_MENU_WIDTH - 10;

  //Two black lines between the settings step 56
  display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(102, xstart, xend);//
  display_draw_horz_line(158, xstart, xend);//
  display_draw_horz_line(214, xstart, xend);//
  display_draw_horz_line(270, xstart, xend);//
  display_draw_horz_line(326, xstart, xend);//
  display_draw_horz_line(382, xstart, xend);//

  //Main texts in white
  display_set_fg_color(WHITE_COLOR);

  //Select the font for the texts
  display_set_font(&font_3);

  //Display the texts
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+20,  "Power");//
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+76,  "Wave");// 
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+132, "Freq");//
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+188, "Duty");//
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+244, "Ampl");// 
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+300, "Offset");//
  display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+356, "Phase");//
  
   //display_copy_icon_use_colors ramik olkolo ikony generatora
  //display_draw_rounded_rect(GEN_MENU_XPOS+77, GEN_MENU_YPOS+11, 30, 32, 2);
  
  //Background icon color dark grey
  display_set_bg_color(DARKGREY_COLOR);
  
  //Display the icon with the set colors
  //display_copy_icon_use_colors(Generator_menu_icon, GEN_MENU_XPOS+80, GEN_MENU_YPOS+15, 24, 24);//24*24176//+21 299
  
  //Display the icon with the set colors
  //display_copy_icon_use_colors(trigger_50_percent_icon, GEN_MENU_XPOS+75, GEN_MENU_YPOS+184, 24, 24);

  //Display the actual settings
  gen_enable_select(); //gen_source_select();
  gen_wave_select();
  gen_freq_select();
  gen_duty_select();
  gen_ampl_select();
  gen_offset_select();
  gen_phase_select();
  
  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  //display_slide_top_rect_onto_screen(560, 46, 166, 246, 56415);//186
  display_slide_top_rect_onto_screen(GEN_MENU_XPOS, GEN_MENU_YPOS, GEN_MENU_WIDTH, GEN_MENU_HEIGHT, 56415);
}


//==============================================================================
void gen_enable_select(void) //genmenuopen
{
    //Select the font for the texts
  //display_set_font(&font_3);

  //Set dark grey color for the box behind the not selected text
  //display_set_fg_color(DARKGREY_COLOR); //treba? 21.11.2025
  
     //extern uint32 a,b,c,d,e,f,g,h,i,j,k;
  
  // add source  interny - externy , ch1 and ch2
  //display_text(GEN_MENU_XPOS+10, GEN_MENU_YPOS+356, "Source");//
     
  //Show the state (generator on or off)
  scope_display_slide_button(TRIGGER_MENU_XPOS + 162, TRIGGER_MENU_YPOS + 17, fpgasettings.gen_enable, GREEN_COLOR);//135 upravitt na 140 aj 50% triger a button
  
}
//==============================================================================
void gen_wave_select(void) //genmenuopen
{
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);
  
  //Check which generator mode is selected
  switch(fpgasettings.gen_wave_select)
  {
    case 0:                                  //SINE
      //dark grey SINE and TRIANGLE
      display_fill_rounded_rect(GEN_MENU_XPOS+117, GEN_MENU_YPOS+73, 38, 22, 2);//36 57 20 38
      display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+73, 42, 22, 2);
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(GEN_MENU_XPOS+117, GEN_MENU_YPOS+73, 38, 22, 2);//628 57 20 38
      display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+73, 42, 22, 2);//692 56
      break;//SINE


    case 1:                                 //SQUARE
      //dark grey SQUARE and TRIANGLE
      display_fill_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+73, 42, 22, 2);//65 17na74 47 22
      display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+73, 42, 22, 2);//54 56
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+73, 42, 22, 2);//47 56
      display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+73, 42, 22, 2);//54 56
      break;

    default:                                //TRIANGLE
      //dark grey SINE and SQUARE
      display_fill_rounded_rect(GEN_MENU_XPOS+65, GEN_MENU_YPOS+73, 42, 22, 2);//629 57 20 38
      display_fill_rounded_rect(GEN_MENU_XPOS+117, GEN_MENU_YPOS+73, 38, 22, 2);//661
      display_set_fg_color(GREY_COLOR);//GREY_COLOR
      display_draw_rounded_rect(GEN_MENU_XPOS+65, GEN_MENU_YPOS+73, 42, 22, 2);//661 56
      display_draw_rounded_rect(GEN_MENU_XPOS+117, GEN_MENU_YPOS+73, 38, 22, 2);//661
      break;
  }

  switch(fpgasettings.gen_wave_select)
  {
    case 0:
      //Highlight SQUARE mode
      display_set_fg_color(ORANGE_COLOR); 
      display_fill_rounded_rect(GEN_MENU_XPOS+65, GEN_MENU_YPOS+73, 42, 22, 2);//661 68 101 132
      break;
      
    case 1:
      //Highlight SINE mode
      display_set_fg_color(GREEN_COLOR);  
      display_fill_rounded_rect(GEN_MENU_XPOS+117, GEN_MENU_YPOS+73, 38, 22, 2);//629 57 20 38
      break;

    default:
      //Highlight TRIANGLE mode
      display_set_fg_color(YELLOW_COLOR);//DARKGREEN_COLOR
      display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+73, 42, 22, 2);//692
      break;
  }

  //Check if generator mode is square
  if(fpgasettings.gen_wave_select == 0)
  {
    //Yes so black square text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White square text if in normal mode
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Display the single text
  display_text(GEN_MENU_XPOS+67, GEN_MENU_YPOS+76,  "SQUR");//71

  //Check if generator mode is sine
  if(fpgasettings.gen_wave_select == 1)
  {
    //Yes so black sine text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White sine text if in generator mode
    display_set_fg_color(WHITE_COLOR);
  }
  
  //Display the sine text
  display_text(GEN_MENU_XPOS+121, GEN_MENU_YPOS+76, "SINE");//123


  //Check if generator mode is triangle
  if(fpgasettings.gen_wave_select == 2)
  {
    //Yes so black normal text
    display_set_fg_color(BLACK_COLOR);
  }
  else
  {
    //White normal text if in triangle mode
    display_set_fg_color(WHITE_COLOR); 
  }

  //Display the triangle text
  display_text(GEN_MENU_XPOS+169, GEN_MENU_YPOS+76,  "TRGL");//695 155 33
}
//==============================================================================
void gen_freq_select(void)
{  
  //buffer for text frequency
  char buffer[16];
   
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);
  
  //dark grey 
  display_fill_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+129, 92, 22, 2);//69-129-88-22-2//65 17na74 47 22      
  display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+129, 42, 22, 2);//692 56
      
  display_set_fg_color(GREEN_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+129, 92, 22, 2);
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+129, 42, 22, 2);//692 56

  //White normal text if in normal mode
  display_set_fg_color(WHITE_COLOR);

  make_freq_to_long_text(buffer, fpgasettings.gen_freq);
  display_text(GEN_MENU_XPOS + 68, GEN_MENU_YPOS + 132, buffer);

  //Display the normal text
  display_text(GEN_MENU_XPOS+169, GEN_MENU_YPOS+132, "1 kHz");//695 155 33
}
//==============================================================================
void gen_duty_select(void)
{  
  //buffer for text frequency
  char buffer[16];
   
  //Select the font for the texts
  display_set_font(&font_3);
  
     //extern uint32 a,b,c,d,e,f,g,h,i,j,k;

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);

  display_fill_rounded_rect(GEN_MENU_XPOS+90,  GEN_MENU_YPOS+185, 42, 22, 2);//69-129-88-22-2//65 17na74 47 22      
  display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+185, 42, 22, 2);//692 56
      
  display_set_fg_color(YELLOW_COLOR);
  //display_draw_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+185, 92, 22, 2);
  display_draw_rounded_rect(GEN_MENU_XPOS+90,  GEN_MENU_YPOS+185, 42, 22, 2);//65//90
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+185, 42, 22, 2);//692 56

  //White normal text if in normal mode
  display_set_fg_color(WHITE_COLOR);
    
    //fpgasettings.gen_duty = d;
    //fpga_set_generator_duty(fpgasettings.gen_duty);  //in Hz

  make_value_to_text(buffer, fpgasettings.gen_duty, '%');
  display_text(GEN_MENU_XPOS + 95, GEN_MENU_YPOS + 188, buffer);//70

  //Display the normal text
  display_text(GEN_MENU_XPOS+175, GEN_MENU_YPOS+188, "50%");//175
//display_text(GEN_MENU_XPOS+169, GEN_MENU_YPOS+132,  "1 kHz");//695 155 33
  
}
//==============================================================================
void gen_ampl_select(void)
{  
  //buffer for text frequency
  char buffer[16];
   
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);
                                //SINE
  //dark grey SQUARE and TRIANGLE
  display_fill_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+241, 92, 22, 2);//69-129-88-22-2//65 17na74 47 22      
  display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+241, 42, 22, 2);//692 56
      
  display_set_fg_color(RED_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+241, 92, 22, 2);
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+241, 42, 22, 2);//692 56

  //White normal text if in normal mode
  display_set_fg_color(WHITE_COLOR);
  
      //extern uint32 a,b,c,d,e,f,g,h,i,j,k;
  

  make_volt_to_long_text(buffer, fpgasettings.gen_ampl);
  //my_strcat(buffer, " V");
  display_text(GEN_MENU_XPOS + 80, GEN_MENU_YPOS + 244, buffer);//+3 //68 //80

  //Display the normal text
  display_text(GEN_MENU_XPOS+169, GEN_MENU_YPOS+244, "5.00V");//695 155 33
}
//==============================================================================
void gen_offset_select(void)
{  
  //buffer for text frequency
  char buffer[16];
   
  //Select the font for the texts
  display_set_font(&font_3);

  //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);
                                //SINE
  //dark grey SQUARE and TRIANGLE
  display_fill_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+297, 92, 22, 2);//69-129-88-22-2//65 17na74 47 22      
  display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+297, 42, 22, 2);//692 56
      
  display_set_fg_color(BLUE_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+297, 92, 22, 2);
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+297, 42, 22, 2);//692 56

  //White normal text if in normal mode
  display_set_fg_color(WHITE_COLOR);

        //extern uint32 a,b,c,d,e,f,g,h,i,j,k;
        //fpgasettings.gen_offset=f;
        
  make_volt_to_long_text(buffer, fpgasettings.gen_offset);
  //my_strcat(buffer, " V");
  display_text(GEN_MENU_XPOS + 80, GEN_MENU_YPOS + 300, buffer);//68-300

  //Display the normal text
  display_text(GEN_MENU_XPOS+169, GEN_MENU_YPOS+300,  "2.50V");//695 155 33
}
//==============================================================================
void gen_phase_select(void)
{  
  //buffer for text frequency
  char buffer[16];
   
  //Select the font for the texts
  display_set_font(&font_3);

    //Set dark grey color for the boxes behind the not selected texts
  display_set_fg_color(DARKGREY_COLOR);
                                //SINE
  //dark grey SQUARE and TRIANGLE
  display_fill_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+353, 92, 22, 2);//69-129-88-22-2//65 17na74 47 22      
  display_fill_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+353, 42, 22, 2);//692 56
      
  display_set_fg_color(ORANGE_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+65,  GEN_MENU_YPOS+353, 92, 22, 2);
  display_set_fg_color(GREY_COLOR);
  display_draw_rounded_rect(GEN_MENU_XPOS+165, GEN_MENU_YPOS+353, 42, 22, 2);//692 56

  //White normal text if in normal mode
  display_set_fg_color(WHITE_COLOR);

  //extern uint32 a,b,c,d,e,f,g,h,i,j,k;
  //fpgasettings.gen_phase=k;
      
  make_value_to_text(buffer, fpgasettings.gen_phase, 176); //176 is °
  //my_strcat(buffer, " p");
  display_text(GEN_MENU_XPOS + 100, GEN_MENU_YPOS + 356, buffer);//68 //85
  

  //Display the normal text
  display_text(GEN_MENU_XPOS+182, GEN_MENU_YPOS+356,  "0");//169//172
  display_character(GEN_MENU_XPOS+182+8, GEN_MENU_YPOS+356, 176);//-1 ma byt //198
  
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_system_settings_menu(void)
{
  int y;

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(SYSTEM_MENU_XPOS, SYSTEM_MENU_YPOS, SYSTEM_MENU_WIDTH, SYSTEM_MENU_HEIGHT);//353

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(SYSTEM_MENU_XPOS, SYSTEM_MENU_YPOS, SYSTEM_MENU_WIDTH, SYSTEM_MENU_HEIGHT);//353

  //Black lines between the settings
  display_set_fg_color(BLACK_COLOR);

  //for(y=SYSTEM_MENU_YPOS+58;y<SYSTEM_MENU_HEIGHT;y+=59)//350
  //{
  //  display_draw_horz_line(y, SYSTEM_MENU_XPOS+9, SYSTEM_MENU_HEIGHT-28);
  //}
  //v1.00s4: five rows (Display, X-Y mode display, Baseline calibration, RTC settings, Other settings)
  for(y=SYSTEM_MENU_YPOS+58;y<(SYSTEM_MENU_YPOS+SYSTEM_MENU_HEIGHT-1);y+=59)
  {
    display_draw_horz_line(y, SYSTEM_MENU_XPOS+9, SYSTEM_MENU_XPOS+SYSTEM_MENU_WIDTH-9);
  }

  //Display the menu items
  //scope_system_settings_screen_brightness_item(0);
  //scope_system_settings_grid_brightness_item(0);
  //scope_system_settings_trigger_50_item();
  //scope_system_settings_other_settings_item(0);
  //scope_system_settings_calibration_item(0);
  //scope_system_settings_x_y_mode_item(0);
  //scope_system_settings_confirmation_item(0);
  //scope_system_settings_RTC_settings_item(0);
  //v1.00s4: the brightness settings are in the Display panel, the notification confirmation in Other settings
  scope_system_settings_screen_brightness_item(0);     //row 0: Display
  scope_system_settings_x_y_mode_item(0);              //row 1
  scope_system_settings_calibration_item(0);           //row 2
  scope_system_settings_RTC_settings_item(0);          //row 3
  scope_system_settings_other_settings_item(0);        //row 4

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(SYSTEM_MENU_XPOS, SYSTEM_MENU_YPOS, SYSTEM_MENU_WIDTH, SYSTEM_MENU_HEIGHT, 63039);//353
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00s4: row 0 of the system settings menu is "Display", it opens the Display panel (screen brightness, grid brightness,
//transparent measurements). The function keeps its name for the existing callers.
void scope_system_settings_screen_brightness_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  display_fill_rounded_rect(SYSTEM_MENU_XPOS+9, 58, 226, 36, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icons with the set colors
  display_copy_icon_use_colors(screen_brightness_icon, SYSTEM_MENU_XPOS+21, 64, 24, 24);
  display_copy_icon_use_colors(Right_drop_menu_icon, SYSTEM_MENU_XPOS+202, 64, 24, 24);

  //Display the text
  display_set_font(&font_3);
  display_text(SYSTEM_MENU_XPOS+85, 68, "Display");
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00s4: the Display panel right of the system settings menu: two sliders with their labels, rows of 58 px from
//S_BRIGHTNESS_MENU_YPOS (v1.00s5: the transparent measurements switch moved to MEASURES)

static void scope_display_panel_label(uint16 ypos, const char *text, uint8 value)
{
  char buffer[16];

  //Clear the label line
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(S_BRIGHTNESS_MENU_XPOS + 8, ypos + 2, 315, 15);

  display_set_font(&font_2);
  display_set_fg_color(WHITE_COLOR);
  display_text(S_BRIGHTNESS_MENU_XPOS + 20, ypos + 3, (int8 *)text);

  //The value in a yellow box at the right
  display_set_fg_color(YELLOW_COLOR);
  display_fill_rounded_rect(S_BRIGHTNESS_MENU_XPOS + 275, ypos + 2, 36, 15, 2);
  make_value_to_text(buffer, value, '%');
  display_set_fg_color(BLACK_COLOR);
  display_text(S_BRIGHTNESS_MENU_XPOS + 277, ypos + 3, buffer);
}

void scope_display_panel_transparent_item(void)
{
  uint16 y = S_BRIGHTNESS_MENU_YPOS + 116;

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(S_BRIGHTNESS_MENU_XPOS + 8, y + 8, 315, 42);

  scope_display_slide_button(S_BRIGHTNESS_MENU_XPOS + 20, y + 18, scopesettings.transparentmeasures, GREEN_COLOR);

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(S_BRIGHTNESS_MENU_XPOS + 80, y + 19, "Transparent measurements");
}

void scope_open_display_panel(void)
{
  //Save the screen under the panel
  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(S_BRIGHTNESS_MENU_XPOS, S_BRIGHTNESS_MENU_YPOS, S_BRIGHTNESS_MENU_WIDTH, S_BRIGHTNESS_MENU_HEIGHT);

  //Draw it in a separate buffer to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(S_BRIGHTNESS_MENU_XPOS, S_BRIGHTNESS_MENU_YPOS, S_BRIGHTNESS_MENU_WIDTH, S_BRIGHTNESS_MENU_HEIGHT);
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rect(S_BRIGHTNESS_MENU_XPOS, S_BRIGHTNESS_MENU_YPOS, S_BRIGHTNESS_MENU_WIDTH, S_BRIGHTNESS_MENU_HEIGHT);

  //Black line between the rows
  display_set_fg_color(BLACK_COLOR);
  display_draw_horz_line(S_BRIGHTNESS_MENU_YPOS + 58, S_BRIGHTNESS_MENU_XPOS + 9, S_BRIGHTNESS_MENU_XPOS + S_BRIGHTNESS_MENU_WIDTH - 9);

  //Screen brightness and grid brightness sliders with their labels
  scope_display_slider(S_BRIGHTNESS_MENU_XPOS, S_BRIGHTNESS_MENU_YPOS, scopesettings.screenbrightness);
  scope_system_settings_screen_brightness_value();
  scope_display_slider(S_BRIGHTNESS_MENU_XPOS, S_BRIGHTNESS_MENU_YPOS + 58, scopesettings.gridbrightness);
  scope_system_settings_grid_brightness_value();

  //v1.00s5: the transparent measurements switch moved to MEASURES and the Measure tab of Other settings

  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_slide_left_rect_onto_screen(S_BRIGHTNESS_MENU_XPOS, S_BRIGHTNESS_MENU_YPOS, S_BRIGHTNESS_MENU_WIDTH, S_BRIGHTNESS_MENU_HEIGHT, 63039);
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00s4: the value is shown in the label of the Display panel (was a box in the system settings menu row)
void scope_system_settings_screen_brightness_value(void)
{
  scope_display_panel_label(S_BRIGHTNESS_MENU_YPOS, "Screen brightness", scopesettings.screenbrightness);
}

//----------------------------------------------------------------------------------------------------------------------------------

//Original screen brightness item and value (up to v1.00s3)
#if 0
void scope_system_settings_screen_brightness_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  display_fill_rounded_rect(SYSTEM_MENU_XPOS+9, 58, 226, 36, 3);//159 59 226 36 3

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {    
    //Set the icon to white sun
    scope_maxlight_item(0);
    //switch from max light to user set value
    scope_set_maxlight(0);
    
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(screen_brightness_icon, SYSTEM_MENU_XPOS+21, 64, 24, 24);

  //Display the text
  display_set_font(&font_3);
  display_text(231, 60, "Screen");
  display_text(220, 76, "brightness");

  //Show the actual setting
  scope_system_settings_screen_brightness_value();
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_screen_brightness_value(void)
{
  //buffer for text 
  char buffer[16];
  
  //Draw the yellow background
  display_set_fg_color(YELLOW_COLOR);
  display_fill_rounded_rect(328, 67, 36, 16, 2);   //font 2
  //display_fill_rounded_rect(325, 66, 54, 20, 2);    // font 5
  
  //convert number to text with %
  make_value_to_text(buffer, scopesettings.screenbrightness, '%');

  //Display the number with  black color
  display_set_font(&font_2);//5
  display_set_fg_color(BLACK_COLOR);
  display_text(330, 68, buffer); 
  //display_text(325, 64, buffer); //font 5
}

//----------------------------------------------------------------------------------------------------------------------------------

#endif

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_grid_brightness_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  display_fill_rounded_rect(SYSTEM_MENU_XPOS+9, 116, 226, 36, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(grid_brightness_icon, SYSTEM_MENU_XPOS+21, 122, 24, 24);

  //Display the text
  display_set_font(&font_3);
  display_text(240, 118, "Grid");
  display_text(220, 134, "brightness");

  //Show the actual setting
  scope_system_settings_grid_brightness_value();
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00s4: the value is shown in the label of the Display panel (was a box in the system settings menu row)
void scope_system_settings_grid_brightness_value(void)
{
  scope_display_panel_label(S_BRIGHTNESS_MENU_YPOS + 58, "Grid brightness", scopesettings.gridbrightness);
}

//Original grid brightness value (up to v1.00s3)
#if 0
void scope_system_settings_grid_brightness_value_old(void)
{
  //buffer for text 
  char buffer[16];
  
  //Draw the yellow background
  display_set_fg_color(YELLOW_COLOR);
  display_fill_rounded_rect(328, 124, 36, 16, 2);   //font 2
  //display_fill_rounded_rect(325, 123, 54, 20, 2);    // font 5
  
  //convert number to text with %
  make_value_to_text(buffer, scopesettings.gridbrightness, '%');

  //Display the number with  black color
  display_set_font(&font_2);//5
  display_set_fg_color(BLACK_COLOR);
  display_text(330, 125, buffer); 
  //display_text(325, 121, buffer); //font 5
}

//----------------------------------------------------------------------------------------------------------------------------------

#endif

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  //display_fill_rounded_rect(159, 174, 226, 38, 3);//401 36 
  //v1.00s4: row 4 (was row 2)
  display_fill_rounded_rect(SYSTEM_MENU_XPOS+9, SYSTEM_MENU_YPOS+246, 226, 38, 3);//401 36

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icon with the set colors
  //display_copy_icon_use_colors(RTC_icon, 171, 417, 24, 24);
    //Display the icon with the set colors
  //v1.00s5: the same icon as Settings in the main menu
  display_copy_icon_use_colors(Other_settings_icon, SYSTEM_MENU_XPOS+21, 299, 24, 24);//171
  display_copy_icon_use_colors(Right_drop_menu_icon, SYSTEM_MENU_XPOS+202, 299, 24, 24);//211

  //Display the text
  display_set_font(&font_3);
  display_text(235, 295, "Other");
  display_text(229, 311, "settings");
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00s4: layout of the Other settings menu: four groups, a heading of OS_HEADING_H px and items of OS_ITEM_H px each
static const int8 *os_group_names[OS_GROUPS] = { "Startup", "Operation", "Files & USB", "Service" };
static const uint8 os_group_first[OS_GROUPS + 1] = { OS_BOOT, OS_AUTOSETUP, OS_BMPTAG, OS_DCSHIFT, OS_TRANSPARENT };

static int os_group_of(int item)
{
  int g = 0;

  while((g < (OS_GROUPS - 1)) && (item >= os_group_first[g + 1]))
    g++;

  return(g);
}

int os_heading_y(int group)
{
  return(OTHER_MENU_YPOS + 4 + (group * OS_HEADING_H) + (os_group_first[group] * OS_ITEM_H));
}

int os_item_y(int item)
{
  int g = os_group_of(item);

  return(os_heading_y(g) + OS_HEADING_H + ((item - os_group_first[g]) * OS_ITEM_H));
}

//The item at a y position, -1 on a heading or outside the items
int os_item_at(int y)
{
  int i;

  for(i = 0; i < OS_TRANSPARENT; i++)
  {
    if((y >= os_item_y(i)) && (y < (os_item_y(i) + OS_ITEM_H)))
      return(i);
  }

  return(-1);
}

void scope_system_settings_open_other_settings_menu(void)
{
  int y;
  
  uint32 *ptr = STARTUP_CONFIG_ADDRESS; //Read boot config 
  boot_menu_start = ptr[0] & 0x07;      //choice 1 for fnirsi firmware, 0 for peco firmware, 2 for FEL mode, 4 view choice menu

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(OTHER_MENU_XPOS, OTHER_MENU_YPOS, OTHER_MENU_WIDTH, OTHER_MENU_HEIGHT);//150  46 244 353

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(OTHER_MENU_XPOS, OTHER_MENU_YPOS, OTHER_MENU_WIDTH, OTHER_MENU_HEIGHT);//46 413 353

  //Five black lines between the settings
  //display_set_fg_color(BLACK_COLOR);
  //for(y=OTHER_MENU_YPOS+46;y<OTHER_MENU_YPOS+OTHER_MENU_HEIGHT;y+=46)//+59
  //{
  //  display_draw_horz_line(y, OTHER_MENU_XPOS+9, OTHER_MENU_XPOS+OTHER_MENU_WIDTH-9);//1404 585//59 385 630
  //}
  (void)y;

  //v1.00s4: the items in four groups with a heading each (os_item_y / os_heading_y)
  for(y = 0; y < OS_GROUPS; y++)
  {
    display_set_font(&font_2);
    display_set_fg_color(0x00A0A0A0);
    display_text(OTHER_MENU_XPOS + 12, os_heading_y(y) + 3, (int8 *)os_group_names[y]);
    display_set_fg_color(0x00505050);
    display_draw_horz_line(os_heading_y(y) + 15, OTHER_MENU_XPOS + 9, OTHER_MENU_XPOS + OTHER_MENU_WIDTH - 9);
  }

  //Display the menu items
  scope_system_settings_other_settings_boot_menu_item();
  scope_system_settings_other_settings_default_start_item();
  scope_system_settings_other_settings_ref_on_start_item();
  scope_system_settings_other_settings_new_autosetup_item();
  scope_system_settings_other_settings_lock_cursor_item();
  scope_system_settings_other_settings_confirmation_item();
  scope_system_settings_other_settings_BMP_mark_item();
  scope_system_settings_other_settings_CH340_mode_item();
  scope_system_settings_other_settings_dc_shift_cal_item();
  scope_system_settings_other_settings_dev_mode_item();
  
  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(OTHER_MENU_XPOS, OTHER_MENU_YPOS, OTHER_MENU_WIDTH, OTHER_MENU_HEIGHT, 63039);//46 244 353
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_boot_menu_item(void)
{
  uint8 tmp;                  //for choice default start 
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_BOOT);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
  
  //Show the state (boot menu button mode)
  tmp=((boot_menu_start & 0x04)>>2);
  scope_display_slide_button(x+6, y+5, tmp, GREEN_COLOR);//588
  
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
   
  display_text(x+66, y+7, "Boot menu");     
  //display_text(x+57, 162, "Default start"); 
}

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_default_start_item(void)
{
  //uint8 tmp;                  //for choice default start
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_DEFSTART);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58

  //Add the button for BOOT Default start
  scope_boot_button(x+6, y+5);//588
    
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  display_text(x+66, y+7, "Default start"); 
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_new_autosetup_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_AUTOSETUP);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58

  //Show the state (autosetup button mode)
  scope_display_slide_button(x+6, y+5, scopesettings.new_autosetup, GREEN_COLOR);//588
  
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  display_text(x+66, y+7, "New autosetup");      //575 425
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_lock_cursor_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_LOCKCUR);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
  
  //Show the state (lock cursors move)
  scope_display_slide_button(x+6, y+5, scopesettings.lockcursors, GREEN_COLOR);//588
  
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);

  display_text(x+66, y+7, "Lock move cursors"); 
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_dc_shift_cal_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_DCSHIFT);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
        
  //Show the state (dc_shift_cal button mode)
  scope_display_slide_button(x+6, y+5, dc_shift_cal, GREEN_COLOR);//588
   
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  display_text(x+66, y+7, "DC shift calibration");     
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_CH340_mode_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_USBSERIAL);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
        
  //Show the state (dc_shift_cal button mode)
  scope_display_slide_button(x+6, y+5, USB_CH340, GREEN_COLOR);//588
   
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  //display_text(x+66, y+7, "USB CH340 mode");  
    display_text(x+66, y+7, "USB-Serial mode");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_dev_mode_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_DEVMODE);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
        
  //Show the state (dc_shift_cal button mode)
  scope_display_slide_button(x+6, y+5, dev_mode, RED_COLOR);//588
   
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  display_text(x+66, y+7, "Dev mode"); 
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_BMP_mark_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_BMPTAG);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
        
  //Show the state (dc_shift_cal button mode)
  scope_display_slide_button(x+6, y+5, tag_in_BMP, GREEN_COLOR);//588
   
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  display_text(x+66, y+7, "Add a tag to BMP"); 
}
//----------------------------------------------------------------------------------------------------------------------------------

//v1.00s4: Notification confirmation moved here from the system settings menu
void scope_system_settings_other_settings_confirmation_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_CONFIRM);

  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);

  //Show the state
  scope_display_slide_button(x+6, y+5, scopesettings.confirmationmode, GREEN_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);

  display_text(x+66, y+7, "Notify confirm");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_other_settings_ref_on_start_item(void)
{
  int x,y;
  x = OTHER_MENU_XPOS + 9;
  y = os_item_y(OS_REFSTART);    //v1.00s4: grouped layout
  
  //Inactive so dark grey background
  display_set_fg_color(DARKGREY_COLOR);

  //Draw the background
  display_fill_rounded_rect(x, y, OTHER_MENU_WIDTH-18, OS_ITEM_H-4, 3);//step 58
        
  //Show the state (ref_on_startup button)
  scope_display_slide_button(x+6, y+5, scopesettings.ref_on_startup, GREEN_COLOR);//588
   
  //Display the text
  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  
  display_text(x+66, y+7, "Load Ref on start"); 
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_calibration_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  //v1.00s4: row 2 (was row 3)
  display_fill_rounded_rect(SYSTEM_MENU_XPOS+9, 174, 226, 36, 3);//235

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(baseline_calibration_icon, SYSTEM_MENU_XPOS+21, 180, 24, 25);//239
  display_copy_icon_use_colors(Right_drop_menu_icon, SYSTEM_MENU_XPOS+202, 180, 24, 24);//211

  //Display the text
  display_set_font(&font_3);
  display_text(225, 176, "Baseline");
  display_text(219, 192, "calibration");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_x_y_mode_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Set the colors for white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);

    //Display the icon with the set colors
    //v1.00s4: row 1 (was row 4)
    display_copy_icon_use_colors(x_y_mode_display_icon, SYSTEM_MENU_XPOS+21, 122, 24, 24);//176//+21 299

    //Display the text
    display_set_font(&font_3);
    display_text(SYSTEM_MENU_XPOS+147, 118, "X-Y mode");//100//223
    display_text(SYSTEM_MENU_XPOS+155, 134, "display");//108//231
  }

  //Show the state
  scope_display_slide_button(SYSTEM_MENU_XPOS+70, 123, scopesettings.xymodedisplay, MAGENTA_COLOR);//+21//+176//326 299
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_confirmation_item(int mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Set the colors for white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);

    //Display the icon with the set colors
    display_copy_icon_use_colors(confirmation_icon, SYSTEM_MENU_XPOS+21, 358, 24, 24);//80//202 358

    //Display the text
    display_set_font(&font_3);
    display_text(SYSTEM_MENU_XPOS+142, 354, "Notification");//94//217
    display_text(SYSTEM_MENU_XPOS+138, 370, "confirmation");//90//213
  }

  //Show the state
  scope_display_slide_button(SYSTEM_MENU_XPOS+70, 359, scopesettings.confirmationmode, GREEN_COLOR);//+15 358
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_RTC_settings_item(int mode)//set
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark grey background
    display_set_fg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so yellow background
    display_set_fg_color(YELLOW_COLOR);
  }

  //Draw the background
  //v1.00s4: row 3 (was row 6)
  display_fill_rounded_rect(SYSTEM_MENU_XPOS+9, 233, 226, 38, 3);//401 36

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    //Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }

  //Display the icon with the set colors
  display_copy_icon_use_colors(RTC_icon, SYSTEM_MENU_XPOS+21, 240, 24, 24);//171
  display_copy_icon_use_colors(Right_drop_menu_icon, SYSTEM_MENU_XPOS+202, 240, 24, 24);//211
  

  //Display the text
  display_set_font(&font_3);
  display_text(241, 236, "RTC settings");       //250// 241 413
  display_text(213, 252, "Time & Date settings");//222//220 429
  
  //Read time for RTC
  get_fattime();
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_RTC_settings_menu(void)
{
  int y;

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(RTC_MENU_XPOS, RTC_MENU_YPOS, RTC_MENU_WIDTH, RTC_MENU_HEIGHT);//150  46 244 353

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(RTC_MENU_XPOS, RTC_MENU_YPOS, RTC_MENU_WIDTH, RTC_MENU_HEIGHT);//46 413 353

  //Five black lines between the settings
  display_set_fg_color(BLACK_COLOR);

  for(y=163;y<410;y+=59)//104 350
  {
    display_draw_horz_line(y, 404, 585);//159 385 630
  }

  //Display the menu items
  scope_system_settings_hour_item();
  scope_system_settings_minute_item();
  scope_system_settings_day_item();
  scope_system_settings_month_item();
  scope_system_settings_year_item();
  scope_system_settings_ONOFF_RTC_item();

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(RTC_MENU_XPOS, RTC_MENU_YPOS, RTC_MENU_WIDTH, RTC_MENU_HEIGHT, 63039);//46 244 353
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_hour_item(void)
{
  //Grey color for inactive button
  display_set_fg_color(GREY_COLOR);
  
  //Draw the body of the button < and >
  display_fill_rounded_rect(415, 115, 35, 35, 2);//739 5 51 50
  display_fill_rounded_rect(540, 115, 35, 35, 2);//739 5 51 50

  //Draw the edge
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(415, 115, 35, 35, 2);
  display_draw_rounded_rect(540, 115, 35, 35, 2);

  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(GREY_COLOR);
  
  //Display the icon with the set colors
  display_copy_icon_use_colors(Left_icon, 423, 120, 24, 24);
  display_copy_icon_use_colors(Right_icon, 544, 120, 24, 24);
  
  //Set the colors for white foreground and gray background
   display_set_bg_color(DARKGREY_COLOR);
   
  //Display the text
  display_set_font(&font_3);
  display_text(476, 119, "Hours");//475

  //Show the state
  scope_system_settings_hour_item_value();
}
void scope_system_settings_hour_item_value(void)
{
  //Draw the gray background
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(488, 136, 32, 15);
  
  //Set the colors for white foreground and gray background
  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(DARKGREY_COLOR);

   //Display the text
  display_set_font(&font_3);
  readnameRTC();
  display_decimal(488, 136, hour);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_minute_item(void)
{
  //Grey color for inactive button
  display_set_fg_color(GREY_COLOR);
  
  //Draw the body of the button < and >
  display_fill_rounded_rect(415, 174, 35, 35, 2);//739 5 51 50
  display_fill_rounded_rect(540, 174, 35, 35, 2);//739 5 51 50

  //Draw the edge
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(415, 174, 35, 35, 2);
  display_draw_rounded_rect(540, 174, 35, 35, 2);

  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(GREY_COLOR);
  
  //Display the icon with the set colors
  display_copy_icon_use_colors(Left_icon, 423, 179, 24, 24);
  display_copy_icon_use_colors(Right_icon, 544, 179, 24, 24);
  
  //Set the colors for white foreground and gray background
   display_set_bg_color(DARKGREY_COLOR);
   
  //Display the text
  display_set_font(&font_3);
  display_text(471, 178, "Minutes");//475

  //Show the state
  scope_system_settings_minute_item_value();
}
void scope_system_settings_minute_item_value(void)
{
  //Draw the gray background
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(488, 195, 32, 15);
  
  //Set the colors for white foreground and gray background
  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(DARKGREY_COLOR);

   //Display the text
  display_set_font(&font_3);
  readnameRTC();
  display_decimal(488, 195, minute);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_day_item(void)
{
  //Grey color for inactive button
  display_set_fg_color(GREY_COLOR);
  
  //Draw the body of the button < and >
  display_fill_rounded_rect(415, 233, 35, 35, 2);//739 5 51 50
  display_fill_rounded_rect(540, 233, 35, 35, 2);//739 5 51 50

  //Draw the edge
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(415, 233, 35, 35, 2);
  display_draw_rounded_rect(540, 233, 35, 35, 2);

  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(GREY_COLOR);
  
  //Display the icon with the set colors
  display_copy_icon_use_colors(Left_icon, 423, 238, 24, 24);
  display_copy_icon_use_colors(Right_icon, 544, 238, 24, 24);
  
  //Set the colors for white foreground and gray background
   display_set_bg_color(DARKGREY_COLOR);
   
  //Display the text
  display_set_font(&font_3);
  display_text(483, 237, "Day");//475

  //Show the state
  scope_system_settings_day_item_value();
}
void scope_system_settings_day_item_value(void)
{
  //Draw the gray background
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(488, 254, 32, 15);
  
  //Set the colors for white foreground and gray background
  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(DARKGREY_COLOR);

   //Display the text
  display_set_font(&font_3);
  readnameRTC();
  display_decimal(488, 254, day);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_month_item(void)
{
  //Grey color for inactive button
  display_set_fg_color(GREY_COLOR);
  
  //Draw the body of the button < and >
  display_fill_rounded_rect(415, 291, 35, 35, 2);//739 5 51 50
  display_fill_rounded_rect(540, 291, 35, 35, 2);//739 5 51 50

  //Draw the edge
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(415, 291, 35, 35, 2);
  display_draw_rounded_rect(540, 291, 35, 35, 2);

  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(GREY_COLOR);
  
  //Display the icon with the set colors
  display_copy_icon_use_colors(Left_icon, 423, 296, 24, 24);
  display_copy_icon_use_colors(Right_icon, 544, 296, 24, 24);
  
  //Set the colors for white foreground and gray background
   display_set_bg_color(DARKGREY_COLOR);
 
  //Display the text
  display_set_font(&font_3);
  display_text(475, 295, "Month");//241

  //Show the state
  scope_system_settings_month_item_value();
}
void scope_system_settings_month_item_value(void)
{
  //Draw the gray background
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(488, 312, 32, 15);
  
  //Set the colors for white foreground and gray background
  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(DARKGREY_COLOR);

   //Display the text
  display_set_font(&font_3);
  readnameRTC();
  display_decimal(488, 312, month);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_year_item(void)
{
  //Grey color for inactive button
  display_set_fg_color(GREY_COLOR);
  
  //Draw the body of the button < and >
  display_fill_rounded_rect(415, 350, 35, 35, 2);//739 5 51 50
  display_fill_rounded_rect(540, 350, 35, 35, 2);//739 5 51 50

  //Draw the edge
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(415, 350, 35, 35, 2);
  display_draw_rounded_rect(540, 350, 35, 35, 2);

  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(GREY_COLOR);
  
  //Display the icon with the set colors
  display_copy_icon_use_colors(Left_icon, 423, 355, 24, 24);
  display_copy_icon_use_colors(Right_icon, 544, 355, 24, 24);
  
  //Set the colors for white foreground and gray background
  display_set_bg_color(DARKGREY_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_text(481, 354, "Year");//241
  display_text(481, 371, "20");
  //Show the state
  scope_system_settings_year_item_value();
}
void scope_system_settings_year_item_value(void)
{
  //char buffer_time_date[]={'2','0','2','3',0}; 
     //Draw the gray background
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(495, 371, 32, 15);
  
  //Set the colors for white foreground and gray background
  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(DARKGREY_COLOR);

   //Display the text
  display_set_font(&font_3);
  readnameRTC();
  display_decimal(496, 371, year);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_system_settings_ONOFF_RTC_item(void)
{
  //Set the colors for white foreground and grey background
  display_set_fg_color(WHITE_COLOR);
  display_set_bg_color(DARKGREY_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_text(415, 420, "RTC On/Off");//410 241

  //Show the state
  scope_display_slide_button(530, 419, onoffRTC, GREEN_COLOR);
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00y4: ADC encode self-check of the 0x153F port (0x2050 EF2, 0x3050 AL3), lines at y 135 / 155 of the diagnostics
static void diag_port_adc_check(void)
{
  //v1.00x9: ADC encode self-check of 0x2050 (read 0x33): 0xF6 = all right; else which pins / the sticky error
  if(FPGA_IS_153F_PORT())
  {
    int32 c = fpga_read_encode_check();
    uint32 i;
    static const char *pins[4] = { "CH1B", "CH1A", "CH2B", "CH2A" };

    display_set_fg_color(YELLOW_COLOR);
    //v1.00y0: shorter, the result apart from the value and left of the line at x 515
    display_text(330, 135, "ADC check:");
    display_set_fg_color(WHITE_COLOR);
    display_hex(420, 135, 2, (uint32)c);

    if(c == 0xF6)
    {
      display_set_fg_color(GREEN_COLOR);
      display_text(465, 135, "OK");
    }
    else
    {
      display_set_fg_color(RED_COLOR);
      display_text(465, 135, (c & 0x01) ? "ERR" : "CHECK");

      //Pins that failed the last check
      for(i = 0; i < 4; i++)
      {
        if(!(c & (0x10 << i)))
          display_text(330 + (i * 45), 155, (int8 *)pins[i]);
      }
    }
  }

  //v1.00y9: streaming logger test (20 ms at 1 Mword/s, about 20000 words expected): the roll mode needs it
  if(FPGA_IS_153F_PORT())
  {
    int32 w = fpga_logger_selftest();

    display_set_fg_color(YELLOW_COLOR);
    display_text(330, 175, "Logger:");
    display_set_fg_color(WHITE_COLOR);
    display_decimal(390, 175, (w > 0) ? w : 0);
    display_set_fg_color((w > 1000) ? GREEN_COLOR : RED_COLOR);
    display_text(460, 175, (w > 1000) ? "OK" : "ERR");
  }
}

void scope_open_diagnostic_view(void)
{
  //Setup the menu in a separate buffer to be able to slide it onto the screen
  //display_set_screen_buffer(displaybuffertmp);
  //******************************************
//  uint32 *ptr = STARTUP_CONFIG_ADDRESS; //for diagnostic menu  
//  boot_menu_start = ptr[0] & 0x07;  //choice 1 for fnirsi firmware, 0 for peco firmware, 2 for FEL mode, 4 view choice menu
        
  const uint16    a=20;     //280
  const uint16    b=100;    //360
  const uint16    c=200;    //460
  const uint16    d=b+40;
  //y
  const uint16    i=65; //40
  const uint16    j=225;//200
  //const uint16    k=328;//385
  
  uint16    b1;
  uint8    temp;
  //uint8    tmp;
  
  //Clear the whole screen
  display_set_fg_color(BLACK_COLOR);
  //display_fill_rect(265, 0, 535, 480);//400
  display_fill_rect(0, 0, 800, 480);//400
  
  //Draw the edge
  display_set_fg_color(WHITE_COLOR);
  display_draw_rect(0, 0, 800, 480); 
  display_draw_rounded_rect(10, 10, 780, 460, 3);  //4
  display_draw_rounded_rect(11, 11, 778, 458, 3);  //4
  //  display_draw_rounded_rect(270, 10, 520, 460, 3);  //4
  //display_draw_rounded_rect(271, 11, 518, 458, 3);  //4
  //display_draw_vert_line(575, 10, 468);
  display_draw_vert_line(315, 10, 468);
  display_draw_vert_line(515, 10, 468);
  
  display_draw_horz_line(350, 10, 315);
  
  
  //Display the text with the green color
  display_set_fg_color(GREEN_COLOR);
  display_set_font(&font_3);
  display_text(a, 20, VERSION_STRING);  //c//460      //Show version information 
  
  //Display the temperature with darkgreen color
  //display_set_font(&font_3);
  display_set_fg_color(DARKGREEN_COLOR);
  display_text(b, 20, "Temperature");//j+135
  
  //Display the text with the white color
  display_set_fg_color(WHITE_COLOR);
  
  //display_text(85, 375, "Adjustment of calibration data"); //335 390
  //display_text(120, 375, "Reset or restore of calibration data"); //x70 //335 390
  display_text(37, 385, "Settings"); //x70 //335 390
  display_text(160, 370, "Reset or restore"); //x70 //335 390
  display_text(150, 385, "of calibration data"); //x70 //335 390
  
  /*
  display_text(k+57, 42,  "New autosetup");      //575 425
  display_text(k+57, 82,  "DC shift calibration");     
  display_text(k+57, 122, "Boot menu");     
  display_text(k+57, 162, "Default start"); 
  display_text(k+57, 202, "Lock move cursors"); 
  */
    
  temp = readtemperature();
  
  //Display sign (-)
  if (!(temp & 0x80)) b1=c; else {b1=c+10; display_text(c, 20, "-");}
  
  display_decimal(b1, 20, temp & 0x7F);
  display_text(b1+20, 20, "C"); 
 /* 
  //Display the text with font 3 and the red color
  display_set_fg_color(RED_COLOR);
  display_set_font(&font_3);
  
  //display_text(435, 414, "Reset calibration values !!!");
  display_text(473, 390, "RESET");                      //670 260
  //display_text(320, 425, "calibration values !!!");     //630 220
  
  display_set_fg_color(DARKGREEN_COLOR);
  display_text(363, 390, "RESTORE"); 
 */ 
  
  //display_text(435, 414, "Reset calibration values !!!");
          //display_text(75, 390, "Please run BASE CALIBRATION !!!"); //335 390 
          //display_text(435, 414, "Reset calibration values !!!");
          //display_text(77, 380, "Adjustment of calibration data"); //335 390 
          
  //Display the text with the channel1 color
  display_set_fg_color(CHANNEL1_COLOR);
  display_text(a, i-20, "Channel 1");//b
  

  display_decimal(a +  80, i-20, scopesettings.trigger_A);
  display_decimal(a + 120, i-20, scopesettings.trigger_B);
  
  //Display the text with the channel2 color
  display_set_fg_color(CHANNEL2_COLOR);
  display_text(a, j-20, "Channel 2");//b
  
  
  display_set_fg_color(DARKGREEN_COLOR);
  display_text(a, i, "ADc comp"); 
  display_set_fg_color(RED_COLOR);
  display_text(a, i+30, "DC offset");
  display_set_fg_color(ORANGE_COLOR);
  display_text(a, i+60, "DC shift"); 
    
  //Display the text with the white color
  display_set_fg_color(WHITE_COLOR);
  display_decimal(a, i+15, scopesettings.channel1.adc1compensation);
  display_decimal(a+40, i+15, scopesettings.channel1.adc2compensation);
  display_decimal(a, i+45, scopesettings.channel1.dcoffset);
  display_decimal(a, i+75, scopesettings.channel1.dc_shift_center); 
  display_decimal(a, i+90, scopesettings.channel1.dc_shift_size); 
  display_decimal(a, i+105, scopesettings.channel1.dc_shift_value); 
  
  display_set_fg_color(DARKGREEN_COLOR);  
  display_text(a, j, "ADc comp"); 
  display_set_fg_color(RED_COLOR); 
  display_text(a, j+30, "DC offset");  
  display_set_fg_color(ORANGE_COLOR);
  display_text(a, j+60, "DC shift"); 
  
  //Display the text with the white color
  display_set_fg_color(WHITE_COLOR);    
  display_decimal(a, j+15, scopesettings.channel2.adc1compensation);
  display_decimal(a+40, j+15, scopesettings.channel2.adc2compensation);
  display_decimal(a, j+45, scopesettings.channel2.dcoffset);
  display_decimal(a, j+75, scopesettings.channel2.dc_shift_center); 
  display_decimal(a, j+90, scopesettings.channel2.dc_shift_size); 
  display_decimal(a, j+105, scopesettings.channel2.dc_shift_value);  
  
  display_set_fg_color(ORANGE_COLOR);
  display_text(b, i, "Offset");  
  display_text(c, i, "Calibration input"); 
  //Display the text with the white color
  display_set_fg_color(WHITE_COLOR);
  display_decimal(b, i+15, scopesettings.channel1.dc_calibration_offset[0]);
  display_text(d, i+15, "5V");     
  display_decimal(b, i+30, scopesettings.channel1.dc_calibration_offset[1]);
  display_decimal(b, i+45, scopesettings.channel1.dc_calibration_offset[2]);
  display_decimal(b, i+60, scopesettings.channel1.dc_calibration_offset[3]);
  display_decimal(b, i+75, scopesettings.channel1.dc_calibration_offset[4]);
  display_decimal(b, i+90, scopesettings.channel1.dc_calibration_offset[5]);
  display_decimal(b, i+105, scopesettings.channel1.dc_calibration_offset[6]);
  display_text(d, i+105, "50mV");
      
  
  display_decimal(c, i+15, scopesettings.channel1.input_calibration[0]);
  display_decimal(c, i+30, scopesettings.channel1.input_calibration[1]);
  display_decimal(c, i+45, scopesettings.channel1.input_calibration[2]);
  display_decimal(c, i+60, scopesettings.channel1.input_calibration[3]);
  display_decimal(c, i+75, scopesettings.channel1.input_calibration[4]);
  display_decimal(c, i+90, scopesettings.channel1.input_calibration[5]);
  display_decimal(c, i+105, scopesettings.channel1.input_calibration[6]);
      
  display_set_fg_color(ORANGE_COLOR);    
  display_text(b, j, "Offset");  
  display_text(c, j, "Calibration input");    //130 bolo
  //Display the text with the white color
  display_set_fg_color(WHITE_COLOR);
  display_decimal(b, j+15, scopesettings.channel2.dc_calibration_offset[0]);
  display_text(d, j+15, "5V"); 
  display_decimal(b, j+30, scopesettings.channel2.dc_calibration_offset[1]);
  display_decimal(b, j+45, scopesettings.channel2.dc_calibration_offset[2]);
  display_decimal(b, j+60, scopesettings.channel2.dc_calibration_offset[3]);
  display_decimal(b, j+75, scopesettings.channel2.dc_calibration_offset[4]);
  display_decimal(b, j+90, scopesettings.channel2.dc_calibration_offset[5]);
  display_decimal(b, j+105, scopesettings.channel2.dc_calibration_offset[6]);
  display_text(d, j+105, "50mV");
 
      
  display_decimal(c, j+15, scopesettings.channel2.input_calibration[0]);
  display_decimal(c, j+30, scopesettings.channel2.input_calibration[1]);
  display_decimal(c, j+45, scopesettings.channel2.input_calibration[2]);
  display_decimal(c, j+60, scopesettings.channel2.input_calibration[3]);
  display_decimal(c, j+75, scopesettings.channel2.input_calibration[4]);
  display_decimal(c, j+90, scopesettings.channel2.input_calibration[5]);
  display_decimal(c, j+105, scopesettings.channel2.input_calibration[6]);
/*
  //Display the text with the green color
  display_set_fg_color(GREEN_COLOR);
  display_text(c, j+135, "Xtouch");
  display_decimal(c+60, j+135, xtouch);
  display_text(c, j+150, "Ytouch");
  display_decimal(c+60, j+150, ytouch);
 */
  
  //Add the button for DEFAULT
  scope_default_button(30, 410, 0);   
  
  //Add the button for RESTORE
  scope_restore_button(130, 410, 0);   //b=100 //360 410 //350 410
          
  //Add the button for RESET
  scope_reset_button(230, 410, 0);    //c=200 //460 400
  /*
  //Show the state (autosetup button mode)
  scope_display_slide_button(k, 40, scopesettings.new_autosetup, GREEN_COLOR);//588
        
  //Show the state (dc_shift_cal button mode)
  scope_display_slide_button(k, 80, dc_shift_cal, GREEN_COLOR);//588
  
  //Show the state (boot menu button mode)
  tmp=((boot_menu_start & 0x04)>>2);
  scope_display_slide_button(k, 120, tmp, GREEN_COLOR);//588

  //Add the button for BOOT Default start
  scope_boot_button(k, 160);//588 //0
  
  //Show the state (lock cursors move)
  scope_display_slide_button(k, 200, scopesettings.lockcursors, GREEN_COLOR);//588
  */
  display_set_fg_color(DARKGREEN_COLOR);
  display_text(330, 20, "Total samples:");//j+135
  display_set_fg_color(WHITE_COLOR);
  display_decimal(430, 20, scopesettings.samplecount);
  
  display_set_fg_color(YELLOW_COLOR);
  display_text(330, 40, "FPGA version:");//j+135
  
  display_set_fg_color(WHITE_COLOR);
  display_hex(430, 40, 4, fpga_get_version());
  
  if(fpgasettings.fw_FPGA == 1) 
  { 
    display_text(430, 60, "fw: Fnirsi");
    fpgasettings.totalsamples = 3000; 
    scopesettings.samplecount = fpgasettings.totalsamples;
    scopesettings.nofsamples = fpgasettings.totalsamples/2;
    fpgasettings.settriggerpoint = 1500;
    
    display_set_fg_color(ORANGE_COLOR);
    display_text(330, 80,  "Total samples set to 3000");//j+135
    display_text(330, 100, "Trigger point set to   50%");//j+135
  }
  
  if(fpgasettings.fw_FPGA == 2) 
  { 
    display_text(430, 60, "fw: PECO");
    display_set_fg_color(BLUE_COLOR);
    //display_text(430, 80, "EF2-L45");
    //v1.00x3: the port of 0x153F (0x2050 and later) has 8192 words
    //display_text(430, 80, FPGA_IS_153F_PORT() ? "EF2-L45 (153F port, 8192)" : "EF2-L45");
    //display_text(430, 80, FPGA_IS_153F_PORT() ? "EF2-L45, 0x153F port" : "EF2-L45");
    display_text(430, 80, "EF2-L45");     //v1.00y0: "0x153F port" removed (too long, the version says it)

    //fpgasettings.totalsamples = 12000;
    //scopesettings.samplecount = fpgasettings.totalsamples;
    //scopesettings.nofsamples = fpgasettings.totalsamples/2;

    //display_set_fg_color(ORANGE_COLOR);
    //display_text(330, 110,  "Total samples MAX 12000");//j+135

    //v1.00x4: the real memory of this FPGA: a word holds the A and B core sample, so two samples per word
    //(0x2000: 6144 words = 12288 samples, record max 12000; 0x2050: 8192 words = 16384 samples, record max 16000).
    //The record length is no longer forced to 12000 here, only shortened when it does not fit.
    fpga_limit_record_length();

    display_set_fg_color(ORANGE_COLOR);
    //display_text(330, 110, FPGA_IS_153F_PORT() ? "Memory 8192 words = 16384 samples" : "Memory 6144 words = 12288 samples");
    //display_text(330, 130, FPGA_IS_153F_PORT() ? "Record length MAX 16000" : "Record length MAX 12000");
    //v1.00y0: only the record length (the memory line removed)
    display_text(330, 110, FPGA_IS_153F_PORT() ? "Record length MAX 16000" : "Record length MAX 12000");

    //v1.00y4: the ADC check of the 0x153F port (shared with AL3), see diag_port_adc_check below
    diag_port_adc_check();
  }
  
  if(fpgasettings.fw_FPGA == 3) 
  { 
    display_text(430, 60, "fw: PECO");
    display_set_fg_color(BLUE_COLOR);
    display_text(430, 80, "AL3-A10");
    
    //fpgasettings.totalsamples = 9000; 
    //scopesettings.samplecount = fpgasettings.totalsamples;
    //scopesettings.nofsamples = fpgasettings.totalsamples/2;

    //display_set_fg_color(ORANGE_COLOR);
    //display_text(330, 110,  "Total samples MAX 15000");//j+135

    //v1.00y4: as EF2: the record length (8192 words = 16384 samples) and, for the 0x153F port (0x3050), the ADC check
    fpga_limit_record_length();
    display_set_fg_color(ORANGE_COLOR);
    display_text(330, 110, "Record length MAX 16000");
    diag_port_adc_check();
  }
  
  if(fpgasettings.fw_FPGA == 4) 
  { 
    display_text(430, 60, "fw: PECO");
    display_set_fg_color(BLUE_COLOR);
    display_text(430, 80, "EP4CE06");
  }
    
  //display_decimal(430, 40, scopesettings.samplecount);
  
  //Add the button for EXIT
  scope_exit_button(710, 410, 0);
  
  //*********************************************************
  /*
  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  //display_slide_left_rect_onto_screen(150, 46, 244, 413, 63039);//353
  display_slide_left_rect_onto_screen(265, 0, 535, 480, 63039);//353
*/
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_calibration_start_text(void)
{
  //Save the screen under the baseline calibration start text
  display_set_destination_buffer(displaybuffer3);//2
  display_copy_rect_from_screen(CALIBRATION_MENU_XPOS, CALIBRATION_MENU_YPOS, CALIBRATION_MENU_WIDTH, CALIBRATION_MENU_HEIGHT);

  //Setup the text in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in yellow //white
  display_set_fg_color(YELLOW_COLOR);
  display_fill_rounded_rect(CALIBRATION_MENU_XPOS, CALIBRATION_MENU_YPOS, CALIBRATION_MENU_WIDTH, CALIBRATION_MENU_HEIGHT, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(CALIBRATION_MENU_XPOS, CALIBRATION_MENU_YPOS, CALIBRATION_MENU_WIDTH, CALIBRATION_MENU_HEIGHT, 3);

  //Display the text in white
  display_set_fg_color(RED_COLOR);
  display_set_font(&font_3);
  display_text(409, 227, "Please unplug");
  display_text(410, 243, "the probe and");
  display_text(424, 259, "USB first !");    //409

  //Add the ok button
  scope_display_ok_button(517, 230, 0);

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);//1
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(CALIBRATION_MENU_XPOS, CALIBRATION_MENU_YPOS, CALIBRATION_MENU_WIDTH, CALIBRATION_MENU_HEIGHT, 63039);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_show_calibrating_text(void)
{
  //Restore the screen from under the calibration start text to get rid of it
  display_set_source_buffer(displaybuffer3);//2
  display_copy_rect_to_screen(CALIBRATION_MENU_XPOS, CALIBRATION_MENU_YPOS, CALIBRATION_MENU_WIDTH, CALIBRATION_MENU_HEIGHT);

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 109, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 110, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  //display_text(409, 243, "Calibrating...");
  display_text(409, 233, "Calibrating...");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_show_calibration_done_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 109, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 110, 59, 3);

  //Display the text in green
  display_set_fg_color(GREEN_COLOR);
  display_set_font(&font_3);
  
  //scope_save_input_calibration_data();
          
  display_text(414, 233, "Calibration");
  display_text(416, 255, "successful");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_show_calibration_fail(void)
{
  //Draw the background in white
  display_set_fg_color(WHITE_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);//199 59

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in red
  display_set_fg_color(RED_COLOR);
  display_set_font(&font_3);
  
  display_text(420, 233, "Offset calibration failed");
  display_text(445, 255, "Check hardware");
}

//-*********************************************************************************
void scope_show_Input_calibration(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);//199 59

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  //display_text(435, 235, "Input");
  display_text(405, 233, "Input CH1 & CH2");
  display_text(421, 255, "calibration");
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

//-----------------------------------------------------

void scope_show_calibrating_300mV_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(413, 233, "Set 300mV DC");//100mV/div 425 -12
  display_text(416, 255, "and press OK");
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

//----------------------------------------------------------------------------------------------------------------------------------
void scope_show_calibrating_600mV_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(413, 233, "Set 600mV DC");//200mV/div 440
  display_text(416, 255, "and press OK");
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

//----------------------------------------------------------------------------------------------------------------------------------
void scope_show_calibrating_1_5V_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(420, 233, "Set 1.5V DC");//500mV/div 430
  display_text(416, 255, "and press OK");
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------
void scope_show_calibrating_3V_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(425, 233, "Set 3V DC");  //3V/div
  display_text(416, 255, "and press OK");
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_show_calibrating_7_5V_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(420, 233, "Set 7.5V DC");//2.5V/div 235
  display_text(416, 255, "and press OK");//252
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

void scope_show_calibrating_15V_text(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  display_text(422, 233, "Set 15V DC");//5V/div
  display_text(416, 255, "and press OK");
  
  //Add the ok button
  scope_display_ok_button(517, 230, 0);
}

void scope_show_Input_calibration_done(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in green
  display_set_fg_color(GREEN_COLOR);
  display_set_font(&font_3);
  
  display_text(425, 233, "Calibration successful");
  display_set_fg_color(RED_COLOR);
  display_text(455, 255, "Please restart");
}

void scope_show_Input_calibration_fail(void)
{
  //Draw the background in white
  display_set_fg_color(WHITE_COLOR);
  display_fill_rounded_rect(395, 222, 198, 58, 3);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);
  display_draw_rounded_rect(395, 222, 199, 59, 3);

  //Display the text in red
  display_set_fg_color(RED_COLOR);
  display_set_font(&font_3);
  
  display_text(440, 233, "Calibration failed");//435
  //display_text(470, 255, "Try again");//475
  display_text(437, 255, "PLS Reset values !");//475
}

//-*******************************************************************************
//----------------------------------------------------------------------------------------------------------------------------------
/*
void scope_open_t_cursor_menu(void)
{
  //int item;
  //int channel;

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(677, 185, 50, 50);

  //Draw the edge in black
  //display_set_fg_color(BLACK_COLOR);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rect(677, 185, 50, 50);
  
  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_right_rect_onto_screen(677, 185, 50, 50, 46);//449
}
*/
//----------------------------------------------------------------------------------------------------------------------------------
/*
void scope_open_v_cursor_menu(void)
{
  //int item;
  //int channel;

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(677, 245, 50, 50);

  //Draw the edge in black
  //display_set_fg_color(BLACK_COLOR);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rect(677, 245, 50, 50);
  
  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_right_rect_onto_screen(677, 245, 50, 50, 46);//449
}
*/
//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_measures_menu(void)
{
  int item;
  int channel;

  //Setup the menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);//1

  //v1.00s5: a strip above the menu with the transparent measurements switch (y 202..231)
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(232, MEASURES_STRIP_Y, 499, 30);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rect(232, MEASURES_STRIP_Y, 499, 31);
  scope_measures_transparent_item();

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(232, 232, 499, 246);//231-263-501-215 //499

  //Draw the edge in black
  //display_set_fg_color(BLACK_COLOR);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rect(232, 232, 499, 246);//499

  //Three horizontal black lines between the settings y, x, long
  display_set_fg_color(BLACK_COLOR);
  //display_set_fg_color(WHITE_COLOR);
  display_draw_horz_line(264, 233, 728); 
  display_draw_horz_line(296, 233, 728);
  display_draw_horz_line(356, 233, 728);
  display_draw_horz_line(416, 233, 728);
  
  scope_source1_measures_menu_item();
  scope_source2_measures_menu_item();
  
  //If hide measures menu item is active change color Hide bar CH1 & CH2
  //scopesettings.measures_color1 = CHANNEL1_COLOR;
  //scope_hide_measures_menu_item();

  //Vertical separator between the channel sections
  //Draw the edge in white
  //display_set_fg_color(ORANGE_COLOR);
  display_set_fg_color(WHITE_COLOR);
  display_draw_vert_line(480, 232, 476);
  display_draw_vert_line(481, 232, 476);

  //Vertical separators between the items
  //Draw the edge in black
  display_set_fg_color(BLACK_COLOR);
  display_draw_vert_line(294, 233, 475);//294 289 476
  display_draw_vert_line(356, 233, 475);
  display_draw_vert_line(418, 233, 475);
  display_draw_vert_line(544, 233, 475);
  display_draw_vert_line(606, 233, 475);
  display_draw_vert_line(668, 233, 475);


  //Display the menu items
  for(channel=0;channel<2;channel++)
  {
    //For each channel 12 items
    for(item=0;item<12;item++)
    {
      //Draw the separate items
      scope_measures_menu_item(channel, item);
    }
  }

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  //display_slide_right_rect_onto_screen(232, 232, 499, 246, 75646);//449
  display_slide_right_rect_onto_screen(232, MEASURES_STRIP_Y, 499, 276, 75646);   //v1.00s5: with the strip on top
}

//v1.00s5: the transparent measurements switch in the strip above the measures menu
void scope_measures_transparent_item(void)
{
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(233, MEASURES_STRIP_Y + 1, 497, 29);

  scope_display_slide_button(244, MEASURES_STRIP_Y + 4, scopesettings.transparentmeasures, GREEN_COLOR);

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(300, MEASURES_STRIP_Y + 7, "Transparent measurements");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_source1_measures_menu_item(void)
{
  //Draw the background in dark gray
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(233, 265, 61, 31); //Channel 1 item
  display_fill_rect(233, 233, 61, 31);
  display_fill_rect(295, 233, 61, 31);
  display_fill_rect(357, 233, 61, 31);
  display_fill_rect(419, 233, 61, 31);
  
switch (scopesettings.source1_measures)
{
  case 0:
    scopesettings.measures_color1 = CHANNEL1_COLOR;
    display_set_fg_color(scopesettings.measures_color1);
    display_fill_rect(233, 265, 61, 31); //Channel 1 item
    break;
  case 1:
    scopesettings.measures_color1 = scopesettings.ch_ref1.color;
    display_set_fg_color(scopesettings.measures_color1);
    display_fill_rect(233, 233, 61, 31);
    break;
  case 2:
    scopesettings.measures_color1 = scopesettings.ch_ref2.color;
    display_set_fg_color(scopesettings.measures_color1);
    display_fill_rect(295, 233, 61, 31);
    break;
  case 3:
    scopesettings.measures_color1 = scopesettings.ch_ref3.color;
    display_set_fg_color(scopesettings.measures_color1);
    display_fill_rect(357, 233, 61, 31);
    break;
  case 4:
    scopesettings.measures_color1 = scopesettings.ch_ref4.color;
    display_set_fg_color(scopesettings.measures_color1);
    display_fill_rect(419, 233, 61, 31);
    break;
  default:
    scopesettings.measures_color1 = CHANNEL1_COLOR;
    display_set_fg_color(scopesettings.measures_color1);
    display_fill_rect(233, 265, 61, 31); //Channel 1 item
    break;
}
  //Select all_1 item 
  display_fill_rect(295, 265, 61, 31);
  //Clear_1 item
  display_fill_rect(357, 265, 61, 31);
   
  display_set_font(&font_2);
  display_set_fg_color(GREY_COLOR);
  display_text(253, 273, "CH1");
  display_text(250, 242, "Ref 1");
  display_text(312, 242, "Ref 2");
  display_text(374, 242, "Ref 3");
  display_text(436, 242, "Ref 4");
  
  //Display the channel identifier text in black
  display_set_fg_color(BLACK_COLOR);
  display_text(300, 273, "Select All");
  display_text(375, 273, "Clear");  
  
  if(scopesettings.source1_measures == 0) display_text(253, 273, "CH1");
  if(scopesettings.source1_measures == 1) display_text(250, 242, "Ref 1");
  if(scopesettings.source1_measures == 2) display_text(312, 242, "Ref 2"); 
  if(scopesettings.source1_measures == 3) display_text(374, 242, "Ref 3");
  if(scopesettings.source1_measures == 4) display_text(436, 242, "Ref 4");
  
  //If hide measures menu item is active change color Hide bar CH1 & CH2
  scope_hide_measures_menu_item();  //change source color of button
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_source2_measures_menu_item(void)
{
  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);
  
  display_fill_rect(482, 265, 62, 31);//246
  display_fill_rect(482, 233, 62, 31);
  display_fill_rect(545, 233, 61, 31);
  display_fill_rect(607, 233, 61, 31);
  display_fill_rect(669, 233, 61, 31);
  
switch (scopesettings.source2_measures)
{
  case 0:
    scopesettings.measures_color2 = CHANNEL2_COLOR;
    display_set_fg_color(scopesettings.measures_color2);
    display_fill_rect(482, 265, 62, 31); //Channel 2 item
    break;
  case 1:
    scopesettings.measures_color2 = scopesettings.ch_ref5.color;
    display_set_fg_color(scopesettings.measures_color2);
    display_fill_rect(482, 233, 62, 31);
    break;
  case 2:
    scopesettings.measures_color2 = scopesettings.ch_ref6.color;
    display_set_fg_color(scopesettings.measures_color2);
    display_fill_rect(545, 233, 61, 31);
    break;
  case 3:
    scopesettings.measures_color2 = scopesettings.ch_ref7.color;
    display_set_fg_color(scopesettings.measures_color2);
    display_fill_rect(607, 233, 61, 31);
    break;
  case 4:
    scopesettings.measures_color2 = scopesettings.ch_ref8.color;
    display_set_fg_color(scopesettings.measures_color2);
    display_fill_rect(669, 233, 61, 31);
    break;
  default:
    scopesettings.measures_color2 = CHANNEL2_COLOR;
    display_set_fg_color(scopesettings.measures_color2);
    display_fill_rect(482, 265, 62, 31); //Channel 1 item
    break;
}
  //Select all_2
  display_fill_rect(545, 265, 61, 31);
  //Clear_2 item
  display_fill_rect(607, 265, 61, 31);
  
  display_set_font(&font_2);
  display_set_fg_color(GREY_COLOR);
  display_text(503, 273, "CH2");
  display_text(499, 242, "Ref 5");
  display_text(562, 242, "Ref 6");
  display_text(624, 242, "Ref 7");
  display_text(686, 242, "Ref 8");
    
  //Display the channel identifier text in black
  display_set_fg_color(BLACK_COLOR);
  display_text(550, 273, "Select All");
  display_text(625, 273, "Clear");  //623 

  if(scopesettings.source2_measures == 0) display_text(503, 273, "CH2");
  if(scopesettings.source2_measures == 1) display_text(499, 242, "Ref 5");
  if(scopesettings.source2_measures == 2) display_text(562, 242, "Ref 6");
  if(scopesettings.source2_measures == 3) display_text(624, 242, "Ref 7");
  if(scopesettings.source2_measures == 4) display_text(686, 242, "Ref 8");
  
  //If hide measures menu item is active change color Hide bar CH1 & CH2
  scope_hide_measures_menu_item();  //change source color of button
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_hide_measures_menu_item(void)
{
  //Channel 1 HIDE top bar
  if( scopesettings.hide_values_CH1) display_set_fg_color(RED_COLOR); else display_set_fg_color(scopesettings.measures_color1);
  display_fill_rect(419, 265, 61, 31);

  //Channel 2 HIDE top bar
  if( scopesettings.hide_values_CH2) display_set_fg_color(RED_COLOR); else display_set_fg_color(scopesettings.measures_color2);
  display_fill_rect(669, 265, 61, 31);   
  
  //Display text Hide in black
  display_set_fg_color(BLACK_COLOR);
  display_set_font(&font_2);
  display_text(438, 273, "Hide");  
  display_text(690, 273, "Hide");     
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_measures_menu_item(int channel, int item)
{
  uint16  xpos;
  uint16  ypos;
  char   *text;

  //Set the x position offset for the given channel
  if(channel == 0)
  {
    //Channel 1 is on the left side
    xpos = 232;
  }
  else
  {
    //Channel 2 is on the right side
    xpos = 482;
  }

  //Set the text and the position for the given item
  switch(item)
  {
    case 0:
      text  = "Vmax";
      xpos += 15;
      ypos  = 316;
      break;

    case 1:
      text  = "Vmin";
      xpos += 79;
      ypos  = 316;
      break;

    case 2:
      text  = "Vavg";
      xpos += 141;
      ypos  = 316;
      break;

    case 3:
      text  = "Vrms";
      xpos += 203;
      ypos  = 316;
      break;

    case 4:
      text  = "Vpp";
      xpos += 19;
      ypos  = 376;
      break;

    case 5:
      text  = "Vp";
      xpos += 86;
      ypos  = 376;
      break;

    case 6:
      text  = "Freq";
      xpos += 143;
      ypos  = 376;
      break;

    case 7:
      text  = "Cycle";
      xpos += 201;
      ypos  = 376;
      break;

    case 8:
      text  = "Tim+";
      xpos += 17;
      ypos  = 437;
      break;

    case 9:
      text  = "Tim-";
      xpos += 80;
      ypos  = 437;
      break;

    case 10:
      text  = "Duty+";
      xpos += 138;
      ypos  = 437;
      break;

    case 11:
      text  = "Duty-";
      xpos += 202;
      ypos  = 437;
      break;

    default:
      return;
  }

  //Check if item is on or off
  if(scopesettings.measuresstate[channel][item] == 0)
  {
    //Off so some dark grey text
    display_set_fg_color(GREY_COLOR);
  }
  else
  {
    //On so white text
    display_set_fg_color(WHITE_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xpos, ypos, text);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_open_slider(uint16 xpos, uint16 ypos, uint8 position)
{
  //Save the screen under the screen brightness slider
  display_set_destination_buffer(displaybuffer3);//2
  display_copy_rect_from_screen(xpos, ypos, 331, 58);

  //Setup the slider menu in a separate buffer to be able to slide it onto the screen
  display_set_screen_buffer(displaybuffertmp);

  //Draw the background in dark grey
  display_set_fg_color(DARKGREY_COLOR);

  //Fill the background
  display_fill_rect(xpos, ypos, 331, 58);

  //Draw the edge in a lighter grey
  display_set_fg_color(LIGHTGREY_COLOR);

  //Draw the edge
  display_draw_rect(xpos, ypos, 331, 58);

  //Display the actual slider
  scope_display_slider(xpos, ypos, position);

  //Set source and target for getting it on the actual screen
  display_set_source_buffer(displaybuffertmp);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  //Slide the image onto the actual screen. The speed factor makes it start fast and end slow, Smaller value makes it slower.
  display_slide_left_rect_onto_screen(xpos, ypos, 331, 58, 63039);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_display_slider(uint16 xpos, uint16 ypos, uint8 position)
{
  uint16 x = xpos + 20;
  uint16 y = ypos + 24;
  uint16 w = (291 * position) / 100;
  uint16 ys = ypos + 23;
  uint16 ye = ypos + 35;

  //Clear the background first
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(xpos + 8, ypos + 17, 315, 24);

  //Draw the first part of the slider bar in a yellow color
  display_set_fg_color(YELLOW_COLOR);
  display_fill_rounded_rect(x, y, w, 10, 2);

  //Adjust positions for the grey part
  x += w;
  w  = 291 - w;

  //Draw the last part of the slider bar in a light grey color
  display_set_fg_color(0x00666666);
  display_fill_rounded_rect(x, y, w, 10, 2);

  //Adjust positions for drawing the knob
  x -= 11;
  y -= 6;

  //Draw the knob
  display_set_fg_color(0x00AAAAAA);
  display_fill_rounded_rect(x, y, 22, 22, 2);

  //Draw the black lines on the knob
  display_set_fg_color(BLACK_COLOR);
  display_draw_vert_line(x +  6, ys, ye);
  display_draw_vert_line(x + 11, ys, ye);
  display_draw_vert_line(x + 16, ys, ye);
}

//----------------------------------------------------------------------------------------------------------------------------------

int32 scope_move_slider(uint16 xpos, uint16 ypos, uint8 *position)
{
  uint16 xs = xpos + 20;
  uint16 value;
  int16 filter = xtouch - prevxtouch;

  //Check if update needed
  if((filter > -3) && (filter < 3))
  {
    //When change in movement less the absolute 3 don't process
    return(0);
  }

  //Save for next filter check
  prevxtouch = xtouch;

  //Make sure it stays in allowed range
  if(xtouch <= xs)
  {
    //Below slider keep it on 0
    value = 0;
  }
  else if(xtouch >= (xpos + 311))
  {
    //Above slider keep it on max
    value = 100;
  }
  else
  {
    //Based on xtouch position calculate a new position from 0 to 100
    value = ((xtouch - xs) * 100) / 291;
  }

  //Update the position variable
  *position = value;

  //Show the new position on screen
  scope_display_slider(xpos, ypos, value);

  //Signal there is change
  return(1);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_display_slide_button(uint16 xpos, uint16 ypos, uint8 state, uint32 color)
{
  uint16 linex      = xpos + 9;//8
  uint16 lineystart = ypos + 6;//6
  uint16 lineyend   = ypos + 14;//15
  uint16 buttonx    = xpos + 4;
  uint32 edgecolor  = GREY_COLOR;
  uint32 fillcolor  = 0x00888888;

  if(state == 1)
  {
    //Displace the lines and button by 19 pixels
    linex   += 17;//19
    buttonx += 17;//19

    //Set the enabled colors
    //edgecolor  = 0x00008800;
    //fillcolor  = GREEN_COLOR;
    edgecolor = color-0x7700;
    fillcolor  = color;
    
  }

  //Draw the background
  display_set_fg_color(fillcolor);
  display_fill_rounded_rect(xpos, ypos, 45, 21, 2);

  //Draw the edge
  display_set_fg_color(edgecolor);
  display_draw_rounded_rect(xpos, ypos, 45, 21, 2);

  //Draw button in dark grey
  display_set_fg_color(GREY_COLOR);
  display_fill_rect(buttonx, ypos + 4, 20, 13);//19 13

  //Draw lines in black
  display_set_fg_color(BLACK_COLOR);
  display_draw_vert_line(linex,     lineystart, lineyend);
  display_draw_vert_line(linex + 3, lineystart, lineyend);
  display_draw_vert_line(linex + 6, lineystart, lineyend);
  display_draw_vert_line(linex + 9, lineystart, lineyend);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_display_ok_button(uint16 xpos, uint16 ypos, uint8 mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so light gray background
    display_set_fg_color(LIGHTGREY_COLOR);
  }
  else
  {
    //Active so light grey background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(xpos, ypos, 66, 44, 3);

  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white foreground
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active so black foreground
    display_set_fg_color(BLACK_COLOR);
  }

  //Display the text
  display_set_font(&font_3);
  display_text(xpos + 24, ypos + 14, "OK");
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_default_button(uint16 xpos, uint16 ypos, uint8 mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark orange background
    display_set_fg_color(ORANGE_COLOR);
  }
  else
  {
    //Active so light gray background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(xpos, ypos, 66, 44, 3);

  //Black text
  display_set_fg_color(BLACK_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_text(xpos + 3, ypos + 14, "DEFAULT");
  //display_text(xpos + 3, ypos + 14, "RESTORE");

}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_restore_button(uint16 xpos, uint16 ypos, uint8 mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so dark dark green background
    display_set_fg_color(DARKGREEN_COLOR);
  }
  else
  {
    //Active so light gray background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(xpos, ypos, 66, 44, 3);

  //Black text
  display_set_fg_color(BLACK_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_text(xpos + 3, ypos + 14, "RESTORE");

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_reset_button(uint16 xpos, uint16 ypos, uint8 mode) //((xtouch >= 470) && (xtouch <= 520) && (ytouch >= 420) && (ytouch <= 460))
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so red background
    display_set_fg_color(RED_COLOR);
  }
  else
  {
    //Active so light grey background
    display_set_fg_color(0x00CCCCCC);
  }

  //Draw the background
  display_fill_rounded_rect(xpos, ypos, 66, 44, 3);

  //Black text
  display_set_fg_color(BLACK_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_text(xpos + 13, ypos + 14, "RESET");

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_boot_button(uint16 xpos, uint16 ypos)
{
  uint8 tmp;   
  
  //type firmware to view
  tmp = (boot_menu_start & 0x03);

  //Set so color
  if (tmp == 0) display_set_fg_color(GREEN_COLOR);    //Peco
  if (tmp == 1) display_set_fg_color(BLUE_COLOR);     //fnirsi    
  if (tmp == 2) display_set_fg_color(ORANGE_COLOR);   //FEL mode

  //Draw the background
  display_fill_rounded_rect(xpos, ypos, 46, 22, 2);

  //Black text
  display_set_fg_color(BLACK_COLOR);

  //Display the text
  display_set_font(&font_2);//3
  if (tmp == 0) display_text(xpos + 10, ypos + 4, "PECO"); else
  if (tmp == 1) display_text(xpos + 5,  ypos + 4, "FNIRSI"); else
  if (tmp == 2) display_text(xpos + 2,  ypos + 4, "FELmod");
}
//----------------------------------------------------------------------------------------------------------------------------------

void scope_exit_button(uint16 xpos, uint16 ypos, uint8 mode)
{
  //Check if inactive or active
  if(mode == 0)
  {
    //Inactive so white background
    display_set_fg_color(WHITE_COLOR);
  }
  else
  {
    //Active so green background
    display_set_fg_color(GREEN_COLOR);
  }

  //Draw the background
  display_fill_rounded_rect(xpos, ypos, 66, 44, 3);

  //Black text
  display_set_fg_color(BLACK_COLOR);

  //Display the text
  display_set_font(&font_3);
  display_text(xpos + 20, ypos + 14, "EXIT");//13

}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_display_error(void)
{
  int16  x = WIN2_XPOS + 10;
  
  //Save the screen rectangle where the menu will be displayed
  //display_set_destination_buffer(displaybuffertmp);
  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(WIN2_XPOS, WIN2_YPOS, WIN2_WIDTH, WIN2_HEIGHT);
  
  //Draw the background in grey
  display_set_fg_color(GREY_COLOR);

  //Fill the background
  display_fill_rounded_rect(WIN2_XPOS, WIN2_YPOS, WIN2_WIDTH, WIN2_HEIGHT, 3);
  
  //Display the message in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_3);
  
  display_draw_rounded_rect(WIN2_XPOS, WIN2_YPOS, WIN2_WIDTH, WIN2_HEIGHT, 3);  
  
  //Fill the background white
  display_set_fg_color(WHITE_COLOR);
  display_fill_rounded_rect(x + 40, WIN2_YPOS + 15, 105, 16, 3);
  
  //Display the message in red
  display_set_fg_color(RED_COLOR);
  display_text(x + 50, WIN2_YPOS + 15, "Not allowed !");//+5
  
  //Display the message in white
  display_set_fg_color(GREEN_COLOR);
  display_set_font(&font_2);
  display_text(x, WIN2_YPOS + 45, "Please unmount disk in PC first !");

  // Wait 4 seconds
  timer0_delay(4000);
  
  //Restore the screen when done
  //display_set_source_buffer(displaybuffertmp);
  display_set_source_buffer(displaybuffer3);
  display_copy_rect_to_screen(WIN2_XPOS, WIN2_YPOS, WIN2_WIDTH, WIN2_HEIGHT);
}

//----------------------------------------------------------------------------------------------------------------------------------
/*
void scope_adjust_timebase(void)
{
  //Check if touch within the trace display region
  if((previousxtouch > 2) && (previousxtouch < 720) && (previousytouch > 50) && (previousytouch < 470))
  {
    //Check if touch on the left of the center line
    if(previousxtouch < 358)
    {
      //Check if not already on the highest setting (50S/div)
      if(scopesettings.timeperdiv > 0)
      {
        //Go up in time by taking one of the setting
        scopesettings.timeperdiv--;
      }
    }
    //Check if touch on the right of the center line
    else if(previousxtouch > 362)
    {
      //Check if not already on the lowest setting (10nS/div)
      if(scopesettings.timeperdiv < ((sizeof(time_div_texts) / sizeof(int8 *)) - 1))
      {
        //Go down in time by adding one to the setting
        scopesettings.timeperdiv++;
      }
    }

    //For time per div set with tapping on the screen the direct relation between the time per div and the sample rate is set
    //but only when the scope is running. Otherwise the sample rate of the acquired buffer still is valid.
    if(scopesettings.runstate)//ok
    {
      //Set the sample rate that belongs to the selected time per div setting
      scopesettings.samplerate = time_per_div_sample_rate[scopesettings.timeperdiv];
    }

    //Set the new setting in the FPGA
    fpga_set_sample_rate(scopesettings.samplerate);

    //Show he new setting on the display
    scope_acqusition_settings(0);
  }
}
*/
//----------------------------------------------------------------------------------------------------------------------------------

//v1.00s2: record overview in the scroll box under the grid (columns x 4..726, rows y 454..469)
#define RO_X0          4
#define RO_W           723
#define RO_Y_TOP       454
#define RO_Y_BOTTOM    469

static void scope_draw_record_channel_overview(PCHANNELSETTINGS settings, uint32 color, uint32 dimcolor, int32 wx, int32 ww)
{
  uint32 total = fpgasettings.totalsamples;
  uint32 c, a, b, i, min, max, v;
  uint8 *buf = settings->tracebuffer;

  if(!settings->enable || (total == 0))
    return;

  for(c = 0; c < RO_W; c++)
  {
    a = (c * total) / RO_W;
    b = ((c + 1) * total) / RO_W;

    if(b <= a)
      b = a + 1;

    if(b > total)
      b = total;

    min = 255;
    max = 0;

    for(i = a; i < b; i++)
    {
      v = buf[i];

      if(v < min) min = v;
      if(v > max) max = v;
    }

    //Full color inside the window, dimmed outside it
    display_set_fg_color((((int32)(RO_X0 + c) >= wx) && ((int32)(RO_X0 + c) < (wx + ww))) ? color : dimcolor);
    display_draw_vert_line(RO_X0 + c, RO_Y_BOTTOM - ((max * (RO_Y_BOTTOM - RO_Y_TOP)) / 255), RO_Y_BOTTOM - ((min * (RO_Y_BOTTOM - RO_Y_TOP)) / 255));
  }
}

void scope_draw_record_overview(int32 wx, int32 ww)
{
  //Not in the long time base mode (no record)
  if(scopesettings.long_mode)
    return;

  scope_draw_record_channel_overview(&scopesettings.channel2, CHANNEL2_COLOR, 0x00007F7F, wx, ww);
  scope_draw_record_channel_overview(&scopesettings.channel1, CHANNEL1_COLOR, 0x007F7F00, wx, ww);
}

void scope_draw_grid(void)
{
  uint32 color;
  register uint32 i;
   
  uint32 cursor_position;
  int32 cursor_width;
  
  //Set the color for drawing
  //display_set_fg_color(WHITE_COLOR);
  //v1.00s3: the scroll box frame in the grey of the grid frame (grid brightness) instead of white
  color = (scopesettings.gridbrightness * 255) / 100;
  color = (color << 16) | (color << 8) | color;
  display_set_fg_color(color);
  
  // Draw buffer scroll box
  display_draw_rect(2, 452, 726, 20);//46 404
  
  // Handling limits for disp_first_sample (must not be outside the buffer)
  // We need to subtract the screen width in samples so that the cursor doesn't point "beyond the end"
  int32 screen_width_samples = (int32)(725.0 / disp_xpos_per_sample);
  int32 max_first_sample = fpgasettings.totalsamples - screen_width_samples;

  if (disp_first_sample > max_first_sample) disp_first_sample = max_first_sample;
  if (disp_first_sample < 0) disp_first_sample = 0;

  // Calculating scrollbar position
  // Assume: bar width = 600 pixels, start at pixel 4
  // Formula: (current_start / total_count) * bar_width + start_offset
  cursor_position = (int32)(((float)disp_first_sample * 723.0) / fpgasettings.totalsamples) + 4;

  // Calculating cursor width (shows how big a viewport we can see)
  // Cursor width = (samples_on_display / total_samples) * bar_width
  cursor_width = (int32)(((float)screen_width_samples * 723.0) / fpgasettings.totalsamples);

  // Minimum width lock to always keep the cursor visible (e.g. at least 5 pixels)
  if (cursor_width < 5) cursor_width = 5;
  // Fuse for maximum width (must not exceed the bar)
  if (cursor_width > 723) cursor_width = 723;

  //v1.00s2: overview of the whole record in the scroll box (as the MCP record slider): per column the min / max of the
  //samples that fall in it, CH2 then CH1, dimmed outside the window and in the full color inside it
  scope_draw_record_overview(cursor_position, cursor_width);

  //Set the color for drawing
  display_set_fg_color(WHITE_COLOR);

  // Rendering
  // We will use dynamic cursor width
  display_draw_rect(cursor_position, 455, cursor_width, 14);
 
  //Set the color for drawing
  //display_set_fg_color(YELLOW_COLOR);
  
  //Display the text
  //display_set_font(&font_3);//3
  
  //Draw the ticks on the x line
  //for(i=4;i<722;i+=5)        
  //{
  // //display_draw_vert_line
  // display_text(i, 453, "~");    
  //}
    
//-*****************************************************************************

  //Only draw the grid when something will show (not in the original code)
  if(scopesettings.gridbrightness > 3)
  {
    //Calculate a grey shade based on the grid brightness setting
    color = (scopesettings.gridbrightness * 255) / 100;
    color = (color << 16) | (color << 8) | color;
    
    
    //Draw the center lines orange if single mode
    //if(scopesettings.triggermode == 1) display_set_fg_color(ORANGE_COLOR);  else display_set_fg_color(color);  
    //v1.00z3: not in the logger roll (the orange line marks Single of the normal time base)
    if((scopesettings.triggermode == 1) && !scope_roll_ui()) display_set_fg_color(ORANGE_COLOR);  else display_set_fg_color(color);  
    display_draw_horz_line(249,  2, 726);

    //Set the color for drawing
    display_set_fg_color(color);

    //Draw the edge
    display_draw_rect(2, 48, 726, 403);//46 404   44-406

    //Draw the center lines
    //display_draw_horz_line(249,  2, 726); 
    display_draw_vert_line(364, 49, 449);//44-448

    //Draw the ticks on the x line
    for(i=4;i<726;i+=5)
    {
      display_draw_vert_line(i, 247, 251);
    }

    //Draw the ticks on the y line-ok
    for(i=54;i<448;i+=5)//49 448 5
    {
      display_draw_horz_line(i, 362, 366);
    }

    //Draw the horizontal dots-ok
    for(i=99;i<448;i+=50)
    {
      display_draw_horz_dots(i, 4, 726, 5);
    }

    //Draw the vertical dots-ok
    for(i=14;i<726;i+=50)
    {
      display_draw_vert_dots(i, 54, 448, 5);//49
    }
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
/*
void scope_draw_pointers(void)
{
  int32 position;

  //Draw channel 1 pointer when it is enabled
  if(scopesettings.channel1.enable)
  {
    //Set the colors for drawing
    display_set_fg_color(CHANNEL1_COLOR);
    display_set_bg_color(BLACK_COLOR);

    //Select the font for this pointer id
    display_set_font(&font_0);

    //Check if in normal or x-y display mode
    if(scopesettings.xymodedisplay == 0)
    {
      //y position for the channel 1 trace center pointer.
      position = 441 - scopesettings.channel1.traceposition;

      //Limit on the top of the displayable region
      if(position < 44)
      {
        position = 44;
      }
      //Limit on the bottom of the displayable region
      else if(position > 441)
      {
        position = 441;
      }

      //Draw the pointer
      display_left_pointer(2, position, '1');
    }
    else
    {
      //y position for the channel 1 trace center pointer.
      position = 157 + scopesettings.channel1.traceposition;

      //Limit on the left of the active range
      if(position < 166)
      {
        position = 166;
      }
      //Limit on the right of the active range
      else if(position > 548)
      {
        position = 548;
      }

      //Draw the pointer
      display_top_pointer(position, 47, '1');
    }
  }

  //Draw channel 2 pointer when it is enabled
  if(scopesettings.channel2.enable)
  {
    //y position for the channel 2 trace center pointer
    position = 441 - scopesettings.channel2.traceposition;

    //Limit on the top of the displayable region
    if(position < 44)
    {
      position = 44;
    }
    //Limit on the bottom of the displayable region
    else if(position > 441)
    {
      position = 441;
    }

    //Set the colors for drawing
    display_set_fg_color(CHANNEL2_COLOR);
    display_set_bg_color(BLACK_COLOR);

    //Select the font for this pointer id
    display_set_font(&font_0);

    //Draw the pointer
    display_left_pointer(2, position, '2');
  }

  //Need to think about trigger position in 200mS - 20mS/div settings. Not sure if they work or need to be done in software
  //The original scope does not show them for 50mS and 20mS/div

  //Draw trigger position and level pointer when in normal display mode
  if(scopesettings.xymodedisplay == 0)
  {
    //Set the colors for drawing
    if(disp_have_trigger == 1) display_set_fg_color(RED_COLOR); 
    else display_set_fg_color(TRIGGER_COLOR);
    display_set_bg_color(BLACK_COLOR);

    //Select the font for this pointer id
    display_set_font(&font_3); 
    
    //x position for the trigger position pointer
    //position = scopesettings.triggerhorizontalposition + 2;
    position = scopesettings.triggerhorizontalposition;

    //Limit on the left of the displayable region
    if(position < 3)//3
    { //Out of limit on the left of the displayable region
      display_right_pointer(2, 45, 'H');
    }
    //Limit on the right of the displayable region
    else if(position > 713)
    {//Out of limit on the right of the displayable region
      display_left_pointer(706, 45, 'H');
    }
    else 
    //Draw the pointer
    display_top_pointer(position, 45, 'H');//47
    
    //-----------------------------------------------------
    //y position for the trigger level pointer
    position = 441 - scopesettings.triggerverticalposition;

    //Limit on the top of the displayable region
    if(position < 44)
    {
      position = 44;
    }
    //Limit on the bottom of the displayable region
    else if(position > 441)
    {
      position = 441;
    }

    //Need to reset the fore ground color
    //Select the channel based on the current trigger color
    if(scopesettings.triggerchannel == 0) display_set_fg_color(CHANNEL1_COLOR);
            else display_set_fg_color(CHANNEL2_COLOR);   
    

    //Draw the pointer
    display_right_pointer(707, position, 'T');
  }
}
*/
//----------------------------------------------------------------------------------------------------------------------------------

void scope_draw_time_cursors(void)
{
  //Only draw the lines when enabled
  if(scopesettings.timecursorsenable)
  {
    //Set the color for the dashed lines
    display_set_fg_color(CURSORS_COLOR);

    //Draw the lines
    display_draw_vert_dashes(scopesettings.timecursor1position, 51, 446, 3, 3);//49 444 3 3 //48 448//46 447
    display_draw_vert_dashes(scopesettings.timecursor2position, 51, 446, 3, 3);//48 448
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_draw_volt_cursors(void)
{
  //Only draw the lines when enabled
  if(scopesettings.voltcursorsenable)
  {
    //Set the color for the dashed lines
    display_set_fg_color(CURSORS_COLOR);

    //Draw the lines
    display_draw_horz_dashes(scopesettings.voltcursor1position, 6, 725, 3, 3);//6 726
    display_draw_horz_dashes(scopesettings.voltcursor2position, 6, 725, 3, 3);//6 726
  }
}

//----------------------------------------------------------------------------------------------------------------------------------

/*
 void u32_to_hexstr(uint32 value, char *buffer) {
    const char hex_chars[] = "0123456789ABCDEF";
    for (int i = 0; i < 8; i++) {
        buffer[7 - i] = hex_chars[(value >> (i * 4)) & 0xF];
    }
    buffer[8] = '\0'; // null-terminate
}
 
 */
//==============================================================================

void make_freq_to_text(char *dst, uint32 f)
{
  char buf[16];
  dst[0] = 0;         // clear buffer
    
  if (f < 1000) 
  {
    // Hz
    my_uint_to_str(buf, f);
    my_strcpy(dst, buf);
    my_strcat(dst, "Hz");
  } 
  else if (f < 1000000) 
  {
    // kHz
    uint32 k = f / 1000;
    uint32 r = f % 1000; // zvyšok pre desatiny
    my_uint_to_str(buf, k);
    my_strcpy(dst, buf);
        
    int len = my_strlen(dst); // pozícia konca stringu
    dst[len++] = '.';          // bodka
    dst[len++] = '0' + (r / 100);       // prvá desatina
    //dst[len++] = '0' + ((r/10)%10);    // druhá
    //dst[len++] = '0' + (r % 10);       // tretia
    dst[len] = 0;  

    my_strcat(dst, "kHz");
  } 
  else 
  {
    // MHz s 6 desatinnými miestami
    uint32_t k = f / 1000000;
    uint32_t r = f % 1000000; // zvyšok pre desatiny

    my_uint_to_str(buf, k);
    my_strcpy(dst, buf);

    int len = my_strlen(dst); // pozícia konca stringu
    dst[len++] = '.';          // bodka
    dst[len++] = '0' + (r / 100000);        // prvá desatina
    dst[len++] = '0' + ((r / 10000) % 10);  // druhá
    //dst[len++] = '0' + ((r / 1000) % 10);   // tretia
    //dst[len++] = '0' + ((r / 100) % 10);    // štvrtá
    //dst[len++] = '0' + ((r / 10) % 10);     // piata
    //dst[len++] = '0' + (r % 10);            // šiesta
    dst[len] = 0;

    my_strcat(dst, "MHz");
  }
  
  // Center text alignment
  align_text(dst, 8, 2);
  //centering_text(dst, 5);
}

//==============================================================================

void make_freq_to_long_text(char *dst, uint32 f)
{
  char buf[16];
  dst[0] = 0;         // clear buffer
    
  if (f < 1000) 
  {
    // Hz
    my_uint_to_str(buf, f);
    my_strcpy(dst, buf);
    my_strcat(dst, "Hz");
  } 
    else if (f < 1000000) 
    {
      // kHz
      uint32 k = f / 1000;
      uint32 r = f % 1000; // zvyšok pre desatiny
      my_uint_to_str(buf, k);
      my_strcpy(dst, buf);
        
      int len = my_strlen(dst); // pozícia konca stringu
      dst[len++] = '.';          // bodka
      dst[len++] = '0' + (r / 100);       // prvá desatina
      dst[len++] = '0' + ((r/10)%10);    // druhá
      dst[len++] = '0' + (r % 10);       // tretia
      dst[len] = 0;  

      my_strcat(dst, "kHz");
    } 
      else 
      {
        // MHz s 6 desatinnými miestami
        uint32_t k = f / 1000000;
        uint32_t r = f % 1000000; // zvyšok pre desatiny

        my_uint_to_str(buf, k);
        my_strcpy(dst, buf);

        int len = my_strlen(dst); // pozícia konca stringu
        dst[len++] = '.';          // bodka
        dst[len++] = '0' + (r / 100000);        // prvá desatina
        dst[len++] = '0' + ((r / 10000) % 10);  // druhá
        dst[len++] = '0' + ((r / 1000) % 10);   // tretia
        dst[len++] = '0' + ((r / 100) % 10);    // štvrtá
        dst[len++] = '0' + ((r / 10) % 10);     // piata
        dst[len++] = '0' + (r % 10);            // šiesta
        dst[len] = 0;

        my_strcat(dst, "MHz");
      }
  
  // Center text alignment
  //centering_text(dst, 12);
  align_text(dst, 12, 2);
}

//==============================================================================

void make_value_to_text(char *dst, uint32 d, char c)
{
  char buf[16];
  char tmp[2];
  tmp[0] = c;
  tmp[1] = '\0';
  dst[0] = 0;         // clear buffer

  // %
  my_uint_to_str(buf, d);
  my_strcpy(dst, buf);
  
  my_strcat(dst, tmp);
  //my_strcat(dst, "%");

  // Right text alignment
  //centering_text(dst, 4);
  align_text(dst, 4, 2);
}

//==============================================================================

void make_volt_to_long_text(char *dst, uint32 f)
{
  char buf[16];
  dst[0] = 0;         // clear buffer
    
  if (f < 1000) 
  {
    // Hz
    my_uint_to_str(buf, f);
    my_strcpy(dst, buf);
    my_strcat(dst, "mV");
  } 
  else if (f < 1000000) 
  {
    // kHz
    uint32 k = f / 1000;
    uint32 r = f % 1000; // remainder for tithes
    my_uint_to_str(buf, k);
    my_strcpy(dst, buf);
        
    int len = my_strlen(dst);         // end position of string
    dst[len++] = '.';                 // dot
    dst[len++] = '0' + (r / 100);     // first tithe
    dst[len++] = '0' + ((r/10)%10);   // second tithe
    dst[len++] = '0' + (r % 10);      // third tithe
    dst[len] = 0;  

    my_strcat(dst, "V");
  } 
  else 
  {
    // MHz with 6 decimal places
    uint32_t k = f / 1000000;
    uint32_t r = f % 1000000;         // remainder for tithes

    my_uint_to_str(buf, k);
    my_strcpy(dst, buf);

    int len = my_strlen(dst); // end position of string
    dst[len++] = '.';                       // dot
    dst[len++] = '0' + (r / 100000);        // first tithe
    dst[len++] = '0' + ((r / 10000) % 10);  // second tithe
    dst[len++] = '0' + ((r / 1000) % 10);   // third tithe
    dst[len++] = '0' + ((r / 100) % 10);    // fourth tithe
    dst[len++] = '0' + ((r / 10) % 10);     // fifth tithe
    dst[len++] = '0' + (r % 10);            // sixth tithe
    dst[len] = 0;

    //my_strcat(dst, "MHz");
  }
   
  //my_strcat(dst, tmp);
  // Center text alignment
  //centering_text(dst, 12);
  align_text(dst, 12, 1);
}

//==============================================================================
/*
void centering_text(char *dst, uint8 width)
{
  int len = my_strlen(dst);
  if (len >= width) return;

  int shift = width - len;

  // move BACK from the end so we don't overwrite anything
    for (int i = len; i >= 0; i--) dst[i + shift] = dst[i];
      
  // add spaces to the beginning
  for (int i = 0; i < shift; i++) dst[i] = ' ';     
}
*/
void align_text(char *dst, uint8 width, uint8 mode)
{
  //ALIGN_LEFT = 0,  ALIGN_CENTER = 1, ALIGN_RIGHT = 2
              
  int len = my_strlen(dst); 
  if (len >= width){dst[width] = 0;return;} // if the text is longer, we cut it off

  int left_spaces = 0;
  int right_spaces = 0;
  int free_space = width - len;

  switch (mode)
  {
    case 0:
            left_spaces = 0;
            right_spaces = free_space;
            break;

    case 1:
            left_spaces = free_space / 2;
            right_spaces = free_space - left_spaces;
            break;    
            
    case 2:
            left_spaces = free_space;
            right_spaces = 0;
            break;
  }

  // shift the text to the right by left_spaces
  for (int i = len; i >= 0; i--) dst[i + left_spaces] = dst[i];
        
  // adding spaces to the beginning
  for (int i = 0; i < left_spaces; i++) dst[i] = ' ';
        
  // adding spaces at the end
  for (int i = 0; i < right_spaces; i++) dst[left_spaces + len + i] = ' ';

  dst[width] = 0;
}

//==============================================================================

void format_version_full(uint32 value, char *buffer) 
{
  int idx = 0;

  for (int i = 3; i >= 0; i--) 
  {
    uint8_t byte = (value >> (i * 8)) & 0xFF;

    if (i != 3)  buffer[idx++] = '.';
            
    // Converting a byte to a decimal number
    if (byte >= 100) 
    {
      buffer[idx++] = '0' + byte / 100;
      buffer[idx++] = '0' + (byte / 10) % 10;
      buffer[idx++] = '0' + byte % 10;
    } 
    else if (byte >= 10) 
    {
      buffer[idx++] = '0' + byte / 10;
      buffer[idx++] = '0' + byte % 10;
    } 
    else { buffer[idx++] = '0' + byte; }
  }
  buffer[idx] = '\0';
}

void extract_version_string(uint32 word1, uint32 word2, char *buffer) 
{ 
  buffer[0] = (char) (word1 & 0xFF);         // 'v'
  buffer[1] = (char)((word1 >> 8) & 0xFF);   // '0'
  buffer[2] = (char)((word1 >> 16) & 0xFF);  // '.'
  buffer[3] = (char)((word1 >> 24) & 0xFF);  // '2'

  buffer[4] = (char) (word2 & 0xFF);         // '6'
  buffer[5] = (char)((word2 >> 8) & 0xFF);   // 's'
  buffer[6] = (char)((word2 >> 16) & 0xFF);  // '\0' (null terminator)
  buffer[7] = '\0'; // just to be sure
}

//==============================================================================
//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00s7: all settings on one full screen page with tabs at the top (opened by Settings in the main menu). Each tab is a
//card with framed sections (a small heading over the settings that belong together) in two columns, or one section over
//the full width. The tables below give the layout; the touch handling is handle_settings_page (statemachine.c).
//v1.00s8: a frame around the page, wide brightness sliders with more room, and the Clock tab in the same style (on /
//off switch, hours and minutes, day, month and year with - / + buttons) instead of the old RTC panel.
//(v1.00s5 had the Other settings only; its item list used int8, which is unsigned char here, so the -1 end marker was
//never seen and empty places were drawn as "Boot menu".)

#define SP_TAB_H          44
#define SP_TAB_W          115
#define SP_TAB_CLOSE_W    100
#define SP_SEC_Y0         62
#define SP_SEC_HEAD_H     22
#define SP_SEC_GAP        14
#define SP_ROW_H          48
#define SP_SLIDER_ROW_H   62          //v1.00s9: a bit smaller (was 76)
#define SP_COL_X0         16
#define SP_COL_W          376
#define SP_COL_PITCH      392
#define SP_FULL_W         (SP_COL_PITCH + SP_COL_W)
#define SP_FRAME_COLOR    0x00505050
#define SP_PAGE_BG        0x00101010     //v1.00s8: background inside the page frame

//v1.00s8: an accent color per tab (tab, frame, section frames and headings, item stripe)
static const uint32 settings_tab_colors[SETTINGS_TABS] = { 0x00FFFF00, 0x0000FFFF, 0x0000DD55, 0x00FF8000, 0x00FF5050, 0x00FF60FF };

static uint32 settings_dim(uint32 c)
{
  return((c >> 1) & 0x007F7F7F);
}

const int8 *settings_tab_names[SETTINGS_TABS] = { "Display", "Measure", "Startup", "Files & USB", "Service", "Clock" };

static const SETTINGSSECTION settings_sections[SETTINGS_TABS][SETTINGS_SECTIONS] =
{
  //Display
  { { "Brightness",              2, { OS_SCREENBRIGHT, OS_GRIDBRIGHT, -1 } },
    { "Display mode",            0, { OS_XYMODE, -1 } },
    //{ 0, 0, { -1 } }, { 0, 0, { -1 } } },
    { "Trigger position",        1, { OS_TRIGMIN, OS_TRIGMAX, OS_TRIGHYST, -1 } },     //v1.00x9
    { 0, 0, { -1 } } },
  //Measure
  { { "Measurements & cursors",  0, { OS_TRANSPARENT, OS_LOCKCUR, -1 } },
    //{ "Operation",               1, { OS_AUTOSETUP, -1 } },      //v1.00t0: Notification confirmation moved to Service
    { "Operation",               1, { OS_AUTOSETUP, OS_TAPVDIV, OS_BODEHINT, -1 } },      //v1.00y6: + tap V/div, Bode hint
    //{ 0, 0, { -1 } }, { 0, 0, { -1 } } },
    //{ "Decoder",                 0, { OS_I2CON, OS_I2CAUTO, OS_I2C10, OS_I2CDEC, -1 } },  //v1.01a3: I2C decoder
    //{ "Decoder",                 0, { OS_I2CON, OS_I2CAUTO, OS_I2C10, -1 } },  //v1.01b2: the start settings only
    { "Decoder",                 0, { OS_I2CON, OS_I2CAUTO, OS_I2C10, OS_I2CDEC, -1 } },  //v1.01b6: + Decode button switches on
    { 0, 0, { -1 } } },
  //Startup
  //{ { "Boot",                    0, { OS_BOOT, OS_DEFSTART, -1 } },
  { { "Boot",                    0, { OS_BOOT, OS_DEFSTART, OS_LASTVIEW, -1 } },     //v1.00z4: + Start in last view
    { "Reference waveforms",     1, { OS_REFSTART, -1 } },
    { 0, 0, { -1 } }, { 0, 0, { -1 } } },
  //Files & USB
  { { "Pictures",                0, { OS_BMPTAG, -1 } },
    { "USB",                     1, { OS_USBSERIAL, -1 } },
    { "CSV export (with SAVE)",  0, { OS_CSVSCOPE, OS_CSVSPEC, OS_CSVBODE, -1 } },     //v1.00v3: each on its own
    { 0, 0, { -1 } } },
  //Service (v1.00t0: baseline and input divider calibration as two buttons)
  //{ { "Calibration",             0, { OS_BASECAL, OS_INPUTCAL, OS_DCSHIFT, -1 } },
  { { "Calibration",             0, { OS_BASECAL, OS_INPUTCAL, OS_ADCCAL, OS_DCSHIFT, -1 } },     //v1.00y1: + ADC timing
    { "Developer",               1, { OS_CONFIRM, OS_DEVMODE, -1 } },     //v1.00t0: Notification confirmation over Dev mode
    { 0, 0, { -1 } }, { 0, 0, { -1 } } },
  //Clock (v1.00t0: right column the current time, under it the time setting, under that the date setting)
  { { "Clock",                   0, { OS_CLOCKON, -1 } },
    { "Current time",            1, { OS_CLOCKNOW, -1 } },
    { "Time",                    1, { OS_HOUR, OS_MINUTE, -1 } },
    { "Date",                    1, { OS_DAY, OS_MONTH, OS_YEAR, -1 } } },
};

static const int8 *settings_item_names[OS_ITEMS] =
{
  "Boot menu", "Default start", "Load Ref on start", "New autosetup", "Lock move cursors", "Notification confirmation",
  "Add a tag to BMP", "USB-Serial mode", "DC shift calibration", "Dev mode", "Transparent measurements",
  "Screen brightness", "Grid brightness", "X-Y mode display", "Baseline calibration",
  "Clock on (time stamp in files)", "Hours", "Minutes", "Day", "Month", "Year", "Current time", "Input divider calibration",
  "Scope waveform CSV", "Frequency response CSV", "Spectrum CSV",
  "Min position", "Max position", "Hysteresis (ADC codes)",     //v1.00x9
  "ADC timing calibration",                                      //v1.00y1
  "Frequency response start hint", "Tap V/div (top / bottom edge)",  //v1.00y6
  "Start in last view",                                              //v1.00z4
  //"I2C decoder (SDA CH1, SCL CH2)", "Automatic threshold (50 %)", "10 bit addresses", "Values in decimal"     //v1.01a3
  //"Decoder on (I2C / UART / SPI)", "Automatic threshold (50 %)", "I2C 10 bit addresses", "Values in decimal"     //v1.01b1
  //v1.01b2: only the start settings of the decoder (the rest is in its window)
  //"Decoder on at start", "Protocol at start", "Threshold Auto 50 % at start", "Values in decimal"
  "Decoder on at start", "Protocol at start", "Threshold Auto 50 % at start", "CTRL Decode button switches on"     //v1.01b6
};

//v1.00x9: the slider rows (brightness, trigger position Min / Max, trigger hysteresis)
int settings_is_slider(int id)
{
  return((id == OS_SCREENBRIGHT) || (id == OS_GRIDBRIGHT) || (id == OS_TRIGMIN) || (id == OS_TRIGMAX) || (id == OS_TRIGHYST));
}

static int settings_row_h(int id)
{
  //return(((id == OS_SCREENBRIGHT) || (id == OS_GRIDBRIGHT)) ? SP_SLIDER_ROW_H : SP_ROW_H);
  return(settings_is_slider(id) ? SP_SLIDER_ROW_H : SP_ROW_H);
}

static int settings_section_count(int tab, int sec)
{
  int n = 0;

  if(!settings_sections[tab][sec].title)
    return(0);

  while((n < SETTINGS_SECTION_ITEMS) && (settings_sections[tab][sec].items[n] >= 0))
    n++;

  return(n);
}

//Height of the items of a section
static int settings_section_rows_h(int tab, int sec)
{
  int i, h = 0;

  for(i = 0; i < settings_section_count(tab, sec); i++)
    h += settings_row_h(settings_sections[tab][sec].items[i]);

  return(h);
}

static int settings_section_h(int tab, int sec)
{
  return(SP_SEC_HEAD_H + settings_section_rows_h(tab, sec) + 8);
}

//Column 2 is the full width: it takes the place in both columns
static int settings_cols_overlap(int a, int b)
{
  return((a == b) || (a == 2) || (b == 2));
}

//Top of a section: sections of the same column (or a full width one) are stacked
static int settings_section_y(int tab, int sec)
{
  int y = SP_SEC_Y0, s;

  for(s = 0; s < sec; s++)
  {
    if(settings_sections[tab][s].title && settings_cols_overlap(settings_sections[tab][s].col, settings_sections[tab][sec].col))
      y += settings_section_h(tab, s) + SP_SEC_GAP;
  }

  return(y);
}

static int settings_section_x(int tab, int sec)
{
  return(SP_COL_X0 + ((settings_sections[tab][sec].col == 1) ? SP_COL_PITCH : 0));
}

int settings_section_w(int tab, int sec)
{
  return((settings_sections[tab][sec].col == 2) ? SP_FULL_W : SP_COL_W);
}

int settings_item_id(int tab, int sec, int idx)
{
  return(settings_sections[tab][sec].items[idx]);
}

void settings_item_pos(int tab, int sec, int idx, int *x, int *y)
{
  int i;

  *x = settings_section_x(tab, sec) + 8;
  *y = settings_section_y(tab, sec) + SP_SEC_HEAD_H;

  for(i = 0; i < idx; i++)
    *y += settings_row_h(settings_sections[tab][sec].items[i]);
}

//Width of an item row
int settings_item_w(int tab, int sec)
{
  return(settings_section_w(tab, sec) - 16);
}

//The section and item at a touch position, 0 when none
int settings_item_at(int tab, int x, int y, int *sec, int *idx)
{
  int s, i, ix, iy;

  for(s = 0; s < SETTINGS_SECTIONS; s++)
  {
    for(i = 0; i < settings_section_count(tab, s); i++)
    {
      settings_item_pos(tab, s, i, &ix, &iy);

      if((x >= ix) && (x < (ix + settings_item_w(tab, s))) && (y >= iy) && (y < (iy + settings_row_h(settings_sections[tab][s].items[i]) - 4)))
      {
        *sec = s;
        *idx = i;
        return(1);
      }
    }
  }

  return(0);
}

//The tab at a touch position in the tab bar, SETTINGS_TABS for Close, -1 when none
int settings_tab_at(int x, int y)
{
  if(y >= SP_TAB_H)
    return(-1);

  if(x >= (800 - SP_TAB_CLOSE_W))
    return(SETTINGS_TABS);

  if((x / SP_TAB_W) < SETTINGS_TABS)
    return(x / SP_TAB_W);

  return(-1);
}

static uint8 settings_item_state(int id)
{
  switch(id)
  {
    case OS_BOOT:        return((boot_menu_start & 0x04) >> 2);
    case OS_REFSTART:    return(scopesettings.ref_on_startup);
    case OS_AUTOSETUP:   return(scopesettings.new_autosetup);
    case OS_LOCKCUR:     return(scopesettings.lockcursors);
    case OS_CONFIRM:     return(scopesettings.confirmationmode);
    case OS_BMPTAG:      return(tag_in_BMP);
    case OS_USBSERIAL:   return(USB_CH340);
    case OS_DCSHIFT:     return(dc_shift_cal);
    case OS_DEVMODE:     return(dev_mode);
    case OS_TRANSPARENT: return(scopesettings.transparentmeasures);
    case OS_XYMODE:      return(scopesettings.xymodedisplay);
    case OS_CLOCKON:     return(onoffRTC);
    case OS_CSVSCOPE:    return((scopesettings.csvexport & CSV_EXPORT_SCOPE) ? 1 : 0);
    case OS_CSVBODE:     return((scopesettings.csvexport & CSV_EXPORT_BODE) ? 1 : 0);
    case OS_CSVSPEC:     return((scopesettings.csvexport & CSV_EXPORT_SPECTRUM) ? 1 : 0);
    case OS_BODEHINT:    return(!scopesettings.bodehint_off);     //v1.00y6
    case OS_TAPVDIV:     return(!scopesettings.tapvdiv_off);      //v1.00y6
    case OS_LASTVIEW:    return(scopesettings.startlastview);     //v1.00z4
    //case OS_I2CON:       return(scope_i2c_enabled);               //v1.01a3
    //case OS_I2CAUTO:     return(scope_i2c_thr_auto);
    //case OS_I2C10:       return(scope_i2c_addr10);
    case OS_I2CON:       return(scope_dec_start_on);              //v1.01b2: start settings
    case OS_I2C10:       return(scope_dec_start_auto);
    //case OS_I2CDEC:      return(scope_i2c_dec);
    case OS_I2CDEC:      return(scope_dec_btn_on);                //v1.01b6
    default:             return(0);
  }
}

static uint32 settings_text_width(const char *t)
{
  extern DISPLAYDATA displaydata;
  PFONTINFORMATION info;
  uint32 w = 0;

  for(; *t; t++)
  {
    info = check_char_in_vw_font(displaydata.font->fontinformation, (uint16)(uint8)*t);

    if(info)
      w += info->fontmetrics[(uint8)*t - info->first_char].width;
  }

  return(w);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Wide sliders (v1.00s8): the name and the value on the first line, the bar over the row's width below it

uint8 *settings_slider_value(int id)
{
  //return((id == OS_SCREENBRIGHT) ? &scopesettings.screenbrightness : &scopesettings.gridbrightness);
  //v1.00x9: + trigger position Min / Max and the trigger hysteresis
  switch(id)
  {
    case OS_SCREENBRIGHT: return(&scopesettings.screenbrightness);
    case OS_TRIGMIN:      return(&scopesettings.trigposmin);
    case OS_TRIGMAX:      return(&scopesettings.trigposmax);
    case OS_TRIGHYST:     return(&scopesettings.trighyst);
    default:              return(&scopesettings.gridbrightness);
  }
}

//v1.00x9: range and step of a slider (brightness 0..100 %, Min 0..45 %, Max 55..100 % in 5 % steps, hysteresis
//0..TRIG_HYST_MAX ADC codes)
void settings_slider_range(int id, int *min, int *max, int *step)
{
  *step = 1;

  switch(id)
  {
    case OS_TRIGMIN:  *min = 0;  *max = 45;  *step = 5; break;
    case OS_TRIGMAX:  *min = 55; *max = 100; *step = 5; break;
    case OS_TRIGHYST: *min = 0;  *max = TRIG_HYST_MAX;  break;
    default:          *min = 0;  *max = 100;            break;
  }
}

//v1.00x9: the hysteresis needs FPGA 0x2050; with others its slider is grey and does nothing
int settings_slider_enabled(int id)
{
  return((id != OS_TRIGHYST) || FPGA_IS_153F_PORT());
}

//The bar of a slider row: x from bx to bx + bw
void settings_slider_bar(int x, int w, int *bx, int *bw)
{
  *bx = x + 24;
  *bw = w - 48;
}

void settings_slider_draw(int x, int y, int w, int id)
{
  char   buffer[16];
  uint8  v = *settings_slider_value(id);
  int    bx, bw, k;
  int    smin, smax, sstep, en = settings_slider_enabled(id);   //v1.00x9

  settings_slider_bar(x, w, &bx, &bw);
  //k = (bw * v) / 100;
  settings_slider_range(id, &smin, &smax, &sstep);
  (void)sstep;

  if(v < smin) v = smin;
  if(v > smax) v = smax;

  k = (bw * (v - smin)) / (smax - smin);

  //Name and value (v1.00s9: smaller, row of 62 px)
  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rect(x + 8, y + 3, w - 16, 52);

  display_set_font(&font_2);
  display_set_fg_color(WHITE_COLOR);
  display_text(x + 20, y + 7, (int8 *)settings_item_names[id]);

  //make_value_to_text(buffer, v, '%');
  //v1.00x9: % except the hysteresis (codes); n/a when the FPGA has no hysteresis
  if(!en)
  {
    buffer[0] = 'n'; buffer[1] = '/'; buffer[2] = 'a'; buffer[3] = 0;
  }
  else
    make_value_to_text(buffer, v, (id == OS_TRIGHYST) ? ' ' : '%');

  display_set_fg_color(en ? YELLOW_COLOR : 0x00666666);
  display_fill_rounded_rect(x + w - 66, y + 6, 40, 16, 2);
  display_set_fg_color(BLACK_COLOR);
  display_text(x + w - 62, y + 7, buffer);

  //Bar: yellow up to the value, grey after it, and the knob
  //display_set_fg_color(YELLOW_COLOR);
  display_set_fg_color(en ? YELLOW_COLOR : 0x00666666);     //v1.00x9
  display_fill_rounded_rect(bx, y + 33, (k > 0) ? k : 1, 9, 3);
  display_set_fg_color(0x00666666);
  display_fill_rounded_rect(bx + k, y + 33, (bw - k > 0) ? (bw - k) : 1, 9, 3);

  display_set_fg_color(0x00AAAAAA);
  display_fill_rounded_rect(bx + k - 10, y + 27, 20, 21, 2);
  display_set_fg_color(BLACK_COLOR);
  display_draw_vert_line(bx + k - 5, y + 31, y + 44);
  display_draw_vert_line(bx + k,     y + 31, y + 44);
  display_draw_vert_line(bx + k + 5, y + 31, y + 44);
}

//----------------------------------------------------------------------------------------------------------------------------------
//Clock rows (v1.00s8): the name, then - value + buttons at the right

static void settings_clock_value_text(int id, char *t)
{
  int v;

  readnameRTC();

  switch(id)
  {
    case OS_HOUR:   v = hour;          break;
    case OS_MINUTE: v = minute;        break;
    case OS_DAY:    v = day;           break;
    case OS_MONTH:  v = month;         break;
    default:        v = 2000 + year;   break;
  }

  if(v >= 1000)
  {
    *t++ = '0' + ((v / 1000) % 10);
    *t++ = '0' + ((v / 100) % 10);
  }

  *t++ = '0' + ((v / 10) % 10);
  *t++ = '0' + (v % 10);
  *t = 0;
}

//x of the - button, the value box and the + button of a clock row of width w
void settings_clock_buttons(int x, int w, int *minus, int *value, int *plus)
{
  *plus  = x + w - 52;
  *value = *plus - 80;
  *minus = *value - 52;
}

//v1.00s9: the buttons as the old RTC panel's (grey with a light edge and an arrow icon), arrow up for +, down for -
static void settings_clock_button(int bx, int y, const uint8 *icon, int active)
{
  display_set_fg_color(active ? ITEM_ACTIVE_COLOR : GREY_COLOR);
  display_fill_rounded_rect(bx, y + 2, 44, 38, 2);
  display_set_fg_color(LIGHTGREY1_COLOR);
  display_draw_rounded_rect(bx, y + 2, 44, 38, 2);

  display_set_fg_color(active ? BLACK_COLOR : WHITE_COLOR);
  display_set_bg_color(active ? ITEM_ACTIVE_COLOR : GREY_COLOR);
  display_copy_icon_use_colors(icon, bx + 10, y + 9, 24, 24);
}

void settings_clock_row(int x, int y, int w, int id, int active)
{
  char t[8];
  int  minus, value, plus;

  settings_clock_buttons(x, w, &minus, &value, &plus);

  settings_clock_button(minus, y, Down_icon, active == 1);
  settings_clock_button(plus, y, Up_icon, active == 2);

  settings_clock_value_text(id, t);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rounded_rect(value, y + 4, 72, 34, 3);
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(value, y + 4, 72, 34, 3);
  display_set_font(&font_3);
  display_set_fg_color(YELLOW_COLOR);
  display_text(value + ((72 - (int)settings_text_width(t)) / 2), y + 13, (int8 *)t);
}

//----------------------------------------------------------------------------------------------------------------------------------

//v1.00t0: the current time of the clock chip, HH:MM:SS, in the middle of its row (updated by handle_settings_page)
void settings_clock_now(int x, int y, int w)
{
  char t[12];

  readnameRTC();

  //filenameRTC: YYMMDD-HHMMSS
  t[0] = filenameRTC[7];  t[1] = filenameRTC[8];  t[2] = ':';
  t[3] = filenameRTC[9];  t[4] = filenameRTC[10]; t[5] = ':';
  t[6] = filenameRTC[11]; t[7] = filenameRTC[12]; t[8] = 0;

  display_set_fg_color(BLACK_COLOR);
  display_fill_rounded_rect(x + (w / 2) - 70, y + 3, 140, 36, 3);
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(x + (w / 2) - 70, y + 3, 140, 36, 3);

  display_set_font(&font_5);
  display_set_fg_color(onoffRTC ? YELLOW_COLOR : 0x00808080);
  display_text(x + (w / 2) - ((int)settings_text_width(t) / 2), y + 9, (int8 *)t);
}

void settings_page_item(int tab, int sec, int idx, int active)
{
  int id = settings_item_id(tab, sec, idx);
  int w  = settings_item_w(tab, sec);
  int x, y;

  settings_item_pos(tab, sec, idx, &x, &y);

  display_set_fg_color((active && (id < OS_HOUR)) ? ITEM_ACTIVE_COLOR : DARKGREY_COLOR);
  display_fill_rounded_rect(x, y, w, settings_row_h(id) - 6, 3);

  //(v1.00s9: no accent stripe at the left of the row, owner's choice)

  //if((id == OS_SCREENBRIGHT) || (id == OS_GRIDBRIGHT))
  if(settings_is_slider(id))     //v1.00x9
  {
    settings_slider_draw(x, y, w, id);
    return;
  }

  if(id == OS_CLOCKNOW)
  {
    settings_clock_now(x, y, w);
    return;
  }

  if((id >= OS_HOUR) && (id <= OS_YEAR))
  {
    //The name, then - value + (active 1 / 2: the - / + button highlighted)
    display_set_font(&font_3);
    display_set_fg_color(WHITE_COLOR);
    display_text(x + 20, y + 13, (int8 *)settings_item_names[id]);
    settings_clock_row(x, y, w, id, active);
    return;
  }

  if(id == OS_DEFSTART)
  {
    //The boot choice shows its firmware
    scope_boot_button(x + 10, y + 10);
  }
  else if(id == OS_I2CAUTO)
  {
    //v1.01b2: the protocol at start (Last = as it was at power off); a tap goes on to the next
    const char *t = scope_dec_start_name();

    display_set_fg_color(active ? BLACK_COLOR : 0x00305870);
    display_fill_rounded_rect(x + 6, y + 8, 56, 26, 2);
    display_set_font(&font_2);
    display_set_fg_color(WHITE_COLOR);
    display_text(x + 34 - (mm_text_width(t) / 2), y + 14, (int8 *)t);
  }
  else if((id == OS_BASECAL) || (id == OS_INPUTCAL) || (id == OS_ADCCAL))     //v1.00y1: + ADC timing
  {
    //An action: a Start button (v1.00t1: blue instead of yellow, owner's choice)
    //display_set_fg_color(active ? BLACK_COLOR : 0x002080FF);
    //v1.00y1: grey when the FPGA has no ADC timing calibration
    //display_set_fg_color(active ? BLACK_COLOR : ((id == OS_ADCCAL) && !FPGA_IS_153F_PORT()) ? 0x00505050 : 0x002080FF);
    //v1.00z0: each calibration its own color: baseline yellow, input divider blue, ADC timing orange (grey without
    //the FPGA for it); black text on yellow / orange, white on blue and grey
    uint32 fill = (id == OS_BASECAL) ? YELLOW_COLOR : (id == OS_INPUTCAL) ? 0x002080FF : FPGA_IS_153F_PORT() ? ORANGE_COLOR : 0x00505050;
    uint32 text = ((fill == YELLOW_COLOR) || (fill == ORANGE_COLOR)) ? BLACK_COLOR : WHITE_COLOR;

    display_set_fg_color(active ? BLACK_COLOR : fill);
    display_fill_rounded_rect(x + 10, y + 10, 46, 22, 2);
    display_set_font(&font_2);
    //display_set_fg_color(WHITE_COLOR);
    display_set_fg_color(active ? WHITE_COLOR : text);
    display_text(x + 17, y + 14, "Start");
  }
  else
  {
    scope_display_slide_button(x + 10, y + 12, settings_item_state(id), (id == OS_DEVMODE) ? RED_COLOR : (id == OS_XYMODE) ? MAGENTA_COLOR : GREEN_COLOR);
  }

  display_set_font(&font_3);
  display_set_fg_color(active ? BLACK_COLOR : WHITE_COLOR);
  display_text(x + 72, y + 13, (int8 *)settings_item_names[id]);

  //v1.00z1: no X-Y in the logger roll: dimmed (the switch does nothing there)
  if((id == OS_XYMODE) && scope_roll_ui())
    display_dim_rect(x, y, w, settings_row_h(id) - 6);
}

static void settings_page_tab(int tab, int selected)
{
  int x = (tab < SETTINGS_TABS) ? (tab * SP_TAB_W) : (800 - SP_TAB_CLOSE_W);
  int w = (tab < SETTINGS_TABS) ? SP_TAB_W : SP_TAB_CLOSE_W;
  const char *t = (tab < SETTINGS_TABS) ? (const char *)settings_tab_names[tab] : "Close";

  uint32 accent = (tab < SETTINGS_TABS) ? settings_tab_colors[tab] : 0x00C0C0C0;

  //The selected tab filled with its accent color, the others dark with an accent line at the bottom
  display_set_fg_color(selected ? accent : DARKGREY_COLOR);
  display_fill_rounded_rect(x + 3, 4, w - 6, SP_TAB_H - 6, 3);

  if(!selected)
  {
    display_set_fg_color(settings_dim(accent));
    display_fill_rect(x + 8, SP_TAB_H - 7, w - 16, 3);
  }

  display_set_font(&font_3);
  display_set_fg_color(selected ? BLACK_COLOR : WHITE_COLOR);
  display_text(x + ((w - (int)settings_text_width(t)) / 2), 15, (int8 *)t);
}

//A framed section with its heading
static void settings_page_section(int tab, int sec)
{
  int x = settings_section_x(tab, sec);
  int y = settings_section_y(tab, sec);
  int w = settings_section_w(tab, sec);
  int h = settings_section_h(tab, sec);
  int i;

  //Frame in the dimmed accent color, the heading in the accent color over the frame line
  display_set_fg_color(settings_dim(settings_tab_colors[tab]));
  display_draw_rounded_rect(x, y + 7, w, h - 7, 4);

  display_set_font(&font_2);
  display_set_fg_color(SP_PAGE_BG);
  display_fill_rect(x + 10, y, settings_text_width(settings_sections[tab][sec].title) + 10, 15);
  display_set_fg_color(settings_tab_colors[tab]);
  display_text(x + 15, y + 1, (int8 *)settings_sections[tab][sec].title);

  for(i = 0; i < settings_section_count(tab, sec); i++)
    settings_page_item(tab, sec, i, 0);
}

//Draw the whole page with tab 'tab' selected
void settings_page_draw(int tab)
{
  int i;

  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(0, 0, 800, 480);

  for(i = 0; i <= SETTINGS_TABS; i++)
    settings_page_tab(i, i == tab);

  //v1.00s8: a frame around the page under the tabs in the selected tab's accent color, a dark background inside it
  display_set_fg_color(SP_PAGE_BG);
  display_fill_rounded_rect(2, SP_TAB_H + 2, 796, 480 - SP_TAB_H - 4, 6);
  display_set_fg_color(settings_dim(settings_tab_colors[tab]));
  display_draw_rounded_rect(2, SP_TAB_H + 2, 796, 480 - SP_TAB_H - 4, 6);

  for(i = 0; i < SETTINGS_SECTIONS; i++)
  {
    if(settings_sections[tab][i].title)
      settings_page_section(tab, i);
  }
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.00t0: a Yes / No confirmation dialog in the middle of the screen (the screen under it is saved in displaybuffer3)

#define CONFIRM_X     190
#define CONFIRM_Y     150
#define CONFIRM_W     420
#define CONFIRM_H     170

//v1.00z0: the frame color of the dialog (red; a caller sets green for a good result and red back after it)
uint32 settings_confirm_frame = RED_COLOR;

void settings_confirm_draw(const char *line1, const char *line2, const char *line3, int active)
{
  display_set_screen_buffer((uint16 *)maindisplaybuffer);

  display_set_fg_color(DARKGREY_COLOR);
  display_fill_rounded_rect(CONFIRM_X, CONFIRM_Y, CONFIRM_W, CONFIRM_H, 5);
  //display_set_fg_color(RED_COLOR);
  display_set_fg_color(settings_confirm_frame);     //v1.00z0: red, green for a good result
  display_draw_rounded_rect(CONFIRM_X, CONFIRM_Y, CONFIRM_W, CONFIRM_H, 5);
  display_draw_rounded_rect(CONFIRM_X + 1, CONFIRM_Y + 1, CONFIRM_W - 2, CONFIRM_H - 2, 5);

  display_set_font(&font_3);
  display_set_fg_color(WHITE_COLOR);
  display_text(CONFIRM_X + ((CONFIRM_W - (int)settings_text_width(line1)) / 2), CONFIRM_Y + 18, (int8 *)line1);
  display_set_fg_color(0x00C0C0C0);
  display_text(CONFIRM_X + ((CONFIRM_W - (int)settings_text_width(line2)) / 2), CONFIRM_Y + 44, (int8 *)line2);
  display_text(CONFIRM_X + ((CONFIRM_W - (int)settings_text_width(line3)) / 2), CONFIRM_Y + 64, (int8 *)line3);

  //No on the left (the safe choice), Yes on the right
  display_set_fg_color((active == 1) ? ITEM_ACTIVE_COLOR : GREY_COLOR);
  display_fill_rounded_rect(CONFIRM_X + 40, CONFIRM_Y + 106, 140, 44, 3);
  display_set_fg_color((active == 2) ? ITEM_ACTIVE_COLOR : 0x00A02020);
  display_fill_rounded_rect(CONFIRM_X + CONFIRM_W - 180, CONFIRM_Y + 106, 140, 44, 3);

  display_set_fg_color(WHITE_COLOR);
  display_text(CONFIRM_X + 40 + ((140 - (int)settings_text_width("No")) / 2), CONFIRM_Y + 119, "No");
  display_text(CONFIRM_X + CONFIRM_W - 180 + ((140 - (int)settings_text_width("Yes")) / 2), CONFIRM_Y + 119, "Yes");
}

//Which button is at a touch position: 1 No, 2 Yes, 0 none
int settings_confirm_at(int x, int y)
{
  if((y < (CONFIRM_Y + 106)) || (y >= (CONFIRM_Y + 150)))
    return(0);

  if((x >= (CONFIRM_X + 40)) && (x < (CONFIRM_X + 180)))
    return(1);

  if((x >= (CONFIRM_X + CONFIRM_W - 180)) && (x < (CONFIRM_X + CONFIRM_W - 40)))
    return(2);

  return(0);
}

//Show the dialog and wait for Yes (1) or No (0); the screen under it is put back
int settings_confirm(const char *line1, const char *line2, const char *line3)
{
  int b;

  display_set_destination_buffer(displaybuffer3);
  display_copy_rect_from_screen(CONFIRM_X, CONFIRM_Y, CONFIRM_W, CONFIRM_H);

  settings_confirm_draw(line1, line2, line3, 0);

  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    b = settings_confirm_at(xtouch, ytouch);

    if(b)
    {
      settings_confirm_draw(line1, line2, line3, b);
      tp_i2c_wait_for_touch_release();
      break;
    }

    //Elsewhere: nothing, wait for a button
    tp_i2c_wait_for_touch_release();
  }

  display_set_source_buffer(displaybuffer3);
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_copy_rect_to_screen(CONFIRM_X, CONFIRM_Y, CONFIRM_W, CONFIRM_H);

  return(b == 2);
}

//----------------------------------------------------------------------------------------------------------------------------------
//v1.01b2: the width of a text in the current (variable width) font, for centred texts of other files
uint32 scope_text_width(const char *text)
{
  return(mm_text_width(text));
}

//v1.01b2: the decoder page of the right bar (CTRL: main -> V/div -> decoder -> main): Decoder (opens its window,
//shows the protocol and ON / OFF) and List
//v1.01b3: the buttons are 42 high and sit on the V/div page under CTRL (y 59 and 105)
static void scope_right_dec_button(int32 y, const char *l1, const char *l2, uint32 fill, uint32 text, int mode)
{
  display_set_fg_color(mode ? ITEM_ACTIVE_COLOR : fill);
  display_fill_rounded_rect(739, y, 51, RIGHT_DEC_BUTTON_H, 2);
  display_set_fg_color(0x00505050);
  display_draw_rounded_rect(739, y, 51, RIGHT_DEC_BUTTON_H, 2);

  display_set_font(&font_2);
  display_set_fg_color(mode ? BLACK_COLOR : text);
  display_text(765 - (mm_text_width(l1) / 2), y + 5, (int8 *)l1);     //v1.01b5: 40 high (y + 6 / + 22 at 42)
  display_text(765 - (mm_text_width(l2) / 2), y + 21, (int8 *)l2);
}

#if 0     //v1.01b3: the protocol and ON / OFF
void scope_right_decoder_button(int mode)
{
  scope_right_dec_button(RIGHT_DEC_BUTTON1_Y, scope_dec_name(), scope_i2c_enabled ? "ON" : "OFF", scope_i2c_enabled ? 0x00305830 : DARKGREY_COLOR, WHITE_COLOR, mode);
}
#endif

//v1.01b4: "Decode" and under it the protocol with on / off ("I2C on"; 1-Wire as "1W" and small letters, so
//"UART off" fits the button), in the protocol's colour when on, grey when off
void scope_right_decoder_button(int mode)
{
  char        t[16], *p = t;
  const char *n = scope_dec_name(), *s = scope_i2c_enabled ? " on" : " off";

  if(n[0] && (n[1] == '-'))
  {
    //1-Wire
    *p++ = n[0];
    *p++ = n[2];
  }
  else
    while(*n && (p < (t + 8))) *p++ = *n++;

  while(*s) *p++ = *s++;
  *p = 0;

  scope_right_dec_button(RIGHT_DEC_BUTTON1_Y, "Decode", t, scope_i2c_enabled ? scope_dec_color() : DARKGREY_COLOR,
                         scope_i2c_enabled ? BLACK_COLOR : WHITE_COLOR, mode);
}

void scope_right_list_button(int mode)
{
  scope_right_dec_button(RIGHT_DEC_BUTTON2_Y, "Decode", "List", 0x00304870, WHITE_COLOR, mode);
}
