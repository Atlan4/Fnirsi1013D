# FNIRSI 1013D – zhrnutie práce (stav k 26. 11. 2026, firmvér v1.00v9)

Tento súbor slúži na pokračovanie v novom chate. Stačí ho vložiť na začiatok konverzácie.

## 1. Projekt a priečinky

| Čo | Kde |
|---|---|
| Firmvér (Atlan základ, cesta B, vlastné FPGA 0x2000) | `/home/dk/Desktop/Fnirsi_1013d/FNIRSI_1013D_Firmware-main/fnirsi_1013d_scope` |
| Zálohy verzií | `.../FNIRSI_1013D_Firmware-main/zaloha moje scope/fnirsi_1013d_scope vX.XXxN/` + `scope vX.XXxN.bin` |
| MCP firmvér (zdroj nápadov a kódu) | `/home/dk/Downloads/fnirsi-1013d-mcp-main` |
| Vlastné FPGA (aktuálne používané) | `/home/dk/Desktop/AnLogic/FPGA EF2L45` (verzia 0x2000) |
| Port MCP FPGA 0x153F na EF2L45 (pozastavené) | `/home/dk/Desktop/AnLogic/FPGA EF2L45 153F` (verzia 0x253F) |
| MCP-zlúčený firmvér (nepoužíva sa) | `fnirsi_1013d_scope ncp.zip` |

## 2. Pravidlá a konvencie

- Odpovede a diskusia **po slovensky**. **Komentáre v kóde po anglicky.**
- Keď Dusan len **diskutuje**, kód sa **nemení**, kým to výslovne nepovie („môžeš generovať kód“).
- Každá zmena = nová verzia v `variables.h`: len **jeden** riadok `#define VERSION_STRING "v1.00xN" // krátky popis` (bez starých verzií v komentároch). Po `x9` ide ďalšie písmeno a `0` (napr. v1.00v9 → **v1.00w0**).
- Po každej verzii záloha: `rsync` priečinka bez `build/` a `dist/` do `zaloha moje scope/fnirsi_1013d_scope vX/`, plus `scope vX.bin`.
- Build na kontrolu: skopírovať zdrojáky do dočasného priečinka a spustiť `make -f nbproject/Makefile-Debug.mk CONF=Debug SUBPROJECTS= .build-conf`, potom `arm-none-eabi-objcopy -O binary ... .elf ... .bin` a `./mksunxi ... .bin`. **Pozor:** `.build-post` v Makefile kopíruje na SD karty (`/media/dk/*`) a do `../../firmware_Atlan_Peco`.
- Nový `.c` súbor treba pridať do `nbproject/Makefile-Debug.mk`, `Makefile-Release.mk` aj `configurations.xml`, a pri tom musí byť **NetBeans zatvorený**.
- Starý kód radšej zakomentovať (alebo `#if 0`) ako zmazať.
- UI: vzdušné rozloženie, žiadne farebné pruhy vľavo pri riadkoch, malé posuvníky, tlačidlá v štýle existujúcich.

## 3. Úskalia (gotchas)

- `int8` = `char` = **unsigned** na ARM, takže pre hodnotu -1 treba `signed char`.
- `strlen` ani `sin` (libm) nie sú linkované. Treba vlastné náhrady (je aj `sin_cos_math.c`).
- `scope_set_timebase()` zapíše sample rate do FPGA **len pri runstate = 1**. Pri obnove nastavení treba dočasne nastaviť runstate = 1.
- `scope_preset_values()` volá `scope_display_trace_data`, ktoré pri aktívnom spektre alebo Bode overlay osciloskopu preskočí.
- Akvizícia je sekvenčná: ďalšia konverzia začína až po kroku zobrazenia.
- Náhľad (`THUMBNAILDATA.filename[33]`) obsahuje cestu, meno, `\0` a RTC pečiatku. Názov priečinka môže mať preto **najviac 11 znakov** vrátane lomítok.
- V spektre a Bode nie je roll mode: `scope_set_timebase` pri aktívnom spektre alebo Bode drží `timeperdiv >= 11`.

## 4. Hotové funkcie (podľa verzií)

| Verzia | Čo |
|---|---|
| q4 | Trigger porovnáva len ADC jadro A (`trigger_A = level - kompenzácia`), vyhladzovanie batérie |
| q5 | Hlavné MENU s 8 riadkami ako MCP (`MM_ROW_*`, `scope_main_menu_item`) |
| q6–s0 | **Spektrálny analyzátor** (`spectrum.c/.h`, `fx_fft.c` z MCP): FFT, 7 tlačidiel pod grafom s vyskakovacími zoznamami, THD, priemerovanie v dB, F/L kurzory, vlastné MEASURES, AUTO SET (bez prepínania V/div), čísla v rámikoch |
| s1 | Oprava `display_fill_rect` (posledný stĺpec a riadok) |
| s2–s3 | Posuvník záznamu s prehľadom (record overview) a oprava skoku na začiatok |
| s4–t1 | **Nastavenia** ako celá obrazovka so záložkami (Display, Measure, Startup, Files & USB, Service, Clock), rámované sekcie, farebné akcenty, hodiny so šípkami, kalibrácia vstupného deliča s potvrdením, priehľadné merania |
| s6 | Spektrum a osciloskop majú každý vlastnú časovú základňu a trigger |
| t1–v1 | **Frekvenčná charakteristika (Bode)** (`bode.c/.h`): DDS generátor (FPGA 0x50/0x51/0x52, 50 MHz, `phase_inc = (f_mHz<<26)/781250000`), CH1 = vstup, CH2 = výstup, Hann DFT na jednej frekvencii, Auto range s hysterézou, markery (-3 dB, peak, fáza -45/-90/-180), všetky MCP merania, Thru kalibrácia, kurzory C1/C2 (nikdy zamknuté) so sklonom v dB/dek, otvára sa v STOP, tlačidlo CLEAR CHART |
| v2 | Nastavenia Bode v nastavovacom sektore (offset 208, magic 0xB0DE) |
| v3 | SAVE BODE / SAVE SPEC (súbory `.bod` v `\bode\` a `.spc` v `\spectrum\`), náhľady, prehliadače, CSV export (scope, Bode, spektrum, každé zvlášť) |
| v4 | Nastavenia spektra v sektore (offset 216, magic 0x5EC7) |
| v5 | Náhľad SAVE WAVE v roll móde ukazuje krivky, poradie CSV ako v MENU |
| v6 | Spektrum a Bode bez roll módu (zo spektra roll → 1 ms/div), vlastné priečinky obrázkov `\pic_scope\` (starý `\pictures\` sa premenuje sám), `\pic_bode\`, `\pic_spec\`, názvy v MENU podľa režimu („Bode pictures“, „Saved Bode“, „Spectrum pictures“, „Saved spectrum“), po prezeraní obrázkov sa Bode sám nespustí |
| v7 | Prehliadač uloženého Bode a spektra má pravý panel: Next/Prev, kurzory, MEASURES (v Bode MARKERS), SAVE PICTURE, Delete. Meno súboru s dátumom pri RTC, nepoužiteľné tlačidlá sú sivé |
| v8 | ACQ menu má nový stĺpec „More“ (2 voľné pozície), nové režimy kreslenia **Auto** (Linear/Peak podľa vzoriek na pixel) a **Sin x** (Lanczos sinc, 8 vzoriek, 32 fáz). Oprava pretečenia bufferov trace points pri Peak a Pro (730 → 1464) |
| v9 | V ACQ menu je pri Auto a Sin x zelené písmo pri režime, ktorým sa práve kreslí |

## 5. Dôležité miesta v kóde

- `variables.h`: VERSION_STRING, `MM_ROW_*`, `VIEW_TYPE_*` (0 scope pic, 1 wave, 2 ref, 3 bode, 4 spectrum, 5 bode pic, 6 spec pic, `VIEW_TYPE_IS_PICTURE`), `CSV_EXPORT_*`, `TRACE_MODES`, `ACQ_MENU_*`, offsety nastavení.
- `variables.c`: `view_file_path`, `view_file_extension`, `thumbnail_file_names`, `trace_texts`.
- `scope_functions.c`:
  - Háčiky pre spektrum a Bode v `scope_display_trace_data`, `scope_acquire_trace_data` a `scope_preset_values`.
  - Ukladanie (`scope_save_view_item_file`) a náhľady (`scope_create_thumbnail`, `scope_thumbnail_fix_paths`).
  - CSV (`csv_*`, `scope_csv_write_waveform`).
  - Režimy kreslenia (`scope_display_channel_*_trace`, `scope_trace_mode_in_use`, `scope_picture_view_type`, `scope_display_saved_file_name`).
- `menu.c`: hlavné MENU (`mm_line1/2`, popisy podľa režimu), stránka nastavení (`settings_sections`), ACQ menu (`scope_open_acquisition_menu`, `scope_acquisition_trace_select`), pravý panel prehliadača (`scope_saved_view_right_menu`).
- `statemachine.c`: dotyky MENU, `handle_settings_page`, `handle_right_basic_menu_touch`, `handle_saved_view_right_touch`, ACQ menu.
- `spectrum.c`, `bode.c`: celé režimy vrátane `*_settings_save/load`, `*_file_write/read`, `*_csv_write`, `*_fill_thumbnail`, `*_view_file`.
- `DS3231.c`: RTC, `decodethumbnailfilename` (meno za posledným `\`).

## 6. Otvorené body a nápady

**Zobrazenie (z návrhu, zatiaľ neschválené):**
3. Persistencia / dosvit (Off / 1 s / 3 s / nekonečno), buffer jasu pre každý pixel.
4. Lepší Pro: priestor medzi min a max vyplnený tlmenou farbou, stred jasnou čiarou.
5. Hi-Res: priemer vzoriek v pixeli.
6. Average s voliteľným počtom 2/4/8/16 (teraz vždy (nový + starý)/2).
7. Hrubšia čiara (2 px) ako nastavenie.
- Stĺpec „More“ v ACQ menu má 2 voľné pozície a hornú časť voľnú.

**Bode (ponúknuté z porovnania s MCP, Dusan zatiaľ nevybral):** kontrola ustálenia, šumové dno, dôvod sivého bodu, lepší AUTO SET, posuvník, lineárna os / body / mriežka, jednorazový sweep, výber meraní, rozsah 1 Hz – 10 MHz. Otvorená je aj otázka, či má AUTO SET v Bode meniť rozsah Start/Stop (napr. ×100 alebo ponechať vyšší Stop).

**Neodskúšané na prístroji:** v5 až v9 (roll náhľad, priečinky obrázkov a ich premenovanie, prehliadač s pravým panelom, Auto a Sin x, oprava bufferov).

## 7. FPGA

- **Aktuálne sa používa** vlastné `FPGA EF2L45` (Anlogic EF2L45LG144B), verzia **0x2000**:
  - Pamäť má 6144 slov.
  - Trigger je len na jadre A, jedna úroveň cez príkaz 0x17 (0x18 je len na čítanie).
  - DDS generátor je na kalibračnom pine (0x50 zapnutie, 0x51 phase_inc, 0x52 strieda).
  - Bitstream si Dusan zostavuje sám v Anlogic TD 5.0.3.
- Schéma verzií (`fpga_get_version`), horný nibble určuje rodinu:
  - 1 = originál FNIRSI (0x1432),
  - 2 = Dusanove EF2 (0x2000, plánované 0x25xx),
  - 3 = AL3 (8192),
  - 4 = EP4 (8192).
- **Port MCP 0x153F na EF2L45 = verzia 0x253F** (`/home/dk/Desktop/AnLogic/FPGA EF2L45 153F`), **pozastavené a neodskúšané**:
  - Vypnuté sú sekvencer, FIR a HW čítač (`EF2_NO_SEQ`, `EF2_NO_FIR`, `EF2_NO_COUNTER`). Pamäť má 8192 slov (6 × ERAM32K + 8 × ERAM9K).
  - Nový príkaz **0x19 = hysterézia triggera** v kódoch ADC (0 = správanie ako 0x153F). Príkaz 0x06 vracia 0x25 0x3F.
  - Zmeny sú v `diff_0x253F_vs_0x153F.patch`, originál je `zaklad.v.orig_153F`, návod v `README_EF2.md`.
  - Treba ešte overiť v TD (LUT/registre pod 4480, timing 0 errors) a **na strane firmvéru 0x253F nie je nič urobené** (rozlíšenie rodiny 2 podľa nižších bitov, 8192 vzoriek, zápis 0x19).
