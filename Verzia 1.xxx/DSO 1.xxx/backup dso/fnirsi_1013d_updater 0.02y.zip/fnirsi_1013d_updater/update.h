/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   update.h
 * Author: dk
 *
 * Created on October 2, 2025, 9:59 AM
 */

#ifndef UPDATE_H
#define UPDATE_H

#include "types.h"

//------------------------------------------------------------------------------

//define sector on SDcart
#define BOOT_PROGRAM_START_SECTOR      16
#define UPDATE_PROGRAM_START_SECTOR    80
#define DSO_PROGRAM_START_SECTOR      750

#define CALIBRATION_DATA_SECTOR       708
#define DSO_SETTINGS_SECTOR           709
#define TP_DISPLAY_CONFIG_SECTOR      710

//=========================================

//define address on FLASH SPI
#define DSO_FIRMWARE_ADDRESS      0x13000
//#define FPGA_START_ADDRESS          0x00

//------------------------------------------------------------------------------

void ini_folders(void);
void create_directory_if_missing(char* dirname, int16 x, int16 y);
void create_info_firmware_file_if_missing(int16 x);
void check_firmware_files(void);

void check_file(const char *path, int x, int y,  int shift);
int8 starts_with(const char *str, const char *prefix);
int8 ends_with(const char *str, const char *suffix);

int read_sdcard_to_file_with_progress(const char* filename, uint32 start_sector, uint32 num_sectors);

//int write_file_to_sdcard_with_progress(const char* folder, const char* prefix, uint32 start_sector);

int write_file_to_sdcard_with_progress(const char* filename, uint32 start_sector);
void text_and_touch_the_screen(int16 x);

int read_spi_flash_to_file_with_progress(const char* filename);
int write_file_to_spi_flash_with_progress(const char* filename, uint32 start_address);

//int write_file_to_spi_flash_with_progress(const char* filename);


void progress_bar_init(void);
void progress_bar_update(uint32 current_step, uint32 total_steps);
void calculate_progress_delay(uint32 num_sectors);

void button_enable(void);
void button_disable(void);

const char *my_strstr(const char *haystack, const char *needle);
int my_strcmp(const char *s1, const char *s2);
char *my_strrchr(const char *s, int c);
char *my_strcpy(char *dest, const char *src);
char *my_strncpy(char *dest, const char *src, int n);
int my_strlen(const char *s);
void my_sprintf_path(char *dst, const char *folder, const char *fname);
int my_strcasecmp(const char *s1, const char *s2);

int32 load_picture(const char* filename);

void load_from_SDcard(uint32 address);

//v0.02w: size checks and "Extend reserve to 4 MB"
#define RSV_BTN_X   535
#define RSV_BTN_Y   296
#define RSV_BTN_W   120
#define RSV_BTN_H   40
extern uint8 upl_block_boot, upl_block_upd, upl_block_dso;
uint32 sd_partition_start(void);
uint32 sd_area_bytes(uint32 start_sector);
void   sd_reserve_panel(uint32 dso_size);
uint32 sd_reserve_button_shown(void);
void   sd_extend_reserve(void);
extern uint8 updater_fpga_written;
void   updater_exit_restart(void);
//void update_procedure(void);
//void create_directory_if_missing(const char *dirname, uint16 y);

//DWORD get_fattime (void);

#endif /* UPDATE_H */

