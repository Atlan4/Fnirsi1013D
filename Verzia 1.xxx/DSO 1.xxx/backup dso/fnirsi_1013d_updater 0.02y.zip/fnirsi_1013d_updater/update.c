

#include "update.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "variables.h"
#include "types.h"
#include "timer.h"
//#include "scope_functions.h"
#include "menu.h"
#include "touchpanel.h"
#include "spi_control.h"

//#include <string.h>

//---------------------------------------------------------------------

//v0.02w: the reserve and size checks (at the end of this file)
static char *rsv_num(char *p, uint32 v);
static char *rsv_str(char *p, const char *s);
static int32 rsv_text_w(const char *text);
extern uint8  upl_block_boot, upl_block_upd, upl_block_dso;
extern uint32 rsv_dso_size;

#define TOTAL_PROGRESS_STEPS 56//57 50
uint32 progress_delay = 5; // default value in milliseconds (can be modified when calling the function)
//#define TOTAL_WRITE_TIME_MS 200
//#define DELAY_PER_STEP_MS (TOTAL_WRITE_TIME_MS / TOTAL_PROGRESS_STEPS)

// Global progress bar buffer
char progress_bar[TOTAL_PROGRESS_STEPS + 3]; // '[' + 50 steps + ']' + '\0'
uint32 last_progress_index = 0;
//uint32 speed;
//uint32 DELAY_PER_STEP_MS;


#define SECTOR_SIZE 512
//Buffer for reading/writing from SD card
//unsigned char buffer[SECTOR_SIZE];

//******************************************************************************
//******************************************************************************

void ini_folders(void) 
{
  int16  x = WIN1_XPOS + 20;
  
  //Save the screen rectangle where the menu will be displayed
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
  //Draw the background in grey
  display_set_fg_color(GREY_COLOR);

  //Fill the background
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  
  display_set_font(&font_2);
  
  //Setup and check SD card on file system being present
  if(f_mount(&fs, "0", 1))
  {
    //Show SD card error message on failure
    //Display the message in red
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 10, "SD MOUNT ERROR");

    //On error just hang
    while(1);
  }
  
  //Display the message in white
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);  
  
  display_text(x, WIN1_YPOS + 10, "Search folders...");
  

  
/*
   create_directory_if_missing("firmware_FNIRSI", x, WIN1_YPOS+40);
  create_directory_if_missing("firmware_FNIRSI_FPGA", x, WIN1_YPOS+55);
  
  create_directory_if_missing("firmware Atlan & PECO", x, WIN1_YPOS+70);
  create_directory_if_missing("firmware Atlan & PECO FPGA", x, WIN1_YPOS+85);
  
  create_directory_if_missing("firmware_FNIRSI_BACKUP", x, WIN1_YPOS+100);
 */
  create_directory_if_missing("firmware_FNIRSI_FPGA", x, WIN1_YPOS+40);
  
  create_directory_if_missing("firmware Atlan & PECO", x, WIN1_YPOS+55);
  create_directory_if_missing("firmware Atlan & PECO FPGA", x, WIN1_YPOS+70);
  
  //Check TXT file, create if missing
  create_info_firmware_file_if_missing(x);
  
  timer0_delay(1000);
  
  //Restore the screen when done
  display_set_source_buffer(displaybuffertmp);
  display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
}
    
//------------------------------------------------------------------------------

void create_directory_if_missing(char* dirname, int16 x, int16 y)  
{
  int32  result;    
  
  //Check the status of the directory for this view type
  result = f_stat(dirname, 0);

  //See if there is an error
  if(result != FR_OK)
  {
    //If so check if the directory does not exist
    if(result == FR_NO_FILE)
    {
      //Draw the background in grey
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x + 150, WIN1_YPOS + 10, 35, 14);//135
      
      //Display the message in red
      display_set_fg_color(RED_COLOR);
      display_text(x + 155, WIN1_YPOS + 10, "FAIL");//140
      
      //Create the directory
      result = f_mkdir(dirname);
      
      //Display the message in green
      display_set_fg_color(GREEN_COLOR);
      display_text(x, WIN1_YPOS+25, "Create folder:");
     
      //Show a message creating the directory
      //Display the message in white
      display_set_fg_color(WHITE_COLOR);
      display_text(x, y, dirname);
      timer0_delay(1000);
      
      if(result != FR_OK)
      {
        //Show a message stating creating the directory failed
        //Display the message in red
        display_set_fg_color(RED_COLOR);
        display_set_font(&font_2);
        display_text(x, WIN1_YPOS + 40, "MESSAGE_DIRECTORY_CREATE_FAILED");
        
        //On error just hang
        while(1);
      }
    }
  } 
  else 
  {      
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    //display_set_fg_color(YELLOW_COLOR);
    display_fill_rect(x + 150, WIN1_YPOS + 10, 35, 14);//135-10-35-14
    display_set_fg_color(GREEN_COLOR); 
    display_text(x + 155, WIN1_YPOS + 10, "OK");//140
    //display_set_fg_color(YELLOW_COLOR);
    //display_fill_rect(x + 150, WIN1_YPOS + 20, 35, 14);//135
    //display_set_fg_color(GREEN_COLOR);
    //display_text(x + 155, WIN1_YPOS + 20, "FAIL");
    //while(1); 
  }     
}

//******************************************************************************

// Main firmware info file creation/update
void create_info_firmware_file_if_missing(int16 x)
{
  FIL file;
  FRESULT res;
  const char *filename = "info_firmware.txt";
  const char *content =
    "************************************************************************************\r\n"
    "Updater firmware: " VERSION_STRING "\r\n"
    "------------------------------------------------------------------------------------\r\n"
    "Boot Loader      - bootloader.bin\r\n"
    "Updater          - updater.bin\r\n"
    "DSO firmware     - scope.bin\r\n"
    "FPGA firmware    - FPGA.bin                ( Hardware modification required )\r\n"
    "\r\n"
    "Calibration data - data.cal                ( Backup file for: Calibration data )\r\n"
    "Touch pad and screen data - TP_Screen.bin  ( Backup file for: TP & screen settings )\r\n"
    "------------------------------------------------------------------------------------\r\n"
    "FPGA Flash       - Fnirsi FPGA.bin         ( Hardware modification required )\r\n"
    "************************************************************************************\r\n"
    "updater.bmp      - updater program startup image\r\n"
    "scope.bmp        - scope program startup image\r\n"
    "************************************************************************************\r\n";

  FILINFO fno;
  res = f_stat(filename, &fno);

  uint8 file_exists = 0;
  uint8 need_update = 0;

  if (res == FR_OK)
  {
    file_exists = 1; // file already exists
      
    // File exists — check if version matches
    res = f_open(&file, filename, FA_READ);
    if (res == FR_OK)
    {
      char buffer[256];  // read only the beginning of the file
      UINT bytes_read;
      f_read(&file, buffer, sizeof(buffer) - 1, &bytes_read);
      f_close(&file);

      buffer[bytes_read] = '\0';

      // Find the line containing "Updater firmware:"
      const char *ver_line = my_strstr(buffer, "Updater firmware:");
      if (ver_line)
      {
        // Move pointer to version string
        ver_line += strlen("Updater firmware:");
        while (*ver_line == ' ' || *ver_line == '\t') ver_line++;

        // Extract version from file
        char version_in_file[64] = {0};
        int i = 0;
        while (*ver_line && *ver_line != '\r' && *ver_line != '\n' && i < (int)(sizeof(version_in_file) - 1))
        {
          version_in_file[i++] = *ver_line++;
        }
        version_in_file[i] = '\0';

        // Compare with program version
        if (my_strcmp(version_in_file, VERSION_STRING) != 0) need_update = 1;
      }
      else
      {
        // No version line found → update required
        need_update = 1;
      }
    }
    else
    {
      // Could not open file for reading → update required
      need_update = 1;
    }
  }
  else
  {
    // File does not exist → create new one
    need_update = 1;
    file_exists = 0;
  }
    
  //set font
  display_set_font(&font_2);
    
  if (need_update)
  {
    // Show message: creating or updating file
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x, WIN1_YPOS + 115, 165, 14);//x+10
        
    if (file_exists)
    {
      display_set_fg_color(ORANGE_COLOR);
      //display_text(x + 5, WIN1_YPOS + 115, "info_firmware.txt updated");
      display_text(x + 13, WIN1_YPOS + 115, "Updating info_firmware.txt");//3
    }
    else
    {
      display_set_fg_color(YELLOW_COLOR);
      display_text(x + 14, WIN1_YPOS + 115, "Creating info_firmware.txt");//3
    }

    timer0_delay(1000);//2

    // Open or create new file for writing
    res = f_open(&file, filename, FA_WRITE | FA_CREATE_ALWAYS);
    if (res == FR_OK)
    {
      UINT bytes_written;
      res = f_write(&file, content, strlen(content), &bytes_written);
      f_close(&file);

      if (res == FR_OK && bytes_written == strlen(content))
      {
        //Draw the background in grey
        display_set_fg_color(GREY_COLOR);
        display_fill_rect(x, WIN1_YPOS + 130, 165, 14);
        display_set_fg_color(GREEN_COLOR);
        //display_text(x + 5, WIN1_YPOS + 115, "info_firmware.txt updated");
        if (file_exists) display_text(x + 15, WIN1_YPOS + 130, "info_firmware.txt updated");//5-130
          else display_text(x + 16, WIN1_YPOS + 130, "info_firmware.txt created");
        timer0_delay(2000);//3
        //while(1);
      }
      else
      {
        //Write error
        //Draw the background in grey
        display_set_fg_color(GREY_COLOR);
        display_fill_rect(x + 18, WIN1_YPOS + 130, 145, 14);
        display_set_fg_color(RED_COLOR);
        display_text(x + 34, WIN1_YPOS + 130, "Write in txt file - Fail");//25
        //display_text(x + 25, WIN1_YPOS + 115, "Write error in txt file");
        timer0_delay(5000);//5000
      }
    }
    else
    {
      // Failed to create or open file for writing
      //Draw the background in grey
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x, WIN1_YPOS + 130, 180, 14);
      //Display the message in red
      display_set_fg_color(RED_COLOR);
      display_text(x + 1, WIN1_YPOS + 130, "MESSAGE_FILE_CREATE_FAILED");
      while (1);
    }
  }
  else
  {
    // File is up to date
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x + 18, WIN1_YPOS + 130, 145, 14);
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 28, WIN1_YPOS + 130, "info_firmware.txt - OK");
    //while(1); 
  }
}

//******************************************************************************

void check_firmware_files(void)
{
  //v0.02w: set again by check_file (a missing folder leaves them 0)
  upl_block_boot = 0;
  upl_block_upd  = 0;
  upl_block_dso  = 0;
  rsv_dso_size   = 0;

  check_file("firmware Atlan & PECO/bootloader.bin", 145, 131, 8);//
  check_file("firmware Atlan & PECO/updater.bin", 145, 191, 11);//
  check_file("firmware Atlan & PECO/scope.bin", 145, 251, 14);//
  check_file("firmware Atlan & PECO FPGA/FPGA.bin", 145, 311, 40);
  check_file("firmware Atlan & PECO/data.cal", 145, 375, 40 );//
  check_file("firmware Atlan & PECO/TP_Screen.bin", 145, 435, 25);
  
  //check_file("firmware_FNIRSI/Fnirsi 1013D.bin", 535, 131, 20);//
  //check_file("firmware_FNIRSI_FPGA/Fnirsi FPGA.bin", 535, 191, 23);
  check_file("firmware_FNIRSI_FPGA/Fnirsi FPGA.bin", 535, 131, 23);
  
  //check_file("firmware_FNIRSI_BACKUP/Fnirsi backup.bin", 535, 311, 18);

  //v0.02w: the reserve of the card and the Extend button
  sd_reserve_panel(rsv_dso_size);
}

//------------------------------------------------------------------------------

void check_file(const char *path, int x, int y,  int shift)
{
    char folder_path[128];
    char base_prefix[32];
    FILINFO fno;
    DIR dir;
    int32 result;
    int8 file_found = 0;

// Split 'path' into folder and base filename
    const char *slash = my_strrchr(path, '/');
    if (slash) {
        my_strncpy(folder_path, path, slash - path);
        folder_path[slash - path] = '\0';
        my_strcpy(base_prefix, slash + 1);
    } else {
        my_strcpy(folder_path, "");
        my_strcpy(base_prefix, path);
    }

    // Remove ".bin" or ".cal" extension from base_prefix if present
    char *dot = (char *)my_strstr(base_prefix, ".bin");
    if (!dot)
        dot = (char *)my_strstr(base_prefix, ".cal");
    if (dot)
        *dot = '\0';

    // Try to open target folder
    result = f_opendir(&dir, folder_path);
    if (result != FR_OK) {
        display_set_fg_color(RED_COLOR);
        display_draw_rounded_rect(x, y, 127, 22, 3);
        display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
        display_text(x + 18, y + 4, "Folder missing!");
        return;
    }

    // Search for matching files in the folder
    while (f_readdir(&dir, &fno) == FR_OK && fno.fname[0]) {
        if (!(fno.fattrib & AM_DIR)) {
            // Match file starting with base_prefix and ending with ".bin" or ".cal"
            if (starts_with(fno.fname, base_prefix) &&
                (ends_with(fno.fname, ".bin") || ends_with(fno.fname, ".cal"))) {
                file_found = 1;
                break;
            }
        }
    }
    f_closedir(&dir);

    // Draw background
    display_set_font(&font_2);
    display_set_fg_color(WHITE_COLOR);
    display_fill_rounded_rect(x, y, 127, 22, 3);

    //v0.02w: the boot loader, updater and scope files must fit their areas of the card; too big: red, Upload blocked
    {
        uint8 *blk = 0;
        uint32 area = 0;

        if (starts_with(base_prefix, "bootloader"))   { blk = &upl_block_boot; area = sd_area_bytes(BOOT_PROGRAM_START_SECTOR); }
        else if (starts_with(base_prefix, "updater")) { blk = &upl_block_upd;  area = sd_area_bytes(UPDATE_PROGRAM_START_SECTOR); }
        else if (starts_with(base_prefix, "scope"))   { blk = &upl_block_dso;  area = sd_area_bytes(DSO_PROGRAM_START_SECTOR); rsv_dso_size = file_found ? (uint32)fno.fsize : 0; }

        if (blk)
            *blk = (uint8)(file_found && ((uint32)fno.fsize > area));

        if (blk && *blk) {
            display_set_font(&font_2);
            display_set_fg_color(WHITE_COLOR);
            display_fill_rounded_rect(x, y, 127, 22, 3);
            display_set_fg_color(RED_COLOR);
            display_draw_rounded_rect(x, y, 127, 22, 3);
            display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
            display_text(x + 22, y + 4, "File too big!");
            return;
        }
    }

    // Show result box
    if (file_found) {
        display_set_fg_color(GREEN_COLOR);
        display_draw_rounded_rect(x, y, 127, 22, 3);
        display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
        display_set_fg_color(BLACK_COLOR);
        display_text(x + shift, y + 4, fno.fname);

        // Optional special behavior for specific files
        if (my_strcmp(fno.fname, "data.cal") == 0)
            download_button_cal_data = 0;

        if (my_strcmp(fno.fname, "TP_Screen.bin") == 0)
            download_button_TP_Screen_data = 0;
        
        if (my_strcmp(fno.fname, "Fnirsi FPGA.bin") == 0)
            download_button_SPI_FPGA_Flash = 0;

        //if (my_strcmp(fno.fname, "Fnirsi backup.bin") == 0)
           // download_button_SPI_BACKUP_Flash = 0;
    } else {
        display_set_fg_color(RED_COLOR);
        display_draw_rounded_rect(x, y, 127, 22, 3);
        display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
        display_text(x + 28, y + 4, "File missing!");
    }
}

//----------------------------------------------------------------
// Pomocná funkcia: skontroluje, či reťazec začína daným prefixom
int8 starts_with(const char *str, const char *prefix)
{
    while (*prefix) {
        if (*prefix++ != *str++) return 0;
    }
    return 1;
}
//----------------------------------------------------------------
// Pomocná funkcia: skontroluje, či reťazec končí daným sufixom
int8 ends_with(const char *str, const char *suffix)
{
    int lenstr = my_strlen(str);
    int lensuffix = my_strlen(suffix);
    if (lensuffix > lenstr) return 0;
    return (my_strcmp(str + lenstr - lensuffix, suffix) == 0);
}


//******************************************************************************

int read_sdcard_to_file_with_progress(const char* filename, uint32 start_sector, uint32 num_sectors)
{
  FIL file;
  FRESULT fr;
  UINT bytes_written;
  uint32 sector = start_sector;
  uint8 buffer[512];
   
  const char* basename = filename;
  const char* p = filename;

  uint16 x = WIN1_XPOS + 20;

  // Save screen content where the progress window will be displayed
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

  // Draw the background and frame
  display_set_fg_color(GREY_COLOR);
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

  // Display header
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 27, WIN1_YPOS + 10, "Reading from SD card");//24 15*

  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Saving to file:");

  // Extract base file name from path
  while (*p) 
  {
    if (*p == '/' || *p == '\\') basename = p + 1;
    p++;
  }

  // Show file name
  display_set_fg_color(WHITE_COLOR);
  display_text(x + 82, WIN1_YPOS + 40, (char *)basename);
    
  //Display filename
  //display_set_fg_color(WHITE_COLOR);
  //display_text(x + 82, WIN1_YPOS + 40, (char *)filename);

  // Open destination file
  fr = f_open(&file, filename, FA_CREATE_ALWAYS | FA_WRITE);
  if (fr != FR_OK) 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "File open failed");
    text_and_touch_the_screen(x);
    return 1;
  }

  // Initialize progress bar
  progress_bar_init();
    
  // calculate progress_delay
  calculate_progress_delay(num_sectors);

  for (uint32 i = 0; i < num_sectors; i++) 
  {
    if (sd_card_read(sector + i, 1, buffer) != SD_OK) 
    {
      f_close(&file);
      display_set_fg_color(RED_COLOR);
      display_text(x, WIN1_YPOS + 75, "SD card read error");
      text_and_touch_the_screen(x);
      return 2;

    }

    fr = f_write(&file, buffer, SECTOR_SIZE, &bytes_written);
    if (fr != FR_OK || bytes_written != SECTOR_SIZE) 
    {
      f_close(&file);
      display_set_fg_color(RED_COLOR);
      display_text(x, WIN1_YPOS + 75, "File write failed");
      text_and_touch_the_screen(x);
      return 3;
    }

    // Update progress
    progress_bar_update(i + 1, num_sectors);
  }

  f_close(&file);

  // Complete message
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 48, WIN1_YPOS + 95, "Read complete");//46 37*
  text_and_touch_the_screen(x);
  return 0;
}

//******************************************************************************

int write_file_to_sdcard_with_progress(const char* filename, uint32 start_sector)
{
    FIL file;
    FRESULT fr;
    UINT bytes_read;
    uint32 sector = start_sector;
    uint8 buffer[512];
    
    char folder[128];
    char prefix[64];
    //char filepath[128];
    char found_file[128];
    FILINFO fno;
    DIR dir;

    const char* basename = filename;
    const char* p = filename;
    
    uint16 x = WIN1_XPOS + 20;
    
    display_set_destination_buffer(displaybuffertmp);
    display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
    display_set_fg_color(GREY_COLOR);
    display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
    display_set_fg_color(WHITE_COLOR);
    display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
    display_set_font(&font_2);
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 39, WIN1_YPOS + 10, "Writing to SD card");//30-10*
    display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 40, "Writing file:");

    // --- 1. Split folder and base name ---
    const char* last_slash = my_strrchr(filename, '/');
    if (!last_slash) {
        my_strcpy(folder, ".");
        my_strcpy(prefix, filename);
    } else {
        size_t folder_len = last_slash - filename;
        my_strncpy(folder, filename, folder_len);
        folder[folder_len] = 0;
        my_strcpy(prefix, last_slash + 1);
    }

    // Remove extension from prefix (.bin or .cal)  
    char* dot = my_strrchr(prefix, '.');
    if (dot) *dot = 0;

    // --- 2. Search for matching file ---
    fr = f_opendir(&dir, folder);
    if (fr != FR_OK) 
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "Folder open failed");
        text_and_touch_the_screen(x);
        return 1;
    }

    int file_found = 0;
    while (1)
    {
        fr = f_readdir(&dir, &fno);
        if (fr != FR_OK || fno.fname[0] == 0) break;

        if (!(fno.fattrib & AM_DIR))
        {
            // Check if name starts with prefix and ends with .bin or .cal
            if (my_strstr(fno.fname, prefix) == fno.fname)
            {
                const char* ext = my_strrchr(fno.fname, '.');
                if (ext && 
                   (my_strcasecmp(ext, ".bin") == 0 || my_strcasecmp(ext, ".cal") == 0))
                {
                    my_sprintf_path(found_file, folder, fno.fname);
                    file_found = 1;
                    break;
                }
            }
        }
    }

    f_closedir(&dir);

    if (!file_found)
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File not found");
        text_and_touch_the_screen(x);
        return 1;
    }

    // --- 3. display file name ---
    basename = found_file;
    p = found_file;
    while (*p) 
    {
        if (*p == '/' || *p == '\\') basename = p + 1;
        p++;
    }

    display_set_fg_color(WHITE_COLOR);
    display_text(x + 72, WIN1_YPOS + 40, (char *)basename);

    // --- 4. Open file ---
    fr = f_open(&file, found_file, FA_READ);
    if (fr != FR_OK) 
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File open failed");
        text_and_touch_the_screen(x);
        return 1;
    }

    //v0.02w: the file must fit its area of the card (never into the next area or the FAT partition)
    if ((uint32)f_size(&file) > sd_area_bytes(start_sector))
    {
        char t[48], *q;

        f_close(&file);
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File too big - not written");
        q = rsv_str(t, "max ");
        q = rsv_num(q, sd_area_bytes(start_sector));
        rsv_str(q, " bytes");
        display_text(x, WIN1_YPOS + 75, t);

        if (start_sector == DSO_PROGRAM_START_SECTOR)
            display_text(x, WIN1_YPOS + 90, "Extend the reserve to 4 MB");

        text_and_touch_the_screen(x);
        return 3;
    }

    // --- 5. Write with progress ---
    progress_bar_init();
    
    uint32_t total_bytes = f_size(&file);
    uint32_t total_sectors = (total_bytes + SECTOR_SIZE - 1) / SECTOR_SIZE;
    calculate_progress_delay(total_sectors);

    uint32_t written_sectors = 0;
    while (1) 
    {
        fr = f_read(&file, buffer, SECTOR_SIZE, &bytes_read);
        if (fr != FR_OK || bytes_read == 0) break;

        if (bytes_read < SECTOR_SIZE) memset(buffer + bytes_read, 0xFF, SECTOR_SIZE - bytes_read);

        if (sd_card_write(sector, 1, buffer) != SD_OK) 
        {
          display_set_fg_color(RED_COLOR);
          display_text(x, WIN1_YPOS + 75, "SD card write failed");
          f_close(&file);
          text_and_touch_the_screen(x);
          return 2;
        }

        sector++;
        written_sectors++;
        progress_bar_update(written_sectors, total_sectors);
    }

    f_close(&file);

    // --- 6. Done ---
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 48, WIN1_YPOS + 95, "Write complete");//37-95*
    text_and_touch_the_screen(x);

    return 0;
}


//******************************************************************************
void text_and_touch_the_screen(int16 x)
{
        display_set_fg_color(WHITE_COLOR);
        display_text(x + 42, WIN1_YPOS + 115, "Touch the screen");
        while ((havetouch == 0)) tp_i2c_read_status();
        while ((havetouch == 1)) tp_i2c_read_status();
        display_set_source_buffer(displaybuffertmp);
        display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
}
        
//******************************************************************************

int read_spi_flash_to_file_with_progress(const char* filename)
{
  FIL file;
  FRESULT fr;
  UINT bytes_written;
  uint32 addr = 0;
  uint32 total_size = 0;      // // default 0x200000; 2 MB (25VQ16)
  uint32 sector_size = FLASH_SECTOR_SIZE; // 4096
  uint32 num_sectors;
  //uint32 num_sectors = total_size / sector_size;
  
  uint8 buffer[FLASH_SECTOR_SIZE];  
  
  const char* basename = filename;
  const char* p = filename;

  uint16 x = WIN1_XPOS + 20;

  // Save screen content
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

  // Draw window
  display_set_fg_color(GREY_COLOR);
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

  // Header
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 40, WIN1_YPOS + 10, "Reading SPI flash");//31*
  
  // Detect flash size using JEDEC ID
  SPIFlashInfo info = sys_spi_flash_get_info();
  total_size = info.total_size;
  
  if (total_size == 0)  //0
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, info.description);//60
    f_close(&file);
    text_and_touch_the_screen(x);
    return 2;
  } else 
  { 
    display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 75, info.description);//60
  }
  
  num_sectors = total_size / sector_size;

  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Saving to:");

  // Extract file name
  while (*p) 
  {
      if (*p == '/' || *p == '\\') basename = p + 1;
      p++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x + 65, WIN1_YPOS + 40, (char *)basename);//67 65

  // Open file
  fr = f_open(&file, filename, FA_CREATE_ALWAYS | FA_WRITE);
  if (fr != FR_OK) 
  {
      display_set_fg_color(RED_COLOR);
      display_text(x, WIN1_YPOS + 60, "File open failed");
      text_and_touch_the_screen(x);
      return 2;
  }

  progress_bar_init();
  //calculate_progress_delay(num_sectors);
  progress_delay = 0;

  // Read flash sector by sector (4 KB each)
  for (uint32 i = 0; i < num_sectors; i++) 
  {
      sys_spi_flash_read(addr, buffer, sector_size);
      fr = f_write(&file, buffer, sector_size, &bytes_written);
      if (fr != FR_OK || bytes_written != sector_size) 
      {
        f_close(&file);
        display_set_fg_color(GREY_COLOR);
        display_fill_rect(x, WIN1_YPOS + 75, 180, 16);
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 75, "File write failed");
        text_and_touch_the_screen(x);
        return 3;
      }

      addr += sector_size;
      progress_bar_update(i + 1, num_sectors);
  }

  f_close(&file);

  // Done
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 32, WIN1_YPOS + 95, "Flash read complete");//23*
  text_and_touch_the_screen(x);

  return 0;
}

//******************************************************************************

int write_file_to_spi_flash_with_progress(const char* filename, uint32 start_address)
{
  FIL file;
  FRESULT fr;
  UINT bytes_read;
//  char info[64];
  uint32 addr = start_address;
  uint32 total_size = 0; // default 2 MB (25VQ16)
  uint32 sector_size = FLASH_SECTOR_SIZE; // 4096
  uint32 num_sectors = 0;
  
  uint8 buffer[FLASH_SECTOR_SIZE];
  uint8 verify_buffer[FLASH_SECTOR_SIZE];
  uint8 verify_error = 0;

  const char* basename = filename;
  const char* p = filename;
  uint16 x = WIN1_XPOS + 20;

  // Save current screen content
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

  // Draw progress window
  display_set_fg_color(GREY_COLOR);
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

  // Header
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 34, WIN1_YPOS + 10, "Writing to SPI flash");//25*

  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Writing file:");

  // Extract file name from path
  while (*p) 
  {
    if (*p == '/' || *p == '\\') basename = p + 1;
    p++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x + 72, WIN1_YPOS + 40, (char *)basename);//67

  // Open input file
  fr = f_open(&file, filename, FA_READ);
  if (fr != FR_OK) 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "File open failed");
    text_and_touch_the_screen(x);
    return 1;
  }

  // Detect flash size using JEDEC ID  
  SPIFlashInfo info = sys_spi_flash_get_info();
  total_size = info.total_size;
   
  if (total_size == 0)  //0
  {
    display_set_fg_color(RED_COLOR);
    //display_text(x, WIN1_YPOS + 60, "SPI flash not detected");
        //display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 60, info.description);
    f_close(&file);
    text_and_touch_the_screen(x);
    return 2;
  } else 
  { 
    display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 75, info.description);
  }
  //total_size = 0x400000; // docasne na test
  num_sectors = total_size / sector_size;

  // Get file size and compute total sectors to write
  uint32 total_bytes = f_size(&file);
  uint32 total_file_sectors = (total_bytes + sector_size - 1) / sector_size;

  // Check available space in flash
  if ((start_address + total_bytes) > total_size) 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "Not enough space in flash");
    f_close(&file);
    text_and_touch_the_screen(x);
    return 3;
  }
  
  progress_bar_init();

  //calculate_progress_delay(total_file_sectors);
  progress_delay = 0;

  // Erase and write flash sector by sector (4 KB each)
  for (uint32 i = 0; i < total_file_sectors; i++) 
  {
    fr = f_read(&file, buffer, sector_size, &bytes_read);
    if (fr != FR_OK) break;
    if (bytes_read == 0) break;

    // Pad last sector with 0xFF if not full
    if (bytes_read < sector_size) { memset(buffer + bytes_read, 0xFF, sector_size - bytes_read); }

    sys_spi_flash_write_enable();
    sys_spi_flash_erase_sector(addr);
    sys_spi_flash_wait_while_busy();

    sys_spi_flash_program_sector(addr, buffer, sector_size);
    sys_spi_flash_wait_while_busy();
    
    //----------------
    // Verification step
    sys_spi_flash_read(addr, verify_buffer, sector_size);
    if (memcmp(buffer, verify_buffer, sector_size) != 0) 
    {
      verify_error = 1;
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x, WIN1_YPOS + 75, 180, 16);
      display_set_fg_color(ORANGE_COLOR);
      display_text(x + 42, WIN1_YPOS + 75, "Verification failed");//40
      break;
    }
    //------------------

    addr += sector_size;
    progress_bar_update(i + 1, total_file_sectors);
  }

  f_close(&file);
  
    // Done or failed message
  if (verify_error == 0) 
  {
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x, WIN1_YPOS + 75, 180, 16);
    display_set_fg_color(YELLOW_COLOR);
    display_text(x + 36, WIN1_YPOS + 75, "Flash write verified");
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 31, WIN1_YPOS + 95, "Flash write complete");//22*
    
    text_and_touch_the_screen(x);

    return 0;
  } 
  else 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x + 43, WIN1_YPOS + 95, "Flash write error!");
    
    text_and_touch_the_screen(x);

    return 4;
  }
  //return (verify_error ? 4 : 0);
}

//******************************************************************************

//Initialize progress bar on display
void progress_bar_init(void)
{
  uint16 x = WIN1_XPOS + 20;
  
  progress_bar[0] = '[';
  for (int i = 0; i < TOTAL_PROGRESS_STEPS; i++) progress_bar[i + 1] = ' ';
  progress_bar[TOTAL_PROGRESS_STEPS + 1] = ']';
  progress_bar[TOTAL_PROGRESS_STEPS + 2] = '\0';
  last_progress_index = 0;

  display_set_fg_color(WHITE_COLOR);
  display_text(x, WIN1_YPOS + 60, progress_bar);
}

//------------------------------------------------------------------------------

//Update progress bar with current progress
void progress_bar_update(uint32 current_step, uint32 total_steps)
{
  uint16 x = WIN1_XPOS + 20;
  uint32 step = (current_step * TOTAL_PROGRESS_STEPS) / total_steps;

  while (last_progress_index < step && last_progress_index < TOTAL_PROGRESS_STEPS)
  {
    progress_bar[last_progress_index + 1] = '.';
    last_progress_index++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x, WIN1_YPOS + 60, progress_bar);
  
  //Slower progress according to the set variable
  timer0_delay(progress_delay);
}

//------------------------------------------------------------------------------

//calculate progress_delay
void calculate_progress_delay(uint32 num_sectors)
{
  // Set delay according to transfer size
  if      (num_sectors < 2)  progress_delay = 80;  
  else if (num_sectors < 40) progress_delay = 40;
  else if (num_sectors < 80) progress_delay = 20;
//else if (num_sectors < 160) progress_delay = 2;
          else                progress_delay = 1;
}

//******************************************************************************

void button_enable(void)
{
  //Boot Loader
  //Button for DOWNLOAD
  scope_download_button(70, 110, 2);//118
  //Button for UPLOAD
  scope_upload_button(280, 110, upl_block_boot ? 2 : 0);     //v0.02w: blocked when the file is too big
    
  //Updater
  //Button for DOWNLOAD
  scope_download_button(70, 170, 2);//178
  //Button for UPLOAD
  scope_upload_button(280, 170, upl_block_upd ? 2 : 0);     //v0.02w: blocked when the file is too big
  
  //DSO firmware
  //Button for DOWNLOAD
  scope_download_button(70, 230, 2);
  //Button for UPLOAD
  scope_upload_button(280, 230, upl_block_dso ? 2 : 0);     //v0.02w: blocked when the file is too big
  
  //FPGA firmware
  //Button for DOWNLOAD
  scope_download_button(70, 290, 2);
  //Button for UPLOAD
  if(download_button_SPI_FPGA_Flash) scope_upload_button(280, 290, 2);
    else scope_upload_button(280, 290, 0);
  
  //Calibration data
  //Button for DOWNLOAD
  if(download_button_cal_data) scope_download_button(70, 354, 0);
    else scope_download_button(70, 354, 2);
  //Button for UPLOAD
  scope_upload_button(280, 354, 0);
  
  //TP & screen data
  //Button for DOWNLOAD
  if(download_button_TP_Screen_data) scope_download_button(70, 414, 0);
    else scope_download_button(70, 414, 2);
  //Button for UPLOAD
  scope_upload_button(280, 414, 0);
  //----------------------------------
  
  //SPI Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 110, 2);
  //Button for UPLOAD
  //if(download_button_SPI_FPGA_Flash) scope_upload_button(670, 110, 2);
    //else scope_upload_button(670, 110, 0);
  
  //FPGA Flash
  //Button for DOWNLOAD
  if(download_button_SPI_FPGA_Flash) scope_download_button(460, 110, 0);
    else scope_download_button(460, 110, 2);
  //Button for UPLOAD
  if(download_button_SPI_FPGA_Flash) scope_upload_button(670, 110, 2);
    else scope_upload_button(670, 110, 0);
  
  //SPI BACKUP Flash
  //Button for DOWNLOAD
  //if(download_button_SPI_BACKUP_Flash) scope_download_button(460, 290, 0);
  //  else scope_download_button(460, 290, 2);
  //Button for UPLOAD
 // if(download_button_SPI_BACKUP_Flash) scope_upload_button(670, 290, 2);
  //  else scope_upload_button(670, 290, 0);
  
 //download_button_cal_data = 0;
//download_button_TP_Screen_data = 0;
// download_button_SPI_BACKUP_Flash = 0;
  
  button_status = 1;
}

//******************************************************************************

void button_disable(void)
{
  //Boot Loader
  //Button for DOWNLOAD
  //scope_download_button(70, 110, 2);//118
  //Button for UPLOAD
  scope_upload_button(280, 110, 2);
    
  //Updater
  //Button for DOWNLOAD
  //scope_download_button(70, 170, 2);//178
  //Button for UPLOAD
  scope_upload_button(280, 170, 2);
  
  //DSO firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 230, 2);
  //Button for UPLOAD
  scope_upload_button(280, 230, 2);
  
  //FPGA firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 290, 2);
  //Button for UPLOAD
  scope_upload_button(280, 290, 2);
  
  //Calibration data
  //Button for DOWNLOAD
  scope_download_button(70, 354, 2);
  //Button for UPLOAD
  scope_upload_button(280, 354, 2);
    //Remove the current item from the thumbnails and delete the item from disk
  //scope_remove_item_from_thumbnails(1);

  //Save the thumbnail file
  //scope_save_thumbnail_file();
  //TP & screen data
  //Button for DOWNLOAD
  scope_download_button(70, 414, 2);
  //Button for UPLOAD
  scope_upload_button(280, 414, 2);
  
  //----------------------------------
  
  //FPGA Flash //SPI Flash
  //Button for DOWNLOAD
  scope_download_button(460, 110, 2);
  //Button for UPLOAD
  scope_upload_button(670, 110, 2);
  
  //FPGA Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 170, 2);
  //Button for UPLOAD
  //scope_upload_button(670, 170, 2);
  

  
  button_status = 0;
}

//******************************************************************************

//Simple strstr replacement: find substring within string
const char *my_strstr(const char *haystack, const char *needle)
{
  if (!*needle) return haystack; // Empty substring always matches

  const char *p1 = haystack;
  while (*p1)
  {
    const char *p1_begin = p1;
    const char *p2 = needle;

    // Compare characters
    while (*p1 && *p2 && (*p1 == *p2))
    {
      p1++;
      p2++;
    }

    if (!*p2) return p1_begin; // Found match

    p1 = p1_begin + 1; // Move to next position
  }

  return 0; // Not found
}

//-----------------------------------------------------------------

int my_strcmp(const char *s1, const char *s2)
{
  while (*s1 && (*s1 == *s2)) 
  {
    s1++;
    s2++;
  }
  return *(const unsigned char *)s1 - *(const unsigned char *)s2;
}

char *my_strrchr(const char *s, int c)
{
    const char *last = 0;
    do {
        if (*s == (char)c)
            last = s;
    } while (*s++);
    return (char*)last;
}

char *my_strcpy(char *dest, const char *src)
{
    char *d = dest;
    while ((*d++ = *src++));
    return dest;
}

char *my_strncpy(char *dest, const char *src, int n)
{
    int i;
    for (i = 0; i < n && src[i]; i++) dest[i] = src[i];
    for (; i < n; i++) dest[i] = '\0';
    return dest;
}

int my_strlen(const char *s)
{
    int len = 0;
    while (*s++) len++;
    return len;
}

// Simple sprintf for path joining (no formatting)
void my_sprintf_path(char *dst, const char *folder, const char *fname)
{
    while (*folder) *dst++ = *folder++;
    *dst++ = '/';
    while (*fname) *dst++ = *fname++;
    *dst = 0;
}

// Case-insensitive compare
int my_strcasecmp(const char *s1, const char *s2)
{
    while (*s1 && *s2)
    {
        char c1 = *s1++;
        char c2 = *s2++;
        if (c1 >= 'A' && c1 <= 'Z') c1 += 32;
        if (c2 >= 'A' && c2 <= 'Z') c2 += 32;
        if (c1 != c2) return (unsigned char)c1 - (unsigned char)c2;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

//******************************************************************************

//----------------------------------------------------------------------------------------------------------------------------------

int32 load_picture(const char* filename)
{
  uint32 result;
  //uint32 x = 300;
  display_set_font(&font_2);

  //Set the name in the global buffer for message display
  //strcpy(viewfilename, viewthumbnaildata[viewcurrentindex].filename);

  //Try to open the file for reading
  result = f_open(&viewfp, filename, FA_READ);

  //Check if file opened ok
  if(result == FR_OK)
  {
    //Read the bitmap header to verify if the bitmap can be displayed
    result = f_read(&viewfp, viewbitmapheader, PICTURE_HEADER_SIZE, 0);

    //Check if still ok to proceed
    if(result == FR_OK)
    {
      //Check if the header matches what it should be
      if(memcmp(viewbitmapheader, bmpheader, PICTURE_HEADER_SIZE) == 0)
      {
        //display_set_fg_color(RED_COLOR);
        //display_text(x, WIN1_YPOS + 15, "OK");
        //timer0_delay(3000);
        //Load the bitmap data directly onto the screen
        result = f_read(&viewfp, (uint8 *)maindisplaybuffer, PICTURE_DATA_SIZE, 0);
      }
      else
      {
        //Signal a header mismatch detected
        result = PICTURE_HEADER_MISMATCH;

        //Show the user the file is not correct
        //scope_display_file_status_message(MESSAGE_BMP_HEADER_MISMATCH, 0);
        display_set_fg_color(RED_COLOR);
        display_text(320, 185, "MESSAGE_BMP_HEADER_MISMATCH");
        timer0_delay(3000);
      }
    }

    //Done with the file so close it
    f_close(&viewfp);

    //Check if one of the reads failed
    if((result != FR_OK) && (result != PICTURE_HEADER_MISMATCH))
    {
      //Signal unable to read from the file
      //scope_display_file_status_message(MESSAGE_FILE_READ_FAILED, 0);
      display_set_fg_color(RED_COLOR);
      display_text(320, 200, "MESSAGE_FILE_READ_FAILED");
      timer0_delay(3000);
    }
  }
  else
  {
    //Signal unable to open the file
    //scope_display_file_status_message(MESSAGE_FILE_OPEN_FAILED, 0);
    display_set_fg_color(RED_COLOR);
    display_text(320, 220, "MESSAGE_FILE_OPEN_FAILED");
    display_set_fg_color(YELLOW_COLOR);
    display_text(270, 250, "Please copy the update.bmp file to the SD card.");
    //while(1);
    timer0_delay(5000);
  }

  //Check if all went well
  if(result == FR_OK)
  {
    //Tell it to the caller
    return(VIEW_BITMAP_LOAD_OK);
  }
  
  return(VIEW_BITMAP_LOAD_ERROR);
}

//----------------------------------------------------------------------------------------------------------------------------------

void load_from_SDcard(uint32 address)
{   
  unsigned int blocks;
  int retval;
  unsigned int length;
  //Buffer for reading/writing from SD card
  unsigned char buffer[512];
  
    //Load the first program sector from the SD card
    if(sd_card_read(address, 1, buffer) != SD_OK)
    {
      display_set_fg_color(RED_COLOR);
      //display_text(305, 300, "SD card first read failed");
      display_text(295, 300, "SD card program read failed");

      //On error just frees
      while(1);
    }

    //Check if there is a brom header there
    if(memcmp(&buffer[4], "eGON.EXE", 8) != 0)
    {
      display_set_fg_color(RED_COLOR);
      display_text(337, 300, "Not an executable");

      //On error just frees
      while(1);
    }

    //Get the length from the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]);

    //Calculate the number of sectors to read
    blocks = (length + 511) / 512;

    //Copy the first program bytes to DRAM (So the eGON header is skipped)
    memcpy((void *)0x80000000, &buffer[32], 480);

    //Check if more data needs to be read
    if(blocks > 1)
    {
      //Already read the first block
      blocks--;

      //Load the remainder of the program from the SD card
      if((retval = sd_card_read(address + 1, blocks, (void *)0x800001E0)) != SD_OK)
      {
        display_set_fg_color(BLACK_COLOR);
        //Fill the settings background
        display_fill_rect(0, 0, 800, 480);  //x , y , sirka, vyska
          
        display_set_fg_color(RED_COLOR);
        display_text(190, 100, "SD card, Failed reading program sector");
        display_text(190, 130, "Error: ");
        display_text(190, 160, "Sector: ");
        display_set_fg_color(WHITE_COLOR);
        display_decimal(350, 130, retval);
        display_decimal(350, 160, blocks);

        //On error just frees
        while(1);
      }
    }
     //Start the chosen code
  __asm__ __volatile__ ("mov pc, %0\n" :"=r"(address):"0"(address));
}
/*
DWORD get_fattime (void)
{
    uint8   year = 25;
    uint8   month = 11;
    uint8   day = 3;    
    uint8 hour = 11;
            uint8   minute = 30;
                uint8   tm_sec = 22;
        
    
  

      //return date and time (FATtime original year-1980)
      return (DWORD)(year+20) << 25 |
             (DWORD)(month) << 21 |
             (DWORD)(day) << 16 |
             (DWORD)(hour) << 11 |
             (DWORD)minute << 5 |
             (DWORD)tm_sec >> 1;
}
 * */
//******************************************************************************

//******************************************************************************
//v0.02w: the size check of the firmware files and "Extend reserve to 4 MB"
//
//The SD card: sector 0 the partition table (MBR), 16 the boot loader (to 79), 80 the updater (to 707), 708 calibration,
//709 the scope settings, 710 the display configuration, 750 the scope firmware up to the start of the FAT partition.
//With the partition at 1 MB (sector 2048) the scope firmware may have 664 576 bytes. "Extend reserve" moves the
//partition to 4 MB (sector 8192): the firmware folders, \i2c_chips, the REF folders, \decoder, the start pictures and
//the .sys files are kept in RAM (CRC32), the partition table is written again, FAT32 made new, the files written back
//and checked. The sectors 16 .. start of the old partition are never written and are checked before and after.
//******************************************************************************

extern uint32 cardsectors;

#define RSV_NEW_START       8192                   //4 MB
#define RSV_MIN_CARD        131072                 //64 MB
#define RSV_RAM_SIZE        (16 * 1024 * 1024)
#define RSV_MAX_FILES       400
#define RSV_PATH            100
#define RSV_MIN_BATTERY     10                     //of 20 (50 %)

typedef struct
{
  char   path[RSV_PATH];
  uint32 size;
  uint32 offset;
  uint32 crc;
} RSVFILE;

PARTITION VolToPart[FF_VOLUMES] = { { 0, 1 } };    //FatFs: the first partition of the card

uint8 upl_block_boot = 0;      //the file is too big for its area: Upload blocked
uint8 upl_block_upd  = 0;
uint8 upl_block_dso  = 0;
uint32 rsv_dso_size = 0;     //the size of the scope file found by Refresh

static uint8   rsv_ram[RSV_RAM_SIZE] __attribute__((aligned(4)));
static RSVFILE rsv_files[RSV_MAX_FILES];
static uint32  rsv_nfiles;
static uint32  rsv_bytes;
static uint32  rsv_crc_table[256];
static uint8   rsv_sec[16 * 512] __attribute__((aligned(4)));

//Whole folders (with their sub folders)
static const char *const rsv_folders[] =
{
  "firmware_FNIRSI", "firmware_FNIRSI_FPGA", "firmware Atlan & PECO", "firmware Atlan & PECO FPGA", "firmware_FNIRSI_BACKUP",
  "i2c_chips", "ref_scope", "ref_roll", "ref_bode", "ref_spec", "refforms", "decoder", 0
};

//Folders of which only the .sys files are kept (the thumbnail lists; the scope removes items whose files are missing)
static const char *const rsv_sys_folders[] =
{
  "waveforms", "pic_scope", "pictures", "bode", "spectrum", "pic_bode", "pic_spec", 0
};

//------------------------------------------------------------------------------

static void rsv_crc_init(void)
{
  uint32 i, k, c;

  for(i = 0; i < 256; i++)
  {
    c = i;

    for(k = 0; k < 8; k++)
      c = (c & 1) ? (0xEDB88320 ^ (c >> 1)) : (c >> 1);

    rsv_crc_table[i] = c;
  }
}

static uint32 rsv_crc(uint32 crc, const uint8 *p, uint32 n)
{
  crc = ~crc;

  while(n--)
    crc = rsv_crc_table[(crc ^ *p++) & 0xFF] ^ (crc >> 8);

  return(~crc);
}

//The first sector of the first partition, 0 when there is no partition table
uint32 sd_partition_start(void)
{
  if(sd_card_read(0, 1, rsv_sec) != SD_OK)
    return(0);

  if((rsv_sec[510] != 0x55) || (rsv_sec[511] != 0xAA))
    return(0);

  return((uint32)rsv_sec[454] | ((uint32)rsv_sec[455] << 8) | ((uint32)rsv_sec[456] << 16) | ((uint32)rsv_sec[457] << 24));
}

//The bytes the area from start_sector may hold
uint32 sd_area_bytes(uint32 start_sector)
{
  uint32 ps;

  if(start_sector == BOOT_PROGRAM_START_SECTOR)
    return((UPDATE_PROGRAM_START_SECTOR - BOOT_PROGRAM_START_SECTOR) * 512);

  if(start_sector == UPDATE_PROGRAM_START_SECTOR)
    return((CALIBRATION_DATA_SECTOR - UPDATE_PROGRAM_START_SECTOR) * 512);

  if(start_sector == DSO_PROGRAM_START_SECTOR)
  {
    ps = sd_partition_start();
    return((ps > DSO_PROGRAM_START_SECTOR) ? ((ps - DSO_PROGRAM_START_SECTOR) * 512) : 0);
  }

  return(512);
}

//A number as text, returns the end
static char *rsv_num(char *p, uint32 v)
{
  char   t[12];
  uint32 n = 0;

  do
  {
    t[n++] = '0' + (v % 10);
    v /= 10;
  } while(v);

  while(n)
    *p++ = t[--n];

  *p = 0;
  return(p);
}

static char *rsv_str(char *p, const char *s)
{
  while(*s)
    *p++ = *s++;

  *p = 0;
  return(p);
}

//------------------------------------------------------------------------------
//The panel on the right (Refresh): where the partition starts, how much the scope firmware may have

void sd_reserve_panel(uint32 dso_size)
{
  char   t[80], *p;
  uint32 ps = sd_partition_start();

  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(404, 168, 382, 232);

  display_set_font(&font_3);
  display_set_fg_color(0x0000C0C0);
  display_text(520, 172, "SD card reserve");

  display_set_font(&font_2);
  display_set_fg_color(WHITE_COLOR);

  if(!ps)
  {
    display_set_fg_color(RED_COLOR);
    display_text(420, 200, "No partition table on the card");
    return;
  }

  p = rsv_str(t, "Partition from sector ");
  p = rsv_num(p, ps);
  p = rsv_str(p, " (");
  p = rsv_num(p, (ps * 512) / 1024);
  rsv_str(p, " KB reserve)");
  display_text(420, 200, t);

  p = rsv_str(t, "DSO firmware may have ");
  p = rsv_num(p, sd_area_bytes(DSO_PROGRAM_START_SECTOR));
  rsv_str(p, " bytes");
  display_text(420, 218, t);

  if(dso_size)
  {
    p = rsv_str(t, "scope file: ");
    p = rsv_num(p, dso_size);
    rsv_str(p, " bytes");
    display_set_fg_color(upl_block_dso ? RED_COLOR : GREEN_COLOR);
    display_text(420, 236, t);
  }

  if(upl_block_dso)
  {
    display_set_fg_color(RED_COLOR);
    display_text(420, 254, "Too big: Upload blocked, extend the reserve");
  }

  if(ps >= RSV_NEW_START)
  {
    display_set_fg_color(GREEN_COLOR);
    display_text(420, 290, "Reserve 4 MB or more - OK");
    return;
  }

  //The button
  display_set_fg_color(ORANGE_COLOR);
  display_fill_rounded_rect(RSV_BTN_X, RSV_BTN_Y, RSV_BTN_W, RSV_BTN_H, 4);
  display_set_fg_color(BLACK_COLOR);
  display_set_font(&font_3);
  display_text(RSV_BTN_X + ((RSV_BTN_W - rsv_text_w("Extend reserve")) / 2), RSV_BTN_Y + 4, "Extend reserve");
  display_text(RSV_BTN_X + ((RSV_BTN_W - rsv_text_w("to 4 MB")) / 2), RSV_BTN_Y + 21, "to 4 MB");

  display_set_font(&font_2);
  display_set_fg_color(LIGHTGREY2_COLOR);
  display_text(420, 360, "Formatting keeps the reserve. Deleting and making");
  display_text(420, 376, "the partition again sets it back (often to 1 MB).");
}

uint32 sd_reserve_button_shown(void)
{
  uint32 ps = sd_partition_start();

  return(ps && (ps < RSV_NEW_START));
}

//------------------------------------------------------------------------------
//The screen of the extension

#define RSV_X   20
#define RSV_Y   20
#define RSV_W   760
#define RSV_H   440
#define RSV_BTN2_Y   (RSV_Y + RSV_H - 56)     //v0.02w: the buttons of the dialog (Cancel / Retry left of Hold / Give up)
#define RSV_HOLD_W   140
//#define RSV_HOLD_X   (RSV_X + RSV_W - 20 - RSV_HOLD_W)
//v0.02y: the red button (Hold / Give up) on the left, Cancel / Retry on the right, far apart
#define RSV_HOLD_X   (RSV_X + 20)
#define RSV_SAFE_X   (RSV_X + RSV_W - 20 - 90)

static int32 rsv_line_y;

static void rsv_screen(const char *title)
{
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(RSV_X, RSV_Y, RSV_W, RSV_H);
  display_set_fg_color(ORANGE_COLOR);
  display_draw_rounded_rect(RSV_X, RSV_Y, RSV_W, RSV_H, 4);
  display_set_font(&font_4);
  display_text(RSV_X + 20, RSV_Y + 12, (int8 *)title);
  rsv_line_y = RSV_Y + 50;
}

static void rsv_line(const char *text, uint32 color)
{
  display_set_font(&font_2);
  display_set_fg_color(color);
  display_text(RSV_X + 20, rsv_line_y, (int8 *)text);
  rsv_line_y += 17;
}

//A line with OK / FAIL at the right
static uint32 rsv_check_line(const char *text, uint32 ok)
{
  display_set_font(&font_2);
  display_set_fg_color(WHITE_COLOR);
  display_text(RSV_X + 20, rsv_line_y, (int8 *)text);
  display_set_fg_color(ok ? GREEN_COLOR : RED_COLOR);
  display_text(RSV_X + 560, rsv_line_y, ok ? "OK" : "NOT OK");
  rsv_line_y += 17;
  return(ok);
}

extern DISPLAYDATA displaydata;

//The width of a text in the current font (variable width)
static int32 rsv_text_w(const char *text)
{
  PFONTDATA        font = displaydata.font;
  PFONTINFORMATION info;
  int32            w = 0;

  if(font->type != VARIABLE_WIDTH_FONT)
    return(0);

  for(; *text; text++)
  {
    info = check_char_in_vw_font(font->fontinformation, (uint16)(uint8)*text);

    if(info)
      w += info->fontmetrics[(uint8)*text - info->first_char].width;
  }

  return(w);
}

//A button 40 high with its text centred
#define RSV_BH  40

static void rsv_button(int32 x, int32 y, int32 w, const char *text, uint32 fill, uint32 color)
{
  display_set_fg_color(fill);
  display_fill_rounded_rect(x, y, w, RSV_BH, 4);
  display_set_font(&font_3);
  display_set_fg_color(color);
  display_text(x + ((w - rsv_text_w(text)) / 2), y + 12, (int8 *)text);
}

static uint32 rsv_in(int32 x, int32 y, int32 w)
{
  return(((int32)xtouch >= x) && ((int32)xtouch < (x + w)) && ((int32)ytouch >= y) && ((int32)ytouch < (y + RSV_BH)));
}

static void rsv_wait_touch(void)
{
  tp_i2c_wait_for_touch_release();

  do
    tp_i2c_read_status();
  while(!havetouch);

  tp_i2c_wait_for_touch_release();
}

//------------------------------------------------------------------------------
//The files to keep: listed with their sizes (pass 0) or read into RAM (pass 1)

static uint32 rsv_add_file(const char *path, uint32 size)
{
  uint32 i;

  if((rsv_nfiles >= RSV_MAX_FILES) || (my_strlen(path) >= RSV_PATH) || ((rsv_bytes + size + 3) > (RSV_RAM_SIZE - 32768)))     //the last 32 KB: f_mkfs work buffer
    return(0);

  for(i = 0; path[i]; i++)
    rsv_files[rsv_nfiles].path[i] = path[i];

  rsv_files[rsv_nfiles].path[i] = 0;
  rsv_files[rsv_nfiles].size    = size;
  rsv_files[rsv_nfiles].offset  = rsv_bytes;
  rsv_files[rsv_nfiles].crc     = 0;
  rsv_nfiles++;
  rsv_bytes = (rsv_bytes + size + 3) & ~3;
  return(1);
}

//A folder (sysonly: only *.sys), sub folders to depth 3; 0 when the list is full
static uint32 rsv_scan(const char *folder, uint32 sysonly, uint32 depth)
{
  DIR     dir;
  FILINFO fno;
  char    path[RSV_PATH], *p;
  uint32  ok = 1;

  if(f_opendir(&dir, folder) != FR_OK)
    return(1);

  while(ok && (f_readdir(&dir, &fno) == FR_OK) && fno.fname[0])
  {
    if((my_strlen(folder) + my_strlen(fno.fname) + 2) >= RSV_PATH)
    {
      ok = 0;
      break;
    }

    p = rsv_str(path, folder);
    p = rsv_str(p, "/");
    rsv_str(p, fno.fname);

    if(fno.fattrib & AM_DIR)
    {
      if(!sysonly && (depth < 3))
        ok = rsv_scan(path, 0, depth + 1);
    }
    else if(!sysonly || ends_with(fno.fname, ".sys"))
      ok = rsv_add_file(path, (uint32)fno.fsize);
  }

  f_closedir(&dir);
  return(ok);
}

//All the files to keep; 0 when they do not fit (too many or more than 16 MB)
static uint32 rsv_list(void)
{
  static const char *const root[] = { "updater.bmp", "scope.bmp", 0 };
  FILINFO fno;
  uint32  i, ok = 1;

  rsv_nfiles = 0;
  rsv_bytes  = 0;

  for(i = 0; ok && rsv_folders[i]; i++)
    ok = rsv_scan(rsv_folders[i], 0, 1);

  for(i = 0; ok && rsv_sys_folders[i]; i++)
    ok = rsv_scan(rsv_sys_folders[i], 1, 1);

  for(i = 0; ok && root[i]; i++)
    if(f_stat(root[i], &fno) == FR_OK)
      ok = rsv_add_file(root[i], (uint32)fno.fsize);

  return(ok);
}

//The CRC32 of a file on the card, 0xFFFFFFFF on a read error (not a real CRC in practice)
static uint32 rsv_file_crc(const char *path, uint32 *size)
{
  FIL    f;
  UINT   br;
  uint32 crc = 0;

  *size = 0;

  if(f_open(&f, path, FA_READ) != FR_OK)
    return(0xFFFFFFFF);

  while(1)
  {
    if(f_read(&f, rsv_sec, sizeof(rsv_sec), &br) != FR_OK)
    {
      f_close(&f);
      return(0xFFFFFFFF);
    }

    if(!br)
      break;

    crc = rsv_crc(crc, rsv_sec, br);
    *size += br;
  }

  f_close(&f);
  return(crc);
}

//The CRC32 of the sectors from first to last - 1 (boot loader, updater, settings, scope firmware)
static uint32 rsv_sectors_crc(uint32 first, uint32 last, uint32 *ok)
{
  uint32 s, n, crc = 0;

  *ok = 1;

  for(s = first; s < last; s += n)
  {
    n = ((last - s) > 16) ? 16 : (last - s);

    if(sd_card_read(s, n, rsv_sec) != SD_OK)
    {
      *ok = 0;
      return(0);
    }

    crc = rsv_crc(crc, rsv_sec, n * 512);
  }

  return(crc);
}

//The folders of a path made (each part)
static void rsv_mkdirs(const char *path)
{
  char   t[RSV_PATH];
  uint32 i;

  for(i = 0; path[i] && (i < (RSV_PATH - 1)); i++)
  {
    if(path[i] == '/')
    {
      t[i] = 0;
      f_mkdir(t);
    }

    t[i] = path[i];
  }
}

//A progress line: "text n / total"
static void rsv_progress(int32 y, const char *text, uint32 n, uint32 total)
{
  char t[80], *p;

  p = rsv_str(t, text);
  p = rsv_num(p, n);
  p = rsv_str(p, " / ");
  rsv_num(p, total);

  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(RSV_X + 20, y, 600, 16);
  display_set_font(&font_2);
  display_set_fg_color(WHITE_COLOR);
  display_text(RSV_X + 20, y, (int8 *)t);
}

//------------------------------------------------------------------------------
//Step 1 and 2 (nothing on the card changed yet): the files into RAM, each read again and checked; the CRC of the
//sectors that must stay. 1 when all went well.

static uint32 rsv_crc_keep;

static uint32 rsv_backup(uint32 old_start)
{
  FIL    f;
  UINT   br;
  uint32 i, size, ok;

  rsv_line("1. Files into RAM (each read twice and compared by CRC32)", YELLOW_COLOR);

  for(i = 0; i < rsv_nfiles; i++)
  {
    rsv_progress(rsv_line_y, "   file ", i + 1, rsv_nfiles);

    if(f_open(&f, rsv_files[i].path, FA_READ) != FR_OK)
      return(0);

    if((f_read(&f, &rsv_ram[rsv_files[i].offset], rsv_files[i].size, &br) != FR_OK) || (br != rsv_files[i].size))
    {
      f_close(&f);
      return(0);
    }

    f_close(&f);
    rsv_files[i].crc = rsv_crc(0, &rsv_ram[rsv_files[i].offset], rsv_files[i].size);

    if((rsv_file_crc(rsv_files[i].path, &size) != rsv_files[i].crc) || (size != rsv_files[i].size))
      return(0);
  }

  rsv_line_y += 17;
  rsv_line("2. CRC32 of the sectors 16 .. start of the partition (firmware area)", YELLOW_COLOR);
  rsv_crc_keep = rsv_sectors_crc(BOOT_PROGRAM_START_SECTOR, old_start, &ok);
  return(ok);
}

//Step 3 .. 6 (can be repeated): the partition table, FAT32, the kept sectors checked, the files back and checked.
//0 all well, else the step that failed
static uint32 rsv_rebuild(uint32 old_start)
{
  FIL       f;
  UINT      bw;
  MKFS_PARM opt;
  uint32    i, ok, size, part_size, bad = 0;
  char      t[80], *p;

  //3. The partition table: one FAT32 (LBA) partition from 4 MB to the end of the card
  rsv_line("3. Partition table: FAT32 from sector 8192", YELLOW_COLOR);
  f_mount(0, "0", 0);

  if(sd_card_read(0, 1, rsv_sec) != SD_OK)
    return(3);

  part_size = cardsectors - RSV_NEW_START;

  for(i = 446; i < 510; i++)
    rsv_sec[i] = 0;

  rsv_sec[446 + 0] = 0x00;                  //not active
  rsv_sec[446 + 1] = 0xFE;                  //CHS start / end: LBA is used
  rsv_sec[446 + 2] = 0xFF;
  rsv_sec[446 + 3] = 0xFF;
  rsv_sec[446 + 4] = 0x0C;                  //FAT32 LBA
  rsv_sec[446 + 5] = 0xFE;
  rsv_sec[446 + 6] = 0xFF;
  rsv_sec[446 + 7] = 0xFF;
  rsv_sec[446 + 8]  = (uint8)(RSV_NEW_START);
  rsv_sec[446 + 9]  = (uint8)(RSV_NEW_START >> 8);
  rsv_sec[446 + 10] = (uint8)(RSV_NEW_START >> 16);
  rsv_sec[446 + 11] = (uint8)(RSV_NEW_START >> 24);
  rsv_sec[446 + 12] = (uint8)(part_size);
  rsv_sec[446 + 13] = (uint8)(part_size >> 8);
  rsv_sec[446 + 14] = (uint8)(part_size >> 16);
  rsv_sec[446 + 15] = (uint8)(part_size >> 24);
  rsv_sec[510] = 0x55;
  rsv_sec[511] = 0xAA;

  if(sd_card_write(0, 1, rsv_sec) != SD_OK)
    return(3);

  if(sd_partition_start() != RSV_NEW_START)
    return(3);

  //4. FAT32 in the partition
  rsv_line("4. FAT32 made in the partition", YELLOW_COLOR);
  opt.fmt     = FM_FAT32;
  opt.n_fat   = 2;
  opt.align   = 64;
  opt.n_root  = 0;
  opt.au_size = 32768;

  //The RAM after the files is the work buffer (32 KB). 32 KB clusters as the SD cards have; when the partition is too
  //small for that the size FatFs chooses, at last any FAT type
  if(f_mkfs("0", &opt, &rsv_ram[RSV_RAM_SIZE - 32768], 32768) != FR_OK)
  {
    opt.au_size = 0;

    if(f_mkfs("0", &opt, &rsv_ram[RSV_RAM_SIZE - 32768], 32768) != FR_OK)
    {
      opt.fmt = FM_ANY;

      if(f_mkfs("0", &opt, &rsv_ram[RSV_RAM_SIZE - 32768], 32768) != FR_OK)
        return(4);
    }
  }

  if(f_mount(&fs, "0", 1) != FR_OK)
    return(4);

  //5. The kept sectors unchanged
  rsv_line("5. Sectors 16 .. old partition start checked (CRC32)", YELLOW_COLOR);

  if((rsv_sectors_crc(BOOT_PROGRAM_START_SECTOR, old_start, &ok) != rsv_crc_keep) || !ok)
    return(5);

  //6. The files back, then each read and checked
  rsv_line("6. Files written back and checked (CRC32)", YELLOW_COLOR);

  for(i = 0; i < rsv_nfiles; i++)
  {
    rsv_progress(rsv_line_y, "   file ", i + 1, rsv_nfiles);
    rsv_mkdirs(rsv_files[i].path);

    if(f_open(&f, rsv_files[i].path, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK)
    {
      bad++;
      continue;
    }

    if((f_write(&f, &rsv_ram[rsv_files[i].offset], rsv_files[i].size, &bw) != FR_OK) || (bw != rsv_files[i].size))
      bad++;

    f_close(&f);

    if((rsv_file_crc(rsv_files[i].path, &size) != rsv_files[i].crc) || (size != rsv_files[i].size))
      bad++;
  }

  //The kept folders also when they were empty
  for(i = 0; rsv_folders[i]; i++)
    f_mkdir(rsv_folders[i]);

  rsv_line_y += 17;

  if(bad)
  {
    p = rsv_str(t, "Files with errors: ");
    rsv_num(p, bad);
    rsv_line(t, RED_COLOR);
    return(6);
  }

  return(0);
}

//------------------------------------------------------------------------------
//The button "Extend reserve to 4 MB": the conditions first, then the warning and the 3 s hold, then the work

void sd_extend_reserve(void)
{
  char   t[96], *p;
  uint32 ps, ok = 1, power, step;
  int32  held;

  rsv_crc_init();
  rsv_screen("Extend the SD card reserve to 4 MB");

  ps = sd_partition_start();

  //The conditions, all shown before anything is asked
  p = rsv_str(t, "Partition now from sector ");
  p = rsv_num(p, ps);
  rsv_str(p, " (must be below 8192)");
  ok &= rsv_check_line(t, ps && (ps < RSV_NEW_START) && (ps > DSO_PROGRAM_START_SECTOR));

  p = rsv_str(t, "Card size ");
  p = rsv_num(p, cardsectors / 2048);
  rsv_str(p, " MB (64 MB at least)");
  ok &= rsv_check_line(t, cardsectors >= RSV_MIN_CARD);

  power = scopesettings.batterycharging || (scopesettings.batterychargelevel >= RSV_MIN_BATTERY);
  p = rsv_str(t, scopesettings.batterycharging ? "Charger connected" : "Battery ");

  if(!scopesettings.batterycharging)
  {
    p = rsv_num(p, (scopesettings.batterychargelevel * 100) / 20);
    rsv_str(p, " % (charger or 50 % at least)");
  }

  ok &= rsv_check_line(t, power);
  ok &= rsv_check_line("USB connection to the PC off", !mounted_to_PC && button_status);

  ok &= rsv_check_line("Files to keep listed", rsv_list());
  p = rsv_str(t, "   ");
  p = rsv_num(p, rsv_nfiles);
  p = rsv_str(p, " files, ");
  p = rsv_num(p, rsv_bytes / 1024);
  rsv_str(p, " KB (16 MB at most)");
  rsv_line(t, LIGHTGREY2_COLOR);

  if(!ok)
  {
    rsv_line_y += 10;
    rsv_line("Not possible now: fix the points marked NOT OK and try again.", RED_COLOR);
    rsv_button(RSV_SAFE_X, RSV_BTN2_Y, 90, "Close", LIGHTGREY2_COLOR, BLACK_COLOR);
    rsv_wait_touch();
    return;
  }

  //The warning
  rsv_line_y += 8;
  rsv_line("WARNING: ALL FILES ON THE SD CARD WILL BE DELETED!", RED_COLOR);
  rsv_line("Kept: the firmware folders, i2c_chips, the REF folders, decoder, the .sys files and the start pictures.", WHITE_COLOR);     //v0.02y: white
  rsv_line("Waves, pictures and all other files are lost: copy them to a PC first (USB on).", RED_COLOR);
  rsv_line("Do not switch off and do not remove the card until the end (about a minute).", RED_COLOR);
  rsv_line("Later formatting keeps the 4 MB; deleting and making the partition again sets it back.", ORANGE_COLOR);

  rsv_button(RSV_SAFE_X, RSV_BTN2_Y, 90, "Cancel", LIGHTGREY2_COLOR, BLACK_COLOR);
  rsv_button(RSV_HOLD_X, RSV_BTN2_Y, RSV_HOLD_W, "Hold 3 s to start", RED_COLOR, WHITE_COLOR);

  //Hold 3 s on the red button (the bar fills), Cancel or a touch elsewhere does nothing
  while(1)
  {
    tp_i2c_read_status();

    if(!havetouch)
      continue;

    if(rsv_in(RSV_SAFE_X, RSV_BTN2_Y, 90))
    {
      tp_i2c_wait_for_touch_release();
      return;
    }

    if(rsv_in(RSV_HOLD_X, RSV_BTN2_Y, RSV_HOLD_W))
    {
      for(held = 0; havetouch && rsv_in(RSV_HOLD_X, RSV_BTN2_Y, RSV_HOLD_W) && (held < 60); held++)
      {
        display_set_fg_color(YELLOW_COLOR);
        display_fill_rect(RSV_HOLD_X, RSV_BTN2_Y + RSV_BH + 4, (held * RSV_HOLD_W) / 60, 5);
        timer0_delay(50);
        tp_i2c_read_status();
      }

      if(held >= 60)
        break;

      display_set_fg_color(BLACK_COLOR);
      display_fill_rect(RSV_HOLD_X, RSV_BTN2_Y + RSV_BH + 4, RSV_HOLD_W, 5);
    }

    tp_i2c_wait_for_touch_release();
  }

  tp_i2c_wait_for_touch_release();

  //The work
  rsv_screen("Extending the reserve - do not switch off!");

  if(!rsv_backup(ps))
  {
    rsv_line("Reading the files failed. Nothing on the card was changed.", RED_COLOR);
    rsv_line("Touch the screen.", WHITE_COLOR);
    rsv_wait_touch();
    return;
  }

  while((step = rsv_rebuild(ps)) != 0)
  {
    //The card is changed but the files are in RAM: repeat until it works (or give up knowingly)
    p = rsv_str(t, "Step ");
    p = rsv_num(p, step);
    rsv_str(p, " failed. The files are still in RAM - do not switch off.");
    rsv_line(t, RED_COLOR);

    rsv_button(RSV_SAFE_X, RSV_BTN2_Y, 90, "Retry", ORANGE_COLOR, BLACK_COLOR);
    rsv_button(RSV_HOLD_X, RSV_BTN2_Y, RSV_HOLD_W, "Give up (files lost)", RED_COLOR, WHITE_COLOR);

    while(1)
    {
      tp_i2c_read_status();

      if(havetouch && rsv_in(RSV_SAFE_X, RSV_BTN2_Y, 90))
        break;

      if(havetouch && rsv_in(RSV_HOLD_X, RSV_BTN2_Y, RSV_HOLD_W))
      {
        tp_i2c_wait_for_touch_release();
        return;
      }
    }

    tp_i2c_wait_for_touch_release();
    rsv_screen("Extending the reserve - retry, do not switch off!");
  }

  p = rsv_str(t, "Done: reserve 4 MB, ");
  p = rsv_num(p, rsv_nfiles);
  rsv_str(p, " files back, all CRC32 OK. Firmware area unchanged.");
  rsv_line(t, GREEN_COLOR);
  p = rsv_str(t, "The DSO firmware may now have ");
  p = rsv_num(p, sd_area_bytes(DSO_PROGRAM_START_SECTOR));
  rsv_str(p, " bytes.");
  rsv_line(t, GREEN_COLOR);
  rsv_line("Touch the screen.", WHITE_COLOR);
  rsv_wait_touch();
}

//******************************************************************************
//v0.02w: EXIT: the whole device restarted by the watchdog of the F1C100s / F1C200s (Timer block 0x01C20C00:
//WDOG_CTRL 0xB0, WDOG_CFG 0xB4 = 1 whole system reset, WDOG_MODE 0xB8 bit 0 enable, bits 7..4 interval 0 = 0.5 s).
//After new FPGA firmware a message asks for power off instead (a reset does not reload the FPGA).

//(the registers as defined in timer.h)

uint8 updater_fpga_written = 0;

static void exit_message(const char *l1, const char *l2, uint32 color)
{
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_fg_color(BLACK_COLOR);
  display_fill_rect(200, 180, 400, 110);
  display_set_fg_color(color);
  display_draw_rounded_rect(200, 180, 400, 110, 4);
  display_set_font(&font_3);
  display_text(400 - (rsv_text_w(l1) / 2), 205, (int8 *)l1);
  display_set_font(&font_2);
  display_set_fg_color(WHITE_COLOR);
  display_text(400 - (rsv_text_w(l2) / 2), 240, (int8 *)l2);
}

void updater_exit_restart(void)
{
  if(updater_fpga_written)
  {
    exit_message("New FPGA firmware written", "Switch the scope off and on to load it.", ORANGE_COLOR);
    rsv_wait_touch();
    scope_setup_main_screen();
    ini_folders();
    download_button_cal_data = 1;
    download_button_TP_Screen_data = 1;
    download_button_SPI_FPGA_Flash = 1;
    check_firmware_files();
    button_enable();
    return;
  }

  exit_message("Restarting ...", "", GREEN_COLOR);

  *WDOG_CFG_REG  = 1;                         //the whole system
  *WDOG_MODE_REG = (0 << 4) | 1;              //0.5 s, on
  *WDOG_CTRL_REG = (0xA57 << 1) | 1;          //start counting from now

  timer0_delay(2000);

  //Still here: the watchdog did not reset
  exit_message("Restart did not work", "Switch the scope off and on.", RED_COLOR);
  *WDOG_MODE_REG = 0;

  while(1);
}
