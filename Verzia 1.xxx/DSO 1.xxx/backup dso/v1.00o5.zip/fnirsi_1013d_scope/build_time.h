#ifndef BUILD_TIME_H
#define BUILD_TIME_H
#define COMPILE_YEAR 26
#define COMPILE_MONTH 2
#define COMPILE_DAY 13
#define COMPILE_HOUR 18
#define COMPILE_MIN 59
#define COMPILE_SEC 33
#endif
