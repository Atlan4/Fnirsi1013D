

#include "update.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "variables.h"
#include "types.h"
#include "timer.h"
//#include "scope_functions.h"
#include "menu.h"
#include "touchpanel.h"

//#include <string.h>

//---------------------------------------------------------------------

#define TOTAL_PROGRESS_STEPS 50
uint32 progress_delay = 5; // default value in milliseconds (can be modified when calling the function)
//#define TOTAL_WRITE_TIME_MS 200
//#define DELAY_PER_STEP_MS (TOTAL_WRITE_TIME_MS / TOTAL_PROGRESS_STEPS)

// Global progress bar buffer
char progress_bar[TOTAL_PROGRESS_STEPS + 3]; // '[' + 50 steps + ']' + '\0'
uint32 last_progress_index = 0;
//uint32 speed;
//uint32 DELAY_PER_STEP_MS;


#define SECTOR_SIZE 512
//Buffer for reading/writing from SD card
unsigned char buffer[SECTOR_SIZE];

//******************************************************************************
//******************************************************************************

void ini_folders(void) 
{
  int16  x = WIN1_XPOS + 20;
  
  //Setup and check SD card on file system being present
  if(f_mount(&fs, "0", 1))
  {
    //Show SD card error message on failure
    //Display the message in red
    display_set_fg_color(RED_COLOR);
    //display_set_font(&font_3);
    display_set_font(&font_2);
    display_text(50, 150, "SD MOUNT ERROR");

    //On error just hang
    while(1);
  }
  
  //Save the screen rectangle where the menu will be displayed
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
  //Draw the background in grey
  display_set_fg_color(GREY_COLOR);

  //Fill the background
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  
  //Display the message in white
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_2);
  
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);  
  
  display_text(x, WIN1_YPOS+10, "Search folders...");
  
/*
       //Show a message creating the directory
      display_text(x, WIN1_YPOS+40, "firmware FNIRSI");
      timer0_delay(1000);
      display_text(x, WIN1_YPOS+55, "firmware FNIRSI FPGA");
      timer0_delay(1000);firmware Atlan & PECO
      display_text(x, WIN1_YPOS+70, "firfirmware FNIRSImware Atlan & PECO");
      timer0_delay(1000);
      display_text(x, WIN1_YPOS+85, "firmware Atlan & PECO FPGA");
      timer0_delay(1000);
  
       while(1);
 */
  
  create_directory_if_missing("firmware_FNIRSI", x, WIN1_YPOS+40);
  create_directory_if_missing("firmware_FNIRSI_FPGA", x, WIN1_YPOS+55);
  
  create_directory_if_missing("firmware Atlan & PECO", x, WIN1_YPOS+70);
  create_directory_if_missing("firmware Atlan & PECO FPGA", x, WIN1_YPOS+85);
  
  create_directory_if_missing("firmware_FNIRSI_BACKUP", x, WIN1_YPOS+100);
  
  //Check TXT file, create if missing
  create_info_firmware_file_if_missing(x);
  
  timer0_delay(1000);
  
  //Restore the screen when done
  display_set_source_buffer(displaybuffertmp);
  display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
}
    
//------------------------------------------------------------------------------

void create_directory_if_missing(char* dirname, int16 x, int16 y)  
{
  int32  result;    
  
  //Check the status of the directory for this view type
  result = f_stat(dirname, 0);

  //See if there is an error
  if(result != FR_OK)
  {
    //If so check if the directory does not exist
    if(result == FR_NO_FILE)
    {
      //Draw the background in grey
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x + 135, WIN1_YPOS + 10, 35, 14);
      
      //Display the message in red
      display_set_fg_color(RED_COLOR);
      display_text(x + 140, WIN1_YPOS + 10, "FAIL");
      
      //Create the directory
      result = f_mkdir(dirname);
      
      //Display the message in green
      display_set_fg_color(GREEN_COLOR);
      display_text(x, WIN1_YPOS+25, "Create folder:");
     
      //Show a message creating the directory
      //Display the message in white
      display_set_fg_color(WHITE_COLOR);
      display_text(x, y, dirname);
      timer0_delay(2000);
      
      if(result != FR_OK)
      {
        //Show a message stating creating the directory failed
        //Display the message in red
        display_set_fg_color(RED_COLOR);
        display_set_font(&font_2);
        display_text(x, WIN1_YPOS + 40, "MESSAGE_DIRECTORY_CREATE_FAILED");
        
        //On error just hang
        while(1);
      }
    }
  } 
  else 
  {      
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x + 135, WIN1_YPOS + 10, 35, 14);
    display_set_fg_color(GREEN_COLOR); 
    display_text(x + 140, WIN1_YPOS + 10, "OK");
    //display_text(x + 140, WIN1_YPOS + 10, "FAIL");
    //while(1); 
  }     
}

//******************************************************************************

void create_info_firmware_file_if_missing(int16 x)
{
  FIL file;
  FRESULT res;
  const char *filename = "info_firmware.txt";
  const char *content = 
    "Updater firmware: " VERSION_STRING "\r\n"
    "\r\n"
    "Boot Loader      - bootloader.bin\r\n"
    "Updater          - updater.bin\r\n"
    "DSO firmware     - scope.bin\r\n"
    "FPGA firmware    - FPGA.bin                ( Hardware modification required )\r\n"
    "Calibration data - data.cal                ( Backup file for: calibration & TP & screen settings )\r\n"
    "Touch pad and screen data - TP_Screen.bin  ( Backup file for: TP & screen settings )\r\n"
    "\r\n"
    "SPI Flash        - Fnirsi 1013D.bin  14.06.2024\r\n"
    "FPGA Flash       - Fnirsi FPGA.bin   ( Hardware modification required )\r\n"
    "\r\n"
    "SPI Flash backup - Fnirsi FLASH backup.bin\r\n";

  //Check if the file exists
  FILINFO fno;
  res = f_stat(filename, &fno);

  if (res != FR_OK)  //File does not exist.
  {
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x + 10, WIN1_YPOS + 115, 150, 14);
    display_set_fg_color(YELLOW_COLOR); 
    display_text(x, WIN1_YPOS + 115, "Create info_firmware.txt");//11
    //while(1);
    timer0_delay(2000);
        
        //Try creating a new file to write to
        res = f_open(&file, filename, FA_WRITE | FA_CREATE_NEW);
        if (res == FR_OK)
        {
            UINT bytes_written;
            res = f_write(&file, content, strlen(content), &bytes_written);

            if (res != FR_OK || bytes_written != strlen(content)) 
            {
              //Write error
              //Draw the background in grey
              display_set_fg_color(GREY_COLOR);
              display_fill_rect(x + 10, WIN1_YPOS + 115, 150, 14);
              display_set_fg_color(RED_COLOR); 
              display_text(x + 25, WIN1_YPOS + 115, "Write in txt file - Fail");
              timer0_delay(5000);
            }

            f_close(&file);
        }
        else 
        {
        //Show a message stating creating the file failed
        //Display the message in red
        display_set_fg_color(RED_COLOR);
        display_set_font(&font_2);
        display_text(x, WIN1_YPOS + 115, "MESSAGE_FILE_CREATE_FAILED");
        
        //On error just hang
        while(1);
        }
    }
    else
    {
      //File already exists - do nothing
      //Draw the background in grey
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x + 10, WIN1_YPOS + 115, 150, 14);
      display_set_fg_color(GREEN_COLOR); 
      display_text(x + 20, WIN1_YPOS + 115, "info_firmware.txt - OK");
      //while(1); 
      //timer0_delay(5000);
    }
}

//******************************************************************************

void check_firmware_files(void)
{
  check_file("firmware Atlan & PECO/bootloader.bin", 145, 131, 25);//145-149-25
  check_file("firmware Atlan & PECO/updater.bin", 145, 191, 33);//14-209-33
  check_file("firmware Atlan & PECO/scope.bin", 145, 251, 37);
  check_file("firmware Atlan & PECO/FPGA.bin", 145, 311, 40);
  check_file("firmware Atlan & PECO/data.cal", 145, 375, 40 );//40
  check_file("firmware Atlan & PECO/TP_Screen.bin", 145, 435, 25);
  
  check_file("firmware_FNIRSI/Fnirsi 1013D.bin", 535, 131, 20);//535-149-20
  check_file("firmware_FNIRSI_FPGA/Fnirsi FPGA.bin", 535, 191, 23);
  
  check_file("firmware_FNIRSI_BACKUP/Fnirsi backup.bin", 535, 311, 18);
}

//------------------------------------------------------------------------------

void check_file(const char *path, int x, int y,  int shift)
{
    int32 result; 
    FILINFO fno;

    //Check if the file exists
    result = f_stat(path, &fno);

    //Draw the white background
    display_set_fg_color(WHITE_COLOR);
    display_fill_rounded_rect(x, y, 127, 22, 3);
    display_set_font(&font_2);

    if (result == FR_OK && !(fno.fattrib & AM_DIR)) 
    {
      //File exists and is not a directory - show name and green box
      display_set_fg_color(GREEN_COLOR);
      display_draw_rounded_rect(x, y, 127, 22, 3);
      display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);

      
      display_set_fg_color(BLACK_COLOR);
      display_text(x + shift, y + 4, fno.fname);
      
      // Check if it's the specific file we are looking for
      if (my_strcmp(fno.fname, "Fnirsi backup.bin") == 0) 
      {
        //Button for DOWNLOAD
        scope_download_button(460, 290, 2);
      }
    } 
    else 
    {
      //File does not exist or is a directory - show red box and text
      display_set_fg_color(RED_COLOR);
      display_draw_rounded_rect(x, y, 127, 22, 3);
      display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
      display_text(x + 28, y + 4, "File missing !"); //160-320
    }
}

//******************************************************************************

int read_sdcard_to_file_with_progress(const char* filename, uint32 start_sector, uint32 num_sectors)
{
    FIL file;
    FRESULT fr;
    UINT bytes_written;
    uint32 sector = start_sector;
    
    const char* basename = filename;
    const char* p = filename;

    uint16 x = WIN1_XPOS + 20;

    // Save screen content where the progress window will be displayed
    display_set_destination_buffer(displaybuffertmp);
    display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

    // Draw the background and frame
    display_set_fg_color(GREY_COLOR);
    display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
    display_set_fg_color(WHITE_COLOR);
    display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

    // Display header
    display_set_font(&font_2);
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 15, WIN1_YPOS + 10, "Reading from SD card");

    display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 40, "Saving to file:");

        // Extract base file name from path
    while (*p) {
        if (*p == '/' || *p == '\\') basename = p + 1;
        p++;
    }

    // Show file name
    display_set_fg_color(WHITE_COLOR);
    display_text(x + 82, WIN1_YPOS + 40, (char *)basename);
    
    // Display filename
    //display_set_fg_color(WHITE_COLOR);
    //display_text(x + 82, WIN1_YPOS + 40, (char *)filename);

    // Open destination file
    fr = f_open(&file, filename, FA_CREATE_ALWAYS | FA_WRITE);
    if (fr != FR_OK) {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File open failed");
        display_set_fg_color(WHITE_COLOR);
        display_text(x + 32, WIN1_YPOS + 115, "Touch the screen");
        while ((havetouch == 0)) tp_i2c_read_status();
        while ((havetouch == 1)) tp_i2c_read_status();
        display_set_source_buffer(displaybuffertmp);
        display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
        return 1;
    }

    // Initialize progress bar
    progress_bar_init();
    
    // calculate progress_delay
    calculate_progress_delay(num_sectors);

    for (uint32 i = 0; i < num_sectors; i++) {
        if (sd_card_read(sector + i, 1, buffer) != SD_OK) {
            f_close(&file);
            return 1;
        }

        fr = f_write(&file, buffer, SECTOR_SIZE, &bytes_written);
        if (fr != FR_OK || bytes_written != SECTOR_SIZE) {
            f_close(&file);
            return 1;
        }

        // Update progress
        progress_bar_update(i + 1, num_sectors);
    }

    f_close(&file);

    // Complete message
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 37, WIN1_YPOS + 95, "Read complete");
    display_set_fg_color(WHITE_COLOR);
    display_text(x + 32, WIN1_YPOS + 115, "Touch the screen");
    while ((havetouch == 0)) tp_i2c_read_status();
    while ((havetouch == 1)) tp_i2c_read_status();
    display_set_source_buffer(displaybuffertmp);
    display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
    return 0;
}

//******************************************************************************

int write_file_to_sdcard_with_progress(const char* filename, uint32 start_sector)
{
    FIL file;
    FRESULT fr;
    UINT bytes_read;
    uint32 sector = start_sector;

    const char* basename = filename;
    const char* p = filename;
    
    uint16 x = WIN1_XPOS + 20;

    // Save screen content where the progress window will be displayed
    display_set_destination_buffer(displaybuffertmp);
    display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

    // Draw the background and frame
    display_set_fg_color(GREY_COLOR);
    display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
    display_set_fg_color(WHITE_COLOR);
    display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

    // Display header text
    display_set_font(&font_2);
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 30, WIN1_YPOS + 10, "Writing to SD card");

    display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 40, "Writing file:");

    // Extract base file name from path
    while (*p) {
        if (*p == '/' || *p == '\\') basename = p + 1;
        p++;
    }

    // Show file name
    display_set_fg_color(WHITE_COLOR);
    display_text(x + 72, WIN1_YPOS + 40, (char *)basename);

    // Open file
    fr = f_open(&file, filename, FA_READ);
    if (fr != FR_OK) {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File open failed");
        display_set_fg_color(WHITE_COLOR);
        display_text(x + 32, WIN1_YPOS + 115, "Touch the screen");
        while ((havetouch == 0)) tp_i2c_read_status();
        while ((havetouch == 1)) tp_i2c_read_status();
        display_set_source_buffer(displaybuffertmp);
        display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
        return 1;
    }

    // Prepare progress bar
    progress_bar_init();
    
    // Get total file size in sectors
    uint32_t total_bytes = f_size(&file);
    uint32_t total_sectors = (total_bytes + SECTOR_SIZE - 1) / SECTOR_SIZE;
    
    // calculate progress_delay
    calculate_progress_delay(total_sectors);

    uint32_t written_sectors = 0;

    while (1) {
        fr = f_read(&file, buffer, SECTOR_SIZE, &bytes_read);
        if (fr != FR_OK || bytes_read == 0) break;

        if (bytes_read < SECTOR_SIZE) {
            memset(buffer + bytes_read, 0xFF, SECTOR_SIZE - bytes_read);
        }

        if (sd_card_write(sector, 1, buffer) != SD_OK) {
            display_set_fg_color(RED_COLOR);
            display_text(x, WIN1_YPOS + 75, "SD card write failed");
            f_close(&file);
            while (1); // Error hang
        }

        sector++;
        written_sectors++;

        // Update progress bar
        progress_bar_update(written_sectors, total_sectors);
    }

    f_close(&file);

    // Write completed
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 37, WIN1_YPOS + 95, "Write complete");
    display_set_fg_color(WHITE_COLOR);
    display_text(x + 32, WIN1_YPOS + 115, "Touch the screen");
    while ((havetouch == 0)) tp_i2c_read_status();
    while ((havetouch == 1)) tp_i2c_read_status();
    display_set_source_buffer(displaybuffertmp);
    display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
    return 0;
}

//******************************************************************************

// Initialize progress bar on display
void progress_bar_init(void)
{
  uint16 x = WIN1_XPOS + 20;
  
  progress_bar[0] = '[';
  for (int i = 0; i < TOTAL_PROGRESS_STEPS; i++) progress_bar[i + 1] = ' ';
  progress_bar[TOTAL_PROGRESS_STEPS + 1] = ']';
  progress_bar[TOTAL_PROGRESS_STEPS + 2] = '\0';
  last_progress_index = 0;

  display_set_fg_color(WHITE_COLOR);
  display_text(x, WIN1_YPOS + 60, progress_bar);
}

//------------------------------------------------------------------------------

// Update progress bar with current progress
void progress_bar_update(uint32 current_step, uint32 total_steps)
{
  uint16 x = WIN1_XPOS + 20;
  uint32 step = (current_step * TOTAL_PROGRESS_STEPS) / total_steps;

  while (last_progress_index < step && last_progress_index < TOTAL_PROGRESS_STEPS)
  {
    progress_bar[last_progress_index + 1] = '.';
    last_progress_index++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x, WIN1_YPOS + 60, progress_bar);
  
// Slower progress according to the set variable
  timer0_delay(progress_delay);
}

//------------------------------------------------------------------------------

// calculate progress_delay
void calculate_progress_delay(uint32 num_sectors)
{
  // Set delay according to transfer size
  if      (num_sectors < 2)  progress_delay = 80;  
  else if (num_sectors < 40) progress_delay = 40;
  else if (num_sectors < 80) progress_delay = 20;
          else               progress_delay = 2;
}

//******************************************************************************


/*
int write_file_to_sdcard_with_progress(const char* filename, uint32 start_sector)
{
  FIL file;
  FRESULT fr;
  UINT bytes_read;
  uint32 sector = start_sector;
    
  const char* basename = filename;
  const char* p = filename;
    
  int16  x = WIN1_XPOS + 20;
    
  //Save the screen rectangle where the menu will be displayed
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
  //Draw the background in grey
  display_set_fg_color(GREY_COLOR);

  //Fill the background
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  
  //Display the frame in white
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  
  //Display the text in green
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  
  display_text(x + 30, WIN1_YPOS + 10, "Writing to SD card");
  //display_text(x, WIN1_YPOS + 10, "Writing to FLASH");
  
  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Writing file:");
  
  // Extract only the filename (without path)
  while (*p) 
  {
      if (*p == '/' || *p == '\\') {
          basename = p + 1;
      }
      p++;
  }

  // Show file name
  display_set_fg_color(WHITE_COLOR);
  display_text(x + 72, WIN1_YPOS + 40, (char *)basename);
  //display_text(x + 72, WIN1_YPOS + 30, "bootloader.bin");
  
    // Open file
    fr = f_open(&file, filename, FA_READ);
    if (fr != FR_OK) 
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File open failed");
 
        //Display the text with green color
        display_set_fg_color(WHITE_COLOR);
        display_text(x + 32, WIN1_YPOS + 115, "Touch the screen");  

        //Scan the touch panel to see if there is user input
        while((havetouch == 0)) tp_i2c_read_status();
        while((havetouch == 1)) tp_i2c_read_status();
        
        //Restore the screen when done
        display_set_source_buffer(displaybuffertmp);
        display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
        
        return 0;
        //On error just hang
        //while(1);
    }

    // Prepare progress bar
    char progress_bar[TOTAL_PROGRESS_STEPS + 3]; // + '[' + ']' + '\0'
    progress_bar[0] = '[';
    for (int i = 0; i < TOTAL_PROGRESS_STEPS; i++) progress_bar[i + 1] = ' ';
    progress_bar[TOTAL_PROGRESS_STEPS + 1] = ']';
    progress_bar[TOTAL_PROGRESS_STEPS + 2] = '\0';

    // Inicialny progress
    display_set_fg_color(WHITE_COLOR);
    display_text(x, WIN1_YPOS + 60, progress_bar);

    // Number of sectors
    uint32_t total_bytes = f_size(&file);
    uint32_t total_sectors = (total_bytes + SECTOR_SIZE - 1) / SECTOR_SIZE;

    uint32_t sectors_per_step = total_sectors / TOTAL_PROGRESS_STEPS;
    if (sectors_per_step == 0) sectors_per_step = 1;

    uint32_t written_sectors = 0;
    uint32_t progress_index = 0;

    while (1) 
    {
        fr = f_read(&file, buffer, SECTOR_SIZE, &bytes_read);
        if (fr != FR_OK || bytes_read == 0) break;

        if (bytes_read < SECTOR_SIZE) {
            memset(buffer + bytes_read, 0xFF, SECTOR_SIZE - bytes_read);
        }

        if (sd_card_write(sector, 1, buffer) != SD_OK) {
            display_set_fg_color(RED_COLOR);
            display_text(x, WIN1_YPOS + 75, "SD card write failed");
            f_close(&file);
            //On error just hang
            while(1);
        }

        sector++;
        written_sectors++;

        // Update progress bar
        if (written_sectors % sectors_per_step == 0 && progress_index < TOTAL_PROGRESS_STEPS) {
            progress_bar[progress_index + 1] = '.';  // pis .
            display_text(x, WIN1_YPOS + 60, progress_bar);

            progress_index++;

            // Slowdown
            timer0_delay(DELAY_PER_STEP_MS);
        }
    }

    f_close(&file);

  // Write successfully
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 37, WIN1_YPOS + 95, "Write complete");
    
  //Display the text with green color
  display_set_fg_color(WHITE_COLOR);
  display_text(x + 32, WIN1_YPOS + 115, "Touch the screen");  
   
  //Scan the touch panel to see if there is user input
  while((havetouch == 0)) tp_i2c_read_status();
  while((havetouch == 1)) tp_i2c_read_status();
  
  //Restore the screen when done
  display_set_source_buffer(displaybuffertmp);
  display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
  //timer0_delay(100);
  
  return 0;
}
*/
//******************************************************************************

void button_enable(void)
{
  //Boot Loader
  //Button for DOWNLOAD
  //scope_download_button(70, 110, 2);//118
  //Button for UPLOAD
  scope_upload_button(280, 110, 0);
    
  //Updater
  //Button for DOWNLOAD
  //scope_download_button(70, 170, 2);//178
  //Button for UPLOAD
  scope_upload_button(280, 170, 0);
  
  //DSO firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 230, 2);
  //Button for UPLOAD
  scope_upload_button(280, 230, 0);
  
  //FPGA firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 290, 2);
  //Button for UPLOAD
  scope_upload_button(280, 290, 0);
  
  //Calibration data
  //Button for DOWNLOAD
  scope_download_button(70, 354, 0);
  //Button for UPLOAD
  scope_upload_button(280, 354, 0);
  
  //TP & screen data
  //Button for DOWNLOAD
  scope_download_button(70, 414, 0);
  //Button for UPLOAD
  scope_upload_button(280, 414, 0);
  //----------------------------------
  
  //SPI Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 110, 2);
  //Button for UPLOAD
  scope_upload_button(670, 110, 0);
  
  //FPGA Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 170, 2);
  //Button for UPLOAD
  scope_upload_button(670, 170, 0);
  
  //SPI BACKUP Flash
  //Button for DOWNLOAD
  scope_download_button(460, 290, 0);
  //Button for UPLOAD
  scope_upload_button(670, 290, 0);
  
  button_status = 1;
}

//******************************************************************************

void button_disable(void)
{
  //Boot Loader
  //Button for DOWNLOAD
  //scope_download_button(70, 110, 2);//118
  //Button for UPLOAD
  scope_upload_button(280, 110, 2);
    
  //Updater
  //Button for DOWNLOAD
  //scope_download_button(70, 170, 2);//178
  //Button for UPLOAD
  scope_upload_button(280, 170, 2);
  
  //DSO firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 230, 2);
  //Button for UPLOAD
  scope_upload_button(280, 230, 2);
  
  //FPGA firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 290, 2);
  //Button for UPLOAD
  scope_upload_button(280, 290, 2);
  
  //Calibration data
  //Button for DOWNLOAD
  scope_download_button(70, 354, 2);
  //Button for UPLOAD
  scope_upload_button(280, 354, 2);
  
  //TP & screen data
  //Button for DOWNLOAD
  scope_download_button(70, 414, 2);
  //Button for UPLOAD
  scope_upload_button(280, 414, 2);
  
  //----------------------------------
  
  //SPI Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 110, 2);
  //Button for UPLOAD
  scope_upload_button(670, 110, 2);
  
  //FPGA Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 170, 2);
  //Button for UPLOAD
  scope_upload_button(670, 170, 2);
  
  //SPI BACKUP Flash
  //Button for DOWNLOAD
  scope_download_button(460, 290, 2);
  //Button for UPLOAD
  scope_upload_button(670, 290, 2);
  
  button_status = 0;
}

//******************************************************************************

int my_strcmp(const char *s1, const char *s2)
{
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(const unsigned char *)s1 - *(const unsigned char *)s2;
}

//******************************************************************************

void load_from_SDcard(uint32 address)
{   
  unsigned int blocks;
  int retval;
  unsigned int length;
  
    //Load the first program sector from the SD card
    if(sd_card_read(address, 1, buffer) != SD_OK)
    {
      display_set_fg_color(RED_COLOR);
      //display_text(305, 300, "SD card first read failed");
      display_text(295, 300, "SD card program read failed");

      //On error just frees
      while(1);
    }

    //Check if there is a brom header there
    if(memcmp(&buffer[4], "eGON.EXE", 8) != 0)
    {
      display_set_fg_color(RED_COLOR);
      display_text(337, 300, "Not an executable");

      //On error just frees
      while(1);
    }

    //Get the length from the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]);

    //Calculate the number of sectors to read
    blocks = (length + 511) / 512;

    //Copy the first program bytes to DRAM (So the eGON header is skipped)
    memcpy((void *)0x80000000, &buffer[32], 480);

    //Check if more data needs to be read
    if(blocks > 1)
    {
      //Already read the first block
      blocks--;

      //Load the remainder of the program from the SD card
      if((retval = sd_card_read(address + 1, blocks, (void *)0x800001E0)) != SD_OK)
      {
        display_set_fg_color(BLACK_COLOR);
        //Fill the settings background
        display_fill_rect(0, 0, 800, 480);  //x , y , sirka, vyska
          
        display_set_fg_color(RED_COLOR);
        display_text(190, 100, "SD card, Failed reading program sector");
        display_text(190, 130, "Error: ");
        display_text(190, 160, "Sector: ");
        display_set_fg_color(WHITE_COLOR);
        display_decimal(350, 130, retval);
        display_decimal(350, 160, blocks);

        //On error just frees
        while(1);
      }
    }
     //Start the chosen code
  __asm__ __volatile__ ("mov pc, %0\n" :"=r"(address):"0"(address));
}
/*
DWORD get_fattime (void)
{
    uint8   year = 25;
    uint8   month = 11;
    uint8   day = 3;    
    uint8 hour = 11;
            uint8   minute = 30;
                uint8   tm_sec = 22;
        
    
  

      //return date and time (FATtime original year-1980)
      return (DWORD)(year+20) << 25 |
             (DWORD)(month) << 21 |
             (DWORD)(day) << 16 |
             (DWORD)(hour) << 11 |
             (DWORD)minute << 5 |
             (DWORD)tm_sec >> 1;
}
 * */
//******************************************************************************