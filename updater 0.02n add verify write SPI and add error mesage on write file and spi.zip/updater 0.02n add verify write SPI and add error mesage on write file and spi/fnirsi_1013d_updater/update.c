

#include "update.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "variables.h"
#include "types.h"
#include "timer.h"
//#include "scope_functions.h"
#include "menu.h"
#include "touchpanel.h"
#include "spi_control.h"

//#include <string.h>

//---------------------------------------------------------------------

#define TOTAL_PROGRESS_STEPS 56//57 50
uint32 progress_delay = 5; // default value in milliseconds (can be modified when calling the function)
//#define TOTAL_WRITE_TIME_MS 200
//#define DELAY_PER_STEP_MS (TOTAL_WRITE_TIME_MS / TOTAL_PROGRESS_STEPS)

// Global progress bar buffer
char progress_bar[TOTAL_PROGRESS_STEPS + 3]; // '[' + 50 steps + ']' + '\0'
uint32 last_progress_index = 0;
//uint32 speed;
//uint32 DELAY_PER_STEP_MS;


#define SECTOR_SIZE 512
//Buffer for reading/writing from SD card
//unsigned char buffer[SECTOR_SIZE];

//******************************************************************************
//******************************************************************************

void ini_folders(void) 
{
  int16  x = WIN1_XPOS + 20;
  
  //Save the screen rectangle where the menu will be displayed
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
  //Draw the background in grey
  display_set_fg_color(GREY_COLOR);

  //Fill the background
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  
  display_set_font(&font_2);
  
  //Setup and check SD card on file system being present
  if(f_mount(&fs, "0", 1))
  {
    //Show SD card error message on failure
    //Display the message in red
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 10, "SD MOUNT ERROR");

    //On error just hang
    while(1);
  }
  
  //Display the message in white
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);  
  
  display_text(x, WIN1_YPOS + 10, "Search folders...");
  
/*
       //Show a message creating the directory
      display_text(x, WIN1_YPOS+40, "firmware FNIRSI");
      timer0_delay(1000);
      display_text(x, WIN1_YPOS+55, "firmware FNIRSI FPGA");
      timer0_delay(1000);firmware Atlan & PECO
      display_text(x, WIN1_YPOS+70, "firfirmware FNIRSImware Atlan & PECO");
      timer0_delay(1000);
      display_text(x, WIN1_YPOS+85, "firmware Atlan & PECO FPGA");
      timer0_delay(1000);
  
       while(1);
 */
  
  create_directory_if_missing("firmware_FNIRSI", x, WIN1_YPOS+40);
  create_directory_if_missing("firmware_FNIRSI_FPGA", x, WIN1_YPOS+55);
  
  create_directory_if_missing("firmware Atlan & PECO", x, WIN1_YPOS+70);
  create_directory_if_missing("firmware Atlan & PECO FPGA", x, WIN1_YPOS+85);
  
  create_directory_if_missing("firmware_FNIRSI_BACKUP", x, WIN1_YPOS+100);
  
  //Check TXT file, create if missing
  create_info_firmware_file_if_missing(x);
  
  timer0_delay(1000);
  
  //Restore the screen when done
  display_set_source_buffer(displaybuffertmp);
  display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
  
}
    
//------------------------------------------------------------------------------

void create_directory_if_missing(char* dirname, int16 x, int16 y)  
{
  int32  result;    
  
  //Check the status of the directory for this view type
  result = f_stat(dirname, 0);

  //See if there is an error
  if(result != FR_OK)
  {
    //If so check if the directory does not exist
    if(result == FR_NO_FILE)
    {
      //Draw the background in grey
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x + 150, WIN1_YPOS + 10, 35, 14);//135
      
      //Display the message in red
      display_set_fg_color(RED_COLOR);
      display_text(x + 155, WIN1_YPOS + 10, "FAIL");//140
      
      //Create the directory
      result = f_mkdir(dirname);
      
      //Display the message in green
      display_set_fg_color(GREEN_COLOR);
      display_text(x, WIN1_YPOS+25, "Create folder:");
     
      //Show a message creating the directory
      //Display the message in white
      display_set_fg_color(WHITE_COLOR);
      display_text(x, y, dirname);
      timer0_delay(1000);
      
      if(result != FR_OK)
      {
        //Show a message stating creating the directory failed
        //Display the message in red
        display_set_fg_color(RED_COLOR);
        display_set_font(&font_2);
        display_text(x, WIN1_YPOS + 40, "MESSAGE_DIRECTORY_CREATE_FAILED");
        
        //On error just hang
        while(1);
      }
    }
  } 
  else 
  {      
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    //display_set_fg_color(YELLOW_COLOR);
    display_fill_rect(x + 150, WIN1_YPOS + 10, 35, 14);//135-10-35-14
    display_set_fg_color(GREEN_COLOR); 
    display_text(x + 155, WIN1_YPOS + 10, "OK");//140
    //display_set_fg_color(YELLOW_COLOR);
    //display_fill_rect(x + 150, WIN1_YPOS + 20, 35, 14);//135
    //display_set_fg_color(GREEN_COLOR);
    //display_text(x + 155, WIN1_YPOS + 20, "FAIL");
    //while(1); 
  }     
}

//******************************************************************************

// Main firmware info file creation/update
void create_info_firmware_file_if_missing(int16 x)
{
  FIL file;
  FRESULT res;
  const char *filename = "info_firmware.txt";
  const char *content =
    "************************************************************************************\r\n"
    "Updater firmware: " VERSION_STRING "\r\n"
    "------------------------------------------------------------------------------------\r\n"
    "Boot Loader      - bootloader.bin\r\n"
    "Updater          - updater.bin\r\n"
    "DSO firmware     - scope.bin\r\n"
    "FPGA firmware    - FPGA.bin                ( Hardware modification required )\r\n"
    "\r\n"
    "Calibration data - data.cal                ( Backup file for: Calibration data )\r\n"
    "Touch pad and screen data - TP_Screen.bin  ( Backup file for: TP & screen settings )\r\n"
    "------------------------------------------------------------------------------------\r\n"
    "SPI Flash        - Fnirsi 1013D.bin  14.06.2024\r\n"
    "FPGA Flash       - Fnirsi FPGA.bin   ( Hardware modification required )\r\n"
    "-----------------------------------------------------------------------\r\n"
    "SPI Flash backup - Fnirsi FLASH backup.bin\r\n"
    "************************************************************************************\r\n"
    "updater.bmp      - updater program startup image\r\n"
    "scope.bmp        - scope program startup image\r\n"
    "************************************************************************************\r\n";

  FILINFO fno;
  res = f_stat(filename, &fno);

  uint8 file_exists = 0;
  uint8 need_update = 0;

  if (res == FR_OK)
  {
    file_exists = 1; // file already exists
      
    // File exists — check if version matches
    res = f_open(&file, filename, FA_READ);
    if (res == FR_OK)
    {
      char buffer[256];  // read only the beginning of the file
      UINT bytes_read;
      f_read(&file, buffer, sizeof(buffer) - 1, &bytes_read);
      f_close(&file);

      buffer[bytes_read] = '\0';

      // Find the line containing "Updater firmware:"
      const char *ver_line = my_strstr(buffer, "Updater firmware:");
      if (ver_line)
      {
        // Move pointer to version string
        ver_line += strlen("Updater firmware:");
        while (*ver_line == ' ' || *ver_line == '\t') ver_line++;

        // Extract version from file
        char version_in_file[64] = {0};
        int i = 0;
        while (*ver_line && *ver_line != '\r' && *ver_line != '\n' && i < (int)(sizeof(version_in_file) - 1))
        {
          version_in_file[i++] = *ver_line++;
        }
        version_in_file[i] = '\0';

        // Compare with program version
        if (my_strcmp(version_in_file, VERSION_STRING) != 0) need_update = 1;
      }
      else
      {
        // No version line found → update required
        need_update = 1;
      }
    }
    else
    {
      // Could not open file for reading → update required
      need_update = 1;
    }
  }
  else
  {
    // File does not exist → create new one
    need_update = 1;
    file_exists = 0;
  }
    
  //set font
  display_set_font(&font_2);
    
  if (need_update)
  {
    // Show message: creating or updating file
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x, WIN1_YPOS + 115, 165, 14);//x+10
        
    if (file_exists)
    {
      display_set_fg_color(ORANGE_COLOR);
      //display_text(x + 5, WIN1_YPOS + 115, "info_firmware.txt updated");
      display_text(x + 13, WIN1_YPOS + 115, "Updating info_firmware.txt");//3
    }
    else
    {
      display_set_fg_color(YELLOW_COLOR);
      display_text(x + 14, WIN1_YPOS + 115, "Creating info_firmware.txt");//3
    }

    timer0_delay(1000);//2

    // Open or create new file for writing
    res = f_open(&file, filename, FA_WRITE | FA_CREATE_ALWAYS);
    if (res == FR_OK)
    {
      UINT bytes_written;
      res = f_write(&file, content, strlen(content), &bytes_written);
      f_close(&file);

      if (res == FR_OK && bytes_written == strlen(content))
      {
        //Draw the background in grey
        display_set_fg_color(GREY_COLOR);
        display_fill_rect(x, WIN1_YPOS + 130, 165, 14);
        display_set_fg_color(GREEN_COLOR);
        //display_text(x + 5, WIN1_YPOS + 115, "info_firmware.txt updated");
        if (file_exists) display_text(x + 15, WIN1_YPOS + 130, "info_firmware.txt updated");//5-130
          else display_text(x + 16, WIN1_YPOS + 130, "info_firmware.txt created");
        timer0_delay(2000);//3
        //while(1);
      }
      else
      {
        //Write error
        //Draw the background in grey
        display_set_fg_color(GREY_COLOR);
        display_fill_rect(x + 18, WIN1_YPOS + 130, 145, 14);
        display_set_fg_color(RED_COLOR);
        display_text(x + 34, WIN1_YPOS + 130, "Write in txt file - Fail");//25
        //display_text(x + 25, WIN1_YPOS + 115, "Write error in txt file");
        timer0_delay(5000);//5000
      }
    }
    else
    {
      // Failed to create or open file for writing
      //Draw the background in grey
      display_set_fg_color(GREY_COLOR);
      display_fill_rect(x, WIN1_YPOS + 130, 180, 14);
      //Display the message in red
      display_set_fg_color(RED_COLOR);
      display_text(x + 1, WIN1_YPOS + 130, "MESSAGE_FILE_CREATE_FAILED");
      while (1);
    }
  }
  else
  {
    // File is up to date
    //Draw the background in grey
    display_set_fg_color(GREY_COLOR);
    display_fill_rect(x + 18, WIN1_YPOS + 130, 145, 14);
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 28, WIN1_YPOS + 130, "info_firmware.txt - OK");
    //while(1); 
  }
}

//******************************************************************************

void check_firmware_files(void)
{
  check_file("firmware Atlan & PECO/bootloader.bin", 145, 131, 8);//145-131-25//145-149-25
  check_file("firmware Atlan & PECO/updater.bin", 145, 191, 11);//33//14-209-33
  check_file("firmware Atlan & PECO/scope.bin", 145, 251, 14);//37
  check_file("firmware Atlan & PECO FPGA/FPGA.bin", 145, 311, 40);
  check_file("firmware Atlan & PECO/data.cal", 145, 375, 40 );//40
  check_file("firmware Atlan & PECO/TP_Screen.bin", 145, 435, 25);
  
  check_file("firmware_FNIRSI/Fnirsi 1013D.bin", 535, 131, 20);//535-149-20
  check_file("firmware_FNIRSI_FPGA/Fnirsi FPGA.bin", 535, 191, 23);
  
  check_file("firmware_FNIRSI_BACKUP/Fnirsi backup.bin", 535, 311, 18);
}

//------------------------------------------------------------------------------

void check_file(const char *path, int x, int y,  int shift)
{
    char folder_path[128];
    char base_prefix[32];
    FILINFO fno;
    DIR dir;
    int32 result;
    int8 file_found = 0;

// Split 'path' into folder and base filename
    const char *slash = my_strrchr(path, '/');
    if (slash) {
        my_strncpy(folder_path, path, slash - path);
        folder_path[slash - path] = '\0';
        my_strcpy(base_prefix, slash + 1);
    } else {
        my_strcpy(folder_path, "");
        my_strcpy(base_prefix, path);
    }

    // Remove ".bin" or ".cal" extension from base_prefix if present
    char *dot = (char *)my_strstr(base_prefix, ".bin");
    if (!dot)
        dot = (char *)my_strstr(base_prefix, ".cal");
    if (dot)
        *dot = '\0';

    // Try to open target folder
    result = f_opendir(&dir, folder_path);
    if (result != FR_OK) {
        display_set_fg_color(RED_COLOR);
        display_draw_rounded_rect(x, y, 127, 22, 3);
        display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
        display_text(x + 18, y + 4, "Folder missing!");
        return;
    }

    // Search for matching files in the folder
    while (f_readdir(&dir, &fno) == FR_OK && fno.fname[0]) {
        if (!(fno.fattrib & AM_DIR)) {
            // Match file starting with base_prefix and ending with ".bin" or ".cal"
            if (starts_with(fno.fname, base_prefix) &&
                (ends_with(fno.fname, ".bin") || ends_with(fno.fname, ".cal"))) {
                file_found = 1;
                break;
            }
        }
    }
    f_closedir(&dir);

    // Draw background
    display_set_font(&font_2);
    display_set_fg_color(WHITE_COLOR);
    display_fill_rounded_rect(x, y, 127, 22, 3);

    // Show result box
    if (file_found) {
        display_set_fg_color(GREEN_COLOR);
        display_draw_rounded_rect(x, y, 127, 22, 3);
        display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
        display_set_fg_color(BLACK_COLOR);
        display_text(x + shift, y + 4, fno.fname);

        // Optional special behavior for specific files
        if (my_strcmp(fno.fname, "data.cal") == 0)
            download_button_cal_data = 0;

        if (my_strcmp(fno.fname, "TP_Screen.bin") == 0)
            download_button_TP_Screen_data = 0;

        if (my_strcmp(fno.fname, "Fnirsi backup.bin") == 0)
            download_button_SPI_BACKUP_Flash = 0;
    } else {
        display_set_fg_color(RED_COLOR);
        display_draw_rounded_rect(x, y, 127, 22, 3);
        display_draw_rounded_rect(x + 1, y + 1, 125, 20, 3);
        display_text(x + 28, y + 4, "File missing!");
    }
}

//----------------------------------------------------------------
// Pomocná funkcia: skontroluje, či reťazec začína daným prefixom
int8 starts_with(const char *str, const char *prefix)
{
    while (*prefix) {
        if (*prefix++ != *str++) return 0;
    }
    return 1;
}
//----------------------------------------------------------------
// Pomocná funkcia: skontroluje, či reťazec končí daným sufixom
int8 ends_with(const char *str, const char *suffix)
{
    int lenstr = my_strlen(str);
    int lensuffix = my_strlen(suffix);
    if (lensuffix > lenstr) return 0;
    return (my_strcmp(str + lenstr - lensuffix, suffix) == 0);
}


//******************************************************************************

int read_sdcard_to_file_with_progress(const char* filename, uint32 start_sector, uint32 num_sectors)
{
  FIL file;
  FRESULT fr;
  UINT bytes_written;
  uint32 sector = start_sector;
  uint8 buffer[512];
   
  const char* basename = filename;
  const char* p = filename;

  uint16 x = WIN1_XPOS + 20;

  // Save screen content where the progress window will be displayed
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

  // Draw the background and frame
  display_set_fg_color(GREY_COLOR);
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

  // Display header
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 27, WIN1_YPOS + 10, "Reading from SD card");//24 15*

  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Saving to file:");

  // Extract base file name from path
  while (*p) 
  {
    if (*p == '/' || *p == '\\') basename = p + 1;
    p++;
  }

  // Show file name
  display_set_fg_color(WHITE_COLOR);
  display_text(x + 82, WIN1_YPOS + 40, (char *)basename);
    
  //Display filename
  //display_set_fg_color(WHITE_COLOR);
  //display_text(x + 82, WIN1_YPOS + 40, (char *)filename);

  // Open destination file
  fr = f_open(&file, filename, FA_CREATE_ALWAYS | FA_WRITE);
  if (fr != FR_OK) 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "File open failed");
    text_and_touch_the_screen(x);
    return 1;
  }

  // Initialize progress bar
  progress_bar_init();
    
  // calculate progress_delay
  calculate_progress_delay(num_sectors);

  for (uint32 i = 0; i < num_sectors; i++) 
  {
    if (sd_card_read(sector + i, 1, buffer) != SD_OK) 
    {
      f_close(&file);
      display_set_fg_color(RED_COLOR);
      display_text(x, WIN1_YPOS + 75, "SD card read error");
      text_and_touch_the_screen(x);
      return 2;

    }

    fr = f_write(&file, buffer, SECTOR_SIZE, &bytes_written);
    if (fr != FR_OK || bytes_written != SECTOR_SIZE) 
    {
      f_close(&file);
      display_set_fg_color(RED_COLOR);
      display_text(x, WIN1_YPOS + 75, "File write failed");
      text_and_touch_the_screen(x);
      return 3;
    }

    // Update progress
    progress_bar_update(i + 1, num_sectors);
  }

  f_close(&file);

  // Complete message
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 48, WIN1_YPOS + 95, "Read complete");//46 37*
  text_and_touch_the_screen(x);
  return 0;
}

//******************************************************************************

int write_file_to_sdcard_with_progress(const char* filename, uint32 start_sector)
{
    FIL file;
    FRESULT fr;
    UINT bytes_read;
    uint32 sector = start_sector;
    uint8 buffer[512];
    
    char folder[128];
    char prefix[64];
    //char filepath[128];
    char found_file[128];
    FILINFO fno;
    DIR dir;

    const char* basename = filename;
    const char* p = filename;
    
    uint16 x = WIN1_XPOS + 20;
    
    display_set_destination_buffer(displaybuffertmp);
    display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
    display_set_fg_color(GREY_COLOR);
    display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
    display_set_fg_color(WHITE_COLOR);
    display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
    display_set_font(&font_2);
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 39, WIN1_YPOS + 10, "Writing to SD card");//30-10*
    display_set_fg_color(YELLOW_COLOR);
    display_text(x, WIN1_YPOS + 40, "Writing file:");

    // --- 1. Split folder and base name ---
    const char* last_slash = my_strrchr(filename, '/');
    if (!last_slash) {
        my_strcpy(folder, ".");
        my_strcpy(prefix, filename);
    } else {
        size_t folder_len = last_slash - filename;
        my_strncpy(folder, filename, folder_len);
        folder[folder_len] = 0;
        my_strcpy(prefix, last_slash + 1);
    }

    // Remove extension from prefix (.bin or .cal)  
    char* dot = my_strrchr(prefix, '.');
    if (dot) *dot = 0;

    // --- 2. Search for matching file ---
    fr = f_opendir(&dir, folder);
    if (fr != FR_OK) 
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "Folder open failed");
        text_and_touch_the_screen(x);
        return 1;
    }

    int file_found = 0;
    while (1)
    {
        fr = f_readdir(&dir, &fno);
        if (fr != FR_OK || fno.fname[0] == 0) break;

        if (!(fno.fattrib & AM_DIR))
        {
            // Check if name starts with prefix and ends with .bin or .cal
            if (my_strstr(fno.fname, prefix) == fno.fname)
            {
                const char* ext = my_strrchr(fno.fname, '.');
                if (ext && 
                   (my_strcasecmp(ext, ".bin") == 0 || my_strcasecmp(ext, ".cal") == 0))
                {
                    my_sprintf_path(found_file, folder, fno.fname);
                    file_found = 1;
                    break;
                }
            }
        }
    }

    f_closedir(&dir);

    if (!file_found)
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File not found");
        text_and_touch_the_screen(x);
        return 1;
    }

    // --- 3. display file name ---
    basename = found_file;
    p = found_file;
    while (*p) 
    {
        if (*p == '/' || *p == '\\') basename = p + 1;
        p++;
    }

    display_set_fg_color(WHITE_COLOR);
    display_text(x + 72, WIN1_YPOS + 40, (char *)basename);

    // --- 4. Open file ---
    fr = f_open(&file, found_file, FA_READ);
    if (fr != FR_OK) 
    {
        display_set_fg_color(RED_COLOR);
        display_text(x, WIN1_YPOS + 60, "File open failed");
        text_and_touch_the_screen(x);
        return 1;
    }

    // --- 5. Write with progress ---
    progress_bar_init();
    
    uint32_t total_bytes = f_size(&file);
    uint32_t total_sectors = (total_bytes + SECTOR_SIZE - 1) / SECTOR_SIZE;
    calculate_progress_delay(total_sectors);

    uint32_t written_sectors = 0;
    while (1) 
    {
        fr = f_read(&file, buffer, SECTOR_SIZE, &bytes_read);
        if (fr != FR_OK || bytes_read == 0) break;

        if (bytes_read < SECTOR_SIZE) memset(buffer + bytes_read, 0xFF, SECTOR_SIZE - bytes_read);

        if (sd_card_write(sector, 1, buffer) != SD_OK) 
        {
          display_set_fg_color(RED_COLOR);
          display_text(x, WIN1_YPOS + 75, "SD card write failed");
          f_close(&file);
          text_and_touch_the_screen(x);
          return 2;
        }

        sector++;
        written_sectors++;
        progress_bar_update(written_sectors, total_sectors);
    }

    f_close(&file);

    // --- 6. Done ---
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 48, WIN1_YPOS + 95, "Write complete");//37-95*
    text_and_touch_the_screen(x);

    return 0;
}


//******************************************************************************
void text_and_touch_the_screen(int16 x)
{
        display_set_fg_color(WHITE_COLOR);
        display_text(x + 42, WIN1_YPOS + 115, "Touch the screen");
        while ((havetouch == 0)) tp_i2c_read_status();
        while ((havetouch == 1)) tp_i2c_read_status();
        display_set_source_buffer(displaybuffertmp);
        display_copy_rect_to_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);
}
        
//******************************************************************************

int read_spi_flash_to_file_with_progress(const char* filename)
{
  FIL file;
  FRESULT fr;
  UINT bytes_written;
  uint32 addr = 0;
  uint32 total_size = 0x200000;      // // default 2 MB (25VQ16)
  uint32 sector_size = FLASH_SECTOR_SIZE; // 4096
  uint32 num_sectors;
  //uint32 num_sectors = total_size / sector_size;
  
  uint8 buffer[FLASH_SECTOR_SIZE];  
  
  const char* basename = filename;
  const char* p = filename;

  uint16 x = WIN1_XPOS + 20;

  // Save screen content
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

  // Draw window
  display_set_fg_color(GREY_COLOR);
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

  // Header
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 40, WIN1_YPOS + 10, "Reading SPI flash");//31*
  
  // Detect flash size using JEDEC ID
  total_size = sys_spi_flash_read_jedec_id();
  if (total_size == 0)  //0
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "SPI flash not detected");
    f_close(&file);
    text_and_touch_the_screen(x);
    return 1;
  }
  
  num_sectors = total_size / sector_size;

  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Saving to:");

  // Extract file name
  while (*p) 
  {
      if (*p == '/' || *p == '\\') basename = p + 1;
      p++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x + 65, WIN1_YPOS + 40, (char *)basename);//67 65

  // Open file
  fr = f_open(&file, filename, FA_CREATE_ALWAYS | FA_WRITE);
  if (fr != FR_OK) 
  {
      display_set_fg_color(RED_COLOR);
      display_text(x, WIN1_YPOS + 60, "File open failed");
      text_and_touch_the_screen(x);
      return 2;
  }

  progress_bar_init();
  //calculate_progress_delay(num_sectors);
  progress_delay = 0;

  // Read flash sector by sector (4 KB each)
  for (uint32 i = 0; i < num_sectors; i++) 
  {
      sys_spi_flash_read(addr, buffer, sector_size);
      fr = f_write(&file, buffer, sector_size, &bytes_written);
      if (fr != FR_OK || bytes_written != sector_size) {
          f_close(&file);
          display_set_fg_color(RED_COLOR);
          display_text(x, WIN1_YPOS + 75, "File write failed");
          text_and_touch_the_screen(x);
          return 3;
      }

      addr += sector_size;
      progress_bar_update(i + 1, num_sectors);
  }

  f_close(&file);

  // Done
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 32, WIN1_YPOS + 95, "Flash read complete");//23*
  text_and_touch_the_screen(x);

  return 0;
}

//******************************************************************************

int write_file_to_spi_flash_with_progress(const char* filename, uint32 start_address)
{
  FIL file;
  FRESULT fr;
  UINT bytes_read;
  uint32 addr = start_address;
  uint32 total_size = 0x200000; // default 2 MB (25VQ16)
  uint32 sector_size = FLASH_SECTOR_SIZE; // 4096
  uint32 num_sectors = 0;
  
  uint8 buffer[FLASH_SECTOR_SIZE];
  uint8 verify_buffer[FLASH_SECTOR_SIZE];
  uint8 verify_error = 0;

  const char* basename = filename;
  const char* p = filename;
  uint16 x = WIN1_XPOS + 20;

  // Save current screen content
  display_set_destination_buffer(displaybuffertmp);
  display_copy_rect_from_screen(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT);

  // Draw progress window
  display_set_fg_color(GREY_COLOR);
  display_fill_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);
  display_set_fg_color(WHITE_COLOR);
  display_draw_rounded_rect(WIN1_XPOS, WIN1_YPOS, WIN1_WIDTH, WIN1_HEIGHT, 3);

  // Header
  display_set_font(&font_2);
  display_set_fg_color(GREEN_COLOR);
  display_text(x + 34, WIN1_YPOS + 10, "Writing to SPI flash");//25*

  display_set_fg_color(YELLOW_COLOR);
  display_text(x, WIN1_YPOS + 40, "Writing file:");

  // Extract file name from path
  while (*p) 
  {
    if (*p == '/' || *p == '\\') basename = p + 1;
    p++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x + 72, WIN1_YPOS + 40, (char *)basename);//67

  // Open input file
  fr = f_open(&file, filename, FA_READ);
  if (fr != FR_OK) 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "File open failed");
    text_and_touch_the_screen(x);
    return 1;
  }

  // Detect flash size using JEDEC ID
  total_size = sys_spi_flash_read_jedec_id();
  if (total_size == 0)  //0
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "SPI flash not detected");
    f_close(&file);
    text_and_touch_the_screen(x);
    return 2;
  }
  
  //total_size = 0x400000; // docasne na test
  num_sectors = total_size / sector_size;

  // Get file size and compute total sectors to write
  uint32 total_bytes = f_size(&file);
  uint32 total_file_sectors = (total_bytes + sector_size - 1) / sector_size;

  // Check available space in flash
  if ((start_address + total_bytes) > total_size) 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x, WIN1_YPOS + 60, "Not enough space in flash");
    f_close(&file);
    text_and_touch_the_screen(x);
    return 3;
  }
  
  progress_bar_init();

  //calculate_progress_delay(total_file_sectors);
  progress_delay = 0;

  // Erase and write flash sector by sector (4 KB each)
  for (uint32 i = 0; i < total_file_sectors; i++) 
  {
    fr = f_read(&file, buffer, sector_size, &bytes_read);
    if (fr != FR_OK) break;
    if (bytes_read == 0) break;

    // Pad last sector with 0xFF if not full
    if (bytes_read < sector_size) { memset(buffer + bytes_read, 0xFF, sector_size - bytes_read); }

    sys_spi_flash_write_enable();
    sys_spi_flash_erase_sector(addr);
    sys_spi_flash_wait_while_busy();

    sys_spi_flash_program_sector(addr, buffer, sector_size);
    sys_spi_flash_wait_while_busy();
    
    //----------------
    // Verification step
    sys_spi_flash_read(addr, verify_buffer, sector_size);
    if (memcmp(buffer, verify_buffer, sector_size) != 0) 
    {
      verify_error = 1;
      display_set_fg_color(ORANGE_COLOR);
      display_text(x + 40, WIN1_YPOS + 75, "Verification failed");//35
      break;
    }
    //------------------

    addr += sector_size;
    progress_bar_update(i + 1, total_file_sectors);
  }

  f_close(&file);
  
    // Done or failed message
  if (verify_error == 0) 
  {
    display_set_fg_color(YELLOW_COLOR);
    display_text(x + 31, WIN1_YPOS + 75, "Flash write verified");
    display_set_fg_color(GREEN_COLOR);
    display_text(x + 31, WIN1_YPOS + 95, "Flash write complete");//22*
    
    text_and_touch_the_screen(x);

    return 0;
  } 
  else 
  {
    display_set_fg_color(RED_COLOR);
    display_text(x + 43, WIN1_YPOS + 95, "Flash write error!");
    
    text_and_touch_the_screen(x);

    return 4;
  }
  //return (verify_error ? 4 : 0);
}

//******************************************************************************

//Initialize progress bar on display
void progress_bar_init(void)
{
  uint16 x = WIN1_XPOS + 20;
  
  progress_bar[0] = '[';
  for (int i = 0; i < TOTAL_PROGRESS_STEPS; i++) progress_bar[i + 1] = ' ';
  progress_bar[TOTAL_PROGRESS_STEPS + 1] = ']';
  progress_bar[TOTAL_PROGRESS_STEPS + 2] = '\0';
  last_progress_index = 0;

  display_set_fg_color(WHITE_COLOR);
  display_text(x, WIN1_YPOS + 60, progress_bar);
}

//------------------------------------------------------------------------------

//Update progress bar with current progress
void progress_bar_update(uint32 current_step, uint32 total_steps)
{
  uint16 x = WIN1_XPOS + 20;
  uint32 step = (current_step * TOTAL_PROGRESS_STEPS) / total_steps;

  while (last_progress_index < step && last_progress_index < TOTAL_PROGRESS_STEPS)
  {
    progress_bar[last_progress_index + 1] = '.';
    last_progress_index++;
  }

  display_set_fg_color(WHITE_COLOR);
  display_text(x, WIN1_YPOS + 60, progress_bar);
  
  //Slower progress according to the set variable
  timer0_delay(progress_delay);
}

//------------------------------------------------------------------------------

//calculate progress_delay
void calculate_progress_delay(uint32 num_sectors)
{
  // Set delay according to transfer size
  if      (num_sectors < 2)  progress_delay = 80;  
  else if (num_sectors < 40) progress_delay = 40;
  else if (num_sectors < 80) progress_delay = 20;
//else if (num_sectors < 160) progress_delay = 2;
          else                progress_delay = 1;
}

//******************************************************************************

void button_enable(void)
{
  //Boot Loader
  //Button for DOWNLOAD
  scope_download_button(70, 110, 2);//118
  //Button for UPLOAD
  scope_upload_button(280, 110, 0);
    
  //Updater
  //Button for DOWNLOAD
  scope_download_button(70, 170, 2);//178
  //Button for UPLOAD
  scope_upload_button(280, 170, 0);
  
  //DSO firmware
  //Button for DOWNLOAD
  scope_download_button(70, 230, 2);
  //Button for UPLOAD
  scope_upload_button(280, 230, 0);
  
  //FPGA firmware
  //Button for DOWNLOAD
  scope_download_button(70, 290, 2);
  //Button for UPLOAD
  scope_upload_button(280, 290, 0);
  
  //Calibration data
  //Button for DOWNLOAD
  if(download_button_cal_data) scope_download_button(70, 354, 0);
    else scope_download_button(70, 354, 2);
  //Button for UPLOAD
  scope_upload_button(280, 354, 0);
  
  //TP & screen data
  //Button for DOWNLOAD
  if(download_button_TP_Screen_data) scope_download_button(70, 414, 0);
    else scope_download_button(70, 414, 2);
  //Button for UPLOAD
  scope_upload_button(280, 414, 0);
  //----------------------------------
  
  //SPI Flash
  //Button for DOWNLOAD
  scope_download_button(460, 110, 2);
  //Button for UPLOAD
  if(!download_button_SPI_BACKUP_Flash) scope_upload_button(670, 110, 0);
    else scope_upload_button(670, 110, 2);
  
  //FPGA Flash
  //Button for DOWNLOAD
  scope_download_button(460, 170, 2);
  //Button for UPLOAD
  if(!download_button_SPI_BACKUP_Flash) scope_upload_button(670, 170, 0);
    else scope_upload_button(670, 170, 2);
  
  //SPI BACKUP Flash
  //Button for DOWNLOAD
  if(download_button_SPI_BACKUP_Flash) scope_download_button(460, 290, 0);
    else scope_download_button(460, 290, 2);
  //Button for UPLOAD
  if(download_button_SPI_BACKUP_Flash) scope_upload_button(670, 290, 2);
    else scope_upload_button(670, 290, 0);
  
 //download_button_cal_data = 0;
//download_button_TP_Screen_data = 0;
// download_button_SPI_BACKUP_Flash = 0;
  
  button_status = 1;
}

//******************************************************************************

void button_disable(void)
{
  //Boot Loader
  //Button for DOWNLOAD
  //scope_download_button(70, 110, 2);//118
  //Button for UPLOAD
  scope_upload_button(280, 110, 2);
    
  //Updater
  //Button for DOWNLOAD
  //scope_download_button(70, 170, 2);//178
  //Button for UPLOAD
  scope_upload_button(280, 170, 2);
  
  //DSO firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 230, 2);
  //Button for UPLOAD
  scope_upload_button(280, 230, 2);
  
  //FPGA firmware
  //Button for DOWNLOAD
  //scope_download_button(70, 290, 2);
  //Button for UPLOAD
  scope_upload_button(280, 290, 2);
  
  //Calibration data
  //Button for DOWNLOAD
  scope_download_button(70, 354, 2);
  //Button for UPLOAD
  scope_upload_button(280, 354, 2);
    //Remove the current item from the thumbnails and delete the item from disk
  //scope_remove_item_from_thumbnails(1);

  //Save the thumbnail file
  //scope_save_thumbnail_file();
  //TP & screen data
  //Button for DOWNLOAD
  scope_download_button(70, 414, 2);
  //Button for UPLOAD
  scope_upload_button(280, 414, 2);
  
  //----------------------------------
  
  //SPI Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 110, 2);
  //Button for UPLOAD
  scope_upload_button(670, 110, 2);
  
  //FPGA Flash
  //Button for DOWNLOAD
  //scope_download_button(460, 170, 2);
  //Button for UPLOAD
  scope_upload_button(670, 170, 2);
  
  //SPI BACKUP Flash
  //Button for DOWNLOAD
  scope_download_button(460, 290, 2);
  //Button for UPLOAD
  scope_upload_button(670, 290, 2);
  
  button_status = 0;
}

//******************************************************************************

//Simple strstr replacement: find substring within string
const char *my_strstr(const char *haystack, const char *needle)
{
  if (!*needle) return haystack; // Empty substring always matches

  const char *p1 = haystack;
  while (*p1)
  {
    const char *p1_begin = p1;
    const char *p2 = needle;

    // Compare characters
    while (*p1 && *p2 && (*p1 == *p2))
    {
      p1++;
      p2++;
    }

    if (!*p2) return p1_begin; // Found match

    p1 = p1_begin + 1; // Move to next position
  }

  return 0; // Not found
}

//-----------------------------------------------------------------

int my_strcmp(const char *s1, const char *s2)
{
  while (*s1 && (*s1 == *s2)) 
  {
    s1++;
    s2++;
  }
  return *(const unsigned char *)s1 - *(const unsigned char *)s2;
}

char *my_strrchr(const char *s, int c)
{
    const char *last = 0;
    do {
        if (*s == (char)c)
            last = s;
    } while (*s++);
    return (char*)last;
}

char *my_strcpy(char *dest, const char *src)
{
    char *d = dest;
    while ((*d++ = *src++));
    return dest;
}

char *my_strncpy(char *dest, const char *src, int n)
{
    int i;
    for (i = 0; i < n && src[i]; i++) dest[i] = src[i];
    for (; i < n; i++) dest[i] = '\0';
    return dest;
}

int my_strlen(const char *s)
{
    int len = 0;
    while (*s++) len++;
    return len;
}

// Simple sprintf for path joining (no formatting)
void my_sprintf_path(char *dst, const char *folder, const char *fname)
{
    while (*folder) *dst++ = *folder++;
    *dst++ = '/';
    while (*fname) *dst++ = *fname++;
    *dst = 0;
}

// Case-insensitive compare
int my_strcasecmp(const char *s1, const char *s2)
{
    while (*s1 && *s2)
    {
        char c1 = *s1++;
        char c2 = *s2++;
        if (c1 >= 'A' && c1 <= 'Z') c1 += 32;
        if (c2 >= 'A' && c2 <= 'Z') c2 += 32;
        if (c1 != c2) return (unsigned char)c1 - (unsigned char)c2;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

//******************************************************************************

//----------------------------------------------------------------------------------------------------------------------------------

int32 load_picture(const char* filename)
{
  uint32 result;
  //uint32 x = 300;
  display_set_font(&font_2);

  //Set the name in the global buffer for message display
  //strcpy(viewfilename, viewthumbnaildata[viewcurrentindex].filename);

  //Try to open the file for reading
  result = f_open(&viewfp, filename, FA_READ);

  //Check if file opened ok
  if(result == FR_OK)
  {
    //Read the bitmap header to verify if the bitmap can be displayed
    result = f_read(&viewfp, viewbitmapheader, PICTURE_HEADER_SIZE, 0);

    //Check if still ok to proceed
    if(result == FR_OK)
    {
      //Check if the header matches what it should be
      if(memcmp(viewbitmapheader, bmpheader, PICTURE_HEADER_SIZE) == 0)
      {
        //display_set_fg_color(RED_COLOR);
        //display_text(x, WIN1_YPOS + 15, "OK");
        //timer0_delay(3000);
        //Load the bitmap data directly onto the screen
        result = f_read(&viewfp, (uint8 *)maindisplaybuffer, PICTURE_DATA_SIZE, 0);
      }
      else
      {
        //Signal a header mismatch detected
        result = PICTURE_HEADER_MISMATCH;

        //Show the user the file is not correct
        //scope_display_file_status_message(MESSAGE_BMP_HEADER_MISMATCH, 0);
        display_set_fg_color(RED_COLOR);
        display_text(320, 185, "MESSAGE_BMP_HEADER_MISMATCH");
        timer0_delay(3000);
      }
    }

    //Done with the file so close it
    f_close(&viewfp);

    //Check if one of the reads failed
    if((result != FR_OK) && (result != PICTURE_HEADER_MISMATCH))
    {
      //Signal unable to read from the file
      //scope_display_file_status_message(MESSAGE_FILE_READ_FAILED, 0);
      display_set_fg_color(RED_COLOR);
      display_text(320, 200, "MESSAGE_FILE_READ_FAILED");
      timer0_delay(3000);
    }
  }
  else
  {
    //Signal unable to open the file
    //scope_display_file_status_message(MESSAGE_FILE_OPEN_FAILED, 0);
    display_set_fg_color(RED_COLOR);
    display_text(320, 220, "MESSAGE_FILE_OPEN_FAILED");
    display_set_fg_color(YELLOW_COLOR);
    display_text(270, 250, "Please copy the update.bmp file to the SD card.");
    //while(1);
    timer0_delay(5000);
  }

  //Check if all went well
  if(result == FR_OK)
  {
    //Tell it to the caller
    return(VIEW_BITMAP_LOAD_OK);
  }
  
  return(VIEW_BITMAP_LOAD_ERROR);
}

//----------------------------------------------------------------------------------------------------------------------------------

void load_from_SDcard(uint32 address)
{   
  unsigned int blocks;
  int retval;
  unsigned int length;
  //Buffer for reading/writing from SD card
  unsigned char buffer[512];
  
    //Load the first program sector from the SD card
    if(sd_card_read(address, 1, buffer) != SD_OK)
    {
      display_set_fg_color(RED_COLOR);
      //display_text(305, 300, "SD card first read failed");
      display_text(295, 300, "SD card program read failed");

      //On error just frees
      while(1);
    }

    //Check if there is a brom header there
    if(memcmp(&buffer[4], "eGON.EXE", 8) != 0)
    {
      display_set_fg_color(RED_COLOR);
      display_text(337, 300, "Not an executable");

      //On error just frees
      while(1);
    }

    //Get the length from the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]);

    //Calculate the number of sectors to read
    blocks = (length + 511) / 512;

    //Copy the first program bytes to DRAM (So the eGON header is skipped)
    memcpy((void *)0x80000000, &buffer[32], 480);

    //Check if more data needs to be read
    if(blocks > 1)
    {
      //Already read the first block
      blocks--;

      //Load the remainder of the program from the SD card
      if((retval = sd_card_read(address + 1, blocks, (void *)0x800001E0)) != SD_OK)
      {
        display_set_fg_color(BLACK_COLOR);
        //Fill the settings background
        display_fill_rect(0, 0, 800, 480);  //x , y , sirka, vyska
          
        display_set_fg_color(RED_COLOR);
        display_text(190, 100, "SD card, Failed reading program sector");
        display_text(190, 130, "Error: ");
        display_text(190, 160, "Sector: ");
        display_set_fg_color(WHITE_COLOR);
        display_decimal(350, 130, retval);
        display_decimal(350, 160, blocks);

        //On error just frees
        while(1);
      }
    }
     //Start the chosen code
  __asm__ __volatile__ ("mov pc, %0\n" :"=r"(address):"0"(address));
}
/*
DWORD get_fattime (void)
{
    uint8   year = 25;
    uint8   month = 11;
    uint8   day = 3;    
    uint8 hour = 11;
            uint8   minute = 30;
                uint8   tm_sec = 22;
        
    
  

      //return date and time (FATtime original year-1980)
      return (DWORD)(year+20) << 25 |
             (DWORD)(month) << 21 |
             (DWORD)(day) << 16 |
             (DWORD)(hour) << 11 |
             (DWORD)minute << 5 |
             (DWORD)tm_sec >> 1;
}
 * */
//******************************************************************************