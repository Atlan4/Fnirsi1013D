//----------------------------------------------------------------------------------------------------------------------------------

#include "arm32.h"
#include "ccu_control.h"

#include "touchpanel.h"	    //add 0.025c

#include "dram_control.h"
#include "display_control.h"
#include "spi_control.h"
#include "bl_display_lib.h"
#include "bl-uart.h"
#include "bl_fpga_control.h"
#include "bl_sd_card_interface.h"
#include "bl_variables.h"

#include <string.h>

#define BLACK_COLOR            0x00000000   //*
#define DARKGREY_COLOR         0x00181818   //*
#define LIGHTGREY_COLOR        0x00333333   //* lebo dark?
#define GREY_COLOR             0x00444444   //* 
#define LIGHTGREY1_COLOR       0x00606060   //* 
#define WHITE_COLOR            0x00FFFFFF   //*
#define RED_COLOR              0x00FF0000   //*
#define YELLOW_COLOR           0x00FFFF00   //*
#define DARKGREEN_COLOR        0x0000BB00   //*
#define GREEN_COLOR            0x0000FF00   //*
#define BLUE_COLOR             0x0000FFFF   //*
#define DARKBLUE_COLOR         0x00000078   //* 
#define ORANGE_COLOR           0x00FF8000   //*
#define MAGENTA_COLOR          0x00FF00FF   //*

//----------------------------------------------------------------------------------------------------------------------------------
// This code now works but needs a debug flag to disable the displaying of information
//
// For the 1014D a new version that only loads the main code without showing messages and does not wait for the FPGA
// can be distilled and tested.
//
// There is a problem with the SD card code though when used with a specific 4GB card. Could be a speed issue
//----------------------------------------------------------------------------------------------------------------------------------
// The bootloader itself starts on sector 16, so in the package the firmware should be copied in from address 0x8000
//  to allow for 32KB boot loader
//----------------------------------------------------------------------------------------------------------------------------------

#define PROGRAM_START_SECTOR      80

//----------------------------------------------------------------------------------------------------------------------------------

//Buffer for reading header from SD card
unsigned char buffer[512];

//----------------------------------------------------------------------------------------------------------------------------------

int main(void)
{
  //Set the address to run the loaded main program
  unsigned int address = 0x80000000; 
  unsigned int length;
  unsigned int blocks;
  int choice = 0;
  int i,j, retval;
  uint32 waittime = 0;
  
  //Initialize the clock system
  sys_clock_init();
  
  //Initialize the internal DRAM
  sys_dram_init();

  //Instead of full memory management just the caches enabled
  arm32_icache_enable();
  arm32_dcache_enable();
  
  //Initialize display (PORT D + DEBE)
  sys_init_display(SCREEN_WIDTH, SCREEN_HEIGHT, (uint16 *)maindisplaybuffer);
  
  //Setup the display lib
  display_set_screen_buffer((uint16 *)maindisplaybuffer);
  display_set_dimensions(SCREEN_WIDTH, SCREEN_HEIGHT);

  //Setup for error message display
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_0);
  
  //Initialize UART1 for communication with the user interface microcontroller
  //uart1_init();
  
  //Initialize FPGA (PORT E)
  fpga_init();
  
  //Got some time to spare
  for(j=0;j<1000;j++)
  {
    //At 600MHz CPU_CLK 1000 = ~200uS
    for(i=0;i<1000;i++);
  }
  
  //Wait and make sure FPGA is ready
  fpga_check_ready();

  //Turn on the display brightness
  //fpga_set_backlight_brightness(0x4E20);//0xEA60-100%
    //Turn of the display brightness
  fpga_set_backlight_brightness(0x20);
  
  //Setup the touch panel interface
  tp_i2c_setup();
  havetouch = 0;
  xtouch = 0;
  ytouch = 0;
  
//------------------------------------------------------------------------------
  
  display_set_fg_color(LIGHTGREY_COLOR);
  //Fill the settings background
  display_fill_rect(40,  55, 122, 25);  //x , y , sirka, vyska
  display_fill_rect(340, 55, 130, 25);  //x , y , sirka, vyska
  display_fill_rect(620, 55, 138, 25);  //x , y , sirka, vyska
  
  display_set_fg_color(WHITE_COLOR);
  //Setup the choices texts
  display_text(50,  60, "PECO firmware");
  display_text(350, 60, "Start FEL mode");
  display_text(630, 60, "FNIRSI firmware");

    
  //Display the text with green color
  display_set_fg_color(GREEN_COLOR);
  display_text(300, 200, "Choices mode on the screen"); 
  
  //Display the text with green color
  display_set_fg_color(YELLOW_COLOR);
  display_text(205, 430, "Many thanks to PECO, and small thanks to Atlan :)"); 
  
  //Scan the touch panel to see if there is user input
  while(havetouch == 0) 
  //while(choice == 0)    
  {
    tp_i2c_read_status();
    havetouch = 0; 
      
    /*
    display_set_fg_color(BLACK_COLOR);
    //Fill the settings background
    display_fill_rect(50, 200, 200, 13);  //x , y , sirka, vyska
    display_set_fg_color(WHITE_COLOR);
    display_text(50,  180, "xtouch  ytouch");
    display_decimal(50,   200, xtouch);
    display_decimal(100,  200, ytouch);
    */
       
    
    
    //Scan for where the touch is applied, PEPCO firmware - SDcart
    if((xtouch >= 50) && (xtouch <= 150) && (ytouch >= 50) && (ytouch <= 90))  {choice = 0; havetouch = 1;}
         
    //Scan for where the touch is applied, FEL mode - RAM
    if((xtouch >= 350) && (xtouch <= 450) && (ytouch >= 50) && (ytouch <= 90)) {choice = 2; havetouch = 1;}
          
    //Scan for where the touch is applied, Fnirsi firmware - SPI Flash
    if((xtouch >= 650) && (xtouch <= 750) && (ytouch >= 50) && (ytouch <= 90)) {choice = 1; havetouch = 1;} 
    
    if(waittime>7000) havetouch = 1; //10500 is 5sec, 5500 2.5s
    //if(waittime>5500) choice = 1; //10500 is 5sec, 5500 2.5s
    waittime++;
          
  }
  //display_set_fg_color(WHITE_COLOR);
  //Fill the settings background
  //display_fill_rect(0, 0, 800, 480);  //x , y , sirka, vyska
  
  //Display the text with green color
  display_set_fg_color(ORANGE_COLOR);
  display_text(360, 250, "LOADING...");

  //Wait until the 500 milliseconds have passed
  for(j=0;j<500;j++)       //500 is 500ms ,1000 is 1s
  {
    //At 600MHz CPU_CLK 5000 = ~2000uS
    for(i=0;i<5000;i++);
  }
  
  //Load the chosen program
  if(choice == 0)
  {
    //Initialize the SD card
    if(sd_card_init() != SD_OK)
    {
      display_set_fg_color(0x00FF0000);
      display_text(10, 10, "SD card init failed");

      //On error just frees
      while(1);
    }

    //Load the first program sector from the SD card
    if(sd_card_read(PROGRAM_START_SECTOR, 1, buffer) != SD_OK)
    {
      display_set_fg_color(0x00FF0000);
      display_text(10, 10, "SD card first read failed");

      //On error just frees
      while(1);
    }

    //Check if there is a brom header there
    if(memcmp(&buffer[4], "eGON.EXE", 8) != 0)
    {
      display_set_fg_color(0x00FF0000);
      display_text(10, 10, "Not an executable");

      //On error just frees
      while(1);
    }

    //Get the length from the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]);

    //Calculate the number of sectors to read
    blocks = (length + 511) / 512;

    //Copy the first program bytes to DRAM (So the eGON header is skipped)
    memcpy((void *)0x80000000, &buffer[32], 480);

    //Check if more data needs to be read
    if(blocks > 1)
    {
      //Already read the first block
      blocks--;

      //Load the remainder of the program from the SD card
      if((retval = sd_card_read(PROGRAM_START_SECTOR + 1, blocks, (void *)0x800001E0)) != SD_OK)
      {
        display_set_fg_color(0x00FF0000);
        display_text(10, 10, "Failed reading program sector");
        display_text(10, 26, "Error: ");
        display_text(10, 42, "Sector: ");
        display_decimal(150, 26, retval);
        display_decimal(150, 42, blocks);

        //On error just frees
        while(1);
      }
    }

  }
  else if(choice == 1)
  {
    //Initialize SPI for flash (PORT C + SPI0)
    sys_spi_flash_init();
  
    //Load the main program from flash
    //Get the header first
    sys_spi_flash_read(0x27000, buffer, 32);

    //Original boot loader checks on eGON.EXE file identifier

    //Get the length from the header and take of the header
    length = ((buffer[19] << 24) | (buffer[18] << 16) | (buffer[17] << 8) | buffer[16]) - 32;

    //Read the main program into DRAM. 
    sys_spi_flash_read(0x27020, (unsigned char *)0x80000000, length);
  }
  else
  {
    //Clear the screen
    display_set_fg_color(0x00000000);
    display_fill_rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    //Show the scope is in FEL mode
    display_set_fg_color(0x00FFFFFF);
    display_text(340, 230, "Running FEL mode");
    
    //Set the address to run the FEL code
    address = 0xFFFF0020;
  }

  //Start the chosen code
  __asm__ __volatile__ ("mov pc, %0\n" :"=r"(address):"0"(address));
}
