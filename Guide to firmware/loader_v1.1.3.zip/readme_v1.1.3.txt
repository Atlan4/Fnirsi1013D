FNIRSI Firmware Loader

v1.1.3
Minor changes, added buttons to write or clear boot mode byte. Added warning when FEL mode and disabled boot menu selected.

v1.1.2
Added "Boot Mode" page to configure which firmware should be loaded and whether the boot menu should be available. As usual, the values ​​can be edited by double-clicking on the text label.

v1.1.1
Minor UI bugs fixed. Main window resizing disabled.

Added default name for calibration file save dialog, it is current date in yyyy-mm-dd format. Of course you can enter your own name.

Reformatting the card doesn't work yet, but I've added a first version of repartitioning procedure. It overwrites the MBR and creates a single FAT32-LBA partition (regardless of the SD card size) with the required number of hidden sectors. You'll need to unplug and replug the device after resizing, Windows should prompt you to format it. After format reselect the device in the loader. This feature won't work for GPT-partitioned cards, for now you have to repartition it with Rufus etc.
You can now use old small SD cards (1GB or less) that have too few hidden sectors, just change its count. The correct number of hidden sectors is 1023 (for the current alternative firmware) or more.
Also you can repartition new large SDHC cards (64GB or more), but it's useless for now, because of Windows formats these cards as NTFS or exFAT, not FAT32.
THIS FEATURE IS DESTRUCTIVE for files on the card, not finished and is not fully tested yet, use with caution.

The partition type code is displayed for the partition type "Unknown" (this feature is mainly for me, not for users). Added some known partition types.


v1.1.0

The default extension of LCD/TP configuration files has been changed to ".cnf" instead of ".bin" (not the same as firmware). You can open ".bin" configuration files with the appropriate filter, also small ".bin" files will be listed.

Partition type and number of "hidden" sectors are now displayed for the selected device. The value will be red if the card is formatted with a non-FAT32 partition or with insufficient number of hidden sectors (write operation will be disabled on this card). Some additional checks for correctness of MBR structure have been added (write operations will be disabled on errors).
The "Reformat" button does not work yet, sorry.

"Calibration" page added to save/load/clear calibration data sector (708, value can be changed by double clicking on the text label). Default extension for these files is ".cal".


v1.0.0

This utility can load/verify/delete binary firmware directly to the USB-connected oscilloscope or to an SD card in a card reader. It can also read/write/clear/compile/fix LCD/TP configuration sector and load/save it as a file.

The utility writes directly to the physical sectors of the selected device, so there is a potential risk of data corruption. As usual, use it at your own risk. But I tried to make it safe enough - it won't work with devices that aren't USB, recognized by the system as hard drives, have a non-512 byte sector size, containing a system volume, etc (and won't even put that devices on the list). Also it can read but will not write to physical sectors that falls within MBR and existing partitions of any type (except of RAW).

The "F1C100S" device (i.e. Allwinner CPU of Fnirsi 1013D/1014D oscilloscope) will be the selected device by default if it is present, then the software will look for SD/SDHC cards and then for other USB storage devices. Side effect: USB flash drives will also be on the list because I don't know of a reliable way to distinguish them from noname USB card readers.

The utility requires administrator rights to directly access the physical device. If you are using an administrative account, you do not need to start it as an administrator, elevation will be performed by software itself (you may just get a UAC warning). For a non-administrative account, you will be prompted for administrator credentials.

This software does not have any undocumented, trojan or destructive features, and does not use any third party libraries and components. It does not write anything to the file system or registry. It's made with Delphi VCL and pure Win32API. Software compatible with systems from Windows XP SP3 to Windows 11 (both X86 and X64). Any bug reports and suggestions are welcome.

How to use: For convenience, place this .exe in the same folder as the firmware binaries (and configuration binaries, if needed) and run. Do not worry about safely removing the device, the program writes data immediately, ignoring system caching.

PS: Sorry for not implementing automatic light/dark theme switching, ;-) maybe in the next version...
PPS: For curiosity and possible future use: disabled input fields can be unlocked by double-clicking on the text label near it.