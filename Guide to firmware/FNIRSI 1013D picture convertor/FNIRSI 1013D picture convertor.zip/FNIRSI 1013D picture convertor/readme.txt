The program finds the image, converts it and saves it as scope.bmp
Image with a resolution of 800x480,add color information, 565RGB (16 or 24bit)

1. Copy the image with a resolution of 800x480 to the program folder.
2. Run Scope_picture_convertor



