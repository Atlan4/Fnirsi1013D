1. Copy the image with a resolution of 800x480 to the program folder.
2. Run Scope_picture_convertor

The program finds the image, converts it and saves it as scope.bmp
