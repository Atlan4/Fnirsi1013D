/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   update.h
 * Author: dk
 *
 * Created on October 2, 2025, 9:59 AM
 */

#ifndef UPDATE_H
#define UPDATE_H

#include "types.h"

void ini_folders(void);
void create_directory_if_missing(char* dirname, int16 x, int16 y);
//void update_procedure(void);
//void create_directory_if_missing(const char *dirname, uint16 y);

//DWORD get_fattime (void);

#endif /* UPDATE_H */

