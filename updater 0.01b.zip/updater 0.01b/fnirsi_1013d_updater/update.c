/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.c to edit this template
 */

#include "update.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "variables.h"
#include "types.h"
#include "timer.h"





void ini_folders(void) 
{
  int16  x = CD_XPOS + 20;
  
  //Setup and check SD card on file system being present
  if(f_mount(&fs, "0", 1))
  {
    //Show SD card error message on failure
    //Display the message in red
    display_set_fg_color(RED_COLOR);
    //display_set_font(&font_3);
    display_set_font(&font_2);
    display_text(50, 150, "SD MOUNT ERROR");

    //On error just hang
    while(1);
  }
  
  //Save the screen rectangle where the menu will be displayed
  display_set_destination_buffer(displaybuffer1);
  display_copy_rect_from_screen(CD_XPOS, CD_YPOS, CD_WIDTH, CD_HEIGHT);
  
  //Display the message in red
  display_set_fg_color(WHITE_COLOR);
  display_set_font(&font_2);
  
  display_draw_rounded_rect(CD_XPOS, CD_YPOS, CD_WIDTH, CD_HEIGHT, 3);  
  
  display_text(x, CD_YPOS+10, "Search folders...");
  
/*
       //Show a message creating the directory
      display_text(x, CD_YPOS+40, "firmware FNIRSI");
      timer0_delay(1000);
      display_text(x, CD_YPOS+55, "firmware FNIRSI FPGA");
      timer0_delay(1000);
      display_text(x, CD_YPOS+70, "firmware Atlan & PECO");
      timer0_delay(1000);
      display_text(x, CD_YPOS+85, "firmware Atlan & PECO FPGA");
      timer0_delay(1000);
  
       while(1);
 */
  
  create_directory_if_missing("firmware FNIRSI", x, CD_YPOS+40);
  create_directory_if_missing("firmware FNIRSI FPGA", x, CD_YPOS+55);
  
  create_directory_if_missing("firmware Atlan & PECO", x, CD_YPOS+70);
  create_directory_if_missing("firmware Atlan & PECO FPGA", x, CD_YPOS+85);
  
  timer0_delay(3000);
  
  //Restore the screen when done
  display_set_source_buffer(displaybuffer1);
  display_copy_rect_to_screen(CD_XPOS, CD_YPOS, CD_WIDTH, CD_HEIGHT);
}
    

void create_directory_if_missing(char* dirname, int16 x, int16 y)  
{
  int32  result;    
  
  //Check the status of the directory for this view type
  result = f_stat(dirname, 0);

  //See if there is an error
  if(result != FR_OK)
  {
    //If so check if the directory does not exist
    if(result == FR_NO_FILE)
    {
      //Display the message in red
      display_set_fg_color(RED_COLOR);
      display_text(x + 130, CD_YPOS + 10, "FAIL");
      
      //Create the directory
      result = f_mkdir(dirname);
      
      //Display the message in green
      display_set_fg_color(GREEN_COLOR);
      display_text(x, CD_YPOS+25, "Create folder:");
     
      //Show a message creating the directory
      //Display the message in white
      display_set_fg_color(WHITE_COLOR);
      display_text(x, y, dirname);
      timer0_delay(2000);
      
      if(result != FR_OK)
      {
        //Show a message stating creating the directory failed
        //Display the message in red
        display_set_fg_color(RED_COLOR);
        display_set_font(&font_2);
        display_text(50, 150, "MESSAGE_DIRECTORY_CREATE_FAILED");
        
        //On error just hang
        while(1);
      }
    }
  } else { display_set_fg_color(GREEN_COLOR); display_text(x + 130, CD_YPOS + 10, "OK"); }     
}

//******************************************************************************
/*
DWORD get_fattime (void)
{
    uint8   year = 25;
    uint8   month = 11;
    uint8   day = 3;    
    uint8 hour = 11;
            uint8   minute = 30;
                uint8   tm_sec = 22;
        
    
  

      //return date and time (FATtime original year-1980)
      return (DWORD)(year+20) << 25 |
             (DWORD)(month) << 21 |
             (DWORD)(day) << 16 |
             (DWORD)(hour) << 11 |
             (DWORD)minute << 5 |
             (DWORD)tm_sec >> 1;
}
 * */
//******************************************************************************