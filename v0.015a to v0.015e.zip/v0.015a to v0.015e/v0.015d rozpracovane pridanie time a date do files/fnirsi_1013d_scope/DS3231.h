
//#define DS3231_W 0xD0     // 0x4E	//write
//#define DS3231_R 0xD1     // 0x4F 	//read

#define RTC_DEVICE_ADDR    0xD0

#include "types.h"

void iniDS3231(void);

void readtime(void);
void sec (void);
void minut (void);
void hodin (void);


void settime(void);
void minp (void);
void hodp (void);

void strcatx ( unsigned char *d, unsigned char *s );

