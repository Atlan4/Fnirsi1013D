//The connections are:
//  PA2:  SDA
//  PA3:  SCL
/*
#include <avr/io.h>
#include <util/twi.h>
#include <util/delay.h>          //kniznica pre oneskorenia
*/

#include "variables.h"
#include "touchpanel.h"
#include "DS3231.h"

//#include	<stdio.h>
//#include 	"lcd.h"

//***********************************************************
//----------------------------------------------------------
//***********************************************************
void readtime(void)
	{
	uint8 buftimeX[3];	// 
        uint8 jedsec,jedmin,jedhod,dessec,desmin,deshod;

	//i2c_start(DS3231_W);
	//i2c_readReg(DS3231_W,0x00,buftime,3); RTC_DEVICE_ADDR
	//i2c_stop();
        
        //tp_i2c_read_data(uint8 adr_dev, uint16 reg_addr, uint8 *buffer, uint32 size) 
     //Read the data of the RTC
  //tp_i2c_read_data(RTC_DEVICE_ADDR, TP_STATUS_REG, &status, 1);
   tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 3);
  

    //tp_i2c_send_data(RTC_DEVICE_ADDR, TP_STATUS_REG, data, 1);
    
        

	dessec=buftimeX[0]>>4;
	dessec&=7;
	jedsec=buftimeX[0]&15;

	desmin=buftimeX[1]>>4;
	desmin&=7;
	jedmin=buftimeX[1]&15;

	deshod=buftimeX[2]>>4;
	deshod&=3;
        jedhod=buftimeX[2]&15;
        
        //if(deshod)buftime[0]=deshod+48; else buftime[0]=' ';
        buftime[0]=deshod+48;
        
        buftime[1]=jedhod+48;
        buftime[2]=':';
        buftime[3]=desmin+48;
        buftime[4]=jedmin+48;
        buftime[5]=':';
        buftime[6]=dessec+48;
        buftime[7]=jedsec+48;
        
        
        
	}
//;---------------------------------------------------------------
//****************************************************************
void settime	(void)		//;prenos i2c DS3231
	{
        //unsigned char tmp=0;
/*
	i2c_start(DS3231_W);
	i2c_write(0b00000000);	//zapisovat sa bude do konf regis
//	i2c_write(0b10000100);	//zastavi sa citanie impulzov
//	i2c_write(0b00000000);	//zapise sa 0 tiscin sek
	i2c_write(0b00000000);	//zapise sa 0sekund

	tmp=desmin<<4;
	tmp|=jedmin;
	i2c_write(tmp);		//zapise minuty

	tmp=deshod<<4;
	tmp|=jedhod;
	i2c_write(tmp);		//zapise hodiny

	i2c_stop();
*/
	return;
	}
//****************************************************************
//*************************  Set time  ***************************
//****************************************************************
void minp (void)
	{
	if (jedmin<9) jedmin++; 
		else {jedmin=0; if (desmin<5) desmin++; 
			else {desmin=0;}}
	settime();
	return;
	}
//--------------------------------------------------
void hodp (void)
	{
	if ((deshod==2)&(jedhod==3)){deshod=0;jedhod=0;} 
	else {
 			if (jedhod<9) jedhod++;			
				else {jedhod=0; if (deshod<2) deshod++;
					else {deshod=0;}}
		 }
	settime();
	return;
	}
//-------------------------------------------------------
//*******************************************************
//strcatx(thumbnaildata->filename, timecode);
 void modname ( int8 *d, int8 *s )
{
   int8 filename[32];
   uint8 x=0;

 //copy *s to filename  
   while(*s) 
      {
      filename[x++] = *s;
      s++;
      }  
   filename[x++]=' ';

   while(*d)
      {
      if (*d==115) {d=d+2;break;}
      d++;      
      }
  //copy *d to filename
   while(*d) 
      {
      filename[x] = *d;
      d++;
      x++;
      }  

   d=d-16;
   filename[x++]=0;
   
   x=0;
   while(filename[x]!= 0) 
      {
      *d = filename[x];
      x++;
      d++;  
      }
   *d=0;
}