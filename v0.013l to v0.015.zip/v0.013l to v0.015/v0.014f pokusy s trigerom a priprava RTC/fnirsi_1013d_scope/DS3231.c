//The connections are:
//  PA2:  SDA
//  PA3:  SCL
/*
#include <avr/io.h>
#include <util/twi.h>
#include <util/delay.h>          //kniznica pre oneskorenia
*/

#include "variables.h"
#include "touchpanel.h"
#include "DS3231.h"

//#include	<stdio.h>
//#include 	"lcd.h"

//***********************************************************
//----------------------------------------------------------
//***********************************************************
void readtime(void)
	{
	unsigned char buftime[3];	// 

	//i2c_start(DS3231_W);
	//i2c_readReg(DS3231_W,0x00,buftime,3);
	//i2c_stop();
        
        //tp_i2c_read_data(uint16 reg_addr, uint8 *buffer, uint32 size);

	dessec=buftime[0]>>4;
	dessec&=7;
	jedsec=buftime[0]&15;

	desmin=buftime[1]>>4;
	desmin&=7;
	jedmin=buftime[1]&15;

	deshod=buftime[2]>>4;
	deshod&=3;
	jedhod=buftime[2]&15;
	}
//;---------------------------------------------------------------
//****************************************************************
void settime	(void)		//;prenos i2c DS3231
	{unsigned char tmp=0;
/*
	i2c_start(DS3231_W);
	i2c_write(0b00000000);	//zapisovat sa bude do konf regis
//	i2c_write(0b10000100);	//zastavi sa citanie impulzov
//	i2c_write(0b00000000);	//zapise sa 0 tiscin sek
	i2c_write(0b00000000);	//zapise sa 0sekund

	tmp=desmin<<4;
	tmp|=jedmin;
	i2c_write(tmp);		//zapise minuty

	tmp=deshod<<4;
	tmp|=jedhod;
	i2c_write(tmp);		//zapise hodiny

	i2c_stop();
*/
	return;
	}
//****************************************************************
//*************************  Set time  ***************************
//****************************************************************
void minp (void)
	{
	if (jedmin<9) jedmin++; 
		else {jedmin=0; if (desmin<5) desmin++; 
			else {desmin=0;}}
	settime();
	return;
	}
//--------------------------------------------------
void hodp (void)
	{
	if ((deshod==2)&(jedhod==3)){deshod=0;jedhod=0;} 
	else {
 			if (jedhod<9) jedhod++;			
				else {jedhod=0; if (deshod<2) deshod++;
					else {deshod=0;}}
		 }
	settime();
	return;
	}
//-------------------------------------------------------
//*******************************************************

