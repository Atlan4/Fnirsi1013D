
//#define DS3231_W 0xD0     // 0x4E	//write
//#define DS3231_R 0xD1     // 0x4F 	//read

#define RTC_DEVICE_ADDR    0xD0



uint8 dati2c;
uint8 jedsec,jedmin,jedhod,dessec,desmin,deshod;
uint8 jedmina,jedhoda,desmina,deshoda;	

//	unsigned char adrIO=0b10100000;	//Adresa chipu DS3231 !!!!!
//	unsigned char adr08=0b00010000; //bit 0-3 no timer,4-5 01 daily alarm,bit6 timer alaram,bit7 alarm on off
	
void iniDS3231(void);

void readtime(void);
void sec (void);
void minut (void);
void hodin (void);


void settime(void);
void minp (void);
void hodp (void);

