//The connections are:
//  PA2:  SDA
//  PA3:  SCL
/*
#include <avr/io.h>
#include <util/twi.h>
#include <util/delay.h>          //kniznica pre oneskorenia
*/

#include "variables.h"
#include "touchpanel.h"
#include "DS3231.h"

//#include	<stdio.h>
//#include 	"lcd.h"

//***********************************************************
//----------------------------------------------------------
//***********************************************************
void readtime(void)
	{
	uint8 buftimeX[3];	// 
        uint8 jedsec,jedmin,jedhod,dessec,desmin,deshod;

        tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 3);
  
	dessec=buftimeX[0]>>4;
	dessec&=7;
	jedsec=buftimeX[0]&15;

	desmin=buftimeX[1]>>4;
	desmin&=7;
	jedmin=buftimeX[1]&15;

	deshod=buftimeX[2]>>4;
	deshod&=3;
        jedhod=buftimeX[2]&15;
        
        //if(deshod)buftime[0]=deshod+48; else buftime[0]=' ';
        buftime[0]=deshod+48;
        
        buftime[1]=jedhod+48;
        buftime[2]=':';
        buftime[3]=desmin+48;
        buftime[4]=jedmin+48;
        buftime[5]=':';
        buftime[6]=dessec+48;
        buftime[7]=jedsec+48;
        buftime[8]=0;           //end of string   
	}
//;---------------------------------------------------------------
//****************************************************************
void settime (void)                 //write time & date to DS3231
	{
        //start register for writing
        uint8 RTC_CMD_REG = 0; //write to sec register
        uint8 buftimeX[3];
        
        buftimeX[0]=0;              //set 0sec
        
	buftimeX[1]=(minute/10)<<4; //set min
	buftimeX[1]|=(minute%10);

	buftimeX[2]=(hour/10)<<4;   //set hour
	buftimeX[2]|=(hour%10);
        
        if(scopesettings.onoffRTC) 
            {
            tp_i2c_send_data(RTC_DEVICE_ADDR, RTC_CMD_REG, buftimeX, 3);
            }
	return;
	}
//****************************************************************
//****************************************************************
void setdate (void)                 //write time & date to DS3231
	{
        //start register for writing
        uint8 RTC_CMD_REG = 3; //write to day register
        uint8 buftimeX[4];
       
        buftimeX[0]=6;              //set day
        
        buftimeX[1]=(day/10)<<4;    //set date
        buftimeX[1]|=(day%10);
        
        buftimeX[2]=(month/10)<<4;  //set month
        buftimeX[2]|=(month%10);

        buftimeX[3]=(year/10)<<4;   //set year 20xx 00 to 99
        buftimeX[3]|=(year%10);
        
        if(scopesettings.onoffRTC) 
            {
            tp_i2c_send_data(RTC_DEVICE_ADDR, RTC_CMD_REG, buftimeX, 4);
            }
	return;
	}
//****************************************************************
//*************************  Set time  ***************************
//****************************************************************

void hourUp (void)
	{
	if (hour<23) hour++; else hour=0;
        settime();
	return;
	}

void hourDown (void)
	{
	if (hour>0) hour--; else hour=23;
        settime();
	return;
	}
//--------------------------------------------------
void minuteUp (void)
	{
	if (minute<59) minute++; else minute=0;
        settime();
	return;
	}

void minuteDown (void)
	{
	if (minute>0) minute--; else minute=59;
        settime();
	return;
	}
//--------------------------------------------------
void dayUp (void)
    {
    if ((month==1)|(month==3)|(month==5)|(month==7)|(month==8)|(month==10)|(month==12))
        {if (day<31) day++; else day=1;}
    if ((month==2)|(month==4)|(month==6)|(month==9)|(month==11))
        {if (day<30) day++; else day=1;} 
        setdate();
	return;
    }
void dayDown (void)
    {
    if (day>1) day--; else 
        {if ((month==2)|(month==4)|(month==6)|(month==9)|(month==11))day=30; else day=31;}
    setdate();
    return;
    }
//--------------------------------------------------
void monthUp (void)
	{
	if (month<12) month++; else month=1;
        setdate();
	return;
	}
void monthDown (void)
	{
	if (month>1) month--; else month=12;
        setdate();
	return;
	}
//--------------------------------------------------
void yearUp (void)
	{
	if (year<40) year++; else year=22;
        setdate();
	return;
	}
void yearDown (void)
	{
	if (year>22) year--; else year=40;
        setdate();
	return;
	}
//------------------------------------------------------------------------------
//******************************************************************************

 void modname ( int8 *d, int8 *s )
{  
   while(*d) d++;
   *d=0;
   d++;
    while(*s) 
    {
       *d = *s;
       d++; 
       s++;
    }
   *d=0; 
}
 
//-------------------------------------------------------
//******************************************************* 
 //***********************************************************
void readnameRTC(void)
	{
	uint8 buftimeX[7];	// 
        uint8 jedsec,jedmin,jedhod,dessec,desmin,deshod,dated,datej,monthd,monthj,yeard,yearj;

        tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 7);
  
	dessec=buftimeX[0]>>4;
	dessec&=7;
	jedsec=buftimeX[0]&15;

	desmin=buftimeX[1]>>4;
	desmin&=7;
	jedmin=buftimeX[1]&15;

	deshod=buftimeX[2]>>4;
	deshod&=3;
        jedhod=buftimeX[2]&15;
        
        //day=buftimeX[3]&7;
        
	dated=buftimeX[4]>>4;
	dated&=3;
        datej=buftimeX[4]&15;
        
	monthd=buftimeX[5]>>4;
	monthd&=1;
        monthj=buftimeX[5]&15;

        yeard=buftimeX[6]>>4;
	yeard&=15;
        yearj=buftimeX[6]&15;
        
        
        filenameRTC[0]=yeard+48;
        filenameRTC[1]=yearj+48;
        filenameRTC[2]=monthd+48;
        filenameRTC[3]=monthj+48;
        filenameRTC[4]=dated+48;
        filenameRTC[5]=datej+48; 
        filenameRTC[6]='-';
        filenameRTC[7]=deshod+48;
        filenameRTC[8]=jedhod+48;
        filenameRTC[9]=desmin+48;
        filenameRTC[10]=jedmin+48;     
        filenameRTC[11]=dessec+48;
        filenameRTC[12]=jedsec+48;
        
        filenameRTC[13]=0;           //end of string 
	}
//;---------------------------------------------------------------
//****************************************************************
void decodethumbnailfilename (int8 *s)
{
   //int8 filename[32];
   uint8 x=0;
   uint8 dx=0;
   
   //finds 's'
   while(*s)
      {
      if (*s==115) {s=s+2;break;}   //115 is 's' and go 2positions right
      s++; 
      }
   
   //copy *s to filename  
   while(*s) 
      {
      filenameRTC[x] = *s;
      s++;
      x++;
      }
   //x++;
   filenameRTC[x]=' ';
   x++;
   filenameRTC[x]='2';
   x++;
   filenameRTC[x]='0';
   x++;
   s++;
   
   //dx=1;
   //copy *s to filename  
   while(*s) 
      {
      filenameRTC[x] = *s;
      if (dx==1) {x++;filenameRTC[x]='.';}
      if (dx==3) {x++;filenameRTC[x]='.';}
      if (dx==8) {x++;filenameRTC[x]=':';}
      if (dx==10) {x++;filenameRTC[x]=':';}
      s++;
      x++;
      dx++;
      }  
   filenameRTC[x++]=0;
  }

//;---------------------------------------------------------------
//****************************************************************
DWORD get_fattime (void)
{
    //uint8   tm_year,tm_mon,tm_mday,tm_hour,tm_min,tm_sec;
    uint8   tm_sec;
    uint8   tmp;
    uint8   buftimeX[7];
    
    if(scopesettings.onoffRTC) 
        {
        tp_i2c_read_data(RTC_DEVICE_ADDR, 0x00, buftimeX, 7);
  
	tmp=(buftimeX[0]>>4)&7;	
	tm_sec=(buftimeX[0]&15)+(10*tmp);
        
        tmp=(buftimeX[1]>>4)&7;	
	minute=(buftimeX[1]&15)+(10*tmp);
        
        tmp=(buftimeX[2]>>4)&3;	
	hour=(buftimeX[2]&15)+(10*tmp);
        
        tmp=(buftimeX[4]>>4)&3;	
	day=(buftimeX[4]&15)+(10*tmp);
        
        tmp=(buftimeX[5]>>4)&1;	
	month=(buftimeX[5]&15)+(10*tmp);
        
        tmp=(buftimeX[6]>>4)&15;	
	year=(buftimeX[6]&15)+(10*tmp);

   
        //return date and time
        return (DWORD)(year+20) << 25 |
               (DWORD)(month) << 21 |
               (DWORD)(day-20) << 16 |
               (DWORD)(hour) << 11 |
               (DWORD)minute << 5 |
               (DWORD)tm_sec >> 1; 
    } else 
        //Some date and time value
        return(1449957149);   //Ne 12. marec 2023, 19:56:58
}




