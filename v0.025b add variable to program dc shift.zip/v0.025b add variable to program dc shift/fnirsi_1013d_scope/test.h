//----------------------------------------------------------------------------------------------------------------------------------

#include "fnirsi_1013d_scope.h"
#include "variables.h"

//----------------------------------------------------------------------------------------------------------------------------------

 
 
    //void scope_update_cursor_possition(void);
 
//void scope_preset_long_mode(void);

void scope_get_long_timebase_data(void);

void scope_check_long_trigger(void);



//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_ADoffset_value(void);

void scope_test_TP(void);

void scope_test_sunlight(void);

void scope_test_longbase_value(void);

void scope_test_trigerposition_value(void);
void scope_test_calibration_value(void);

//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------
