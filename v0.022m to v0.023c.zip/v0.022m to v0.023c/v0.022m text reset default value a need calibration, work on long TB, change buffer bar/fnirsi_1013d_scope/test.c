//----------------------------------------------------------------------------------------------------------------------------------
#include "types.h"
#include "menu.h"
#include "test.h"
#include "scope_functions.h"
#include "statemachine.h"
#include "touchpanel.h"
#include "timer.h"
#include "fpga_control.h"
#include "spi_control.h"
#include "sd_card_interface.h"
#include "display_lib.h"
#include "ff.h"
#include "DS3231.h"

#include "usb_interface.h"
#include "variables.h"

#include "sin_cos_math.h"

#include <string.h>
//----------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------

void scope_get_long_timebase_data(void)
{
  //Default timeout for 50S/div
  uint32    timeout = 2000;
  uint32    curticks;
  //uint32    signaladjust;
  //uint32    temp1, temp2;
  //uint16    *ptr;
  uint16    channel1tracebuffer1[0];
  uint16    channel2tracebuffer1[0];
  
  //Send the time base command for the longer settings
  fpga_set_long_timebase();
/*  
  //Get the delay setting based on the time base
  switch(scopesettings.timeperdiv)
  {
    //50S/div
    case 1:
      timeout = 2000;
      break;
    //20S/div
    case 1:
      timeout = 800;//1000
      break;

    //10S/div
    case 2:
      timeout = 400;
      break;

    //5S/div
    case 3:
      timeout = 200;
      break;

    //2S/div
    case 4:
      timeout = 80;
      break;

    //1S/div
    case 5:
      timeout = 40;
      break;

    //500mS/div
    case 6:
      timeout = 20;
      break;

    //200mS/div
    case 7:
      timeout = 8;
      break;

    //100mS/div
    case 8:
      timeout = 4;
      break;
  }
 */ 
  
  timeout = 40;//1s
  
  //Make the timeout timer tick related by adding it to the previous capture
  //timeout += scopesettings.previoustimerticks;
  timeout += previoustimerticks;
  
  //For smaller timeouts (500mS/div, 200mS/div and 100mS/div) stay in the wait loop even if there is touch
  //while((scopesettings.timeperdiv > 5) || (havetouch == 0))
  while((havetouch == 0))
  {
    //Get the current ticks
    curticks = timer0_get_ticks();
  
    //Check if there is a timeout
    //While technically prone to error on timer ticks overflow the scope has to be running for >49 days before it occurs
    if(curticks >= timeout)
    {
      //Save the current ticks for next timeout and bail out the loop
      //scopesettings.previoustimerticks = curticks;
      previoustimerticks = curticks;
      goto skip_delay;
    }
    
    //Scan the touch panel to see if there is user input
    tp_i2c_read_status();
  }
    
  //Wait an extra 40 milliseconds when there was touch
  timer0_delay(40);
  
skip_delay:
  //Some mode select command for the FPGA (0x01 for long time base)
  fpga_write_cmd(0x28);
  fpga_write_byte(0x01);
  
  //Read, accumulate and average 10 bytes of channel 1 trace data
  channel1tracebuffer1[0] = fpga_average_trace_data(0x24);
  //scopesettings.channel2.tracebuffer[i]
  
  //Read, accumulate and average 10 bytes of channel 2 trace data
  channel2tracebuffer1[0] = fpga_average_trace_data(0x26);
  //scopesettings.channel2.tracebuffer[i]
  
  //Need insight in the code that displays the data to get an understanding of the next bit of code
  //It is a more or less straight conversion from what Ghidra shows
 /* 
  //Some fractional scaling on the signal to fit it on screen???
  //Adjust the channel 1 signal based on the volts per div setting
  signaladjust = channel1tracebuffer1[0] * signal_adjusters[scopesettings.channel1.samplevoltperdiv];
  temp1 = ((0xA3D7 * signaladjust) + 0xA3D7) >> 0x16;
  temp2 = signaladjust + (((int64)((int64)signaladjust * (int64)0x51EB851F) >> 0x25) * -100);
  
  //If above half the pixel up to next one?????
  if(temp2 > 50)
  {
    temp1++;
  }
  
  //Store it somewhere
  channel1tracebuffer3[0] = temp1;                    //At address 0x801A916A in original code

  //Check if data needs to be doubled
  //This is missing in the original code  
  if(scopesettings.channel1.samplevoltperdiv == 6)
  {
    //Only on highest sensitivity
    temp1 <<= 1;
    
    //Check if the data is smaller then the offset
    if(temp1 < scopesettings.channel1.traceoffset)
    {
      //If so limit to top of the screen
      temp1 = 0;
    }
    else
    {
      //Else take of the offset
      temp1 = temp1 - scopesettings.channel1.traceoffset;
    }
  }
  */
 /* 
  //Destination buffer is declared as uint32 to be able to use it with file functions, so need to cast it to uint16 pointer here
  ptr = (uint16 *)channel1tracebuffer4;
  
  //Check if outside displayable range??
  if(temp1 > 401)
  {
    //Keep it on max allowed
    *ptr = 401;                    //At address 0x801AC04A in original code
  }
  else
  {
    //Else store it again in an other location
    *ptr = temp1;
  }
  
  //Some fractional scaling on the signal to fit it on screen???
  //Adjust the channel 2 signal based on the volts per div setting
  signaladjust = channel2tracebuffer1[0] * signal_adjusters[scopesettings.channel2.voltperdiv];
  temp1 = ((0xA3D7 * signaladjust) + 0xA3D7) >> 0x16;
  temp2 = signaladjust + (((int64)((int64)signaladjust * (int64)0x51EB851F) >> 0x25) * -100);
  
  //If above half the pixel up to next one?????
  if(temp2 > 50)
  {
    temp1++;
  }
  
  //Store it somewhere
  channel2tracebuffer3[0] = temp1;               //At address 0x801AA8DA in original code

  //Check if data needs to be doubled
  //This is missing in the original code  
  if(scopesettings.channel2.voltperdiv == 6)
  {
    //Only on highest sensitivity
    temp1 <<= 1;
    
    //Check if the data is smaller then the offset
    if(temp1 < scopesettings.channel2.traceoffset)
    {
      //If so limit to top of the screen
      temp1 = 0;
    }
    else
    {
      //Else take of the offset
      temp1 = temp1 - scopesettings.channel2.traceoffset;
    }
  }
  
  //Destination buffer is declared as uint32 to be able to use it with file functions, so need to cast it to uint16 pointer here
  ptr = (uint16 *)channel2tracebuffer4;
  
  //Check if outside displayable range??
  if(temp1 > 401)
  {
    //Keep it on max allowed
    *ptr = 401;               //At address 0x801AD7BA in original code
  }
  else
  {
    //Else store it again in an other location
    *ptr = temp1;
  }
   */
}

//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------------------------------------------
/*
void scope_trigger_mode_select(void)
{
  
}
*/

//----------------------------------------------------------------------------------------------------------------------------------
//**********************************************************************************************************************************
//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_ADoffset_value(void)
{
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 220);  //x , y , sirka, vyska
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);
      //uint32 center = (scopesettings.channel1.center * signal_adjusters[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;   
      
       
 // uint32 offset;
  uint32    max1;
  uint32    min1;    
  uint32    p2p1; 
  uint32    center1x; 
      
    max1 = (scopesettings.channel1.max * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    center1x = (scopesettings.channel1.center * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    min1 = (scopesettings.channel1.min * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
    p2p1 = (scopesettings.channel1.peakpeak * scopesettings.channel1.input_calibration[scopesettings.channel1.displayvoltperdiv]) >> VOLTAGE_SHIFTER;
      
      display_decimal(550, 0, max1 );
      display_decimal(550, 10, center1x);
      display_decimal(550, 20, min1);
      display_decimal(550, 30, p2p1);
      
      display_decimal(600, 0, scopesettings.channel1.max );
      display_decimal(600, 10, scopesettings.channel1.center );
      display_decimal(600, 20, scopesettings.channel1.min );
      display_decimal(600, 30, scopesettings.channel1.peakpeak );
      
      //display_decimal(630, 20, scopesettings.voltcursor1position );
      //display_decimal(630, 30, scopesettings.voltcursor2position );
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_sunlight(void)
{
  //Draw the background
  display_fill_rect(159, 116, 226, 36);

  if(mode == 0)
  {
    //Inactive so white foreground and grey background
    display_set_fg_color(WHITE_COLOR);
    display_set_bg_color(DARKGREY_COLOR);
  }
  else
  {
    Active so black foreground and yellow background
    display_set_fg_color(BLACK_COLOR);
    display_set_bg_color(YELLOW_COLOR);
  }
 

  //Display the icon with the set colors
  display_copy_icon_use_colors(light_icon, 350, 10, 24, 24);    //light-sun icon
}

//----------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_trigerposition_value(void)
{
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 220);  //x , y , sirka, vyska
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);

      //display_decimal(600, 0, triggerposition);
      display_decimal(600, 10, disp_xstart);
      display_decimal(600, 20, disp_xend);
      display_decimal(600, 30, disp_first_sample);
      
      
      //display_decimal(600, 50,  ((disp_trigger_index - disp_first_sample + 1) * 727.0) / (disp_trigger_index - disp_first_sample >= 0 ? (727.0 / disp_xpos_per_sample) : 1));
      //display_decimal(600, 60,  int32 ((disp_trigger_index - disp_first_sample + 1) * 727.0) / (727.0 / disp_xpos_per_sample));
      //display_decimal(600, 50,  (((1500          ) * 727.0) / (727.0 / disp_xpos_per_sample)+15));
      //display_decimal(600, 60,  (((1500 - 3000 ) * 727.0) / (727.0 / disp_xpos_per_sample)));
      
     // (disp_trigger_index - disp_first_sample + 1) / (727.0 / disp_xpos_per_sample)
      
      //display_decimal(600, 70, disp_trigger_index);
      //display_decimal(600, 80, disp_xpos_per_sample);  
      
      display_decimal(600, 210, scopesettings.timeperdiv);
      display_decimal(600, 220, scopesettings.samplerate);
}

//----------------------------------------------------------------------------------------------------------------------------------

void scope_test_calibration_value(void)
{
      display_set_fg_color(BLACK_COLOR);
      //Fill the settings background
      display_fill_rect(550, 0, 100, 250);  //x , y , sirka, vyska 220
      display_set_fg_color(WHITE_COLOR);
      display_set_font(&font_2);
      //display_text(650, 10, buffertime);
  
      display_decimal(600, 40, scopesettings.channel1.dc_calibration_offset[0]);
      display_decimal(600, 50, scopesettings.channel1.dc_calibration_offset[1]);
      display_decimal(600, 60, scopesettings.channel1.dc_calibration_offset[2]);
      display_decimal(600, 70, scopesettings.channel1.dc_calibration_offset[3]);
      display_decimal(600, 80, scopesettings.channel1.dc_calibration_offset[4]);
      display_decimal(600, 90, scopesettings.channel1.dc_calibration_offset[5]);
      display_decimal(600, 100, scopesettings.channel1.dc_calibration_offset[6]);
      
      display_decimal(600, 120, scopesettings.channel2.dc_calibration_offset[0]);
      display_decimal(600, 130, scopesettings.channel2.dc_calibration_offset[1]);
      display_decimal(600, 140, scopesettings.channel2.dc_calibration_offset[2]);
      display_decimal(600, 150, scopesettings.channel2.dc_calibration_offset[3]);
      display_decimal(600, 160, scopesettings.channel2.dc_calibration_offset[4]);
      display_decimal(600, 170, scopesettings.channel2.dc_calibration_offset[5]);
      display_decimal(600, 180, scopesettings.channel2.dc_calibration_offset[6]);
      
      display_decimal(600, 210, scopesettings.channel1.adc1compensation);
      display_decimal(600, 220, scopesettings.channel1.adc2compensation);
      display_decimal(600, 230, scopesettings.channel2.adc1compensation);
      display_decimal(600, 240, scopesettings.channel2.adc2compensation);
      
      display_decimal(650, 40, scopesettings.channel1.input_calibration[0]);
      display_decimal(650, 50, scopesettings.channel1.input_calibration[1]);
      display_decimal(650, 60, scopesettings.channel1.input_calibration[2]);
      display_decimal(650, 70, scopesettings.channel1.input_calibration[3]);
      display_decimal(650, 80, scopesettings.channel1.input_calibration[4]);
      display_decimal(650, 90, scopesettings.channel1.input_calibration[5]);
      display_decimal(650, 100, scopesettings.channel1.input_calibration[6]);
      
      display_decimal(650, 120, scopesettings.channel2.input_calibration[0]);
      display_decimal(650, 130, scopesettings.channel2.input_calibration[1]);
      display_decimal(650, 140, scopesettings.channel2.input_calibration[2]);
      display_decimal(650, 150, scopesettings.channel2.input_calibration[3]);
      display_decimal(650, 160, scopesettings.channel2.input_calibration[4]);
      display_decimal(650, 170, scopesettings.channel2.input_calibration[5]);
      display_decimal(650, 180, scopesettings.channel2.input_calibration[6]);
      
    int32   volts;
    int32   value;
    PVOLTCALCDATA vcd;
    
    //Calculate the voltage based on the channel settings
    vcd = (PVOLTCALCDATA)&volt_calc_data[scopesettings.channel2.magnification][scopesettings.channel2.displayvoltperdiv];
    
    //value=scopesettings.channel1.peakpeak;
    value=scopesettings.channel2.max-128;
    
    volts = (value * scopesettings.channel2.input_calibration[5]) >> VOLTAGE_SHIFTER;
    
    volts *= vcd->mul_factor;
      
    display_decimal(650, 190, value);
    display_decimal(650, 200, volts);
    
    display_decimal(600, 190, scopesettings.channel2.displayvoltperdiv);
    display_decimal(600, 200, scopesettings.channel2.magnification);
    
}
//----------------------------------------------------------------------------------------------------------------------------------