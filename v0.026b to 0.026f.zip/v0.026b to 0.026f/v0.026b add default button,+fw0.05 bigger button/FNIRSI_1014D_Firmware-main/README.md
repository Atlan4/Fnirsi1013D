# FNIRSI_1014D_FIRMWARE

New firmware for the FNIRSI-1014D oscilloscope.

This new firmware is offered without any warrenty and I take no responsibility for any damage.

!!! It is only suited for the 1014D. It won't work on the 1013D. !!!

This repository is a result of the reverse engineering of the original FNIRSI 1013D and 1014D firmwares.

---------------------------------------------------------------------------------------------------------
28 June 2024

Added a boot loader to the repository.
This boot loader is for the 1014D and allows for starting different firmware's via a startup menu.
The menu is accessed by holding another key when starting the scope.
